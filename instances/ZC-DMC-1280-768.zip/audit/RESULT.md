# ZC-DMC — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| ZC-DMC-1280-512 | `ZC-DMC-1280-512.so` | 34352 B | `be562d3b5a6e26262cc2457ae760bd9fa9eece93e0b855b29b1f1d2de649b2d5` |
| ZC-DMC-1280-768 | `ZC-DMC-1280-768.so` | 34352 B | `be562d3b5a6e26262cc2457ae760bd9fa9eece93e0b855b29b1f1d2de649b2d5` |
| ZC-DMC-1536-1024 | `ZC-DMC-1536-1024.so` | 21912 B | `7d6764f210b3915a8ff103c196424e32cc863157b1f991d89836d6420ba8440b` |
| ZC-DMC-1536-512 | `ZC-DMC-1536-512.so` | 21912 B | `7d6764f210b3915a8ff103c196424e32cc863157b1f991d89836d6420ba8440b` |
| ZC-DMC-1536-768 | `ZC-DMC-1536-768.so` | 21912 B | `7d6764f210b3915a8ff103c196424e32cc863157b1f991d89836d6420ba8440b` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| ZC-DMC-1280-512 | 512 | 7.1475 | 5.5805 | 5.1207 | 1.0898 | 1.0836 |
| ZC-DMC-1280-768 | 768 | 11.0059 | 8.6219 | 7.9936 | 1.0786 | 1.0738 |
| ZC-DMC-1536-1024 | 1024 | 24.1348 | 15.0714 | 11.6624 | 1.2923 | 1.3201 |
| ZC-DMC-1536-512 | 512 | 11.6172 | 7.4819 | 5.4765 | 1.3662 | 1.3695 |
| ZC-DMC-1536-768 | 768 | 19.667 | 12.5401 | 9.461 | 1.3254 | 1.3292 |

## 优化方法（逐实例原文，来自交付清单）

### ZC-DMC-1280-512
**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息长度无关 ⇒ 短消息里它占整次调用的相当比例，而 cpB 表的几何均值含 S1/S2，收益直接进总 gm。改法（`zc/try_1280_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.013649（512 B 处 1.0155、1024 B 1.0287、4096 B 1.0112、65536 B 0.9995）。ZC-DMC 胶水每块只回容量部分，异或链比 EDMC 短，所以同一段 pad 空转摊到总时间里的占比也更小 —— 这是它的收益（1.0–1.6%）小于 ZC-DM（1.0–3.3%）与 ZC-EDMC（1.0–3.1%）的原因。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DMC-1280-768
**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息长度无关 ⇒ 短消息里它占整次调用的相当比例，而 cpB 表的几何均值含 S1/S2，收益直接进总 gm。改法（`zc/try_1280_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.016402（512 B 处 1.0362、1024 B 1.0227、4096 B 1.0079、65536 B 0.9992）。ZC-DMC 胶水每块只回容量部分，异或链比 EDMC 短，所以同一段 pad 空转摊到总时间里的占比也更小 —— 这是它的收益（1.0–1.6%）小于 ZC-DM（1.0–3.3%）与 ZC-EDMC（1.0–3.1%）的原因。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DMC-1536-1024
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.014921（512 B 处 1.0305、1024 B 1.0199、4096 B 1.0095、65536 B 1.0001）。本档 rate = 56 B，pad 空转上限 447 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-DMC 胶水每块只回容量部分，异或链比 EDMC 短，所以同一段 pad 空转摊到总时间里的占比更小 —— 这是它的收益（1.1–5.0%）小于 ZC-DM（2.3–12.1%）与 ZC-EDMC（2.1–8.2%）的原因。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DMC-1536-512
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.049848（512 B 处 1.1117、1024 B 1.0513、4096 B 1.0351、65536 B 1.0043）。本档 rate = 120 B，pad 空转上限 959 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-DMC 胶水每块只回容量部分，异或链比 EDMC 短，所以同一段 pad 空转摊到总时间里的占比更小 —— 这是它的收益（1.1–5.0%）小于 ZC-DM（2.3–12.1%）与 ZC-EDMC（2.1–8.2%）的原因。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DMC-1536-768
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.011437（512 B 处 1.0142、1024 B 1.0216、4096 B 1.0101、65536 B 1.0000）。本档 rate = 88 B，pad 空转上限 703 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-DMC 胶水每块只回容量部分，异或链比 EDMC 短，所以同一段 pad 空转摊到总时间里的占比更小 —— 这是它的收益（1.1–5.0%）小于 ZC-DM（2.3–12.1%）与 ZC-EDMC（2.1–8.2%）的原因。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。
