# ZC-DMC-1280-768

Algorithm: ZC-DMC | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header ZC-DMC-1280-768.h, prebuilt ZC-DMC-1280-768.so,
KAT vector KAT_2_12_ZC-DMC-1280-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): be562d3b5a6e26262cc2457ae760bd9fa9eece93e0b855b29b1f1d2de649b2d5
Speed (cpB, lower is faster): reference 11.01 / official-optimized 8.62 / optimized 7.99
Speedup: GM(S1-S8) 1.07x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
