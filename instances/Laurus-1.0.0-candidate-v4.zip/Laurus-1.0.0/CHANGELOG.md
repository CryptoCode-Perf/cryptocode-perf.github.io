# Candidate change record

The inherited optimized implementation consumed whole bytes and did not match
the official bit-oriented KAT for non-byte-aligned inputs. CryptoCode's candidate
keeps the byte-aligned path and adds bit-tail padding and block-boundary handling.

All three candidates passed their 4097-record KAT and selected long-input
comparisons against the official reference. Address and undefined-behavior
checks covered selected boundary lengths. These checks do not prove correctness
for every input or cryptographic security.

The official optimized adapter in test/ is only for byte-aligned comparison; it
rejects non-aligned inputs and does not claim to implement the full bit API.
Performance measurement and redistribution authorization remain pending.
