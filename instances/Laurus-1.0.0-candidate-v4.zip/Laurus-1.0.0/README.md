# Laurus candidate package

Instances: Laurus-512, Laurus-768 and Laurus-1024.

On x86-64 Linux with GCC, Python 3 and AVX2 support, run:

```sh
bash build_and_verify.sh
```

The script rebuilds the official reference and CryptoCode implementation for each
instance and checks all records in the bundled KAT. The official optimized implementation is also rebuilt and tested on its 513
byte-aligned vectors per instance; the adapter rejects non-byte-aligned input.
Performance comparison remains pending.

The bit-oriented input repair is experimental. KAT and selected differential
and sanitizer checks passed; performance comparison and clean archive acceptance
remain pending. Do not treat this package as an approved release.

The original implementation and KAT redistribution terms require confirmation.
No license grant is asserted by this package.

For selected address and undefined-behavior checks, run:

```sh
bash test/run_sanitizers.sh
```

The sanitizer run covers selected boundary lengths, not every possible input.
The official optimized adapter is byte-aligned only and rejects other inputs.
