#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for bits in 512 768 1024; do
  ref="Reference_Implementation/Laurus-$bits"
  gcc -O2 -fPIC -shared -Wl,-z,defs -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" "$ref/laurus_$bits.c" -o "build/reference-$bits.so"
  python3 "test/kat_check_$bits.py" "build/reference-$bits.so" 100000 0 "kat/Laurus-$bits.txt"
  gcc -O3 -march=x86-64 -mavx2 -fPIC -shared -Wl,-z,defs "CryptoCode_Implementation/Laurus-$bits/core.c" -o "build/Laurus-$bits.so"
  python3 "test/kat_check_$bits.py" "build/Laurus-$bits.so" 100000 0 "kat/Laurus-$bits.txt"
done

python3 test/check_official_opt.py
python3 test/long_differential.py
