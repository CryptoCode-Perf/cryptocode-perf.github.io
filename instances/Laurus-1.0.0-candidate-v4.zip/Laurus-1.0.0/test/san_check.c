#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
extern int CryptHash(int,const unsigned char*,unsigned long long,unsigned char*);
#ifndef BITS
#define BITS 1024
#endif
int main(void){unsigned lens[]={0,1,7,8,9,511,512,513,767,768,769,1023,1024,1025,4095,4096,4097,65535,65536,65537};for(unsigned i=0;i<sizeof(lens)/sizeof(*lens);i++){unsigned n=lens[i],bytes=(n+7)/8;unsigned char *m=malloc(bytes?bytes:1),*o=malloc(BITS/8);if(!m||!o)return 2;memset(m,0xa5,bytes?bytes:1);if(CryptHash(BITS,m,n,o))return 3;free(m);free(o);}puts("sanitizer cases passed");return 0;}
