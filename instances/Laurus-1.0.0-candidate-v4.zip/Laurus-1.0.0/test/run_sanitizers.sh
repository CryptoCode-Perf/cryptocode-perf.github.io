#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
for bits in 512 768 1024; do
  gcc -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -DBITS="$bits" "CryptoCode_Implementation/Laurus-$bits/core.c" test/san_check.c -o "build/san-$bits"
  "build/san-$bits"
done
