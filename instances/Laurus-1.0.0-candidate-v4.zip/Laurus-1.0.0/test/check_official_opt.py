from pathlib import Path
import subprocess,ctypes,importlib.util,json
r=Path(__file__).resolve().parent.parent;out=[]
for b in (512,768,1024):
 d=r/'Optimized_Implementation'/f'Laurus-{b}';lib=r/'build'/f'official-opt-{b}.so';subprocess.run(['gcc','-O3','-march=x86-64','-mavx2','-fPIC','-shared','-Wl,-z,defs','-I'+str(d),str(d/f'laurus_{b}.c'),str(r/'test'/f'official_opt_adapter_{b}.c'),'-o',str(lib)],check=True)
 spec=importlib.util.spec_from_file_location('kat',r/'test'/f'kat_check_{b}.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);records=m.parse_kat(r/'kat'/f'Laurus-{b}.txt');aligned=[v for v in records if v[0]%8==0];
 if len(records)!=4097 or len(aligned)!=513: raise ValueError('Unexpected KAT record counts')
 l=ctypes.CDLL(str(lib));l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int;bad=0
 for n,msg,dl,dst in aligned:
  buf=ctypes.create_string_buffer(b//8);rc=l.CryptHash(b,msg,n,buf);bad+=rc!=0 or buf.raw!=dst
 buf=ctypes.create_string_buffer(b//8);reject=l.CryptHash(b,b'\x80',1,buf)!=0
 out.append({'bits':b,'aligned_cases':len(aligned),'mismatches':bad,'nonaligned_rejected':reject});print(out[-1])
(r/'build'/'official-opt-aligned.json').write_text(json.dumps(out,indent=2))
if any(x['mismatches'] or not x['nonaligned_rejected'] for x in out): raise SystemExit(1)
