#include <stddef.h>
#include <stdint.h>
#include "laurus_768.h"
/* The official optimized implementation accepts byte lengths only. */
int CryptHash(int digest_bits,const unsigned char *msg,unsigned long long msg_bits,unsigned char *out) {
 if (digest_bits != 768 || !out || (!msg && msg_bits) || (msg_bits & 7)) return -1;
 laurus_768(out,msg,msg_bits / 8); return 0;
}
