#include <stddef.h>
#include <stdint.h>
#include "laurus_1024.h"
/* The official optimized implementation accepts byte lengths only. */
int CryptHash(int digest_bits,const unsigned char *msg,unsigned long long msg_bits,unsigned char *out) {
 if (digest_bits != 1024 || !out || (!msg && msg_bits) || (msg_bits & 7)) return -1;
 laurus_1024(out,msg,msg_bits / 8); return 0;
}
