# MEGASCON candidate package

Instances: MEGASCON-384, MEGASCON-512, MEGASCON-768 and MEGASCON-1024.
XOF instances are not included. On x86-64 Linux with GCC, G++, Python 3 and
AVX2, run `bash build_and_verify.sh`. It rebuilds reference, official optimized
and CryptoCode implementations, checks 4097 known-answer vectors per build,
compares deterministic long and boundary inputs, and checks selected input
and output guard pages. `CryptHash` lengths are in bits.

CryptoCode wrappers and generated assembly were recovered from the local
performance report and its build tree. Jasmin source is included, but the
build does not regenerate assembly. Candidate only: XOF coverage, controlled
performance comparison, independent source and license review, redistribution
permission and final release review remain pending. Tests do not prove security.
