/*
 * glue_megascon1024_fast.c --- MEGASCON-1024 交付件的**驱动层重写**。
 *
 * ## 为什么要重写驱动层
 *
 * `probe_call_cost.py` 的分解（16384 bit = 18 块）：
 *
 *   | 口径 | opt cyc/块 | ours cyc/块 |
 *   |---|---|---|
 *   | 真实置换 | 455.0 | 527.5 |
 *   | 置换清空（只留驱动） | 492.5 | **79.1** |
 *
 *   ⇒ 我方 `调用+核心 = 448.3`，而**核心单测 = 459** ⇒ **纯调用边界 ≈ −10.7 周期
 *   （在噪声内，等于零）**。所以差距**不在调用边界**，在驱动本身：我方驱动
 *   79.1 周期/块，官方（零 `call`、650 条指令内联）≈ 7 周期/块。
 *   `527.5 − 455.0 = 72.5` 与 `79.1 − 7` 对得上 ⇒ **72 周期就是全部差距**。
 *
 * ## 官方 Reference 驱动（我们原来逐字保留的那份）为什么贵
 *
 * 1. **整条消息 malloc + memset + memcpy**（P1 形态）：`padded_input =
 *    malloc(padded_len); memset(...); memcpy(padded_input, input, full_bytes);`
 * 2. **逐字节吸收**：`for (j = 0; j < rate; j++) state[j] ^= padded_input[...]`
 *    —— 120 次单字节读改写，而不是 15 次 u64 异或。
 * 3. **每块把 capacity 136 B 拷进 `forward[256]` 再拷回来**做 feedforward。
 * 4. `state[256]` 与 `IV[256]` 两次 memset 512 B。
 *
 * ## 本文件的做法（与官方**优化版驱动同形**，不是另创算法）
 *
 * - **不 malloc**：消息块直接从 `input` 读；只有**最后一块**（含 padding 字节）
 *   在栈上 120 B 缓冲里拼。
 * - **u64 吸收**：15 次 `memcpy(&v, b+8i, 8)` + 异或（编译器出 unaligned load）。
 * - **feedforward 用 17 个标量局部**（`f33` + `f4..f7`，正好 136 B），与官方
 *   `fast_absorb_one120_scalar` 完全同形。
 * - 状态 256 B memset 一次。
 *
 * ## 语义等价性由四道门保证（不靠推理）
 *
 * padding 语义逐字复刻官方 Reference（含 `remaining_bits` 的部分字节掩码、
 * `0x80 >> remaining_bits` 的落位、以及「长度正好对齐时**仍要多吸收一整块**」
 * 这条 `((L + rate*8) / (rate*8)) * rate*8` 的规则）。任何不一致都会被
 * `delivery_gate.py` 的 11 个位长（含 0 位与 1000/16384 这类非对齐长度）抓到。
 */

#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "CryptHash_AlgorithmInstance.h"

#define ULL unsigned long long
#define RATE_BYTES 120
#define STATE_BYTES 256
#define HASH_BYTES 128

/* ★ 状态声明成 8 个 `__m256i`（一行 = 一个 256 位向量），而不是 `uint64_t w[8][4]`。
 *
 * 为什么：第一版用 `uint64_t w[8][4]` + `for (i=0;i<4;i++) s->w[4][i] ^= f4[i];`
 * 做 feedforward，GCC 没有把它识别成 32 字节整块异或，而是发了一串
 * `vmovq` / `vpinsrq $1` / `vinserti128` 把 136 B capacity **从内存里逐段
 * 重新拼装**（objdump 在 `hash_Fsponge.part.0+0x100` 一带能看到成片的
 * `vmovq 0x150(%rsp)` / `vpinsrq`）。这与 QILIN 那次「存 32 B 向量、读回 8 B
 * 标量」是同一个病：**编译器把向量往返合成为寄存器搬运，白烧 p5**。
 *
 * 改成 `__m256i` 之后 feedforward 就是 `load / vpxor / store` 各 4 条 32 字节指令。 */
typedef struct __attribute__((aligned(64))) {
    __m256i w[8];
} State2048;

extern void megascon_perm(uint64_t *p);

/* 保留 `permutation` 符号：官方 KAT/胶水历史上用过它，删掉会让「置换到底有没有
 * 被换掉」变得不可核对。它现在只做一次原地调用（0 条打包指令）。 */
void permutation(unsigned char *state, unsigned rounds)
{
    (void)rounds;
    megascon_perm((uint64_t *)state);
}

static inline uint64_t load_u64_unaligned(const unsigned char *p)
{
    uint64_t x;
    memcpy(&x, p, sizeof(x));
    return x;
}

/* 吸收 120 字节 = 15 个 u64：
 *   w[0] ← 字节  0..31   w[1] ← 字节 32..63   w[2] ← 字节 64..95
 *   w[3] ← 字节 96..119（只有低 128 位 = 2 个 u64 … 实际是 3 个 u64 = 24 B）
 * 注意 120 = 32*3 + 24，所以第 4 行只覆盖 3 个 lane（24 B），用 128 位 + 64 位
 * 拼一次，不碰第 4 个 lane（那是 capacity 的起点，稍后由 perm_ff 处理）。 */
static inline void absorb120(State2048 *s, const unsigned char *b)
{
    __m128i lo = _mm_loadu_si128((const __m128i *)(b + 96));
    uint64_t hi = load_u64_unaligned(b + 112);
    /* ★ 必须从 `setzero` 起手：`_mm256_castsi128_si256` 的上 128 位是**未定义**的，
     * 直接 insert 会留下 lane 3 的垃圾，再 XOR 进 w[3] 就把 capacity 打坏。 */
    __m256i r3 = _mm256_inserti128_si256(_mm256_setzero_si256(), lo, 0);
    r3 = _mm256_insert_epi64(r3, hi, 2);   /* lane 3 保持 0（不吸收） */

    s->w[0] = _mm256_xor_si256(s->w[0], _mm256_loadu_si256((const __m256i *)(b + 0)));
    s->w[1] = _mm256_xor_si256(s->w[1], _mm256_loadu_si256((const __m256i *)(b + 32)));
    s->w[2] = _mm256_xor_si256(s->w[2], _mm256_loadu_si256((const __m256i *)(b + 64)));
    s->w[3] = _mm256_xor_si256(s->w[3], r3);
}

/* 置换 + feedforward。capacity 起点是字节 120 = w[3] 的 lane 3。
 * 与官方 `fast_absorb_one120_scalar`(:517-543) 同形：f33 + f4..f7 共 17 个 u64，
 * 但这里**按 32 字节整行搬**，不做标量拼装。 */
static inline void perm_ff(State2048 *s, int final_block)
{
    /* 只有 lane 3 参与 feedforward（其余 3 个 lane 是 rate 区，已被吸收异或过） */
    const __m256i lane3 = _mm256_set_epi64x(-1LL, 0, 0, 0);
    __m256i f3, f4, f5, f6, f7;

    if (final_block) {
        s->w[3] = _mm256_xor_si256(s->w[3], _mm256_set_epi64x(0x80ULL, 0, 0, 0));
    }

    f3 = _mm256_and_si256(s->w[3], lane3);
    f4 = s->w[4];
    f5 = s->w[5];
    f6 = s->w[6];
    f7 = s->w[7];

    megascon_perm((uint64_t *)&s->w[0]);

    s->w[3] = _mm256_xor_si256(s->w[3], f3);
    s->w[4] = _mm256_xor_si256(s->w[4], f4);
    s->w[5] = _mm256_xor_si256(s->w[5], f5);
    s->w[6] = _mm256_xor_si256(s->w[6], f6);
    s->w[7] = _mm256_xor_si256(s->w[7], f7);
}

int hash_Fsponge(int hash, int rate, const unsigned char *input,
                 ULL input_len_bits, int output_len_bits,
                 unsigned char *output)
{
    State2048 st;
    ULL full_bytes;
    unsigned int rem;
    ULL last_block;          /* 最后一块的块号（含 padding 字节的那块） */
    unsigned int off_in_last; /* padding 字节在该块内的偏移 */
    ULL i;

    (void)output_len_bits;

    if (rate != RATE_BYTES || hash != HASH_BYTES) {
        printf("Invalid rate or hash length\n");
        return 1;
    }

    memset(&st, 0, sizeof(st));   /* IV 全零 */

    full_bytes = input_len_bits / 8ULL;
    rem = (unsigned int)(input_len_bits & 7ULL);

    /* 块数 = floor(input_len_bits / 960) + 1，恒至少 1 块。
     * 这与官方 `((L + rate*8) / (rate*8)) * rate*8` 等价（见文件头推导）。 */
    last_block = full_bytes / (ULL)RATE_BYTES;
    off_in_last = (unsigned int)(full_bytes % (ULL)RATE_BYTES);

    /* 前面的满块：直接从 input 吸收，不复制整条消息 */
    for (i = 0; i < last_block; i++) {
        absorb120(&st, input + i * (ULL)RATE_BYTES);
        perm_ff(&st, 0);
    }

    /* 最后一块：拼进栈缓冲（消息剩余部分 + padding 字节 + 全零） */
    {
        unsigned char blk[RATE_BYTES];
        unsigned int n = off_in_last;

        if (n > 0U) {
            memcpy(blk, input + last_block * (ULL)RATE_BYTES, (size_t)n);
        }
        if (n < RATE_BYTES) {
            memset(blk + n, 0, (size_t)(RATE_BYTES - n));
        }
        if (rem > 0U) {
            unsigned char mask = (unsigned char)(0xFFU << (8U - rem));
            unsigned char b = (unsigned char)(input[full_bytes] & mask);
            b = (unsigned char)(b | (unsigned char)(0x80U >> rem));
            blk[n] = b;
        } else {
            blk[n] = 0x80U;
        }
        absorb120(&st, blk);
        perm_ff(&st, 1);
    }

    /* 挤出：state[128..255] */
    memcpy(output, ((const unsigned char *)&st) + (STATE_BYTES - HASH_BYTES),
           HASH_BYTES);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    return hash_Fsponge(digest_len_bits / 8, RATE_BYTES, msg, msg_len_bits,
                        digest_len_bits, digest);
}
