/* MEGASCON-512 交付件驱动层重写（纯 sponge 族：无前馈、无域分离、15 轮、从头挤出）
 *
 * 同族说明见 glue_megascon384_fast.c 的头注释；与 384 只差 rate/hash：
 *   rate = 128 字节 = 4 整行（capacity = w[4..7]，字节 128..255，128 B）
 *   hash = 64，从头挤出 64 字节
 * 官方 CryptHash 转发的是 hash_sponge(digest_len_bits/8, 128, ...)，
 * 所以这里 RATE_BYTES 必须是 128、HASH_BYTES 必须是 64。
 *
 * ⚠ 轮数：官方调 permutation(state, 15)；仓库里 megascon_perm.o 是 16 轮
 *   （_probe_perm_rounds.c 实测），必须链接 megascon_perm15.o
 *   （_probe_perm15.c 实测 perm(15) == megascon_perm15 : YES）。
 */
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "CryptHash_AlgorithmInstance.h"

#define ULL unsigned long long

#define RATE_BYTES   128
#define STATE_BYTES  256
#define HASH_BYTES   64

typedef struct __attribute__((aligned(64))) {
    __m256i w[8];
} State2048;

extern void megascon_perm15(uint64_t *p);

/* 保留官方符号名；本文件只服务 512，轮数恒为 15。 */
void permutation(unsigned char *state, unsigned rounds)
{
    (void)rounds;
    megascon_perm15((uint64_t *)state);
}

static inline __m256i loadu256(const unsigned char *p)
{
    return _mm256_loadu_si256((const __m256i *)(const void *)p);
}

/* 128 字节 = 4 个整 32 B 行。 */
static inline void absorb128(State2048 *s, const unsigned char *b)
{
    s->w[0] = _mm256_xor_si256(s->w[0], loadu256(b + 0));
    s->w[1] = _mm256_xor_si256(s->w[1], loadu256(b + 32));
    s->w[2] = _mm256_xor_si256(s->w[2], loadu256(b + 64));
    s->w[3] = _mm256_xor_si256(s->w[3], loadu256(b + 96));
}

int hash_sponge(int hash, int rate, const unsigned char *input,
                ULL input_len_bits, int output_len_bits, unsigned char *output)
{
    State2048 st;
    ULL full_bytes, last_block, i;
    unsigned int rem, off_in_last;

    (void)output_len_bits;

    if (rate != RATE_BYTES || hash != HASH_BYTES) {
        printf("Invalid rate or hash length\n");
        return 1;
    }

    memset(&st, 0, sizeof(st));

    full_bytes  = input_len_bits / 8ULL;
    rem         = (unsigned int)(input_len_bits & 7ULL);
    last_block  = full_bytes / (ULL)RATE_BYTES;
    off_in_last = (unsigned int)(full_bytes % (ULL)RATE_BYTES);

    for (i = 0; i < last_block; i++) {
        absorb128(&st, input + i * (ULL)RATE_BYTES);
        megascon_perm15((uint64_t *)&st.w[0]);
    }

    {
        unsigned char blk[RATE_BYTES];
        unsigned int n = off_in_last;

        if (n > 0) {
            memcpy(blk, input + last_block * (ULL)RATE_BYTES, n);
        }
        if (n < RATE_BYTES) {
            memset(blk + n, 0, RATE_BYTES - n);
        }

        if (rem > 0) {
            unsigned char mask = (unsigned char)(0xFFU << (8U - rem));
            unsigned char b = (unsigned char)(input[full_bytes] & mask);
            b = (unsigned char)(b | (0x80U >> rem));
            blk[n] = b;
        } else {
            blk[n] = 0x80U;
        }

        absorb128(&st, blk);
        megascon_perm15((uint64_t *)&st.w[0]);
    }

    /* 512 的官方挤出是 output[i] = state[i]，从头取 64 字节 */
    memcpy(output, (const unsigned char *)&st, HASH_BYTES);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    return hash_sponge(digest_len_bits / 8, RATE_BYTES, msg, msg_len_bits,
                       digest_len_bits, digest);
}
