/* MEGASCON-768 交付件驱动层重写（前馈 sponge 族：有 forward、有域分离、16 轮、从尾挤出）
 *
 * 与 1024 那份（glue_megascon1024_fast.c）同族，只有 rate/hash 不同：
 *   rate = 152 字节 = 4 整行 + 24 B（capacity = 字节 152..255，104 B）
 *   hash = 96，从尾挤出（output[i] = state[256-96+i] = 字节 160..255）
 * 官方 CryptHash 转发的是 hash_Fsponge(digest_len_bits/8, 152, ...)。
 *
 * ⚠ 轮数：768 与 1024 都是 `permutation(state, 16)`，所以这里可以直接复用
 *   已是 16 轮的 megascon_perm.o（_probe_perm_rounds.c 实测
 *   perm(16) == megascon_perm : YES），**不需要** megascon_perm15.o。
 *   这正是 768 比 384/512 便宜的地方。
 *
 * capacity 边界核对（rate = 152）：
 *   行 0..3 = 字节 0..127（128 B，全部吸收）
 *   行 4    = 字节 128..159，其中 128..151 是速率域（3 个 lane），
 *             152..159 是 capacity 的第 1 个 lane ⇒ 吸收时 lane 3 必须置 0，
 *             不能像 512 那样整行 loadu（会把 capacity 读进来异或掉）。
 *   行 5..7 = 字节 160..255（96 B，全是 capacity）
 *   域分离字节 = rate = 152 ⇒ w[4] 的 lane 3（_mm256_set_epi64x 的首参进 lane 3）。
 *
 * 官方每块付的钱：malloc+memset+memcpy 整条消息、逐字节吸收 152 次、
 * 每块 memcpy(forward+rate, state+rate, 256-rate) 再 state[j] ^= forward[j]、
 * state 与 IV 两次 memset 共 512 B。这里全去掉。
 */
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "CryptHash_AlgorithmInstance.h"

#define ULL unsigned long long

#define RATE_BYTES   152
#define STATE_BYTES  256
#define HASH_BYTES   96

typedef struct __attribute__((aligned(64))) {
    __m256i w[8];
} State2048;

extern void megascon_perm(uint64_t *p);

/* 保留官方符号名，便于核对置换没被换掉。本文件只服务 768（16 轮）。 */
void permutation(unsigned char *state, unsigned rounds)
{
    (void)rounds;
    megascon_perm((uint64_t *)state);
}

static inline uint64_t load_u64_unaligned(const unsigned char *p)
{
    uint64_t x;
    memcpy(&x, p, sizeof(x));
    return x;
}

/* 152 = 32*4 + 24：前 4 行整行，第 5 行只有 3 个 lane（24 B）。 */
static inline void absorb152(State2048 *s, const unsigned char *b)
{
    __m128i lo = _mm_loadu_si128((const __m128i *)(const void *)(b + 128));
    uint64_t hi = load_u64_unaligned(b + 144);
    __m256i r4;

    /* 必须从 setzero 起手：_mm256_castsi128_si256 的上 128 位是未定义的，
     * 会留下 lane 3 的垃圾把 capacity 打坏。lane 3 保持 0 = 不吸收。 */
    r4 = _mm256_inserti128_si256(_mm256_setzero_si256(), lo, 0);
    r4 = _mm256_insert_epi64(r4, hi, 2);

    s->w[0] = _mm256_xor_si256(s->w[0], _mm256_loadu_si256((const __m256i *)(const void *)(b + 0)));
    s->w[1] = _mm256_xor_si256(s->w[1], _mm256_loadu_si256((const __m256i *)(const void *)(b + 32)));
    s->w[2] = _mm256_xor_si256(s->w[2], _mm256_loadu_si256((const __m256i *)(const void *)(b + 64)));
    s->w[3] = _mm256_xor_si256(s->w[3], _mm256_loadu_si256((const __m256i *)(const void *)(b + 96)));
    s->w[4] = _mm256_xor_si256(s->w[4], r4);
}

/* 置换 + 前馈。capacity 参与前馈的是 w[4] 的 lane 3 与 w[5..7]；
 * w[4] 的 lane 0..2 属于速率域，必须用 lane3 掩码剔除，
 * 否则前馈会把速率域的值也异或回 state[j]（j < rate）——官方不做这件事。 */
static inline void perm_ff(State2048 *s, int final_block)
{
    const __m256i lane3 = _mm256_set_epi64x(-1LL, 0, 0, 0);
    __m256i f4, f5, f6, f7;

    if (final_block) {
        /* 域分离：state[rate] ^= 0x80 ⇒ w[4] 的 lane 3 */
        s->w[4] = _mm256_xor_si256(s->w[4], _mm256_set_epi64x(0x80ULL, 0, 0, 0));
    }

    f4 = _mm256_and_si256(s->w[4], lane3);
    f5 = s->w[5];
    f6 = s->w[6];
    f7 = s->w[7];

    megascon_perm((uint64_t *)&s->w[0]);

    s->w[4] = _mm256_xor_si256(s->w[4], f4);
    s->w[5] = _mm256_xor_si256(s->w[5], f5);
    s->w[6] = _mm256_xor_si256(s->w[6], f6);
    s->w[7] = _mm256_xor_si256(s->w[7], f7);
}

int hash_Fsponge(int hash, int rate, const unsigned char *input,
                 ULL input_len_bits, int output_len_bits, unsigned char *output)
{
    State2048 st;
    ULL full_bytes, last_block, i;
    unsigned int rem, off_in_last;

    (void)output_len_bits;

    if (rate != RATE_BYTES || hash != HASH_BYTES) {
        printf("Invalid rate or hash length\n");
        return 1;
    }

    memset(&st, 0, sizeof(st));

    full_bytes  = input_len_bits / 8ULL;
    rem         = (unsigned int)(input_len_bits & 7ULL);
    last_block  = full_bytes / (ULL)RATE_BYTES;
    off_in_last = (unsigned int)(full_bytes % (ULL)RATE_BYTES);

    for (i = 0; i < last_block; i++) {
        absorb152(&st, input + i * (ULL)RATE_BYTES);
        perm_ff(&st, 0);
    }

    {
        unsigned char blk[RATE_BYTES];
        unsigned int n = off_in_last;

        if (n > 0) {
            memcpy(blk, input + last_block * (ULL)RATE_BYTES, n);
        }
        if (n < RATE_BYTES) {
            memset(blk + n, 0, RATE_BYTES - n);
        }

        if (rem > 0) {
            unsigned char mask = (unsigned char)(0xFFU << (8U - rem));
            unsigned char b = (unsigned char)(input[full_bytes] & mask);
            b = (unsigned char)(b | (0x80U >> rem));
            blk[n] = b;
        } else {
            blk[n] = 0x80U;
        }

        absorb152(&st, blk);
        perm_ff(&st, 1);
    }

    /* 768 的官方挤出是 output[i] = state[256 - hash + i] = 字节 160..255 */
    memcpy(output, ((const unsigned char *)&st) + (STATE_BYTES - HASH_BYTES),
           HASH_BYTES);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    return hash_Fsponge(digest_len_bits / 8, RATE_BYTES, msg, msg_len_bits,
                        digest_len_bits, digest);
}
