/* MEGASCON-384 交付件驱动层重写（纯 sponge 族：无前馈、无域分离、15 轮、从头挤出）
 *
 * 对手 = 官方 Optimized_Implementation 的 MEGASCON-384；
 * 被替换的是官方 Reference_Implementation 的驱动外壳，
 * 置换核心用仓库自产的 15 轮 JIR 件 megascon_perm15.o。
 *
 * 官方 Reference 驱动（src/hash-18/.../Reference_Implementation/MEGASCON-384/
 * CryptHash_AlgorithmInstance.c）在每一块上付四笔钱：
 *   ① 整条消息 malloc(padded_len) + memset + memcpy；
 *   ② 逐字节吸收 for (j = 0; j < 160; j++) state[j] ^= padded_input[i*160+j];
 *      （160 次单字节读改写，而不是 5 次 32 B 向量异或）；
 *   ③ 尾部 padding 走逐位运算（这里是 384 的 rate=160、hash=48）；
 *   ④ state[256] 与 IV[256] 两次 memset 共 512 B。
 * 另外每次调用还要重新 memset(IV) + memcpy(state, IV, 256)。
 * 这里改成：不 malloc（满块直接从 input 读，只有最后一块在栈上拼）、
 * 32 B 整行异或、状态只清零一次。
 *
 * ⚠ 与 1024 那份最关键的差别：**384 是纯 sponge**
 *   —— 官方 hash_sponge 里没有 `forward[256]` 前馈，也没有 `state[rate] ^= 0x80`
 *   域分离；挤出是 `output[i] = state[i]`（**从头**，不是从尾）。
 *   已由 _probe_megascon_family.sh 计数取证（forward 0 / state[rate] 0）。
 *
 * ⚠ 轮数：官方调 permutation(state, 15)，而仓库里原来那份 megascon_perm.o
 *   是 16 轮（_probe_perm_rounds.c 实测 perm(16) == megascon_perm : YES），
 *   所以这里必须链接 megascon_perm15.o（make_perm15.py 生成，
 *   _probe_perm15.c 实测 perm(15) == megascon_perm15 : YES）。
 *
 * 置换速查（rate R = 160 字节 = 5 整行）：
 *   吸收行 w[0..4]（字节 0..159），capacity = w[5..7]（字节 160..255，96 B），
 *   capacity 起点正好落在 w[5] 的 lane 0，所以 absorb160 不需要拼半个向量。
 */
#include <immintrin.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "CryptHash_AlgorithmInstance.h"

#define ULL unsigned long long

#define RATE_BYTES   160
#define STATE_BYTES  256
#define HASH_BYTES   48

typedef struct __attribute__((aligned(64))) {
    __m256i w[8];
} State2048;

extern void megascon_perm15(uint64_t *p);

/* 保留官方符号名，便于「置换到底有没有被换掉」可核对。
 * 本文件只服务 384，轮数恒为 15，所以这里忽略 rounds 参数。 */
void permutation(unsigned char *state, unsigned rounds)
{
    (void)rounds;
    megascon_perm15((uint64_t *)state);
}

static inline __m256i loadu256(const unsigned char *p)
{
    return _mm256_loadu_si256((const __m256i *)(const void *)p);
}

/* 160 字节 = 5 个整 32 B 行，不需要半个向量拼接。 */
static inline void absorb160(State2048 *s, const unsigned char *b)
{
    s->w[0] = _mm256_xor_si256(s->w[0], loadu256(b + 0));
    s->w[1] = _mm256_xor_si256(s->w[1], loadu256(b + 32));
    s->w[2] = _mm256_xor_si256(s->w[2], loadu256(b + 64));
    s->w[3] = _mm256_xor_si256(s->w[3], loadu256(b + 96));
    s->w[4] = _mm256_xor_si256(s->w[4], loadu256(b + 128));
}

int hash_sponge(int hash, int rate, const unsigned char *input,
                ULL input_len_bits, int output_len_bits, unsigned char *output)
{
    State2048 st;
    ULL full_bytes, last_block, i;
    unsigned int rem, off_in_last;

    (void)output_len_bits;

    if (rate != RATE_BYTES || hash != HASH_BYTES) {
        printf("Invalid rate or hash length\n");
        return 1;
    }

    memset(&st, 0, sizeof(st));           /* IV 全零，只清一次 */

    full_bytes  = input_len_bits / 8ULL;
    rem         = (unsigned int)(input_len_bits & 7ULL);
    last_block  = full_bytes / (ULL)RATE_BYTES;
    off_in_last = (unsigned int)(full_bytes % (ULL)RATE_BYTES);

    /* 满块：直接从调用者的缓冲里读，不复制整条消息 */
    for (i = 0; i < last_block; i++) {
        absorb160(&st, input + i * (ULL)RATE_BYTES);
        megascon_perm15((uint64_t *)&st.w[0]);
    }

    /* 最后一块：栈上拼一个 160 B 块（含填充），与官方逐位 padding 等价 */
    {
        unsigned char blk[RATE_BYTES];
        unsigned int n = off_in_last;

        if (n > 0) {
            memcpy(blk, input + last_block * (ULL)RATE_BYTES, n);
        }
        if (n < RATE_BYTES) {
            memset(blk + n, 0, RATE_BYTES - n);
        }

        if (rem > 0) {
            unsigned char mask = (unsigned char)(0xFFU << (8U - rem));
            unsigned char b = (unsigned char)(input[full_bytes] & mask);
            b = (unsigned char)(b | (0x80U >> rem));
            blk[n] = b;
        } else {
            blk[n] = 0x80U;
        }

        absorb160(&st, blk);
        megascon_perm15((uint64_t *)&st.w[0]);
    }

    /* 384 的官方挤出是 output[i] = state[i]，从头取 48 字节 */
    memcpy(output, (const unsigned char *)&st, HASH_BYTES);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    return hash_sponge(digest_len_bits / 8, RATE_BYTES, msg, msg_len_bits,
                       digest_len_bits, digest);
}
