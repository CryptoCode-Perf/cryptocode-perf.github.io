#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")";mkdir -p build
for bits in 384 512 768 1024; do
 ref="Reference_Implementation/MEGASCON-$bits";opt="Optimized_Implementation/MEGASCON-$bits";own="CryptoCode_Implementation/MEGASCON-$bits"
 gcc -O2 -fPIC -shared -Wl,-z,defs -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" -o "build/Reference-$bits.so"
 g++ -std=c++17 -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" "$opt/CryptHash_AlgorithmInstance_fast.cpp" -o "build/Optimized-$bits.so"
 core=megascon_perm; [ "$bits" -le 512 ] && core=megascon_perm15
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$ref" "$own/glue.c" "CryptoCode_Implementation/common/$core.s" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/MEGASCON-$bits.txt";done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 384 512 768 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits";done;done
