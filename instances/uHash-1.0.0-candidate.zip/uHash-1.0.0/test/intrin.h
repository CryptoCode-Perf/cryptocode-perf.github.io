/* GCC has no MSVC <intrin.h>.  The package's Windows-oriented sources include it
 * only for __rdtsc(); GCC exposes that (and everything else they use) through
 * <x86intrin.h>.  This shim keeps their include lines untouched. */
#ifndef L0_SHIM_INTRIN_H
#define L0_SHIM_INTRIN_H
#include <x86intrin.h>
#endif
