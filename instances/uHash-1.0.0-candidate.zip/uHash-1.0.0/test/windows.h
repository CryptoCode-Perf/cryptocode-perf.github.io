/* Minimal shim so that Windows-only-including sources build under Linux/WSL.
 * Only the MSVC/Windows declarations the package's C sources actually use are
 * needed: __rdtsc() comes from GCC's own <intrin.h>, and nothing else from
 * <windows.h> is referenced.  This header is intentionally empty. */
#ifndef L0_SHIM_WINDOWS_H
#define L0_SHIM_WINDOWS_H
#endif
