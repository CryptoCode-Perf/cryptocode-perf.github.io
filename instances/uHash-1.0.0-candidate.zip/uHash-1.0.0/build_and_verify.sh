#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")";mkdir -p build
for bits in 512 768 1024; do
 ref="Reference_Implementation/uHash-$bits";opt="Optimized_Implementation/uHash-$bits";own="CryptoCode_Implementation/uHash-$bits"
 gcc -O2 -fPIC -shared -Wl,-z,defs -Itest -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" -o "build/Reference-$bits.so"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -Itest -I"$opt" "$opt/adapted.c" -o "build/Optimized-$bits.so"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -Itest -I"$own" "$own/implementation.c" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/uHash-$bits.txt";done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 768 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits";done;done
