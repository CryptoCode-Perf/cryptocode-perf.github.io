# uHash candidate package

Instances: uHash-512, uHash-768 and uHash-1024. On x86-64 Linux with GCC,
Python 3 and AVX2, run `bash build_and_verify.sh`. It rebuilds reference,
official optimized and CryptoCode implementations, checks 4097 known-answer
vectors per build, compares deterministic long and boundary inputs, and checks
selected input/output guard pages. `CryptHash` lengths are in bits.

The official optimized source targets Windows. Its original file is retained;
`adapted.c`, `adapt.diff` and the test compatibility headers record the Linux
portability changes used for this build. CryptoCode sources were recovered
from the local performance report. Candidate only: controlled performance
comparison, independent review of the adaptation and source, redistribution
permission and final release review remain pending. Tests do not prove security.
