#!/usr/bin/env python3
from pathlib import Path
import ctypes,random
root=Path(__file__).resolve().parent.parent;rng=random.Random(20261127)
for bits in (512,768,1024):
 libs=[ctypes.CDLL(str(root/'build'/f'{kind}-{bits}.so')) for kind in ('Reference','Optimized','CryptoCode')]
 for l in libs:
  l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
  l.CryptHash_AlgorithmInstance_permutation.argtypes=[ctypes.POINTER(ctypes.c_uint64)];l.CryptHash_AlgorithmInstance_permutation.restype=None
 for k in range(256):
  state=[rng.getrandbits(64) for _ in range(32)];result=[]
  for l in libs:
   box=(ctypes.c_uint64*36)();box[0]=box[1]=box[34]=box[35]=0xA5A5A5A5A5A5A5A5
   for i,v in enumerate(state):box[i+2]=v
   ptr=ctypes.cast(ctypes.byref(box,16),ctypes.POINTER(ctypes.c_uint64));l.CryptHash_AlgorithmInstance_permutation(ptr)
   assert box[0]==box[1]==box[34]==box[35]==0xA5A5A5A5A5A5A5A5
   result.append(tuple(box[i+2] for i in range(32)))
  assert result[0]==result[1]==result[2],(bits,k,'permutation')
 d=bits//8
 for n in (0,1,7,8,9,511,512,513,767,768,769,1023,1024,1025,4095,4096,4097,8193):
  msg=rng.randbytes((n+7)//8);source=ctypes.create_string_buffer(msg or b'\0');expect=ctypes.create_string_buffer(d);assert libs[0].CryptHash(bits,source,n,expect)==0
  for l in libs:
   size=max(d,len(msg));box=ctypes.create_string_buffer(b'\xa5'*16+msg+b'\xa5'*(size-len(msg))+b'\xa5'*16,32+size);before=box.raw;ptr=ctypes.byref(box,16)
   assert l.CryptHash(bits,ptr,n,ptr)==0 and box.raw[16:16+d]==expect.raw and box.raw[:16]==before[:16] and box.raw[16+size:]==before[16+size:],(bits,n,'in-place')
 for l in libs:
  a=ctypes.create_string_buffer(d);b=ctypes.create_string_buffer(d)
  assert l.CryptHash(bits,None,0,a)==0 and l.CryptHash(bits,b'',0,b)==0 and a.raw==b.raw
  assert l.CryptHash(bits,None,1,a)==-1 and l.CryptHash(bits,b'x',8,None)==-1 and l.CryptHash(bits-1,b'x',8,a)==-1
 print('Iphe-%d: 256 permutation cases, in-place, empty and invalid-argument checks passed'%bits,flush=True)
