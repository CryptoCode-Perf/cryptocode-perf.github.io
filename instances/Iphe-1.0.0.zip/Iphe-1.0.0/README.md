# Iphe 1.0.0 — CryptoCode implementation

Instances: Iphe-512, Iphe-768 and Iphe-1024. Requires x86-64 Linux/WSL2,
AVX2, GCC, Python 3 and standard Unix tools. From this directory run:

    bash build_and_verify.sh

The script rebuilds reference, official optimized and CryptoCode implementations,
checks all 4097 known-answer vectors per implementation and instance, compares
selected long and boundary inputs, and tests guarded buffers, in-place calls,
empty and invalid arguments, and 256 permutation states per instance. Build
commands and environment are recorded under build/; prebuilt libraries are in
prebuilt/.

`CryptHash` takes a digest length in bits, a message pointer, a message length
in bits and an output pointer. Each library accepts its named digest length;
allocate digest_bits/8 output bytes. The permutation entry was compared for
test coverage but is not part of the public CryptHash header. Original source
notices are retained.

The selected binaries match the previously captured website binaries. Both
website and current report implementations were compared under the same setup;
raw data are in results/2026-11-27-report-comparison. Rebuilt official optimized
and CryptoCode measurements, three 101-sample rounds over eight sizes, are in
results/2026-11-27-delivery-comparison. Reference timing was sampled in a
separate session under results/2026-11-27-reference-comparison. Units are
elapsed nanoseconds, not hardware cycles. To remeasure after building:

    python3 test/measure.py --lock /path/to/shared/measurement.lock --output /path/to/new/results

The lock cannot exclude unrelated host work. Results depend on hardware and
load. Tests do not prove security or constant-time behavior. See
SOURCE_MANIFEST.json for hashes.
