# CHAMP candidate package

Includes CHAMP-512 and CHAMP-1024. On x86-64 Linux with GCC, Python 3 and
AVX2, run `bash build_and_verify.sh`. It rebuilds official reference, official
optimized and CryptoCode implementations, checks full KAT, runs selected
long-input reference differential and input/output guard-page checks.

Candidate only: performance comparison, release review and upstream
redistribution permissions remain pending. Tests do not prove security.
