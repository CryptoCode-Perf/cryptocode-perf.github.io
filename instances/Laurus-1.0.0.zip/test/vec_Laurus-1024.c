/* Cross-validation harness for Laurus-1024 (x86_64 / AVX2).
 * 只走**字节对齐**的消息长度：官方胶水把位长当字节传（inlen_bits >> 3），
 * 非字节对齐长度在对手侧没有定义，故本表以字节数给出再乘 8 换成位。
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest);

static const unsigned blens[] = {
    0, 1, 7, 8, 9, 63, 64, 65, 127, 128, 129, 255, 256, 511, 512,
    513, 1023, 1024, 2048, 4096
};
static const unsigned dtiers[] = { 1024 };

int main(void)
{
    static unsigned char msg[8192];
    unsigned char dig[160];
    for (unsigned t = 0; t < sizeof(dtiers) / sizeof(dtiers[0]); t++)
    for (unsigned i = 0; i < sizeof(blens) / sizeof(blens[0]); i++) {
        unsigned nbytes = blens[i], bits = nbytes * 8u;
        for (unsigned j = 0; j < nbytes; j++)
            msg[j] = (unsigned char)(j * 97u + nbytes * 31u + 0x9Eu);
        if (CryptHash((int)dtiers[t], msg, bits, dig) != 0) {
            printf("ERR d=%u bytes=%u\n", dtiers[t], nbytes);
            return 1;
        }
        printf("d=%u bytes=%u ", dtiers[t], nbytes);
        for (int k = 0; k < (int)(dtiers[t] / 8); k++) printf("%02X", dig[k]);
        printf("\n");
    }
    return 0;
}
