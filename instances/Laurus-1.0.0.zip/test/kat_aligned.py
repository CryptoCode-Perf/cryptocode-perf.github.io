#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""kat_aligned.py <so> <kat_file>

Laurus 专用：只比对**字节对齐**的 KAT 记录（官方胶水把位长当字节传，
非字节对齐长度在对手侧没有定义）。输出一行 `KAT: checked=.. match=.. pass=..`，
与 kat_check.py 的格式一致，便于 build_and_verify.sh 统一判断。
"""
import ctypes
import io
import sys


def load(path):
    lib = ctypes.CDLL(path)
    fn = lib.CryptHash
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_ulonglong,
                   ctypes.c_char_p]
    return fn


def records(path):
    cur = None
    for line in io.open(path, encoding="utf-8", errors="replace"):
        line = line.rstrip("\n")
        if line.startswith("Msg_Len"):
            cur = {"n": int(line.split()[-1])}
        elif line.startswith("Msg"):
            cur["m"] = line.split("=", 1)[1].strip() if "=" in line else ""
        elif line.startswith("Dst_Len"):
            cur["d"] = int(line.split()[-1])
        elif line.startswith("Dst"):
            cur["h"] = line.split("=", 1)[1].strip().replace(" ", "")
            yield cur


def main():
    so, kat = sys.argv[1], sys.argv[2]
    fn = load(so)
    checked = matched = 0
    first = None
    for r in records(kat):
        if r["n"] % 8 != 0:
            continue
        msg = bytes.fromhex(r["m"]) if r.get("m") else b""
        nout = r["d"] // 8
        buf = ctypes.create_string_buffer(nout + 16)
        rc = fn(r["d"], msg, r["n"], buf)
        got = buf.raw[:nout]
        checked += 1
        if rc != 0 or got.hex().upper() != r["h"].upper():
            if first is None:
                first = r["n"]
        else:
            matched += 1
    ok = checked and matched == checked
    print("KAT: checked=%d match=%d byte_aligned=%d pass=%s"
          % (checked, matched, checked, ok))
    if not ok:
        print("  first failing msg_len_bits=%s" % first)
        sys.exit(1)


if __name__ == "__main__":
    main()
