#!/usr/bin/env bash
# Laurus 1.0.0 —— 三方编译 + 字节对齐差分 + 黄金向量 + KAT + 测速
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
REFFLAGS="-std=c99 -Wpedantic -Wall -Wextra -O2"
mkdir -p build
pass=1
uname -a > build/environment.txt
gcc --version >> build/environment.txt
lscpu >> build/environment.txt

echo "== [Laurus-512] 1/5 编译三方 =="
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-512" -c "Reference_Implementation/Laurus-512/CryptHash_AlgorithmInstance.c" -o build/glue_ref_512.o
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-512" -c "Reference_Implementation/Laurus-512/drng.c" -o build/drng_ref_512.o
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-512" -c "Reference_Implementation/Laurus-512/laurus_512.c" -o build/impl_ref_512.o
gcc -shared -o build/ref_512.so build/glue_ref_512.o build/drng_ref_512.o build/impl_ref_512.o
gcc $FLAGS -fPIC -I "Optimized_Implementation/Laurus-512" -I "Reference_Implementation/Laurus-512" -c "Reference_Implementation/Laurus-512/CryptHash_AlgorithmInstance.c" -o build/glue_512.o
gcc $FLAGS -fPIC -I "Optimized_Implementation/Laurus-512" -I "Reference_Implementation/Laurus-512" -c "Reference_Implementation/Laurus-512/drng.c" -o build/drng_512.o
gcc $FLAGS -Dlaurus_512=laurus_512__raw -I "Reference_Implementation/Laurus-512" -I "Optimized_Implementation/Laurus-512" -c "Optimized_Implementation/Laurus-512/laurus_512.c" -o build/impl_off_512.o
gcc $FLAGS -fPIC -I "Reference_Implementation/Laurus-512" -c "CryptoCode_Implementation/x86_AVX2/Laurus-512/shim_512_len.c" -o build/shim_512.o
gcc -shared -o build/off_512.so build/glue_512.o build/drng_512.o build/impl_off_512.o build/shim_512.o
bash "CryptoCode_Implementation/x86_AVX2/Laurus-512/build_ours.sh"

gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-512" "test/vec_Laurus-512.c" build/ref_512.so -o build/vec_ref_512 -Wl,-rpath,'$ORIGIN'
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-512" "test/vec_Laurus-512.c" build/off_512.so -o build/vec_off_512 -Wl,-rpath,'$ORIGIN'
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-512" "test/vec_Laurus-512.c" build/our_512.so -o build/vec_our_512 -Wl,-rpath,'$ORIGIN'
echo "== [Laurus-512] 2/5 交叉验证（20 个字节对齐长度，逐字节 diff） =="
./build/vec_ref_512 > build/v_ref_512.txt
./build/vec_off_512 > build/v_off_512.txt
./build/vec_our_512 > build/v_our_512.txt
diff -q build/v_ref_512.txt build/v_off_512.txt >/dev/null || { echo "   !! 官方优化版与参考不一致"; pass=0; }
diff -q build/v_ref_512.txt build/v_our_512.txt >/dev/null || { echo "   !! CryptoCode 版与参考不一致"; diff build/v_ref_512.txt build/v_our_512.txt | head -4; pass=0; }
echo "== [Laurus-512] 3/5 黄金向量 =="
diff -q build/v_ref_512.txt test/golden_vectors_ref_512.txt >/dev/null || { echo "ERROR: golden vectors mismatch"; pass=0; }
echo "== [Laurus-512] 4/5 KAT 全量（513 条 × 三方） =="
python3 test/kat_aligned.py "build/our_512.so" "kat/KAT_2_12_Laurus-512.txt" || pass=0
python3 test/kat_aligned.py "build/ref_512.so" "kat/KAT_2_12_Laurus-512.txt" || pass=0
python3 test/kat_aligned.py "build/off_512.so" "kat/KAT_2_12_Laurus-512.txt" || pass=0
echo "== [Laurus-512] 5/5 测速 =="
gcc -O2 -mavx2 test/speed.c -o build/speed_512 -ldl -lm
for rep in 1 2 3; do ./build/speed_512 ./build/our_512.so ./build/off_512.so 512 > "build/speed_512_${rep}.txt" || { echo "   !! 测速未跑通"; pass=0; }; done

echo "== [Laurus-768] 1/5 编译三方 =="
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-768" -c "Reference_Implementation/Laurus-768/CryptHash_AlgorithmInstance.c" -o build/glue_ref_768.o
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-768" -c "Reference_Implementation/Laurus-768/drng.c" -o build/drng_ref_768.o
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-768" -c "Reference_Implementation/Laurus-768/laurus_768.c" -o build/impl_ref_768.o
gcc -shared -o build/ref_768.so build/glue_ref_768.o build/drng_ref_768.o build/impl_ref_768.o
gcc $FLAGS -fPIC -I "Optimized_Implementation/Laurus-768" -I "Reference_Implementation/Laurus-768" -c "Reference_Implementation/Laurus-768/CryptHash_AlgorithmInstance.c" -o build/glue_768.o
gcc $FLAGS -fPIC -I "Optimized_Implementation/Laurus-768" -I "Reference_Implementation/Laurus-768" -c "Reference_Implementation/Laurus-768/drng.c" -o build/drng_768.o
gcc $FLAGS -Dlaurus_768=laurus_768__raw -I "Reference_Implementation/Laurus-768" -I "Optimized_Implementation/Laurus-768" -c "Optimized_Implementation/Laurus-768/laurus_768.c" -o build/impl_off_768.o
gcc $FLAGS -fPIC -I "Reference_Implementation/Laurus-768" -c "CryptoCode_Implementation/x86_AVX2/Laurus-768/shim_768_len.c" -o build/shim_768.o
gcc -shared -o build/off_768.so build/glue_768.o build/drng_768.o build/impl_off_768.o build/shim_768.o
bash "CryptoCode_Implementation/x86_AVX2/Laurus-768/build_ours.sh"

gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-768" "test/vec_Laurus-768.c" build/ref_768.so -o build/vec_ref_768 -Wl,-rpath,'$ORIGIN'
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-768" "test/vec_Laurus-768.c" build/off_768.so -o build/vec_off_768 -Wl,-rpath,'$ORIGIN'
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-768" "test/vec_Laurus-768.c" build/our_768.so -o build/vec_our_768 -Wl,-rpath,'$ORIGIN'
echo "== [Laurus-768] 2/5 交叉验证（20 个字节对齐长度，逐字节 diff） =="
./build/vec_ref_768 > build/v_ref_768.txt
./build/vec_off_768 > build/v_off_768.txt
./build/vec_our_768 > build/v_our_768.txt
diff -q build/v_ref_768.txt build/v_off_768.txt >/dev/null || { echo "   !! 官方优化版与参考不一致"; pass=0; }
diff -q build/v_ref_768.txt build/v_our_768.txt >/dev/null || { echo "   !! CryptoCode 版与参考不一致"; diff build/v_ref_768.txt build/v_our_768.txt | head -4; pass=0; }
echo "== [Laurus-768] 3/5 黄金向量 =="
diff -q build/v_ref_768.txt test/golden_vectors_ref_768.txt >/dev/null || { echo "ERROR: golden vectors mismatch"; pass=0; }
echo "== [Laurus-768] 4/5 KAT 全量（513 条 × 三方） =="
python3 test/kat_aligned.py "build/our_768.so" "kat/KAT_2_12_Laurus-768.txt" || pass=0
python3 test/kat_aligned.py "build/ref_768.so" "kat/KAT_2_12_Laurus-768.txt" || pass=0
python3 test/kat_aligned.py "build/off_768.so" "kat/KAT_2_12_Laurus-768.txt" || pass=0
echo "== [Laurus-768] 5/5 测速 =="
gcc -O2 -mavx2 test/speed.c -o build/speed_768 -ldl -lm
for rep in 1 2 3; do ./build/speed_768 ./build/our_768.so ./build/off_768.so 768 > "build/speed_768_${rep}.txt" || { echo "   !! 测速未跑通"; pass=0; }; done

echo "== [Laurus-1024] 1/5 编译三方 =="
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-1024" -c "Reference_Implementation/Laurus-1024/CryptHash_AlgorithmInstance.c" -o build/glue_ref_1024.o
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-1024" -c "Reference_Implementation/Laurus-1024/drng.c" -o build/drng_ref_1024.o
gcc $REFFLAGS -fPIC -I "Reference_Implementation/Laurus-1024" -c "Reference_Implementation/Laurus-1024/laurus_1024.c" -o build/impl_ref_1024.o
gcc -shared -o build/ref_1024.so build/glue_ref_1024.o build/drng_ref_1024.o build/impl_ref_1024.o
gcc $FLAGS -fPIC -I "Optimized_Implementation/Laurus-1024" -I "Reference_Implementation/Laurus-1024" -c "Reference_Implementation/Laurus-1024/CryptHash_AlgorithmInstance.c" -o build/glue_1024.o
gcc $FLAGS -fPIC -I "Optimized_Implementation/Laurus-1024" -I "Reference_Implementation/Laurus-1024" -c "Reference_Implementation/Laurus-1024/drng.c" -o build/drng_1024.o
gcc $FLAGS -Dlaurus_1024=laurus_1024__raw -I "Reference_Implementation/Laurus-1024" -I "Optimized_Implementation/Laurus-1024" -c "Optimized_Implementation/Laurus-1024/laurus_1024.c" -o build/impl_off_1024.o
gcc $FLAGS -fPIC -I "Reference_Implementation/Laurus-1024" -c "CryptoCode_Implementation/x86_AVX2/Laurus-1024/shim_1024_len.c" -o build/shim_1024.o
gcc -shared -o build/off_1024.so build/glue_1024.o build/drng_1024.o build/impl_off_1024.o build/shim_1024.o
bash "CryptoCode_Implementation/x86_AVX2/Laurus-1024/build_ours.sh"

gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-1024" "test/vec_Laurus-1024.c" build/ref_1024.so -o build/vec_ref_1024 -Wl,-rpath,'$ORIGIN'
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-1024" "test/vec_Laurus-1024.c" build/off_1024.so -o build/vec_off_1024 -Wl,-rpath,'$ORIGIN'
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I "Reference_Implementation/Laurus-1024" "test/vec_Laurus-1024.c" build/our_1024.so -o build/vec_our_1024 -Wl,-rpath,'$ORIGIN'
echo "== [Laurus-1024] 2/5 交叉验证（20 个字节对齐长度，逐字节 diff） =="
./build/vec_ref_1024 > build/v_ref_1024.txt
./build/vec_off_1024 > build/v_off_1024.txt
./build/vec_our_1024 > build/v_our_1024.txt
diff -q build/v_ref_1024.txt build/v_off_1024.txt >/dev/null || { echo "   !! 官方优化版与参考不一致"; pass=0; }
diff -q build/v_ref_1024.txt build/v_our_1024.txt >/dev/null || { echo "   !! CryptoCode 版与参考不一致"; diff build/v_ref_1024.txt build/v_our_1024.txt | head -4; pass=0; }
echo "== [Laurus-1024] 3/5 黄金向量 =="
diff -q build/v_ref_1024.txt test/golden_vectors_ref_1024.txt >/dev/null || { echo "ERROR: golden vectors mismatch"; pass=0; }
echo "== [Laurus-1024] 4/5 KAT 全量（513 条 × 三方） =="
python3 test/kat_aligned.py "build/our_1024.so" "kat/KAT_2_12_Laurus-1024.txt" || pass=0
python3 test/kat_aligned.py "build/ref_1024.so" "kat/KAT_2_12_Laurus-1024.txt" || pass=0
python3 test/kat_aligned.py "build/off_1024.so" "kat/KAT_2_12_Laurus-1024.txt" || pass=0
echo "== [Laurus-1024] 5/5 测速 =="
gcc -O2 -mavx2 test/speed.c -o build/speed_1024 -ldl -lm
for rep in 1 2 3; do ./build/speed_1024 ./build/our_1024.so ./build/off_1024.so 1024 > "build/speed_1024_${rep}.txt" || { echo "   !! 测速未跑通"; pass=0; }; done

echo
if [ "$pass" = "1" ]; then echo "== 验证全部通过 =="; else echo "== 验证发现不一致（见上） =="; exit 1; fi
