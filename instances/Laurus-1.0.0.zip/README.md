# Laurus 1.0.0 — CryptoCode release package

本站点收录的三档（512 / 768 / 1024）CryptoCode 实现与官方 Reference、官方 Optimized 三方同 flag 编译、逐字节交叉验证、官方 KAT 全量校验。

## 与其它族不同、必须在 README 里说清的两点

1. **我方件是四对象配方**（`CryptoCode_Implementation/x86_AVX2/Laurus-<bits>/build_ours.sh`）：
   参考树的胶水 `CryptHash_AlgorithmInstance.c` + `drng.c` + 我方实现（带
   `-Dlaurus_<bits>=laurus_<bits>__raw` 改名）+ 我们的长度换算 shim，最后
   `gcc -shared -o` 链接（**不带 `-flto/-lm`**，与自评估装置逐字一致）。
2. **官方优化版也必须带同一份 shim**：官方胶水把位长当字节传给实现
   （`inlen_bits >> 3`），所以包内官方侧同样链接 `shim_<bits>_len.c`，
   差分只使用**字节对齐**的消息长度（20 个边界值）。

## 编译与验证

```
bash build_and_verify.sh
```

五步：三方编译 → 字节对齐差分（20 个长度，逐字节）→ 黄金向量 → 官方 KAT 全量（513 条 × 三方）→ 测速（3 次）。

# LLH 1.0.0 — CryptoCode AVX2 Implementation

Covers LLH-512, LLH-1024 through the CryptHash ABI.
Requires x86-64 Linux/WSL2, AVX2, GCC, Python 3 and standard shell tools.

```sh
bash build_and_verify.sh
```

The script rebuilds the official reference implementation, the official optimized
implementation and the CryptoCode implementation from the sources in this package;
diff-compares digests over 22 padding-boundary message lengths; compares against the
golden vectors frozen from the official reference at release time; verifies all 4097
KAT records per digest size; and benchmarks the rebuilt shared libraries (three
repetitions each). Failure returns non-zero. All output goes to `build/`.

Baselines are compiled from exactly the files recorded in `SOURCE_MANIFEST.json`
(read out of the recipe that produced the measured opponent libraries), with the
official reference flags `-std=c99 -Wpedantic -Wall -Wextra -O2` and the official optimized flags
`-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra`.
No ISA exceptions are used by this package.

The benchmark harness uses -O2. Units are TSC ticks, not hardware core cycles; each
size reports the minimum of five batches. Results depend on the machine — they are a
reproducibility record, not a universal performance guarantee.

Directory guide: `CryptoCode_Implementation/` holds our optimized implementation, its
build script and the verified prebuilt library; `Reference_Implementation/` and
`Optimized_Implementation/` hold the official baselines; `kat/` holds official vectors;
`test/` holds the validation and benchmark tools; `results/` records this release.
Rebuilding the CryptoCode source is supported; regenerating it from the generator is
outside this release procedure.

CryptHash takes digest length in bits, message pointer, message length in bits and
output pointer; allocate at least digest_bits/8 output bytes. Supported release digest
sizes are 512, 1024. AVX2 is mandatory; no runtime dispatch or fallback is supplied.
No constant-time or security proof is claimed.

Third-party sources retain their existing notices; no new license grant is invented and
redistribution permission still needs review. See SOURCE_MANIFEST.json.
