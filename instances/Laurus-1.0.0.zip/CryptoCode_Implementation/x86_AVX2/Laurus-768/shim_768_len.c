/* 自动生成：把 CryptHash 胶水传进来的「位」长度换成 opt 实现要求的「字节」。
 * 只做 (inlen_bits >> 3) 一处换算，不加任何拷贝、不做对齐假设。 */
#include <stdint.h>
extern void laurus_768__raw(uint8_t *h, const uint8_t *in, uint64_t inlen_bytes);
void laurus_768(uint8_t h[96], const uint8_t *in, uint64_t inlen_bits)
{
    laurus_768__raw(h, in, inlen_bits >> 3);
}
