#!/usr/bin/env bash
# Laurus-768 的 CryptoCode 实现——四对象配方（照 fix14 / build512.py 逐字复刻）。
# 与其它族不同：impl 要改名（-Dlaurus_768=laurus_768__raw），
# 链接命令不带 -flto / -lm（差一个 flag 就出不同字节）。
set -euo pipefail
cd "$(dirname "$0")"
REF=../../../Reference_Implementation/Laurus-768
OPT=../../../Optimized_Implementation/Laurus-768
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
OBJ=../../../build/ours_768
mkdir -p "$OBJ"

gcc -c -fPIC $FLAGS -I "$REF" -o "$OBJ/glue.o"  "$REF/CryptHash_AlgorithmInstance.c"
gcc -c -fPIC $FLAGS -I "$REF" -o "$OBJ/drng.o"  "$REF/drng.c"
gcc -c -fPIC $FLAGS -Dlaurus_768=laurus_768__raw -I "$OPT" -I "$REF" -I . -o "$OBJ/impl.o" ours_768.c
gcc -c -fPIC $FLAGS -I "$REF" -o "$OBJ/shim.o" shim_768_len.c
gcc -shared -o ../../../build/our_768.so "$OBJ/glue.o" "$OBJ/drng.o" "$OBJ/impl.o" "$OBJ/shim.o"
echo "built build/our_768.so"
