# Dragon-512

Algorithm: Dragon | Digest bits: 512 | Form: 标量 C（宏展开）

Contents: implementation source/, public header Dragon-512.h, prebuilt Dragon-512.so,
KAT vector KAT_2_12_Dragon-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 06254e335913855be89809130c41f0aed335d3be75cf138bc85622be93189395
Speed (cpB, lower is faster): reference 10.66 / official-optimized 3.39 / optimized 3.23
Speedup: GM(S1-S8) 1.05x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
