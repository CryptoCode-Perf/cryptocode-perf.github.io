# Dragon — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Dragon-512
- 摘要位：512；实现形态：标量 C（宏展开）
- 官方参考源码：随包 `Reference_Implementation/Dragon-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Dragon-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Dragon-512/`
- 优化要点：_scoreboard/ours/h07_ours_wrap.c + alg/h07/agent.s
