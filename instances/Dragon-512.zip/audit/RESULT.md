# Dragon — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| Dragon-512 | `Dragon-512.so` | 31632 B | `06254e335913855be89809130c41f0aed335d3be75cf138bc85622be93189395` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| Dragon-512 | 512 | 10.6572 | 3.3934 | 3.225427 | 1.052078 | 1.0535 |

## 优化方法（逐实例原文，来自交付清单）

### Dragon-512
_scoreboard/ours/h07_ours_wrap.c + alg/h07/agent.s
