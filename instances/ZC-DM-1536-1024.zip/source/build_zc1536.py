"""构建 ZC-DM-1536 三实例（512/768/1024）的 .so 并跑三道门。

口径与 `_overnight/l0/zc/` 的 ZC-1280 256 位版一致：
  * 外壳（吸收/填充/域分隔/挤出）用**官方胶水** `CryptHash_AlgorithmInstance.c`
    （Optimized_Implementation 侧），只把核心置换换成我们自己的 jasmin 产物；
  * 编译用官方十 flag 逐字：`-O3 -march=x86-64 -mavx2 -mtune=native -flto
    -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra`；
  * 门顺序：置换逐随机状态比对 → KAT → （计时由 captain 独占，本脚本不测时间）。

用法：python3 build_zc1536.py [--skip-gen]
"""
import ctypes
import hashlib
import io
import json
import os
import random
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
L0 = os.path.abspath(os.path.join(HERE, ".."))
SRC = os.path.join(L0, "src", "hash-30", "ZC-DM", "Implementations")
INST_ROOT = os.path.join(SRC, "Implementations")
LIB = os.path.join(SRC, "lib", "low", "ZuD-1536")
OUT = os.path.join(HERE, "out")
LOGS = os.path.join(HERE, "logs")

OPT_FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
             "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

INSTANCES = [
    ("ZC-DM-1536-512", 512),
    ("ZC-DM-1536-768", 768),
    ("ZC-DM-1536-1024", 1024),
]

INC = [
    os.path.join(LIB),
    os.path.join(LIB, "plain"),
    os.path.join(LIB, "AVX2"),
    os.path.join(SRC, "lib", "common"),
]


def sh(args, logname, timeout=600):
    """跑命令并把输出落盘（不用 capture_output —— 本环境会 WinError 5）。"""
    os.makedirs(LOGS, exist_ok=True)
    log = os.path.join(LOGS, logname)
    with open(log, "w") as fh:
        r = subprocess.run(args, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout)
    txt = io.open(log, encoding="utf-8", errors="replace").read()
    return r.returncode, txt


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------- 构建

def build_plain():
    """官方 plain 置换单独编成 .so：置换比对的裁判。"""
    os.makedirs(OUT, exist_ok=True)
    so = os.path.join(OUT, "plain_1536.so")
    cmd = ["gcc", "-O2", "-std=c99", "-fPIC", "-shared", "-o", so]
    for d in INC:
        cmd += ["-I", d]
    cmd.append(os.path.join(LIB, "plain", "ZuD1536-plain.c"))
    rc, log = sh(cmd, "plain_build.log")
    if rc != 0:
        print("✗ plain 参考构建失败：\n" + log[-2500:])
        return None
    print("✓ plain 裁判：%s（%d 字节）" % (so, os.path.getsize(so)))
    return so


def build_jasmin():
    """两个 .jazz -> .s -> .o。"""
    os.makedirs(OUT, exist_ok=True)
    objs = []
    for name in ("zud1536_p12", "zud1536_round"):
        jazz = os.path.join(HERE, name + ".jazz")
        s = os.path.join(OUT, name + ".s")
        rc, log = sh(["jasminc", "-o", s, jazz], name + "_jasminc.log")
        if rc != 0:
            print("✗ jasminc %s 失败：\n%s" % (name, log[-2500:]))
            return None
        o = os.path.join(OUT, name + ".o")
        rc, log = sh(["gcc", "-c", "-o", o, s], name + "_as.log")
        if rc != 0:
            print("✗ 汇编 %s 失败：\n%s" % (name, log[-2500:]))
            return None
        objs.append(o)
    return objs


def compile_c(src, outdir, name, extra=()):
    o = os.path.join(outdir, name + ".o")
    cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", o]
    for d in INC:
        cmd += ["-I", d]
    cmd += list(extra)
    cmd.append(src)
    rc, log = sh(cmd, name + "_cc.log")
    if rc != 0:
        print("✗ 编译 %s 失败：\n%s" % (os.path.basename(src), log[-2500:]))
        return None
    return o


def build_instance(inst, core_objs, jasmin_objs):
    outdir = os.path.join(OUT, inst)
    os.makedirs(outdir, exist_ok=True)
    api_o = compile_c(os.path.join(HERE, "zud1536_api.c"), outdir, "zud1536_api")
    if not api_o:
        return None
    inst_dir = os.path.join(INST_ROOT, "Optimized_Implementation", inst)
    glue_o = compile_c(os.path.join(inst_dir, "CryptHash_AlgorithmInstance.c"),
                       outdir, "glue", extra=["-I", inst_dir])
    if not glue_o:
        return None
    so = os.path.join(outdir, "ours_zc1536_%s.so" % inst.split("-")[-1])
    rc, log = sh(["gcc", "-shared", "-o", so, api_o, glue_o] + jasmin_objs,
                 "link_%s.log" % inst)
    if rc != 0:
        print("✗ 链接 %s 失败：\n%s" % (inst, log[-2500:]))
        return None
    print("✓ %s：%s（%d 字节）" % (inst, so, os.path.getsize(so)))
    return so


# ---------------------------------------------------------------- 门

WA = 24  # 24 个 u64 lane


def _mk_state(rnd):
    return [rnd.getrandbits(64) for _ in range(WA)]


def perm_gate(so, plain_so, trials=64):
    """① 置换逐随机状态比对：12 轮 / Nrounds(1..12) / 6 轮。"""
    ours = ctypes.CDLL(so)
    plain = ctypes.CDLL(plain_so)
    P = ctypes.POINTER(ctypes.c_uint64)
    ours.ZuD1536_avx2_Permute_12rounds.argtypes = [P]
    ours.ZuD1536_avx2_Permute_Nrounds.argtypes = [P, ctypes.c_uint]
    ours.ZuD1536_avx2_Permute_6rounds.argtypes = [P]
    plain.ZuD1536_plain_Permute_12rounds.argtypes = [P]
    plain.ZuD1536_plain_Permute_Nrounds.argtypes = [P, ctypes.c_uint]
    plain.ZuD1536_plain_Permute_6rounds.argtypes = [P]

    rnd = random.Random(20261106)
    bad = 0
    first = None
    # 12 轮（含全零 / 全 1 / 随机）
    cases = [[0] * WA, [0xFFFFFFFFFFFFFFFF] * WA] + [_mk_state(rnd) for _ in range(trials)]
    for t, st in enumerate(cases):
        a = (ctypes.c_uint64 * WA)(*st)
        b = (ctypes.c_uint64 * WA)(*st)
        ours.ZuD1536_avx2_Permute_12rounds(a)
        plain.ZuD1536_plain_Permute_12rounds(b)
        if list(a) != list(b):
            bad += 1
            if first is None:
                first = ("p12", t, [(i, a[i], b[i]) for i in range(WA) if a[i] != b[i]][:4])
    n12 = len(cases)
    print("  ①a 12 轮置换：%d/%d 一致%s"
          % (n12 - bad, n12, "" if not bad else "，首个不一致 %s" % (first,)))

    # Nrounds(1..12)，另外试 nr=0 与 nr=99(>MAXROUNDS 应被 clamp 到 12)
    bad_nr = 0
    first_nr = None
    n_nr = 0
    for nr in list(range(1, 13)) + [0, 99]:
        for t in range(8):
            st = _mk_state(rnd)
            a = (ctypes.c_uint64 * WA)(*st)
            b = (ctypes.c_uint64 * WA)(*st)
            ours.ZuD1536_avx2_Permute_Nrounds(a, nr)
            plain.ZuD1536_plain_Permute_Nrounds(b, nr)
            n_nr += 1
            if list(a) != list(b):
                bad_nr += 1
                if first_nr is None:
                    first_nr = (nr, t, [(i, a[i], b[i]) for i in range(WA) if a[i] != b[i]][:4])
    print("  ①b Nrounds(nr=0..12,99) × 8 组：%d/%d 一致%s"
          % (n_nr - bad_nr, n_nr, "" if not bad_nr else "，首个不一致 %s" % (first_nr,)))

    # 6 轮
    bad6 = 0
    first6 = None
    for t in range(24):
        st = _mk_state(rnd)
        a = (ctypes.c_uint64 * WA)(*st)
        b = (ctypes.c_uint64 * WA)(*st)
        ours.ZuD1536_avx2_Permute_6rounds(a)
        plain.ZuD1536_plain_Permute_6rounds(b)
        if list(a) != list(b):
            bad6 += 1
            if first6 is None:
                first6 = (t, [(i, a[i], b[i]) for i in range(WA) if a[i] != b[i]][:4])
    print("  ①c 6 轮置换 × 24 组：%d/%d 一致%s"
          % (24 - bad6, 24, "" if not bad6 else "，首个不一致 %s" % (first6,)))

    ok = (bad == 0 and bad_nr == 0 and bad6 == 0)
    return ok, {"p12": [n12 - bad, n12], "nrounds": [n_nr - bad_nr, n_nr],
                "p6": [24 - bad6, 24], "first_bad": first or first_nr or first6}


def kat_gate(so, inst):
    """② KAT（官方向量，最多 40 条）。"""
    sys.path.insert(0, L0)
    import kat_gate as K
    recs, files = K.find_kat("hash-30", inst)
    checked, match, first_bad, err = K.check(so, recs)
    ok = bool(checked) and match == checked
    print("  ② KAT %s：%s %d/%d%s%s"
          % (inst, "✓" if ok else "✗", match, checked,
             "" if not first_bad else "，首个不符 %s" % (first_bad,),
             "" if not err else "，门报错 %s" % err))
    return ok, {"files": [os.path.basename(p) for p in files], "match": match,
                "checked": checked, "first_bad": first_bad, "error": err}


def ir_stats():
    """从 .jir 复算 IR 规模（与 gen 脚本一致），并读 .s 的指令数。"""
    sys.path.insert(0, WORK)
    import ir_text as I
    stats = {}
    for name in ("zud1536_p12", "zud1536_round"):
        jir = io.open(os.path.join(HERE, name + ".jir"), encoding="utf-8").read()
        js, info = I.to_jasmin(jir, nregs=16)
        n_insn = 0
        s_path = os.path.join(OUT, name + ".s")
        if os.path.exists(s_path):
            for line in io.open(s_path, encoding="utf-8", errors="replace"):
                t = line.strip()
                if not t or t.startswith(".") or t.startswith("#") or t.endswith(":"):
                    continue
                n_insn += 1
        stats[name] = {"ir_instr": info["ir_instr"], "peak": info["peak"],
                       "spill": info["spill"], "asm_insn": n_insn}
    return stats


def main():
    t0 = time.time()
    os.makedirs(OUT, exist_ok=True)
    if "--skip-gen" not in sys.argv:
        rc, log = sh([sys.executable, os.path.join(HERE, "gen_zud1536.py")],
                     "gen.log")
        print(log.strip())
        if rc != 0:
            return 1
    plain = build_plain()
    jas = build_jasmin()
    if not plain or not jas:
        return 1
    results = {}
    all_ok = True
    for inst, bits in INSTANCES:
        so = build_instance(inst, None, jas)
        if not so:
            all_ok = False
            continue
        print("[%s]" % inst)
        ok1, r1 = perm_gate(so, plain)
        ok2, r2 = kat_gate(so, inst)
        ok = ok1 and ok2
        all_ok = all_ok and ok
        results[inst] = {"digest_bits": bits, "so": os.path.relpath(so, HERE),
                         "so_sha256": sha256(so), "so_bytes": os.path.getsize(so),
                         "gate_perm": r1, "gate_kat": r2, "ok": ok}
    results["_ir"] = ir_stats()
    results["_plain_so_sha256"] = sha256(plain)
    results["_elapsed_s"] = round(time.time() - t0, 1)
    results["_all_gates_ok"] = all_ok
    results["_timed"] = False
    io.open(os.path.join(HERE, "gates.json"), "w", encoding="utf-8",
            newline="\n").write(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
    print("\n%s 三道门：%s（未计时）"
          % ("✓" if all_ok else "✗", "全绿" if all_ok else "有红"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
