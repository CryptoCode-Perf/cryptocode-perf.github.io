#!/usr/bin/env python3
from pathlib import Path
import ctypes,random
root=Path(__file__).resolve().parent.parent;rng=random.Random(20261127)
for tier in (512,1024):
 libs=[ctypes.CDLL(str(root/'build'/f'{kind}-{tier}.so')) for kind in ('Reference','Optimized','CryptoCode')]
 for l in libs:l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
 d=tier//8
 for n in (0,1,7,8,9,63,64,65,511,512,513,1023,1024,1025,4095,4096,4097,8193):
  msg=rng.randbytes((n+7)//8);source=ctypes.create_string_buffer(msg or b'\0');expect=ctypes.create_string_buffer(d);assert libs[0].CryptHash(tier,source,n,expect)==0
  for l in libs:
   size=max(d,len(msg));box=ctypes.create_string_buffer(b'\xa5'*16+msg+b'\xa5'*(size-len(msg))+b'\xa5'*16,32+size);before=box.raw;ptr=ctypes.byref(box,16)
   assert l.CryptHash(tier,ptr,n,ptr)==0 and box.raw[16:16+d]==expect.raw and box.raw[:16]==before[:16] and box.raw[16+size:]==before[16+size:],(tier,n,'in-place')
 for l in libs:
  a=ctypes.create_string_buffer(d);b=ctypes.create_string_buffer(d)
  assert l.CryptHash(tier,None,0,a)==0 and l.CryptHash(tier,b'',0,b)==0 and a.raw==b.raw
  # Source fixes output by instance and ignores the digest-length argument.
  assert l.CryptHash(0,b'',0,b)==0 and a.raw==b.raw
 print('CHAMP-%d: in-place, empty-input and fixed-digest behavior passed'%tier)
