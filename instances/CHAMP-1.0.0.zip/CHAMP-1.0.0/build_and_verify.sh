#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
{ uname -a; gcc --version; lscpu; } > build/environment.txt
exec 9>build/build-commands.log
export BASH_XTRACEFD=9
set -x
for bits in 512 1024; do
 for kind in Reference Optimized; do
  d="${kind}_Implementation/CHAMP-$bits"
  flags="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/CryptHash_AlgorithmInstance.c" -o "build/$kind-$bits.so"
 done
 d="CryptoCode_Implementation/CHAMP-$bits"
 gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -Wl,-z,defs -I"$d" "$d/glue_champ$bits.c" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 "test/kat_$bits.py" "build/$kind-$bits.so" 100000 0 "kat/CHAMP-$bits.txt"; done
done

python3 test/differential.py
python3 test/api_check.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 1024; do for kind in Reference Optimized CryptoCode; do build/guard_check "build/$kind-$bits.so" "$bits"; done; done

set +x
