# CHAMP 1.0.0 — CryptoCode implementation

Instances: CHAMP-512 and CHAMP-1024. Requires x86-64 Linux/WSL2, AVX2, GCC,
Python 3 and standard Unix tools. From this directory run:

    bash build_and_verify.sh

The script rebuilds reference, official optimized and CryptoCode implementations,
checks all 4097 known-answer vectors per implementation and instance, compares
selected long and boundary inputs, and tests guarded buffers and in-place calls.
Compile commands and environment are recorded under build/. Prebuilt libraries
are in prebuilt/.

`CryptHash` takes digest length in bits, a message pointer, a message length in
bits and an output pointer. Each build has a fixed output size: the original
reference and both other implementations ignore the digest-length argument.
Call with the named instance size and allocate 64 bytes for CHAMP-512 or 128
bytes for CHAMP-1024; the library does not reject an incorrect digest length.
An empty message may use a null input pointer; nonempty input and output must
point to valid buffers. Original source notices are retained.

The delivery binaries match the previously captured website binaries; their
source files match the report source. The report's 512 prebuilt file was no
longer available during the final comparison, so its last recorded hash is
corroborated by the unchanged website binary and source, not a current file.

Performance measurements of rebuilt official optimized and CryptoCode
libraries, three 101-sample rounds over eight input sizes, are under
results/2026-11-27-delivery-comparison. Reference timing was sampled in a
separate session under results/2026-11-27-reference-comparison. Units are
elapsed nanoseconds, not hardware cycles. To remeasure after building:

    python3 test/measure.py --lock /path/to/shared/measurement.lock --output /path/to/new/results

The lock cannot exclude unrelated host work. Results depend on hardware and
load. Tests do not prove security or constant-time behavior. See
SOURCE_MANIFEST.json for hashes.
