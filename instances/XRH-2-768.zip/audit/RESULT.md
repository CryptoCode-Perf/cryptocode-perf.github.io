# XRH-2 — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| XRH-2-1024 | `XRH-2-1024.so` | 38872 B | `481a2ccafc6c8952883ee606ab055c956cb73274ca60e8af6ba11f62dbbc45ee` |
| XRH-2-768 | `XRH-2-768.so` | 38872 B | `271d77174f891db2a95217bfb95651280910f99b32b15e3e2401ef6c72641f45` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| XRH-2-1024 | 1024 | 59.4414 | 49.4856 | 42.597204 | 1.16171 | 1.1331 |
| XRH-2-768 | 768 | 26.0791 | 21.2065 | 19.448481 | 1.090394 | 1.0787 |

## 优化方法（逐实例原文，来自交付清单）

### XRH-2-1024
引擎产物 `_overnight/l0/xrh2/out/ours_xrh2_1024.so`（`port_xrh2.py`：官方参考 `.c` 逐字保留，只把 54 行标量 `void XRH1280(int R0,int R1,uint64_t *restrict buf)` 挖掉换成调用 `xrh_r0_18` 的声明；核心 = `_overnight/l0/xrh_vec/xrh_r0_18.{jir,jazz,o}`，零改动复用） ★官方 `Optimized_Implementation/XRH-2-1024/CryptHash_AlgorithmInstance.c` 与 hash-28 的同名文件 **diff 0 行**；两种模式只需不同轮入口：XRH-1 EDMC = `XRH1280(0,9)`→异或容量部分→`XRH1280(9,18)`，XRH-2 DM = `XRH1280(0,18)`→异或全部 20 字，所以 XRH-2 只要 (0,18) 一个入口。（512 / 768 / 1024 三份 .so 的 sha256 互不相同，是三份独立二进制，不是一件库多档位。）等价性：A1 `kat_gate` 全量 4097 条 ours/ref/opt 三方各 4097/4097（KAT = `src/hash-29/XRH-2/Test_Vectors/KAT_2_12_XRH-2-1024.txt`，`KAT_2_23`/`KAT_2_33` 不进分母）；A2 `delivery_gate.py` 11 个位长全部一致；A3 时间 `_ab_pair.py --reps 7 --pairs 80` 对官方 `opt.so`。

### XRH-2-768
引擎产物 `_overnight/l0/xrh2/out/ours_xrh2_768.so`（`port_xrh2.py`：官方参考 `.c` 逐字保留，只把 54 行标量 `void XRH1280(int R0,int R1,uint64_t *restrict buf)` 挖掉换成调用 `xrh_r0_18` 的声明；核心 = `_overnight/l0/xrh_vec/xrh_r0_18.{jir,jazz,o}`，零改动复用） ★官方 `Optimized_Implementation/XRH-2-1024/CryptHash_AlgorithmInstance.c` 与 hash-28 的同名文件 **diff 0 行**；两种模式只需不同轮入口：XRH-1 EDMC = `XRH1280(0,9)`→异或容量部分→`XRH1280(9,18)`，XRH-2 DM = `XRH1280(0,18)`→异或全部 20 字，所以 XRH-2 只要 (0,18) 一个入口。（512 / 768 / 1024 三份 .so 的 sha256 互不相同，是三份独立二进制，不是一件库多档位。）等价性：A1 `kat_gate` 全量 4097 条 ours/ref/opt 三方各 4097/4097（KAT = `src/hash-29/XRH-2/Test_Vectors/KAT_2_12_XRH-2-768.txt`，`KAT_2_23`/`KAT_2_33` 不进分母）；A2 `delivery_gate.py` 11 个位长全部一致；A3 时间 `_ab_pair.py --reps 7 --pairs 80` 对官方 `opt.so`。
