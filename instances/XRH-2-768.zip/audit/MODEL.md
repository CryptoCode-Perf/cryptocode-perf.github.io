# XRH-2 — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## XRH-2-1024
- 摘要位：1024；实现形态：AVX2 汇编
- 官方参考源码：随包 `Reference_Implementation/XRH-2-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/XRH-2-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/XRH-2-1024/`
- 优化要点：引擎产物 `_overnight/l0/xrh2/out/ours_xrh2_1024.so`（`port_xrh2.py`：官方参考 `.c` 逐字保留，只把 54 行标量 `void XRH1280(int R0,int R1,uint64_t *restrict buf)` 挖掉换成调用 `xrh_r0_18` 的声明；核心 = `_overnight/l0/xrh_vec/xrh_r0_18.{jir,jazz,o}`，零改动复用） ★官方 `Optimized_Implementation/XRH-2-1024/CryptHash_AlgorithmInstance.c` 与 hash-28 的同名文件 **diff 0 行**；两种模式只需不同轮入口：XRH-1 EDMC = `XRH1280(0,9)`→异或容量部分→`XRH1280(9,18)`，XRH-2 DM = `X

## XRH-2-768
- 摘要位：768；实现形态：AVX2 汇编
- 官方参考源码：随包 `Reference_Implementation/XRH-2-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/XRH-2-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/XRH-2-768/`
- 优化要点：引擎产物 `_overnight/l0/xrh2/out/ours_xrh2_768.so`（`port_xrh2.py`：官方参考 `.c` 逐字保留，只把 54 行标量 `void XRH1280(int R0,int R1,uint64_t *restrict buf)` 挖掉换成调用 `xrh_r0_18` 的声明；核心 = `_overnight/l0/xrh_vec/xrh_r0_18.{jir,jazz,o}`，零改动复用） ★官方 `Optimized_Implementation/XRH-2-1024/CryptHash_AlgorithmInstance.c` 与 hash-28 的同名文件 **diff 0 行**；两种模式只需不同轮入口：XRH-1 EDMC = `XRH1280(0,9)`→异或容量部分→`XRH1280(9,18)`，XRH-2 DM = `XR
