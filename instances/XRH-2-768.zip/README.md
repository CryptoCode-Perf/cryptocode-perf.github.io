# XRH-2-768

Algorithm: XRH-2 | Digest bits: 768 | Form: AVX2 汇编

Contents: implementation source/, public header XRH-2-768.h, prebuilt XRH-2-768.so,
KAT vector KAT_2_12_XRH-2-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 271d77174f891db2a95217bfb95651280910f99b32b15e3e2401ef6c72641f45
Speed (cpB, lower is faster): reference 26.08 / official-optimized 21.21 / optimized 19.45
Speedup: GM(S1-S8) 1.08x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
