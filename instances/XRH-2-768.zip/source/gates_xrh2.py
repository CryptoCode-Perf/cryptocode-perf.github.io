#!/usr/bin/env python3
"""gates_xrh2.py —— XRH-2 三实例的四道门（全跑真硬件，未计时）。

门 0：置换对拍 —— 我们的 `XRH1280(0,18)` 与官方参考实现的 `XRH1280(0,18)`
      逐字节比 20 个 u64（64 组随机 + 全 0 + 全 ff）。
门 1：完整摘要 —— 与官方**参考** `.so` 逐字节比（多个位长，含吸收边界）。
门 2：KAT —— `kat_gate.find_kat` 找向量文件、逐条比公布值。
门 3：`kat_gate` 的 both 判定（同时 ref 与 opt 都过，才证明我们的实现落在官方语义上）。
门 4：与官方**优化版** `.so` 的完整摘要对拍（11 个长度，比全部被覆写字节）。
"""
import ctypes
import hashlib
import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
sys.path.insert(0, L0)

import kat_gate as K  # noqa: E402

INST = [("XRH-2-512", 512), ("XRH-2-768", 768), ("XRH-2-1024", 1024)]
BULD = os.path.join(L0, "build", "hash-29")
LENGTHS = [0, 8, 128, 512, 1000, 1024, 2048, 4096, 8192, 16384, 65536]


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def load(p):
    lib = ctypes.CDLL(p)
    lib.CryptHash.restype = ctypes.c_int
    lib.CryptHash.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_ubyte),
                              ctypes.c_ulonglong, ctypes.POINTER(ctypes.c_ubyte)]
    return lib


def digest(lib, msg, bits):
    nout = max(64, bits // 8 + 8)
    out = (ctypes.c_ubyte * nout)(*([0xAA] * nout))
    buf = (ctypes.c_ubyte * max(1, len(msg)))(*msg) if msg else (ctypes.c_ubyte * 1)()
    rc = lib.CryptHash(bits, buf, len(msg) * 8, out)
    return rc, bytes(out[: bits // 8])


def gate0(ours, ref, bits):
    """置换门：我们的 XRH1280(0,18) vs 官方参考 XRH1280(0,18)。"""
    a, b = ctypes.CDLL(ours), ctypes.CDLL(ref)
    for lib in (a, b):
        lib.XRH1280.argtypes = [ctypes.c_int, ctypes.c_int,
                                ctypes.POINTER(ctypes.c_uint64)]
    rnd = random.Random(20261106)
    bad = 0
    trials = [bytes([0] * 20 * 8), bytes([0xFF] * 20 * 8)]
    trials += [bytes(rnd.getrandbits(8) for _ in range(20 * 8)) for _ in range(64)]
    for t in trials:
        v1 = (ctypes.c_uint64 * 20)(*[int.from_bytes(t[i * 8:(i + 1) * 8], "little")
                                     for i in range(20)])
        v2 = (ctypes.c_uint64 * 20)(*list(v1))
        a.XRH1280(0, 18, v1)
        b.XRH1280(0, 18, v2)
        if list(v1) != list(v2):
            bad += 1
    return bad, len(trials)


def main():
    ok_all = True
    rows = []
    for name, bits in INST:
        ours = os.path.join(HERE, "out", "ours_xrh2_%d.so" % bits)
        ref = os.path.join(BULD, "xrh2%d" % bits, "ref.so")
        opt = os.path.join(BULD, "xrh2%d" % bits, "opt.so")
        print("=" * 78)
        print("%s   ours=%s（%d B, sha256 %s）" % (
            name, os.path.relpath(ours, L0), os.path.getsize(ours), sha(ours)[:16]))
        if not (os.path.exists(ours) and os.path.exists(ref)):
            print("  ✗ 缺文件"); ok_all = False; continue

        bad, n = gate0(ours, ref, bits)
        print("  门0 置换 XRH1280(0,18)：%d/%d 组一致%s"
              % (n - bad, n, "" if bad == 0 else "  ✗"))
        ok_all &= bad == 0

        lo, lr = load(ours), load(ref)
        mism = []
        for L in LENGTHS:
            msg = [(i * 131 + 17) & 0xFF for i in range(L // 8)]
            rc1, d1 = digest(lo, msg, bits)
            rc2, d2 = digest(lr, msg, bits)
            if rc1 != rc2 or d1 != d2:
                mism.append((L, rc1, rc2))
        print("  门1 完整摘要 vs 官方参考（%d 个长度）：%s"
              % (len(LENGTHS), "全等" if not mism else "✗ %s" % mism[:3]))
        ok_all &= not mism

        recs, kfiles = K.find_kat("hash-29", name)
        checked, match, first_bad, err = K.check(ours, recs)
        both = (err is None and checked > 0 and match == checked)
        print("  门2/3 kat_gate：checked=%d match=%d first_bad=%r err=%r ⇒ %s（KAT %s）"
              % (checked, match, first_bad, err,
                 "both" if both else "NOT both",
                 os.path.basename(kfiles[0]) if kfiles else "-"))
        ok_all &= both

        lo2 = load(opt)
        mism2 = []
        for L in LENGTHS:
            msg = [(i * 131 + 17) & 0xFF for i in range(L // 8)]
            rc1, d1 = digest(lo, msg, bits)
            rc2, d2 = digest(lo2, msg, bits)
            if rc1 != rc2 or d1 != d2:
                mism2.append(L)
        print("  门4 完整摘要 vs 官方优化版（%d 个长度）：%s"
              % (len(LENGTHS), "全等" if not mism2 else "✗ %s" % mism2))
        ok_all &= not mism2
        rows.append({"instance": name, "digest_bits": bits,
                     "ours_so": os.path.relpath(ours, L0), "ours_sha256": sha(ours),
                     "gate0_perm": "%d/%d" % (n - bad, n),
                     "gate1_vs_ref": not mism,
                     "gate2_kat": "both" if both else "checked=%d match=%d err=%r"
                                                 % (checked, match, err),
                     "gate4_vs_opt": not mism2})

    json.dump({"all_ok": bool(ok_all), "results": rows},
              open(os.path.join(HERE, "GATES.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("=" * 78)
    print("四道门（未计时）：%s" % ("全绿" if ok_all else "有红"))
    return 0 if ok_all else 1


if __name__ == "__main__":
    raise SystemExit(main())
