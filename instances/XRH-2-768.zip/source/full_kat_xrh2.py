#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""full_kat_xrh2.py —— XRH-2 全量官方 KAT（绕过 kat_gate.MAX_RECORDS=40 的上限）。

`KAT_2_12_XRH-2-{512,768,1024}.txt` 各 4097 条（Msg_Len 0..4096 bit）且每条都带
完整 `Msg` 十六进制 ⇒ 可以逐条当权威比对。同时把官方**参考** .so 也跑一遍，
用来证明「分母是这条 KAT 本身可用的记录数」，而不是我们的实现对不上才少算。

`KAT_2_23_*` 用 `Msg_Seed`/`Msg_Exp` 表达 8 Mbit 消息（无 `Msg` 字段），
`KAT_2_33_*` 是 8 Gbit（1 GiB），`KAT_Loop_*` 语义不明 —— 这三类都不进分母，
理由与 `neulaser_vec/full_kat.py` 一致。

用法：python3 full_kat_xrh2.py [--quiet]
"""
import ctypes
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(HERE, "out")
BUILD = os.path.join(L0, "build", "hash-29")
SRC = os.path.join(L0, "src", "hash-29", "XRH-2", "Test_Vectors")
if L0 not in sys.path:
    sys.path.insert(0, L0)

INST = [512, 768, 1024]


def files(d):
    return sorted(glob.glob(os.path.join(SRC, "KAT_2_12_XRH-2-%d.txt" % d)))


def digest_bits(lib, msg, out_bits, msg_bits):
    """按**记录的位长**调用 CryptHash（不是 len(msg)*8）。

    KAT_2_12 里 4097 条有 3584 条消息位长不是 8 的倍数（1..4096 位全谱），
    hex 是按字节补齐的；用 `len(msg)*8` 会把 1 位消息当 8 位，这 3584 条全错
    —— 官方 ref 也一样错（第一版实测两边都是 513/4097，正好证明是调用方式
    的问题，不是实现的问题）。
    """
    nout = max(64, out_bits // 8 + 8)
    out = (ctypes.c_ubyte * nout)(*([0xAA] * nout))
    buf = (ctypes.c_ubyte * max(1, len(msg)))(*msg) if msg else (ctypes.c_ubyte * 1)()
    rc = lib.CryptHash(out_bits, buf, msg_bits, out)
    return rc, bytes(out[: out_bits // 8])


def main():
    from kat_gate import parse_kat
    import gates_xrh2 as G

    quiet = "--quiet" in sys.argv
    tot = ok = bad = refok = 0
    first_bad = None
    detail = []
    for d in INST:
        fs = files(d)
        if not fs:
            raise SystemExit("找不到 KAT_2_12_XRH-2-%d.txt" % d)
        recs = []
        for p in fs:
            recs += parse_kat(p)
        ours = G.load(os.path.join(OUT, "ours_xrh2_%d.so" % d))
        ref = G.load(os.path.join(BUILD, "xrh2%d" % d, "ref.so"))
        n_ok = n_ref = 0
        for i, r in enumerate(recs):
            nb = r["msg_len_bits"]
            msg = bytes.fromhex(r["msg_hex"]) if r["msg_hex"] else b""
            a = digest_bits(ours, list(msg), d, nb)[1].hex()
            b = digest_bits(ref, list(msg), d, nb)[1].hex()
            tot += 1
            if a == r["dst_hex"]:
                n_ok += 1
            else:
                bad += 1
                if first_bad is None:
                    first_bad = {"instance": d, "idx": i, "bits": nb,
                                 "kat": r["dst_hex"][:32], "ours": a[:32],
                                 "ref": b[:32]}
            if b == r["dst_hex"]:
                n_ref += 1
            if (not quiet) and i % 1000 == 0:
                print("   XRH-2-%d %d/%d ..." % (d, i, len(recs)), flush=True)
        ok += n_ok
        refok += n_ref
        detail.append({"instance": d, "records": len(recs), "ours_match": n_ok,
                       "ref_match": n_ref, "kat_file": os.path.basename(fs[0])})
        print("XRH-2-%d: %d/%d（官方 ref %d/%d）"
              % (d, n_ok, len(recs), n_ref, len(recs)))

    res = {"gate": "full_kat", "total": tot, "ok": ok, "bad": bad,
           "ref_ok": refok, "first_bad": first_bad, "detail": detail}
    json.dump(res, open(os.path.join(HERE, "GATES_full_kat.json"), "w",
                        encoding="utf-8"), ensure_ascii=False, indent=1)
    print("\n全量 KAT：%d/%d（官方 ref %d/%d）%s"
          % (ok, tot, refok, tot, "" if first_bad is None else "  first_bad=%s" % first_bad))
    return 0 if ok == tot else 1


if __name__ == "__main__":
    raise SystemExit(main())
