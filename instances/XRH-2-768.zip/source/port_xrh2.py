#!/usr/bin/env python3
"""port_xrh2.py —— XRH-2（hash-29）三实例交付件：复用 XRH-1 的向量核心，只换模式外壳。

为什么可以这样（判据，不是猜测）：
1. `src/hash-29/XRH-2/Implementations/Optimized_Implementation/XRH-2-1024/
   CryptHash_AlgorithmInstance.c` 与 hash-28 的同名文件 **逐字节相同**（`diff` 0 行）
   ⇒ 官方自己的两个候选在「核心置换 + S 盒 + MDS + SR 宏」上就是同一份代码。
2. 参考实现只差模式壳：XRH-1 是 EDMC（`XRH1280(0,9)` → 异或容量部分 → `XRH1280(9,18)`），
   XRH-2 是 DM（`XRH1280(0,18)` → 异或全部 20 字）。
3. 我们 `xrh_vec/` 的向量核心本来就生成了 `xrh_r0_18`（第四道门里 64 组 × (0,18) 入口已过）
   ⇒ **XRH-2 只需要 (0,18) 这一个入口，核心对象零改动复用**。

做法：取官方 XRH-2 的**参考实现** C，把它自带的 `XRH1280` 函数体挖掉换成声明
（这样链接时用我们的向量版），其余（`XRH_dm_permute` / `ROUND_CONSTANTS` / `CryptHash`）逐字保留。
挖函数用的是花括号配平，不是行号，避免换实例后错位。

用法（WSL 内）：
    python3 port_xrh2.py cores     # 只生成 xrh_r0_18.{jir,jazz} 并打印 IR 统计
    python3 port_xrh2.py build     # 三实例编译成 out/ours_xrh2_<bits>.so
    python3 port_xrh2.py gates     # 四道门（全跑真硬件，未计时）
"""
import hashlib
import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)                     # _overnight/l0
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(L0, "xrh_vec"))   # 复用 gen_xrh / vec_api

import ir_text as I          # noqa: E402
import gen_xrh as G          # noqa: E402

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

INSTANCES = ["XRH-2-512", "XRH-2-768", "XRH-2-1024"]
BITS = {n: int(n.rsplit("-", 1)[1]) for n in INSTANCES}
OUT = os.path.join(HERE, "out")
REFROOT = os.path.join(L0, "src", "hash-29", "XRH-2",
                       "Implementations", "Reference_Implementation")
CORES = [("xrh_r0_18", 0, 18)]           # XRH-2 只需要整 18 轮这一个入口
THREE_ADDR = True


def run(args, cwd=HERE):
    rc = subprocess.run(args, cwd=cwd).returncode
    if rc != 0:
        raise SystemExit("失败 rc=%d：%s" % (rc, " ".join(args)))
    return rc


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def cut_function(text, signature):
    """把 `signature` 开头的那个 C 函数整体挖掉，返回 (剩余文本, 被挖掉的文本)。"""
    i = text.index(signature)
    j = text.index("{", i)
    depth = 0
    k = j
    while k < len(text):
        if text[k] == "{":
            depth += 1
        elif text[k] == "}":
            depth -= 1
            if depth == 0:
                break
        k += 1
    if depth != 0:
        raise SystemExit("花括号没配平：" + signature)
    return text[:i] + text[k + 1:], text[i:k + 1]


def make_glue(bits):
    """官方 XRH-2 参考实现 C，但把自带的 XRH1280 换成我们向量版的声明。"""
    src = os.path.join(REFROOT, "XRH-2-%d" % bits, "CryptHash_AlgorithmInstance.c")
    text = io.open(src, encoding="utf-8").read()
    body, cut = cut_function(text, "void XRH1280(int R0, int R1, uint64_t *restrict buf)")
    decl = ("/* 本文件的 XRH1280 已挖掉（原本 %d 行标量 C），改用 xrh_vec 的 256 位向量核心。\n"
            " * 判据：hash-29 与 hash-28 的 Optimized_Implementation C 源逐字节相同。 */\n"
            "void XRH1280(int R0, int R1, uint64_t *restrict buf);\n"
            % len(cut.splitlines()))
    # 插在 XRH_dm_permute 之前，保证声明在使用点之前。
    anchor = "void XRH_dm_permute(uint64_t state[STATE_LANES])"
    body = body.replace(anchor, decl + "\n" + anchor, 1)
    p = os.path.join(HERE, "glue_xrh2_%d.c" % bits)
    io.open(p, "w", encoding="utf-8", newline="\n").write(body)
    return p, len(cut.splitlines())


def cores():
    for nm, r0, r1 in CORES:
        text, g, _, _ = G.emit_core(nm, r0, r1, coal=False)
        io.open(os.path.join(HERE, nm + ".jir"), "w", encoding="utf-8",
                newline="\n").write(text)
        js, info = I.to_jasmin(text, nregs=16, entry=nm, three_addr=THREE_ADDR)
        io.open(os.path.join(HERE, nm + ".jazz"), "w", encoding="utf-8",
                newline="\n").write(js)
        print("%-10s 轮 %2d  IR %4d 条、峰值 %2d/16、溢出 %d、andn %d"
              % (nm, r1 - r0, info["ir_instr"], info["peak"], info["spill"],
                 info.get("andn", 0)))
    return 0


def make_api():
    """xrh_vec 的 vec_api.c，但只保留 XRH-2 需要的部分。

    为什么必须裁：`vec_api.c` 里带 `XRH_edmc_permute`（XRH-1 的 EDMC 模式）和
    `XRH1280` 的四路分派，它们引用 `xrh_r0_9` / `xrh_r9_18` / `xrh_round1`。
    XRH-2 只用 (0,18)，若不裁就得为这三个入口也编对象（试过：`undefined
    symbol: xrh_r9_18`），既不必要也让交付件里塞进三条永不执行的路径。
    """
    src = io.open(os.path.join(L0, "xrh_vec", "vec_api.c"), encoding="utf-8").read()
    body, cut_edmc = cut_function(src, "void XRH_edmc_permute(uint64_t state[STATE_LANES])")
    body, cut_disp = cut_function(body, "void XRH1280(int R0, int R1, uint64_t *restrict buf)")
    for nm in ("xrh_round1", "xrh_r0_9", "xrh_r9_18"):
        body = body.replace("extern void %s(uint64_t *p);\n" % nm, "")
    body = body.replace(
        "/* 自然序（20 个连续 u64）→ 向量 scratch",
        "/* 本文件是 xrh_vec/vec_api.c 的 XRH-2 专用裁剪版：\n"
        " * 挖掉 XRH_edmc_permute（EDMC 是 XRH-1 的模式，XRH-2 是 DM）%d 行，\n"
        " * XRH1280 的分派改为只认 (0,18)（挖掉 %d 行）。判据见 port_xrh2.py 顶部。 */\n"
        "/* 自然序（20 个连续 u64）→ 向量 scratch" % (len(cut_edmc.splitlines()),
                                                    len(cut_disp.splitlines())), 1)
    body += ("\nvoid XRH1280(int R0, int R1, uint64_t *restrict buf)\n"
             "{\n"
             "    uint64_t sc[20] __attribute__((aligned(32)));\n"
             "    if (R0 != 0 || R1 != 18) {\n"
             "        fprintf(stderr, \"XRH1280: unsupported range (%d,%d)\\n\", R0, R1);\n"
             "        abort();\n"
             "    }\n"
             "    nat_to_sc(buf, sc);\n"
             "    xrh_r0_18(sc);\n"
             "    sc_to_nat(sc, buf);\n"
             "}\n")
    p = os.path.join(HERE, "vec_api_xrh2.c")
    io.open(p, "w", encoding="utf-8", newline="\n").write(body)
    return p


def build():
    os.makedirs(OUT, exist_ok=True)
    objs = []
    for nm, _, _ in CORES:
        run(["jasminc", "-o", nm + ".s", nm + ".jazz"])
        run(["gcc"] + FLAGS + ["-c", "-o", nm + ".o", nm + ".s"])
        objs.append(os.path.join(HERE, nm + ".o"))
    api = make_api()
    for it in INSTANCES:
        bits = BITS[it]
        glue, cutlines = make_glue(bits)
        incd = os.path.join(REFROOT, it)
        so = os.path.join(OUT, "ours_xrh2_%d.so" % bits)
        run(["gcc"] + FLAGS + ["-fPIC", "-shared", "-o", so, "-I", incd]
            + objs + [api, glue])
        print("build %-10s → %s（%d B，sha256 %s；挖掉标量核心 %d 行）"
              % (it, os.path.relpath(so, L0), os.path.getsize(so), sha(so)[:16], cutlines))
    return 0


def main(argv):
    if len(argv) > 1 and argv[1] == "cores":
        return cores()
    if len(argv) > 1 and argv[1] == "build":
        cores()
        return build()
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
