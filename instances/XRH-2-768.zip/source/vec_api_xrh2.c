
#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <immintrin.h>

extern void xrh_r0_18(uint64_t *p);

/* 本文件是 xrh_vec/vec_api.c 的 XRH-2 专用裁剪版：
 * 挖掉 XRH_edmc_permute（EDMC 是 XRH-1 的模式，XRH-2 是 DM）22 行，
 * XRH1280 的分派改为只认 (0,18)（挖掉 18 行）。判据见 port_xrh2.py 顶部。 */
/* 自然序（20 个连续 u64）→ 向量 scratch（也是 20 个 u64，但换了排法） */
static void nat_to_sc(const uint64_t *x, uint64_t *sc)
{
    __m256i a0 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 0));
    __m256i a1 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 5));
    __m256i a2 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 10));
    __m256i a3 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 15));
    __m256i t0 = _mm256_unpacklo_epi64(a0, a1);
    __m256i t1 = _mm256_unpackhi_epi64(a0, a1);
    __m256i t2 = _mm256_unpacklo_epi64(a2, a3);
    __m256i t3 = _mm256_unpackhi_epi64(a2, a3);
    __m256i c0 = _mm256_permute2x128_si256(t0, t2, 0x20);
    __m256i c1 = _mm256_permute2x128_si256(t1, t3, 0x20);
    __m256i c2 = _mm256_permute2x128_si256(t0, t2, 0x31);
    __m256i c3 = _mm256_permute2x128_si256(t1, t3, 0x31);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 0), c0);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 4), c1);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 8), c2);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 12), c3);
    sc[16] = x[4];
    sc[17] = x[9];
    sc[18] = x[14];
    sc[19] = x[19];
}

/* 向量 scratch → 自然序（与上面同构，转置自逆） */
static void sc_to_nat(const uint64_t *sc, uint64_t *x)
{
    __m256i a0 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 0));
    __m256i a1 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 4));
    __m256i a2 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 8));
    __m256i a3 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 12));
    __m256i t0 = _mm256_unpacklo_epi64(a0, a1);
    __m256i t1 = _mm256_unpackhi_epi64(a0, a1);
    __m256i t2 = _mm256_unpacklo_epi64(a2, a3);
    __m256i t3 = _mm256_unpackhi_epi64(a2, a3);
    _mm256_storeu_si256((__m256i *)(void *)(x + 0),
                        _mm256_permute2x128_si256(t0, t2, 0x20));
    _mm256_storeu_si256((__m256i *)(void *)(x + 5),
                        _mm256_permute2x128_si256(t1, t3, 0x20));
    _mm256_storeu_si256((__m256i *)(void *)(x + 10),
                        _mm256_permute2x128_si256(t0, t2, 0x31));
    _mm256_storeu_si256((__m256i *)(void *)(x + 15),
                        _mm256_permute2x128_si256(t1, t3, 0x31));
    x[4] = sc[16];
    x[9] = sc[17];
    x[14] = sc[18];
    x[19] = sc[19];
}





void XRH1280(int R0, int R1, uint64_t *restrict buf)
{
    uint64_t sc[20] __attribute__((aligned(32)));
    if (R0 != 0 || R1 != 18) {
        fprintf(stderr, "XRH1280: unsupported range (%d,%d)\n", R0, R1);
        abort();
    }
    nat_to_sc(buf, sc);
    xrh_r0_18(sc);
    sc_to_nat(sc, buf);
}
