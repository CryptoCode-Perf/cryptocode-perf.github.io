#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""emit_vec.py — 生成 .jir，再走 `ir_text.to_jasmin` 得到 .jazz，打印分配统计。

只做「发得出去」的最小一步；编译在 build_vec.py 里。
"""
from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, WORK)
sys.path.insert(0, HERE)

import ir_text as I          # noqa: E402
import gen_iphe_vec as V     # noqa: E402
import patch_cse             # noqa: E402

OUT = os.path.join(HERE, "out")


def main(nregs=16):
    os.makedirs(OUT, exist_ok=True)
    text = V.generate_nomodel()
    p = os.path.join(OUT, "iphe_perm_vec.jir")
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    print("写出 %s：%d 行" % (os.path.basename(p), text.count("\n")))

    # 1) 语法自检（parse 不过就别往下走）
    ssa, meta = I.parse(text)
    print("parse OK：%d 节点；常量 %d 个" % (len(ssa.nodes), len(meta["consts"])))
    # 2) dump→parse 往返（文本无损）
    text2 = I.dump(ssa, meta["entry"], meta["params"],
                   consts={c[0]: (c[2], int(c[1], 16).to_bytes(c[2] // 8, "big"))
                           for c in meta["consts"]})
    try:
        I.parse(text2)
        print("dump→parse 往返 OK：%d 行" % text2.count("\n"))
    except I.JirError as exc:
        # 已知缺口（写进 GAP.md）：dump() 的通用分支不写 vshl/vshr 的 4 个 kv，
        # 所以**回写**出来的文本丢移位量。读的方向（parse 手写 .jir）没问题。
        msg = str(exc)
        if "需要 5 个参数" not in msg:
            raise
        print("dump→parse 往返：已知缺口（dump 不写 kv）→ %s" % msg.splitlines()[0])
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "iphe_perm_vec.rt.jir"), "w",
              encoding="utf-8", newline="\n") as f:
        f.write(text2)

    # 3) 发射
    #    先装 kv 感知的 CSE：上游 opt_ir.cse 的合并键 (op, args, k, w) 不含
    #    n.kv，会把「同源、不同 kv」的 vshl/vshr 当成同一子表达式并掉
    #    （本图 600 条里吞掉 85 条，见 patch_cse.py 的文件头与 repro_cse.py）。
    patch_cse.install()
    js, info = I.to_jasmin(text, nregs=nregs)
    print("cse（kv 感知）：合并 %d 条，保留 %d 条不同子表达式"
          % (patch_cse.STATS["merged"], patch_cse.STATS["kept"]))
    n_v = js.count("#VPSLLV_4u64") + js.count("#VPSRLV_4u64")
    print("发射的 vpsllv/vpsrlv：%d 条（.jir 里 vshl/vshr 共 %d 条）"
          % (n_v, text.count("vshl(") + text.count("vshr(")))
    q = os.path.join(OUT, "iphe_perm_vec.jazz")
    with open(q, "w", encoding="utf-8", newline="\n") as f:
        f.write(js)
    print("写出 %s：%d 行" % (os.path.basename(q), js.count("\n")))
    print("IR 指令 %d 条；峰值寄存器 %d/%d；溢出 %d 条（槽 %d）；"
          "真实指令 %d；临界路径 %d；andn 融合 %d"
          % (info["ir_instr"], info["peak"], nregs, info["spill"],
             info["slots"], info["real_instr"], info["cp"], info["andn"]))
    return 0


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 16
    sys.exit(main(n))
