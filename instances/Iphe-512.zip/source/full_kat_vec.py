#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""full_kat_vec.py — 全量 KAT：跑 KAT 文件里的**全部**记录（门 3 只跑 40 条上限）。

与标量版 `iphe/full_kat.py` 同口径、同两条判据，只把 .so 换成 iphe_vec/out 下的
向量版（复用 gates_vec.TARGETS，保证与四门里的实例/路径完全一致）：
  (a) ours vs 文件里的 Dst        —— 能不能复现官方 KAT
  (b) ours vs 官方 ref.so 的 Dst  —— 和官方实现是否等价（真正的交付判据）
`KAT_Loop_*` 只可能成立 (b)：那份文件的 8192 位不是一次性吸收的消息，而是
「种子 + 循环条数」的语义，官方 ref.so/opt.so 喂同一条也复现不出文件里的 Dst，
我们与官方同值（文件口径陷阱，不是实现差异）。
`KAT_2_23` / `KAT_2_33` 的 Msg 字段为空（1 MB / 1 GB 消息不落盘），无法校验，
如实列出跳过条数。

用法：python3 full_kat_vec.py
"""
import ctypes
import glob
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, "..", "..", "..", "_overnight", "l0"))
sys.path.insert(0, L0)
sys.path.insert(0, HERE)

import kat_gate      # noqa: E402
import gates_vec     # noqa: E402

kat_gate.MAX_RECORDS = 10 ** 9
kat_gate.MAX_MSG_BYTES = 10 ** 9


def crypt(lib):
    fn = lib.CryptHash
    fn.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_ulonglong,
                   ctypes.c_void_p]
    fn.restype = ctypes.c_int
    return fn


def run(fn, msg: bytes, bits: int, dbits: int):
    n = dbits // 8
    mb = (ctypes.c_ubyte * max(len(msg), 1))()
    if msg:
        ctypes.memmove(mb, msg, len(msg))
    out = (ctypes.c_ubyte * n)()
    ctypes.memset(out, 0xAA, n)
    rc = fn(dbits, mb, bits, out)
    return rc, bytes(out).hex()


def main():
    checked = 0
    ok_both = 0
    skipped = 0
    bad = []

    for inst, sub, ourso, dbits, _rate in gates_vec.TARGETS:
        ours = crypt(ctypes.CDLL(os.path.join(gates_vec.OUT, ourso)))
        ref = crypt(ctypes.CDLL(os.path.join(gates_vec.BUILD, sub, "ref.so")))
        paths = sorted(glob.glob(os.path.join(kat_gate.SRC, "hash-12", "**",
                                              "Test_Vector*",
                                              "KAT_*_%s.txt" % inst),
                                 recursive=True))
        if not paths:
            print("%-10s 找不到 KAT 文件" % inst)
            bad.append(inst)
            continue
        for path in paths:
            base = os.path.basename(path)
            recs = kat_gate.parse_kat(path)
            if not recs:
                print("%-10s %-26s （空文件，0 条）" % (inst, base))
                continue
            nom = [r for r in recs if "msg_hex" in r]
            skipped += len(recs) - len(nom)
            if not nom:
                print("%-10s %-26s 文件内 %d 条记录不含消息（%s 位），无法校验，跳过"
                      % (inst, base, len(recs), recs[0]["msg_len_bits"]))
                continue
            vs_file = vs_ref = 0
            first = []
            for r in nom:
                msg = bytes.fromhex(r["msg_hex"])
                bits = r["msg_len_bits"]
                want = (r["dst_hex"] or "").lower()
                rc1, d1 = run(ours, msg, bits, dbits)
                rc2, d2 = run(ref, msg, bits, dbits)
                if rc1 == rc2 and d1 == d2:
                    vs_ref += 1
                elif len(first) < 2:
                    first.append("digest/rc @ %d 位: rc %s/%s ours %s… 官方 %s…"
                                 % (bits, rc1, rc2, d1[:12], d2[:12]))
                if rc1 == 0 and d1 == want:
                    vs_file += 1
                elif len(first) < 2:
                    first.append("文件 @ %d 位: 期望 %s… / 我们 %s…"
                                 % (bits, want[:12], d1[:12]))
            n = len(nom)
            checked += n
            both = (vs_file == n and vs_ref == n)
            ok_both += n if both else 0
            print("%-10s %-26s 文件 %4d/%-4d  官方 %4d/%-4d  %s%s"
                  % (inst, base, vs_file, n, vs_ref, n,
                     "OK" if both else ("仅官方一致" if vs_ref == n else "FAIL"),
                     "" if not first else "   " + "; ".join(first)))
            if vs_ref != n:
                bad.append("%s/%s" % (inst, base))

    print()
    print("合计：检查 %d 条；与官方 ref.so 逐字节一致 %d/%d；"
          "同时复现文件 Dst %d 条；因文件不含消息跳过 %d 条"
          % (checked, checked - 0 if not bad else 0, checked, ok_both, skipped)
          if not bad else
          "合计：检查 %d 条，**有失败**：%s（跳过 %d 条无消息记录）"
          % (checked, ", ".join(bad), skipped))
    print("总判定：%s" % ("全量 KAT 与官方等价" if not bad else "有实例未通过"))
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
