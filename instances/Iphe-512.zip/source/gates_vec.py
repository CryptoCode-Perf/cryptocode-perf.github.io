#!/usr/bin/env python3
"""gates_vec.py — Iphe(hash-12) u256 向量化交付件的四道正确性门。

与 `_overnight/l0/iphe/gates.py`（标量交付件）同口径、同门数、同判据，只把
"我们的件"换成 `iphe_vec/out/ours_vec_iphe<bits>.so`（jasmin 生成的 u256 核心置换
+ 逐字照抄的官方外壳），并且门 0 额外用**向量版 JIR 文本**去跑工具链解释器。

  门 0 .jir 语义：工具链解释器 ir_eval 跑 `out/iphe_perm_vec.jir`（内含
        vshl/vshr 的 kv 逐 lane 移位），出口从内存读回 32 个 u64，
        对比 `gen_iphe.model_perm`（源码直译的标量模型，与本目录的
        Emit 建模**互相独立**——这是"JIR 文本本身对"的唯一证据）。
  门 1 核心置换：ours 的 `iphe_perm_vec` vs 官方
        `CryptHash_AlgorithmInstance_permutation`（ref.so 导出），随机状态
        200 组/实例，逐 lane 比；并顺带确认我们 .so 里的同名符号也一致。
  门 2 整条 CryptHash：ours vs 官方 ref.so vs 官方 opt.so，逐字节比摘要 +
        返回码；位长覆盖 0..2048 连续 + 每个 rate_bits 的 ±1/±2 边界 +
        大消息 + 非整字节位长 + 错误入参路径。
  门 3 KAT：kat_gate.find_kat("hash-12", inst) + check，要求 match == checked
        （40 条上限；全量 KAT 见 full_kat_vec.py）。

用法：python3 gates_vec.py [--rounds 200] [--seed 20261105]
退出码 0 = 四道门全过。**不做任何计时**。
"""
import argparse
import ctypes
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
BUILD = os.path.join(WORK, "_overnight", "l0", "build", "hash-12")
L0 = os.path.join(WORK, "_overnight", "l0")
OUT = os.path.join(HERE, "out")
sys.path.insert(0, L0)
sys.path.insert(0, os.path.join(L0, "iphe"))   # 标量交付件里的模型（只读引用）
sys.path.insert(0, HERE)

import kat_gate  # noqa: E402
import gen_iphe  # noqa: E402  标量模型（源码直译），门 0 的参照

sys.path.insert(0, WORK)
import ir_text   # noqa: E402
import ir_eval as ie  # noqa: E402

LANES = 32
PERM_FN = "iphe_perm_vec"

TARGETS = [
    # (实例名, build 子目录, 我们的 .so, digest 位数, rate 位数)
    ("Iphe-1024", "iphe1024", "ours_vec_iphe1024.so", 1024, 2048 - 1024 - 64),
    ("Iphe-768", "iphe768", "ours_vec_iphe768.so", 768, 2048 - 768 - 64),
    ("Iphe-512", "iphe512", "ours_vec_iphe512.so", 512, 2048 - 512 - 64),
]

MAXBITS = 1 << 21          # 门 2 里最大的消息：2 Mibit = 256 KiB


def _load(path):
    return ctypes.CDLL(os.path.abspath(path))


def _perm(lib, name):
    fn = getattr(lib, name)
    fn.argtypes = [ctypes.POINTER(ctypes.c_uint64)]
    fn.restype = None
    return fn


def _crypt(lib):
    fn = lib.CryptHash
    fn.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_ulonglong,
                   ctypes.c_void_p]
    fn.restype = ctypes.c_int
    return fn


# ---------------------------------------------------------------- 门 0
def gate0(rounds, rnd):
    """.jir 语义门：ir_eval 跑**向量版** JIR 文本 vs 源码直译标量模型。"""
    text = open(os.path.join(OUT, "iphe_perm_vec.jir"), encoding="utf-8").read()
    ssa, meta = ir_text.parse(text)
    # 命名常量（注入用的 kv 向量）必须先登记，否则解释器报"没有登记"
    ie.set_consts({nm: (w, int(lit, 16).to_bytes(w // 8, "big"))
                   for nm, lit, w in meta["consts"]})
    ok = 0
    first_bad = None
    for _ in range(rounds):
        x = [rnd.getrandbits(64) for _ in range(LANES)]
        mem = ie.Mem(random.Random(0))
        mem.buf["p"] = bytearray(ie.MEM_SIZE)
        for i, v in enumerate(x):
            mem.write("p", 8 * i, 64, v)
        ie.evaluate(ssa, {"p": 0}, mem)
        # 出口必须从**内存**读回：store 节点在 val 里不携带结果。
        got = [mem.read("p", 8 * i, 64) for i in range(LANES)]
        want = gen_iphe.model_perm(x)
        if got == want:
            ok += 1
        elif first_bad is None:
            d = [i for i in range(LANES) if got[i] != want[i]]
            first_bad = "lane %s" % d[:6]
    return ok, rounds, first_bad


# ---------------------------------------------------------------- 门 1
def gate1(rounds, rnd):
    """核心置换门：ours 的 u256 `iphe_perm_vec` vs 官方置换函数。"""
    rows = []
    u64 = ctypes.c_uint64
    for inst, sub, ourso, _db, _rb in TARGETS:
        ours = _load(os.path.join(OUT, ourso))
        ref = _load(os.path.join(BUILD, sub, "ref.so"))
        f_ours = _perm(ours, PERM_FN)
        f_ref = _perm(ref, "CryptHash_AlgorithmInstance_permutation")
        # 顺带确认 .so 里保留的官方符号名也指向同一份生成代码
        f_alias = _perm(ours, "CryptHash_AlgorithmInstance_permutation")
        ok = 0
        first_bad = None
        for _ in range(rounds):
            x = [rnd.getrandbits(64) for _ in range(LANES)]
            a = (u64 * LANES)(*x)
            b = (u64 * LANES)(*x)
            c = (u64 * LANES)(*x)
            f_ref(a)
            f_ours(b)
            f_alias(c)
            va = [a[i] for i in range(LANES)]
            vb = [b[i] for i in range(LANES)]
            vc = [c[i] for i in range(LANES)]
            if va == vb == vc:
                ok += 1
            elif first_bad is None:
                first_bad = "lane %s" % [i for i in range(LANES)
                                         if va[i] != vb[i]][:6]
        rows.append((inst, ok, rounds, first_bad))
    return rows


# ---------------------------------------------------------------- 门 2
def _bit_lengths(rate_bits):
    """门 2 的位长清单：连续 + 块边界 + 大消息 + 非整字节。"""
    s = set(range(0, 2049))
    for k in range(1, 10):
        for d in (-2, -1, 0, 1, 2):
            v = k * rate_bits + d
            if v >= 0:
                s.add(v)
    s.update(range(1, 8))
    for base in (8, 64, 512, 1024, 1536, 2048, rate_bits - 8, rate_bits):
        for d in range(-7, 8):
            if base + d >= 0:
                s.add(base + d)
    s.update([rate_bits * 16, 100000, 1 << 17, MAXBITS])
    return sorted(s)


def gate2(rnd):
    """整条 CryptHash 门：ours vs 官方 ref.so vs 官方 opt.so，逐字节。"""
    rows = []
    blob = bytes(rnd.getrandbits(8) for _ in range(MAXBITS // 8 + 16))
    buf = (ctypes.c_ubyte * len(blob)).from_buffer_copy(blob)
    for inst, sub, ourso, dbits, rate_bits in TARGETS:
        ours = _crypt(_load(os.path.join(OUT, ourso)))
        ref = _crypt(_load(os.path.join(BUILD, sub, "ref.so")))
        opt = _crypt(_load(os.path.join(BUILD, sub, "opt.so")))
        nbytes = dbits // 8
        d1 = (ctypes.c_ubyte * nbytes)()
        d2 = (ctypes.c_ubyte * nbytes)()
        d3 = (ctypes.c_ubyte * nbytes)()
        lengths = _bit_lengths(rate_bits)
        ok = 0
        first_bad = None
        for bits in lengths:
            for dd in (d1, d2, d3):
                ctypes.memset(dd, 0xAA, nbytes)
            r1 = ours(dbits, buf, bits, d1)
            r2 = ref(dbits, buf, bits, d2)
            r3 = opt(dbits, buf, bits, d3)
            same = (r1 == r2 == r3 and
                    (r1 != 0 or (bytes(d1) == bytes(d2) == bytes(d3))))
            if same:
                ok += 1
            elif first_bad is None:
                first_bad = (bits, r1, r2, r3)
        neg = 0
        negtot = 0
        for args in ((dbits, None, 0, d1), (dbits, None, 8, d1),
                     (dbits, buf, 0, None), (0, buf, 8, d1),
                     (dbits ^ 0x800, buf, 8, d1), (-1, buf, 8, d1)):
            negtot += 1
            try:
                a = ours(*args)
            except Exception:                                  # noqa: BLE001
                a = "exc"
            try:
                b = ref(*args)
            except Exception:                              # noqa: BLE001
                b = "exc"
            if a == b:
                neg += 1
        rows.append((inst, ok, len(lengths), first_bad, neg, negtot))
    return rows


# ---------------------------------------------------------------- 门 3
def gate3():
    rows = []
    for inst, sub, ourso, _db, _rb in TARGETS:
        recs, files = kat_gate.find_kat("hash-12", inst)
        so = os.path.join(OUT, ourso)
        checked, match, first_bad, err = kat_gate.check(so, recs)
        rows.append((inst, checked, match, first_bad, err,
                     os.path.basename(files[0]) if files else "-"))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rounds", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20261105)
    a = ap.parse_args()
    rnd = random.Random(a.seed)

    print("== 门 0 .jir 语义（ir_eval 跑向量版 JIR vs 源码直译标量模型） ==")
    g0o, g0t, g0bad = gate0(max(20, a.rounds // 4), rnd)
    print("   iphe_perm_vec.jir  %4d/%-4d %s%s"
          % (g0o, g0t, "PASS" if g0o == g0t else "FAIL",
             "" if g0bad is None else "  首个不一致: " + g0bad))

    print("== 门 1 核心置换（随机状态，逐 lane 逐字） ==")
    g1 = gate1(a.rounds, rnd)
    for inst, ok, tot, bad in g1:
        print("   %-10s %4d/%-4d %s%s"
              % (inst, ok, tot, "PASS" if ok == tot else "FAIL",
                 "" if bad is None else "  首个不一致: " + bad))

    print("== 门 2 整条 CryptHash vs 官方 ref.so 与 opt.so（逐字节） ==")
    g2 = gate2(rnd)
    for inst, ok, tot, bad, neg, negtot in g2:
        print("   %-10s %5d/%-5d %s   错误入参 %d/%d%s"
              % (inst, ok, tot, "PASS" if ok == tot else "FAIL", neg, negtot,
                 "" if bad is None else "  首个不一致: %s" % (bad,)))

    print("== 门 3 KAT（kat_gate，40 条上限内） ==")
    g3 = gate3()
    for inst, checked, match, bad, err, fn in g3:
        print("   %-10s %3d/%-3d %s   %s%s"
              % (inst, match, checked,
                 "PASS" if (err is None and checked == match and checked > 0)
                 else "FAIL", fn,
                 "" if bad is None else "  首个不一致: %s" % (bad,)))
        if err:
            print("      错误: %s" % err)

    ok = (g0o == g0t
          and all(o == t for _i, o, t, _b in g1)
          and all(o == t and n == nt for _i, o, t, _b, n, nt in g2)
          and all(e is None and c == m and c > 0 for _i, c, m, _b, e, _f in g3))
    print("== 四道门：%s ==" % ("全部通过" if ok else "有失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
