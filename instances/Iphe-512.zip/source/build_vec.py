#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_vec.py — 把「官方外壳 + jasmin 生成的 u256 核心置换」拼成 .so（三个实例）。

口径与 `_overnight/l0/iphe/build_ours.py` **完全一致**（那是标量版的交付件）：
外壳逐字照抄官方 opt 源 `Optimized_Implementation/Iphe-<bits>/CryptHash_AlgorithmInstance.c`，
只把 `CryptHash_AlgorithmInstance_permutation` 的函数体换成一行 `iphe_perm_vec(x);`。
三块与核心绑定的死代码（`C[26]` 常量表、`GM_DST[5][16]` 出口表、
`rotl64/sum2/red4/.../round_g32` 辅助函数族）必须切干净：留着会在
`-Wall -Wextra` 下报 `-Wunused-*`，而本脚本把**任何 stderr 输出**都当失败。

本文件是独立实现（不 import `iphe/build_ours.py`），因为那条路径会改
`_overnight/l0/iphe/` 的产物；这里只写 `iphe_vec/`。

流水线：
  gen_iphe_vec.py（模型自校验）→ out/iphe_perm_vec.jir
  → ir_text.to_jasmin → out/iphe_perm_vec.jazz → jasminc → out/iphe_perm_vec.s
  → gcc -c → out/iphe_perm_vec.o
  → gcc <官方 OPT flags> shell.c perm.o -o out/ours_vec_iphe<bits>.so

用法：
  python3 build_vec.py            # 生成外壳 + 三个 .so
  python3 build_vec.py --check    # 额外打印导出符号与 .s 的指令统计
  python3 build_vec.py --diff     # 打印 shells vs 官方源的 diff 摘要
"""
from __future__ import annotations

import argparse
import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
SRCROOT = os.path.join(WORK, "_overnight", "l0", "src", "hash-12", "Iphe",
                       "Implementations", "Optimized_Implementation")
OUT = os.path.join(HERE, "out")
LOGS = os.path.join(HERE, "logs")

INSTS = (1024, 768, 512)

# 官方 OPT flag，逐字（与 _overnight/l0/BRIEF.md §2、iphe/build_ours.py 相同）
FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

PERM_SIG = "void CryptHash_AlgorithmInstance_permutation(word_t x[32])"
CALL = "iphe_perm_vec"


def inst_src(bits: int) -> str:
    return os.path.join(SRCROOT, "Iphe-%d" % bits, "CryptHash_AlgorithmInstance.c")


# ------------------------------------------------------------------ 文本手术
def _cut(text: str, start: str, end: str) -> str:
    i = text.index(start)
    j = text.index(end, i)
    return text[:i] + text[j:]


def _func_end(text: str, sig: str) -> int:
    i = text.index(sig)
    b = text.index("{", i)
    depth = 0
    for k in range(b, len(text)):
        c = text[k]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return k + 1
    raise AssertionError("花括号不配平: " + sig)


def patch(text: str) -> str:
    """官方源 → 外壳（只换核心置换）。断言与标量版逐条相同。"""
    head_end = text.index("static const word_t C[26] = {")
    tail_start = text.index("static int get_message_bit(")
    head, mid, tail = text[:head_end], text[head_end:tail_start], text[tail_start:]

    body = mid[mid.index("static const unsigned char REV8[256] = {"):]
    body = _cut(body, "static inline word_t rotl64(word_t x, unsigned n)",
                PERM_SIG)

    i = body.index(PERM_SIG)
    j = _func_end(body, PERM_SIG)
    body = (body[:i]
            + "/* 核心置换：JIR 工具链生成（u256 向量化），见 %s */\n"
              "void %s(word_t *x);\n\n" % (CALL, CALL)
            + PERM_SIG + "\n{\n"
              "    %s(x);\n"
              "}\n" % CALL
            + body[j:])

    out = head + body + tail
    assert out[:head_end] == text[:head_end], "头部不通"
    assert out[-len(tail):] == text[tail_start:], "CryptHash 尾部被改动"
    assert out.count("typedef uint64_t word_t;") == 1, "文件头重复"
    for must in ("rate_bits = 2048U - ((unsigned)digest_len_bits + 64U);",
                 "state[rate_words + i] ^= feed_forward[i];",
                 "store64_le(digest + 8U * i, state[rate_words + i]);",
                 "padding_blocks = remaining_bits > rate_bits - 2U ? 2U : 1U;"):
        assert must in out, "外壳关键行丢了: " + must
    for gone in ("round_g2", "red32", "GM_DST", "wr_wp", "rotl64"):
        assert gone not in out, "死代码没切干净: " + gone
    return out


# ------------------------------------------------------------------ 子进程
def sh(args, log_path, what, stderr_must_be_clean=True):
    """跑命令：stdout、stderr 分别落盘（不用 PIPE）。

    编译器/汇编器这一步要求 stderr 完全为空（warning 也算失败）；
    python 脚本那一步 stdout 是正常输出，只认 returncode。
    """
    os.makedirs(LOGS, exist_ok=True)
    err_path = log_path + ".err"
    with open(log_path, "w", encoding="utf-8") as fo, \
            open(err_path, "w", encoding="utf-8") as fe:
        p = subprocess.run(args, stdout=fo, stderr=fe)
    blob = ""
    with open(err_path, encoding="utf-8", errors="replace") as f:
        blob = f.read()
    if p.returncode != 0 or (stderr_must_be_clean and blob.strip()):
        print("失败（%s，returncode=%d）：" % (what, p.returncode))
        if blob.strip():
            print(blob.strip()[:4000])
        raise SystemExit(1)
    return blob


# ------------------------------------------------------------------ 构建
def build_perm_asm():
    """jir → jazz（to_jasmin）→ s（jasminc）→ o（gcc -c）。"""
    log = os.path.join(LOGS, "emit.log")
    sh([sys.executable, os.path.join(HERE, "emit_vec.py")], log, "emit",
       stderr_must_be_clean=False)
    jazz = os.path.join(OUT, "iphe_perm_vec.jazz")
    s_path = os.path.join(OUT, "iphe_perm_vec.s")
    sh(["jasminc", "-o", s_path, jazz],
       os.path.join(LOGS, "jasminc.log"), "jasminc")
    o_path = os.path.join(OUT, "iphe_perm_vec.o")
    sh(["gcc", "-c", "-o", o_path, s_path],
       os.path.join(LOGS, "asm_gcc.log"), "gcc -c")
    return o_path


def build(bits: int, perm_o: str) -> str:
    src = inst_src(bits)
    inc = os.path.dirname(src)
    with open(src, encoding="utf-8") as f:
        shell = patch(f.read())
    os.makedirs(OUT, exist_ok=True)
    shell_c = os.path.join(OUT, "iphe_shell_vec_%d.c" % bits)
    with open(shell_c, "w", encoding="utf-8", newline="\n") as f:
        f.write(shell)
    so = os.path.join(OUT, "ours_vec_iphe%d.so" % bits)
    cmd = (["gcc"] + FLAGS + ["-fPIC", "-shared", "-I", inc,
                              shell_c, perm_o, "-o", so])
    sh(cmd, os.path.join(LOGS, "cc_%d.log" % bits), "编译 %d" % bits)
    return so


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--diff", action="store_true")
    a = ap.parse_args()

    perm_o = build_perm_asm()
    sos = [build(b, perm_o) for b in INSTS]
    for so in sos:
        print("OK  %-24s %7d 字节  sha256=%s"
              % (os.path.basename(so), os.path.getsize(so), sha256(so)))

    if a.diff:
        for b in INSTS:
            with open(inst_src(b), encoding="utf-8") as f:
                off = f.read()
            with open(os.path.join(OUT, "iphe_shell_vec_%d.c" % b),
                      encoding="utf-8") as f:
                mine = f.read()
            d = _diff_lines(off, mine)
            add = sum(1 for l in d if l.startswith("+"))
            rem = sum(1 for l in d if l.startswith("-"))
            print("shell %d：官方 %d 行 → 我们 %d 行（+%d / -%d）"
                  % (b, off.count("\n"), mine.count("\n"), add, rem))
            with open(os.path.join(LOGS, "diff_%d.txt" % b), "w",
                      encoding="utf-8") as f:
                f.write("\n".join(d))

    if a.check:
        for so in sos:
            with open(os.path.join(LOGS, "nm_%s.log" % os.path.basename(so)),
                      "w", encoding="utf-8") as f:
                subprocess.run(["nm", "-D", "--defined-only", so], stdout=f,
                               stderr=subprocess.STDOUT)
        s_path = os.path.join(OUT, "iphe_perm_vec.s")
        with open(s_path, encoding="utf-8") as f:
            lines = [l.strip() for l in f if l.strip()]
        ins = [l.split()[0] for l in lines if not l.endswith(":")]
        from collections import Counter
        c = Counter(ins)
        print("汇编：%d 行、%d 条指令；前 12 类：%s"
              % (len(lines), len(ins), c.most_common(12)))
    return 0


def _diff_lines(a: str, b: str):
    import difflib
    return [l for l in difflib.unified_diff(a.splitlines(), b.splitlines(),
                                            lineterm="", n=0)
            if l[:1] in "+-" and not l.startswith(("+++", "---"))]


if __name__ == "__main__":
    sys.exit(main())
