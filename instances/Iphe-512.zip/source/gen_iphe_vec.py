#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_iphe_vec.py — Iphe(hash-12) 核心置换的 u256 向量化生成器。

状态 32 个 u64 = 8 条 ymm。约定：子轮开始时 V_m 持有 nat[4m .. 4m+3]。

每个子轮 g = 2/4/8/16/32 分成六步，全部在 8 条寄存器上原地做：

  1) 注入  只有「组首 lane」抬常量：xor 一张 4 值常量向量（其余 lane 填 0）
  2) 归约  组内和 s：red4 用 permq(0xB1)+add、permq(0xEE)+xor 把 s 广播到 4 lane，
           更大的 g 就按官方递归树（add/xor 交替）把若干条 s 向量再合一次
  3) 混合  G = s + (s <<< (k+1))（vshl 逐 lane 变长移位），
           p = x + G、q = x ^ G，blendd 选出「组内偏移 0 走 add、其余走 xor」
  4) 出口  组出口 l = block_perm(j, g)：所有 g 下都恰好是整条/整对寄存器搬家，
           所以这一步退化成寄存器改名（g=2 时最多 1 条 permq、1 条半区交换）
  5) 旋转  vrot 逐 lane 变长旋转（(7j%32)+16，32 个量互不相同，只能逐 lane）
  6) 洗牌  x[j//2 + (j%2)*16] = y[j]：每两条向量 unpacklo/hi 出低/高半，
           再 permq(0xD8) 归位 —— 8 条输出向量固定 16 条指令

生成器**同时**发射「文本」和「逐 lane 的 AVX2 语义模型」：每条发射的指令都
在 Python 里按 ir_eval 的语义算一遍（permq 立即数、blendd 掩码、unpack 的
128 位半语义、vshl/vrot 的逐 lane 量……），跑完与 gen_iphe.model_perm
（官方 ref 源码逐行直译）比。不一致就在**生成阶段**报错，不用等 jasmin。

用法：
  python3 gen_iphe_vec.py --check        # 只做模型自校验（快）
  python3 gen_iphe_vec.py --emit         # 写 out/iphe_perm_vec.jir + 统计
"""
from __future__ import annotations

import argparse
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
L0 = os.path.join(WORK, "_overnight", "l0")
IPHE = os.path.join(L0, "iphe")
OUT = os.path.join(HERE, "out")
sys.path.insert(0, WORK)
sys.path.insert(0, IPHE)

import gen_iphe as G  # noqa: E402

LANES = 32
MASK = (1 << 64) - 1
C = G.C
block_perm = G.block_perm
reduce_op = G.reduce_op
model_perm = G.model_perm
OUTER_ROUNDS = 5
SUB_TYPES = 5

ENTRY = "iphe_perm_vec"

# permq 立即数：每 2 位一个源 lane
PQ_SWAP2 = [1, 0, 3, 2]          # 相邻对调（0xB1）
PQ_BCAST2 = [2, 3, 0, 1]         # 128 位半对调（0x4E）：把高半的 (x2+x3) 换到低半
PQ_LO2HI = [0, 2, 1, 3]          # unpacklo 之后归位（0xD8）


# ---------------------------------------------------------------- 发射 + 模型
class Emit:
    """一边写 .jir 文本，一边按 AVX2 语义把每条指令算出来。"""

    def __init__(self):
        self.body = []
        self.consts = []          # [(name, [v0..v3])]
        self.vals = {}            # 名字 -> (v0, v1, v2, v3)
        self.n = 0

    # -- 基础设施 ---------------------------------------------------------
    def fresh(self, tag):
        self.n += 1
        return "t%04d_%s" % (self.n, tag)

    def emit(self, expr, tag, v4):
        d = self.fresh(tag)
        self.body.append("  %s = %s" % (d, expr))
        self.vals[d] = tuple(v4)
        return d

    def stmt(self, text):
        self.body.append("  " + text)

    def defconst(self, name, v4):
        self.consts.append((name, list(v4)))
        self.vals[name] = tuple(v4)
        return name

    # -- 算子 -------------------------------------------------------------
    def _bin(self, op, a, b, tag):
        va, vb = self.vals[a], self.vals[b]
        if op == "xor":
            v = [x ^ y for x, y in zip(va, vb)]
        elif op == "add":
            v = [(x + y) & MASK for x, y in zip(va, vb)]
        else:
            raise ValueError(op)
        return self.emit("%s(%s, %s)" % (op, a, b), tag, v)

    def xor2(self, a, b, tag="x"):
        return self._bin("xor", a, b, tag)

    def add2(self, a, b, tag="a"):
        return self._bin("add", a, b, tag)

    def permq(self, a, perm, tag="pq"):
        imm = 0
        for i, p in enumerate(perm):
            imm |= (p & 3) << (2 * i)
        return self.emit("permq(%s, 0x%02x)" % (a, imm), tag,
                         [self.vals[a][p & 3] for p in perm])

    def unpack(self, lh, a, b, tag="up"):
        xa, xb = self.vals[a], self.vals[b]
        if lh == "lo":
            v = [xa[0], xb[0], xa[2], xb[2]]
        else:
            v = [xa[1], xb[1], xa[3], xb[3]]
        return self.emit("unpack%s(%s, %s)" % (lh, a, b), tag, v)

    def blend(self, a, b, mask4, tag="bl"):
        """mask4 的 bit i 置位 → 取 b 的 lane i（blendd 的 32 位掩码成对拼）。"""
        imm = 0
        for i in range(4):
            if (mask4 >> i) & 1:
                imm |= 3 << (2 * i)
        v = [self.vals[b][i] if (mask4 >> i) & 1 else self.vals[a][i]
             for i in range(4)]
        return self.emit("blendd(%s, %s, 0x%02x)" % (a, b, imm), tag, v)

    def vshl(self, a, kv, tag="vsl"):
        v = [(x << k) & MASK for x, k in zip(self.vals[a], kv)]
        return self.emit("vshl(%s, %s)" % (a, ", ".join(str(k) for k in kv)),
                         tag, v)

    def vrot(self, a, kv, tag="vrt"):
        """vrot(x, kv) = 逐 lane 循环**右**移 kv[i]（见 opt_ir._expand_vrot）。"""
        v = []
        for x, k in zip(self.vals[a], kv):
            k %= 64
            v.append(x if k == 0 else ((x >> k) | (x << (64 - k))) & MASK)
        return self.emit("vrot(%s, %s)" % (a, ", ".join(str(k) for k in kv)),
                         tag, v)

    def vrotl(self, a, kv, tag="rot"):
        """逐 lane 循环**左**移 kv[i]，显式写成 xor(vshl, vshr) 三条。

        与 `vrot` 的区别：不依赖 `ir_text._expand_vrot` 的展开，也不依赖
        `or` 的发射（两半位段不相交，xor 与 or 等价）。kv 取 17..48，
        所以 `64 - kv` 取 16..47 —— 两个移位量都不为 0/64，避开“移 64 位”
        这个在 x86 上按 &63 变成恒等的边界。
        """
        xs = self.vals[a]
        lo = self.emit("vshl(%s, %s)" % (a, ", ".join(str(k) for k in kv)), tag,
                       [(x << k) & MASK for x, k in zip(xs, kv)])
        hi = self.emit("vshr(%s, %s)" % (a, ", ".join(str(64 - k) for k in kv)),
                       tag, [x >> (64 - k) for x, k in zip(xs, kv)])
        return self.emit("xor(%s, %s)" % (lo, hi), tag,
                         [((x << k) | (x >> (64 - k))) & MASK
                          for x, k in zip(xs, kv)])

    def load(self, base, off, name, v4):
        self.body.append("  %s:u256 = ld(%s + %d)" % (name, base, off))
        self.vals[name] = tuple(v4)
        return name

    def store(self, base, off, a):
        self.stmt("st(%s + %d, %s)" % (base, off, a))


def _tree(e, blk, n, tag):
    """官方组内递归归约：n 个 4-lane 向量 → 一条 s 向量（逐 lane 相同）。"""
    if len(blk) == 1:
        return blk[0]
    h = len(blk) // 2
    a = _tree(e, blk[:h], n // 2, tag)
    b = _tree(e, blk[h:], n // 2, tag)
    return e._bin("xor" if reduce_op(n) == "xor" else "add", a, b, tag)


def _red4_bcast(e, v, tag):
    """red4（n=4 的组内和）并广播到 4 个 lane：(x0+x1) ^ (x2+x3)。"""
    u = e.add2(v, e.permq(v, PQ_SWAP2, tag), tag)
    return e.xor2(u, e.permq(u, PQ_BCAST2, tag), tag)


def align_blocks(e, sv, g, inv, tag):
    """把组内和 s 从**入口块**布局搬到**出口块**布局。

    官方混合是 `y[l+k] = f(x[l+k], s_j)`（l = 出口块首、j = 入口块首），
    读的 x 在 l+k 处 —— 也就是说混合是逐位置直角的，只有 s 需要换位：
    `s'[p] = s_j`，j = inv[p - p%g]。

    s 在每个块内恒定 ⇒ 这是「g 块」的置换：
      * g >= 4 时每个块正好是整条（g=4）或若干整条向量 ⇒ 纯寄存器改名，零指令；
      * g == 2 时每对块是 128 位单元，两 lane 恒等 ⇒ 用 perm2i128 搬半区。
    """
    out = []
    if g >= 4:
        for m in range(8):
            j = 4 * m - (4 * m) % g
            out.append(sv[inv[j] // 4])
        return out

    assert g == 2
    for m in range(8):
        units = (2 * m, 2 * m + 1)                 # 出口 128 位单元号 = 出口对号
        regs = [inv[2 * u] // 4 for u in units]
        hs = [(inv[2 * u] // 2) % 2 for u in units]
        assert regs[0] == regs[1], "g=2 的 s 对齐应落在同一条源向量"
        if hs == [0, 1]:
            out.append(sv[regs[0]])                # 半区顺序本来就对 → 改名
            continue
        src = sv[regs[0]]
        halves = [e.vals[src][0:2], e.vals[src][2:4]]
        v4 = list(halves[hs[0]]) + list(halves[hs[1]])
        imm = hs[0] | (hs[1] << 4)
        out.append(e.emit("perm2i128(%s, %s, 0x%02x)" % (src, src, imm), tag, v4))
    return out


def regather(e, vecs, target, tag):
    """把 8 条向量按 target 重排；target[p] = 4 个 (源下标, 源内 lane)。

    每一步只做「一源 permq」或「permq + blendd」，源相同且顺序不变时零指令。
    """
    assert len(target) == 8 and all(len(t) == 4 for t in target)
    out = []
    for lanes in target:
        groups = {}
        for slot, (si, pos) in enumerate(lanes):
            groups.setdefault(si, []).append((slot, pos))
        srcs = sorted(groups)
        res = None
        for si in srcs:
            perm = [0, 0, 0, 0]
            for slot, pos in groups[si]:
                perm[slot] = pos
            if len(srcs) == 1 and perm == [0, 1, 2, 3]:
                res = vecs[si]                      # 纯改名，零指令
                continue
            d = e.permq(vecs[si], perm, tag)
            if res is None:
                res = d
            else:
                m = 0
                for slot, _pos in groups[si]:
                    m |= 1 << slot
                res = e.blend(res, d, m, tag)
        out.append(res)
    return out


def _flat(e, names):
    """把 8 条寄存器的模型值摊成 32 个自然序 lane。"""
    out = []
    for nm in names:
        out.extend(e.vals[nm])
    return out


def subround(e, cur, i, r, trace=None):
    """一个子轮：cur 是 8 条寄存器名（V_m = nat[4m..4m+3]），返回新的 8 条。

    trace 传入 dict 时，按阶段把模型值快照放进去（调试用）。
    """
    g = 2 << i
    rc = C[16 + i] ^ C[21 + r]

    # ---- 1) 组首 lane 注入常量
    cur = list(cur)
    for m in range(8):
        v4 = []
        for t in range(4):
            j = 4 * m + t
            v4.append((C[j // g] ^ rc) if j % g == 0 else 0)
        if any(v4):
            cur[m] = e.xor2(cur[m], "K%d_%d_%d" % (i, r, m), "inj")

    if trace is not None:
        trace["inj"] = _flat(e, cur)

    # ---- 2) 组内归约 → 每条向量一份 s（入口块布局：g=2 时两两交错，g>=4 时整条恒定）
    if g == 2:
        s = [e.add2(cur[m], e.permq(cur[m], PQ_SWAP2, "red"), "red")
             for m in range(8)]
    elif g == 4:
        s = [_red4_bcast(e, cur[m], "red") for m in range(8)]
    else:
        r4 = [_red4_bcast(e, cur[m], "red4") for m in range(8)]
        nv = g // 4                      # 每组几条向量
        sg = [_tree(e, r4[q * nv:(q + 1) * nv], g, "red%d" % g)
              for q in range(32 // g)]
        s = [sg[m // nv] for m in range(8)]

    # ---- 2b) s 从入口块布局搬到出口块布局（混合读的是 x[l+k]，l 是出口块首）
    bp = {j0: block_perm(j0, g) for j0 in range(0, LANES, g)}
    inv = {v: k for k, v in bp.items()}
    assert len(inv) == len(bp), "组出口置换不是双射"
    s = align_blocks(e, s, g, inv, "srb")

    # ---- 3) 混合：G = s + (s << (k+1))，块内偏移 0 走 add、其余走 xor
    y = []
    for m in range(8):
        off = [(4 * m + t) % g for t in range(4)]
        Gv = e.add2(s[m], e.vshl(s[m], [o + 1 for o in off], "mix"), "mix")
        if 0 in off:
            p = e.add2(cur[m], Gv, "mix")
            q = e.xor2(cur[m], Gv, "mix")
            msk = sum(1 << t for t in range(4) if off[t] != 0)
            y.append(e.blend(p, q, msk, "mix"))
        else:
            y.append(e.xor2(cur[m], Gv, "mix"))

    # ---- 4) 逐 lane 旋转 rotl((7j%32)+16) ⇒ xor(vshl(.,n), vshr(.,64-n))
    rot = [e.vrotl(y[p], [((7 * (4 * p + t) % 32) + 16) for t in range(4)],
                  "rot") for p in range(8)]

    # ---- 5) 洗牌 x[j//2 + (j%2)*16] = y[j]
    nx = [None] * 8
    for p in range(4):
        a, b = rot[2 * p], rot[2 * p + 1]
        nx[p] = e.permq(e.unpack("lo", a, b, "shf"), PQ_LO2HI, "shf")
        nx[p + 4] = e.permq(e.unpack("hi", a, b, "shf"), PQ_LO2HI, "shf")
    return nx


def generate(x0, stop_after=None):
    """生成整条置换的 .jir 文本；x0 = 32 个 u64（模型用）。

    stop_after=k 时只生成前 k 个子轮（调试/对拍用：二分"文本对但 .so 错"的
    位置）。k 为 None = 完整 25 个子轮。
    """
    e = Emit()
    for i in range(SUB_TYPES):
        g = 2 << i
        for r in range(OUTER_ROUNDS):
            rc = C[16 + i] ^ C[21 + r]
            for m in range(8):
                v4 = []
                for t in range(4):
                    j = 4 * m + t
                    v4.append((C[j // g] ^ rc) if j % g == 0 else 0)
                if any(v4):
                    e.defconst("K%d_%d_%d" % (i, r, m), v4)

    cur = [e.load("p", 32 * m, "R%d" % m, x0[4 * m:4 * m + 4])
           for m in range(8)]
    done = 0
    for r in range(OUTER_ROUNDS):
        for i in range(SUB_TYPES):
            if stop_after is not None and done >= stop_after:
                break
            cur = subround(e, cur, i, r)
            done += 1
        if stop_after is not None and done >= stop_after:
            break
    for m in range(8):
        e.store("p", 32 * m, cur[m])

    head = ["const %s:u256 = 0x%s" % (nm, "".join("%016x" % v for v in reversed(v4)))
            for nm, v4 in e.consts]
    text = "\n".join(head + ["", "entry %s(p: u64)" % ENTRY] + e.body) + "\n"
    got = []
    for m in range(8):
        got.extend(e.vals[cur[m]])
    return text, got, e


def generate_nomodel(nregs_hint=None):
    """只为拿文本（模型用 0 输入也行，但这里给固定随机种子保证可复现统计）。"""
    rnd = random.Random(20261105)
    return generate([rnd.getrandbits(64) for _ in range(LANES)])[0]


# ---------------------------------------------------------------- 自校验
def check(rounds=200, seed=20261106):
    rnd = random.Random(seed)
    bad = 0
    e0 = None
    for t in range(rounds):
        x = [rnd.getrandbits(64) for _ in range(LANES)]
        _text, got, e = generate(x)
        e0 = e
        want = model_perm(x)
        if got != want:
            bad += 1
            if bad == 1:
                d = [i for i in range(LANES) if got[i] != want[i]]
                print("第一组不一致：lane %s" % d[:8])
                print("  got  %016x" % got[d[0]])
                print("  want %016x" % want[d[0]])
    print("模型自校验：%d/%d 组与 gen_iphe.model_perm 逐 lane 相同" %
          (rounds - bad, rounds))
    return 0 if bad == 0 else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--emit", action="store_true")
    ap.add_argument("--rounds", type=int, default=200)
    a = ap.parse_args()
    if not (a.check or a.emit):
        a.check = a.emit = True
    rc = 0
    if a.check:
        rc |= check(a.rounds)
    if a.emit:
        text, got, e = generate([0] * LANES)
        os.makedirs(OUT, exist_ok=True)
        path = os.path.join(OUT, "iphe_perm_vec.jir")
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        n_op = sum(1 for ln in e.body if "=" in ln.split(":")[0] or "= " in ln)
        print("已写出 %s：%d 行、%d 条常量向量、%d 条指令语句"
              % (os.path.basename(path), text.count("\n"), len(e.consts),
                 len(e.body)))
    return rc


if __name__ == "__main__":
    sys.exit(main())
