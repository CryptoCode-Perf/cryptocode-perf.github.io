# Iphe-512

Algorithm: Iphe | Digest bits: 512 | Form: u256 向量（AVX2）

Contents: implementation source/, public header Iphe-512.h, prebuilt Iphe-512.so,
KAT vector KAT_2_12_Iphe-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 0acaea1a216fba3d46e8768d2bdab70020752433dd3dc709a48f623f96a0b867
Speed (cpB, lower is faster): reference 27.44 / official-optimized 7.00 / optimized 6.68
Speedup: GM(S1-S8) 1.05x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
