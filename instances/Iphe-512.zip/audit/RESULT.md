# Iphe-512 CAP website pilot

The source was selected from CAP task `iphe512-dsh-effort-low-fresh-v1` (candidate_10). 1024 B, three serial 101-sample runs: OPT/CAP geometric mean 1.720404; prior website/CAP geometric mean 1.601253. Eight-length OPT/CAP geometric mean 1.934855.

The displayed per-byte numbers are TSC ticks/B, not hardware core cycles. Hardware core CPB was unavailable. Full short and long KAT and 8,329 differential cases passed; the rebuilt website source also matched its published binary over those differential cases. This does not prove constant-time or cryptographic security.
