# Iphe — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| Iphe-512 | `Iphe-512.so` | 42072 B | `0acaea1a216fba3d46e8768d2bdab70020752433dd3dc709a48f623f96a0b867` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| Iphe-512 | 512 | 27.4424 | 6.9951 | 6.6817 | 1.0469 | 1.0509 |

## 优化方法（逐实例原文，来自交付清单）

### Iphe-512
把 32×64 位状态装进 8 条 ymm，只替换 `CryptHash_AlgorithmInstance_permutation`，外壳逐字移植官方实现（346 行 → 157 行，切掉 C[26]/GM_DST/round_g/red/rotl64）。逐 lane 旋转量各不相同，无法用 vprolq 立即数，改用 vpsllvq/vpsrlvq + vpxor 合成（每子轮 8 条向量运算）；组内平衡树归约与入口→出口块布局搬运用 permq/perm2i128/blendd。IR 2771 条、峰值寄存器 16/16、溢出 1 槽，汇编 2821 条真实指令。构建走官方十 flag 逐字，纯 AVX2（`objdump -d` 里 rorx/andn/shlx/vaesenc 全为 0）。同族的 rorx 版虽快约 9%（0.9119/0.9137/0.9391）但含 160 条 BMI2 `rorx`、超出 AVX2 口径，按站点「诚实边界」那条规矩**主动撤掉不用**。
