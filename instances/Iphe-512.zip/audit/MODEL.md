# Iphe — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Iphe-512
- 摘要位：512；实现形态：u256 向量（AVX2）
- 官方参考源码：随包 `Reference_Implementation/Iphe-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Iphe-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Iphe-512/`
- 优化要点：把 32×64 位状态装进 8 条 ymm，只替换 `CryptHash_AlgorithmInstance_permutation`，外壳逐字移植官方实现（346 行 → 157 行，切掉 C[26]/GM_DST/round_g/red/rotl64）。逐 lane 旋转量各不相同，无法用 vprolq 立即数，改用 vpsllvq/vpsrlvq + vpxor 合成（每子轮 8 条向量运算）；组内平衡树归约与入口→出口块布局搬运用 permq/perm2i128/blendd。IR 2771 条、峰值寄存器 16/16、溢出 1 槽，汇编 2821 条真实指令。构建走官方十 flag 逐字，纯 AVX2（`objdump -d` 里 rorx/andn/shlx/vaesenc 全为 0）。同族的 rorx 版虽快约 9%（0.9119/0.9137/0.9391）但含 160 条
