# Eijen-512

Algorithm: Eijen | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header Eijen-512.h, prebuilt Eijen-512.so,
KAT vector KAT_2_12_Eijen-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 420eac1809d93022e405888a3b6c44f967704ab226b2bcade9cc6de0275f7777
Speed (cpB, lower is faster): reference 6.15 / official-optimized 2.57 / optimized 2.41
Speedup: GM(S1-S8) 1.07x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
