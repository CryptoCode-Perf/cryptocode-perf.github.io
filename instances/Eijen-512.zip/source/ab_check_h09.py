#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Eijen v3（sigma blend，第 5 例）的三道等价门。

与 h14 的 `laurus512/ab_check512.py` 同结构，对象不同：
  A1  全量 KAT 4097 条：官方 ref 必须全过（阳性对照），cand 必须全过，
      且 cand 与 base 逐条同结论。
  A2  位长扫描 0..1023：cand 与 base 逐条相同。
  A3  负对照：把一个字节扰动过的 cand 拿去比，必须变色（证明 A2 在判定）。

kat_gate 的真实 API 是 parse_kat(path) / check(lib, recs) / check_aligned(lib, recs)，
没有 parse_all / run_one。且 check() 内部受 MAX_RECORDS=40 截断，全量比对必须
先把 MAX_RECORDS 抬上去 —— 否则「4097/4097」实际只是 40/40，是假读数。

用法:
  python3 ab_check_h09.py
  python3 ab_check_h09.py --skip-negctl
"""
import argparse
import ctypes
import hashlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))

sys.path.insert(0, L0)
import kat_gate as KG  # noqa: E402

BASE = os.path.join(WORK, "_std", "out", "so", "libh09_opt.so")
REF = os.path.join(WORK, "_std", "out", "so", "libh09_ref.so")
CAND = os.path.join(HERE, "out_blend", "ours_eijen2_512.so")
KAT = os.path.join(L0, "src", "hash-09", "Eijen", "Test_Vectors",
                   "KAT_2_12_Eijen-512.txt")


def sha16(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 16), b""):
            h.update(b)
    return h.hexdigest()[:16]


def digest(lib, msg, bits):
    """直接调 CryptHash，返回 (rc, digest_hex)。"""
    dll = ctypes.CDLL(os.path.abspath(lib))
    fn = getattr(dll, "CryptHash", None)
    if fn is None:
        raise RuntimeError("no CryptHash in %s" % lib)
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_ulonglong,
                   ctypes.c_char_p]
    dl = 64
    buf = ctypes.create_string_buffer(dl + 16)
    rc = fn(dl * 8, msg, ctypes.c_ulonglong(bits), buf)
    return rc, buf.raw[:dl].hex()


def digest_forked(lib, msg, bits):
    """在子进程里取一次摘要：扰动过的 .so 会 SIGILL/SIGSEGV，
    直接在本进程调会把整个判据装置打死（实测 A3 就是这样崩的）。
    子进程崩掉返回 None，由调用方记成「变色」。"""
    rfd, wfd = os.pipe()
    pid = os.fork()
    if pid == 0:                                  # child
        os.close(rfd)
        try:
            res = digest(lib, msg, bits)
        except BaseException:                     # noqa: BLE001
            res = None
        try:
            with os.fdopen(wfd, "wb") as fh:
                fh.write(b"" if res is None
                         else ("%d:%s" % (res[0], res[1])).encode())
        finally:
            os._exit(0)
    os.close(wfd)
    with os.fdopen(rfd, "rb") as fh:
        data = fh.read()
    os.waitpid(pid, 0)
    if not data:
        return None
    rc, h = data.decode().split(":", 1)
    return int(rc), h


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-negctl", action="store_true")
    ap.add_argument("--sweep", type=int, default=1024)
    a = ap.parse_args()

    for p in (BASE, CAND, REF, KAT):
        if not os.path.exists(p):
            print("FATAL: 缺文件 %s" % p)
            return 2

    print("=== 输入")
    for p in (REF, BASE, CAND):
        print("  %-22s %8d B  sha16 %s" % (os.path.basename(p),
                                           os.path.getsize(p), sha16(p)))
    print("  KAT  %s" % KAT)

    recs = KG.parse_kat(KAT)
    print("\n=== A1 全量 KAT（解析出 %d 条）" % len(recs))
    if len(recs) < 1000:
        print("FATAL: 只解析出 %d 条，远少于 4097 ⇒ 判据不成立，停" % len(recs))
        return 2

    # check() 内部按 MAX_RECORDS 截断；全量必须抬高，否则 4097/4097 是假读数。
    KG.MAX_RECORDS = len(recs)
    KG.MAX_MSG_BYTES = 1 << 20

    res = {}
    for tag, lib in (("ref", REF), ("base", BASE), ("cand", CAND)):
        n, m, first, err = KG.check(lib, recs)
        res[tag] = (n, m, first, err)
        print("  %-6s %d/%d  first_bad=%s  err=%s" % (tag, m, n, first, err))

    ok_a1a = res["ref"][0] > 0 and res["ref"][0] == res["ref"][1]
    ok_a1b = res["cand"][0] > 0 and res["cand"][0] == res["cand"][1]
    ok_a1c = (res["base"][0] == res["cand"][0]
              and res["base"][2] == res["cand"][2])
    print("  A1a ref 全过            : %s" % ok_a1a)
    print("  A1b cand 全过           : %s" % ok_a1b)
    print("  A1c cand 与 base 同结论 : %s" % ok_a1c)

    print("\n=== A2 位长扫描 0..%d（cand vs base 逐条相同）" % (a.sweep - 1))
    same = diff = 0
    first_diff = None
    for bits in range(a.sweep):
        nbytes = (bits + 7) // 8
        msg = bytes(((i * 37 + bits * 11) & 0xFF) for i in range(nbytes))
        rb, hb = digest(BASE, msg, bits)
        rc_, hc = digest(CAND, msg, bits)
        if rb == rc_ and hb == hc:
            same += 1
        else:
            diff += 1
            if first_diff is None:
                first_diff = {"bits": bits, "rc": (rb, rc_), "base": hb[:16],
                              "cand": hc[:16]}
    print("  same %d / %d   diff %d   first_diff=%s"
          % (same, same + diff, diff, first_diff))
    ok_a2 = (diff == 0 and same > 0)

    print("\n=== A3 负对照（扰动 cand 的一个字节，A2 必须变色）")
    ok_a3 = None
    if a.skip_negctl:
        print("  SKIPPED（--skip-negctl）：**跳过不等于通过**")
    else:
        raw = bytearray(open(CAND, "rb").read())
        # 改 .text 里的一个字节：找一个非零、且不在 ELF 头/段表附近的偏移。
        # 目的只是让它坏掉，不追求「只坏一处语义」。
        idx = raw.find(b"\x48\x8b", 4096)
        if idx < 0:
            print("  FATAL: 找不到可扰动字节 ⇒ 负对照无法进行（不是通过）")
            ok_a3 = False
        else:
            neg = os.path.join(HERE, "_neg_h09.so")
            raw[idx + 1] ^= 0xFF
            open(neg, "wb").write(raw)
            chg = 0
            for bits in range(0, 256):
                nbytes = (bits + 7) // 8
                msg = bytes(((i * 37 + bits * 11) & 0xFF) for i in range(nbytes))
                hc = digest(CAND, msg, bits)
                hn = digest_forked(neg, msg, bits)
                # 扰动件可能直接 SIGILL/SIGSEGV —— 那也算「变色」：
                # 它确实坏了，只是坏得比「算错」更彻底。
                if hn is None or hc != hn:
                    chg += 1
            print("  扰动件 vs cand：%d / 256 变色（期望 >0；崩溃计为变色）" % chg)
            ok_a3 = (chg > 0)
            try:
                os.remove(neg)
            except OSError:
                pass

    print("\n=== 判决")
    allok = ok_a1a and ok_a1b and ok_a1c and ok_a2 and (ok_a3 is not False)
    print("  A1a=%s A1b=%s A1c=%s A2=%s A3=%s"
          % (ok_a1a, ok_a1b, ok_a1c, ok_a2, ok_a3))
    print("  => %s" % ("ALL PASS" if allok else "FAIL"))
    return 0 if allok else 1


if __name__ == "__main__":
    sys.exit(main())
