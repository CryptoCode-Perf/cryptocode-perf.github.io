#include "CryptHash_AlgorithmInstance.h"
#include "eijen.h"
#include "eijen_internal.h"

#include <string.h>

const char *eijen_implementation_name(void) {
    return "Eijen x86 reference C99";
}

/* Look up the fixed parameter set for a supported digest length. */
const eijen_config *eijen_get_config(int digest_bits) {
    return eijen_config_by_bits(digest_bits);
}

/* Return the digest size in bytes, or zero for an unsupported instance. */
size_t eijen_digest_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->digest_bytes;
}

/* Return the absorbing rate in bytes, or zero for an unsupported instance. */
size_t eijen_rate_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->rate_bytes;
}

/*
 * Sigma-free round representation.
 *
 * The reference round is  M ; SIGMA ; L ; SIGMA  where SIGMA is a fixed
 * word-position permutation and L is the four-word XOR fold applied
 * independently to each of the eight columns.
 *
 * With q = SIGMA(p):
 *
 *   out[p] = in[SIGMA(q)] ^ XOR over w in column(q), w != q of in[SIGMA(w)]
 *
 * Writing W[r][c] for role r (r = 0..3) of column c (position 4*c + r),
 * one round is, for every lane k = 0..7 (index arithmetic mod 8):
 *
 *   W = MIX(W)                                       eight independent columns
 *   v0 = W[2][k+5]   v1 = W[0][k]   v2 = W[1][k+7]   v3 = W[3][k+4]
 *   q  = v0 ^ v1 ^ v2 ^ v3
 *   W'[1][k]   = q ^ v0
 *   W'[2][k+1] = q ^ v1
 *   W'[0][k+3] = q ^ v2
 *   W'[3][k+4] = q ^ v3
 *
 * This is exactly the EIJEN_G_ALL block list (sources 22,0,29,19 -> writes
 * 1,6,12,19 for lane 0).  Equivalently the outputs are lane shifts of q ^ v_r
 * by -1, -3 and -4 respectively.
 *
 * The AVX2 path keeps all 32 words live in eight YMM registers for the whole
 * permutation in a role-major layout: register (*0) holds lanes 0..3 (columns
 * 0..3) of a role, register (*1) holds lanes 4..7 (columns 4..7).  Every MIX
 * operation is lane-uniform except the two fixed rotation sets, which are
 * selected per register (columns 0..3 use 36,54,45,44,18,9 and columns 4..7
 * use 56,46,54,34,19,51).  The fold then costs three lane-shift networks: two
 * on the shifted sources (v2 = +7) and one on output role 0 (-3).
 *
 * Role 3's -4 output shift is free: its two registers are simply held in the
 * opposite column order (d1 = columns 0..3, d0 = columns 4..7), so the +4 and
 * -4 cancel and role 3 needs no shuffle at all.  Entry and exit each use one
 * 4x4 lane transpose (its own inverse) to move between the canonical
 * column-major state and this layout.
 *
 * Two further exact rewrites are applied inside the round:
 *
 *  1. Pair-sum fold.  q is never materialised.  With p = v0 ^ v2 and
 *     s = v1 ^ v3, each output is a three-term sum of the *other* sources:
 *
 *         W'[1] = s ^ v2,  W'[2] = p ^ v3,  W'[0] = s ^ v0,  W'[3] = p ^ v1
 *
 *     which is 6 XORs instead of 7 (verified exhaustively as a 4-bit Boolean
 *     layer) and one XOR level shallower than folding through q.
 *
 *  2. Pair-sum fold ordering.  Because p and s are formed first, all four
 *     outputs are two levels deep from the MIX results instead of three, and
 *     the pre-shift value t = p ^ v3 can be reused for the -1 output without
 *     ever rebuilding q.
 *
 * The 56-bit rotate is exactly a byte rotation, so it uses one vpshufb instead
 * of the three-operation shift/or sequence.  The mask is a fixed static
 * constant, not an input- or secret-dependent table.
 */

#if defined(__AVX2__)

#include <immintrin.h>

/* Rotate 64-bit lanes left by a compile-time amount. */
#define EIJEN_VROTL(X, N) \
    _mm256_or_si256(_mm256_slli_epi64((X), (N)), _mm256_srli_epi64((X), 64 - (N)))

/* 4x4 transpose of 64-bit lanes; an involution. */
#define EIJEN_TP4(X0, X1, X2, X3, Y0, Y1, Y2, Y3) do { \
    __m256i eij_t0 = _mm256_unpacklo_epi64((X0), (X1)); \
    __m256i eij_t1 = _mm256_unpackhi_epi64((X0), (X1)); \
    __m256i eij_t2 = _mm256_unpacklo_epi64((X2), (X3)); \
    __m256i eij_t3 = _mm256_unpackhi_epi64((X2), (X3)); \
    (Y0) = _mm256_permute2x128_si256(eij_t0, eij_t2, 0x20); \
    (Y1) = _mm256_permute2x128_si256(eij_t1, eij_t3, 0x20); \
    (Y2) = _mm256_permute2x128_si256(eij_t0, eij_t2, 0x31); \
    (Y3) = _mm256_permute2x128_si256(eij_t1, eij_t3, 0x31); \
} while (0)

/* Eight-column lane shift: Y[j] = X[(j+5) mod 8]. */
#define EIJEN_SH5(X0, X1, Y0, Y1) do { \
    __m256i eij_p0 = _mm256_permute4x64_epi64((X0), 0x39); \
    __m256i eij_p1 = _mm256_permute4x64_epi64((X1), 0x39); \
    (Y0) = _mm256_blend_epi32(eij_p1, eij_p0, 0xC0); \
    (Y1) = _mm256_blend_epi32(eij_p0, eij_p1, 0xC0); \
} while (0)

/* Eight-column lane shift: Y[j] = X[(j+7) mod 8]. */
#define EIJEN_SH7(X0, X1, Y0, Y1) do { \
    __m256i eij_s0 = _mm256_permute4x64_epi64((X0), 0x93); \
    __m256i eij_s1 = _mm256_permute4x64_epi64((X1), 0x93); \
    __m256i eij_c0 = _mm256_permute4x64_epi64((X0), 0xFF); \
    __m256i eij_c1 = _mm256_permute4x64_epi64((X1), 0xFF); \
    (Y0) = _mm256_blend_epi32(eij_s0, eij_c1, 0x03); \
    (Y1) = _mm256_blend_epi32(eij_s1, eij_c0, 0x03); \
} while (0)

/* Vectorised MixQuad over all eight columns.  D0/D1 are passed in the
 * swapped role-3 column order described above; M8 rotates 64-bit lanes by 8
 * bytes. */
#define EIJEN_MIXV(A0, A1, B0, B1, C0, C1, D0, D1, RC0, RC1, M8) do { \
    (A0) = _mm256_add_epi64((A0), (B0)); \
    (A1) = _mm256_add_epi64((A1), (B1)); \
    (D0) = _mm256_xor_si256((D0), (A0)); \
    (D1) = _mm256_xor_si256((D1), (A1)); \
    (D0) = EIJEN_VROTL((D0), 36); \
    (D1) = _mm256_shuffle_epi8((D1), (M8)); \
    (A0) = _mm256_xor_si256(EIJEN_VROTL((A0), 18), (RC0)); \
    (A1) = _mm256_xor_si256(EIJEN_VROTL((A1), 19), (RC1)); \
    (C0) = _mm256_add_epi64((C0), (D0)); \
    (C1) = _mm256_add_epi64((C1), (D1)); \
    (B0) = _mm256_xor_si256((B0), (C0)); \
    (B1) = _mm256_xor_si256((B1), (C1)); \
    (B0) = EIJEN_VROTL((B0), 54); \
    (B1) = EIJEN_VROTL((B1), 46); \
    (C0) = EIJEN_VROTL((C0), 9); \
    (C1) = EIJEN_VROTL((C1), 51); \
    (A0) = _mm256_add_epi64((A0), (B0)); \
    (A1) = _mm256_add_epi64((A1), (B1)); \
    (D0) = _mm256_xor_si256((D0), (A0)); \
    (D1) = _mm256_xor_si256((D1), (A1)); \
    (D0) = EIJEN_VROTL((D0), 45); \
    (D1) = EIJEN_VROTL((D1), 54); \
    (C0) = _mm256_add_epi64((C0), (D0)); \
    (C1) = _mm256_add_epi64((C1), (D1)); \
    (B0) = _mm256_xor_si256((B0), (C0)); \
    (B1) = _mm256_xor_si256((B1), (C1)); \
    (B0) = EIJEN_VROTL((B0), 44); \
    (B1) = EIJEN_VROTL((B1), 34); \
} while (0)

/* Byte index map implementing a 64-bit lane rotate by 8 bits (rotr 8 ==
 * rotl 56).  vpshufb works within 128-bit lanes, so each 64-bit group gets
 * its own 8-byte rotation. */
static const unsigned char EIJEN_ROR8_MASK[32] = {
    1, 2, 3, 4, 5, 6, 7, 0, 9, 10, 11, 12, 13, 14, 15, 8,
    1, 2, 3, 4, 5, 6, 7, 0, 9, 10, 11, 12, 13, 14, 15, 8
};

/* Evaluate the full 16-round Eijen permutation. */
static void eijen_permutation(uint64_t state[EIJEN_STATE_WORDS]) {
    __m256i a0, a1, b0, b1, c0, c1, d0, d1;
    __m256i u0, u1, e0, e1, p0, p1, s0, s1, t0, t1;
    const __m256i ror8 =
        _mm256_loadu_si256((const __m256i *)(const void *)EIJEN_ROR8_MASK);
    int r;

    /* Canonical column-major -> role-major.  d1 takes columns 0..3 and d0
     * takes columns 4..7 so that role 3's -4 fold shift cancels. */
    t0 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 0));
    t1 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 4));
    e0 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 8));
    e1 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 12));
    EIJEN_TP4(t0, t1, e0, e1, a0, b0, c0, d1);
    t0 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 16));
    t1 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 20));
    e0 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 24));
    e1 = _mm256_loadu_si256((const __m256i *)(const void *)(state + 28));
    EIJEN_TP4(t0, t1, e0, e1, a1, b1, c1, d0);

    u0 = c0;                                /* v0 of round 0 = SH5(role 2) */
    u1 = c1;

    for (r = 0; r < EIJEN_ROUNDS; r++) {
        __m256i rc0 = _mm256_set1_epi64x((long long)EIJEN_RC0[r]);
        __m256i rc1 = _mm256_set1_epi64x((long long)EIJEN_RC1[r]);

        EIJEN_MIXV(a0, a1, b0, b1, c0, c1, d1, d0, rc0, rc1, ror8);

        EIJEN_SH5(c0, c1, u0, u1);              /* v0 = W[2][k+5] */
        EIJEN_SH7(b0, b1, e0, e1);              /* v2 = W[1][k+7] */

        p0 = _mm256_xor_si256(u0, e0);          /* p = v0 ^ v2 */
        p1 = _mm256_xor_si256(u1, e1);
        s0 = _mm256_xor_si256(a0, d0);          /* s = v1 ^ v3 */
        s1 = _mm256_xor_si256(a1, d1);

        t0 = _mm256_xor_si256(p0, d0);          /* W'[2] pre-shift = p ^ v3 */
        t1 = _mm256_xor_si256(p1, d1);
        d1 = _mm256_xor_si256(p1, a1);          /* W'[3] = p ^ v1, no shift */
        d0 = _mm256_xor_si256(p0, a0);
        b0 = _mm256_xor_si256(s0, e0);          /* W'[1] = s ^ v2, no shift */
        b1 = _mm256_xor_si256(s1, e1);

        EIJEN_SH7(t0, t1, c0, c1);              /* W'[2] = shift(-1) */

        e0 = _mm256_xor_si256(s0, u0);          /* W'[0] pre-shift = s ^ v0 */
        e1 = _mm256_xor_si256(s1, u1);
        EIJEN_SH5(e0, e1, a0, a1);              /* W'[0] = shift(-3) */
    }

    /* Role-major -> canonical column-major. */
    EIJEN_TP4(a0, b0, c0, d1, t0, t1, e0, e1);
    _mm256_storeu_si256((__m256i *)(void *)(state + 0), t0);
    _mm256_storeu_si256((__m256i *)(void *)(state + 4), t1);
    _mm256_storeu_si256((__m256i *)(void *)(state + 8), e0);
    _mm256_storeu_si256((__m256i *)(void *)(state + 12), e1);
    EIJEN_TP4(a1, b1, c1, d0, t0, t1, e0, e1);
    _mm256_storeu_si256((__m256i *)(void *)(state + 16), t0);
    _mm256_storeu_si256((__m256i *)(void *)(state + 20), t1);
    _mm256_storeu_si256((__m256i *)(void *)(state + 24), e0);
    _mm256_storeu_si256((__m256i *)(void *)(state + 28), e1);
}

#else /* portable C99 fallback */

#define EIJEN_MIXQ(A, i, R0, R1, R2, R3, R4, R5, RC) do { \
    uint64_t a = (A)[(i)]; \
    uint64_t b = (A)[(i) + 1]; \
    uint64_t c = (A)[(i) + 2]; \
    uint64_t d = (A)[(i) + 3]; \
    a += b; \
    d ^= a; \
    d = eijen_rotl64(d, (R0)); \
    a = eijen_rotl64(a, (R4)) ^ (RC); \
    c += d; \
    b ^= c; \
    b = eijen_rotl64(b, (R1)); \
    c = eijen_rotl64(c, (R5)); \
    a += b; \
    d ^= a; \
    d = eijen_rotl64(d, (R2)); \
    c += d; \
    b ^= c; \
    b = eijen_rotl64(b, (R3)); \
    (A)[(i)] = a; \
    (A)[(i) + 1] = b; \
    (A)[(i) + 2] = c; \
    (A)[(i) + 3] = d; \
} while (0)

#define EIJEN_MIXQ_LO(A, i, RC) \
    EIJEN_MIXQ((A), (i), 36, 54, 45, 44, 18, 9, (RC))

#define EIJEN_MIXQ_HI(A, i, RC) \
    EIJEN_MIXQ((A), (i), 56, 46, 54, 34, 19, 51, (RC))

#define EIJEN_MIX_ALL(A, RC0, RC1) do { \
    EIJEN_MIXQ_LO((A), 0, (RC0)); \
    EIJEN_MIXQ_LO((A), 4, (RC0)); \
    EIJEN_MIXQ_LO((A), 8, (RC0)); \
    EIJEN_MIXQ_LO((A), 12, (RC0)); \
    EIJEN_MIXQ_HI((A), 16, (RC1)); \
    EIJEN_MIXQ_HI((A), 20, (RC1)); \
    EIJEN_MIXQ_HI((A), 24, (RC1)); \
    EIJEN_MIXQ_HI((A), 28, (RC1)); \
} while (0)

#define EIJEN_GB(A, B, s0, s1, s2, s3, p0, p1, p2, p3) do { \
    uint64_t v0 = (A)[(s0)]; \
    uint64_t v1 = (A)[(s1)]; \
    uint64_t v2 = (A)[(s2)]; \
    uint64_t v3 = (A)[(s3)]; \
    uint64_t q = v0 ^ v1 ^ v2 ^ v3; \
    (B)[(p0)] = q ^ v0; \
    (B)[(p1)] = q ^ v1; \
    (B)[(p2)] = q ^ v2; \
    (B)[(p3)] = q ^ v3; \
} while (0)

#define EIJEN_G_ALL(A, B) do { \
    EIJEN_GB((A), (B), 22, 0, 29, 19, 1, 6, 12, 19); \
    EIJEN_GB((A), (B), 26, 4, 1, 23, 5, 10, 16, 23); \
    EIJEN_GB((A), (B), 30, 8, 5, 27, 9, 14, 20, 27); \
    EIJEN_GB((A), (B), 2, 12, 9, 31, 13, 18, 24, 31); \
    EIJEN_GB((A), (B), 6, 16, 13, 3, 17, 22, 28, 3); \
    EIJEN_GB((A), (B), 10, 20, 17, 7, 21, 26, 0, 7); \
    EIJEN_GB((A), (B), 14, 24, 21, 11, 25, 30, 4, 11); \
    EIJEN_GB((A), (B), 18, 28, 25, 15, 29, 2, 8, 15); \
} while (0)

/* Evaluate the full 16-round Eijen permutation. */
static void eijen_permutation(uint64_t state[EIJEN_STATE_WORDS]) {
    uint64_t alt[EIJEN_STATE_WORDS];
    int r;

    for (r = 0; r < EIJEN_ROUNDS; r += 2) {
        EIJEN_MIX_ALL(state, EIJEN_RC0[r], EIJEN_RC1[r]);
        EIJEN_G_ALL(state, alt);
        EIJEN_MIX_ALL(alt, EIJEN_RC0[r + 1], EIJEN_RC1[r + 1]);
        EIJEN_G_ALL(alt, state);
    }
}

#endif /* __AVX2__ */

/* Absorb one complete rate block and apply capacity feed-forward. */
static void eijen_absorb_block(eijen_ctx *ctx, const uint8_t *block, int is_last) {
    uint64_t saved_cap[17];
    int i;
    int cap_start = ctx->cfg->rate_words;
    int cap_words = ctx->cfg->capacity_words;

    for (i = 0; i < cap_words; i++) {
        saved_cap[i] = ctx->state[cap_start + i];
    }
    for (i = 0; i < ctx->cfg->rate_words; i++) {
        ctx->state[i] ^= eijen_load64_le(block + ((size_t)i * 8U));
    }
    if (is_last) {
        ctx->state[EIJEN_STATE_WORDS - 1] ^= (UINT64_C(1) << 63);
    }

    eijen_permutation(ctx->state);

    for (i = 0; i < cap_words; i++) {
        ctx->state[cap_start + i] ^= saved_cap[i];
    }
}

/* Initialize the byte-streaming hash context. */
int eijen_init(eijen_ctx *ctx, int digest_bits) {
    const eijen_config *cfg;
    if (ctx == NULL) {
        return -1;
    }
    cfg = eijen_get_config(digest_bits);
    if (cfg == NULL) {
        return -1;
    }
    memset(ctx, 0, sizeof(*ctx));
    ctx->cfg = cfg;
    return 0;
}

/* Absorb a byte-aligned fragment into the streaming hash context. */
int eijen_update(eijen_ctx *ctx, const uint8_t *data, size_t len) {
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || (data == NULL && len != 0U)) {
        return -1;
    }
    rb = (size_t)ctx->cfg->rate_bytes;
    while (len > 0U) {
        size_t space = rb - ctx->buf_len;
        size_t take = len < space ? len : space;
        if (ctx->buf_len == 0U && len > rb) {
            eijen_absorb_block(ctx, data, 0);
            data += rb;
            len -= rb;
            continue;
        }
        memcpy(ctx->buf + ctx->buf_len, data, take);
        ctx->buf_len += take;
        data += take;
        len -= take;
        if (ctx->buf_len == rb && len > 0U) {
            eijen_absorb_block(ctx, ctx->buf, 0);
            ctx->buf_len = 0U;
        }
    }
    return 0;
}

/* Finalize the context, optionally including a partial MSB-first final byte. */
static int eijen_final_partial(eijen_ctx *ctx, uint8_t partial_byte,
                               unsigned int partial_bits, uint8_t *digest) {
    int i;
    int ds;
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || digest == NULL || partial_bits > 7U) {
        return -1;
    }
    rb = (size_t)ctx->cfg->rate_bytes;
    if (ctx->buf_len == rb) {
        eijen_absorb_block(ctx, ctx->buf, 0);
        ctx->buf_len = 0U;
    }
    if (partial_bits == 0U) {
        ctx->buf[ctx->buf_len] = 0x01U;
    } else {
        uint8_t keep = (uint8_t)(0xffU << (8U - partial_bits));
        uint8_t pad = (uint8_t)(0x80U >> partial_bits);
        ctx->buf[ctx->buf_len] = (uint8_t)((partial_byte & keep) | pad);
    }
    ctx->buf_len++;
    memset(ctx->buf + ctx->buf_len, 0, rb - ctx->buf_len);
    eijen_absorb_block(ctx, ctx->buf, 1);

    ds = EIJEN_STATE_WORDS - ctx->cfg->digest_words;
    for (i = 0; i < ctx->cfg->digest_words; i++) {
        eijen_store64_le(digest + ((size_t)i * 8U), ctx->state[ds + i]);
    }
    return 0;
}

/* Finalize a byte-aligned message. */
int eijen_final(eijen_ctx *ctx, uint8_t *digest) {
    return eijen_final_partial(ctx, 0U, 0U, digest);
}

/* Hash a byte-aligned message in one call. */
int eijen_hash(int digest_bits, const uint8_t *msg, size_t len, uint8_t *digest) {
    eijen_ctx ctx;
    if (eijen_init(&ctx, digest_bits) != 0) {
        return -1;
    }
    if (eijen_update(&ctx, msg, len) != 0) {
        return -1;
    }
    return eijen_final(&ctx, digest);
}

/* Hash a bit-length message using the API_CryptHash partial-byte convention. */
int eijen_hash_bits(int digest_bits, const uint8_t *msg,
                    unsigned long long msg_len_bits, unsigned char *digest) {
    eijen_ctx ctx;
    unsigned long long full_bytes = msg_len_bits / 8ULL;
    unsigned int partial_bits = (unsigned int)(msg_len_bits & 7ULL);
    uint8_t partial_byte = 0U;

    if ((msg == NULL && msg_len_bits != 0ULL) || digest == NULL) {
        return -1;
    }
    if (full_bytes > (unsigned long long)((size_t)-1)) {
        return -1;
    }
    if (eijen_init(&ctx, digest_bits) != 0) {
        return -1;
    }
    if (eijen_update(&ctx, msg, (size_t)full_bytes) != 0) {
        return -1;
    }
    if (partial_bits != 0U) {
        partial_byte = msg[full_bytes];
    }
    return eijen_final_partial(&ctx, partial_byte, partial_bits, digest);
}
