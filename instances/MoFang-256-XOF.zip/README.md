# MoFang-256-XOF

Algorithm: MoFang | Digest bits: 256 | Form: AVX2 C

Contents: implementation source/, public header MoFang-256-XOF.h, prebuilt MoFang-256-XOF.so,
KAT vector KAT_2_12_MoFang_256_XOF.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 7fc2d51ac6b834bbe58f4220b050c594c0f3b4cf050b12ebb0aff7f14916a5d2
Speed (cpB, lower is faster): reference 9.30 / official-optimized 6.49 / optimized 2.12
Speedup: GM(S1-S8) 2.99x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
