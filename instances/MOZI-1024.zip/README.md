# MOZI-1024

Algorithm: Mozi | Digest bits: 1024 | Form: SSE C++（对手 fast 驱动）

Contents: implementation source/, public header MOZI-1024.h, prebuilt MOZI-1024.so,
KAT vector KAT_2_12_MOZI-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): f122162919e7f5801523947c110d4d7858e9099b4ce42b994d4d2c54b1a844b0
Speed (cpB, lower is faster): reference 19.81 / official-optimized 5.84 / optimized 5.54
Speedup: GM(S1-S8) 1.07x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
