/* 由 _overnight/l0/build_engine_artifact.py 生成，勿手改。
 *
 * 结构：官方 Duet-512 sponge 外壳（逐字节照抄 _b/avx2/duet_ours_simd.c）
 *     + 置换核 duet_p / duet_p2 由 rewrites 引擎发射（A1 内联 → A3 AVX2 打包）。
 *
 * 引擎在这一件上做的事，逐条记在 evidence/Duet-512 (引擎发射).json 的
 * transforms 里；本文件可被 build_engine_artifact.py 逐字节重建。
 */
/* duet_ours_simd.c — Duet-512 完整实现：我们的 AVX2 位切片置换
 * （duet_avx2.c 提供 duet_p/duet_p2）+ 自研 sponge 外壳。
 *
 * sponge 语义严格照抄 ref.c（pad/absorb/squeeze 结构一致，已验证摘要与
 * ref/opt 全同）。差异仅在**字节序转换**：ref 用逐字节移位（8 条/字），
 * 这里用 pshufb 一次转 4 字（1 条/字），消除外壳开销。
 *
 * absorb 块首 6 字（rate）与末 9 字（capacity）分别做 BE<->LE 转换。
 */
#include <immintrin.h>
#include <stdint.h>
#include <string.h>

enum {
  R_BITS = 384,
  C_BITS = 576,
  WORDS_r = R_BITS / 64,
  WORDS_c = C_BITS / 64,
  WORDS_perm = WORDS_r + WORDS_c,
  R_BYTES = WORDS_r * 8,
  C_BYTES = WORDS_c * 8
};

void duet_p(uint64_t *p);
void duet_p2(uint64_t *p);

/* --- SIMD 字节序转换 --- */
static inline __m256i bswap256(__m256i a) {
  const __m256i m = _mm256_set_epi8(8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3,
                                    4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                                    0, 1, 2, 3, 4, 5, 6, 7);
  return _mm256_shuffle_epi8(a, m);
}
static inline __m128i bswap128(__m128i a) {
  const __m128i m = _mm_set_epi8(8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4,
                                 5, 6, 7);
  return _mm_shuffle_epi8(a, m);
}

static uint64_t load64_be(const unsigned char in[8]) {
  return ((uint64_t)in[0] << 56) | ((uint64_t)in[1] << 48) |
         ((uint64_t)in[2] << 40) | ((uint64_t)in[3] << 32) |
         ((uint64_t)in[4] << 24) | ((uint64_t)in[5] << 16) |
         ((uint64_t)in[6] << 8) | (uint64_t)in[7];
}
static void store64_be(unsigned char out[8], uint64_t x) {
  out[0] = (unsigned char)(x >> 56);
  out[1] = (unsigned char)(x >> 48);
  out[2] = (unsigned char)(x >> 40);
  out[3] = (unsigned char)(x >> 32);
  out[4] = (unsigned char)(x >> 24);
  out[5] = (unsigned char)(x >> 16);
  out[6] = (unsigned char)(x >> 8);
  out[7] = (unsigned char)x;
}

/* BE 字节 -> u64 数组，SIMD 批量（n=6 或 9）。 */
static void bytes_to_words_simd(uint64_t *out, const unsigned char *in,
                                unsigned n) {
  unsigned i = 0;
  for (; i + 4 <= n; i += 4) {
    __m256i a = _mm256_loadu_si256((const __m256i *)(const void *)(in + i * 8));
    _mm256_storeu_si256((__m256i *)(void *)(out + i), bswap256(a));
  }
  if (i + 2 <= n) {
    __m128i a = _mm_loadu_si128((const __m128i *)(const void *)(in + i * 8));
    _mm_storeu_si128((__m128i *)(void *)(out + i), bswap128(a));
    i += 2;
  }
  for (; i < n; i++) out[i] = load64_be(in + i * 8);
}

/* u64 数组 -> BE 字节，SIMD 批量（n=6 或 9）。 */
static void words_to_bytes_simd(unsigned char *out, const uint64_t *in,
                                unsigned n) {
  unsigned i = 0;
  for (; i + 4 <= n; i += 4) {
    __m256i a = _mm256_loadu_si256((const __m256i *)(const void *)(in + i));
    _mm256_storeu_si256((__m256i *)(void *)(out + i * 8), bswap256(a));
  }
  if (i + 2 <= n) {
    __m128i a = _mm_loadu_si128((const __m128i *)(const void *)(in + i));
    _mm_storeu_si128((__m128i *)(void *)(out + i * 8), bswap128(a));
    i += 2;
  }
  for (; i < n; i++) store64_be(out + i * 8, in[i]);
}

/* --- sponge --- */
static void pad_message_block(uint64_t block[WORDS_r], const unsigned char *msg,
                              uint64_t msg_len_bits) {
  unsigned char buf[R_BYTES];
  uint64_t full_bytes = msg_len_bits >> 3;
  unsigned rem_bits = (unsigned)(msg_len_bits & 7U);
  unsigned full_words = (unsigned)(full_bytes >> 3);
  unsigned tail_bytes = (unsigned)(full_bytes & 7U);
  unsigned i;

  memset(block, 0, sizeof(uint64_t) * WORDS_r);
  for (i = 0; i < full_words; ++i) block[i] = load64_be(msg + 8U * i);

  if (rem_bits == 0U && tail_bytes == 0U) {
    block[full_words] = 0x8000000000000000ULL;
    return;
  }
  msg += 8U * full_words;
  for (i = 0; i < tail_bytes; ++i)
    block[full_words] |= (uint64_t)msg[i] << (56U - 8U * i);
  if (rem_bits == 0U) {
    block[full_words] |= 0x80ULL << (56U - 8U * tail_bytes);
  } else {
    unsigned char last = (unsigned char)(msg[tail_bytes] & (0xffU << (8U - rem_bits)));
    last |= (unsigned char)(0x80U >> rem_bits);
    block[full_words] |= (uint64_t)last << (56U - 8U * tail_bytes);
  }
  (void)buf;
}

static void absorb_block(uint64_t A[WORDS_r], uint64_t B[WORDS_r],
                         uint64_t C[WORDS_c], const uint64_t Mi[WORDS_r]) {
  uint64_t p[WORDS_perm];
  unsigned i;

  p[0] = A[0] ^ Mi[0]; p[1] = A[1] ^ Mi[1]; p[2] = A[2] ^ Mi[2];
  p[3] = A[3] ^ Mi[3]; p[4] = A[4] ^ Mi[4]; p[5] = A[5] ^ Mi[5];
  for (i = 0; i < WORDS_c; ++i) p[WORDS_r + i] = C[i];

  duet_p(p);

  A[0] = p[0]; A[1] = p[1]; A[2] = p[2]; A[3] = p[3]; A[4] = p[4]; A[5] = p[5];
  for (i = 0; i < WORDS_c; ++i) { p[WORDS_r + i] ^= C[i]; C[i] = p[WORDS_r + i]; }

  p[0] = B[0] ^ Mi[3]; p[1] = B[1] ^ Mi[0]; p[2] = B[2] ^ Mi[5];
  p[3] = B[3] ^ Mi[1]; p[4] = B[4] ^ Mi[4]; p[5] = B[5] ^ Mi[2];

  duet_p2(p);

  B[0] = p[0]; B[1] = p[1]; B[2] = p[2]; B[3] = p[3]; B[4] = p[4]; B[5] = p[5];
  for (i = 0; i < WORDS_c; ++i) C[i] ^= p[WORDS_r + i];
}

static void apply_empty(uint64_t R[WORDS_r], uint64_t C[WORDS_c],
                        int second) {
  uint64_t p[WORDS_perm];
  unsigned i;
  for (i = 0; i < WORDS_r; ++i) p[i] = R[i];
  for (i = 0; i < WORDS_c; ++i) p[WORDS_r + i] = C[i];
  if (second) duet_p2(p); else duet_p(p);
  for (i = 0; i < WORDS_r; ++i) R[i] = p[i];
  for (i = 0; i < WORDS_c; ++i) C[i] ^= p[WORDS_r + i];
}

static void copy_capacity_bytes(unsigned char *out,
                                const uint64_t C[WORDS_c], size_t count) {
  size_t full_words = count >> 3;
  size_t rem_bytes = count & 7U;
  size_t i;
  for (i = 0; i < full_words; ++i) store64_be(out + 8U * i, C[i]);
  if (rem_bytes != 0U) {
    uint64_t x = C[full_words];
    unsigned shift = 56U;
    for (i = 0; i < rem_bytes; ++i, shift -= 8U)
      out[8U * full_words + i] = (unsigned char)(x >> shift);
  }
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest) {
  uint64_t A[WORDS_r] = {0};
  uint64_t B[WORDS_r] = {0};
  uint64_t C[WORDS_c] = {0};
  uint64_t Mi[WORDS_r];
  unsigned long long full_blocks, rem_bits, blk;
  const unsigned char *p;
  unsigned char *out;
  size_t remaining_bytes;

  if (digest_len_bits <= 0 || digest_len_bits > 8192) return -1;
  if (digest == NULL) return -2;
  if (msg == NULL && msg_len_bits != 0U) return -3;

  full_blocks = msg_len_bits / R_BITS;
  rem_bits = msg_len_bits % R_BITS;
  p = msg;

  for (blk = 0; blk < full_blocks; ++blk) {
    bytes_to_words_simd(Mi, p, WORDS_r);
    absorb_block(A, B, C, Mi);
    p += R_BYTES;
  }

  pad_message_block(Mi, p, rem_bits);
  absorb_block(A, B, C, Mi);

  remaining_bytes = ((size_t)(unsigned)digest_len_bits + 7U) >> 3;
  out = digest;

  for (;;) {
    size_t take = remaining_bytes < C_BYTES ? remaining_bytes : C_BYTES;
    words_to_bytes_simd((unsigned char *)digest + (out - digest), C,
                        (unsigned)((take + 7) / 8));
    out += take;
    remaining_bytes -= take;
    if (remaining_bytes == 0U) break;

    apply_empty(A, C, 0);
    take = remaining_bytes < C_BYTES ? remaining_bytes : C_BYTES;
    words_to_bytes_simd((unsigned char *)digest + (out - digest), C,
                        (unsigned)((take + 7) / 8));
    out += take;
    remaining_bytes -= take;
    if (remaining_bytes == 0U) break;

    apply_empty(B, C, 1);
  }

  if (((unsigned)digest_len_bits & 7U) != 0U)
    digest[(unsigned)digest_len_bits >> 3] &=
        (unsigned char)(0xffU << (8U - ((unsigned)digest_len_bits & 7U)));

  return 0;
}


#include <immintrin.h>
#include <stdint.h>

/* 引擎的标量助手（ror64/shl_l/shr_l）必须来自 PREAMBLE —— 不能在这里
 * 另写一份：两份实现漂移会让「参照系」与「真交付」不是同一件事。
 * 只发一次，两个核共用。 */
#include <stdint.h>
static inline uint64_t ror64(uint64_t x, unsigned n) {
    return (x >> n) | (x << (64 - n));
}
/* lane 内移位：把 uint64 看成 64/lw 个 lw 位槽，逐槽移位且不跨槽进位，
   与 ir_eval 的 shl/shr(.uN) 语义逐位对齐。 */
static inline uint64_t shl_l(uint64_t x, unsigned k, unsigned lw) {
    const uint64_t m = (lw >= 64) ? ~0ULL : ((1ULL << lw) - 1);
    uint64_t out = 0;
    for (unsigned i = 0; i < 64u / lw; i++) {
        uint64_t v = (x >> (i * lw)) & m;
        out |= ((v << k) & m) << (i * lw);
    }
    return out;
}
static inline uint64_t shr_l(uint64_t x, unsigned k, unsigned lw) {
    const uint64_t m = (lw >= 64) ? ~0ULL : ((1ULL << lw) - 1);
    uint64_t out = 0;
    for (unsigned i = 0; i < 64u / lw; i++) {
        uint64_t v = (x >> (i * lw)) & m;
        out |= ((v >> k) & m) << (i * lw);
    }
    return out;
}
static inline uint64_t ror_l(uint64_t x, unsigned k, unsigned lw) {
    k %= lw;
    const uint64_t m = (lw >= 64) ? ~0ULL : ((1ULL << lw) - 1);
    uint64_t out = 0;
    for (unsigned i = 0; i < 64u / lw; i++) {
        uint64_t v = (x >> (i * lw)) & m;
        uint64_t r = k ? (((v >> k) | (v << (lw - k))) & m) : v;
        out |= r << (i * lw);
    }
    return out;
}

/* ==================== 引擎发射部分（勿手改） ==================== */
/* duet_p ← alg/h08/agent.jir：208 条改写，体内 101 条，3 lane × 3 块 */
static const uint64_t DUET_P_RC[12] = {
    0x243f6a8885a308d3ULL, 0x13198a2e03707344ULL, 0xa4093822299f31d0ULL, 0x082efa98ec4e6c89ULL, 0x452821e638d01377ULL, 0xbe5466cf34e90c6cULL, 0xc0ac29b7c97c50ddULL, 0x3f84d5b5b5470917ULL, 0x9216d5d98979fb1bULL, 0xd1310ba698dfb5acULL, 0x2ffd72dbd01adfb7ULL, 0xb8e1afed6a267e96ULL,
};

static void duet_p_orig(uint64_t *p) {
    uint64_t s00 = p[0];
    uint64_t s01 = p[1];
    uint64_t s02 = p[2];
    uint64_t s03 = p[3];
    uint64_t s04 = p[4];
    uint64_t s10 = p[5];
    uint64_t s11 = p[6];
    uint64_t s12 = p[7];
    uint64_t s13 = p[8];
    uint64_t s14 = p[9];
    uint64_t s20 = p[10];
    uint64_t s21 = p[11];
    uint64_t s22 = p[12];
    uint64_t s23 = p[13];
    uint64_t s24 = p[14];

    for (int r = 0; r < 12; r++) {
        const uint64_t rc = DUET_P_RC[r];
        uint64_t x0 = s00;
        uint64_t x1 = s01;
        uint64_t x2 = s02;
        uint64_t x3 = s03;
        uint64_t x4 = s04;
        uint64_t t0 = (x3 & x4);
        uint64_t t1 = (x2 & x4);
        uint64_t t2 = (x2 & x3);
        uint64_t t3 = (x1 & x4);
        uint64_t t4 = (x1 & x2);
        uint64_t t5 = (x0 & x1);
        uint64_t t6 = (x4 ^ x2);
        uint64_t t7 = (x0 ^ t0);
        uint64_t t8 = (t1 ^ t2);
        uint64_t t9 = (t3 ^ t4);
        uint64_t t10 = (t5 ^ t6);
        uint64_t t11 = (t7 ^ t8);
        uint64_t t12 = (t9 ^ t10);
        uint64_t t13 = (t11 ^ t12);
        uint64_t t14 = (t13 ^ 0xffffffffffffffff);
        uint64_t t15 = (x1 & x3);
        uint64_t t16 = (x0 & x2);
        uint64_t t17 = (x3 ^ x2);
        uint64_t t18 = (x0 ^ t1);
        uint64_t t19 = (t2 ^ t15);
        uint64_t t20 = (t4 ^ t16);
        uint64_t t21 = (t17 ^ t18);
        uint64_t t22 = (t19 ^ t20);
        uint64_t t23 = (t21 ^ t22);
        uint64_t t24 = (t23 ^ 0xffffffffffffffff);
        uint64_t t25 = (x0 & x4);
        uint64_t t26 = (x2 ^ x0);
        uint64_t t27 = (t0 ^ t1);
        uint64_t t28 = (t3 ^ t15);
        uint64_t t29 = (t4 ^ t25);
        uint64_t t30 = (t16 ^ t5);
        uint64_t t31 = (t26 ^ t27);
        uint64_t t32 = (t28 ^ t29);
        uint64_t t33 = (t30 ^ t31);
        uint64_t t34 = (t32 ^ t33);
        uint64_t t35 = (x0 & x3);
        uint64_t t36 = (x4 ^ x3);
        uint64_t t37 = (x1 ^ x0);
        uint64_t t38 = (t4 ^ t35);
        uint64_t t39 = (t16 ^ t5);
        uint64_t t40 = (t36 ^ t37);
        uint64_t t41 = (t38 ^ t39);
        uint64_t t42 = (t40 ^ t41);
        uint64_t t43 = (t42 ^ 0xffffffffffffffff);
        uint64_t t44 = (x4 ^ x2);
        uint64_t t45 = (x1 ^ x0);
        uint64_t t46 = (t3 ^ t15);
        uint64_t t47 = (t4 ^ t25);
        uint64_t t48 = (t5 ^ t44);
        uint64_t t49 = (t45 ^ t46);
        uint64_t t50 = (t47 ^ t48);
        uint64_t t51 = (t49 ^ t50);
        s00 = t14;
        s01 = t24;
        s02 = t34;
        s03 = t43;
        s04 = t51;
        x0 = s10;
        x1 = s11;
        x2 = s12;
        x3 = s13;
        x4 = s14;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t6 = (x4 ^ x2);
        t7 = (x0 ^ t0);
        t8 = (t1 ^ t2);
        t9 = (t3 ^ t4);
        t10 = (t5 ^ t6);
        t11 = (t7 ^ t8);
        t12 = (t9 ^ t10);
        t13 = (t11 ^ t12);
        t14 = (t13 ^ 0xffffffffffffffff);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t17 = (x3 ^ x2);
        t18 = (x0 ^ t1);
        t19 = (t2 ^ t15);
        t20 = (t4 ^ t16);
        t21 = (t17 ^ t18);
        t22 = (t19 ^ t20);
        t23 = (t21 ^ t22);
        t24 = (t23 ^ 0xffffffffffffffff);
        t25 = (x0 & x4);
        t26 = (x2 ^ x0);
        t27 = (t0 ^ t1);
        t28 = (t3 ^ t15);
        t29 = (t4 ^ t25);
        t30 = (t16 ^ t5);
        t31 = (t26 ^ t27);
        t32 = (t28 ^ t29);
        t33 = (t30 ^ t31);
        t34 = (t32 ^ t33);
        t35 = (x0 & x3);
        t36 = (x4 ^ x3);
        t37 = (x1 ^ x0);
        t38 = (t4 ^ t35);
        t39 = (t16 ^ t5);
        t40 = (t36 ^ t37);
        t41 = (t38 ^ t39);
        t42 = (t40 ^ t41);
        t43 = (t42 ^ 0xffffffffffffffff);
        t44 = (x4 ^ x2);
        t45 = (x1 ^ x0);
        t46 = (t3 ^ t15);
        t47 = (t4 ^ t25);
        t48 = (t5 ^ t44);
        t49 = (t45 ^ t46);
        t50 = (t47 ^ t48);
        t51 = (t49 ^ t50);
        s10 = t14;
        s11 = t24;
        s12 = t34;
        s13 = t43;
        s14 = t51;
        x0 = s20;
        x1 = s21;
        x2 = s22;
        x3 = s23;
        x4 = s24;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t6 = (x4 ^ x2);
        t7 = (x0 ^ t0);
        t8 = (t1 ^ t2);
        t9 = (t3 ^ t4);
        t10 = (t5 ^ t6);
        t11 = (t7 ^ t8);
        t12 = (t9 ^ t10);
        t13 = (t11 ^ t12);
        t14 = (t13 ^ 0xffffffffffffffff);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t17 = (x3 ^ x2);
        t18 = (x0 ^ t1);
        t19 = (t2 ^ t15);
        t20 = (t4 ^ t16);
        t21 = (t17 ^ t18);
        t22 = (t19 ^ t20);
        t23 = (t21 ^ t22);
        t24 = (t23 ^ 0xffffffffffffffff);
        t25 = (x0 & x4);
        t26 = (x2 ^ x0);
        t27 = (t0 ^ t1);
        t28 = (t3 ^ t15);
        t29 = (t4 ^ t25);
        t30 = (t16 ^ t5);
        t31 = (t26 ^ t27);
        t32 = (t28 ^ t29);
        t33 = (t30 ^ t31);
        t34 = (t32 ^ t33);
        t35 = (x0 & x3);
        t36 = (x4 ^ x3);
        t37 = (x1 ^ x0);
        t38 = (t4 ^ t35);
        t39 = (t16 ^ t5);
        t40 = (t36 ^ t37);
        t41 = (t38 ^ t39);
        t42 = (t40 ^ t41);
        t43 = (t42 ^ 0xffffffffffffffff);
        t44 = (x4 ^ x2);
        t45 = (x1 ^ x0);
        t46 = (t3 ^ t15);
        t47 = (t4 ^ t25);
        t48 = (t5 ^ t44);
        t49 = (t45 ^ t46);
        t50 = (t47 ^ t48);
        t51 = (t49 ^ t50);
        s20 = t14;
        s21 = t24;
        s22 = t34;
        s23 = t43;
        s24 = t51;
        uint64_t n0 = (s00 ^ s03);
        uint64_t n1 = (s04 ^ s10);
        uint64_t n2 = (s12 ^ s13);
        uint64_t n3 = (n0 ^ n1);
        uint64_t n4 = (n2 ^ s23);
        uint64_t o0 = (n3 ^ n4);
        n0 = (s01 ^ s04);
        n1 = (s10 ^ s11);
        n2 = (s13 ^ s14);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s24);
        uint64_t o1 = (n3 ^ n4);
        n0 = (s02 ^ s10);
        n1 = (s11 ^ s12);
        n2 = (s14 ^ s20);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s00);
        uint64_t o2 = (n3 ^ n4);
        n0 = (s03 ^ s11);
        n1 = (s12 ^ s13);
        n2 = (s20 ^ s21);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s01);
        uint64_t o3 = (n3 ^ n4);
        n0 = (s04 ^ s12);
        n1 = (s13 ^ s14);
        n2 = (s21 ^ s22);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s02);
        uint64_t o4 = (n3 ^ n4);
        n0 = (s10 ^ s13);
        n1 = (s14 ^ s20);
        n2 = (s22 ^ s23);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s03);
        uint64_t o5 = (n3 ^ n4);
        n0 = (s11 ^ s14);
        n1 = (s20 ^ s21);
        n2 = (s23 ^ s24);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s04);
        uint64_t o6 = (n3 ^ n4);
        n0 = (s12 ^ s20);
        n1 = (s21 ^ s22);
        n2 = (s24 ^ s00);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s10);
        uint64_t o7 = (n3 ^ n4);
        n0 = (s13 ^ s21);
        n1 = (s22 ^ s23);
        n2 = (s00 ^ s01);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s11);
        uint64_t o8 = (n3 ^ n4);
        n0 = (s14 ^ s22);
        n1 = (s23 ^ s24);
        n2 = (s01 ^ s02);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s12);
        uint64_t o9 = (n3 ^ n4);
        n0 = (s20 ^ s23);
        n1 = (s24 ^ s00);
        n2 = (s02 ^ s03);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s13);
        uint64_t o10 = (n3 ^ n4);
        n0 = (s21 ^ s24);
        n1 = (s00 ^ s01);
        n2 = (s03 ^ s04);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s14);
        uint64_t o11 = (n3 ^ n4);
        n0 = (s22 ^ s00);
        n1 = (s01 ^ s02);
        n2 = (s04 ^ s10);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s20);
        uint64_t o12 = (n3 ^ n4);
        n0 = (s23 ^ s01);
        n1 = (s02 ^ s03);
        n2 = (s10 ^ s11);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s21);
        uint64_t o13 = (n3 ^ n4);
        n0 = (s24 ^ s02);
        n1 = (s03 ^ s04);
        n2 = (s11 ^ s12);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s22);
        uint64_t o14 = (n3 ^ n4);
        s00 = o0;
        s01 = o1;
        s02 = o2;
        s03 = o3;
        s04 = o4;
        s10 = o5;
        s11 = o6;
        s12 = o7;
        s13 = o8;
        s14 = o9;
        s20 = o10;
        s21 = o11;
        s22 = o12;
        s23 = o13;
        s24 = o14;
        s00 = (s00 ^ rc);
        s00 = ((ror64(s00, 0) ^ ror64(s00, 43)) ^ ror64(s00, 21));
        s01 = ((ror64(s01, 63) ^ ror64(s01, 42)) ^ ror64(s01, 20));
        s02 = ((ror64(s02, 62) ^ ror64(s02, 41)) ^ ror64(s02, 19));
        s03 = ((ror64(s03, 61) ^ ror64(s03, 40)) ^ ror64(s03, 18));
        s04 = ((ror64(s04, 60) ^ ror64(s04, 39)) ^ ror64(s04, 17));
        s10 = ((ror64(s10, 59) ^ ror64(s10, 38)) ^ ror64(s10, 16));
        s11 = ((ror64(s11, 58) ^ ror64(s11, 37)) ^ ror64(s11, 15));
        s12 = ((ror64(s12, 57) ^ ror64(s12, 36)) ^ ror64(s12, 14));
        s13 = ((ror64(s13, 56) ^ ror64(s13, 35)) ^ ror64(s13, 13));
        s14 = ((ror64(s14, 55) ^ ror64(s14, 34)) ^ ror64(s14, 12));
        s20 = ((ror64(s20, 54) ^ ror64(s20, 33)) ^ ror64(s20, 11));
        s21 = ((ror64(s21, 53) ^ ror64(s21, 32)) ^ ror64(s21, 10));
        s22 = ((ror64(s22, 52) ^ ror64(s22, 31)) ^ ror64(s22, 9));
        s23 = ((ror64(s23, 51) ^ ror64(s23, 30)) ^ ror64(s23, 8));
        s24 = ((ror64(s24, 50) ^ ror64(s24, 29)) ^ ror64(s24, 7));
    }

    p[0] = s00;
    p[1] = s01;
    p[2] = s02;
    p[3] = s03;
    p[4] = s04;
    p[5] = s10;
    p[6] = s11;
    p[7] = s12;
    p[8] = s13;
    p[9] = s14;
    p[10] = s20;
    p[11] = s21;
    p[12] = s22;
    p[13] = s23;
    p[14] = s24;
}

static void duet_p_ref(uint64_t *p) {
    uint64_t s00 = p[0];
    uint64_t s01 = p[1];
    uint64_t s02 = p[2];
    uint64_t s03 = p[3];
    uint64_t s04 = p[4];
    uint64_t s10 = p[5];
    uint64_t s11 = p[6];
    uint64_t s12 = p[7];
    uint64_t s13 = p[8];
    uint64_t s14 = p[9];
    uint64_t s20 = p[10];
    uint64_t s21 = p[11];
    uint64_t s22 = p[12];
    uint64_t s23 = p[13];
    uint64_t s24 = p[14];

    for (int r = 0; r < 12; r++) {
        const uint64_t rc = DUET_P_RC[r];
        uint64_t x0 = s00;
        uint64_t x1 = s01;
        uint64_t x2 = s02;
        uint64_t x3 = s03;
        uint64_t x4 = s04;
        uint64_t t0 = (x3 & x4);
        uint64_t t1 = (x2 & x4);
        uint64_t t2 = (x2 & x3);
        uint64_t t3 = (x1 & x4);
        uint64_t t4 = (x1 & x2);
        uint64_t t5 = (x0 & x1);
        uint64_t t15 = (x1 & x3);
        uint64_t t16 = (x0 & x2);
        uint64_t t25 = (x0 & x4);
        s00 = ((((x0 ^ t0) ^ (t1 ^ t2)) ^ ((t3 ^ t4) ^ (t5 ^ (x4 ^ x2)))) ^ 0xffffffffffffffff);
        s01 = ((((x3 ^ x2) ^ (x0 ^ t1)) ^ ((t2 ^ t15) ^ (t4 ^ t16))) ^ 0xffffffffffffffff);
        s02 = (((t3 ^ t15) ^ (t4 ^ t25)) ^ ((t16 ^ t5) ^ ((x2 ^ x0) ^ (t0 ^ t1))));
        s03 = ((((x4 ^ x3) ^ (x1 ^ x0)) ^ ((t4 ^ (x0 & x3)) ^ (t16 ^ t5))) ^ 0xffffffffffffffff);
        s04 = (((x1 ^ x0) ^ (t3 ^ t15)) ^ ((t4 ^ t25) ^ (t5 ^ (x4 ^ x2))));
        x0 = s10;
        x1 = s11;
        x2 = s12;
        x3 = s13;
        x4 = s14;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t25 = (x0 & x4);
        s10 = ((((x0 ^ t0) ^ (t1 ^ t2)) ^ ((t3 ^ t4) ^ (t5 ^ (x4 ^ x2)))) ^ 0xffffffffffffffff);
        s11 = ((((x3 ^ x2) ^ (x0 ^ t1)) ^ ((t2 ^ t15) ^ (t4 ^ t16))) ^ 0xffffffffffffffff);
        s12 = (((t3 ^ t15) ^ (t4 ^ t25)) ^ ((t16 ^ t5) ^ ((x2 ^ x0) ^ (t0 ^ t1))));
        s13 = ((((x4 ^ x3) ^ (x1 ^ x0)) ^ ((t4 ^ (x0 & x3)) ^ (t16 ^ t5))) ^ 0xffffffffffffffff);
        s14 = (((x1 ^ x0) ^ (t3 ^ t15)) ^ ((t4 ^ t25) ^ (t5 ^ (x4 ^ x2))));
        x0 = s20;
        x1 = s21;
        x2 = s22;
        x3 = s23;
        x4 = s24;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t25 = (x0 & x4);
        s20 = ((((x0 ^ t0) ^ (t1 ^ t2)) ^ ((t3 ^ t4) ^ (t5 ^ (x4 ^ x2)))) ^ 0xffffffffffffffff);
        s21 = ((((x3 ^ x2) ^ (x0 ^ t1)) ^ ((t2 ^ t15) ^ (t4 ^ t16))) ^ 0xffffffffffffffff);
        s22 = (((t3 ^ t15) ^ (t4 ^ t25)) ^ ((t16 ^ t5) ^ ((x2 ^ x0) ^ (t0 ^ t1))));
        s23 = ((((x4 ^ x3) ^ (x1 ^ x0)) ^ ((t4 ^ (x0 & x3)) ^ (t16 ^ t5))) ^ 0xffffffffffffffff);
        s24 = (((x1 ^ x0) ^ (t3 ^ t15)) ^ ((t4 ^ t25) ^ (t5 ^ (x4 ^ x2))));
        uint64_t o2 = (((s02 ^ s10) ^ (s11 ^ s12)) ^ ((s14 ^ s20) ^ s00));
        uint64_t o3 = (((s03 ^ s11) ^ (s12 ^ s13)) ^ ((s20 ^ s21) ^ s01));
        uint64_t o4 = (((s04 ^ s12) ^ (s13 ^ s14)) ^ ((s21 ^ s22) ^ s02));
        uint64_t o5 = (((s10 ^ s13) ^ (s14 ^ s20)) ^ ((s22 ^ s23) ^ s03));
        uint64_t o6 = (((s11 ^ s14) ^ (s20 ^ s21)) ^ ((s23 ^ s24) ^ s04));
        uint64_t o7 = (((s12 ^ s20) ^ (s21 ^ s22)) ^ ((s24 ^ s00) ^ s10));
        uint64_t o8 = (((s13 ^ s21) ^ (s22 ^ s23)) ^ ((s00 ^ s01) ^ s11));
        uint64_t o9 = (((s14 ^ s22) ^ (s23 ^ s24)) ^ ((s01 ^ s02) ^ s12));
        uint64_t o10 = (((s20 ^ s23) ^ (s24 ^ s00)) ^ ((s02 ^ s03) ^ s13));
        uint64_t o11 = (((s21 ^ s24) ^ (s00 ^ s01)) ^ ((s03 ^ s04) ^ s14));
        uint64_t o12 = (((s22 ^ s00) ^ (s01 ^ s02)) ^ ((s04 ^ s10) ^ s20));
        uint64_t o13 = (((s23 ^ s01) ^ (s02 ^ s03)) ^ ((s10 ^ s11) ^ s21));
        uint64_t o14 = (((s24 ^ s02) ^ (s03 ^ s04)) ^ ((s11 ^ s12) ^ s22));
        s00 = (((s00 ^ s03) ^ (s04 ^ s10)) ^ ((s12 ^ s13) ^ s23));
        s01 = (((s01 ^ s04) ^ (s10 ^ s11)) ^ ((s13 ^ s14) ^ s24));
        s02 = o2;
        s03 = o3;
        s04 = o4;
        s10 = o5;
        s11 = o6;
        s12 = o7;
        s13 = o8;
        s14 = o9;
        s20 = o10;
        s21 = o11;
        s22 = o12;
        s23 = o13;
        s24 = o14;
        s00 = (s00 ^ rc);
        s00 = ((ror64(s00, 0) ^ ror64(s00, 43)) ^ ror64(s00, 21));
        s01 = ((ror64(s01, 63) ^ ror64(s01, 42)) ^ ror64(s01, 20));
        s02 = ((ror64(s02, 62) ^ ror64(s02, 41)) ^ ror64(s02, 19));
        s03 = ((ror64(s03, 61) ^ ror64(s03, 40)) ^ ror64(s03, 18));
        s04 = ((ror64(s04, 60) ^ ror64(s04, 39)) ^ ror64(s04, 17));
        s10 = ((ror64(s10, 59) ^ ror64(s10, 38)) ^ ror64(s10, 16));
        s11 = ((ror64(s11, 58) ^ ror64(s11, 37)) ^ ror64(s11, 15));
        s12 = ((ror64(s12, 57) ^ ror64(s12, 36)) ^ ror64(s12, 14));
        s13 = ((ror64(s13, 56) ^ ror64(s13, 35)) ^ ror64(s13, 13));
        s14 = ((ror64(s14, 55) ^ ror64(s14, 34)) ^ ror64(s14, 12));
        s20 = ((ror64(s20, 54) ^ ror64(s20, 33)) ^ ror64(s20, 11));
        s21 = ((ror64(s21, 53) ^ ror64(s21, 32)) ^ ror64(s21, 10));
        s22 = ((ror64(s22, 52) ^ ror64(s22, 31)) ^ ror64(s22, 9));
        s23 = ((ror64(s23, 51) ^ ror64(s23, 30)) ^ ror64(s23, 8));
        s24 = ((ror64(s24, 50) ^ ror64(s24, 29)) ^ ror64(s24, 7));
    }

    p[0] = s00;
    p[1] = s01;
    p[2] = s02;
    p[3] = s03;
    p[4] = s04;
    p[5] = s10;
    p[6] = s11;
    p[7] = s12;
    p[8] = s13;
    p[9] = s14;
    p[10] = s20;
    p[11] = s21;
    p[12] = s22;
    p[13] = s23;
    p[14] = s24;
}

 void duet_p(uint64_t *p) {
    /* 状态常驻 5 个行向量 R0..R4；槽 lane 存该 lane 的一个状态字 */
    __m256i R0 = _mm256_set_epi64x(0, (long long)p[10], (long long)p[5], (long long)p[0]);
    __m256i R1 = _mm256_set_epi64x(0, (long long)p[11], (long long)p[6], (long long)p[1]);
    __m256i R2 = _mm256_set_epi64x(0, (long long)p[12], (long long)p[7], (long long)p[2]);
    __m256i R3 = _mm256_set_epi64x(0, (long long)p[13], (long long)p[8], (long long)p[3]);
    __m256i R4 = _mm256_set_epi64x(0, (long long)p[14], (long long)p[9], (long long)p[4]);

    for (int r = 0; r < 12; r++) {
        const uint64_t rc = DUET_P_RC[r];

        /* [1] lane 块：只发一块，逐 lane 同时算完 3 个 lane */
        __m256i T_x0 = R0;
        __m256i T_x1 = R1;
        __m256i T_x2 = R2;
        __m256i T_x3 = R3;
        __m256i T_x4 = R4;
        __m256i T_t0 = _mm256_and_si256(T_x3, T_x4);
        __m256i T_t1 = _mm256_and_si256(T_x2, T_x4);
        __m256i T_t2 = _mm256_and_si256(T_x2, T_x3);
        __m256i T_t3 = _mm256_and_si256(T_x1, T_x4);
        __m256i T_t4 = _mm256_and_si256(T_x1, T_x2);
        __m256i T_t5 = _mm256_and_si256(T_x0, T_x1);
        __m256i T_t15 = _mm256_and_si256(T_x1, T_x3);
        __m256i T_t16 = _mm256_and_si256(T_x0, T_x2);
        __m256i T_t25 = _mm256_and_si256(T_x0, T_x4);
        R0 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x0, T_t0), _mm256_xor_si256(T_t1, T_t2)), _mm256_xor_si256(_mm256_xor_si256(T_t3, T_t4), _mm256_xor_si256(T_t5, _mm256_xor_si256(T_x4, T_x2)))), _mm256_set1_epi64x((long long)0xffffffffffffffffULL));
        R1 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x3, T_x2), _mm256_xor_si256(T_x0, T_t1)), _mm256_xor_si256(_mm256_xor_si256(T_t2, T_t15), _mm256_xor_si256(T_t4, T_t16))), _mm256_set1_epi64x((long long)0xffffffffffffffffULL));
        R2 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_t3, T_t15), _mm256_xor_si256(T_t4, T_t25)), _mm256_xor_si256(_mm256_xor_si256(T_t16, T_t5), _mm256_xor_si256(_mm256_xor_si256(T_x2, T_x0), _mm256_xor_si256(T_t0, T_t1))));
        R3 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x4, T_x3), _mm256_xor_si256(T_x1, T_x0)), _mm256_xor_si256(_mm256_xor_si256(T_t4, _mm256_and_si256(T_x0, T_x3)), _mm256_xor_si256(T_t16, T_t5))), _mm256_set1_epi64x((long long)0xffffffffffffffffULL));
        R4 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x1, T_x0), _mm256_xor_si256(T_t3, T_t15)), _mm256_xor_si256(_mm256_xor_si256(T_t4, T_t25), _mm256_xor_si256(T_t5, _mm256_xor_si256(T_x4, T_x2))));

        /* [2] 行扩散层：整轮留在向量里（原来要卸回 15 个标量） */
        __m256i N0 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R0, R3), R4), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 1, 0, 2)));
        __m256i N1 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R1, R4), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 1, 0, 2)));
        __m256i N2 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R2, _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 1, 0, 2))), R0);
        __m256i N3 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R3, _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 1, 0, 2))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 1, 0, 2))), R1);
        __m256i N4 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R4, _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 1, 0, 2))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 1, 0, 2))), R2);
        R0 = N0;
        R1 = N1;
        R2 = N2;
        R3 = N3;
        R4 = N4;

        /* [3] 轮常量只混入 lane0 的那一个字 */
        R0 = _mm256_xor_si256(R0, _mm256_set_epi64x(0, 0, 0, (long long)rc));

        /* [4] 旋转层：y = ror(x, base)；out = y ^ ror(y,21) ^ ror(y,43) */
        /*     相对量恒 (21,43)，基旋转逐 lane 不同 ⇒ 用变量移位施加 */
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R0, _mm256_set_epi64x((long long)0, (long long)54, (long long)59, (long long)0)),
              _mm256_sllv_epi64(R0, _mm256_set_epi64x((long long)0, (long long)10, (long long)5, (long long)0)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R0 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R1, _mm256_set_epi64x((long long)0, (long long)53, (long long)58, (long long)63)),
              _mm256_sllv_epi64(R1, _mm256_set_epi64x((long long)0, (long long)11, (long long)6, (long long)1)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R1 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R2, _mm256_set_epi64x((long long)0, (long long)52, (long long)57, (long long)62)),
              _mm256_sllv_epi64(R2, _mm256_set_epi64x((long long)0, (long long)12, (long long)7, (long long)2)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R2 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R3, _mm256_set_epi64x((long long)0, (long long)51, (long long)56, (long long)61)),
              _mm256_sllv_epi64(R3, _mm256_set_epi64x((long long)0, (long long)13, (long long)8, (long long)3)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R3 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R4, _mm256_set_epi64x((long long)0, (long long)50, (long long)55, (long long)60)),
              _mm256_sllv_epi64(R4, _mm256_set_epi64x((long long)0, (long long)14, (long long)9, (long long)4)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R4 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
    }

    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R0);
      p[0] = t[0];
      p[5] = t[1];
      p[10] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R1);
      p[1] = t[0];
      p[6] = t[1];
      p[11] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R2);
      p[2] = t[0];
      p[7] = t[1];
      p[12] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R3);
      p[3] = t[0];
      p[8] = t[1];
      p[13] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R4);
      p[4] = t[0];
      p[9] = t[1];
      p[14] = t[2];
    }
}

/* duet_p2 ← alg/h08/agent_f2.jir：208 条改写，体内 101 条，3 lane × 3 块 */
static const uint64_t DUET_P2_RC[12] = {
    0xba7c9045f12c7f99ULL, 0x24a19947b3916cf7ULL, 0x0801f2e2858efc16ULL, 0x636920d871574e69ULL, 0xa458fea3f4933d7eULL, 0x0d95748f728eb658ULL, 0x718bcd5882154aeeULL, 0x7b54a41dc25a59b5ULL, 0x9c30d5392af26013ULL, 0xc5d1b023286085f0ULL, 0xca417918b8db38efULL, 0x8e79dcb0603a180eULL,
};

static void duet_p2_orig(uint64_t *p) {
    uint64_t s00 = p[0];
    uint64_t s01 = p[1];
    uint64_t s02 = p[2];
    uint64_t s03 = p[3];
    uint64_t s04 = p[4];
    uint64_t s10 = p[5];
    uint64_t s11 = p[6];
    uint64_t s12 = p[7];
    uint64_t s13 = p[8];
    uint64_t s14 = p[9];
    uint64_t s20 = p[10];
    uint64_t s21 = p[11];
    uint64_t s22 = p[12];
    uint64_t s23 = p[13];
    uint64_t s24 = p[14];

    for (int r = 0; r < 12; r++) {
        const uint64_t rc = DUET_P2_RC[r];
        uint64_t x0 = s00;
        uint64_t x1 = s01;
        uint64_t x2 = s02;
        uint64_t x3 = s03;
        uint64_t x4 = s04;
        uint64_t t0 = (x3 & x4);
        uint64_t t1 = (x2 & x4);
        uint64_t t2 = (x2 & x3);
        uint64_t t3 = (x1 & x4);
        uint64_t t4 = (x1 & x2);
        uint64_t t5 = (x0 & x1);
        uint64_t t6 = (x4 ^ x2);
        uint64_t t7 = (x0 ^ t0);
        uint64_t t8 = (t1 ^ t2);
        uint64_t t9 = (t3 ^ t4);
        uint64_t t10 = (t5 ^ t6);
        uint64_t t11 = (t7 ^ t8);
        uint64_t t12 = (t9 ^ t10);
        uint64_t t13 = (t11 ^ t12);
        uint64_t t14 = (t13 ^ 0xffffffffffffffff);
        uint64_t t15 = (x1 & x3);
        uint64_t t16 = (x0 & x2);
        uint64_t t17 = (x3 ^ x2);
        uint64_t t18 = (x0 ^ t1);
        uint64_t t19 = (t2 ^ t15);
        uint64_t t20 = (t4 ^ t16);
        uint64_t t21 = (t17 ^ t18);
        uint64_t t22 = (t19 ^ t20);
        uint64_t t23 = (t21 ^ t22);
        uint64_t t24 = (t23 ^ 0xffffffffffffffff);
        uint64_t t25 = (x0 & x4);
        uint64_t t26 = (x2 ^ x0);
        uint64_t t27 = (t0 ^ t1);
        uint64_t t28 = (t3 ^ t15);
        uint64_t t29 = (t4 ^ t25);
        uint64_t t30 = (t16 ^ t5);
        uint64_t t31 = (t26 ^ t27);
        uint64_t t32 = (t28 ^ t29);
        uint64_t t33 = (t30 ^ t31);
        uint64_t t34 = (t32 ^ t33);
        uint64_t t35 = (x0 & x3);
        uint64_t t36 = (x4 ^ x3);
        uint64_t t37 = (x1 ^ x0);
        uint64_t t38 = (t4 ^ t35);
        uint64_t t39 = (t16 ^ t5);
        uint64_t t40 = (t36 ^ t37);
        uint64_t t41 = (t38 ^ t39);
        uint64_t t42 = (t40 ^ t41);
        uint64_t t43 = (t42 ^ 0xffffffffffffffff);
        uint64_t t44 = (x4 ^ x2);
        uint64_t t45 = (x1 ^ x0);
        uint64_t t46 = (t3 ^ t15);
        uint64_t t47 = (t4 ^ t25);
        uint64_t t48 = (t5 ^ t44);
        uint64_t t49 = (t45 ^ t46);
        uint64_t t50 = (t47 ^ t48);
        uint64_t t51 = (t49 ^ t50);
        s00 = t14;
        s01 = t24;
        s02 = t34;
        s03 = t43;
        s04 = t51;
        x0 = s10;
        x1 = s11;
        x2 = s12;
        x3 = s13;
        x4 = s14;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t6 = (x4 ^ x2);
        t7 = (x0 ^ t0);
        t8 = (t1 ^ t2);
        t9 = (t3 ^ t4);
        t10 = (t5 ^ t6);
        t11 = (t7 ^ t8);
        t12 = (t9 ^ t10);
        t13 = (t11 ^ t12);
        t14 = (t13 ^ 0xffffffffffffffff);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t17 = (x3 ^ x2);
        t18 = (x0 ^ t1);
        t19 = (t2 ^ t15);
        t20 = (t4 ^ t16);
        t21 = (t17 ^ t18);
        t22 = (t19 ^ t20);
        t23 = (t21 ^ t22);
        t24 = (t23 ^ 0xffffffffffffffff);
        t25 = (x0 & x4);
        t26 = (x2 ^ x0);
        t27 = (t0 ^ t1);
        t28 = (t3 ^ t15);
        t29 = (t4 ^ t25);
        t30 = (t16 ^ t5);
        t31 = (t26 ^ t27);
        t32 = (t28 ^ t29);
        t33 = (t30 ^ t31);
        t34 = (t32 ^ t33);
        t35 = (x0 & x3);
        t36 = (x4 ^ x3);
        t37 = (x1 ^ x0);
        t38 = (t4 ^ t35);
        t39 = (t16 ^ t5);
        t40 = (t36 ^ t37);
        t41 = (t38 ^ t39);
        t42 = (t40 ^ t41);
        t43 = (t42 ^ 0xffffffffffffffff);
        t44 = (x4 ^ x2);
        t45 = (x1 ^ x0);
        t46 = (t3 ^ t15);
        t47 = (t4 ^ t25);
        t48 = (t5 ^ t44);
        t49 = (t45 ^ t46);
        t50 = (t47 ^ t48);
        t51 = (t49 ^ t50);
        s10 = t14;
        s11 = t24;
        s12 = t34;
        s13 = t43;
        s14 = t51;
        x0 = s20;
        x1 = s21;
        x2 = s22;
        x3 = s23;
        x4 = s24;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t6 = (x4 ^ x2);
        t7 = (x0 ^ t0);
        t8 = (t1 ^ t2);
        t9 = (t3 ^ t4);
        t10 = (t5 ^ t6);
        t11 = (t7 ^ t8);
        t12 = (t9 ^ t10);
        t13 = (t11 ^ t12);
        t14 = (t13 ^ 0xffffffffffffffff);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t17 = (x3 ^ x2);
        t18 = (x0 ^ t1);
        t19 = (t2 ^ t15);
        t20 = (t4 ^ t16);
        t21 = (t17 ^ t18);
        t22 = (t19 ^ t20);
        t23 = (t21 ^ t22);
        t24 = (t23 ^ 0xffffffffffffffff);
        t25 = (x0 & x4);
        t26 = (x2 ^ x0);
        t27 = (t0 ^ t1);
        t28 = (t3 ^ t15);
        t29 = (t4 ^ t25);
        t30 = (t16 ^ t5);
        t31 = (t26 ^ t27);
        t32 = (t28 ^ t29);
        t33 = (t30 ^ t31);
        t34 = (t32 ^ t33);
        t35 = (x0 & x3);
        t36 = (x4 ^ x3);
        t37 = (x1 ^ x0);
        t38 = (t4 ^ t35);
        t39 = (t16 ^ t5);
        t40 = (t36 ^ t37);
        t41 = (t38 ^ t39);
        t42 = (t40 ^ t41);
        t43 = (t42 ^ 0xffffffffffffffff);
        t44 = (x4 ^ x2);
        t45 = (x1 ^ x0);
        t46 = (t3 ^ t15);
        t47 = (t4 ^ t25);
        t48 = (t5 ^ t44);
        t49 = (t45 ^ t46);
        t50 = (t47 ^ t48);
        t51 = (t49 ^ t50);
        s20 = t14;
        s21 = t24;
        s22 = t34;
        s23 = t43;
        s24 = t51;
        uint64_t n0 = (s00 ^ s03);
        uint64_t n1 = (s04 ^ s10);
        uint64_t n2 = (s12 ^ s13);
        uint64_t n3 = (n0 ^ n1);
        uint64_t n4 = (n2 ^ s23);
        uint64_t o0 = (n3 ^ n4);
        n0 = (s01 ^ s04);
        n1 = (s10 ^ s11);
        n2 = (s13 ^ s14);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s24);
        uint64_t o1 = (n3 ^ n4);
        n0 = (s02 ^ s10);
        n1 = (s11 ^ s12);
        n2 = (s14 ^ s20);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s00);
        uint64_t o2 = (n3 ^ n4);
        n0 = (s03 ^ s11);
        n1 = (s12 ^ s13);
        n2 = (s20 ^ s21);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s01);
        uint64_t o3 = (n3 ^ n4);
        n0 = (s04 ^ s12);
        n1 = (s13 ^ s14);
        n2 = (s21 ^ s22);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s02);
        uint64_t o4 = (n3 ^ n4);
        n0 = (s10 ^ s13);
        n1 = (s14 ^ s20);
        n2 = (s22 ^ s23);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s03);
        uint64_t o5 = (n3 ^ n4);
        n0 = (s11 ^ s14);
        n1 = (s20 ^ s21);
        n2 = (s23 ^ s24);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s04);
        uint64_t o6 = (n3 ^ n4);
        n0 = (s12 ^ s20);
        n1 = (s21 ^ s22);
        n2 = (s24 ^ s00);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s10);
        uint64_t o7 = (n3 ^ n4);
        n0 = (s13 ^ s21);
        n1 = (s22 ^ s23);
        n2 = (s00 ^ s01);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s11);
        uint64_t o8 = (n3 ^ n4);
        n0 = (s14 ^ s22);
        n1 = (s23 ^ s24);
        n2 = (s01 ^ s02);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s12);
        uint64_t o9 = (n3 ^ n4);
        n0 = (s20 ^ s23);
        n1 = (s24 ^ s00);
        n2 = (s02 ^ s03);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s13);
        uint64_t o10 = (n3 ^ n4);
        n0 = (s21 ^ s24);
        n1 = (s00 ^ s01);
        n2 = (s03 ^ s04);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s14);
        uint64_t o11 = (n3 ^ n4);
        n0 = (s22 ^ s00);
        n1 = (s01 ^ s02);
        n2 = (s04 ^ s10);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s20);
        uint64_t o12 = (n3 ^ n4);
        n0 = (s23 ^ s01);
        n1 = (s02 ^ s03);
        n2 = (s10 ^ s11);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s21);
        uint64_t o13 = (n3 ^ n4);
        n0 = (s24 ^ s02);
        n1 = (s03 ^ s04);
        n2 = (s11 ^ s12);
        n3 = (n0 ^ n1);
        n4 = (n2 ^ s22);
        uint64_t o14 = (n3 ^ n4);
        s00 = o0;
        s01 = o1;
        s02 = o2;
        s03 = o3;
        s04 = o4;
        s10 = o5;
        s11 = o6;
        s12 = o7;
        s13 = o8;
        s14 = o9;
        s20 = o10;
        s21 = o11;
        s22 = o12;
        s23 = o13;
        s24 = o14;
        s00 = (s00 ^ rc);
        s00 = ((ror64(s00, 0) ^ ror64(s00, 43)) ^ ror64(s00, 21));
        s01 = ((ror64(s01, 63) ^ ror64(s01, 42)) ^ ror64(s01, 20));
        s02 = ((ror64(s02, 62) ^ ror64(s02, 41)) ^ ror64(s02, 19));
        s03 = ((ror64(s03, 61) ^ ror64(s03, 40)) ^ ror64(s03, 18));
        s04 = ((ror64(s04, 60) ^ ror64(s04, 39)) ^ ror64(s04, 17));
        s10 = ((ror64(s10, 59) ^ ror64(s10, 38)) ^ ror64(s10, 16));
        s11 = ((ror64(s11, 58) ^ ror64(s11, 37)) ^ ror64(s11, 15));
        s12 = ((ror64(s12, 57) ^ ror64(s12, 36)) ^ ror64(s12, 14));
        s13 = ((ror64(s13, 56) ^ ror64(s13, 35)) ^ ror64(s13, 13));
        s14 = ((ror64(s14, 55) ^ ror64(s14, 34)) ^ ror64(s14, 12));
        s20 = ((ror64(s20, 54) ^ ror64(s20, 33)) ^ ror64(s20, 11));
        s21 = ((ror64(s21, 53) ^ ror64(s21, 32)) ^ ror64(s21, 10));
        s22 = ((ror64(s22, 52) ^ ror64(s22, 31)) ^ ror64(s22, 9));
        s23 = ((ror64(s23, 51) ^ ror64(s23, 30)) ^ ror64(s23, 8));
        s24 = ((ror64(s24, 50) ^ ror64(s24, 29)) ^ ror64(s24, 7));
    }

    p[0] = s00;
    p[1] = s01;
    p[2] = s02;
    p[3] = s03;
    p[4] = s04;
    p[5] = s10;
    p[6] = s11;
    p[7] = s12;
    p[8] = s13;
    p[9] = s14;
    p[10] = s20;
    p[11] = s21;
    p[12] = s22;
    p[13] = s23;
    p[14] = s24;
}

static void duet_p2_ref(uint64_t *p) {
    uint64_t s00 = p[0];
    uint64_t s01 = p[1];
    uint64_t s02 = p[2];
    uint64_t s03 = p[3];
    uint64_t s04 = p[4];
    uint64_t s10 = p[5];
    uint64_t s11 = p[6];
    uint64_t s12 = p[7];
    uint64_t s13 = p[8];
    uint64_t s14 = p[9];
    uint64_t s20 = p[10];
    uint64_t s21 = p[11];
    uint64_t s22 = p[12];
    uint64_t s23 = p[13];
    uint64_t s24 = p[14];

    for (int r = 0; r < 12; r++) {
        const uint64_t rc = DUET_P2_RC[r];
        uint64_t x0 = s00;
        uint64_t x1 = s01;
        uint64_t x2 = s02;
        uint64_t x3 = s03;
        uint64_t x4 = s04;
        uint64_t t0 = (x3 & x4);
        uint64_t t1 = (x2 & x4);
        uint64_t t2 = (x2 & x3);
        uint64_t t3 = (x1 & x4);
        uint64_t t4 = (x1 & x2);
        uint64_t t5 = (x0 & x1);
        uint64_t t15 = (x1 & x3);
        uint64_t t16 = (x0 & x2);
        uint64_t t25 = (x0 & x4);
        s00 = ((((x0 ^ t0) ^ (t1 ^ t2)) ^ ((t3 ^ t4) ^ (t5 ^ (x4 ^ x2)))) ^ 0xffffffffffffffff);
        s01 = ((((x3 ^ x2) ^ (x0 ^ t1)) ^ ((t2 ^ t15) ^ (t4 ^ t16))) ^ 0xffffffffffffffff);
        s02 = (((t3 ^ t15) ^ (t4 ^ t25)) ^ ((t16 ^ t5) ^ ((x2 ^ x0) ^ (t0 ^ t1))));
        s03 = ((((x4 ^ x3) ^ (x1 ^ x0)) ^ ((t4 ^ (x0 & x3)) ^ (t16 ^ t5))) ^ 0xffffffffffffffff);
        s04 = (((x1 ^ x0) ^ (t3 ^ t15)) ^ ((t4 ^ t25) ^ (t5 ^ (x4 ^ x2))));
        x0 = s10;
        x1 = s11;
        x2 = s12;
        x3 = s13;
        x4 = s14;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t25 = (x0 & x4);
        s10 = ((((x0 ^ t0) ^ (t1 ^ t2)) ^ ((t3 ^ t4) ^ (t5 ^ (x4 ^ x2)))) ^ 0xffffffffffffffff);
        s11 = ((((x3 ^ x2) ^ (x0 ^ t1)) ^ ((t2 ^ t15) ^ (t4 ^ t16))) ^ 0xffffffffffffffff);
        s12 = (((t3 ^ t15) ^ (t4 ^ t25)) ^ ((t16 ^ t5) ^ ((x2 ^ x0) ^ (t0 ^ t1))));
        s13 = ((((x4 ^ x3) ^ (x1 ^ x0)) ^ ((t4 ^ (x0 & x3)) ^ (t16 ^ t5))) ^ 0xffffffffffffffff);
        s14 = (((x1 ^ x0) ^ (t3 ^ t15)) ^ ((t4 ^ t25) ^ (t5 ^ (x4 ^ x2))));
        x0 = s20;
        x1 = s21;
        x2 = s22;
        x3 = s23;
        x4 = s24;
        t0 = (x3 & x4);
        t1 = (x2 & x4);
        t2 = (x2 & x3);
        t3 = (x1 & x4);
        t4 = (x1 & x2);
        t5 = (x0 & x1);
        t15 = (x1 & x3);
        t16 = (x0 & x2);
        t25 = (x0 & x4);
        s20 = ((((x0 ^ t0) ^ (t1 ^ t2)) ^ ((t3 ^ t4) ^ (t5 ^ (x4 ^ x2)))) ^ 0xffffffffffffffff);
        s21 = ((((x3 ^ x2) ^ (x0 ^ t1)) ^ ((t2 ^ t15) ^ (t4 ^ t16))) ^ 0xffffffffffffffff);
        s22 = (((t3 ^ t15) ^ (t4 ^ t25)) ^ ((t16 ^ t5) ^ ((x2 ^ x0) ^ (t0 ^ t1))));
        s23 = ((((x4 ^ x3) ^ (x1 ^ x0)) ^ ((t4 ^ (x0 & x3)) ^ (t16 ^ t5))) ^ 0xffffffffffffffff);
        s24 = (((x1 ^ x0) ^ (t3 ^ t15)) ^ ((t4 ^ t25) ^ (t5 ^ (x4 ^ x2))));
        uint64_t o2 = (((s02 ^ s10) ^ (s11 ^ s12)) ^ ((s14 ^ s20) ^ s00));
        uint64_t o3 = (((s03 ^ s11) ^ (s12 ^ s13)) ^ ((s20 ^ s21) ^ s01));
        uint64_t o4 = (((s04 ^ s12) ^ (s13 ^ s14)) ^ ((s21 ^ s22) ^ s02));
        uint64_t o5 = (((s10 ^ s13) ^ (s14 ^ s20)) ^ ((s22 ^ s23) ^ s03));
        uint64_t o6 = (((s11 ^ s14) ^ (s20 ^ s21)) ^ ((s23 ^ s24) ^ s04));
        uint64_t o7 = (((s12 ^ s20) ^ (s21 ^ s22)) ^ ((s24 ^ s00) ^ s10));
        uint64_t o8 = (((s13 ^ s21) ^ (s22 ^ s23)) ^ ((s00 ^ s01) ^ s11));
        uint64_t o9 = (((s14 ^ s22) ^ (s23 ^ s24)) ^ ((s01 ^ s02) ^ s12));
        uint64_t o10 = (((s20 ^ s23) ^ (s24 ^ s00)) ^ ((s02 ^ s03) ^ s13));
        uint64_t o11 = (((s21 ^ s24) ^ (s00 ^ s01)) ^ ((s03 ^ s04) ^ s14));
        uint64_t o12 = (((s22 ^ s00) ^ (s01 ^ s02)) ^ ((s04 ^ s10) ^ s20));
        uint64_t o13 = (((s23 ^ s01) ^ (s02 ^ s03)) ^ ((s10 ^ s11) ^ s21));
        uint64_t o14 = (((s24 ^ s02) ^ (s03 ^ s04)) ^ ((s11 ^ s12) ^ s22));
        s00 = (((s00 ^ s03) ^ (s04 ^ s10)) ^ ((s12 ^ s13) ^ s23));
        s01 = (((s01 ^ s04) ^ (s10 ^ s11)) ^ ((s13 ^ s14) ^ s24));
        s02 = o2;
        s03 = o3;
        s04 = o4;
        s10 = o5;
        s11 = o6;
        s12 = o7;
        s13 = o8;
        s14 = o9;
        s20 = o10;
        s21 = o11;
        s22 = o12;
        s23 = o13;
        s24 = o14;
        s00 = (s00 ^ rc);
        s00 = ((ror64(s00, 0) ^ ror64(s00, 43)) ^ ror64(s00, 21));
        s01 = ((ror64(s01, 63) ^ ror64(s01, 42)) ^ ror64(s01, 20));
        s02 = ((ror64(s02, 62) ^ ror64(s02, 41)) ^ ror64(s02, 19));
        s03 = ((ror64(s03, 61) ^ ror64(s03, 40)) ^ ror64(s03, 18));
        s04 = ((ror64(s04, 60) ^ ror64(s04, 39)) ^ ror64(s04, 17));
        s10 = ((ror64(s10, 59) ^ ror64(s10, 38)) ^ ror64(s10, 16));
        s11 = ((ror64(s11, 58) ^ ror64(s11, 37)) ^ ror64(s11, 15));
        s12 = ((ror64(s12, 57) ^ ror64(s12, 36)) ^ ror64(s12, 14));
        s13 = ((ror64(s13, 56) ^ ror64(s13, 35)) ^ ror64(s13, 13));
        s14 = ((ror64(s14, 55) ^ ror64(s14, 34)) ^ ror64(s14, 12));
        s20 = ((ror64(s20, 54) ^ ror64(s20, 33)) ^ ror64(s20, 11));
        s21 = ((ror64(s21, 53) ^ ror64(s21, 32)) ^ ror64(s21, 10));
        s22 = ((ror64(s22, 52) ^ ror64(s22, 31)) ^ ror64(s22, 9));
        s23 = ((ror64(s23, 51) ^ ror64(s23, 30)) ^ ror64(s23, 8));
        s24 = ((ror64(s24, 50) ^ ror64(s24, 29)) ^ ror64(s24, 7));
    }

    p[0] = s00;
    p[1] = s01;
    p[2] = s02;
    p[3] = s03;
    p[4] = s04;
    p[5] = s10;
    p[6] = s11;
    p[7] = s12;
    p[8] = s13;
    p[9] = s14;
    p[10] = s20;
    p[11] = s21;
    p[12] = s22;
    p[13] = s23;
    p[14] = s24;
}

 void duet_p2(uint64_t *p) {
    /* 状态常驻 5 个行向量 R0..R4；槽 lane 存该 lane 的一个状态字 */
    __m256i R0 = _mm256_set_epi64x(0, (long long)p[10], (long long)p[5], (long long)p[0]);
    __m256i R1 = _mm256_set_epi64x(0, (long long)p[11], (long long)p[6], (long long)p[1]);
    __m256i R2 = _mm256_set_epi64x(0, (long long)p[12], (long long)p[7], (long long)p[2]);
    __m256i R3 = _mm256_set_epi64x(0, (long long)p[13], (long long)p[8], (long long)p[3]);
    __m256i R4 = _mm256_set_epi64x(0, (long long)p[14], (long long)p[9], (long long)p[4]);

    for (int r = 0; r < 12; r++) {
        const uint64_t rc = DUET_P2_RC[r];

        /* [1] lane 块：只发一块，逐 lane 同时算完 3 个 lane */
        __m256i T_x0 = R0;
        __m256i T_x1 = R1;
        __m256i T_x2 = R2;
        __m256i T_x3 = R3;
        __m256i T_x4 = R4;
        __m256i T_t0 = _mm256_and_si256(T_x3, T_x4);
        __m256i T_t1 = _mm256_and_si256(T_x2, T_x4);
        __m256i T_t2 = _mm256_and_si256(T_x2, T_x3);
        __m256i T_t3 = _mm256_and_si256(T_x1, T_x4);
        __m256i T_t4 = _mm256_and_si256(T_x1, T_x2);
        __m256i T_t5 = _mm256_and_si256(T_x0, T_x1);
        __m256i T_t15 = _mm256_and_si256(T_x1, T_x3);
        __m256i T_t16 = _mm256_and_si256(T_x0, T_x2);
        __m256i T_t25 = _mm256_and_si256(T_x0, T_x4);
        R0 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x0, T_t0), _mm256_xor_si256(T_t1, T_t2)), _mm256_xor_si256(_mm256_xor_si256(T_t3, T_t4), _mm256_xor_si256(T_t5, _mm256_xor_si256(T_x4, T_x2)))), _mm256_set1_epi64x((long long)0xffffffffffffffffULL));
        R1 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x3, T_x2), _mm256_xor_si256(T_x0, T_t1)), _mm256_xor_si256(_mm256_xor_si256(T_t2, T_t15), _mm256_xor_si256(T_t4, T_t16))), _mm256_set1_epi64x((long long)0xffffffffffffffffULL));
        R2 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_t3, T_t15), _mm256_xor_si256(T_t4, T_t25)), _mm256_xor_si256(_mm256_xor_si256(T_t16, T_t5), _mm256_xor_si256(_mm256_xor_si256(T_x2, T_x0), _mm256_xor_si256(T_t0, T_t1))));
        R3 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x4, T_x3), _mm256_xor_si256(T_x1, T_x0)), _mm256_xor_si256(_mm256_xor_si256(T_t4, _mm256_and_si256(T_x0, T_x3)), _mm256_xor_si256(T_t16, T_t5))), _mm256_set1_epi64x((long long)0xffffffffffffffffULL));
        R4 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(T_x1, T_x0), _mm256_xor_si256(T_t3, T_t15)), _mm256_xor_si256(_mm256_xor_si256(T_t4, T_t25), _mm256_xor_si256(T_t5, _mm256_xor_si256(T_x4, T_x2))));

        /* [2] 行扩散层：整轮留在向量里（原来要卸回 15 个标量） */
        __m256i N0 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R0, R3), R4), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 1, 0, 2)));
        __m256i N1 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R1, R4), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 1, 0, 2)));
        __m256i N2 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R2, _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 1, 0, 2))), R0);
        __m256i N3 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R3, _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R0, _MM_SHUFFLE(3, 1, 0, 2))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 1, 0, 2))), R1);
        __m256i N4 = _mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(_mm256_xor_si256(R4, _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R3, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R4, _MM_SHUFFLE(3, 0, 2, 1))), _mm256_permute4x64_epi64(R1, _MM_SHUFFLE(3, 1, 0, 2))), _mm256_permute4x64_epi64(R2, _MM_SHUFFLE(3, 1, 0, 2))), R2);
        R0 = N0;
        R1 = N1;
        R2 = N2;
        R3 = N3;
        R4 = N4;

        /* [3] 轮常量只混入 lane0 的那一个字 */
        R0 = _mm256_xor_si256(R0, _mm256_set_epi64x(0, 0, 0, (long long)rc));

        /* [4] 旋转层：y = ror(x, base)；out = y ^ ror(y,21) ^ ror(y,43) */
        /*     相对量恒 (21,43)，基旋转逐 lane 不同 ⇒ 用变量移位施加 */
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R0, _mm256_set_epi64x((long long)0, (long long)54, (long long)59, (long long)0)),
              _mm256_sllv_epi64(R0, _mm256_set_epi64x((long long)0, (long long)10, (long long)5, (long long)0)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R0 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R1, _mm256_set_epi64x((long long)0, (long long)53, (long long)58, (long long)63)),
              _mm256_sllv_epi64(R1, _mm256_set_epi64x((long long)0, (long long)11, (long long)6, (long long)1)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R1 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R2, _mm256_set_epi64x((long long)0, (long long)52, (long long)57, (long long)62)),
              _mm256_sllv_epi64(R2, _mm256_set_epi64x((long long)0, (long long)12, (long long)7, (long long)2)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R2 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R3, _mm256_set_epi64x((long long)0, (long long)51, (long long)56, (long long)61)),
              _mm256_sllv_epi64(R3, _mm256_set_epi64x((long long)0, (long long)13, (long long)8, (long long)3)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R3 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
        {
          __m256i y = _mm256_or_si256(
              _mm256_srlv_epi64(R4, _mm256_set_epi64x((long long)0, (long long)50, (long long)55, (long long)60)),
              _mm256_sllv_epi64(R4, _mm256_set_epi64x((long long)0, (long long)14, (long long)9, (long long)4)));
          __m256i r21 = _mm256_or_si256(_mm256_srli_epi64(y, 21), _mm256_slli_epi64(y, 43));
          __m256i r43 = _mm256_or_si256(_mm256_srli_epi64(y, 43), _mm256_slli_epi64(y, 21));
          R4 = _mm256_xor_si256(_mm256_xor_si256(y, r21), r43);
        }
    }

    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R0);
      p[0] = t[0];
      p[5] = t[1];
      p[10] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R1);
      p[1] = t[0];
      p[6] = t[1];
      p[11] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R2);
      p[2] = t[0];
      p[7] = t[1];
      p[12] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R3);
      p[3] = t[0];
      p[8] = t[1];
      p[13] = t[2];
    }
    { uint64_t t[4];
      _mm256_storeu_si256((__m256i *)t, R4);
      p[4] = t[0];
      p[9] = t[1];
      p[14] = t[2];
    }
}

