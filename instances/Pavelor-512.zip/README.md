# Pavelor-512

Algorithm: Pavelor | Digest bits: 512 | Form: 标量 C

Contents: implementation source/, public header Pavelor-512.h, prebuilt Pavelor-512.so,
KAT vector KAT_2_12_Pavelor-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 664369379aac683ccd3f2f477fe11dbed8b19c7334b685d76d8e056cf3d49807
Speed (cpB, lower is faster): reference 150.44 / official-optimized 1.17 / optimized 1.00
Speedup: GM(S1-S8) 1.12x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
