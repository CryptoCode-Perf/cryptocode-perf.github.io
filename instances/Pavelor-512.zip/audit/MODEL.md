# Pavelor — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Pavelor-1024
- 摘要位：1024；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Pavelor-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Pavelor-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Pavelor-1024/`
- 优化要点：官方 Optimized_Implementation 逐字保留，唯一改动是把 permute24 的 24 轮滚动循环按 k=8 分组展开：24 轮分 3 次外循环，组内 round_local 的轮号是编译期常量，轮常量寻址由运行时查表变成立即数，循环回边从 24 次降到 3 次。语义逐位等价（round_local 只依赖状态与轮号），官方 KAT 4097/4097 全过。展开因子是扫出来的：k∈{1,2,3,4,6,8,12,24} 八件全编全测，单跑 gm 依次 1.0021 / 1.0106 / 1.0509 / 1.0174 / 1.0231 / 1.0907 / 1.0339 / 1.0435，k=8 最优；k=1 对照件 gm 1.0021 说明它确实复现了官方性能、比较是公平的。5 轮稳健复测（4 个长档、同进程交替）：k=1 0.995847 / k=3 1.022

## Pavelor-512
- 摘要位：512；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Pavelor-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Pavelor-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Pavelor-512/`
- 优化要点：官方 Optimized_Implementation 逐字保留，唯一改动是把 permute24 的 24 轮滚动循环按 k=6 分组展开：轮号变编译期常量、轮常量寻址变立即数、循环回边 24→4。k∈{1,2,3,4,6,8,12,24} 八件全编全测，5 轮稳健（4 长档、ROUNDS=120）k=1 0.993916（对照，说明复现官方）/ k=3 1.063806 / k=4 1.104281 / k=6 1.108591 / k=8 1.072861 / k=12 1.095797，k=6 最优且 spread 0.69%。KAT 4097/4097，forbidden(非 AES)=0；vaesenc 是算法本体要求、合法。

## Pavelor-768
- 摘要位：768；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Pavelor-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Pavelor-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Pavelor-768/`
- 优化要点：同一套 permute24 分组展开，本档取 k=2：5 轮稳健 gm 1.060753 spread 0.98% win，另跑 10 轮独立复测 median 1.059310、10 轮全部 >= 1.05（最低 1.0551，唯一向上离群 1.1267 不改判赢）。其余 k 在 5 轮里 spread 都 > 1%（unstable）、不采用。k=1 对照 0.991674 说明复现官方。KAT 4097/4097，forbidden(非 AES)=0；vaesenc 是算法本体要求、合法。对手件为台账缺口修复后按官方 build_cmd 重编的 oppfix/opt_768.so。
