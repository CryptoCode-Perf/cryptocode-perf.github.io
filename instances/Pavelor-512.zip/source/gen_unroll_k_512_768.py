#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_unroll_k_512_768.py --- 为 Pavelor-512 / Pavelor-768 生成置换展开变体源。

照 pavelor/gen_unroll_k.py（1024 的做法）逐字搬：把官方 permute24 的
`for (r=0; r<CH_ROUNDS; ++r) round_local(st,r);` 按 k 展开（k|24），
保持 r 在组内是编译期常量，循环回边从 24 次降到 24/k 次。
512/768 的 permute24 锚点与 1024 逐字相同，故 OLD/body_for 完全复用。

产物写到 pavelor/src512_768/unroll_k<k>_<bits>.c，不碰 1024 的 src/。

用法：
  python3 gen_unroll_k_512_768.py <k>        # 生成该 k 的 512+768 两套源
  python3 gen_unroll_k_512_768.py all        # 生成 k∈{1,2,3,4,6,8,12,24} 全部
"""
from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
OPTBASE = os.path.join(L0, "src", "hash-22", "Pavelor",
                       "Implementations and Test_Vectors", "API_CryptHash",
                       "Implementations", "Optimized_Implementation")
OUTDIR = os.path.join(HERE, "src512_768")
ROUNDS = 24
BITS_LIST = (512, 768)

OLD = """static CH_FORCE_INLINE void permute24(CHState* st)
{
    unsigned r;
    for (r = 0u; r < CH_ROUNDS; ++r) {
        round_local(st, r);
    }
}"""


def body_for(k):
    if k == 1:
        return OLD           # 原样 = 官方滚动循环
    if ROUNDS % k:
        raise SystemExit("k=%d 不整除 %d" % (k, ROUNDS))
    lines = ["static CH_FORCE_INLINE void permute24(CHState* st)", "{"]
    lines.append("    /* %d 轮，按 k=%d 分组成 %d 次外循环：组内 r 是编译期常量，"
                 % (ROUNDS, k, ROUNDS // k))
    lines.append("     * 轮常量寻址变常量、循环回边从 %d 次降到 %d 次。"
                 % (ROUNDS, ROUNDS // k))
    lines.append("     * 语义与官方滚动循环逐位等价（round_local 只依赖 st 与 r）。 */")
    lines.append("    unsigned g;")
    lines.append("    for (g = 0u; g < %du; g += %du) {" % (ROUNDS, k))
    for j in range(k):
        lines.append("        round_local(st, %2du + g);" % j)
    lines.append("    }")
    lines.append("}")
    return "\n".join(lines)


def gen(bits, k):
    src = os.path.join(OPTBASE, "Pavelor-%d" % bits, "CryptHash_AlgorithmInstance.c")
    if not os.path.exists(src):
        raise SystemExit("缺源：%s" % src)
    txt = open(src, "r", encoding="utf-8", errors="replace").read()
    if txt.count(OLD) != 1:
        raise SystemExit("Pavelor-%d permute24 锚点命中 %d 次（必须恰好 1）"
                         % (bits, txt.count(OLD)))
    os.makedirs(OUTDIR, exist_ok=True)
    out = os.path.join(OUTDIR, "unroll_k%d_%d.c" % (k, bits))
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(txt.replace(OLD, body_for(k)))
    print("Pavelor-%d k=%2d -> %s（%d 字节）"
          % (bits, k, os.path.relpath(out, HERE), os.path.getsize(out)))
    # k=1 必须逐字节等于官方源（自证）
    if k == 1:
        same = open(out, "rb").read() == open(src, "rb").read()
        print("   k=1 自证：生成源与官方源逐字节相同 = %s" % same)
        if not same:
            raise SystemExit("k=1 自证失败")
    return out


def main():
    if len(sys.argv) < 2:
        raise SystemExit("用法：gen_unroll_k_512_768.py <k|all>")
    a = sys.argv[1]
    ks = [1, 2, 3, 4, 6, 8, 12, 24] if a == "all" else [int(a)]
    for k in ks:
        for bits in BITS_LIST:
            gen(bits, k)
    return 0


if __name__ == "__main__":
    sys.exit(main())
