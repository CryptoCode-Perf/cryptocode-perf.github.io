#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_gate_512_768.py --- 为 Pavelor-512 / Pavelor-768 编译展开变体并过门禁。

口径（全部照 pavelor/build_unroll_k.py + user 硬性要求）：
  * 官方十 flag 逐字 + -maes -msse2：
      -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
      -std=c99 -Wpedantic -Wall -Wextra -maes -msse2
  * 编译失败判据：returncode != 0 **或 stderr 非空（warning 也算失败）** —— 本仓
    1024 脚本容忍 warning 是旧口径；此处按 user 新口径从严，rc+stderr 双判。
  * KAT：KG.find_kat("hash-22","Pavelor-<bits>") + KF.check_all，必须 4097/4097。
  * ISA：objdump -d 扫禁止指令。vaesenc 是 Pavelor 本体需要的 AES-NI 指令
    （= 1024 基线里记的 "aesenc" 家族，允许）；vaesdec/vaesenclast/vaesdeclast
    以及 rorx/andn/.../vpmullq 才是真禁止。报告里把三者分别列清，避免歧义。
  * k=1 必须与 oppfix/opt_<bits>.so 逐字节相同（自证）。

严禁：任何计时脚本、改站点文件。本脚本只编译 + KAT + objdump + 写 pavelor/out/。

用法（在 WSL 里跑）：
  python3 pavelor/build_gate_512_768.py
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
WORK = os.path.dirname(os.path.dirname(L0))
OPTBASE = os.path.join(L0, "src", "hash-22", "Pavelor",
                       "Implementations and Test_Vectors", "API_CryptHash",
                       "Implementations", "Optimized_Implementation")
SRCDIR512_768 = os.path.join(HERE, "src512_768")
OUT = os.path.join(HERE, "out512_768")
OPPDIR = os.path.join(HERE, "oppfix")
FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra",
         "-maes", "-msse2"]
KS = [1, 2, 3, 4, 6, 8, 12, 24]
BITS_LIST = (512, 768)
DELIVER_K = 8  # 1024 经验：k=8 最优（单跑 1.0907、5 轮稳健 1.0499）

# 真·禁止指令（Pavelor 不需要这些）。注意 vaesenc 不在此列：它是算法本体要的 AES-NI，
# 与 1024 基线 "aesenc 不算违禁" 一致，单独计入 allowed_aes。
FORB = ("rorx", "andn", "shlx", "shrx", "sarx", "bzhi", "pdep", "pext",
        "vaesdec", "vaesdeclast", "vaesenclast", "vpternlog", "vprol",
        "vpror", "vplzcnt", "kmov", "vpmullq")
# user 字面 forbidden 里把 vaesenc 也列了；为透明起见单列 raw 命中数。
RAW_FORB_WITH_VAESENC = FORB + ("vaesenc",)
ALLOWED_AES = ("vaesenc", "aesenc", "aesenclast", "aesdec", "aesdeclast")


def sha256(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def wsl(path):
    p = path.replace("\\", "/")
    return p.replace("C:/", "/mnt/c/").replace("c:/", "/mnt/c/")


def build_one(bits, k):
    src = os.path.join(SRCDIR512_768, "unroll_k%d_%d.c" % (k, bits))
    if not os.path.exists(src):
        raise SystemExit("缺 %s，先跑 gen_unroll_k_512_768.py" % src)
    d = os.path.join(OPTBASE, "Pavelor-%d" % bits)
    so = os.path.join(OUT, "ours_unroll_k%d_%d.so" % (k, bits))
    cmd = ["gcc"] + FLAGS + ["-shared", "-fPIC", "-I", wsl(d), "-o", wsl(so),
                             wsl(src), wsl(os.path.join(d, "drng.c"))]
    r = subprocess.run(cmd, capture_output=True)
    out = (r.stdout or b"").decode("utf-8", "replace")
    err = (r.stderr or b"").decode("utf-8", "replace")
    log = os.path.join(OUT, "build_k%d_%d.log" % (k, bits))
    with open(log, "w", encoding="utf-8") as fh:
        fh.write(out + "\n" + err)
    ok = (r.returncode == 0 and err == "")
    nwarn = len(re.findall(r"warning:", out + err))
    print("Pavelor-%d k=%2d  rc=%d stderr=%r warning=%d  BUILD=%s  %s"
          % (bits, k, r.returncode, err[:200].replace("\n", "\\n"), nwarn,
             "OK" if ok else "FAIL",
             ("%d B" % os.path.getsize(so)) if os.path.exists(so) else "NO SO"))
    if not ok:
        print("   build stderr full:\n" + err[:2000])
    return so, ok, err, nwarn


def isa_counts(so):
    r = subprocess.run(["objdump", "-d", so], capture_output=True)
    txt = (r.stdout or b"").decode("utf-8", "replace")
    def cnt(names):
        return sum(len(re.findall(r"\b" + x + r"\b", txt)) for x in names)
    return {
        "forbidden_non_aes": cnt(FORB),
        "forbidden_raw_incl_vaesenc": cnt(RAW_FORB_WITH_VAESENC),
        "allowed_aes_vaesenc": cnt(("vaesenc",)),
        "allowed_aes_other": cnt(tuple(x for x in ALLOWED_AES if x != "vaesenc")),
        "vaesdec_family": cnt(("vaesdec", "vaesdeclast", "vaesenclast")),
        "ymm": txt.count("%ymm"),
    }


def main():
    os.makedirs(OUT, exist_ok=True)
    sys.path.insert(0, WORK)
    sys.path.insert(0, os.path.join(WORK, "_std"))
    sys.path.insert(0, L0)
    import _kat_full as KF  # noqa: E402
    import kat_gate as KG  # noqa: E402

    report = {"flags": FLAGS, "deliver_k": DELIVER_K,
              "forbidden_non_aes": list(FORB),
              "note": ("vaesenc 是 Pavelor 本体需要的 AES-NI（1024 基线算 allowed aesenc 家族，"
                       "不算违禁）；vaesdec/vaesenclast/vaesdeclast 与其它 BMI/AVX512 指令为违禁。"),
              "variants": []}

    for bits in BITS_LIST:
        inst = "Pavelor-%d" % bits
        recs, used = KG.find_kat("hash-22", inst)
        print("\n=== %s KAT 向量：%d 条（%s）==="
              % (inst, len(recs), os.path.basename(str(used[0])) if used else "?"))
        for k in KS:
            so, ok, err, nwarn = build_one(bits, k)
            row = {"bits": bits, "k": k,
                   "so": os.path.relpath(so, HERE),
                   "bytes": os.path.getsize(so) if os.path.exists(so) else -1,
                   "sha256": sha256(so) if os.path.exists(so) else None,
                   "build_ok": ok, "build_stderr": err, "warnings": nwarn}
            if not ok or not os.path.exists(so):
                report["variants"].append(row)
                continue
            row["isa"] = isa_counts(so)
            n, m, first, errk = KF.check_all(so, recs)
            row["kat"] = {"n": n, "match": m, "first_bad": first, "err": errk,
                          "pass": bool(n == 4097 and m == n)}
            if k == 1:
                ref = os.path.join(OPPDIR, "opt_%d.so" % bits)
                row["k1_identity"] = {
                    "ref": os.path.relpath(ref, HERE),
                    "ref_sha256": sha256(ref),
                    "byte_identical": open(so, "rb").read() == open(ref, "rb").read(),
                }
            print("   KAT %d/%d pass=%s  first_bad=%s err=%s  "
                  "forbidden_non_aes=%d raw(+vaesenc)=%d aesenc(vaesenc)=%d ymm=%d"
                  % (n, m, row["kat"]["pass"], first, errk,
                     row["isa"]["forbidden_non_aes"],
                     row["isa"]["forbidden_raw_incl_vaesenc"],
                     row["isa"]["allowed_aes_vaesenc"], row["isa"]["ymm"]))
            if k == 1:
                print("   k=1 自证 byte-identical=%s" %
                      row["k1_identity"]["byte_identical"])
            report["variants"].append(row)

    dst = os.path.join(OUT, "gate_report.json")
    with open(dst, "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=1)
    print("\n写出门禁报告：%s（%d 个变体）" % (dst, len(report["variants"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
