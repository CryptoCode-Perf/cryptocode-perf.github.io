#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pick_k_512_768.py --- 串行扫 Pavelor-512/768 展开因子。

ratio = opp_ticks / ours_ticks  (>1 我方快)。对手 = oppfix/opt_<bits>.so
（就是台账新补的官方 opt，与 k=1 我方件逐字节相同，已自证）。

口径与 1024 的 pick_unroll_k.py 完全一致：
  * 每档 reps 次取 max（噪声只往上抖）
  * 严格串行：一个 k 测完再测下一个，同一进程内共享频率状态
  * bits_a/bits_b 必须显式传对应位长，否则 CryptHash 提前返回、ticks 掉到个位数

输出 pavelor/out512_768/pick_k.json。不做稳健复测，只找方向，胜出者再做 5 轮。

用法：python3 pick_k_512_768.py [reps，默认 3]
"""
import os, sys, json

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))  # l0 -> _overnight -> work
for p in (WORK, os.path.join(WORK, "_std"), L0):
    if p not in sys.path:
        sys.path.insert(0, p)
import bench_proto as BP  # noqa: E402

LENGTHS = [32, 512, 1024, 4096, 65536]
ROUNDS = 60
KS = [1, 2, 3, 4, 6, 8, 12, 24]
OUT = os.path.join(HERE, "out512_768", "pick_k.json")


def gm(vals):
    p = 1.0
    for v in vals:
        p *= v
    return p ** (1.0 / len(vals))


def main():
    reps = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    res = {}
    for bits in (512, 768):
        opp = os.path.join(HERE, "oppfix", "opt_%d.so" % bits)
        if not os.path.exists(opp):
            raise SystemExit("缺对手件: %s" % opp)
        res[str(bits)] = {}
        for k in KS:
            cand = os.path.join(HERE, "out512_768", "ours_unroll_k%d_%d.so" % (k, bits))
            if not os.path.exists(cand):
                print("跳过 k=%d bits=%d（缺件）" % (k, bits), flush=True)
                continue
            vals = []
            for L in LENGTHS:
                best = []
                for _ in range(reps):
                    rows = BP.sweep(cand, opp, lengths=[L], rounds=ROUNDS,
                                    cpu=BP.PIN_CPU, bits_a=bits, bits_b=bits)
                    if not rows:
                        raise SystemExit("sweep 空结果 k=%d L=%d" % (k, L))
                    best.append(rows[0]["ratio"] if isinstance(rows, list) else rows[L]["ratio"])
                vals.append(max(best))
            res[str(bits)]["k%d" % k] = {
                "rows": dict(zip([str(x) for x in LENGTHS], vals)),
                "geomean": gm(vals),
            }
            print("bits=%d k=%-2d gm=%.6f  %s" % (
                bits, k, gm(vals), " ".join("%d:%.4f" % (L, v) for L, v in zip(LENGTHS, vals))),
                flush=True)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    for bits in (512, 768):
        best = max(res[str(bits)].items(), key=lambda kv: kv[1]["geomean"])
        print("\nbits=%d 最优: %s gm=%.6f" % (bits, best[0], best[1]["geomean"]))
    print("写出", OUT)


if __name__ == "__main__":
    main()
