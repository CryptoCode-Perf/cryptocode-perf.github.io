#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""stable_k_512_768.py --- Pavelor-512/768 展开因子多轮稳健复测。

单跑噪声（32B 档 ±20%）不足以判 win/tie/loss，必须多轮重复。口径与
1024 的 stable_unroll_k.py 完全一致：

  * ratio = opp_ticks / ours_ticks（>1 我方快）
  * 对手 oppfix/opt_<bits>.so（与 k=1 我方件逐字节相同）
  * 每轮把候选逐个测一遍（同一进程、同一频率状态）
  * 长度去掉 32 B（短消息置信度最低），留 512/1024/4096/65536
  * WIN_T = 1.05；跨轮极差 > 1% 判 unstable，不当结论

用法：python3 stable_k_512_768.py [轮数，默认 5] <bits> <k> [<bits> <k> ...]
  例：python3 stable_k_512_768.py 5 512 8 768 8
"""
import os, sys, json, statistics

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))  # l0 -> _overnight -> work
for p in (WORK, os.path.join(WORK, "_std"), L0):
    if p not in sys.path:
        sys.path.insert(0, p)
import bench_proto as BP  # noqa: E402

LENGTHS = [512, 1024, 4096, 65536]
WIN_T = 1.05


def gm(d):
    p = 1.0
    for v in d.values():
        p *= v
    return p ** (1.0 / len(d))


def verdict(g):
    if g >= WIN_T:
        return "win"
    if g <= 1.0 / WIN_T:
        return "loss"
    return "tie"


def one(cand, opp, bits):
    rows = BP.sweep(cand, opp, lengths=LENGTHS, rounds=120, cpu=BP.PIN_CPU,
                    bits_a=bits, bits_b=bits)
    return {r["length"]: r["ratio"] for r in rows}


def main():
    args = sys.argv[1:]
    n = int(args[0]) if args else 5
    pairs = [(int(args[i]), int(args[i + 1])) for i in range(1, len(args) - 1, 2)]
    if not pairs:
        raise SystemExit("用法: stable_k_512_768.py [轮数] <bits> <k> ...")

    cands = {}
    opps = {}
    for bits, k in pairs:
        opp = os.path.join(HERE, "oppfix", "opt_%d.so" % bits)
        cand = os.path.join(HERE, "out512_768", "ours_unroll_k%d_%d.so" % (k, bits))
        if not os.path.exists(opp):
            raise SystemExit("缺对手件 %s" % opp)
        if not os.path.exists(cand):
            raise SystemExit("缺候选件 %s" % cand)
        cands[(bits, k)] = cand
        opps[bits] = opp

    acc = {key: [] for key in cands}
    for i in range(n):
        parts = []
        for key in cands:
            bits, k = key
            g = gm(one(cands[key], opps[bits], bits))
            acc[key].append(g)
            parts.append("%d/k%-2d %.6f" % (bits, k, g))
        print("轮 %d: %s" % (i + 1, "  ".join(parts)), flush=True)

    print()
    res = {}
    for key in cands:
        bits, k = key
        med = statistics.median(acc[key])
        spread = 100.0 * (max(acc[key]) - min(acc[key])) / med
        v = "unstable" if spread > 1.0 else verdict(med)
        res["%d_k%d" % key] = {"bits": bits, "k": k, "median": med,
                               "spread_pct": spread, "verdict": v,
                               "rounds": acc[key]}
        print("%d k=%-2d median %.6f  spread %.2f%%  => %s" % (bits, k, med, spread, v))

    dst = os.path.join(HERE, "out512_768", "stable_k.json")
    with open(dst, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    print("写出 %s" % dst)


if __name__ == "__main__":
    main()
