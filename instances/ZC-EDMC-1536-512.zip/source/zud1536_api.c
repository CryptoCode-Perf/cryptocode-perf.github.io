/* ZuD1536_avx2_* 外壳：吸收/挤出/初始化照官方 plain & AVX2 实现的语义逐行抄
 * （两份官方实现这几段完全一致，已比对），**只有置换**换成我们自己从 JIR 生成、
 * 经 jasmin 发射的汇编：
 *
 *      ZuD1536_avx2_Permute_12rounds  ->  zud1536_p12     （12 轮全展开，热路径）
 *      ZuD1536_avx2_Permute_Nrounds   ->  zud1536_round × nr （单轮 + 常量指针）
 *      ZuD1536_avx2_Permute_6rounds   ->  zud1536_round × 6  （rc6..rc1）
 *
 * 这样量到的是"核心置换"的差距，外围（吸收速率/填充/域分隔）与官方同源。
 */
#include <stdint.h>
#include <string.h>
#include <immintrin.h>

#include "ZuD1536-AVX2.h"

/* jasmin 导出：p 是状态指针（3 个 u256 = 24 个 u64 lane） */
void zud1536_p12(uint64_t *p);
void zud1536_round(uint64_t *p, const uint64_t *rcp);

/* RC[i] = rc(12-i)，只有最低 lane 非零 -> 直接当 u256 读（小端） */
static const uint64_t RC256[ZUD1536_MAXROUNDS][4] __attribute__((aligned(32))) = {
    {ZUD1536_rc12, 0, 0, 0},
    {ZUD1536_rc11, 0, 0, 0},
    {ZUD1536_rc10, 0, 0, 0},
    {ZUD1536_rc9,  0, 0, 0},
    {ZUD1536_rc8,  0, 0, 0},
    {ZUD1536_rc7,  0, 0, 0},
    {ZUD1536_rc6,  0, 0, 0},
    {ZUD1536_rc5,  0, 0, 0},
    {ZUD1536_rc4,  0, 0, 0},
    {ZUD1536_rc3,  0, 0, 0},
    {ZUD1536_rc2,  0, 0, 0},
    {ZUD1536_rc1,  0, 0, 0},
};

void ZuD1536_avx2_Initialize(ZuD1536_avx2_state *state)
{
    memset(state, 0, sizeof(*state));
}

void ZuD1536_avx2_AddBytes(ZuD1536_avx2_state *state, const uint8_t *data,
                           unsigned int offset, unsigned int length)
{
    uint8_t *dst = ((uint8_t *)state) + offset;
    unsigned int i = 0;

    /* 32 字节 ymm 异或（判据见 `zc1536_attrib/H2_TIMINGS.md`：把这一段换回官方 `.S`
     * 的逐字节语义后 ours/opt 退 4.8–10.9 个百分点，与 rate 字节数成正比 ⇒ 吸收段是
     * 整块成本的一大块；显式 AVX2 比「8 字节成组」再快 0.5–0.9 个百分点，三个位宽一致）。 */
    for (; i + 32u <= length; i += 32u) {
        __m256i d = _mm256_loadu_si256((const __m256i *)(const void *)(data + i));
        __m256i s = _mm256_loadu_si256((const __m256i *)(const void *)(dst + i));
        _mm256_storeu_si256((__m256i *)(void *)(dst + i), _mm256_xor_si256(s, d));
    }
    for (; i + 8u <= length; i += 8u) {
        uint64_t a, b;
        memcpy(&a, dst + i, 8);
        memcpy(&b, data + i, 8);
        a ^= b;
        memcpy(dst + i, &a, 8);
    }
    for (; i < length; i++)
        dst[i] ^= data[i];
}

void ZuD1536_avx2_OverwriteBytes(ZuD1536_avx2_state *state, const uint8_t *data,
                                 unsigned int offset, unsigned int length)
{
    memcpy(((uint8_t *)state) + offset, data, length);
}

void ZuD1536_avx2_OverwriteWithZeroes(ZuD1536_avx2_state *state, unsigned int byteCount)
{
    memset(state, 0, byteCount);
}

void ZuD1536_avx2_ExtractBytes(const ZuD1536_avx2_state *state, uint8_t *data,
                               unsigned int offset, unsigned int length)
{
    memcpy(data, ((const uint8_t *)state) + offset, length);
}

void ZuD1536_avx2_ExtractAndAddBytes(const ZuD1536_avx2_state *state, const uint8_t *input,
                                     uint8_t *output, unsigned int offset, unsigned int length)
{
    for (unsigned int i = 0; i < length; i++)
        output[i] = input[i] ^ ((const uint8_t *)state)[offset + i];
}

void ZuD1536_avx2_Permute_12rounds(ZuD1536_avx2_state *state)
{
    zud1536_p12(state->A);
}

void ZuD1536_avx2_Permute_Nrounds(ZuD1536_avx2_state *state, unsigned int nr)
{
    if (nr > ZUD1536_MAXROUNDS)
        nr = ZUD1536_MAXROUNDS;
    for (unsigned int i = ZUD1536_MAXROUNDS - nr; i < ZUD1536_MAXROUNDS; ++i)
        zud1536_round(state->A, RC256[i]);
}

void ZuD1536_avx2_Permute_6rounds(ZuD1536_avx2_state *state)
{
    for (unsigned int i = ZUD1536_MAXROUNDS - 6u; i < ZUD1536_MAXROUNDS; ++i)
        zud1536_round(state->A, RC256[i]);
}
