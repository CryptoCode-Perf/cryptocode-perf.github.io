"""ZC-DM-1536（ZuD 3 行 × 8 列 × u64 = 192 字节 = 24 lane）的 256 位向量化。

## 为什么不是「一行一个 u256」
一个 u256 只有 **4 个 u64 lane**（256/64 = 4），而一行有 8 列 = 512 位。
所以一行必须摊到**两个** u256 上：`row_y_L` 放列 0..3、`row_y_H` 放列 4..7，
状态共 6 个 u256。任务书里「一行 = 一个 u256（8 lane × 64 位）」在算术上不成立
（8×64 = 512 > 256），据它推出的 `perm2i128 + permq` 列位移公式也就无法成立
（`permq` 是 4 lane 内的、`perm2i128` 是 128 位粒度，二者组合出来的置换实测
不是 8 lane 轮转）。这里按 6×u256 重新推，见下。

## 六个 u256 上的三步
* `chi`：逐列 3 lane 链式，与「行」怎么摊开无关 —— 两个 4 列分组各做一遍即可，
  **零 shuffle**：`c0 = r0 ^ andn(r2, r1)`、`c1 = r1 ^ andn(c0, r2)`、
  `c2 = r2 ^ andn(c1, c0)`（`andn(x,y) = x & ~y`，注意链式顺序）。
* `theta`：`p = r0 ^ r1 ^ r2` 逐组得到 8 列的奇偶（两组各 2 条 xor）；
  `e[x] = ROTL64(p[x-1],20) ^ ROTL64(p[x-1],56)`；三行都 `^= e`。
* `rho`：行内列位移 + 行 1 额外 rotl3。8 lane 的列位移按「先 ±4（寄存器换名，
  0 条指令）再 ±1」拆：
    `permq(l,1)` / `permq(h,1)` 各自做 4 lane 内轮转，再用一条
    `blendd` 把两个寄存器在边界 lane 上拼接 —— 每对寄存器 4 条指令。

## 源码为准的位移量（不是注释）
`ZuD1536-plain.c` 与 `ZuD1536-AVX2.c` 的 rho 逐行一致：
    row1: A[8+i]  = ROTL64(a1[(i+5)%8], 3)   -> 列位移 +5，再每 lane rotl3
    row2: A[16+i] = a2[(i+3)%8]              -> 列位移 +3，无 lane 旋转
    row0: 不动
`theta` 用 `p[(x+7)%8]`（= 列位移 -1）。
（plain 自己的注释写着 "row2 lanes rotated by ?"、"row1 columns rotated right by ?"，
AVX2 版注释写 "<<< (3,3) rotate 8"，都是错的；以两份代码为准。）
"""
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, WORK)

import ir_text as I  # noqa: E402

# RC[0..11] = rc12..rc1（ZuD1536.h）
RC = [0x58, 0x38, 0x3C0, 0xD0, 0x120, 0x14, 0x60, 0x2C, 0x380, 0xF0, 0x1A0, 0x12]

SHIFT_ROW1 = 5      # 列位移（row1）
SHIFT_ROW2 = 3      # 列位移（row2）
ROTL_ROW1 = 3       # row1 每 lane rotl 3
SHIFT_THETA = 7     # e[x] 用 p[x-1] -> 列位移 7（= -1）
ROTL_E = (20, 56)

READY = 32 * 6      # 6 个 u256 = 192 字节


def perm_imm(m: int) -> int:
    """permq 立即数：dst lane r 取 src lane (r+m)%4（4 lane 内轮转）。"""
    return sum((((r + m) % 4) << (2 * r)) for r in range(4))


PERM_IMM = {m: perm_imm(m) for m in range(4)}
assert PERM_IMM == {0: 0xE4, 1: 0x39, 2: 0x4E, 3: 0x93}, PERM_IMM

# blendd：imm 位 j=1 取第二源（每 32 位一个开关）。64 位 lane3 = dword 6,7
MASK_LANE3 = 0xC0
MASK_LANE0 = 0x03


def u256_const(v: int) -> str:
    return "0x%064x" % v


class E:
    def __init__(self):
        self.L = []
        self.n = 0

    def __call__(self, line):
        self.L.append("  " + line)

    def nm(self, tag):
        self.n += 1
        return "%s_%d" % (tag, self.n)


def rotl64(e, tag, src, k):
    """每 lane rotl64（同 lane 常数）。shl/shr/or 三条，发射器会折成 rot64 或 pshufb。"""
    k %= 64
    if k == 0:
        return src
    a, b = e.nm(tag + "l"), e.nm(tag + "r")
    e("%s = shl(%s, %d)" % (a, src, k))
    e("%s = shr(%s, %d)" % (b, src, 64 - k))
    t = e.nm(tag + "o")
    e("%s = or(%s, %s)" % (t, a, b))
    return t


def shift_cols(e, tag, pair, k):
    """8 lane 列位移：dst[i] = src[(i+k)%8]，pair = (l, h) 两个 u256。

    只有四种情形，都用「±4 靠寄存器换名（零指令）+ ±1 靠 2 permq + 2 blendd」：
        k=1: 不换名, +1      k=5: 换名, +1   (5 = 4+1)
        k=7: 不换名, -1      k=3: 换名, -1   (3 = 4-1, 7 = -1)
    k=2/6 是 2 lane 粒度，用一条 perm2i128 就够（本算法用不到，留着备用）。
    """
    k %= 8
    l, h = pair
    if k == 0:
        return (l, h)
    if k == 2:
        lo, hi = e.nm(tag + "l"), e.nm(tag + "h")
        e("%s = perm2i128(%s, %s, 0x21)" % (lo, l, h))
        e("%s = perm2i128(%s, %s, 0x21)" % (hi, h, l))
        return (lo, hi)
    if k in (5, 3):                 # +4 columns：两个寄存器换名，零指令
        l, h = h, l
    if k in (1, 5):                 # dst[i] = src[(i+1)%8]
        a, b = e.nm(tag + "a"), e.nm(tag + "b")
        e("%s = permq(%s, %#x)" % (a, l, PERM_IMM[1]))
        e("%s = permq(%s, %#x)" % (b, h, PERM_IMM[1]))
        lo, hi = e.nm(tag + "l"), e.nm(tag + "h")
        e("%s = blendd(%s, %s, %#x)" % (lo, a, b, MASK_LANE3))
        e("%s = blendd(%s, %s, %#x)" % (hi, b, a, MASK_LANE3))
        return (lo, hi)
    if k in (3, 7):                 # dst[i] = src[(i-1)%8]
        a, b = e.nm(tag + "a"), e.nm(tag + "b")
        e("%s = permq(%s, %#x)" % (a, l, PERM_IMM[3]))
        e("%s = permq(%s, %#x)" % (b, h, PERM_IMM[3]))
        lo, hi = e.nm(tag + "l"), e.nm(tag + "h")
        e("%s = blendd(%s, %s, %#x)" % (lo, a, b, MASK_LANE0))
        e("%s = blendd(%s, %s, %#x)" % (hi, b, a, MASK_LANE0))
        return (lo, hi)
    raise AssertionError("k=%d 不该走到这里" % k)


def rho(e, tag, rows):
    """rho：row0 不动；row1 = 列位移+5 后再 rotl3；row2 = 列位移+3。"""
    p1 = (rotl64(e, tag + "r1l", rows[1][0], ROTL_ROW1),
          rotl64(e, tag + "r1h", rows[1][1], ROTL_ROW1))
    r1 = shift_cols(e, tag + "s1", p1, SHIFT_ROW1)
    r2 = shift_cols(e, tag + "s2", rows[2], SHIFT_ROW2)
    return [rows[0], r1, r2]


def round_body(e, tag, rows, rc_expr):
    """一轮：iota -> chi -> rho -> theta -> rho。"""
    # iota：A[0] ^= rc（只有 row0 的 lane0）
    i0 = e.nm(tag + "i")
    e("%s = xor(%s, %s)" % (i0, rows[0][0], rc_expr))
    s = [(i0, rows[0][1]), rows[1], rows[2]]

    # chi（两个 4 列分组各一遍，链式）
    c = []
    for g in range(3):
        cg = []
        for half in (0, 1):
            src0, src1, src2 = s[0][half], s[1][half], s[2][half]
            if g == 0:
                t = e.nm(tag + "c0")
                e("%s = xor(%s, andn(%s, %s))" % (t, src0, src2, src1))
                cg.append(t)
            elif g == 1:
                t = e.nm(tag + "c1")
                e("%s = xor(%s, andn(%s, %s))" % (t, src1, c[0][half], src2))
                cg.append(t)
            else:
                t = e.nm(tag + "c2")
                e("%s = xor(%s, andn(%s, %s))" % (t, src2, c[1][half], c[0][half]))
                cg.append(t)
        c.append(tuple(cg))

    a = rho(e, tag + "A", [tuple(c[0]), tuple(c[1]), tuple(c[2])])

    # theta
    p = []
    for half in (0, 1):
        t = e.nm(tag + "p")
        e("%s = xor(xor(%s, %s), %s)" % (t, a[0][half], a[1][half], a[2][half]))
        p.append(t)
    q = shift_cols(e, tag + "q", tuple(p), SHIFT_THETA)
    ee = []
    for half in (0, 1):
        e1 = rotl64(e, tag + "e1", q[half], ROTL_E[0])
        e2 = rotl64(e, tag + "e2", q[half], ROTL_E[1])
        t = e.nm(tag + "e")
        e("%s = xor(%s, %s)" % (t, e1, e2))
        ee.append(t)
    u = []
    for y in range(3):
        pair = []
        for half in (0, 1):
            t = e.nm(tag + "u%d" % y)
            e("%s = xor(%s, %s)" % (t, a[y][half], ee[half]))
            pair.append(t)
        u.append(tuple(pair))

    return rho(e, tag + "B", u)


def build(entry, rounds, rc_mem=False, const_rc=True):
    e = E()
    if const_rc:
        for i, rc in enumerate(RC):
            e.L.append("const RC%d:u256 = %s" % (i, u256_const(rc)))
    e.L.append("entry %s(p: u64%s)" % (entry, ", rcp: u64" if rc_mem else ""))
    rows = []
    for y in range(3):
        pair = []
        for half in (0, 1):
            nm = "R%d%s" % (y, "LH"[half])
            e.L.append("  %s:u256 = ld(p + %d)" % (nm, 32 * (2 * y + half)))
            pair.append(nm)
        rows.append(tuple(pair))
    for n, i in enumerate(rounds):
        if rc_mem and n == 0:
            e.L.append("  rcval:u256 = ld(rcp + 0)")
            rows = round_body(e, "t%d" % n, rows, "rcval")
        else:
            rows = round_body(e, "t%d" % n, rows, "RC%d" % i)
    for y in range(3):
        for half in (0, 1):
            e.L.append("  R%d%s = %s" % (y, "LH"[half], rows[y][half]))
    for y in range(3):
        for half in (0, 1):
            e.L.append("  st(p + %d, R%d%s)" % (32 * (2 * y + half), y, "LH"[half]))
    return "\n".join(e.L) + "\n"


def main() -> int:
    jobs = [("zud1536_p12", list(range(12)), False),
            ("zud1536_round", [0], True)]
    total = 0
    for entry, rounds, rc_mem in jobs:
        jir = os.path.join(HERE, entry + ".jir")
        jazz = os.path.join(HERE, entry + ".jazz")
        text = build(entry, rounds, rc_mem=rc_mem)
        io.open(jir, "w", encoding="utf-8", newline="\n").write(text)
        js, info = I.to_jasmin(text, nregs=16)
        io.open(jazz, "w", encoding="utf-8", newline="\n").write(js)
        total += info["ir_instr"]
        print("%-14s JIR %4d 行  IR %4d 条  峰值 reg %2d/%d  溢出 %d  jazz %d 行"
              % (entry, len(text.splitlines()), info["ir_instr"], info["peak"],
                 info.get("nregs", 16), info["spill"], len(js.splitlines())))
    print("IR 合计 %d 条（p12 是热路径）" % total)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
