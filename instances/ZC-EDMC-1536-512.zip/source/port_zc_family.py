"""ZC 家族移植：把已赢的 ZC-DM-1536 核心（6×u256，`zud1536_p12` / `zud1536_round`）
接到 hash-31 ZC-DMC 与 hash-32 ZC-EDMC 的**官方胶水**上，产出 6 个交付件。

依据（已核实，见 `l0_next_targets.md` §2a）：
  * hash-30/31/32 的 `lib/low/ZuD-1536/` 五个文件逐字节相同（核心同源）；
  * 三个候选的 1536 外壳只引用 `ZuD1536_avx2_{Initialize,AddBytes,ExtractBytes,
    Permute_12rounds}`，EDMC 多一个 `Permute_6rounds`；
  * 这些符号 `zc1536/zud1536_api.c` 全部已导出，`Permute_6rounds` 就是
    `zud1536_round` 跑 rc7..rc12。

⇒ 移植 = 换胶水 + 复用同一批 jasmin 目标文件，**核心与 API 零改动**。

本脚本只做构建 + 三道门（置换 / KAT / 与官方 opt 全长度摘要对拍），**不测时间**
（计时由 captain 串行独占）。

用法：python3 port_zc_family.py [--only hash-31] [--skip-build]
"""
import ctypes
import glob
import hashlib
import io
import json
import os
import random
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
ZC = os.path.join(L0, "zc1536")       # 复用已赢的核心与 API
SRC = os.path.join(L0, "src")
OUT = os.path.join(HERE, "out")
LOGS = os.path.join(HERE, "logs")

OPT_FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
             "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

# cid -> (家族目录名, 核心库目录, 实例子目录前缀)
FAMILIES = {
    "hash-30": ("ZC-DM", "ZuD-1536", "ZC-DM-1536"),
    "hash-31": ("ZC-DMC", "ZuD-1536", "ZC-DMC-1536"),
    "hash-32": ("ZC-EDMC", "ZuD-1536", "ZC-EDMC-1536"),
}
CAPS = ("512", "768", "1024")

WA = 24


def sh(args, logname, timeout=900):
    os.makedirs(LOGS, exist_ok=True)
    log = os.path.join(LOGS, logname)
    with open(log, "w") as fh:
        r = subprocess.run(args, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout)
    txt = io.open(log, encoding="utf-8", errors="replace").read()
    return r.returncode, txt


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 16), b""):
            h.update(c)
    return h.hexdigest()


def inc_dirs(cid):
    """包内层级是 `<dname>/Implementations/Implementations/Optimized_Implementation/<实例>`
    （`Implementations` 出现两次）——这是扫出来的，不是猜的（见 `_layout.py`）。"""
    dname, libname, _ = FAMILIES[cid]
    base = os.path.join(SRC, cid, dname, "Implementations")   # 含 lib/ 与 Implementations/
    root = os.path.join(base, "Implementations")
    lib = os.path.join(base, "lib", "low", libname)
    return root, lib, [lib, os.path.join(lib, "plain"), os.path.join(lib, "AVX2"),
                       os.path.join(base, "lib", "common")]


def core_objs():
    """复用 zc1536 已构建好的 jasmin 目标文件（不重建，保证与已测交付件同源）。"""
    objs = []
    for name in ("zud1536_p12", "zud1536_round"):
        o = os.path.join(ZC, "out", name + ".o")
        if not os.path.exists(o):
            return None, "%s 不存在，请先跑 zc1536/build_zc1536.py" % o
        objs.append(o)
    return objs, None


def build_family(cid, js_objs):
    dname, _, prefix = FAMILIES[cid]
    root, lib, incs = inc_dirs(cid)
    outdir = os.path.join(OUT, dname)
    os.makedirs(outdir, exist_ok=True)

    api_o = os.path.join(outdir, "zud1536_api.o")
    cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", api_o]
    for d in incs:
        cmd += ["-I", d]
    cmd.append(os.path.join(ZC, "zud1536_api.c"))
    rc, log = sh(cmd, "%s_api_cc.log" % dname)
    if rc != 0:
        return None, "api 编译失败：\n" + log[-2000:]

    so = os.path.join(outdir, "ours_%s.so" % dname.lower())
    # 三实例的胶水逐字节相同（官方设计），任取 512 那份
    glue_dir = os.path.join(root, "Optimized_Implementation", "%s-512" % prefix)
    glue_src = os.path.join(glue_dir, "CryptHash_AlgorithmInstance.c")
    if not os.path.exists(glue_src):
        return None, "缺胶水 %s" % glue_src
    glue_o = os.path.join(outdir, "glue_512.o")
    cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", glue_o, "-I", glue_dir]
    for d in incs:
        cmd += ["-I", d]
    cmd.append(glue_src)
    rc, log = sh(cmd, "%s_glue_cc.log" % cname(dname))
    if rc != 0:
        return None, "胶水编译失败：\n" + log[-2000:]
    rc, log = sh(["gcc", "-shared", "-o", so, api_o, glue_o] + js_objs,
                 "%s_link.log" % dname)
    if rc != 0:
        return None, "链接失败：\n" + log[-2000:]
    print("  ✓ %s：%s（%d 字节，sha256=%s）"
          % (dname, os.path.basename(so), os.path.getsize(so), sha256(so)[:16]))
    return so, None


def cname(dname):
    return dname.replace("-", "_").lower()


# ---------------------------------------------------------------- 门

def plain_so(cid):
    """官方 plain 置换编成 .so：置换比对的裁判。"""
    dname, libname, prefix = FAMILIES[cid]
    root, lib, incs = inc_dirs(cid)
    outdir = os.path.join(OUT, dname)
    os.makedirs(outdir, exist_ok=True)
    so = os.path.join(outdir, "plain_1536_%s.so" % cname(dname))
    plain_c = os.path.join(lib, "plain", "ZuD1536-plain.c")
    cmd = ["gcc", "-O2", "-std=c99", "-fPIC", "-shared", "-o", so]
    for d in incs:
        cmd += ["-I", d]
    cmd.append(plain_c)
    rc, log = sh(cmd, "plain_%s.log" % cname(dname))
    if rc != 0:
        return None, "plain 裁判构建失败：\n" + log[-2000:]
    return so, None


def perm_gate(so, pso, trials=48):
    ours = ctypes.CDLL(so)
    plain = ctypes.CDLL(pso)
    P = ctypes.POINTER(ctypes.c_uint64)
    ours.ZuD1536_avx2_Permute_12rounds.argtypes = [P]
    ours.ZuD1536_avx2_Permute_6rounds.argtypes = [P]
    plain.ZuD1536_plain_Permute_12rounds.argtypes = [P]
    plain.ZuD1536_plain_Permute_6rounds.argtypes = [P]
    rnd = random.Random(20261106)
    res = {}
    for tag, target_o, target_p in (
            ("p12", ours.ZuD1536_avx2_Permute_12rounds, plain.ZuD1536_plain_Permute_12rounds),
            ("p6", ours.ZuD1536_avx2_Permute_6rounds, plain.ZuD1536_plain_Permute_6rounds)):
        bad = 0
        first = None
        cases = [[0] * WA, [0xFFFFFFFFFFFFFFFF] * WA] + \
                [[rnd.getrandbits(64) for _ in range(WA)] for _ in range(trials)]
        for t, st in enumerate(cases):
            a = (ctypes.c_uint64 * WA)(*st)
            b = (ctypes.c_uint64 * WA)(*st)
            target_o(a)
            target_p(b)
            if list(a) != list(b):
                bad += 1
                if first is None:
                    first = (t, [(i, hex(a[i]), hex(b[i])) for i in range(WA) if a[i] != b[i]][:3])
        res[tag] = {"ok": bad == 0, "n": len(cases), "bad": bad, "first": first}
        print("  ① %s 置换：%d/%d 一致%s"
              % (tag, len(cases) - bad, len(cases), "" if not bad else "，首个 %s" % (first,)))
    return res["p12"]["ok"] and res["p6"]["ok"], res


def kat_gate(so, cid, inst):
    sys.path.insert(0, L0)
    import kat_gate as K
    recs, files = K.find_kat(cid, inst)
    checked, match, first_bad, err = K.check(so, recs)
    ok = bool(checked) and match == checked
    print("  ② KAT %s：%s %d/%d%s%s"
          % (inst, "✓" if ok else "✗", match, checked,
             "" if not first_bad else "，首个 %s" % (first_bad,),
             "" if not err else "，门报错 %s" % err))
    return ok, {"files": [os.path.basename(p) for p in files], "match": match,
                "checked": checked, "first_bad": first_bad, "error": err}


def delivery_compare(ours_so, opt_so, bits):
    """③ 与官方 opt 逐长度比对完整摘要（第四道门的核心检查，此处内联避免依赖）。

    ⚠ 摘要缓冲必须按 `bits/8` 分配，不能写死 64 字节：768 位 = 96 B、1024 位 = 128 B，
    写死 64 会覆写栈上相邻对象 —— 症状是**段错误**（本脚本第一版就栽在这里）。
    """
    ours = ctypes.CDLL(ours_so)
    opt = ctypes.CDLL(opt_so)
    for lib in (ours, opt):
        lib.CryptHash.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_ulonglong,
                                  ctypes.POINTER(ctypes.c_ubyte)]
        lib.CryptHash.restype = ctypes.c_int
    nout = max(64, bits // 8 + 8)      # 摘要字节数 + 余量
    LENS = [0, 8, 128, 512, 1000, 1024, 2048, 4096, 8192, 16384, 65536]
    buf = ctypes.create_string_buffer(1 << 16)
    bad = []
    n = 0
    for nbits in LENS:
        nbytes = (nbits + 7) // 8
        for i in range(nbytes):
            buf[i] = bytes([(i * 131 + 17) & 0xFF])
        da = (ctypes.c_ubyte * nout)()
        db = (ctypes.c_ubyte * nout)()
        ra = ours.CryptHash(bits, buf, nbits, da)
        rb = opt.CryptHash(bits, buf, nbits, db)
        n += 1
        if ra != rb or bytes(da) != bytes(db):
            diff = [i for i in range(nout) if da[i] != db[i]]
            bad.append({"bits": nbits, "rc": [ra, rb], "first_diff": diff[:1]})
    print("  ③ 与官方 opt 摘要对拍（%d 位摘要，%d 字节缓冲，11 个长度）：%s"
          % (bits, nout, "✓ 全等" if not bad else "✗ %d 个长度不同 %s" % (len(bad), bad[:3])))
    return not bad, {"n": n, "bad": bad, "nout": nout}


def main():
    only = None
    if "--only" in sys.argv:
        only = sys.argv[sys.argv.index("--only") + 1]
    t0 = time.time()
    os.makedirs(OUT, exist_ok=True)
    js_objs, err = core_objs()
    if err:
        print("✗ " + err)
        return 1
    print("复用核心目标文件：%s" % ", ".join(os.path.basename(o) for o in js_objs))

    results = {}
    all_ok = True
    for cid in ("hash-31", "hash-32"):
        if only and cid != only:
            continue
        dname, _, prefix = FAMILIES[cid]
        print("\n[%s %s]" % (cid, dname))
        so, err = build_family(cid, js_objs)
        if err:
            print("✗ " + err)
            all_ok = False
            continue
        pso, err = plain_so(cid)
        if err:
            print("✗ " + err)
            all_ok = False
            continue
        ok1, r1 = perm_gate(so, pso)
        fam = {}
        ok_all = ok1
        for cap in CAPS:
            inst = "%s-%s" % (prefix, cap)
            ok2, r2 = kat_gate(so, cid, inst)
            opt_so = find_opt(cid, inst)
            if opt_so:
                ok3, r3 = delivery_compare(so, opt_so, int(cap))
            else:
                ok3, r3 = False, {"error": "找不到官方 opt .so"}
                print("  ③ 跳过：找不到 %s 的官方 opt" % inst)
            fam[inst] = {"digest_bits": int(cap), "gate_kat": r2,
                         "gate_delivery": r3, "opt_so": opt_so,
                         "opt_so_sha256": sha256(opt_so) if opt_so else None,
                         "ok": bool(ok2 and ok3)}
            ok_all = ok_all and ok2 and ok3
        results[dname] = {"so": os.path.relpath(so, HERE), "so_sha256": sha256(so),
                          "so_bytes": os.path.getsize(so),
                          "gate_perm": r1, "instances": fam, "ok": ok_all}
        all_ok = all_ok and ok_all

    results["_timed"] = False
    results["_elapsed_s"] = round(time.time() - t0, 1)
    results["_all_gates_ok"] = all_ok
    io.open(os.path.join(HERE, "GATES.json"), "w", encoding="utf-8",
            newline="\n").write(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
    print("\n%s 三道门：%s（未计时）" % ("✓" if all_ok else "✗", "全绿" if all_ok else "有红"))
    return 0 if all_ok else 1


def find_opt(cid, inst):
    """从 rows/<cid>.json 取该实例的权威 opt .so（唯一权威来源，不手写路径）。"""
    rp = os.path.join(L0, "rows", "%s.json" % cid)
    if not os.path.exists(rp):
        return None
    data = json.load(io.open(rp, encoding="utf-8"))
    for it in data.get("instances", []):
        if it.get("instance") == inst:
            rel = (it.get("opt") or {}).get("so")
            if not rel:
                return None
            for base in (L0, os.path.dirname(L0)):
                p = os.path.join(base, rel)
                if os.path.exists(p):
                    return p
            return None
    return None


if __name__ == "__main__":
    raise SystemExit(main())
