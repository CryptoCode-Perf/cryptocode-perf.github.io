"""ZC 家族 1536 档九件：套用已证等价的 pad 空转消除（同 1280 档那条，已验证 +15.6%/+6.5%/+1.3%）。

背景：`grep "zeros until last bit position"` 扫全库，只有 ZC 三族（hash-30/31/32）
与 Pavelor 带这段；1536 档九件现在是 win（1.07–1.25），但驱动层同样每调用空转一遍。

1536 档空转上限（rate = 1536 − (digest+64)）：
  512  摘要 ⇒ rate = 1536 − 576  = 960 bit = 120 B ⇒ 959 次
  768  摘要 ⇒ rate = 1536 − 832  = 704 bit =  88 B ⇒ 703 次
  1024 摘要 ⇒ rate = 1536 − 1088 = 448 bit =  56 B ⇒ 447 次
比 1280 档更多，理论上短档收益更大。

做法：从官方胶水派生 `glue_pad1536_<hNN>_<cap>.c`，只替换那一段循环，
再与现成的 `zud1536_api.o` + 各实例 `glue.o` 同源重链接。
不动 jasmin 核心（`zud1536_p12.o` 逐字节不变），所以置换语义不变、KAT 必然仍过。

用法：python3 try_1536_pad.py --cid hash-30 [--cap 512]
产物：`zc1536/out/<inst>/ours_zc1536_<cap>_pad.so`
"""
import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
SRC = os.path.join(L0, "src")
OUT = os.path.join(HERE, "out")

OPT_FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
             "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

FAMILIES = {"hash-30": "ZC-DM", "hash-31": "ZC-DMC", "hash-32": "ZC-EDMC"}

OLD_PAD = """    /* zeros until last bit position of THIS block */
    while (bitpos < rateBytes * 8u - 1u) {
        append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0);
    }
"""

NEW_PAD = """    /* zeros until last bit position of THIS block.
     *
     * 原实现逐比特调用 `append_bit_msb_custom(..., 0)`；该函数在 b==0 时只做
     * `(*bitpos)++`，一个字节都不写，循环条件又保证进不去「攒满一块」的分支
     * ⇒ 整段等价于把 bitpos 直接推到块尾前一位。逐位等价。 */
    if (bitpos < rateBytes * 8u - 1u) {
        bitpos = rateBytes * 8u - 1u;
    }
"""


def sh(args):
    r = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return r.returncode, r.stdout.decode("utf-8", "replace")


def inst_dir(cid, cap):
    return os.path.join(SRC, cid, FAMILIES[cid], "Implementations",
                        "Implementations", "Optimized_Implementation",
                        "%s-1536-%s" % (FAMILIES[cid], cap))


def inc_dirs(cid):
    base = os.path.join(SRC, cid, FAMILIES[cid], "Implementations")
    lib = os.path.join(base, "lib", "low", "ZuD-1536")
    return [lib, os.path.join(lib, "plain"), os.path.join(lib, "AVX2"),
            os.path.join(base, "lib", "common")]


def main():
    cid = "hash-30"
    caps = ["512", "768", "1024"]
    if "--cid" in sys.argv:
        cid = sys.argv[sys.argv.index("--cid") + 1]
    if "--cap" in sys.argv:
        caps = [sys.argv[sys.argv.index("--cap") + 1]]
    if cid not in FAMILIES:
        sys.stderr.write("未知 cid %s\n" % cid)
        return 2
    tag = cid.replace("hash-", "h")

    for cap in caps:
        d = inst_dir(cid, cap)
        glue_src = os.path.join(d, "CryptHash_AlgorithmInstance.c")
        if not os.path.exists(glue_src):
            print("缺 %s" % glue_src)
            return 2
        txt = io.open(glue_src, encoding="utf-8").read()
        n = txt.count(OLD_PAD)
        if n != 1:
            sys.stderr.write("FATAL: %s pad 锚点命中 %d 次（应为 1）\n" % (cap, n))
            return 2
        txt = txt.replace(OLD_PAD, NEW_PAD)
        # 与 1280 档同样的 -Wunused-function 处理（胶水可能已把 feedforward 改寄存器）
        live = sum(1 for ln in txt.splitlines()
                   if "xor_bytes(" in ln and not ln.lstrip().startswith("//"))
        if live == 1:
            txt = txt.replace("static void xor_bytes(",
                              "static __attribute__((unused)) void xor_bytes(", 1)
        dst_c = os.path.join(HERE, "glue_pad1536_%s_%s.c" % (tag, cap))
        io.open(dst_c, "w", encoding="utf-8", newline="\n").write(txt)

        outdir = os.path.join(OUT, "%s-1536-%s" % (FAMILIES[cid], cap))
        os.makedirs(outdir, exist_ok=True)
        glue_o = os.path.join(outdir, "glue_pad.o")
        cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", glue_o]
        for x in inc_dirs(cid):
            cmd += ["-I", x]
        cmd += ["-I", d, dst_c]
        rc, log = sh(cmd)
        if rc != 0 or log.strip():
            print("✗ %s 胶水编译失败/有输出：\n%s" % (cap, log[-2500:]))
            return 1

        api_o = os.path.join(outdir, "zud1536_api.o")
        core_o = os.path.join(OUT, "zud1536_p12.o")
        round_o = os.path.join(OUT, "zud1536_round.o")
        for p in (core_o, round_o):
            if not os.path.exists(p):
                print("缺 %s" % p)
                return 2
        # hash-31/32 的 out 目录里没有 api.o（当年只在 hash-30 下编过）。
        # api 外壳是族无关的（只调 ZuD1536_avx2_AddBytes / ExtractBytes），
        # 用同一份源 + 本族的 include 路径现编。
        if not os.path.exists(api_o):
            cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", api_o]
            for x in inc_dirs(cid):
                cmd += ["-I", x]
            cmd += ["-I", os.path.join(SRC, cid, FAMILIES[cid], "Implementations",
                                       "lib", "low", "ZuD-1536"),
                    os.path.join(HERE, "zud1536_api.c")]
            rc, log = sh(cmd)
            if rc != 0 or log.strip():
                print("✗ %s api 编译失败/有输出：\n%s" % (cap, log[-2500:]))
                return 1
            print("  （现编 api.o 给 %s）" % cap)
        so = os.path.join(outdir, "ours_zc1536_%s_pad.so" % cap)
        rc, log = sh(["gcc", "-shared", "-o", so, api_o, glue_o, core_o, round_o])
        if rc != 0:
            print("✗ %s 链接失败：\n%s" % (cap, log[-2000:]))
            return 1
        print("✓ %s：%s（%d 字节）" % (cap, so, os.path.getsize(so)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
