# ZC-EDMC-1536-1024

Algorithm: ZC-EDMC | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header ZC-EDMC-1536-1024.h, prebuilt ZC-EDMC-1536-1024.so,
KAT vector KAT_2_12_ZC-EDMC-1536-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): fbfc21921e896908dafcaa3fb6db160e9b65a3a0733290e401d894ebc61ad93c
Speed (cpB, lower is faster): reference 16.85 / official-optimized 10.75 / optimized 9.24
Speedup: GM(S1-S8) 1.19x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
