#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
bash CryptoCode_Implementation/1280/build.sh
for bits in 512 768; do
  python3 "test/kat_check_$bits.py" build/CryptoCode-1280.so 100000 0 "kat/ZC-DM-1280-$bits.txt"
done
python3 test/kat_check_1280_1024.py build/CryptoCode-1280.so 100000 0 "kat/ZC-DM-1280-1024.txt"

bash CryptoCode_Implementation/1536/build.sh
for bits in 512 768 1024; do
  python3 "test/kat_check_1536_$bits.py" build/CryptoCode-1536.so 100000 0 "kat/ZC-DM-1536-$bits.txt"
done

mkdir -p build/official_tree/Implementations build/official_tree/lib
cp -R official_tree/lib/. build/official_tree/lib/
cp -R Reference_Implementation Optimized_Implementation build/official_tree/Implementations/
for width in 1280 1536; do
  for kind in Reference Optimized; do
    if [ "$kind" = Reference ]; then impl=plain; flags=-O2; else impl=AVX2; flags="-O3 -mavx2"; fi
    gcc $flags -fPIC -shared -Wl,-z,defs -Ibuild/official_tree/lib/common "build/official_tree/Implementations/${kind}_Implementation/ZC-DM-${width}-512/CryptHash_AlgorithmInstance.c" "build/official_tree/lib/low/ZuD-${width}/${impl}/ZuD${width}-${impl}.c" -o "build/${kind}-${width}.so"
    sizes="512 768 1024"
    for bits in $sizes; do
      if [ "$width" = 1536 ]; then checker="test/kat_check_1536_${bits}.py"; elif [ "$bits" = 1024 ]; then checker="test/kat_check_1280_1024.py"; else checker="test/kat_check_${bits}.py"; fi
      python3 "$checker" "build/${kind}-${width}.so" 100000 0 "kat/ZC-DM-${width}-${bits}.txt"
    done
  done
done

python3 test/differential.py

gcc -O2 test/guard_check.c -ldl -o build/guard_check
build/guard_check build/CryptoCode-1280.so 512
build/guard_check build/CryptoCode-1280.so 768
build/guard_check build/CryptoCode-1280.so 1024
build/guard_check build/CryptoCode-1536.so 512
build/guard_check build/CryptoCode-1536.so 768
build/guard_check build/CryptoCode-1536.so 1024
