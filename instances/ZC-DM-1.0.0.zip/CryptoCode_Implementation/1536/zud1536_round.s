	.att_syntax
	.text
	.p2align	5
	.global	zud1536_round
	.type	zud1536_round, %function
zud1536_round:
	vmovdqu	(%rdi), %ymm2
	vmovdqu	32(%rdi), %ymm3
	vmovdqu	64(%rdi), %ymm4
	vmovdqu	96(%rdi), %ymm5
	vmovdqu	128(%rdi), %ymm0
	vmovdqu	160(%rdi), %ymm1
	vmovdqu	(%rsi), %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm0, %ymm4, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm1, %ymm5, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpandn	%ymm2, %ymm0, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vpandn	%ymm3, %ymm1, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vpandn	%ymm4, %ymm2, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vpandn	%ymm5, %ymm3, %ymm6
	vpxor	%ymm6, %ymm1, %ymm6
	vpsrlq	$61, %ymm4, %ymm1
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm1, %ymm1
	vpsrlq	$61, %ymm5, %ymm4
	vpsllq	$3, %ymm5, %ymm5
	vpor	%ymm5, %ymm4, %ymm4
	vpermq	$57, %ymm4, %ymm4
	vpermq	$57, %ymm1, %ymm5
	vpblendd	$192, %ymm5, %ymm4, %ymm1
	vpblendd	$192, %ymm4, %ymm5, %ymm4
	vpermq	$147, %ymm6, %ymm6
	vpermq	$147, %ymm0, %ymm5
	vpblendd	$3, %ymm5, %ymm6, %ymm0
	vpblendd	$3, %ymm6, %ymm5, %ymm5
	vmovdqu	%ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpxor	%ymm0, %ymm6, %ymm6
	vmovdqu	%ymm3, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm5, %ymm7, %ymm7
	vpermq	$147, %ymm6, %ymm6
	vpermq	$147, %ymm7, %ymm7
	vpblendd	$3, %ymm7, %ymm6, %ymm8
	vpblendd	$3, %ymm6, %ymm7, %ymm7
	vpsrlq	$44, %ymm8, %ymm6
	vpsllq	$20, %ymm8, %ymm9
	vpor	%ymm9, %ymm6, %ymm6
	vpshufb	glob_data + 0(%rip), %ymm8, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vpsrlq	$44, %ymm7, %ymm8
	vpsllq	$20, %ymm7, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpshufb	glob_data + 0(%rip), %ymm7, %ymm7
	vpxor	%ymm7, %ymm8, %ymm8
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm6, %ymm1, %ymm7
	vpxor	%ymm8, %ymm4, %ymm4
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm8, %ymm5, %ymm5
	vpsrlq	$61, %ymm7, %ymm1
	vpsllq	$3, %ymm7, %ymm9
	vpor	%ymm9, %ymm1, %ymm6
	vpsrlq	$61, %ymm4, %ymm1
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm1, %ymm7
	vpermq	$57, %ymm7, %ymm4
	vpermq	$57, %ymm6, %ymm1
	vpblendd	$192, %ymm1, %ymm4, %ymm6
	vpblendd	$192, %ymm4, %ymm1, %ymm8
	vpermq	$147, %ymm5, %ymm5
	vpermq	$147, %ymm0, %ymm7
	vpblendd	$3, %ymm7, %ymm5, %ymm1
	vpblendd	$3, %ymm5, %ymm7, %ymm0
	vmovdqu	%ymm2, (%rdi)
	vmovdqu	%ymm3, 32(%rdi)
	vmovdqu	%ymm6, 64(%rdi)
	vmovdqu	%ymm8, 96(%rdi)
	vmovdqu	%ymm1, 128(%rdi)
	vmovdqu	%ymm0, 160(%rdi)
	ret
	.data
	.p2align	5
glob_data:
G$rotr8mask:
	.byte	  1,   2,   3,   4,   5,   6,   7,   0,   9,  10,  11,  12,  13,  14,  15,   8
	.byte	  1,   2,   3,   4,   5,   6,   7,   0,   9,  10,  11,  12,  13,  14,  15,   8
G$RC11:
	.byte	 18,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC10:
	.byte	160,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC9:
	.byte	240,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC8:
	.byte	128,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC7:
	.byte	 44,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC6:
	.byte	 96,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC5:
	.byte	 20,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC4:
	.byte	 32,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC3:
	.byte	208,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC2:
	.byte	192,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC1:
	.byte	 56,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC0:
	.byte	 88,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits
