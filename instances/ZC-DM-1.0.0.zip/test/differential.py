from pathlib import Path
import ctypes, random, json
root=Path(__file__).resolve().parent.parent
rng=random.Random(20261127)
results=[]
for width,bits in ((1280,512),(1280,768),(1536,512),(1536,768),(1536,1024)):
    paths=[root/f'build/Reference-{width}.so',root/f'build/CryptoCode-{width}.so']
    libs=[ctypes.CDLL(str(p)) for p in paths]
    for lib in libs:
        lib.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p]
        lib.CryptHash.restype=ctypes.c_int
    lengths=[0,1,7,8,9,1279,1280,1281,1535,1536,1537,4095,4096,4097,65535,65536,65537]+[rng.randrange(131073) for _ in range(250)]
    failures=[]
    for n in lengths:
        msg=ctypes.create_string_buffer(rng.randbytes((n+7)//8) or b'\0')
        values=[]
        for lib in libs:
            out=ctypes.create_string_buffer(bits//8);rc=lib.CryptHash(bits,msg,n,out);values.append((rc,out.raw))
        if values[0][0]!=0 or values[1][0]!=0 or values[0][1]!=values[1][1]:failures.append(n)
    results.append({'state_bits':width,'digest_bits':bits,'cases':len(lengths),'failures':failures})
    print(width,bits,'cases',len(lengths),'failures',len(failures))
(root/'build/differential.json').write_text(json.dumps(results,indent=2))
if any(x['failures'] for x in results):raise SystemExit(1)
