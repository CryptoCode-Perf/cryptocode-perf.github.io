# ZC-DM candidate package

Includes ZC-DM-1280-512/768 and ZC-DM-1536-512/768/1024.
Run `bash build_and_verify.sh` on x86-64 Linux with GCC, Python 3 and AVX2.
The script rebuilds CryptoCode, official reference and official optimized
implementations and checks each against its full KAT. Build output is local.

This is an experimental candidate: performance measurements, independent
release review and upstream redistribution permissions remain pending.
The optimized source includes padding fixes; original official sources are
retained separately. KAT success does not establish cryptographic security.

The three top-level implementation directories contain the official reference, official optimized and CryptoCode sources. The build script reconstructs the official include hierarchy in build/ from these sources and official_tree/lib.
