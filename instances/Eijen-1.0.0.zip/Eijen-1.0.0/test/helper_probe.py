"""Supplemental Eijen implemented-helper oracle; no algorithm C changes.
Standalone native phase requires original shared gate; production hooks are opt-in.
"""
import argparse,ctypes as C,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DOMAINS=[256,384,512,768,1024]
REQUIRED=['eijen_implementation_name','eijen_get_config','eijen_digest_size','eijen_rate_size','eijen_init','eijen_update','eijen_final','eijen_hash','eijen_hash_bits']
EVIDENCE_FILES=sorted(['journal.jsonl',*[role+suffix for role in ['reference','candidate'] for suffix in ['_nm.log','_stdout.json','_stderr.log']]])
POLICY={'version':2,'evidence_files':EVIDENCE_FILES,'primary_digest_bits':512,'implemented_public_helper_domains':DOMAINS,'required_symbols':REQUIRED,'hash4_same':'reference_header_declared_but_implementation_unavailable;candidate_optional_export_must_match_reference_hash_per_lane','hash4_len_unit':'bytes','reference_export_evidence':'fresh_nm_and_ctypes_must_agree','candidate_phase':'after_primary_check_before_measure','delivery_phase':'after_clean_rebuild_before_post_acceptance','failure':'exclude_candidate_or_block_delivery','all_header_declared_API_equivalence':False,'OPT_tested':False,'performance_executed':False,'seed':20261121,'retries':0}
class Config(C.Structure):_fields_=[(x,C.c_int) for x in ['digest_bits','rate_words','capacity_words','digest_words','rate_bytes','digest_bytes']]
class Context(C.Structure):_fields_=[('state',C.c_uint64*32),('buf',C.c_uint8*216),('buf_len',C.c_size_t),('cfg',C.POINTER(Config))]
class GuardContext(C.Structure):_fields_=[('prefix',C.c_ubyte*16),('ctx',Context),('suffix',C.c_ubyte*16)]
RATES={256:216,384:200,512:184,768:152,1024:120}
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.next');tmp.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8');tmp.replace(p)
def lengths(bits):
    r=RATES[bits];return sorted({0,1,7,8,r-1,r,r+1,2*r-1,2*r,2*r+1})
def partials(bits):
    r=RATES[bits];return [1,7,9,63,65,8*r-1,8*r+1,16*r-1]
def invalid_widths():return [-1,0,1,255,257,383,385,511,513,767,769,1023,1025]
def plan():
    return {'metadata_getter_cases':3*(len(DOMAINS)+len(invalid_widths())), 'byte_routes':len(DOMAINS)*10*8,'partial_bit_routes':len(DOMAINS)*8*3,'defined_error_and_NULL_empty_routes':len(DOMAINS)*20,'implementation_name_symbol_presence':1,'hash4_if_candidate_exports':len(DOMAINS)*10*2,'hash4_lanes_per_route':4,'mandatory_transcript_records':3*(len(DOMAINS)+len(invalid_widths()))+len(DOMAINS)*(80+24+20),'oracle_hash4_scalar_calls':len(DOMAINS)*10*4,'native_executed':False}
def require_contract(cfg):
    if cfg.get('digest_bits')!=512 or cfg.get('supplemental_eijen_helpers')!=POLICY:raise ValueError('Exact preregistered helper policy required')
    if cfg.get('api_contract')!={'require_in_place':True,'require_invalid_argument_equivalence':True,'require_null_empty_equivalent':True}:raise ValueError('Original strict CryptHash512 API must remain')
def data(n,lane=0):return bytes((i*73+lane*41+19)%256 for i in range(n))
class Output:
    def __init__(self,size,initial=None):
        self.size=size;body=initial if initial is not None else b'\xa5'*size
        self.buf=C.create_string_buffer(b'\xa5'*16+body+b'\xa5'*16,32+size);self.before=self.buf.raw
    @property
    def pointer(self):return C.byref(self.buf,16)
    def result(self,d):
        raw=self.buf.raw
        return {'output_sha256':hashlib.sha256(raw[16:16+d]).hexdigest(),'output_canaries':raw[:16]==self.before[:16] and raw[16+d:]==self.before[16+d:]}
def guarded_context():
    g=GuardContext();C.memset(C.byref(g),0xA5,C.sizeof(g));C.memset(C.byref(g.ctx),0,C.sizeof(Context));return g
def context_canaries(g):return bytes(g.prefix)==bytes(g.suffix)==b'\xa5'*16
def bind(lib):
    missing=[name for name in REQUIRED if not hasattr(lib,name)]
    if missing:raise ValueError('Missing implemented public helpers:'+str(missing))
    definitions={'eijen_get_config':([C.c_int],C.POINTER(Config)),'eijen_digest_size':([C.c_int],C.c_size_t),'eijen_rate_size':([C.c_int],C.c_size_t),'eijen_init':([C.POINTER(Context),C.c_int],C.c_int),'eijen_update':([C.POINTER(Context),C.c_void_p,C.c_size_t],C.c_int),'eijen_final':([C.POINTER(Context),C.c_void_p],C.c_int),'eijen_hash':([C.c_int,C.c_void_p,C.c_size_t,C.c_void_p],C.c_int),'eijen_hash_bits':([C.c_int,C.c_void_p,C.c_ulonglong,C.c_void_p],C.c_int)}
    if hasattr(lib,'eijen_hash4_same'):definitions['eijen_hash4_same']=([C.c_int,*([C.c_void_p]*4),C.c_size_t,*([C.c_void_p]*4)],C.c_int)
    for name,(args,result) in definitions.items():getattr(lib,name).argtypes=args;getattr(lib,name).restype=result
    return {name:hasattr(lib,name) for name in [*REQUIRED,'eijen_hash4_same']}
def worker(libpath):
    lib=C.CDLL(str(Path(libpath).resolve()),mode=os.RTLD_LOCAL);exports=bind(lib);rows=[];oracle=[];four=[]
    def add(key,rc,out=None,d=0,**extras):
        row={'case':key,'returncode':rc,**extras}
        if out:row.update(out.result(d))
        rows.append(row);return row
    def one(fn,bits,msg,n,key,inplace=False):
        d=bits//8;out=Output(max(d,len(msg)) if inplace else d,(msg+b'\xa5'*max(0,d-len(msg))) if inplace else None)
        inp=out.pointer if inplace else C.create_string_buffer(msg,max(1,len(msg)))
        before=bytes(inp) if not inplace else None;rc=getattr(lib,fn)(bits,inp,n,out.pointer)
        return add(key,rc,out,d,input_unchanged=True if inplace else bytes(inp)==before)
    for bits in [*DOMAINS,*invalid_widths()]:
        p=lib.eijen_get_config(bits);add(['get_config',bits],None,config=None if not p else [getattr(p.contents,n) for n,_ in Config._fields_])
        add(['digest_size',bits],int(lib.eijen_digest_size(bits)));add(['rate_size',bits],int(lib.eijen_rate_size(bits)))
    for bits in DOMAINS:
        d=bits//8;r=RATES[bits]
        for n in lengths(bits):
            msg=data(n)
            for fn,k in [('eijen_hash','hash'),('eijen_hash_bits','bits')]:
                one(fn,bits,msg,n if k=='hash' else n*8,[k,bits,n]);one(fn,bits,msg,n if k=='hash' else n*8,[k+'_inplace',bits,n],True)
            for split in [0,1,r,n//2]:
                split=min(split,n);g=guarded_context();rcs=[lib.eijen_init(C.byref(g.ctx),bits)];a=C.create_string_buffer(msg[:split],max(1,split));b=C.create_string_buffer(msg[split:],max(1,n-split));before=(a.raw,b.raw)
                rcs.extend([lib.eijen_update(C.byref(g.ctx),a,split),lib.eijen_update(C.byref(g.ctx),None,0),lib.eijen_update(C.byref(g.ctx),b,n-split)])
                out=Output(d);rcs.append(lib.eijen_final(C.byref(g.ctx),out.pointer));add(['stream',bits,n,split],rcs,out,d,context_canaries=context_canaries(g),input_unchanged=(a.raw,b.raw)==before)
            # Independent original scalar oracle for an optional four-lane export.
            expected=[]
            for lane in range(4):
                lane_msg=C.create_string_buffer(data(n,lane),max(1,n));out=Output(d);rc=lib.eijen_hash(bits,lane_msg,n,out.pointer);expected.append({'returncode':rc,**out.result(d)})
            oracle.append({'case':[bits,n],'lanes':expected})
            if exports['eijen_hash4_same']:
                for alias in [False,True]:
                    inputs=[];outputs=[]
                    for lane in range(4):
                        msg_lane=data(n,lane)
                        if alias:
                            out=Output(max(d,n),msg_lane+b'\xa5'*max(0,d-n));inputs.append(out.pointer);outputs.append(out)
                        else:inputs.append(C.create_string_buffer(msg_lane,max(1,n)));outputs.append(Output(d))
                    snapshots=[bytes(x) for x in inputs] if not alias else None
                    rc=lib.eijen_hash4_same(bits,*inputs,n,*[o.pointer for o in outputs]);four.append({'case':[bits,n,alias],'returncode':rc,'lanes':[o.result(d) for o in outputs],'input_unchanged':True if alias else snapshots==[bytes(x) for x in inputs]})
        for nbits in partials(bits):
            msg=data((nbits+7)//8);one('eijen_hash_bits',bits,msg,nbits,['partial',bits,nbits]);altered=bytearray(msg);altered[-1]^=(1<<(8-nbits%8))-1
            one('eijen_hash_bits',bits,bytes(altered),nbits,['partial_unused_low',bits,nbits]);one('eijen_hash_bits',bits,msg,nbits,['partial_inplace',bits,nbits],True)
        # Only source-defined rejection paths,with valid allocated objects otherwise.
        for fn in ['eijen_hash','eijen_hash_bits']:
            for wrong in [0,bits-1,bits+1]:
                out=Output(d);add(['invalid_width',fn,bits,wrong],getattr(lib,fn)(wrong,b'x',1,out.pointer),out,d)
            for kind in ['NULL_msg_positive','NULL_output','NULL_empty']:
                out=Output(d);msg=None if kind!='NULL_output' else b'x';n=0 if kind=='NULL_empty' else 1
                add([kind,fn,bits],getattr(lib,fn)(bits,msg,n,None if kind=='NULL_output' else out.pointer),out,d)
        for kind in ['init_NULL','init_invalid','update_NULLctx','update_zerocontext','final_NULLctx','update_NULLpositive','final_zerocontext','final_NULLoutput']:
            g=guarded_context();out=Output(d)
            if kind=='init_NULL':rc=lib.eijen_init(None,bits)
            elif kind=='init_invalid':rc=lib.eijen_init(C.byref(g.ctx),0)
            elif kind=='update_NULLctx':rc=lib.eijen_update(None,b'x',1)
            elif kind=='update_zerocontext':rc=lib.eijen_update(C.byref(g.ctx),b'x',1)
            elif kind=='final_NULLctx':rc=lib.eijen_final(None,out.pointer)
            elif kind=='final_zerocontext':rc=lib.eijen_final(C.byref(g.ctx),out.pointer)
            else:
                if lib.eijen_init(C.byref(g.ctx),bits)!=0:raise ValueError('Original valid init failed')
                rc=lib.eijen_update(C.byref(g.ctx),None,1) if kind=='update_NULLpositive' else lib.eijen_final(C.byref(g.ctx),None)
            add([kind,bits],rc,out,d,context_canaries=context_canaries(g))
    result={'status':'completed','exports':exports,'rows':rows,'scalar_four_oracle':oracle,'optional_hash4':four,'implementation_name':'symbol_presence_only;string_not_compared'}
    print(json.dumps(result))

def compare_transcripts(ref,candidate,nm_exports):
    for role,value in [('reference',ref),('candidate',candidate)]:
        if value.get('status')!='completed':raise ValueError(role+' helper worker incomplete')
        if set(nm_exports[role])!=set(name for name,yes in value['exports'].items() if yes):raise ValueError(role+' nm/ctypes exports differ')
        if not all(value['exports'].get(n) for n in REQUIRED):raise ValueError(role+' missing implemented helper')
        if len(value['rows'])!=plan()['mandatory_transcript_records']:raise ValueError('Helper coverage incomplete')
        for row in value['rows']:
            if row.get('output_canaries',True) is not True or row.get('context_canaries',True) is not True or row.get('input_unchanged',True) is not True:raise ValueError('Buffer/context corruption or input mutation')
    if ref['exports']['eijen_hash4_same']:raise ValueError('Reference export differs from preregistered unsupported policy;review new version')
    if ref['rows']!=candidate['rows']:raise ValueError('Implemented public helper semantics differ')
    optional='unavailable_not_validated'
    if candidate['exports']['eijen_hash4_same']:
        lookup={tuple(x['case']):x['lanes'] for x in ref['scalar_four_oracle']}
        if len(candidate['optional_hash4'])!=plan()['hash4_if_candidate_exports']:raise ValueError('Optional hash4 coverage incomplete')
        for row in candidate['optional_hash4']:
            expected=lookup[tuple(row['case'][:2])]
            if row['returncode']!=0 or row['input_unchanged'] is not True or any(x['returncode']!=0 for x in expected) or row['lanes']!=[{k:v for k,v in x.items() if k!='returncode'} for x in expected]:raise ValueError('Optional hash4 does not match original scalar lanes')
        optional='candidate_export_validated_against_original_scalar_hash'
    return {'implemented_helper_equivalence':True,'hash4_reference':'reference_unsupported','hash4_candidate':optional,'all_header_declared_API_equivalence':False,'mandatory_records':len(ref['rows'])}


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        worker(Path(sys.argv[2])); sys.exit(0)
    root = Path(__file__).resolve().parent.parent
    for bits in (256,384,512,768,1024):
        values = {}; exports = {}
        for role, kind in [('reference','Reference'),('candidate','CryptoCode')]:
            so = root / 'build' / f'{kind}-{bits}.so'
            result = subprocess.run([sys.executable, __file__, '--worker', str(so)], capture_output=True, text=True, check=True)
            values[role] = json.loads(result.stdout)
            nm = subprocess.check_output(['nm','-D','--defined-only',str(so)], text=True)
            exports[role] = sorted({line.split()[-1] for line in nm.splitlines() if line.split() and line.split()[-1] in [*REQUIRED,'eijen_hash4_same']})
        result = compare_transcripts(values['reference'], values['candidate'], exports)
        print(f'Eijen-{bits}: {result["mandatory_records"]} helper checks passed; hash4 reference unsupported', flush=True)
