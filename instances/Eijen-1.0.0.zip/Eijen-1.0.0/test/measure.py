#!/usr/bin/env python3
"""Measure freshly built Eijen libraries under a caller-provided shared lock."""
import argparse,csv,datetime,fcntl,hashlib,json,math,os,platform,statistics,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--lock',required=True,help='shared exclusive measurement lock path')
parser.add_argument('--output',required=True,help='new empty results directory')
a=parser.parse_args(); out=Path(a.output).resolve(); out.mkdir(parents=True,exist_ok=False)
sizes=[32,128,512,1024,4096,8192,16384,65536]; seeds=[20261212,20261213,20261214]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bits_list=[256,384,512,768,1024]
libs={str(b):{'official':root/f'build/Optimized-{b}.so','cryptocode':root/f'build/CryptoCode-{b}.so'} for b in bits_list}
for pair in libs.values():
 for f in pair.values():
  if not f.is_file():raise SystemExit('Build and verify all libraries first')
bench=out/'pair_bench';source=root/'test/pair_bench.c';subprocess.run(['gcc','-O2',str(source),'-ldl','-o',str(bench)],check=True)
plan={'sizes_bytes':sizes,'seeds':seeds,'samples_per_size_per_round':101,'batch_target_us':500,'cpu':0,'baseline':'official','ratio':'official/cryptocode','build_script_sha256':sha(root/'build_and_verify.sh'),'harness_source_sha256':sha(source),'libraries':{b:{k:sha(v) for k,v in pair.items()} for b,pair in libs.items()},'platform':platform.platform(),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limitations':'Cooperative lock does not exclude unrelated host activity; elapsed time is not hardware cycles.'}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with open(a.lock,'a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 (out/'environment.txt').write_text(subprocess.check_output(['lscpu'],text=True)+subprocess.check_output(['gcc','--version'],text=True))
 (out/'processes-before.txt').write_text(subprocess.check_output(['ps','-eo','pid,comm,pcpu,args','--sort=-pcpu'],text=True))
 for bits in bits_list:
  for seed in seeds:
   name=f'Eijen-{bits}';pair=libs[str(bits)];cmd=['taskset','-c','0',str(bench),str(pair['official']),str(pair['cryptocode']),str(bits),'101','500',str(seed),','.join(map(str,sizes)),name]
   with (out/f'{name}-{seed}.csv').open('x') as f:subprocess.run(cmd,stdout=f,check=True)
  print(name,'complete',flush=True)
 (out/'processes-after.txt').write_text(subprocess.check_output(['ps','-eo','pid,comm,pcpu,args','--sort=-pcpu'],text=True))
result=[]
for bits in bits_list:
 rounds=[]
 for seed in seeds:
  f=out/f'Eijen-{bits}-{seed}.csv'; rows=list(csv.DictReader(f.open()));assert len(rows)==808
  ratios=[]
  for size in sizes:
   group=[x for x in rows if int(x['bytes'])==size];assert len(group)==101 and {int(x['round']) for x in group}==set(range(101)) and all(x['label']==f'Eijen-{bits}' for x in group)
   official=statistics.mean(float(x['baseline_ns']) for x in group);ours=statistics.mean(float(x['candidate_ns']) for x in group);assert official>0 and ours>0
   ratios.append({'bytes':size,'official_ns':official,'cryptocode_ns':ours,'ratio':official/ours})
  rounds.append({'seed':seed,'raw_sha256':sha(f),'geometric_mean':math.exp(statistics.mean(math.log(x['ratio']) for x in ratios)),'sizes':ratios})
 result.append({'instance':f'Eijen-{bits}','overall_geometric_mean':math.exp(statistics.mean(math.log(x['geometric_mean']) for x in rounds)),'rounds':rounds})
(out/'summary.json').write_text(json.dumps({'direction':'official/cryptocode: above one favors CryptoCode','results':result},indent=2)+'\n')
