#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "eijen.h"
typedef int (*fn_t)(int,const uint8_t*,unsigned long long,uint8_t*);
int main(int argc,char **argv){
 if(argc!=2)return 2;
 void *h=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!h){fprintf(stderr,"%s\n",dlerror());return 3;}
 void *sym=dlsym(h,"eijen_hash_bits");fn_t ref;memcpy(&ref,&sym,sizeof(ref));if(!ref)return 4;
 const int bits[]={256,384,512,768,1024};unsigned x=20261127;int cases=0;
 for(unsigned j=0;j<sizeof(bits)/sizeof(bits[0]);++j){
  for(int k=0;k<512;++k){
   x^=x<<13;x^=x>>17;x^=x<<5;unsigned n=(k<16)?(unsigned[]){0,1,7,8,9,1023,1024,1025,1599,1600,1601,1727,1728,1729,4095,4096}[k]:x%65537;
   size_t len=(n+7)/8;uint8_t *msg=malloc(len?len:1);uint8_t a[128],b[128];if(!msg)return 5;
   for(size_t i=0;i<len;i++)msg[i]=(uint8_t)(i*131u+k*17u+j);
   int ra=ref(bits[j],msg,n,a),rb=eijen_hash_bits(bits[j],msg,n,b);
   if(ra||rb||memcmp(a,b,(size_t)bits[j]/8)){fprintf(stderr,"mismatch bits=%d n=%u\n",bits[j],n);free(msg);return 1;}
   free(msg);++cases;
  }
 }
 dlclose(h);printf("sanitized helper comparisons: %d passed\n",cases);return 0;
}
