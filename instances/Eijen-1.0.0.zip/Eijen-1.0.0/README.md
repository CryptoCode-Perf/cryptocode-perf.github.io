# Eijen 1.0.0 — CryptoCode implementation

Instances: Eijen-256, Eijen-384, Eijen-512, Eijen-768 and Eijen-1024.
Requires x86-64 Linux/WSL2, AVX2, GCC with AddressSanitizer and UBSan, Python 3
and standard Unix tools. From this directory run:

    bash build_and_verify.sh

The script rebuilds reference, official optimized and CryptoCode implementations,
checks 4097 known-answer vectors per implementation and instance, exercises
selected long inputs and guarded buffers, and compares 674 public-helper cases
per implementation across all five digest domains. The reference declares
`eijen_hash4_same` conditionally but does not implement it; full header API
equivalence is not claimed. A separate sanitizer check exercises the repaired
384-bit implementation for 2560 bit-length inputs across five domains; leak
detection is disabled for that check. Outputs and compile commands go in build/.

`CryptHash(int bits, const unsigned char *msg, unsigned long long msg_bits,
unsigned char *digest)` uses bit lengths; allocate bits/8 bytes for output.
The streaming helper `eijen_update` takes byte lengths. `eijen.h` defines the
other helper APIs. AVX2 is required and no runtime dispatch is included.

The 384-bit implementation's original fast path was specialized to its own
rate and gave incorrect results for other digest domains exposed by public
helpers. The delivered source adds a generic path for those domains, retaining
the 384-bit fast path. See results/eijen-384-repair.json and the patch.

Performance: results/2026-11-27-delivery-comparison contains three 101-sample
rounds at eight message sizes for rebuilt official optimized and CryptoCode
libraries. results/2026-11-27-384-repair-comparison also compares the repair
with the earlier 384-bit build and report implementation. Ratios measure
elapsed nanoseconds, not hardware cycles, and depend on machine and load.
The earlier 384-bit build failed multi-domain helper checks and is retained
only as historical evidence. Reference-versus-official measurements
are recorded separately under results/2026-11-27-reference-comparison;
they were sampled in a different session and should not be treated as a
simultaneous three-way comparison. Supplemental helper receipts are under
results/helper-exact7/; see their README for scope. For a fresh comparison after building:

    python3 test/measure.py --lock /path/to/shared/measurement.lock --output /path/to/new/results

The lock must be shared by all participating measurements; it cannot exclude
unrelated host work. Original source notices are preserved. Tests do not prove
security or constant-time behavior. See SOURCE_MANIFEST.json for hashes.
