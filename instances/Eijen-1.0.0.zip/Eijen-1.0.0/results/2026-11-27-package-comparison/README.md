# Exploratory comparisons

The package comparison uses package-rebuilt official optimized and CryptoCode
libraries. `summary.json` and the raw CSV files preserve all samples; ratios
are official time / CryptoCode time. The report comparison separately uses
the previously frozen report and website binaries. It does not establish
that the older displayed website numbers used these identical binaries.
Both comparisons use CLOCK_MONOTONIC_RAW in nanoseconds, not core cycles,
and randomized ABBA/BAAB pairs. WSL host load cannot be excluded by the
cooperative lock. CPU, toolchain and source identity are in the plan or
summary. Results are exploratory; they are not universal fastest claims.
The included `test/pair_bench.c` is the measurement harness.
