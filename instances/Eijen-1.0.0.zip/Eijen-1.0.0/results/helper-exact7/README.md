# Supplemental helper comparison receipts

Each instance directory contains the exact seven helper evidence files and
result.json, produced by the CAP helper checker on binaries from the prior
clean extraction. Each records 674 mandatory cases across five digest domains.
This is a standalone helper-only check using the 512 helper probe contract;
the fixed CryptHash wrapper's actual digest is recorded in the binding. It is
not a claim that the complete registered CAP task lifecycle was run. The
original reference conditionally declares but does not implement hash4.
