#include "eijen.h"
#include "eijen_internal.h"

#include <string.h>
#include <immintrin.h>

const char *eijen_implementation_name(void) {
    return "Eijen x86 reference C99";
}

const eijen_config *eijen_get_config(int digest_bits) {
    return eijen_config_by_bits(digest_bits);
}

size_t eijen_digest_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->digest_bytes;
}

size_t eijen_rate_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->rate_bytes;
}

/*
 * Canonical-index AVX2 layout: RL[p][t] = natural state word 4t+p (t=0..3),
 * RH[p][t] = natural word 16+4t+p.  The word permutation sigma maps, in
 * canonical coordinates, R'[0]=R[2]<<<5, R'[1]=R[0], R'[2]=R[1]<<<7,
 * R'[3]=R[3]<<<4.  The ctx->state array is kept in this canonical layout so
 * no natural<->canonical transpose is needed between absorbed blocks.
 */

#define EIJEN_ROTL_I(x, n)                                                   \
    _mm256_or_si256(_mm256_slli_epi64((x), (n)),                             \
                    _mm256_srli_epi64((x), 64 - (n)))

#define EIJEN_ROTL56(x, M) _mm256_shuffle_epi8((x), (M))

#define EIJEN_MIX(R0, R1, R2, R3, r0, r1, r2, r3, r4, r5, RC) do {            \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r0));                 \
    (R0) = _mm256_xor_si256(EIJEN_ROTL_I((R0), (r4)), (RC));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r1));                 \
    (R2) = EIJEN_ROTL_I((R2), (r5));                                         \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r2));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r3));                 \
} while (0)

#define EIJEN_MIX_HI(R0, R1, R2, R3, r1, r2, r3, r4, r5, RC, M) do {          \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL56(_mm256_xor_si256((R3), (R0)), (M));                  \
    (R0) = _mm256_xor_si256(EIJEN_ROTL_I((R0), (r4)), (RC));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r1));                 \
    (R2) = EIJEN_ROTL_I((R2), (r5));                                         \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r2));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r3));                 \
} while (0)

/* Each output word equals the XOR of the other three inputs.  Computing the
 * two disjoint pair-XORs once yields all four outputs in six XORs instead of
 * the seven required by forming the full parity and XORing it back in. */
#define EIJEN_LINEAR(R0, R1, R2, R3) do {                                    \
    __m256i _p01 = _mm256_xor_si256((R0), (R1));                             \
    __m256i _p23 = _mm256_xor_si256((R2), (R3));                             \
    __m256i _n0 = _mm256_xor_si256((R1), _p23);                              \
    __m256i _n1 = _mm256_xor_si256((R0), _p23);                              \
    __m256i _n2 = _mm256_xor_si256((R3), _p01);                              \
    __m256i _n3 = _mm256_xor_si256((R2), _p01);                              \
    (R0) = _n0; (R1) = _n1; (R2) = _n2; (R3) = _n3;                          \
} while (0)

#define EIJEN_P1230 0x39
#define EIJEN_P3012 0x93

#define EIJEN_SIGMA(RL, RH) do {                                             \
    __m256i _a, _b, _s0l, _s0h, _s3l;                                        \
    _s0l = (RL)[0]; _s0h = (RH)[0];                                          \
    _a = _mm256_permute4x64_epi64((RH)[2], EIJEN_P1230);                      \
    _b = _mm256_permute4x64_epi64((RL)[2], EIJEN_P1230);                      \
    (RL)[0] = _mm256_blend_epi32(_a, _b, 0xC0);                               \
    (RH)[0] = _mm256_blend_epi32(_b, _a, 0xC0);                               \
    _a = _mm256_permute4x64_epi64((RH)[1], EIJEN_P3012);                      \
    _b = _mm256_permute4x64_epi64((RL)[1], EIJEN_P3012);                      \
    (RL)[2] = _mm256_blend_epi32(_a, _b, 0xFC);                               \
    (RH)[2] = _mm256_blend_epi32(_b, _a, 0xFC);                               \
    (RL)[1] = _s0l; (RH)[1] = _s0h;                                          \
    _s3l = (RL)[3]; (RL)[3] = (RH)[3]; (RH)[3] = _s3l;                       \
} while (0)

/* In-place 16-round permutation on canonical AVX2 registers. */
static void eijen_permutation(__m256i RL[4], __m256i RH[4]) {
    __m256i rcv0, rcv1;
    __m256i rot56 = _mm256_setr_epi8(
        1, 2, 3, 4, 5, 6, 7, 0,  9, 10, 11, 12, 13, 14, 15, 8,
        1, 2, 3, 4, 5, 6, 7, 0,  9, 10, 11, 12, 13, 14, 15, 8);
    int r;

    for (r = 0; r < EIJEN_ROUNDS; r++) {
        rcv0 = _mm256_set1_epi64x((long long)EIJEN_RC0[r]);
        rcv1 = _mm256_set1_epi64x((long long)EIJEN_RC1[r]);
        EIJEN_MIX(RL[0], RL[1], RL[2], RL[3],
                  36, 54, 45, 44, 18, 9, rcv0);
        EIJEN_MIX_HI(RH[0], RH[1], RH[2], RH[3],
                     46, 54, 34, 19, 51, rcv1, rot56);
        EIJEN_SIGMA(RL, RH);
        EIJEN_LINEAR(RL[0], RL[1], RL[2], RL[3]);
        EIJEN_LINEAR(RH[0], RH[1], RH[2], RH[3]);
        EIJEN_SIGMA(RL, RH);
    }
}

/* Persistent canonical layout: ctx->state holds RL[0..3] in slots 0..15 and
 * RH[0..3] in slots 16..31, so canonical qword t of register p is at
 * state[8p+t].  Eight direct YMM loads/stores replace the per-block
 * natural<->canonical gather/scatter entirely. */
static void eijen_load_state(const eijen_ctx *ctx, __m256i RL[4], __m256i RH[4]) {
    int p;
    for (p = 0; p < 4; p++) {
        RL[p] = _mm256_loadu_si256((const __m256i *)(ctx->state + 8 * p));
        RH[p] = _mm256_loadu_si256((const __m256i *)(ctx->state + 8 * p + 4));
    }
}

static void eijen_store_state(eijen_ctx *ctx, const __m256i RL[4], const __m256i RH[4]) {
    int p;
    for (p = 0; p < 4; p++) {
        _mm256_storeu_si256((__m256i *)(ctx->state + 8 * p), RL[p]);
        _mm256_storeu_si256((__m256i *)(ctx->state + 8 * p + 4), RH[p]);
    }
}

/* Digest-384 config: rate_words=25, capacity_words=7 (natural 25..31).
 * Mapping: RH[p][t] = natural word 16+4t+p.
 *   w25->RH[1]lane2, w26->RH[2]lane2, w27->RH[3]lane2,
 *   w28->RH[0]lane3, w29->RH[1]lane3, w30->RH[2]lane3, w31->RH[3]lane3.
 * Lane masks are all-ones in the active qword lanes, zero elsewhere. */
static __m256i eijen_cap_mask(int p) {
    /* lane t is active for natural word 16+4t+p in [25,31]. */
    uint64_t active = 0;
    int t;
    for (t = 0; t < 4; t++) {
        int w = 16 + 4 * t + p;
        if (w >= 25 && w <= 31) active |= UINT64_C(1) << t;
    }
    return _mm256_set_epi64x(
        (active & 8) ? -1LL : 0LL, (active & 4) ? -1LL : 0LL,
        (active & 2) ? -1LL : 0LL, (active & 1) ? -1LL : 0LL);
}

/* Transpose a 4x4 matrix of qwords held as four rows (one YMM each):
 * out[p][t] = in[t][p].  Pure AVX2 unpack/permute, no scalar lane gather. */
static void eijen_transpose4(__m256i r[4]) {
    __m256i t0 = _mm256_unpacklo_epi64(r[0], r[1]);
    __m256i t1 = _mm256_unpackhi_epi64(r[0], r[1]);
    __m256i t2 = _mm256_unpacklo_epi64(r[2], r[3]);
    __m256i t3 = _mm256_unpackhi_epi64(r[2], r[3]);
    r[0] = _mm256_permute2x128_si256(t0, t2, 0x20);
    r[1] = _mm256_permute2x128_si256(t1, t3, 0x20);
    r[2] = _mm256_permute2x128_si256(t0, t2, 0x31);
    r[3] = _mm256_permute2x128_si256(t1, t3, 0x31);
}

static void eijen_absorb_block(eijen_ctx *ctx, const uint8_t *block, int is_last) {
    /* The fast path below is specialized for the 384-bit rate.  Public helper
     * APIs accept all supported digest lengths, so handle other rates using the
     * same canonical state layout and permutation without reading past block. */
    if (ctx->cfg->rate_words != 25) {
        uint64_t saved[17];
        __m256i low[4], high[4];
        int w, cap = ctx->cfg->rate_words;
        for (w = cap; w < EIJEN_STATE_WORDS; ++w) {
            int index = (w % 4) * 8 + (w / 16) * 4 + ((w % 16) / 4);
            saved[w - cap] = ctx->state[index];
        }
        for (w = 0; w < cap; ++w) {
            int index = (w % 4) * 8 + (w / 16) * 4 + ((w % 16) / 4);
            ctx->state[index] ^= eijen_load64_le(block + (size_t)w * 8U);
        }
        if (is_last) ctx->state[31] ^= UINT64_C(1) << 63;
        eijen_load_state(ctx, low, high);
        eijen_permutation(low, high);
        eijen_store_state(ctx, low, high);
        for (w = cap; w < EIJEN_STATE_WORDS; ++w) {
            int index = (w % 4) * 8 + (w / 16) * 4 + ((w % 16) / 4);
            ctx->state[index] ^= saved[w - cap];
        }
        return;
    }
    __m256i RL[4], RH[4];
    __m256i caph[4];
    __m256i ml[4], mh[4], maskh;
    int p;

    eijen_load_state(ctx, RL, RH);

    /* Capture the seven capacity qwords in canonical coordinates. */
    for (p = 0; p < 4; p++) {
        maskh = eijen_cap_mask(p);
        caph[p] = _mm256_and_si256(RH[p], maskh);
    }

    /* Load 25 message qwords directly into AVX2 rows and transpose into the
     * canonical register layout: register p, lane t = natural word 4t+p. */
    for (p = 0; p < 4; p++) {
        ml[p] = _mm256_loadu_si256((const __m256i *)(block + (size_t)p * 32U));
    }
    mh[0] = _mm256_loadu_si256((const __m256i *)(block + 128));
    mh[1] = _mm256_loadu_si256((const __m256i *)(block + 160));
    mh[2] = _mm256_maskload_epi64((const long long *)(block + 192),
                                  _mm256_setr_epi64x(-1LL, 0LL, 0LL, 0LL));
    mh[3] = _mm256_setzero_si256();
    eijen_transpose4(ml);
    eijen_transpose4(mh);

    for (p = 0; p < 4; p++) {
        RL[p] = _mm256_xor_si256(RL[p], ml[p]);
        RH[p] = _mm256_xor_si256(RH[p], mh[p]);
    }

    /* Last-block padding: parent XORs 1<<63 into natural word 31, which in
     * canonical coordinates is RH[3] lane 3. */
    if (is_last) {
        RH[3] = _mm256_xor_si256(RH[3], _mm256_setr_epi64x(
            0, 0, 0, (long long)(UINT64_C(1) << 63)));
    }

    eijen_permutation(RL, RH);

    /* Feed the saved capacity back in canonical coordinates. */
    for (p = 0; p < 4; p++) {
        maskh = eijen_cap_mask(p);
        RH[p] = _mm256_xor_si256(RH[p], _mm256_and_si256(caph[p], maskh));
    }

    eijen_store_state(ctx, RL, RH);
}

int eijen_init(eijen_ctx *ctx, int digest_bits) {
    const eijen_config *cfg;
    if (ctx == NULL) return -1;
    cfg = eijen_get_config(digest_bits);
    if (cfg == NULL) return -1;
    memset(ctx, 0, sizeof(*ctx));
    ctx->cfg = cfg;
    return 0;
}

int eijen_update(eijen_ctx *ctx, const uint8_t *data, size_t len) {
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || (data == NULL && len != 0U)) return -1;
    rb = (size_t)ctx->cfg->rate_bytes;
    while (len > 0U) {
        size_t space = rb - ctx->buf_len;
        size_t take = len < space ? len : space;
        if (ctx->buf_len == 0U && len > rb) {
            eijen_absorb_block(ctx, data, 0);
            data += rb; len -= rb; continue;
        }
        memcpy(ctx->buf + ctx->buf_len, data, take);
        ctx->buf_len += take;
        data += take; len -= take;
        if (ctx->buf_len == rb && len > 0U) {
            eijen_absorb_block(ctx, ctx->buf, 0);
            ctx->buf_len = 0U;
        }
    }
    return 0;
}

static int eijen_final_partial(eijen_ctx *ctx, uint8_t partial_byte,
                                 unsigned int partial_bits, uint8_t *digest) {
    int i, ds;
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || digest == NULL || partial_bits > 7U) return -1;
    rb = (size_t)ctx->cfg->rate_bytes;
    if (ctx->buf_len == rb) {
        eijen_absorb_block(ctx, ctx->buf, 0);
        ctx->buf_len = 0U;
    }
    if (partial_bits == 0U) {
        ctx->buf[ctx->buf_len] = 0x01U;
    } else {
        uint8_t keep = (uint8_t)(0xffU << (8U - partial_bits));
        uint8_t pad = (uint8_t)(0x80U >> partial_bits);
        ctx->buf[ctx->buf_len] = (uint8_t)((partial_byte & keep) | pad);
    }
    ctx->buf_len++;
    memset(ctx->buf + ctx->buf_len, 0, rb - ctx->buf_len);
    eijen_absorb_block(ctx, ctx->buf, 1);
    /* Digest words are the final digest_words natural words (26..31 for
     * Eijen-384).  Persistent state is canonical: natural w=16+4t+p is at
     * slot 8p+4+t.  Only digest 384 is compiled here (6 digest words). */
    ds = EIJEN_STATE_WORDS - ctx->cfg->digest_words;
    for (i = 0; i < ctx->cfg->digest_words; i++) {
        int w = ds + i;
        int p = w & 3;
        int t = (w >> 2) - 4;
        eijen_store64_le(digest + ((size_t)i * 8U),
                         ctx->state[8 * p + 4 + t]);
    }
    return 0;
}

int eijen_final(eijen_ctx *ctx, uint8_t *digest) {
    return eijen_final_partial(ctx, 0U, 0U, digest);
}

int eijen_hash(int digest_bits, const uint8_t *msg, size_t len, uint8_t *digest) {
    eijen_ctx ctx;
    if (eijen_init(&ctx, digest_bits) != 0) return -1;
    if (eijen_update(&ctx, msg, len) != 0) return -1;
    return eijen_final(&ctx, digest);
}

int eijen_hash_bits(int digest_bits, const uint8_t *msg,
                     unsigned long long msg_len_bits, uint8_t *digest) {
    eijen_ctx ctx;
    unsigned long long full_bytes = msg_len_bits / 8ULL;
    unsigned int partial_bits = (unsigned int)(msg_len_bits & 7ULL);
    uint8_t partial_byte = 0U;
    if ((msg == NULL && msg_len_bits != 0ULL) || digest == NULL) return -1;
    if (full_bytes > (unsigned long long)((size_t)-1)) return -1;
    if (eijen_init(&ctx, digest_bits) != 0) return -1;
    if (eijen_update(&ctx, msg, (size_t)full_bytes) != 0) return -1;
    if (partial_bits != 0U) partial_byte = msg[full_bytes];
    return eijen_final_partial(&ctx, partial_byte, partial_bits, digest);
}
