# Mozi — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| MOZI-1024 | `MOZI-1024.so` | 31176 B | `f122162919e7f5801523947c110d4d7858e9099b4ce42b994d4d2c54b1a844b0` |
| MOZI-384 | `MOZI-384.so` | 27016 B | `43c7de96ef495007e82051ecff5ea1951c66b64cf10dcfc0c0e58d8ef5a6653a` |
| MOZI-512 | `MOZI-512.so` | 26776 B | `f4ba38b999bbcf36e2b43f8756ba0b0397014fc1eb6e80559c5cd31f8b6db11f` |
| MOZI-768 | `MOZI-768.so` | 31176 B | `9899cb76364bb36f62b94617edb5d0c01b9692ecb22f4abedb8730907681c180` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| MOZI-1024 | 1024 | 19.8096 | 5.8355 | 5.53964 | 1.053408 | 1.0693 |
| MOZI-384 | 384 | 11.9678 | 4.3333 | 3.188875 | 1.35888 | 1.3867 |
| MOZI-512 | 512 | 17.4014 | 4.8736 | 4.523188 | 1.07747 | 1.083 |
| MOZI-768 | 768 | 15.2646 | 4.4222 | 4.121048 | 1.073077 | 1.0581 |

## 优化方法（逐实例原文，来自交付清单）

### MOZI-1024
参数化精简 sponge 外壳（`RATE`/`HASHB` 编译期常量、`static` 内联）+ 引擎生成的置换核（`_overnight/l0/mozi_sib/build_shell_ab.py`）`_std/out/so/libh20d_ours.so` ★与在册 h20(MOZI-384) 同源不同壳/不同核：官方四档 `Reference_Implementation/MOZI-{384,512,768,1024}/CryptHash_AlgorithmInstance.c` 互不相同（7778/7778/8141/8143 B），但 `diff` 显示差异只有注释、rate/hash 两个数字（本档 rate = 120 B、hash = 128 B）与 sponge 变体（384/512 纯 sponge，768/1024 F-sponge：末块 `state[rate] ^= 0x80`、每块 `memcpy(forward+rate, state+rate, 256-rate)` 后逐字节 feedforward、从 `state[256-hash+i]` 挤出）；`rhoY[4][4]` 与 `RCON[24]` 四档完全相同，`permutation(state, roundNum)` 轮数由调用方传（本档 24 轮）⇒ 置换核心与档位无关，本行与兄弟档共用同一份 `gen_mozi_v256b.py` 生成的核（r20 给 384/512、r24 给 768/1024），`.so` 各自独立。**提速来自驱动层而不是核**：官方 `hash_sponge`/`hash_Fsponge` 的 `rate`/`hash` 是运行时参数且函数非 `static` ⇒ 逐字节 xor 吸收循环无法向量化；本件换成 `RATE`/`HASHB` 为 `#define` 编译期常量、函数 `static` 的精简外壳，同核隔离实验单这一项就快 13.56 个百分点。等价性：A1 `kat_gate` 全量 4097/4097（ours/ref/opt 三方）；A2 外壳形状与档位一一对应（纯 sponge 壳只配 512、F-sponge 壳只配 768/1024，套错 match=0）；A3 负对照核常量 +1 与壳 `RATE` +8 摘要都必须变（都变了）、同壳同核复建仍 4097/4097。构建：`_overnight/l0/mozi_sib/build_shell_ab.py`。

### MOZI-384
_cpb_tc/mozi_v256b.s + alg/h20/ref_agent.c

### MOZI-512
参数化精简 sponge 外壳（`RATE`/`HASHB` 编译期常量、`static` 内联）+ 引擎生成的置换核（`_overnight/l0/mozi_sib/build_shell_ab.py`）`_std/out/so/libh20b_ours.so` ★与在册 h20(MOZI-384) 同源不同壳/不同核：官方四档 `Reference_Implementation/MOZI-{384,512,768,1024}/CryptHash_AlgorithmInstance.c` 互不相同（7778/7778/8141/8143 B），但 `diff` 显示差异只有注释、rate/hash 两个数字（本档 rate = 128 B、hash = 64 B）与 sponge 变体（384/512 纯 sponge，768/1024 F-sponge：末块 `state[rate] ^= 0x80`、每块 `memcpy(forward+rate, state+rate, 256-rate)` 后逐字节 feedforward、从 `state[256-hash+i]` 挤出）；`rhoY[4][4]` 与 `RCON[24]` 四档完全相同，`permutation(state, roundNum)` 轮数由调用方传（本档 20 轮）⇒ 置换核心与档位无关，本行与兄弟档共用同一份 `gen_mozi_v256b.py` 生成的核（r20 给 384/512、r24 给 768/1024），`.so` 各自独立。**提速来自驱动层而不是核**：官方 `hash_sponge`/`hash_Fsponge` 的 `rate`/`hash` 是运行时参数且函数非 `static` ⇒ 逐字节 xor 吸收循环无法向量化；本件换成 `RATE`/`HASHB` 为 `#define` 编译期常量、函数 `static` 的精简外壳，同核隔离实验单这一项就快 13.56 个百分点。等价性：A1 `kat_gate` 全量 4097/4097（ours/ref/opt 三方）；A2 外壳形状与档位一一对应（纯 sponge 壳只配 512、F-sponge 壳只配 768/1024，套错 match=0）；A3 负对照核常量 +1 与壳 `RATE` +8 摘要都必须变（都变了）、同壳同核复建仍 4097/4097。构建：`_overnight/l0/mozi_sib/build_shell_ab.py`。

### MOZI-768
参数化精简 sponge 外壳（`RATE`/`HASHB` 编译期常量、`static` 内联）+ 引擎生成的置换核（`_overnight/l0/mozi_sib/build_shell_ab.py`）`_std/out/so/libh20c_ours.so` ★与在册 h20(MOZI-384) 同源不同壳/不同核：官方四档 `Reference_Implementation/MOZI-{384,512,768,1024}/CryptHash_AlgorithmInstance.c` 互不相同（7778/7778/8141/8143 B），但 `diff` 显示差异只有注释、rate/hash 两个数字（本档 rate = 152 B、hash = 96 B）与 sponge 变体（384/512 纯 sponge，768/1024 F-sponge：末块 `state[rate] ^= 0x80`、每块 `memcpy(forward+rate, state+rate, 256-rate)` 后逐字节 feedforward、从 `state[256-hash+i]` 挤出）；`rhoY[4][4]` 与 `RCON[24]` 四档完全相同，`permutation(state, roundNum)` 轮数由调用方传（本档 24 轮）⇒ 置换核心与档位无关，本行与兄弟档共用同一份 `gen_mozi_v256b.py` 生成的核（r20 给 384/512、r24 给 768/1024），`.so` 各自独立。**提速来自驱动层而不是核**：官方 `hash_sponge`/`hash_Fsponge` 的 `rate`/`hash` 是运行时参数且函数非 `static` ⇒ 逐字节 xor 吸收循环无法向量化；本件换成 `RATE`/`HASHB` 为 `#define` 编译期常量、函数 `static` 的精简外壳，同核隔离实验单这一项就快 13.56 个百分点。等价性：A1 `kat_gate` 全量 4097/4097（ours/ref/opt 三方）；A2 外壳形状与档位一一对应（纯 sponge 壳只配 512、F-sponge 壳只配 768/1024，套错 match=0）；A3 负对照核常量 +1 与壳 `RATE` +8 摘要都必须变（都变了）、同壳同核复建仍 4097/4097。构建：`_overnight/l0/mozi_sib/build_shell_ab.py`。
