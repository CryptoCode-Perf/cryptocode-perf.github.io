# Mozi — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## MOZI-1024
- 摘要位：1024；实现形态：SSE C++（对手 fast 驱动）
- 官方参考源码：随包 `Reference_Implementation/MOZI-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MOZI-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MOZI-1024/`
- 优化要点：参数化精简 sponge 外壳（`RATE`/`HASHB` 编译期常量、`static` 内联）+ 引擎生成的置换核（`_overnight/l0/mozi_sib/build_shell_ab.py`）`_std/out/so/libh20d_ours.so` ★与在册 h20(MOZI-384) 同源不同壳/不同核：官方四档 `Reference_Implementation/MOZI-{384,512,768,1024}/CryptHash_AlgorithmInstance.c` 互不相同（7778/7778/8141/8143 B），但 `diff` 显示差异只有注释、rate/hash 两个数字（本档 rate = 120 B、hash = 128 B）与 sponge 变体（384/512 纯 sponge，768/1024 F-sponge：末块 `state[rate]

## MOZI-384
- 摘要位：384；实现形态：SSE 汇编
- 官方参考源码：随包 `Reference_Implementation/MOZI-384/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MOZI-384/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MOZI-384/`
- 优化要点：_cpb_tc/mozi_v256b.s + alg/h20/ref_agent.c

## MOZI-512
- 摘要位：512；实现形态：SSE C++（对手 fast 驱动）
- 官方参考源码：随包 `Reference_Implementation/MOZI-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MOZI-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MOZI-512/`
- 优化要点：参数化精简 sponge 外壳（`RATE`/`HASHB` 编译期常量、`static` 内联）+ 引擎生成的置换核（`_overnight/l0/mozi_sib/build_shell_ab.py`）`_std/out/so/libh20b_ours.so` ★与在册 h20(MOZI-384) 同源不同壳/不同核：官方四档 `Reference_Implementation/MOZI-{384,512,768,1024}/CryptHash_AlgorithmInstance.c` 互不相同（7778/7778/8141/8143 B），但 `diff` 显示差异只有注释、rate/hash 两个数字（本档 rate = 128 B、hash = 64 B）与 sponge 变体（384/512 纯 sponge，768/1024 F-sponge：末块 `state[rate] 

## MOZI-768
- 摘要位：768；实现形态：SSE C++（对手 fast 驱动）
- 官方参考源码：随包 `Reference_Implementation/MOZI-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MOZI-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MOZI-768/`
- 优化要点：参数化精简 sponge 外壳（`RATE`/`HASHB` 编译期常量、`static` 内联）+ 引擎生成的置换核（`_overnight/l0/mozi_sib/build_shell_ab.py`）`_std/out/so/libh20c_ours.so` ★与在册 h20(MOZI-384) 同源不同壳/不同核：官方四档 `Reference_Implementation/MOZI-{384,512,768,1024}/CryptHash_AlgorithmInstance.c` 互不相同（7778/7778/8141/8143 B），但 `diff` 显示差异只有注释、rate/hash 两个数字（本档 rate = 152 B、hash = 96 B）与 sponge 变体（384/512 纯 sponge，768/1024 F-sponge：末块 `state[rate] 
