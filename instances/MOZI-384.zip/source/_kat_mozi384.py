#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validate the u256 Mozi-384 optimized .so against the OFFICIAL NGCC KAT.

KAT_2_12_MOZI-384.txt : 4097 vectors, Msg_Len = 0..4096 bits (all lengths).
The .so must export the unchanged official ABI:
    int CryptHash(int digest_len_bits, const unsigned char *msg,
                  unsigned long long msg_len_bits, unsigned char *digest);
"""
import ctypes
import os
import sys

WORK = "/mnt/c/Users/von/WorkBuddy/2026-10-30-16-05-28/feilian/work"
SO = os.path.join(WORK, "_std/out/so/libh20_v256b.so")
KAT = os.path.join(
    WORK,
    "_overnight/l0/src/hash-20/Mozi/Test_Vectors/Test_Vector/KAT_2_12_MOZI-384.txt",
)

lib = ctypes.CDLL(SO)
lib.CryptHash.argtypes = [
    ctypes.c_int,
    ctypes.c_void_p,
    ctypes.c_ulonglong,
    ctypes.c_void_p,
]
lib.CryptHash.restype = ctypes.c_int


def parse(path):
    out, cur = [], None
    for raw in open(path, encoding="utf-8"):
        line = raw.strip()
        if line.startswith("Msg_Len"):
            cur = {"len": int(line.split("=", 1)[1])}
        elif line.startswith("Msg ="):
            h = line.split("=", 1)[1].strip()
            cur["msg"] = bytes.fromhex(h) if h else b""
        elif line.startswith("Dst_Len"):
            cur["dst_len"] = int(line.split("=", 1)[1])
        elif line.startswith("Dst ="):
            cur["dst"] = bytes.fromhex(line.split("=", 1)[1].strip())
            out.append(cur)
    return out


def main():
    es = parse(KAT)
    bad = []
    for e in es:
        L = e["len"]
        msg = e["msg"] or b"\x00"
        mb = (ctypes.c_ubyte * len(msg)).from_buffer_copy(msg)
        ob = (ctypes.c_ubyte * 64)()
        rc = lib.CryptHash(e["dst_len"], mb, L, ob)
        got = bytes(ob[: e["dst_len"] // 8])
        if rc != 0 or got != e["dst"]:
            bad.append((L, rc, got.hex()[:24], e["dst"].hex()[:24]))
    print("KAT file      : KAT_2_12_MOZI-384.txt (official, 0..4096 bits)")
    print("KAT entries   : %d" % len(es))
    print("digest length : 384 bits / 48 bytes")
    print("mismatches    : %d" % len(bad))
    for b in bad[:10]:
        print("  MISMATCH Msg_Len=%d rc=%d got=%s want=%s" % b)
    if bad:
        print("RESULT: FAIL")
        sys.exit(1)
    print("RESULT: ALL PASS  %d/%d" % (len(es), len(es)))


if __name__ == "__main__":
    main()
