/* mozi_ref_agent.c — Mozi sponge 外壳：复用参考 C 的 padding/absorb/squeeze 逻辑，
 * 只把置换调用指向 Agent 生成的 mozi_perm（与 gen_mozi.py 的 JIR 对应）。 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define ULL unsigned long long

void mozi_perm(uint64_t *p);

int hash_sponge(int hash, int rate, const unsigned char *input,
                ULL input_len_bits, int output_len_bits,
                unsigned char *output) {
    if (rate != 160 || hash != 48) {
        printf("Invalid rate or hash length\n");
        return 1;
    }
    unsigned char state[256];
    unsigned char IV[256];
    memset(IV, 0, sizeof(IV));
    memcpy(state, IV, sizeof(IV));
    ULL padded_input_len_bits = ((input_len_bits + rate * 8) / (rate * 8)) * rate * 8;
    ULL padded_input_len = padded_input_len_bits / 8;
    unsigned char *padded_input = (unsigned char *)malloc(padded_input_len);
    memset(padded_input, 0, padded_input_len);
    ULL full_bytes = input_len_bits / 8;
    int remaining_bits = input_len_bits % 8;
    memcpy(padded_input, input, full_bytes);
    if (remaining_bits > 0) {
        unsigned char mask = 0xFF << (8 - remaining_bits);
        padded_input[full_bytes] = input[full_bytes] & mask;
        padded_input[full_bytes] |= 0x80 >> remaining_bits;
    } else {
        padded_input[full_bytes] = 0x80;
    }

    ULL blocks = padded_input_len / rate;
    for (ULL i = 0; i < blocks; i++) {
        for (int j = 0; j < rate; j++) {
            state[j] ^= padded_input[i * rate + j];
        }
        mozi_perm((uint64_t *)state);
    }
    for (int i = 0; i < hash; i++) {
        output[i] = state[i];
    }
    free(padded_input);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest) {
    return hash_sponge(digest_len_bits / 8, 160, msg, msg_len_bits,
                       digest_len_bits, digest);
}
