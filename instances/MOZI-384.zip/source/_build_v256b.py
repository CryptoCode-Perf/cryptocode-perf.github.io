import os, sys, subprocess
WORK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, WORK); sys.path.insert(0, os.path.join(WORK, "_std"))
import run_std as RS
OUT = os.path.join(WORK, "_std", "out", "so")
def build(name, srcs, incs):
    so = os.path.join(OUT, "lib%s.so" % name)
    cmd = ["gcc"] + RS.FLAGS["opt"] + ["-shared", "-fPIC", "-o", so]
    for i in incs: cmd += ["-I", i]
    cmd += srcs + ["-lm"]
    p = subprocess.run(cmd, capture_output=True, text=True, errors="ignore")
    if p.returncode != 0: return None, (p.stdout+p.stderr)[-400:]
    nm = subprocess.run(["nm","-D",so], capture_output=True, text=True)
    if " T CryptHash" not in nm.stdout: return None, "未导出 CryptHash"
    return so, ""
so, err = build("h20_v256b", ["alg/h20/ref_agent.c","_cpb_tc/mozi_v256b.s"], RS.expand(["<h20ref>"],"h20"))
print("h20_v256b:", "OK "+so if so else "FAIL "+err)
