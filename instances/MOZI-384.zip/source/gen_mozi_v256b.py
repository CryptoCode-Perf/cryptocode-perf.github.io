#!/usr/bin/env python3
"""gen_mozi_v256b.py — Mozi 置换的 u256 JIR，第二版布局。

第一版（gen_mozi_v256.py）的教训：把 (w0,w1) 装进同一 128 位半、把列放进 lane，
S-box 便宜（整寄存器），但 MDS 的 6 个组间 xor 每个都要 3 条 perm2i128 去凑半字、
MUL 还要每寄存器一条 blend —— 20 轮下来 3596 条 IR，实测比标量 C 慢 1.39 倍。

本版布局：**组（列 j）落在 128 位半，寄存器下标留给 i（位平面）**
    A[i] = ymm{ 低 128 = (i, j=0), 高 128 = (i, j=2) }
    B[i] = ymm{ 低 128 = (i, j=1), 高 128 = (i, j=3) }
于是 MDS 的每个组间运算都变成整寄存器运算：
  * "C ^= D"(j2^=j3) 与 "A ^= B"(j0^=j1) 合起来 = A ^= B，一条指令干两件事
  * "B ^= C"(j1^=j2) 与 "D ^= A"(j3^=j0) 合起来 = B ^= swap128(A)，perm2i128 + xor
  * MUL(B)/MUL(D) 合起来 = mul(B)；MUL(A)/MUL(C) 合起来 = mul(A)
  * MUL 本身只是 i 方向的换名 + 一条 xor，不产生额外指令
  * S-box 对 j0/j2 形状相同 ⇒ 一条整寄存器指令同时算这两列
载入/写出：内存序 (i*4+j)*16，两块 32 字节读入后各拆两半（共 8 读 8 写 16 条 perm2i128）。
"""
import argparse

RHO = [[0, 14, 20, 22], [0, 13, 68, 91], [0, 27, 42, 106], [0, 32, 48, 80]]
RCON = [0x24, 0x3f, 0x6a, 0x88, 0x85, 0xa3, 0x08, 0xd3, 0x13, 0x19, 0x8a, 0x2e,
        0x03, 0x70, 0x73, 0x44, 0xa4, 0x09, 0x38, 0x22, 0x29, 0x9f, 0x31, 0xd0]


class G:
    def __init__(self):
        self.L = []
        self.n = 0

    def nm(self, pfx="v"):
        self.n += 1
        return "%s%d" % (pfx, self.n)

    def op(self, dst, expr):
        self.L.append("    %s = %s" % (dst, expr))
        return dst


def sbox(regs, g):
    a0, a1, a2, a3 = regs
    t3 = g.nm(); g.op(t3, "xor(and(%s, %s), %s)" % (a3, a2, a1))
    t1 = g.nm(); g.op(t1, "xor(or(%s, %s), %s)" % (a2, a1, a0))
    b0 = g.nm(); g.op(b0, "xor(and(%s, %s), %s)" % (t3, a0, a3))
    b2 = g.nm(); g.op(b2, "xor(and(%s, %s), %s)" % (t1, a3, a2))
    return [b0, t1, b2, t3]


def mul(regs, g):
    """MUL(x0..x3)：new3=old2, new2=old1, new1=old0^old3, new0=old3。
    换名是编译期免费的，只发一条 xor。"""
    x0, x1, x2, x3 = regs
    t = g.nm()
    g.op(t, "xor(%s, %s)" % (x0, x3))
    return [x3, t, x1, x2]


def rot128(V, a0, a1, g):
    """两个 128 位半各自循环右移 a0 / a1（a 取 0..127）。"""
    A = [a0 % 128, a1 % 128]
    if A[0] == 0 and A[1] == 0:
        return V
    S = g.nm(); g.op(S, "permq(%s, 0xB1)" % V)      # 交换 128 位内的 w0/w1
    m_use_s = 0      # 该半的第一个源取 S
    m_use_v = 0      # 该半的第二个源取 V
    k1 = [0, 0]
    k2 = [0, 0]
    zeros = 0
    for h, a in enumerate(A):
        bits = 0xF << (4 * h)                        # 一个 128 位半 = 4 个 32 位 lane
        if a == 0:
            k1[h] = 0; k2[h] = 0; zeros |= bits
        elif a < 64:
            k1[h] = a; k2[h] = 64 - a
        elif a == 64:
            k1[h] = 0; k2[h] = 0; m_use_s |= bits
        else:
            k1[h] = a - 64; k2[h] = 128 - a
            m_use_s |= bits; m_use_v |= bits
    M = V if m_use_s == 0 else g.op(g.nm(), "blendd(%s, %s, 0x%02x)" % (V, S, m_use_s))
    N = S if m_use_v == 0 else g.op(g.nm(), "blendd(%s, %s, 0x%02x)" % (S, V, m_use_v))
    r = g.nm(); g.op(r, "vshr(%s, %d, %d, %d, %d)" % (M, k1[0], k1[0], k1[1], k1[1]))
    s = g.nm(); g.op(s, "vshl(%s, %d, %d, %d, %d)" % (N, k2[0], k2[0], k2[1], k2[1]))
    o = g.nm(); g.op(o, "or(%s, %s)" % (r, s))
    if zeros:
        o = g.op(g.nm(), "blendd(%s, %s, 0x%02x)" % (o, V, zeros))
    return o


def gen(rounds=20):
    g = G()
    g.L.append("entry mozi_perm(p: u64)")
    A, B = [], []
    for i in range(4):
        q0 = g.nm("q"); g.L.append("    %s:u256 = ld(p + %d)" % (q0, i * 64))
        q1 = g.nm("q"); g.L.append("    %s:u256 = ld(p + %d)" % (q1, i * 64 + 32))
        A.append(g.op(g.nm("a"), "perm2i128(%s, %s, 0x20)" % (q0, q1)))
        B.append(g.op(g.nm("b"), "perm2i128(%s, %s, 0x31)" % (q0, q1)))
    g.L.append("")

    for r in range(rounds):
        rho = RHO[r % 4]
        A = sbox(A, g)
        B = sbox(B, g)
        for i in range(4):                                    # C^=D 且 A^=B
            A[i] = g.op(g.nm(), "xor(%s, %s)" % (A[i], B[i]))
        B = mul(B, g)                                          # MUL(B) 且 MUL(D)
        for i in range(4):                                    # B^=C 且 D^=A
            s = g.op(g.nm(), "perm2i128(%s, %s, 0x01)" % (A[i], A[i]))
            B[i] = g.op(g.nm(), "xor(%s, %s)" % (B[i], s))
        A = mul(A, g); A = mul(A, g)                           # MUL(A)×2 且 MUL(C)×2
        for i in range(4):                                    # C^=D 且 A^=B
            A[i] = g.op(g.nm(), "xor(%s, %s)" % (A[i], B[i]))
        for i in range(4):                                    # B^=C 且 D^=A
            s = g.op(g.nm(), "perm2i128(%s, %s, 0x01)" % (A[i], A[i]))
            B[i] = g.op(g.nm(), "xor(%s, %s)" % (B[i], s))
        for i in range(4):
            A[i] = rot128(A[i], rho[0], rho[2], g)             # j0 / j2
            B[i] = rot128(B[i], rho[1], rho[3], g)             # j1 / j3
        # AddConstant：(i=3, j=3, w=0) = B[3] 高 128 半的 w0 = ymm lane 2
        B[3] = g.op(g.nm(), "xor(%s, 0x%064x)" % (B[3], RCON[r] << 128))

    for i in range(4):
        p0 = g.op(g.nm(), "perm2i128(%s, %s, 0x20)" % (A[i], B[i]))
        g.L.append("    st(p + %d, %s)" % (i * 64, p0))
        p1 = g.op(g.nm(), "perm2i128(%s, %s, 0x31)" % (A[i], B[i]))
        g.L.append("    st(p + %d, %s)" % (i * 64 + 32, p1))
    g.L.append("end")
    return "\n".join(g.L) + "\n"


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--rounds", type=int, default=20)
    a = ap.parse_args()
    open(a.out, "w", encoding="utf-8", newline="\n").write(gen(a.rounds))
    print("写出", a.out)
