	.att_syntax
	.text
	.p2align	5
	.global	mozi_perm
	.type	mozi_perm, %function
mozi_perm:
	vmovdqu	(%rdi), %ymm0
	vmovdqu	32(%rdi), %ymm2
	vperm2i128	$32, %ymm2, %ymm0, %ymm3
	vperm2i128	$49, %ymm2, %ymm0, %ymm2
	vmovdqu	64(%rdi), %ymm0
	vmovdqu	96(%rdi), %ymm4
	vperm2i128	$32, %ymm4, %ymm0, %ymm1
	vperm2i128	$49, %ymm4, %ymm0, %ymm4
	vmovdqu	128(%rdi), %ymm6
	vmovdqu	160(%rdi), %ymm0
	vperm2i128	$32, %ymm0, %ymm6, %ymm5
	vperm2i128	$49, %ymm0, %ymm6, %ymm6
	vmovdqu	192(%rdi), %ymm0
	vmovdqu	224(%rdi), %ymm8
	vperm2i128	$32, %ymm8, %ymm0, %ymm7
	vperm2i128	$49, %ymm8, %ymm0, %ymm8
	vmovdqu	%ymm7, %ymm0
	vpand	%ymm5, %ymm0, %ymm0
	vpxor	%ymm1, %ymm0, %ymm0
	vpor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm3, %ymm1, %ymm1
	vpand	%ymm0, %ymm3, %ymm3
	vpxor	%ymm7, %ymm3, %ymm3
	vpand	%ymm1, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vmovdqu	%ymm8, %ymm7
	vpand	%ymm6, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm2, %ymm4, %ymm4
	vpand	%ymm7, %ymm2, %ymm2
	vpxor	%ymm8, %ymm2, %ymm9
	vpand	%ymm4, %ymm8, %ymm2
	vpxor	%ymm2, %ymm6, %ymm2
	vpxor	%ymm9, %ymm3, %ymm3
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm9, %ymm6
	vperm2i128	$1, %ymm3, %ymm3, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm5, %ymm5, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm2, %ymm2
	vpxor	%ymm0, %ymm3, %ymm8
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm7, %ymm5, %ymm3
	vpxor	%ymm6, %ymm0, %ymm5
	vpxor	%ymm4, %ymm8, %ymm0
	vpxor	%ymm2, %ymm1, %ymm1
	vperm2i128	$1, %ymm3, %ymm3, %ymm10
	vpxor	%ymm10, %ymm7, %ymm7
	vperm2i128	$1, %ymm5, %ymm5, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm4, %ymm8
	vperm2i128	$1, %ymm1, %ymm1, %ymm4
	vpxor	%ymm4, %ymm2, %ymm9
	vpermq	$177, %ymm3, %ymm2
	vpsrlvq	glob_data + 416(%rip), %ymm3, %ymm4
	vpsllvq	glob_data + 128(%rip), %ymm2, %ymm10
	vpor	%ymm10, %ymm4, %ymm2
	vpblendd	$15, %ymm3, %ymm2, %ymm2
	vpermq	$177, %ymm7, %ymm3
	vpsrlvq	glob_data + 352(%rip), %ymm7, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm3
	vpermq	$177, %ymm5, %ymm4
	vpsrlvq	glob_data + 416(%rip), %ymm5, %ymm7
	vpsllvq	glob_data + 128(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm7, %ymm7
	vpblendd	$15, %ymm5, %ymm7, %ymm7
	vpermq	$177, %ymm6, %ymm5
	vpsrlvq	glob_data + 352(%rip), %ymm6, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm4, %ymm4
	vpermq	$177, %ymm0, %ymm5
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpblendd	$15, %ymm0, %ymm5, %ymm6
	vpermq	$177, %ymm8, %ymm5
	vpsrlvq	glob_data + 352(%rip), %ymm8, %ymm0
	vpsllvq	glob_data + 160(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm0, %ymm5
	vpermq	$177, %ymm1, %ymm0
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 128(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm8, %ymm0
	vpblendd	$15, %ymm1, %ymm0, %ymm8
	vpermq	$177, %ymm9, %ymm0
	vpsrlvq	glob_data + 352(%rip), %ymm9, %ymm1
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm1, %ymm0
	vpxor	glob_data + 1120(%rip), %ymm0, %ymm1
	vmovdqu	%ymm8, %ymm0
	vpand	%ymm6, %ymm0, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpor	%ymm6, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpand	%ymm0, %ymm2, %ymm2
	vpxor	%ymm8, %ymm2, %ymm2
	vpand	%ymm7, %ymm8, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vmovdqu	%ymm1, %ymm8
	vpand	%ymm5, %ymm8, %ymm8
	vpxor	%ymm4, %ymm8, %ymm8
	vpor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpand	%ymm8, %ymm3, %ymm3
	vpxor	%ymm1, %ymm3, %ymm3
	vpand	%ymm4, %ymm1, %ymm1
	vpxor	%ymm1, %ymm5, %ymm1
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm1, %ymm6, %ymm6
	vpxor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm8, %ymm3, %ymm3
	vperm2i128	$1, %ymm2, %ymm2, %ymm5
	vpxor	%ymm5, %ymm8, %ymm8
	vperm2i128	$1, %ymm7, %ymm7, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vperm2i128	$1, %ymm6, %ymm6, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm5
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm8, %ymm6, %ymm6
	vpxor	%ymm3, %ymm0, %ymm5
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm1, %ymm7, %ymm0
	vperm2i128	$1, %ymm6, %ymm6, %ymm7
	vpxor	%ymm7, %ymm8, %ymm8
	vperm2i128	$1, %ymm5, %ymm5, %ymm7
	vpxor	%ymm7, %ymm3, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm3
	vpxor	%ymm3, %ymm4, %ymm9
	vperm2i128	$1, %ymm0, %ymm0, %ymm3
	vpxor	%ymm3, %ymm1, %ymm10
	vpermq	$177, %ymm6, %ymm3
	vpblendd	$240, %ymm3, %ymm6, %ymm1
	vpblendd	$240, %ymm6, %ymm3, %ymm3
	vpsrlvq	glob_data + 0(%rip), %ymm1, %ymm1
	vpsllvq	glob_data + 32(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm1, %ymm1
	vpblendd	$15, %ymm6, %ymm1, %ymm1
	vpermq	$177, %ymm8, %ymm3
	vpblendd	$240, %ymm3, %ymm8, %ymm6
	vpblendd	$240, %ymm8, %ymm3, %ymm3
	vpsrlvq	glob_data + 288(%rip), %ymm6, %ymm4
	vpsllvq	glob_data + 256(%rip), %ymm3, %ymm6
	vpor	%ymm6, %ymm4, %ymm3
	vpermq	$177, %ymm5, %ymm4
	vpblendd	$240, %ymm4, %ymm5, %ymm6
	vpblendd	$240, %ymm5, %ymm4, %ymm8
	vpsrlvq	glob_data + 0(%rip), %ymm6, %ymm6
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm4
	vpor	%ymm4, %ymm6, %ymm6
	vpblendd	$15, %ymm5, %ymm6, %ymm6
	vpermq	$177, %ymm7, %ymm4
	vpblendd	$240, %ymm4, %ymm7, %ymm8
	vpblendd	$240, %ymm7, %ymm4, %ymm5
	vpsrlvq	glob_data + 288(%rip), %ymm8, %ymm4
	vpsllvq	glob_data + 256(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm4, %ymm4
	vpermq	$177, %ymm2, %ymm5
	vpblendd	$240, %ymm5, %ymm2, %ymm7
	vpblendd	$240, %ymm2, %ymm5, %ymm5
	vpsrlvq	glob_data + 0(%rip), %ymm7, %ymm8
	vpsllvq	glob_data + 32(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm8, %ymm8
	vpblendd	$15, %ymm2, %ymm8, %ymm2
	vpermq	$177, %ymm9, %ymm5
	vpblendd	$240, %ymm5, %ymm9, %ymm7
	vpblendd	$240, %ymm9, %ymm5, %ymm5
	vpsrlvq	glob_data + 288(%rip), %ymm7, %ymm7
	vpsllvq	glob_data + 256(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpermq	$177, %ymm0, %ymm8
	vpblendd	$240, %ymm8, %ymm0, %ymm9
	vpblendd	$240, %ymm0, %ymm8, %ymm7
	vpsrlvq	glob_data + 0(%rip), %ymm9, %ymm8
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpblendd	$15, %ymm0, %ymm7, %ymm8
	vpermq	$177, %ymm10, %ymm9
	vpblendd	$240, %ymm9, %ymm10, %ymm0
	vpblendd	$240, %ymm10, %ymm9, %ymm7
	vpsrlvq	glob_data + 288(%rip), %ymm0, %ymm0
	vpsllvq	glob_data + 256(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm0, %ymm0
	vpxor	glob_data + 1088(%rip), %ymm0, %ymm7
	vmovdqu	%ymm8, %ymm0
	vpand	%ymm2, %ymm0, %ymm0
	vpxor	%ymm6, %ymm0, %ymm0
	vpor	%ymm2, %ymm6, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpand	%ymm0, %ymm1, %ymm1
	vpxor	%ymm8, %ymm1, %ymm1
	vpand	%ymm6, %ymm8, %ymm8
	vpxor	%ymm8, %ymm2, %ymm2
	vmovdqu	%ymm7, %ymm10
	vpand	%ymm5, %ymm10, %ymm10
	vpxor	%ymm4, %ymm10, %ymm10
	vpor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpand	%ymm10, %ymm3, %ymm3
	vpxor	%ymm7, %ymm3, %ymm3
	vpand	%ymm4, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm4, %ymm6, %ymm6
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm10, %ymm0, %ymm0
	vpxor	%ymm10, %ymm3, %ymm7
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm10, %ymm3
	vperm2i128	$1, %ymm6, %ymm6, %ymm9
	vpxor	%ymm9, %ymm7, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm8
	vpxor	%ymm8, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm5, %ymm5
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm7, %ymm0, %ymm8
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm5, %ymm6, %ymm0
	vperm2i128	$1, %ymm2, %ymm2, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vperm2i128	$1, %ymm8, %ymm8, %ymm9
	vpxor	%ymm9, %ymm7, %ymm7
	vperm2i128	$1, %ymm1, %ymm1, %ymm6
	vpxor	%ymm6, %ymm4, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$177, %ymm2, %ymm4
	vpsrlvq	glob_data + 224(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 384(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm9, %ymm4
	vpblendd	$15, %ymm2, %ymm4, %ymm2
	vpermq	$177, %ymm3, %ymm4
	vpblendd	$240, %ymm4, %ymm3, %ymm9
	vpblendd	$240, %ymm3, %ymm4, %ymm3
	vpsrlvq	glob_data + 192(%rip), %ymm9, %ymm4
	vpsllvq	glob_data + 320(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm3
	vpermq	$177, %ymm8, %ymm4
	vpsrlvq	glob_data + 224(%rip), %ymm8, %ymm10
	vpsllvq	glob_data + 384(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm10, %ymm4
	vpblendd	$15, %ymm8, %ymm4, %ymm9
	vpermq	$177, %ymm7, %ymm4
	vpblendd	$240, %ymm4, %ymm7, %ymm8
	vpblendd	$240, %ymm7, %ymm4, %ymm4
	vpsrlvq	glob_data + 192(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 320(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm8, %ymm4
	vpermq	$177, %ymm1, %ymm7
	vpsrlvq	glob_data + 224(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 384(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpblendd	$15, %ymm1, %ymm7, %ymm1
	vpermq	$177, %ymm6, %ymm7
	vpblendd	$240, %ymm7, %ymm6, %ymm8
	vpblendd	$240, %ymm6, %ymm7, %ymm7
	vpsrlvq	glob_data + 192(%rip), %ymm8, %ymm6
	vpsllvq	glob_data + 320(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpermq	$177, %ymm0, %ymm7
	vpsrlvq	glob_data + 224(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 384(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpblendd	$15, %ymm0, %ymm7, %ymm7
	vpermq	$177, %ymm5, %ymm0
	vpblendd	$240, %ymm0, %ymm5, %ymm8
	vpblendd	$240, %ymm5, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm8, %ymm5
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm0
	vpxor	glob_data + 1056(%rip), %ymm0, %ymm5
	vmovdqu	%ymm7, %ymm0
	vpand	%ymm1, %ymm0, %ymm0
	vpxor	%ymm9, %ymm0, %ymm0
	vpor	%ymm1, %ymm9, %ymm9
	vpxor	%ymm2, %ymm9, %ymm9
	vpand	%ymm0, %ymm2, %ymm2
	vpxor	%ymm7, %ymm2, %ymm2
	vpand	%ymm9, %ymm7, %ymm7
	vpxor	%ymm7, %ymm1, %ymm1
	vmovdqu	%ymm5, %ymm7
	vpand	%ymm6, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpand	%ymm7, %ymm3, %ymm3
	vpxor	%ymm5, %ymm3, %ymm8
	vpand	%ymm4, %ymm5, %ymm5
	vpxor	%ymm5, %ymm6, %ymm3
	vpxor	%ymm8, %ymm2, %ymm2
	vpxor	%ymm4, %ymm9, %ymm9
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm8, %ymm6
	vperm2i128	$1, %ymm2, %ymm2, %ymm5
	vpxor	%ymm5, %ymm7, %ymm5
	vperm2i128	$1, %ymm9, %ymm9, %ymm7
	vpxor	%ymm7, %ymm6, %ymm8
	vperm2i128	$1, %ymm1, %ymm1, %ymm6
	vpxor	%ymm6, %ymm4, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm1, %ymm0, %ymm4
	vpxor	%ymm5, %ymm1, %ymm0
	vpxor	%ymm8, %ymm4, %ymm1
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm3, %ymm9, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vperm2i128	$1, %ymm1, %ymm1, %ymm7
	vpxor	%ymm7, %ymm8, %ymm8
	vperm2i128	$1, %ymm2, %ymm2, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vperm2i128	$1, %ymm4, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm7
	vpermq	$177, %ymm0, %ymm3
	vpsrlvq	glob_data + 96(%rip), %ymm0, %ymm9
	vpsllvq	glob_data + 480(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm9, %ymm9
	vpblendd	$15, %ymm0, %ymm9, %ymm0
	vpermq	$177, %ymm5, %ymm3
	vpblendd	$240, %ymm3, %ymm5, %ymm9
	vpblendd	$240, %ymm5, %ymm3, %ymm3
	vpsrlvq	glob_data + 448(%rip), %ymm9, %ymm5
	vpsllvq	glob_data + 64(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$177, %ymm1, %ymm5
	vpsrlvq	glob_data + 96(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 480(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm9, %ymm5
	vpblendd	$15, %ymm1, %ymm5, %ymm9
	vpermq	$177, %ymm8, %ymm5
	vpblendd	$240, %ymm5, %ymm8, %ymm1
	vpblendd	$240, %ymm8, %ymm5, %ymm5
	vpsrlvq	glob_data + 448(%rip), %ymm1, %ymm1
	vpsllvq	glob_data + 64(%rip), %ymm5, %ymm8
	vpor	%ymm8, %ymm1, %ymm1
	vpermq	$177, %ymm2, %ymm5
	vpsrlvq	glob_data + 96(%rip), %ymm2, %ymm8
	vpsllvq	glob_data + 480(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm8, %ymm5
	vpblendd	$15, %ymm2, %ymm5, %ymm2
	vpermq	$177, %ymm6, %ymm5
	vpblendd	$240, %ymm5, %ymm6, %ymm8
	vpblendd	$240, %ymm6, %ymm5, %ymm5
	vpsrlvq	glob_data + 448(%rip), %ymm8, %ymm6
	vpsllvq	glob_data + 64(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpermq	$177, %ymm4, %ymm6
	vpsrlvq	glob_data + 96(%rip), %ymm4, %ymm8
	vpsllvq	glob_data + 480(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm6
	vpblendd	$15, %ymm4, %ymm6, %ymm6
	vpermq	$177, %ymm7, %ymm8
	vpblendd	$240, %ymm8, %ymm7, %ymm4
	vpblendd	$240, %ymm7, %ymm8, %ymm8
	vpsrlvq	glob_data + 448(%rip), %ymm4, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm8, %ymm4
	vpor	%ymm4, %ymm7, %ymm7
	vpxor	glob_data + 1024(%rip), %ymm7, %ymm7
	vmovdqu	%ymm6, %ymm4
	vpand	%ymm2, %ymm4, %ymm4
	vpxor	%ymm9, %ymm4, %ymm4
	vpor	%ymm2, %ymm9, %ymm8
	vpxor	%ymm0, %ymm8, %ymm9
	vpand	%ymm4, %ymm0, %ymm0
	vpxor	%ymm6, %ymm0, %ymm0
	vpand	%ymm9, %ymm6, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vmovdqu	%ymm7, %ymm6
	vpand	%ymm5, %ymm6, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm3, %ymm1, %ymm1
	vpand	%ymm6, %ymm3, %ymm3
	vpxor	%ymm7, %ymm3, %ymm8
	vpand	%ymm1, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm3
	vpxor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm1, %ymm9, %ymm9
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm6, %ymm8, %ymm7
	vperm2i128	$1, %ymm0, %ymm0, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vperm2i128	$1, %ymm9, %ymm9, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm6
	vpxor	%ymm6, %ymm1, %ymm10
	vperm2i128	$1, %ymm4, %ymm4, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm2, %ymm4, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm7, %ymm1, %ymm4
	vpxor	%ymm10, %ymm0, %ymm0
	vpxor	%ymm3, %ymm9, %ymm1
	vperm2i128	$1, %ymm2, %ymm2, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vperm2i128	$1, %ymm4, %ymm4, %ymm6
	vpxor	%ymm6, %ymm7, %ymm7
	vperm2i128	$1, %ymm0, %ymm0, %ymm6
	vpxor	%ymm6, %ymm10, %ymm10
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm3, %ymm6
	vpermq	$177, %ymm2, %ymm3
	vpsrlvq	glob_data + 416(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 128(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm9, %ymm3
	vpblendd	$15, %ymm2, %ymm3, %ymm2
	vpermq	$177, %ymm5, %ymm3
	vpsrlvq	glob_data + 352(%rip), %ymm5, %ymm5
	vpsllvq	glob_data + 160(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$177, %ymm4, %ymm8
	vpsrlvq	glob_data + 416(%rip), %ymm4, %ymm5
	vpsllvq	glob_data + 128(%rip), %ymm8, %ymm9
	vpor	%ymm9, %ymm5, %ymm5
	vpblendd	$15, %ymm4, %ymm5, %ymm5
	vpermq	$177, %ymm7, %ymm8
	vpsrlvq	glob_data + 352(%rip), %ymm7, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm8, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpermq	$177, %ymm0, %ymm9
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 128(%rip), %ymm9, %ymm7
	vpor	%ymm7, %ymm8, %ymm8
	vpblendd	$15, %ymm0, %ymm8, %ymm0
	vpermq	$177, %ymm10, %ymm7
	vpsrlvq	glob_data + 352(%rip), %ymm10, %ymm8
	vpsllvq	glob_data + 160(%rip), %ymm7, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpermq	$177, %ymm1, %ymm7
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 128(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm9, %ymm7
	vpblendd	$15, %ymm1, %ymm7, %ymm7
	vpermq	$177, %ymm6, %ymm9
	vpsrlvq	glob_data + 352(%rip), %ymm6, %ymm1
	vpsllvq	glob_data + 160(%rip), %ymm9, %ymm6
	vpor	%ymm6, %ymm1, %ymm1
	vpxor	glob_data + 992(%rip), %ymm1, %ymm9
	vmovdqu	%ymm7, %ymm1
	vpand	%ymm0, %ymm1, %ymm1
	vpxor	%ymm5, %ymm1, %ymm1
	vpor	%ymm0, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpand	%ymm1, %ymm2, %ymm2
	vpxor	%ymm7, %ymm2, %ymm2
	vpand	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vmovdqu	%ymm9, %ymm6
	vpand	%ymm8, %ymm6, %ymm6
	vpxor	%ymm4, %ymm6, %ymm6
	vpor	%ymm8, %ymm4, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpand	%ymm6, %ymm3, %ymm3
	vpxor	%ymm9, %ymm3, %ymm7
	vpand	%ymm4, %ymm9, %ymm3
	vpxor	%ymm3, %ymm8, %ymm3
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm6, %ymm7, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm5, %ymm5, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm4, %ymm4
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm1, %ymm2, %ymm2
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm6, %ymm0, %ymm8
	vpxor	%ymm7, %ymm1, %ymm9
	vpxor	%ymm4, %ymm2, %ymm0
	vpxor	%ymm3, %ymm5, %ymm1
	vperm2i128	$1, %ymm8, %ymm8, %ymm5
	vpxor	%ymm5, %ymm6, %ymm2
	vperm2i128	$1, %ymm9, %ymm9, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vperm2i128	$1, %ymm0, %ymm0, %ymm5
	vpxor	%ymm5, %ymm4, %ymm5
	vperm2i128	$1, %ymm1, %ymm1, %ymm4
	vpxor	%ymm4, %ymm3, %ymm6
	vpermq	$177, %ymm8, %ymm3
	vpblendd	$240, %ymm3, %ymm8, %ymm4
	vpblendd	$240, %ymm8, %ymm3, %ymm3
	vpsrlvq	glob_data + 0(%rip), %ymm4, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm3
	vpblendd	$15, %ymm8, %ymm3, %ymm3
	vpermq	$177, %ymm2, %ymm8
	vpblendd	$240, %ymm8, %ymm2, %ymm4
	vpblendd	$240, %ymm2, %ymm8, %ymm10
	vpsrlvq	glob_data + 288(%rip), %ymm4, %ymm2
	vpsllvq	glob_data + 256(%rip), %ymm10, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpermq	$177, %ymm9, %ymm4
	vpblendd	$240, %ymm4, %ymm9, %ymm8
	vpblendd	$240, %ymm9, %ymm4, %ymm4
	vpsrlvq	glob_data + 0(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 32(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm8, %ymm4
	vpblendd	$15, %ymm9, %ymm4, %ymm8
	vpermq	$177, %ymm7, %ymm4
	vpblendd	$240, %ymm4, %ymm7, %ymm9
	vpblendd	$240, %ymm7, %ymm4, %ymm4
	vpsrlvq	glob_data + 288(%rip), %ymm9, %ymm7
	vpsllvq	glob_data + 256(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm7, %ymm4
	vpermq	$177, %ymm0, %ymm7
	vpblendd	$240, %ymm7, %ymm0, %ymm9
	vpblendd	$240, %ymm0, %ymm7, %ymm7
	vpsrlvq	glob_data + 0(%rip), %ymm9, %ymm9
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm9, %ymm7
	vpblendd	$15, %ymm0, %ymm7, %ymm9
	vpermq	$177, %ymm5, %ymm0
	vpblendd	$240, %ymm0, %ymm5, %ymm7
	vpblendd	$240, %ymm5, %ymm0, %ymm0
	vpsrlvq	glob_data + 288(%rip), %ymm7, %ymm5
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm5
	vpermq	$177, %ymm1, %ymm7
	vpblendd	$240, %ymm7, %ymm1, %ymm0
	vpblendd	$240, %ymm1, %ymm7, %ymm7
	vpsrlvq	glob_data + 0(%rip), %ymm0, %ymm0
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm0, %ymm0
	vpblendd	$15, %ymm1, %ymm0, %ymm7
	vpermq	$177, %ymm6, %ymm1
	vpblendd	$240, %ymm1, %ymm6, %ymm0
	vpblendd	$240, %ymm6, %ymm1, %ymm1
	vpsrlvq	glob_data + 288(%rip), %ymm0, %ymm0
	vpsllvq	glob_data + 256(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm0, %ymm0
	vpxor	glob_data + 960(%rip), %ymm0, %ymm1
	vmovdqu	%ymm7, %ymm0
	vpand	%ymm9, %ymm0, %ymm0
	vpxor	%ymm8, %ymm0, %ymm0
	vpor	%ymm9, %ymm8, %ymm8
	vpxor	%ymm3, %ymm8, %ymm8
	vpand	%ymm0, %ymm3, %ymm3
	vpxor	%ymm7, %ymm3, %ymm3
	vpand	%ymm8, %ymm7, %ymm6
	vpxor	%ymm6, %ymm9, %ymm6
	vmovdqu	%ymm1, %ymm7
	vpand	%ymm5, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm2, %ymm4, %ymm4
	vpand	%ymm7, %ymm2, %ymm2
	vpxor	%ymm1, %ymm2, %ymm2
	vpand	%ymm4, %ymm1, %ymm1
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm4, %ymm8, %ymm1
	vpxor	%ymm5, %ymm6, %ymm6
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm2, %ymm2
	vperm2i128	$1, %ymm3, %ymm3, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm2, %ymm2
	vperm2i128	$1, %ymm6, %ymm6, %ymm8
	vpxor	%ymm8, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm5, %ymm5
	vpxor	%ymm0, %ymm3, %ymm3
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm2, %ymm0, %ymm8
	vpxor	%ymm4, %ymm3, %ymm0
	vpxor	%ymm5, %ymm1, %ymm3
	vperm2i128	$1, %ymm6, %ymm6, %ymm9
	vpxor	%ymm9, %ymm7, %ymm1
	vperm2i128	$1, %ymm8, %ymm8, %ymm7
	vpxor	%ymm7, %ymm2, %ymm7
	vperm2i128	$1, %ymm0, %ymm0, %ymm2
	vpxor	%ymm2, %ymm4, %ymm10
	vperm2i128	$1, %ymm3, %ymm3, %ymm2
	vpxor	%ymm2, %ymm5, %ymm5
	vpermq	$177, %ymm6, %ymm2
	vpsrlvq	glob_data + 224(%rip), %ymm6, %ymm4
	vpsllvq	glob_data + 384(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm4, %ymm4
	vpblendd	$15, %ymm6, %ymm4, %ymm4
	vpermq	$177, %ymm1, %ymm2
	vpblendd	$240, %ymm2, %ymm1, %ymm6
	vpblendd	$240, %ymm1, %ymm2, %ymm1
	vpsrlvq	glob_data + 192(%rip), %ymm6, %ymm2
	vpsllvq	glob_data + 320(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm2, %ymm2
	vpermq	$177, %ymm8, %ymm1
	vpsrlvq	glob_data + 224(%rip), %ymm8, %ymm6
	vpsllvq	glob_data + 384(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpblendd	$15, %ymm8, %ymm1, %ymm8
	vpermq	$177, %ymm7, %ymm1
	vpblendd	$240, %ymm1, %ymm7, %ymm6
	vpblendd	$240, %ymm7, %ymm1, %ymm1
	vpsrlvq	glob_data + 192(%rip), %ymm6, %ymm6
	vpsllvq	glob_data + 320(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$177, %ymm0, %ymm6
	vpsrlvq	glob_data + 224(%rip), %ymm0, %ymm7
	vpsllvq	glob_data + 384(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm7, %ymm7
	vpblendd	$15, %ymm0, %ymm7, %ymm6
	vpermq	$177, %ymm10, %ymm0
	vpblendd	$240, %ymm0, %ymm10, %ymm7
	vpblendd	$240, %ymm10, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm7, %ymm7
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm7
	vpermq	$177, %ymm3, %ymm0
	vpsrlvq	glob_data + 224(%rip), %ymm3, %ymm10
	vpsllvq	glob_data + 384(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm10, %ymm0
	vpblendd	$15, %ymm3, %ymm0, %ymm3
	vpermq	$177, %ymm5, %ymm0
	vpblendd	$240, %ymm0, %ymm5, %ymm9
	vpblendd	$240, %ymm5, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm9, %ymm5
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm0
	vpxor	glob_data + 928(%rip), %ymm0, %ymm5
	vmovdqu	%ymm3, %ymm0
	vpand	%ymm6, %ymm0, %ymm0
	vpxor	%ymm8, %ymm0, %ymm0
	vpor	%ymm6, %ymm8, %ymm8
	vpxor	%ymm4, %ymm8, %ymm8
	vpand	%ymm0, %ymm4, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpand	%ymm8, %ymm3, %ymm3
	vpxor	%ymm3, %ymm6, %ymm6
	vmovdqu	%ymm5, %ymm3
	vpand	%ymm7, %ymm3, %ymm3
	vpxor	%ymm1, %ymm3, %ymm3
	vpor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm2, %ymm1, %ymm1
	vpand	%ymm3, %ymm2, %ymm2
	vpxor	%ymm5, %ymm2, %ymm9
	vpand	%ymm1, %ymm5, %ymm5
	vpxor	%ymm5, %ymm7, %ymm2
	vpxor	%ymm9, %ymm4, %ymm4
	vpxor	%ymm1, %ymm8, %ymm5
	vpxor	%ymm2, %ymm6, %ymm6
	vpxor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm3, %ymm9, %ymm7
	vperm2i128	$1, %ymm4, %ymm4, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vperm2i128	$1, %ymm5, %ymm5, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vperm2i128	$1, %ymm6, %ymm6, %ymm8
	vpxor	%ymm8, %ymm1, %ymm1
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm2, %ymm8
	vpxor	%ymm0, %ymm4, %ymm2
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm3, %ymm6, %ymm6
	vpxor	%ymm7, %ymm0, %ymm10
	vpxor	%ymm1, %ymm2, %ymm4
	vpxor	%ymm8, %ymm5, %ymm2
	vperm2i128	$1, %ymm6, %ymm6, %ymm0
	vpxor	%ymm0, %ymm3, %ymm3
	vperm2i128	$1, %ymm10, %ymm10, %ymm0
	vpxor	%ymm0, %ymm7, %ymm7
	vperm2i128	$1, %ymm4, %ymm4, %ymm0
	vpxor	%ymm0, %ymm1, %ymm9
	vperm2i128	$1, %ymm2, %ymm2, %ymm0
	vpxor	%ymm0, %ymm8, %ymm5
	vpermq	$177, %ymm6, %ymm0
	vpsrlvq	glob_data + 96(%rip), %ymm6, %ymm1
	vpsllvq	glob_data + 480(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm1, %ymm0
	vpblendd	$15, %ymm6, %ymm0, %ymm1
	vpermq	$177, %ymm3, %ymm0
	vpblendd	$240, %ymm0, %ymm3, %ymm6
	vpblendd	$240, %ymm3, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm6, %ymm3
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm6
	vpor	%ymm6, %ymm3, %ymm0
	vpermq	$177, %ymm10, %ymm3
	vpsrlvq	glob_data + 96(%rip), %ymm10, %ymm6
	vpsllvq	glob_data + 480(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpblendd	$15, %ymm10, %ymm3, %ymm6
	vpermq	$177, %ymm7, %ymm3
	vpblendd	$240, %ymm3, %ymm7, %ymm8
	vpblendd	$240, %ymm7, %ymm3, %ymm3
	vpsrlvq	glob_data + 448(%rip), %ymm8, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm3
	vpermq	$177, %ymm4, %ymm7
	vpsrlvq	glob_data + 96(%rip), %ymm4, %ymm8
	vpsllvq	glob_data + 480(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpblendd	$15, %ymm4, %ymm7, %ymm4
	vpermq	$177, %ymm9, %ymm7
	vpblendd	$240, %ymm7, %ymm9, %ymm10
	vpblendd	$240, %ymm9, %ymm7, %ymm7
	vpsrlvq	glob_data + 448(%rip), %ymm10, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpermq	$177, %ymm2, %ymm8
	vpsrlvq	glob_data + 96(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 480(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm9, %ymm8
	vpblendd	$15, %ymm2, %ymm8, %ymm10
	vpermq	$177, %ymm5, %ymm8
	vpblendd	$240, %ymm8, %ymm5, %ymm2
	vpblendd	$240, %ymm5, %ymm8, %ymm5
	vpsrlvq	glob_data + 448(%rip), %ymm2, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm5, %ymm2
	vpor	%ymm2, %ymm8, %ymm5
	vpxor	glob_data + 896(%rip), %ymm5, %ymm8
	vmovdqu	%ymm10, %ymm2
	vpand	%ymm4, %ymm2, %ymm2
	vpxor	%ymm6, %ymm2, %ymm2
	vpor	%ymm4, %ymm6, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpand	%ymm2, %ymm1, %ymm1
	vpxor	%ymm10, %ymm1, %ymm1
	vpand	%ymm5, %ymm10, %ymm10
	vpxor	%ymm10, %ymm4, %ymm4
	vmovdqu	%ymm8, %ymm6
	vpand	%ymm7, %ymm6, %ymm6
	vpxor	%ymm3, %ymm6, %ymm6
	vpor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm0, %ymm3, %ymm3
	vpand	%ymm6, %ymm0, %ymm0
	vpxor	%ymm8, %ymm0, %ymm9
	vpand	%ymm3, %ymm8, %ymm0
	vpxor	%ymm0, %ymm7, %ymm0
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm0, %ymm4, %ymm4
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm6, %ymm9, %ymm7
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm5, %ymm5, %ymm9
	vpxor	%ymm9, %ymm7, %ymm7
	vperm2i128	$1, %ymm4, %ymm4, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vperm2i128	$1, %ymm2, %ymm2, %ymm8
	vpxor	%ymm8, %ymm0, %ymm8
	vpxor	%ymm2, %ymm1, %ymm0
	vpxor	%ymm4, %ymm2, %ymm1
	vpxor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm2
	vpxor	%ymm3, %ymm0, %ymm1
	vpxor	%ymm8, %ymm5, %ymm0
	vperm2i128	$1, %ymm4, %ymm4, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vperm2i128	$1, %ymm2, %ymm2, %ymm6
	vpxor	%ymm6, %ymm7, %ymm7
	vperm2i128	$1, %ymm1, %ymm1, %ymm6
	vpxor	%ymm6, %ymm3, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm3
	vpxor	%ymm3, %ymm8, %ymm8
	vpermq	$177, %ymm4, %ymm9
	vpsrlvq	glob_data + 416(%rip), %ymm4, %ymm3
	vpsllvq	glob_data + 128(%rip), %ymm9, %ymm10
	vpor	%ymm10, %ymm3, %ymm3
	vpblendd	$15, %ymm4, %ymm3, %ymm3
	vpermq	$177, %ymm5, %ymm4
	vpsrlvq	glob_data + 352(%rip), %ymm5, %ymm5
	vpsllvq	glob_data + 160(%rip), %ymm4, %ymm9
	vpor	%ymm9, %ymm5, %ymm4
	vpermq	$177, %ymm2, %ymm5
	vpsrlvq	glob_data + 416(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 128(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm9, %ymm9
	vpblendd	$15, %ymm2, %ymm9, %ymm5
	vpermq	$177, %ymm7, %ymm9
	vpsrlvq	glob_data + 352(%rip), %ymm7, %ymm2
	vpsllvq	glob_data + 160(%rip), %ymm9, %ymm7
	vpor	%ymm7, %ymm2, %ymm2
	vpermq	$177, %ymm1, %ymm7
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 128(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm9, %ymm7
	vpblendd	$15, %ymm1, %ymm7, %ymm7
	vpermq	$177, %ymm6, %ymm9
	vpsrlvq	glob_data + 352(%rip), %ymm6, %ymm1
	vpsllvq	glob_data + 160(%rip), %ymm9, %ymm6
	vpor	%ymm6, %ymm1, %ymm10
	vpermq	$177, %ymm0, %ymm1
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpblendd	$15, %ymm0, %ymm1, %ymm0
	vpermq	$177, %ymm8, %ymm6
	vpsrlvq	glob_data + 352(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 160(%rip), %ymm6, %ymm1
	vpor	%ymm1, %ymm8, %ymm6
	vpxor	glob_data + 864(%rip), %ymm6, %ymm8
	vmovdqu	%ymm0, %ymm1
	vpand	%ymm7, %ymm1, %ymm1
	vpxor	%ymm5, %ymm1, %ymm1
	vpor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpand	%ymm1, %ymm3, %ymm3
	vpxor	%ymm0, %ymm3, %ymm3
	vpand	%ymm5, %ymm0, %ymm0
	vpxor	%ymm0, %ymm7, %ymm0
	vmovdqu	%ymm8, %ymm6
	vpand	%ymm10, %ymm6, %ymm6
	vpxor	%ymm2, %ymm6, %ymm6
	vpor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm4, %ymm2, %ymm2
	vpand	%ymm6, %ymm4, %ymm4
	vpxor	%ymm8, %ymm4, %ymm7
	vpand	%ymm2, %ymm8, %ymm4
	vpxor	%ymm4, %ymm10, %ymm4
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm6, %ymm7, %ymm7
	vperm2i128	$1, %ymm3, %ymm3, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm5, %ymm5, %ymm8
	vpxor	%ymm8, %ymm7, %ymm9
	vperm2i128	$1, %ymm0, %ymm0, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vperm2i128	$1, %ymm1, %ymm1, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm1, %ymm3, %ymm8
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm6, %ymm0, %ymm3
	vpxor	%ymm9, %ymm1, %ymm7
	vpxor	%ymm2, %ymm8, %ymm0
	vpxor	%ymm4, %ymm5, %ymm1
	vperm2i128	$1, %ymm3, %ymm3, %ymm8
	vpxor	%ymm8, %ymm6, %ymm5
	vperm2i128	$1, %ymm7, %ymm7, %ymm6
	vpxor	%ymm6, %ymm9, %ymm9
	vperm2i128	$1, %ymm0, %ymm0, %ymm6
	vpxor	%ymm6, %ymm2, %ymm6
	vperm2i128	$1, %ymm1, %ymm1, %ymm2
	vpxor	%ymm2, %ymm4, %ymm10
	vpermq	$177, %ymm3, %ymm4
	vpblendd	$240, %ymm4, %ymm3, %ymm8
	vpblendd	$240, %ymm3, %ymm4, %ymm4
	vpsrlvq	glob_data + 0(%rip), %ymm8, %ymm2
	vpsllvq	glob_data + 32(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpblendd	$15, %ymm3, %ymm2, %ymm2
	vpermq	$177, %ymm5, %ymm3
	vpblendd	$240, %ymm3, %ymm5, %ymm4
	vpblendd	$240, %ymm5, %ymm3, %ymm3
	vpsrlvq	glob_data + 288(%rip), %ymm4, %ymm4
	vpsllvq	glob_data + 256(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm3
	vpermq	$177, %ymm7, %ymm4
	vpblendd	$240, %ymm4, %ymm7, %ymm5
	vpblendd	$240, %ymm7, %ymm4, %ymm4
	vpsrlvq	glob_data + 0(%rip), %ymm5, %ymm8
	vpsllvq	glob_data + 32(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm8, %ymm4
	vpblendd	$15, %ymm7, %ymm4, %ymm7
	vpermq	$177, %ymm9, %ymm4
	vpblendd	$240, %ymm4, %ymm9, %ymm5
	vpblendd	$240, %ymm9, %ymm4, %ymm4
	vpsrlvq	glob_data + 288(%rip), %ymm5, %ymm8
	vpsllvq	glob_data + 256(%rip), %ymm4, %ymm9
	vpor	%ymm9, %ymm8, %ymm4
	vpermq	$177, %ymm0, %ymm8
	vpblendd	$240, %ymm8, %ymm0, %ymm5
	vpblendd	$240, %ymm0, %ymm8, %ymm8
	vpsrlvq	glob_data + 0(%rip), %ymm5, %ymm5
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm5, %ymm5
	vpblendd	$15, %ymm0, %ymm5, %ymm9
	vpermq	$177, %ymm6, %ymm8
	vpblendd	$240, %ymm8, %ymm6, %ymm0
	vpblendd	$240, %ymm6, %ymm8, %ymm5
	vpsrlvq	glob_data + 288(%rip), %ymm0, %ymm0
	vpsllvq	glob_data + 256(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm0, %ymm5
	vpermq	$177, %ymm1, %ymm0
	vpblendd	$240, %ymm0, %ymm1, %ymm6
	vpblendd	$240, %ymm1, %ymm0, %ymm8
	vpsrlvq	glob_data + 0(%rip), %ymm6, %ymm0
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm6
	vpor	%ymm6, %ymm0, %ymm0
	vpblendd	$15, %ymm1, %ymm0, %ymm1
	vpermq	$177, %ymm10, %ymm0
	vpblendd	$240, %ymm0, %ymm10, %ymm6
	vpblendd	$240, %ymm10, %ymm0, %ymm8
	vpsrlvq	glob_data + 288(%rip), %ymm6, %ymm0
	vpsllvq	glob_data + 256(%rip), %ymm8, %ymm6
	vpor	%ymm6, %ymm0, %ymm0
	vpxor	glob_data + 832(%rip), %ymm0, %ymm8
	vmovdqu	%ymm1, %ymm0
	vpand	%ymm9, %ymm0, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpor	%ymm9, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpand	%ymm0, %ymm2, %ymm2
	vpxor	%ymm1, %ymm2, %ymm2
	vpand	%ymm7, %ymm1, %ymm1
	vpxor	%ymm1, %ymm9, %ymm1
	vmovdqu	%ymm8, %ymm10
	vpand	%ymm5, %ymm10, %ymm10
	vpxor	%ymm4, %ymm10, %ymm10
	vpor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpand	%ymm10, %ymm3, %ymm3
	vpxor	%ymm8, %ymm3, %ymm6
	vpand	%ymm4, %ymm8, %ymm3
	vpxor	%ymm3, %ymm5, %ymm3
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm10, %ymm0, %ymm0
	vpxor	%ymm10, %ymm6, %ymm6
	vperm2i128	$1, %ymm2, %ymm2, %ymm5
	vpxor	%ymm5, %ymm10, %ymm5
	vperm2i128	$1, %ymm7, %ymm7, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm6, %ymm0, %ymm9
	vpxor	%ymm4, %ymm2, %ymm0
	vpxor	%ymm3, %ymm7, %ymm2
	vperm2i128	$1, %ymm1, %ymm1, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vperm2i128	$1, %ymm9, %ymm9, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm7
	vpxor	%ymm7, %ymm4, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm8
	vpxor	%ymm8, %ymm3, %ymm8
	vpermq	$177, %ymm1, %ymm4
	vpsrlvq	glob_data + 224(%rip), %ymm1, %ymm3
	vpsllvq	glob_data + 384(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm3, %ymm3
	vpblendd	$15, %ymm1, %ymm3, %ymm3
	vpermq	$177, %ymm5, %ymm4
	vpblendd	$240, %ymm4, %ymm5, %ymm1
	vpblendd	$240, %ymm5, %ymm4, %ymm4
	vpsrlvq	glob_data + 192(%rip), %ymm1, %ymm1
	vpsllvq	glob_data + 320(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm1, %ymm1
	vpermq	$177, %ymm9, %ymm4
	vpsrlvq	glob_data + 224(%rip), %ymm9, %ymm5
	vpsllvq	glob_data + 384(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpblendd	$15, %ymm9, %ymm4, %ymm5
	vpermq	$177, %ymm6, %ymm4
	vpblendd	$240, %ymm4, %ymm6, %ymm9
	vpblendd	$240, %ymm6, %ymm4, %ymm4
	vpsrlvq	glob_data + 192(%rip), %ymm9, %ymm6
	vpsllvq	glob_data + 320(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm6, %ymm4
	vpermq	$177, %ymm0, %ymm10
	vpsrlvq	glob_data + 224(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 384(%rip), %ymm10, %ymm9
	vpor	%ymm9, %ymm6, %ymm6
	vpblendd	$15, %ymm0, %ymm6, %ymm6
	vpermq	$177, %ymm7, %ymm0
	vpblendd	$240, %ymm0, %ymm7, %ymm9
	vpblendd	$240, %ymm7, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm9, %ymm7
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm9
	vpermq	$177, %ymm2, %ymm0
	vpsrlvq	glob_data + 224(%rip), %ymm2, %ymm7
	vpsllvq	glob_data + 384(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm0
	vpblendd	$15, %ymm2, %ymm0, %ymm2
	vpermq	$177, %ymm8, %ymm0
	vpblendd	$240, %ymm0, %ymm8, %ymm7
	vpblendd	$240, %ymm8, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm7, %ymm7
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm0
	vpxor	glob_data + 800(%rip), %ymm0, %ymm7
	vmovdqu	%ymm2, %ymm0
	vpand	%ymm6, %ymm0, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpand	%ymm0, %ymm3, %ymm3
	vpxor	%ymm2, %ymm3, %ymm3
	vpand	%ymm5, %ymm2, %ymm2
	vpxor	%ymm2, %ymm6, %ymm2
	vmovdqu	%ymm7, %ymm6
	vpand	%ymm9, %ymm6, %ymm6
	vpxor	%ymm4, %ymm6, %ymm8
	vpor	%ymm9, %ymm4, %ymm4
	vpxor	%ymm1, %ymm4, %ymm4
	vpand	%ymm8, %ymm1, %ymm1
	vpxor	%ymm7, %ymm1, %ymm6
	vpand	%ymm4, %ymm7, %ymm1
	vpxor	%ymm1, %ymm9, %ymm1
	vpxor	%ymm6, %ymm3, %ymm3
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm2, %ymm2
	vpxor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm3, %ymm3, %ymm7
	vpxor	%ymm7, %ymm8, %ymm7
	vperm2i128	$1, %ymm5, %ymm5, %ymm8
	vpxor	%ymm8, %ymm6, %ymm8
	vperm2i128	$1, %ymm2, %ymm2, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm0, %ymm3, %ymm9
	vpxor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm7, %ymm2, %ymm6
	vpxor	%ymm8, %ymm0, %ymm3
	vpxor	%ymm4, %ymm9, %ymm2
	vpxor	%ymm1, %ymm5, %ymm0
	vperm2i128	$1, %ymm6, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm5
	vperm2i128	$1, %ymm3, %ymm3, %ymm7
	vpxor	%ymm7, %ymm8, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm10
	vpxor	%ymm10, %ymm4, %ymm8
	vperm2i128	$1, %ymm0, %ymm0, %ymm4
	vpxor	%ymm4, %ymm1, %ymm9
	vpermq	$177, %ymm6, %ymm1
	vpsrlvq	glob_data + 96(%rip), %ymm6, %ymm4
	vpsllvq	glob_data + 480(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm4, %ymm1
	vpblendd	$15, %ymm6, %ymm1, %ymm1
	vpermq	$177, %ymm5, %ymm4
	vpblendd	$240, %ymm4, %ymm5, %ymm6
	vpblendd	$240, %ymm5, %ymm4, %ymm4
	vpsrlvq	glob_data + 448(%rip), %ymm6, %ymm5
	vpsllvq	glob_data + 64(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$177, %ymm3, %ymm5
	vpsrlvq	glob_data + 96(%rip), %ymm3, %ymm6
	vpsllvq	glob_data + 480(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpblendd	$15, %ymm3, %ymm5, %ymm5
	vpermq	$177, %ymm7, %ymm3
	vpblendd	$240, %ymm3, %ymm7, %ymm6
	vpblendd	$240, %ymm7, %ymm3, %ymm3
	vpsrlvq	glob_data + 448(%rip), %ymm6, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm3
	vpermq	$177, %ymm2, %ymm6
	vpsrlvq	glob_data + 96(%rip), %ymm2, %ymm7
	vpsllvq	glob_data + 480(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm7, %ymm6
	vpblendd	$15, %ymm2, %ymm6, %ymm2
	vpermq	$177, %ymm8, %ymm7
	vpblendd	$240, %ymm7, %ymm8, %ymm6
	vpblendd	$240, %ymm8, %ymm7, %ymm7
	vpsrlvq	glob_data + 448(%rip), %ymm6, %ymm6
	vpsllvq	glob_data + 64(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpermq	$177, %ymm0, %ymm7
	vpsrlvq	glob_data + 96(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 480(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpblendd	$15, %ymm0, %ymm7, %ymm7
	vpermq	$177, %ymm9, %ymm0
	vpblendd	$240, %ymm0, %ymm9, %ymm8
	vpblendd	$240, %ymm9, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm8, %ymm0
	vpxor	glob_data + 768(%rip), %ymm0, %ymm8
	vmovdqu	%ymm7, %ymm0
	vpand	%ymm2, %ymm0, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpand	%ymm0, %ymm1, %ymm1
	vpxor	%ymm7, %ymm1, %ymm1
	vpand	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vmovdqu	%ymm8, %ymm7
	vpand	%ymm6, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm9
	vpor	%ymm6, %ymm3, %ymm3
	vpxor	%ymm4, %ymm3, %ymm3
	vpand	%ymm9, %ymm4, %ymm4
	vpxor	%ymm8, %ymm4, %ymm7
	vpand	%ymm3, %ymm8, %ymm4
	vpxor	%ymm4, %ymm6, %ymm6
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm3, %ymm5, %ymm4
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm9, %ymm7, %ymm5
	vperm2i128	$1, %ymm1, %ymm1, %ymm7
	vpxor	%ymm7, %ymm9, %ymm8
	vperm2i128	$1, %ymm4, %ymm4, %ymm7
	vpxor	%ymm7, %ymm5, %ymm9
	vperm2i128	$1, %ymm2, %ymm2, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vperm2i128	$1, %ymm0, %ymm0, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm0, %ymm1, %ymm7
	vpxor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm8, %ymm2, %ymm1
	vpxor	%ymm9, %ymm0, %ymm6
	vpxor	%ymm3, %ymm7, %ymm0
	vpxor	%ymm5, %ymm4, %ymm2
	vperm2i128	$1, %ymm1, %ymm1, %ymm4
	vpxor	%ymm4, %ymm8, %ymm4
	vperm2i128	$1, %ymm6, %ymm6, %ymm7
	vpxor	%ymm7, %ymm9, %ymm9
	vperm2i128	$1, %ymm0, %ymm0, %ymm7
	vpxor	%ymm7, %ymm3, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm3
	vpxor	%ymm3, %ymm5, %ymm5
	vpermq	$177, %ymm1, %ymm3
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 128(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm8, %ymm8
	vpblendd	$15, %ymm1, %ymm8, %ymm3
	vpermq	$177, %ymm4, %ymm8
	vpsrlvq	glob_data + 352(%rip), %ymm4, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm8, %ymm1
	vpor	%ymm1, %ymm4, %ymm4
	vpermq	$177, %ymm6, %ymm1
	vpsrlvq	glob_data + 416(%rip), %ymm6, %ymm8
	vpsllvq	glob_data + 128(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm8, %ymm1
	vpblendd	$15, %ymm6, %ymm1, %ymm6
	vpermq	$177, %ymm9, %ymm8
	vpsrlvq	glob_data + 352(%rip), %ymm9, %ymm1
	vpsllvq	glob_data + 160(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm1, %ymm1
	vpermq	$177, %ymm0, %ymm8
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm9
	vpsllvq	glob_data + 128(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm9, %ymm8
	vpblendd	$15, %ymm0, %ymm8, %ymm9
	vpermq	$177, %ymm7, %ymm0
	vpsrlvq	glob_data + 352(%rip), %ymm7, %ymm7
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm7
	vpermq	$177, %ymm2, %ymm8
	vpsrlvq	glob_data + 416(%rip), %ymm2, %ymm0
	vpsllvq	glob_data + 128(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm0, %ymm0
	vpblendd	$15, %ymm2, %ymm0, %ymm10
	vpermq	$177, %ymm5, %ymm0
	vpsrlvq	glob_data + 352(%rip), %ymm5, %ymm2
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm8
	vpor	%ymm8, %ymm2, %ymm0
	vpxor	glob_data + 736(%rip), %ymm0, %ymm2
	vmovdqu	%ymm10, %ymm0
	vpand	%ymm9, %ymm0, %ymm0
	vpxor	%ymm6, %ymm0, %ymm0
	vpor	%ymm9, %ymm6, %ymm6
	vpxor	%ymm3, %ymm6, %ymm6
	vpand	%ymm0, %ymm3, %ymm3
	vpxor	%ymm10, %ymm3, %ymm3
	vpand	%ymm6, %ymm10, %ymm5
	vpxor	%ymm5, %ymm9, %ymm9
	vmovdqu	%ymm2, %ymm5
	vpand	%ymm7, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm4, %ymm1, %ymm1
	vpand	%ymm5, %ymm4, %ymm4
	vpxor	%ymm2, %ymm4, %ymm8
	vpand	%ymm1, %ymm2, %ymm2
	vpxor	%ymm2, %ymm7, %ymm4
	vpxor	%ymm8, %ymm3, %ymm2
	vpxor	%ymm1, %ymm6, %ymm6
	vpxor	%ymm4, %ymm9, %ymm9
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm8, %ymm3
	vperm2i128	$1, %ymm2, %ymm2, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vperm2i128	$1, %ymm6, %ymm6, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vperm2i128	$1, %ymm9, %ymm9, %ymm7
	vpxor	%ymm7, %ymm1, %ymm7
	vperm2i128	$1, %ymm0, %ymm0, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm0, %ymm2, %ymm1
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm5, %ymm9, %ymm2
	vpxor	%ymm3, %ymm0, %ymm8
	vpxor	%ymm7, %ymm1, %ymm0
	vpxor	%ymm4, %ymm6, %ymm1
	vperm2i128	$1, %ymm2, %ymm2, %ymm10
	vpxor	%ymm10, %ymm5, %ymm5
	vperm2i128	$1, %ymm8, %ymm8, %ymm6
	vpxor	%ymm6, %ymm3, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm3
	vpxor	%ymm3, %ymm7, %ymm7
	vperm2i128	$1, %ymm1, %ymm1, %ymm3
	vpxor	%ymm3, %ymm4, %ymm9
	vpermq	$177, %ymm2, %ymm3
	vpblendd	$240, %ymm3, %ymm2, %ymm4
	vpblendd	$240, %ymm2, %ymm3, %ymm3
	vpsrlvq	glob_data + 0(%rip), %ymm4, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm4
	vpblendd	$15, %ymm2, %ymm4, %ymm3
	vpermq	$177, %ymm5, %ymm4
	vpblendd	$240, %ymm4, %ymm5, %ymm2
	vpblendd	$240, %ymm5, %ymm4, %ymm4
	vpsrlvq	glob_data + 288(%rip), %ymm2, %ymm2
	vpsllvq	glob_data + 256(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpermq	$177, %ymm8, %ymm4
	vpblendd	$240, %ymm4, %ymm8, %ymm5
	vpblendd	$240, %ymm8, %ymm4, %ymm4
	vpsrlvq	glob_data + 0(%rip), %ymm5, %ymm5
	vpsllvq	glob_data + 32(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpblendd	$15, %ymm8, %ymm4, %ymm5
	vpermq	$177, %ymm6, %ymm4
	vpblendd	$240, %ymm4, %ymm6, %ymm8
	vpblendd	$240, %ymm6, %ymm4, %ymm4
	vpsrlvq	glob_data + 288(%rip), %ymm8, %ymm10
	vpsllvq	glob_data + 256(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm10, %ymm4
	vpermq	$177, %ymm0, %ymm6
	vpblendd	$240, %ymm6, %ymm0, %ymm8
	vpblendd	$240, %ymm0, %ymm6, %ymm6
	vpsrlvq	glob_data + 0(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 32(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm6
	vpblendd	$15, %ymm0, %ymm6, %ymm6
	vpermq	$177, %ymm7, %ymm8
	vpblendd	$240, %ymm8, %ymm7, %ymm0
	vpblendd	$240, %ymm7, %ymm8, %ymm7
	vpsrlvq	glob_data + 288(%rip), %ymm0, %ymm0
	vpsllvq	glob_data + 256(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm0, %ymm7
	vpermq	$177, %ymm1, %ymm0
	vpblendd	$240, %ymm0, %ymm1, %ymm8
	vpblendd	$240, %ymm1, %ymm0, %ymm0
	vpsrlvq	glob_data + 0(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 32(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm8, %ymm0
	vpblendd	$15, %ymm1, %ymm0, %ymm1
	vpermq	$177, %ymm9, %ymm0
	vpblendd	$240, %ymm0, %ymm9, %ymm8
	vpblendd	$240, %ymm9, %ymm0, %ymm0
	vpsrlvq	glob_data + 288(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm9
	vpor	%ymm9, %ymm8, %ymm0
	vpxor	glob_data + 704(%rip), %ymm0, %ymm8
	vmovdqu	%ymm1, %ymm0
	vpand	%ymm6, %ymm0, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpand	%ymm0, %ymm3, %ymm3
	vpxor	%ymm1, %ymm3, %ymm3
	vpand	%ymm5, %ymm1, %ymm1
	vpxor	%ymm1, %ymm6, %ymm6
	vmovdqu	%ymm8, %ymm1
	vpand	%ymm7, %ymm1, %ymm1
	vpxor	%ymm4, %ymm1, %ymm1
	vpor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm2, %ymm4, %ymm4
	vpand	%ymm1, %ymm2, %ymm2
	vpxor	%ymm8, %ymm2, %ymm9
	vpand	%ymm4, %ymm8, %ymm2
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm9, %ymm3, %ymm3
	vpxor	%ymm4, %ymm5, %ymm2
	vpxor	%ymm7, %ymm6, %ymm5
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm1, %ymm9, %ymm8
	vperm2i128	$1, %ymm3, %ymm3, %ymm6
	vpxor	%ymm6, %ymm1, %ymm6
	vperm2i128	$1, %ymm2, %ymm2, %ymm1
	vpxor	%ymm1, %ymm8, %ymm8
	vperm2i128	$1, %ymm5, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm1
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm0, %ymm3, %ymm1
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm6, %ymm5, %ymm3
	vpxor	%ymm8, %ymm0, %ymm5
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm7, %ymm2, %ymm0
	vperm2i128	$1, %ymm3, %ymm3, %ymm2
	vpxor	%ymm2, %ymm6, %ymm6
	vperm2i128	$1, %ymm5, %ymm5, %ymm2
	vpxor	%ymm2, %ymm8, %ymm8
	vperm2i128	$1, %ymm1, %ymm1, %ymm2
	vpxor	%ymm2, %ymm4, %ymm10
	vperm2i128	$1, %ymm0, %ymm0, %ymm4
	vpxor	%ymm4, %ymm7, %ymm7
	vpermq	$177, %ymm3, %ymm2
	vpsrlvq	glob_data + 224(%rip), %ymm3, %ymm4
	vpsllvq	glob_data + 384(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm4, %ymm4
	vpblendd	$15, %ymm3, %ymm4, %ymm2
	vpermq	$177, %ymm6, %ymm3
	vpblendd	$240, %ymm3, %ymm6, %ymm4
	vpblendd	$240, %ymm6, %ymm3, %ymm3
	vpsrlvq	glob_data + 192(%rip), %ymm4, %ymm4
	vpsllvq	glob_data + 320(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm3
	vpermq	$177, %ymm5, %ymm4
	vpsrlvq	glob_data + 224(%rip), %ymm5, %ymm6
	vpsllvq	glob_data + 384(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm6, %ymm4
	vpblendd	$15, %ymm5, %ymm4, %ymm5
	vpermq	$177, %ymm8, %ymm4
	vpblendd	$240, %ymm4, %ymm8, %ymm6
	vpblendd	$240, %ymm8, %ymm4, %ymm4
	vpsrlvq	glob_data + 192(%rip), %ymm6, %ymm6
	vpsllvq	glob_data + 320(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm6, %ymm4
	vpermq	$177, %ymm1, %ymm6
	vpsrlvq	glob_data + 224(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 384(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm6
	vpblendd	$15, %ymm1, %ymm6, %ymm6
	vpermq	$177, %ymm10, %ymm1
	vpblendd	$240, %ymm1, %ymm10, %ymm8
	vpblendd	$240, %ymm10, %ymm1, %ymm1
	vpsrlvq	glob_data + 192(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 320(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm8, %ymm1
	vpermq	$177, %ymm0, %ymm8
	vpsrlvq	glob_data + 224(%rip), %ymm0, %ymm10
	vpsllvq	glob_data + 384(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm10, %ymm10
	vpblendd	$15, %ymm0, %ymm10, %ymm8
	vpermq	$177, %ymm7, %ymm0
	vpblendd	$240, %ymm0, %ymm7, %ymm9
	vpblendd	$240, %ymm7, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm9, %ymm7
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm7
	vpxor	glob_data + 672(%rip), %ymm7, %ymm9
	vmovdqu	%ymm8, %ymm0
	vpand	%ymm6, %ymm0, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpand	%ymm0, %ymm2, %ymm2
	vpxor	%ymm8, %ymm2, %ymm2
	vpand	%ymm5, %ymm8, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vmovdqu	%ymm9, %ymm7
	vpand	%ymm1, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpand	%ymm7, %ymm3, %ymm3
	vpxor	%ymm9, %ymm3, %ymm8
	vpand	%ymm4, %ymm9, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm8, %ymm2, %ymm2
	vpxor	%ymm4, %ymm5, %ymm3
	vpxor	%ymm1, %ymm6, %ymm5
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm8, %ymm8
	vperm2i128	$1, %ymm2, %ymm2, %ymm6
	vpxor	%ymm6, %ymm7, %ymm7
	vperm2i128	$1, %ymm3, %ymm3, %ymm6
	vpxor	%ymm6, %ymm8, %ymm8
	vperm2i128	$1, %ymm5, %ymm5, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vperm2i128	$1, %ymm0, %ymm0, %ymm9
	vpxor	%ymm9, %ymm1, %ymm6
	vpxor	%ymm0, %ymm2, %ymm1
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm8, %ymm0, %ymm10
	vpxor	%ymm4, %ymm1, %ymm0
	vpxor	%ymm6, %ymm3, %ymm1
	vperm2i128	$1, %ymm5, %ymm5, %ymm2
	vpxor	%ymm2, %ymm7, %ymm3
	vperm2i128	$1, %ymm10, %ymm10, %ymm7
	vpxor	%ymm7, %ymm8, %ymm7
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm4, %ymm8
	vperm2i128	$1, %ymm1, %ymm1, %ymm4
	vpxor	%ymm4, %ymm6, %ymm6
	vpermq	$177, %ymm5, %ymm2
	vpsrlvq	glob_data + 96(%rip), %ymm5, %ymm4
	vpsllvq	glob_data + 480(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm4, %ymm2
	vpblendd	$15, %ymm5, %ymm2, %ymm4
	vpermq	$177, %ymm3, %ymm9
	vpblendd	$240, %ymm9, %ymm3, %ymm5
	vpblendd	$240, %ymm3, %ymm9, %ymm2
	vpsrlvq	glob_data + 448(%rip), %ymm5, %ymm3
	vpsllvq	glob_data + 64(%rip), %ymm2, %ymm5
	vpor	%ymm5, %ymm3, %ymm2
	vpermq	$177, %ymm10, %ymm3
	vpsrlvq	glob_data + 96(%rip), %ymm10, %ymm5
	vpsllvq	glob_data + 480(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpblendd	$15, %ymm10, %ymm3, %ymm5
	vpermq	$177, %ymm7, %ymm3
	vpblendd	$240, %ymm3, %ymm7, %ymm9
	vpblendd	$240, %ymm7, %ymm3, %ymm3
	vpsrlvq	glob_data + 448(%rip), %ymm9, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm3
	vpermq	$177, %ymm0, %ymm7
	vpsrlvq	glob_data + 96(%rip), %ymm0, %ymm9
	vpsllvq	glob_data + 480(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm9, %ymm7
	vpblendd	$15, %ymm0, %ymm7, %ymm7
	vpermq	$177, %ymm8, %ymm0
	vpblendd	$240, %ymm0, %ymm8, %ymm10
	vpblendd	$240, %ymm8, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm10, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm8, %ymm8
	vpermq	$177, %ymm1, %ymm0
	vpsrlvq	glob_data + 96(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 480(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm9, %ymm0
	vpblendd	$15, %ymm1, %ymm0, %ymm1
	vpermq	$177, %ymm6, %ymm0
	vpblendd	$240, %ymm0, %ymm6, %ymm9
	vpblendd	$240, %ymm6, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm9, %ymm9
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm9, %ymm0
	vpxor	glob_data + 640(%rip), %ymm0, %ymm9
	vmovdqu	%ymm1, %ymm0
	vpand	%ymm7, %ymm0, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpand	%ymm0, %ymm4, %ymm4
	vpxor	%ymm1, %ymm4, %ymm4
	vpand	%ymm5, %ymm1, %ymm1
	vpxor	%ymm1, %ymm7, %ymm6
	vmovdqu	%ymm9, %ymm1
	vpand	%ymm8, %ymm1, %ymm1
	vpxor	%ymm3, %ymm1, %ymm1
	vpor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm2, %ymm3, %ymm3
	vpand	%ymm1, %ymm2, %ymm2
	vpxor	%ymm9, %ymm2, %ymm7
	vpand	%ymm3, %ymm9, %ymm2
	vpxor	%ymm2, %ymm8, %ymm2
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm2, %ymm6, %ymm6
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm1, %ymm7, %ymm8
	vperm2i128	$1, %ymm4, %ymm4, %ymm7
	vpxor	%ymm7, %ymm1, %ymm7
	vperm2i128	$1, %ymm5, %ymm5, %ymm1
	vpxor	%ymm1, %ymm8, %ymm8
	vperm2i128	$1, %ymm6, %ymm6, %ymm1
	vpxor	%ymm1, %ymm3, %ymm9
	vperm2i128	$1, %ymm0, %ymm0, %ymm1
	vpxor	%ymm1, %ymm2, %ymm2
	vpxor	%ymm0, %ymm4, %ymm1
	vpxor	%ymm6, %ymm0, %ymm3
	vpxor	%ymm7, %ymm6, %ymm0
	vpxor	%ymm8, %ymm3, %ymm4
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm2, %ymm5, %ymm3
	vperm2i128	$1, %ymm0, %ymm0, %ymm5
	vpxor	%ymm5, %ymm7, %ymm6
	vperm2i128	$1, %ymm4, %ymm4, %ymm5
	vpxor	%ymm5, %ymm8, %ymm5
	vperm2i128	$1, %ymm1, %ymm1, %ymm7
	vpxor	%ymm7, %ymm9, %ymm7
	vperm2i128	$1, %ymm3, %ymm3, %ymm8
	vpxor	%ymm8, %ymm2, %ymm8
	vpermq	$177, %ymm0, %ymm2
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm9
	vpsllvq	glob_data + 128(%rip), %ymm2, %ymm10
	vpor	%ymm10, %ymm9, %ymm9
	vpblendd	$15, %ymm0, %ymm9, %ymm0
	vpermq	$177, %ymm6, %ymm9
	vpsrlvq	glob_data + 352(%rip), %ymm6, %ymm2
	vpsllvq	glob_data + 160(%rip), %ymm9, %ymm9
	vpor	%ymm9, %ymm2, %ymm2
	vpermq	$177, %ymm4, %ymm10
	vpsrlvq	glob_data + 416(%rip), %ymm4, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm10, %ymm9
	vpor	%ymm9, %ymm6, %ymm6
	vpblendd	$15, %ymm4, %ymm6, %ymm6
	vpermq	$177, %ymm5, %ymm4
	vpsrlvq	glob_data + 352(%rip), %ymm5, %ymm5
	vpsllvq	glob_data + 160(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$177, %ymm1, %ymm5
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 128(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm9, %ymm5
	vpblendd	$15, %ymm1, %ymm5, %ymm5
	vpermq	$177, %ymm7, %ymm9
	vpsrlvq	glob_data + 352(%rip), %ymm7, %ymm1
	vpsllvq	glob_data + 160(%rip), %ymm9, %ymm7
	vpor	%ymm7, %ymm1, %ymm7
	vpermq	$177, %ymm3, %ymm9
	vpsrlvq	glob_data + 416(%rip), %ymm3, %ymm1
	vpsllvq	glob_data + 128(%rip), %ymm9, %ymm9
	vpor	%ymm9, %ymm1, %ymm1
	vpblendd	$15, %ymm3, %ymm1, %ymm3
	vpermq	$177, %ymm8, %ymm9
	vpsrlvq	glob_data + 352(%rip), %ymm8, %ymm1
	vpsllvq	glob_data + 160(%rip), %ymm9, %ymm8
	vpor	%ymm8, %ymm1, %ymm1
	vpxor	glob_data + 608(%rip), %ymm1, %ymm8
	vmovdqu	%ymm3, %ymm1
	vpand	%ymm5, %ymm1, %ymm1
	vpxor	%ymm6, %ymm1, %ymm1
	vpor	%ymm5, %ymm6, %ymm6
	vpxor	%ymm0, %ymm6, %ymm6
	vpand	%ymm1, %ymm0, %ymm0
	vpxor	%ymm3, %ymm0, %ymm0
	vpand	%ymm6, %ymm3, %ymm3
	vpxor	%ymm3, %ymm5, %ymm3
	vmovdqu	%ymm8, %ymm5
	vpand	%ymm7, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm2, %ymm4, %ymm4
	vpand	%ymm5, %ymm2, %ymm2
	vpxor	%ymm8, %ymm2, %ymm9
	vpand	%ymm4, %ymm8, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm4, %ymm6, %ymm2
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm9, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm8
	vpxor	%ymm8, %ymm5, %ymm5
	vperm2i128	$1, %ymm2, %ymm2, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vperm2i128	$1, %ymm3, %ymm3, %ymm8
	vpxor	%ymm8, %ymm4, %ymm4
	vperm2i128	$1, %ymm1, %ymm1, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm6, %ymm1, %ymm8
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm7, %ymm2, %ymm1
	vperm2i128	$1, %ymm3, %ymm3, %ymm9
	vpxor	%ymm9, %ymm5, %ymm5
	vperm2i128	$1, %ymm8, %ymm8, %ymm9
	vpxor	%ymm9, %ymm6, %ymm6
	vperm2i128	$1, %ymm0, %ymm0, %ymm9
	vpxor	%ymm9, %ymm4, %ymm9
	vperm2i128	$1, %ymm1, %ymm1, %ymm2
	vpxor	%ymm2, %ymm7, %ymm7
	vpermq	$177, %ymm3, %ymm4
	vpblendd	$240, %ymm4, %ymm3, %ymm2
	vpblendd	$240, %ymm3, %ymm4, %ymm4
	vpsrlvq	glob_data + 0(%rip), %ymm2, %ymm2
	vpsllvq	glob_data + 32(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpblendd	$15, %ymm3, %ymm2, %ymm2
	vpermq	$177, %ymm5, %ymm3
	vpblendd	$240, %ymm3, %ymm5, %ymm4
	vpblendd	$240, %ymm5, %ymm3, %ymm3
	vpsrlvq	glob_data + 288(%rip), %ymm4, %ymm4
	vpsllvq	glob_data + 256(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm4
	vpermq	$177, %ymm8, %ymm3
	vpblendd	$240, %ymm3, %ymm8, %ymm5
	vpblendd	$240, %ymm8, %ymm3, %ymm3
	vpsrlvq	glob_data + 0(%rip), %ymm5, %ymm5
	vpsllvq	glob_data + 32(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpblendd	$15, %ymm8, %ymm3, %ymm5
	vpermq	$177, %ymm6, %ymm3
	vpblendd	$240, %ymm3, %ymm6, %ymm8
	vpblendd	$240, %ymm6, %ymm3, %ymm3
	vpsrlvq	glob_data + 288(%rip), %ymm8, %ymm6
	vpsllvq	glob_data + 256(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$177, %ymm0, %ymm6
	vpblendd	$240, %ymm6, %ymm0, %ymm8
	vpblendd	$240, %ymm0, %ymm6, %ymm6
	vpsrlvq	glob_data + 0(%rip), %ymm8, %ymm8
	vpsllvq	glob_data + 32(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm6
	vpblendd	$15, %ymm0, %ymm6, %ymm8
	vpermq	$177, %ymm9, %ymm0
	vpblendd	$240, %ymm0, %ymm9, %ymm6
	vpblendd	$240, %ymm9, %ymm0, %ymm0
	vpsrlvq	glob_data + 288(%rip), %ymm6, %ymm6
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm6
	vpermq	$177, %ymm1, %ymm0
	vpblendd	$240, %ymm0, %ymm1, %ymm9
	vpblendd	$240, %ymm1, %ymm0, %ymm0
	vpsrlvq	glob_data + 0(%rip), %ymm9, %ymm9
	vpsllvq	glob_data + 32(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm9, %ymm0
	vpblendd	$15, %ymm1, %ymm0, %ymm1
	vpermq	$177, %ymm7, %ymm0
	vpblendd	$240, %ymm0, %ymm7, %ymm9
	vpblendd	$240, %ymm7, %ymm0, %ymm0
	vpsrlvq	glob_data + 288(%rip), %ymm9, %ymm7
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm0
	vpxor	glob_data + 576(%rip), %ymm0, %ymm7
	vmovdqu	%ymm1, %ymm0
	vpand	%ymm8, %ymm0, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpor	%ymm8, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpand	%ymm0, %ymm2, %ymm2
	vpxor	%ymm1, %ymm2, %ymm2
	vpand	%ymm5, %ymm1, %ymm1
	vpxor	%ymm1, %ymm8, %ymm1
	vmovdqu	%ymm7, %ymm10
	vpand	%ymm6, %ymm10, %ymm10
	vpxor	%ymm3, %ymm10, %ymm10
	vpor	%ymm6, %ymm3, %ymm3
	vpxor	%ymm4, %ymm3, %ymm3
	vpand	%ymm10, %ymm4, %ymm4
	vpxor	%ymm7, %ymm4, %ymm8
	vpand	%ymm3, %ymm7, %ymm4
	vpxor	%ymm4, %ymm6, %ymm6
	vpxor	%ymm8, %ymm2, %ymm2
	vpxor	%ymm3, %ymm5, %ymm4
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm10, %ymm0, %ymm0
	vpxor	%ymm10, %ymm8, %ymm7
	vperm2i128	$1, %ymm2, %ymm2, %ymm5
	vpxor	%ymm5, %ymm10, %ymm5
	vperm2i128	$1, %ymm4, %ymm4, %ymm8
	vpxor	%ymm8, %ymm7, %ymm8
	vperm2i128	$1, %ymm1, %ymm1, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vperm2i128	$1, %ymm0, %ymm0, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm8, %ymm0, %ymm7
	vpxor	%ymm3, %ymm2, %ymm0
	vpxor	%ymm6, %ymm4, %ymm2
	vperm2i128	$1, %ymm1, %ymm1, %ymm4
	vpxor	%ymm4, %ymm5, %ymm4
	vperm2i128	$1, %ymm7, %ymm7, %ymm5
	vpxor	%ymm5, %ymm8, %ymm8
	vperm2i128	$1, %ymm0, %ymm0, %ymm5
	vpxor	%ymm5, %ymm3, %ymm9
	vperm2i128	$1, %ymm2, %ymm2, %ymm3
	vpxor	%ymm3, %ymm6, %ymm5
	vpermq	$177, %ymm1, %ymm3
	vpsrlvq	glob_data + 224(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 384(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpblendd	$15, %ymm1, %ymm3, %ymm1
	vpermq	$177, %ymm4, %ymm3
	vpblendd	$240, %ymm3, %ymm4, %ymm6
	vpblendd	$240, %ymm4, %ymm3, %ymm3
	vpsrlvq	glob_data + 192(%rip), %ymm6, %ymm4
	vpsllvq	glob_data + 320(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm4
	vpermq	$177, %ymm7, %ymm3
	vpsrlvq	glob_data + 224(%rip), %ymm7, %ymm10
	vpsllvq	glob_data + 384(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm10, %ymm3
	vpblendd	$15, %ymm7, %ymm3, %ymm7
	vpermq	$177, %ymm8, %ymm3
	vpblendd	$240, %ymm3, %ymm8, %ymm6
	vpblendd	$240, %ymm8, %ymm3, %ymm3
	vpsrlvq	glob_data + 192(%rip), %ymm6, %ymm6
	vpsllvq	glob_data + 320(%rip), %ymm3, %ymm8
	vpor	%ymm8, %ymm6, %ymm3
	vpermq	$177, %ymm0, %ymm10
	vpsrlvq	glob_data + 224(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 384(%rip), %ymm10, %ymm8
	vpor	%ymm8, %ymm6, %ymm6
	vpblendd	$15, %ymm0, %ymm6, %ymm8
	vpermq	$177, %ymm9, %ymm0
	vpblendd	$240, %ymm0, %ymm9, %ymm6
	vpblendd	$240, %ymm9, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm6, %ymm6
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm6
	vpermq	$177, %ymm2, %ymm9
	vpsrlvq	glob_data + 224(%rip), %ymm2, %ymm0
	vpsllvq	glob_data + 384(%rip), %ymm9, %ymm9
	vpor	%ymm9, %ymm0, %ymm0
	vpblendd	$15, %ymm2, %ymm0, %ymm2
	vpermq	$177, %ymm5, %ymm0
	vpblendd	$240, %ymm0, %ymm5, %ymm9
	vpblendd	$240, %ymm5, %ymm0, %ymm0
	vpsrlvq	glob_data + 192(%rip), %ymm9, %ymm5
	vpsllvq	glob_data + 320(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm0
	vpxor	glob_data + 544(%rip), %ymm0, %ymm9
	vmovdqu	%ymm2, %ymm0
	vpand	%ymm8, %ymm0, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpor	%ymm8, %ymm7, %ymm5
	vpxor	%ymm1, %ymm5, %ymm7
	vpand	%ymm0, %ymm1, %ymm1
	vpxor	%ymm2, %ymm1, %ymm1
	vpand	%ymm7, %ymm2, %ymm2
	vpxor	%ymm2, %ymm8, %ymm2
	vmovdqu	%ymm9, %ymm5
	vpand	%ymm6, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpor	%ymm6, %ymm3, %ymm3
	vpxor	%ymm4, %ymm3, %ymm3
	vpand	%ymm5, %ymm4, %ymm4
	vpxor	%ymm9, %ymm4, %ymm8
	vpand	%ymm3, %ymm9, %ymm4
	vpxor	%ymm4, %ymm6, %ymm4
	vpxor	%ymm8, %ymm1, %ymm1
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm8, %ymm8
	vperm2i128	$1, %ymm1, %ymm1, %ymm10
	vpxor	%ymm10, %ymm5, %ymm5
	vperm2i128	$1, %ymm7, %ymm7, %ymm6
	vpxor	%ymm6, %ymm8, %ymm9
	vperm2i128	$1, %ymm2, %ymm2, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vperm2i128	$1, %ymm0, %ymm0, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm0, %ymm1, %ymm8
	vpxor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm5, %ymm2, %ymm1
	vpxor	%ymm9, %ymm0, %ymm6
	vpxor	%ymm3, %ymm8, %ymm0
	vpxor	%ymm4, %ymm7, %ymm2
	vperm2i128	$1, %ymm1, %ymm1, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vperm2i128	$1, %ymm6, %ymm6, %ymm7
	vpxor	%ymm7, %ymm9, %ymm9
	vperm2i128	$1, %ymm0, %ymm0, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vperm2i128	$1, %ymm2, %ymm2, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$177, %ymm1, %ymm7
	vpsrlvq	glob_data + 96(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 480(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpblendd	$15, %ymm1, %ymm7, %ymm1
	vpermq	$177, %ymm5, %ymm7
	vpblendd	$240, %ymm7, %ymm5, %ymm8
	vpblendd	$240, %ymm5, %ymm7, %ymm7
	vpsrlvq	glob_data + 448(%rip), %ymm8, %ymm5
	vpsllvq	glob_data + 64(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm5, %ymm5
	vpermq	$177, %ymm6, %ymm7
	vpsrlvq	glob_data + 96(%rip), %ymm6, %ymm8
	vpsllvq	glob_data + 480(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm7
	vpblendd	$15, %ymm6, %ymm7, %ymm6
	vpermq	$177, %ymm9, %ymm7
	vpblendd	$240, %ymm7, %ymm9, %ymm8
	vpblendd	$240, %ymm9, %ymm7, %ymm7
	vpsrlvq	glob_data + 448(%rip), %ymm8, %ymm10
	vpsllvq	glob_data + 64(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm10, %ymm7
	vpermq	$177, %ymm0, %ymm8
	vpsrlvq	glob_data + 96(%rip), %ymm0, %ymm9
	vpsllvq	glob_data + 480(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm9, %ymm8
	vpblendd	$15, %ymm0, %ymm8, %ymm0
	vpermq	$177, %ymm3, %ymm8
	vpblendd	$240, %ymm8, %ymm3, %ymm9
	vpblendd	$240, %ymm3, %ymm8, %ymm3
	vpsrlvq	glob_data + 448(%rip), %ymm9, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm8, %ymm8
	vpermq	$177, %ymm2, %ymm3
	vpsrlvq	glob_data + 96(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 480(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm9, %ymm3
	vpblendd	$15, %ymm2, %ymm3, %ymm3
	vpermq	$177, %ymm4, %ymm9
	vpblendd	$240, %ymm9, %ymm4, %ymm2
	vpblendd	$240, %ymm4, %ymm9, %ymm4
	vpsrlvq	glob_data + 448(%rip), %ymm2, %ymm2
	vpsllvq	glob_data + 64(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpxor	glob_data + 512(%rip), %ymm2, %ymm2
	vperm2i128	$32, %ymm5, %ymm1, %ymm4
	vmovdqu	%ymm4, (%rdi)
	vperm2i128	$49, %ymm5, %ymm1, %ymm4
	vmovdqu	%ymm4, 32(%rdi)
	vperm2i128	$32, %ymm7, %ymm6, %ymm4
	vmovdqu	%ymm4, 64(%rdi)
	vperm2i128	$49, %ymm7, %ymm6, %ymm1
	vmovdqu	%ymm1, 96(%rdi)
	vperm2i128	$32, %ymm8, %ymm0, %ymm1
	vmovdqu	%ymm1, 128(%rdi)
	vperm2i128	$49, %ymm8, %ymm0, %ymm0
	vmovdqu	%ymm0, 160(%rdi)
	vperm2i128	$32, %ymm2, %ymm3, %ymm0
	vmovdqu	%ymm0, 192(%rdi)
	vperm2i128	$49, %ymm2, %ymm3, %ymm0
	vmovdqu	%ymm0, 224(%rdi)
	ret
	.data
	.p2align	5
glob_data:
G$kvc_4000000000000000400000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  4,   0,   0,   0,   0,   0,   0,   0,   4,   0,   0,   0,   0,   0,   0,   0
G$kvc_3c000000000000003c00000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 60,   0,   0,   0,   0,   0,   0,   0,  60,   0,   0,   0,   0,   0,   0,   0
G$kvc_30000000000000003000000000000000200000000000000020:
	.byte	 32,   0,   0,   0,   0,   0,   0,   0,  32,   0,   0,   0,   0,   0,   0,   0
	.byte	 48,   0,   0,   0,   0,   0,   0,   0,  48,   0,   0,   0,   0,   0,   0,   0
G$kvc_30000000000000003000000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 48,   0,   0,   0,   0,   0,   0,   0,  48,   0,   0,   0,   0,   0,   0,   0
G$kvc_2c000000000000002c00000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 44,   0,   0,   0,   0,   0,   0,   0,  44,   0,   0,   0,   0,   0,   0,   0
G$kvc_2a000000000000002a00000000000000320000000000000032:
	.byte	 50,   0,   0,   0,   0,   0,   0,   0,  50,   0,   0,   0,   0,   0,   0,   0
	.byte	 42,   0,   0,   0,   0,   0,   0,   0,  42,   0,   0,   0,   0,   0,   0,   0
G$kvc_2a000000000000002a000000000000001b000000000000001b:
	.byte	 27,   0,   0,   0,   0,   0,   0,   0,  27,   0,   0,   0,   0,   0,   0,   0
	.byte	 42,   0,   0,   0,   0,   0,   0,   0,  42,   0,   0,   0,   0,   0,   0,   0
G$kvc_2a000000000000002a00000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 42,   0,   0,   0,   0,   0,   0,   0,  42,   0,   0,   0,   0,   0,   0,   0
G$kvc_25000000000000002500000000000000330000000000000033:
	.byte	 51,   0,   0,   0,   0,   0,   0,   0,  51,   0,   0,   0,   0,   0,   0,   0
	.byte	 37,   0,   0,   0,   0,   0,   0,   0,  37,   0,   0,   0,   0,   0,   0,   0
G$kvc_1b000000000000001b000000000000000d000000000000000d:
	.byte	 13,   0,   0,   0,   0,   0,   0,   0,  13,   0,   0,   0,   0,   0,   0,   0
	.byte	 27,   0,   0,   0,   0,   0,   0,   0,  27,   0,   0,   0,   0,   0,   0,   0
G$kvc_16000000000000001600000000000000250000000000000025:
	.byte	 37,   0,   0,   0,   0,   0,   0,   0,  37,   0,   0,   0,   0,   0,   0,   0
	.byte	 22,   0,   0,   0,   0,   0,   0,   0,  22,   0,   0,   0,   0,   0,   0,   0
G$kvc_160000000000000016000000000000000e000000000000000e:
	.byte	 14,   0,   0,   0,   0,   0,   0,   0,  14,   0,   0,   0,   0,   0,   0,   0
	.byte	 22,   0,   0,   0,   0,   0,   0,   0,  22,   0,   0,   0,   0,   0,   0,   0
G$kvc_16000000000000001600000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 22,   0,   0,   0,   0,   0,   0,   0,  22,   0,   0,   0,   0,   0,   0,   0
G$kvc_14000000000000001400000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 20,   0,   0,   0,   0,   0,   0,   0,  20,   0,   0,   0,   0,   0,   0,   0
G$kvc_10000000000000001000000000000000200000000000000020:
	.byte	 32,   0,   0,   0,   0,   0,   0,   0,  32,   0,   0,   0,   0,   0,   0,   0
	.byte	 16,   0,   0,   0,   0,   0,   0,   0,  16,   0,   0,   0,   0,   0,   0,   0
G$kvc_10000000000000001000000000000000000000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 16,   0,   0,   0,   0,   0,   0,   0,  16,   0,   0,   0,   0,   0,   0,   0
G$K19:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 34,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K18:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 56,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K17:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  9,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K16:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	164,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K15:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 68,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K14:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	115,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K13:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	112,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K12:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K11:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 46,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K10:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	138,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K9:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 25,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K8:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 19,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K7:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	211,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K6:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  8,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K5:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	163,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K4:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	133,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K3:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	136,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K2:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	106,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K1:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 63,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$K0:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	 36,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits
