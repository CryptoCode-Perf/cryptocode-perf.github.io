# MOZI-384

Algorithm: Mozi | Digest bits: 384 | Form: SSE 汇编

Contents: implementation source/, public header MOZI-384.h, prebuilt MOZI-384.so,
KAT vector KAT_2_12_MOZI-384.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 43c7de96ef495007e82051ecff5ea1951c66b64cf10dcfc0c0e58d8ef5a6653a
Speed (cpB, lower is faster): reference 11.97 / official-optimized 4.33 / optimized 3.19
Speedup: GM(S1-S8) 1.39x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
