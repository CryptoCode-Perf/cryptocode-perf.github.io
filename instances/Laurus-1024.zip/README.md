# Laurus-1024

Algorithm: Laurus | Digest bits: 1024 | Form: 标量 C

Contents: implementation source/, public header Laurus-1024.h, prebuilt Laurus-1024.so,
KAT vector KAT_2_12_laurus_1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 04a8fe058f3ff0dd1f9387c790058906649f4d449b193b6cca3ba8a54a49da43
Speed (cpB, lower is faster): reference 34.80 / official-optimized 8.73 / optimized 8.08
Speedup: GM(S1-S8) 1.06x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
