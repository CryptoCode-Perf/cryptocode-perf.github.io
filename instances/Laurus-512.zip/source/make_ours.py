#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""make_ours.py —— 从官方 Optimized_Implementation/Laurus-512/laurus_512.c 派生 ours.c。

只做三处**语义等价**改写（与 Laurus-1024 那一例同型，逐处已在该例做过负对照）：

  1) `#define load64(y) ...` 逐字节拼装宏  ->  static inline uint64_t load64()
     （`__builtin_memcpy` 整字读 + `__builtin_bswap64`，big-endian 语义不变）
  2) `#define store64(y,x) ...` 逐字节写宏  ->  static inline void store64()
     （`__builtin_bswap64` + `__builtin_memcpy`，big-endian 语义不变）
  3) `laurus_squeeze` 尾部逐字节 for 拷贝    ->  `__builtin_memcpy`

为什么不用正则硬替换：宏是 4 行续行，且 `store64` 在源里出现 6 次，用「锚定原文 + 断言
恰好命中一次」的方式改写，改不到就直接失败（**不许静默跳过**）。

用法：python3 make_ours.py [--check]
  --check 只比对，不写盘；返回 1 表示源里没有预期的三处锚点（说明官方源变了）。
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
OPT = os.path.join(L0, "src", "hash-14", "Laurus", "Implementations",
                   "Optimized_Implementation", "Laurus-512")
SRC = os.path.join(OPT, "laurus_512.c")
DST = os.path.join(HERE, "src", "ours.c")

LOAD_MACRO = """#define load64(y)\t((uint64_t)((y)[0] & 0xFF) << 56) | ((uint64_t)((y)[1] & 0xFF) << 48) | \\
\t\t\t\t\t((uint64_t)((y)[2] & 0xFF) << 40) | ((uint64_t)((y)[3] & 0xFF) << 32) | \\
\t\t\t\t\t((uint64_t)((y)[4] & 0xFF) << 24) | ((uint64_t)((y)[5] & 0xFF) << 16) | \\
\t\t\t\t\t((uint64_t)((y)[6] & 0xFF) << 8) |  ((uint64_t)((y)[7] & 0xFF))
"""

LOAD_NEW = """/* [ours] 逐字节拼装 -> 一次整字读 + 字节序反转（语义等价：原 load64 是 big-endian） */
static inline uint64_t load64(const uint8_t *y)
{
    uint64_t v;
    __builtin_memcpy(&v, y, 8);
    return __builtin_bswap64(v);
}
"""

STORE_MACRO = """#define store64(y, x) { (y)[0] = ((x) >> 56) & 0xFF; (y)[1] = ((x) >> 48) & 0xFF;\\
\t\t\t\t\t    (y)[2] = ((x) >> 40) & 0xFF; (y)[3] = ((x) >> 32) & 0xFF;\\
                        (y)[4] = ((x) >> 24) & 0xFF; (y)[5] = ((x) >> 16) & 0xFF;\\
\t\t\t\t\t    (y)[6] = ((x) >> 8) & 0xFF; (y)[7] = (x) & 0xFF; }
"""

STORE_NEW = """/* [ours] 逐字节写 -> 一次整字写（语义等价：原 store64 是 big-endian） */
static inline void store64(uint8_t *y, uint64_t x)
{
    uint64_t v = __builtin_bswap64(x);
    __builtin_memcpy(y, &v, 8);
}
"""

SQUEEZE_OLD = """    store64(t, state->A[state->pos / 8]);
    for (i = 0; i < outlen; i++)
        out[i] = t[i];
"""

SQUEEZE_NEW = """    store64(t, state->A[state->pos / 8]);
    __builtin_memcpy(out, t, outlen); /* [ours] 逐字节 -> memcpy */
"""

EDITS = [
    ("load64 宏", LOAD_MACRO, LOAD_NEW),
    ("store64 宏", STORE_MACRO, STORE_NEW),
    ("squeeze 尾部逐字节拷贝", SQUEEZE_OLD, SQUEEZE_NEW),
]


def main():
    text = open(SRC, encoding="utf-8", errors="surrogateescape").read()
    ok = True
    for name, old, new in EDITS:
        n = text.count(old)
        print("[anchor] %-24s 命中 %d 次" % (name, n))
        if n != 1:
            print("    !! 期望恰好 1 次，实际 %d 次 —— 官方源可能已变，拒绝改写" % n)
            ok = False
            continue
        text = text.replace(old, new)
    if not ok:
        return 1
    if "--check" in sys.argv:
        print("[check] 三处锚点齐备（未写盘）")
        return 0
    os.makedirs(os.path.dirname(DST), exist_ok=True)
    with open(DST, "w", encoding="utf-8", errors="surrogateescape", newline="\n") as f:
        f.write(text)
    print("[write] %s（%d 字节）" % (DST, os.path.getsize(DST)))
    # 自检：改写后不应再有逐字节宏
    for bad in ("#define load64", "#define store64"):
        if bad in text:
            print("    !! 仍残留 %r" % bad)
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
