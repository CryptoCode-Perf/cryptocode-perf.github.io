#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build512.py —— 构建 Laurus-512 的 base（未改动官方源）与 ours（三处等价改写）。

**配方逐字复刻 `_overnight/l0/fix14.py` 的 `build_opt()`**（不是照抄 laurus/build_ours.py，
后者是 1024 专用版本、对象顺序与链接方式与 fix14 不同）：

  - 编译 flag：OPT_FLAGS = -O3 -march=x86-64 -mavx2 -mtune=native -flto
                -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
  - 每个对象都 `gcc -c -fPIC <OPT_FLAGS> -I <optd> -I <refd> -o <o> <src>`
  - 对象顺序：glue.o（CryptHash_AlgorithmInstance.c）、drng.o、impl.o、shim.o
  - **链接命令是 `gcc -shared -o <so> <objs>`，不带 -flto / -lm**
    （差一个 flag 就出不同字节 —— 这正是 fix14 与 laurus/build_ours.py 的差异所在）
  - impl 用 `-Dlaurus_512=laurus_512__raw` 改名；shim 单独编译（不带 -D，否则自递归）

复现判据钉 `.text` 段（整文件 sha 会被 -flto 的临时对象名搅乱，落 .symtab/.strtab）：
  base 的 `.text` 必须与在册 `build/hash-14/laurus-512/opt.so` 逐字节相同。

用法：python3 build512.py [base|ours|both]
"""
import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
assert os.path.exists(os.path.join(WORK, "ir_text.py")), WORK

SRCROOT = os.path.join(L0, "src", "hash-14", "Laurus", "Implementations")
OPT = os.path.join(SRCROOT, "Optimized_Implementation", "Laurus-512")
REF = os.path.join(SRCROOT, "Reference_Implementation", "Laurus-512")
SHIM = os.path.join(L0, "shims", "l0_f14_laurus_512_len.c")
OPT_C = os.path.join(OPT, "laurus_512.c")
OURS_C = os.path.join(HERE, "src", "ours.c")
OUTDIR = os.path.join(HERE, "out")

# 与 fix14.OPT_FLAGS 逐字相同
OPT_FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
             "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]


def run(cmd, what):
    p = subprocess.run(cmd, text=True, errors="replace", capture_output=True)
    if p.returncode != 0:
        print(p.stdout[-3000:])
        print(p.stderr[-3000:])
        sys.exit("%s 失败，rc=%d" % (what, p.returncode))
    return p


def build(tag, impl_c):
    obj = os.path.join(HERE, "build_" + tag)
    os.makedirs(obj, exist_ok=True)
    os.makedirs(OUTDIR, exist_ok=True)
    out = os.path.join(OUTDIR, "%s_laurus512.so" % tag)

    objs = []
    # 1) 胶水
    o = os.path.join(obj, "CryptHash_AlgorithmInstance.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-I", OPT, "-I", REF, "-o", o,
                                              os.path.join(REF, "CryptHash_AlgorithmInstance.c")],
        tag + ".glue")
    objs.append(o)
    # 2) drng
    o = os.path.join(obj, "drng.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-I", OPT, "-I", REF, "-o", o,
                                              os.path.join(REF, "drng.c")], tag + ".drng")
    objs.append(o)
    # 3) 实现（改名）
    o = os.path.join(obj, "impl.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-Dlaurus_512=laurus_512__raw",
                                              "-I", OPT, "-I", REF, "-o", o, impl_c],
        tag + ".impl")
    objs.append(o)
    # 4) shim（单独编译，不带 -D）
    o = os.path.join(obj, "shim.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-I", OPT, "-o", o, SHIM], tag + ".shim")
    objs.append(o)

    # 链接：与 fix14 逐字相同 —— 不带 -flto / -lm
    run(["gcc", "-shared", "-o", out] + objs, tag + ".link")

    h = hashlib.sha256(open(out, "rb").read()).hexdigest()
    print("%-4s %7d B  sha256 %s" % (tag, os.path.getsize(out), h))
    return out


def text_sha(so):
    tmp = so + ".text.bin"
    run(["objcopy", "-O", "binary", "--only-section=.text", so, tmp], "objcopy")
    h = hashlib.sha256(open(tmp, "rb").read()).hexdigest()
    n = os.path.getsize(tmp)
    os.remove(tmp)
    return n, h


def main():
    which = sys.argv[1] if len(sys.argv) > 1 else "both"
    built = {}
    if which in ("base", "both"):
        built["base"] = build("base", OPT_C)
    if which in ("ours", "both"):
        if not os.path.isfile(OURS_C):
            sys.exit("缺 %s，先跑 make_ours.py" % OURS_C)
        built["ours"] = build("ours", OURS_C)

    print("\n[.text] 段比对（复现判据）")
    reg = os.path.join(L0, "build", "hash-14", "laurus-512", "opt.so")
    rows = []
    if os.path.isfile(reg):
        rows.append(("在册 opt.so", reg))
    for tag in ("base", "ours"):
        if tag in built:
            rows.append((tag, built[tag]))
    shas = {}
    for name, so in rows:
        n, h = text_sha(so)
        shas[name] = h
        print("  %-12s .text %6d B  %s" % (name, n, h))
    if "base" in shas and "在册 opt.so" in shas:
        if shas["base"] != shas["在册 opt.so"]:
            print("  => base .text 与在册 opt.so 不同：配方不可信，停止")
            return 1
        print("  => base .text 与在册 opt.so 相同（配方复现成立）")
    if "ours" in shas and "base" in shas:
        if shas["ours"] == shas["base"]:
            print("  => ours .text 与 base 相同：改写没生效，停止")
            return 1
        print("  => ours .text 与 base 不同（改写已生效）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
