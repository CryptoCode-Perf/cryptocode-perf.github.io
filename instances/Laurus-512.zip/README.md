# Laurus-512

Algorithm: Laurus | Digest bits: 512 | Form: 标量 C

Contents: implementation source/, public header Laurus-512.h, prebuilt Laurus-512.so,
KAT vector KAT_2_12_laurus_512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 934d81f778e0711a191dd3044bf6059a27c6689d5dfa1c9004b581714c8e7158
Speed (cpB, lower is faster): reference 17.90 / official-optimized 5.45 / optimized 5.06
Speedup: GM(S1-S8) 1.08x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
