# MoFang-512

Algorithm: MoFang | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header MoFang-512.h, prebuilt MoFang-512.so,
KAT vector KAT_2_12_MoFang_512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 3b5e5a69703c2758a1f5b1f8a18b823548a3ead3011f9109f727742028b8318a
Speed (cpB, lower is faster): reference 10.96 / official-optimized 7.23 / optimized 2.67
Speedup: GM(S1-S8) 2.81x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
