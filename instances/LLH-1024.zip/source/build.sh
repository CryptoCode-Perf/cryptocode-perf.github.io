#!/usr/bin/env bash
# build.sh -- official ten flags, verbatim.  Run from WSL:
#   wsl.exe -e bash -lc 'cd .../l0/llh && bash build.sh'
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/out"
SCR="$HERE/scratch"
mkdir -p "$OUT" "$SCR"

# ---- official optimised-build flags (ten) : DO NOT ADD ANYTHING ----------
FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

SRC="$HERE/src/llh1024.c"
SO="$OUT/ours_llh1024.so"

rm -f "$SO"
gcc "${FLAGS[@]}" -fPIC -shared -o "$SO" "$SRC" > "$SCR/build.log" 2>&1
echo "gcc rc=0  flags: ${FLAGS[*]}"

# a non-LTO object of the same source, for the static instruction histogram
gcc "${FLAGS[@]}" -fno-lto -c -o "$OUT/ours_llh1024.o" "$SRC" > "$SCR/build_obj.log" 2>&1
echo "obj rc=0"

echo "--- artefacts ---"
ls -l "$SO" "$OUT/ours_llh1024.o"
sha256sum "$SO" "$OUT/ours_llh1024.o"
echo "--- warnings that came from the OFFICIAL reference driver (pre-existing) ---"
cat "$SCR/build.log"
