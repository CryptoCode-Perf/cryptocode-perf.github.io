#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_llh.py -- build our LLH-1024 delivery artefact.

Method (methodology: "read the official driver, replace only the hot kernel"):
  * take the OFFICIAL REFERENCE driver `llh_core.c` (277 lines) verbatim,
  * delete exactly two functions from it  (`llh_round`, `permutation`),
  * drop in OUR pure-AVX2 `llh_round_avx2` + `permutation` at that position,
  * append the OFFICIAL API wrapper's `reverse_low_bits` + `CryptHash` verbatim.

Everything else (SIGMA / RC / load_word / store_word / xor_rate / squeeze_rate /
hash_process_block / hash_init / hash_absorb / hash_final / hash) is byte-for-byte
the official reference text, so `port_diff.txt` is a proof that only the round
function changed.

Also emits `gates/llh_ref_perm.inc`: the official reference permutation with all
top-level identifiers renamed `ref_*`, so G1 can call the reference and our
version inside the SAME translation unit (cross-TU thin wrappers are forbidden
by this project -- they have lied three times).

Outputs
  src/llh1024.c            our delivery source
  gates/llh_ref_perm.inc   renamed official permutation for G1
  port_diff.txt            unified diff  (official+ours) vs (official)
"""

import os
import re
import sys
import difflib

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)                       # .../_overnight/l0
RELD = os.path.join("src", "hash-16", "LLH",
                    "Implementations and Test_Vectors", "LLH_C",
                    "API_CryptHash", "Implementations")
REF_DIR = os.path.join(L0, RELD, "Reference_Implementation", "LLH-1024")
REF = os.path.join(REF_DIR, "llh_core.c")
WRAP = os.path.join(REF_DIR, "CryptHash_AlgorithmInstance.c")
OUT_C = os.path.join(HERE, "src", "llh1024.c")
OUT_INC = os.path.join(HERE, "gates", "llh_ref_perm.inc")
OUT_DIFF = os.path.join(HERE, "port_diff.txt")

# The six LLH_MIX_FAMILY invocations are read straight out of the reference
# source, so the family table can never silently drift.
FAM_RE = re.compile(r"LLH_MIX_FAMILY\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)")

ALLO = "_mm256_set1_epi64x(-1)"


def die(msg):
    sys.stderr.write("gen_llh: FATAL: %s\n" % msg)
    raise SystemExit(1)


def load_text(path):
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def func_span(lines, pat):
    """Return (start, end) 0-based inclusive line indices of a top-level definition."""
    start = None
    for i, ln in enumerate(lines):
        if re.match(pat, ln):
            start = i
            break
    if start is None:
        die("definition not found: %s" % pat)
    depth = 0
    seen = False
    for j in range(start, len(lines)):
        for ch in lines[j]:
            if ch == "{":
                depth += 1
                seen = True
            elif ch == "}":
                depth -= 1
                if seen and depth == 0:
                    return start, j
    die("unbalanced braces for %s" % pat)


def splice_replace(lines, pat, new_lines):
    """Drop the whole top-level definition matching pat, splice new_lines in."""
    s, e = func_span(lines, pat)
    return lines[:s] + list(new_lines) + lines[e + 1:]


# ---------------------------------------------------------------------------
# Driver-level replacements.
#
# The reference driver is correct but pays for two things the official
# optimised implementation does not: it assembles every 128-bit rate word out
# of four u32 halves, and it absorbs ONE BYTE at a time.  Both are pure
# overhead on x86-64 and are replaced below; the feed-forward structure and the
# block sequence handed to the permutation are unchanged, so the digest is
# bit-identical (see llh/RESULT.md and the G2/G3/G4 gates).
# ---------------------------------------------------------------------------
MY_LOAD_WORD = [
    "/* Replaced: the reference builds the word from four little-endian u32",
    "   halves.  On x86-64 (little endian) one unaligned 16-byte load is",
    "   bit-identical and costs a single instruction. */",
    "static inline word_t load_word(const uint8_t *p)",
    "{",
    "    word_t w;",
    "",
    "    memcpy(&w, p, sizeof(w));",
    "    return w;",
    "}",
]

MY_STORE_WORD = [
    "/* Replaced: mirror image of load_word. */",
    "static inline void store_word(uint8_t *p, word_t w)",
    "{",
    "    memcpy(p, &w, sizeof(w));",
    "}",
]

MY_HASH_ABSORB = [
    "/* Replaced: the reference absorbs one byte at a time and only ever calls",
    "   hash_process_block() from ctx->buf.  Once the buffer is empty a whole",
    "   block can be handed to the permutation straight out of the caller",
    "   buffer: hash_process_block() only READS the block it is given (see",
    "   xor_rate), so the sequence of blocks fed to the permutation and the",
    "   final buffer state are bit-for-bit what the reference byte loop does. */",
    "void hash_absorb(HashCtx *ctx, const uint8_t *data, size_t len)",
    "{",
    "    size_t i = 0;",
    "",
    "    if (ctx->buf_len != 0) {",
    "        while (i < len && ctx->buf_len != RATE_BYTES) {",
    "            ctx->buf[ctx->buf_len++] = data[i++];",
    "        }",
    "        if (ctx->buf_len == RATE_BYTES) {",
    "            llh_absorb_blocks_avx2(ctx, ctx->buf, 1);",
    "            ctx->buf_len = 0;",
    "        }",
    "    }",
    "    if (ctx->buf_len == 0 && len - i >= RATE_BYTES) {",
    "        size_t nb = (len - i) / RATE_BYTES;",
    "",
    "        llh_absorb_blocks_avx2(ctx, data + i, nb);",
    "        i += nb * RATE_BYTES;",
    "    }",
    "    while (i < len) {",
    "        ctx->buf[ctx->buf_len++] = data[i++];",
    "    }",
    "}",
]


def tvar(i):
    """Which pair-ymm holds T[i], and in which 128-bit lane."""
    if i % 4 < 2:
        return "t01_%d" % (i // 4), i % 2
    return "t23_%d" % (i // 4), i % 4 - 2


def imm_of(src):
    return src[0] | (src[1] << 2) | (src[2] << 4) | (src[3] << 6)


def rot_plan(c0, c1):
    """qword reorder + shift counts for a 2-lane 128-bit rotate-by-(c0,c1).

    v = [loA, hiA, loB, hiB]  (qwords 0..3)
    out = (X << CL) | (Y >> CR)   with per-qword variable shifts.
    """
    xs, ys, cl, cr = [], [], [], []
    for c, base in ((c0, 0), (c1, 2)):
        if c < 64:
            xs += [base + 0, base + 1]
            ys += [base + 1, base + 0]
            left, right = c, 64 - c
        else:
            xs += [base + 1, base + 0]
            ys += [base + 0, base + 1]
            left, right = c - 64, 128 - c
        cl += [left, left]
        cr += [right, right]
    return xs, ys, cl, cr


def main():
    ref_txt = load_text(REF)
    wrap_txt = load_text(WRAP)
    ref = ref_txt.split("\n")
    wrap = wrap_txt.split("\n")

    # ---------------------------------------------------------------- cut points
    s_round, e_round = func_span(ref, r"static\s+void\s+llh_round\s*\(")
    s_perm, e_perm = func_span(ref, r"static\s+void\s+permutation\s*\(")
    if not (e_round < s_perm):
        die("llh_round must precede permutation")
    if "llh_round" in "\n".join(ref[e_perm + 1:]):
        die("tail still references llh_round")

    setup = ref[:s_round]
    tail = ref[e_perm + 1:]

    # ---------------------------------------------------------------- tables
    m = re.search(r"SIGMA\[ROWS\]\s*=\s*\{(.*?)\};", ref_txt, re.S)
    if not m:
        die("SIGMA not found")
    SIGMA = [int(x) for x in re.findall(r"\d+", m.group(1))]
    if len(SIGMA) != 24:
        die("SIGMA len %d" % len(SIGMA))

    m = re.search(r"#define LLH_W128_RC_LIST\(X\)(.*?)\n\s*\n", ref_txt, re.S)
    if not m:
        die("RC list not found")
    RC = re.findall(r"X\(\s*([0-9A-Fa-f]+)\s*,\s*([0-9A-Fa-f]+)\s*\)", m.group(1))
    if len(RC) != 40:
        die("RC len %d" % len(RC))

    FAM = [tuple(int(x) for x in t) for t in FAM_RE.findall(ref_txt)]
    if len(FAM) != 6:
        die("expected 6 mix families, got %d" % len(FAM))

    # NOT pattern straight from the reference round body
    nround = "\n".join(ref[s_round:e_round + 1])
    notmap = {}
    for idx, body in re.findall(r"T\[(\d+)\]\s*=\s*(WORD_NOT\()?", nround):
        notmap[int(idx)] = bool(body)
    if len(notmap) != 24:
        die("T not-pattern incomplete (%d)" % len(notmap))
    not01 = [notmap[4 * k] for k in range(6)]
    not23 = [notmap[4 * k + 2] for k in range(6)]
    for k in range(6):
        if notmap[4 * k] != notmap[4 * k + 1] or notmap[4 * k + 2] != notmap[4 * k + 3]:
            die("NOT not lane-uniform for k=%d" % k)

    # lane sanity: every family must have a,c in lane0 and b,d in lane1
    for (dst, a, b, c, d) in FAM:
        for idx, want in ((a, 0), (b, 1), (c, 0), (d, 1)):
            _, lane = tvar(idx)
            if lane != want:
                die("family dst=%d index %d in lane %d, want %d" % (dst, idx, lane, want))

    plans = [rot_plan(SIGMA[2 * p], SIGMA[2 * p + 1]) for p in range(12)]

    # ---------------------------------------------------------------- round body
    L = []
    L.append("static inline __m256i llh_xor3(__m256i a, __m256i b, __m256i c)")
    L.append("{")
    L.append("    return _mm256_xor_si256(_mm256_xor_si256(a, b), c);")
    L.append("}")
    L.append("")
    L.append("/*")
    L.append(" * One LLH round, reference equation exactly.  Reference (llh_core.c):")
    L.append(" *   T[i] = op_i( state[i] ^ state[(i+8)%24] ^ (state[(i+4)%24] & state[(i+12)%24]) )")
    L.append(" * with op_i = WORD_NOT() for i in 0..7 and 12..19, identity otherwise.")
    L.append(" * state_pairs[k] holds rows 2k (lane 0) and 2k+1 (lane 1).")
    L.append(" */")
    L.append("static inline void llh_round_avx2(__m256i *sp, int r)")
    L.append("{")
    decl = ["t01_%d" % k for k in range(6)] + ["t23_%d" % k for k in range(6)]
    decl += ["fx", "fy", "fu", "fw", "tv", "ta", "tb"]
    for d in decl:
        L.append("    __m256i %s;" % d)
    L.append("")
    L.append("    /* ---- T layer : 12 pair-words, no cross-lane shuffle ---- */")
    for k in range(6):
        L.append("    %s = _mm256_and_si256(sp[%d], sp[%d]);"
                 % ("t01_%d" % k, (2 * k + 2) % 12, (2 * k + 6) % 12))
        L.append("    t01_%d = llh_xor3(sp[%d], sp[%d], t01_%d);"
                 % (k, 2 * k, (2 * k + 4) % 12, k))
        if not01[k]:
            L.append("    t01_%d = _mm256_xor_si256(t01_%d, %s);" % (k, k, ALLO))
        L.append("    %s = _mm256_and_si256(sp[%d], sp[%d]);"
                 % ("t23_%d" % k, (2 * k + 3) % 12, (2 * k + 7) % 12))
        L.append("    t23_%d = llh_xor3(sp[%d], sp[%d], t23_%d);"
                 % (k, (2 * k + 1) % 12, (2 * k + 5) % 12, k))
        if not23[k]:
            L.append("    t23_%d = _mm256_xor_si256(t23_%d, %s);" % (k, k, ALLO))
    L.append("")
    L.append("    /* ---- MDS layer : 6 families, 2 gathers + 1 swap each ---- */")
    L.append("    /* out_lo = [Tb^Tc^Td, Ta^Tc^Td] ; out_hi = [Ta^Tb^Td, Ta^Tb^Tc]")
    L.append("       with w = swap(x^y)  =>  out_lo = y^w, out_hi = x^w        */")
    for mi, (dst, a, b, c, d) in enumerate(FAM):
        xa, _ = tvar(a)
        xb, _ = tvar(b)
        yc, _ = tvar(c)
        yd, _ = tvar(d)
        L.append("    fx = _mm256_permute2x128_si256(%s, %s, 0x30);" % (xa, xb))
        L.append("    fy = _mm256_permute2x128_si256(%s, %s, 0x30);" % (yc, yd))
        L.append("    fu = _mm256_xor_si256(fx, fy);")
        L.append("    fw = _mm256_permute2x128_si256(fu, fu, 0x01);")
        for p, src in ((2 * mi, "fy"), (2 * mi + 1, "fx")):
            xs, ys, cl, cr = plans[p]
            lx, ly = imm_of(xs), imm_of(ys)
            L.append("    tv = _mm256_xor_si256(%s, fw);" % src)
            if lx == 0xE4:
                L.append("    ta = tv;")
            else:
                L.append("    ta = _mm256_permute4x64_epi64(tv, 0x%02X);" % lx)
            if ly == 0xE4:
                L.append("    tb = tv;")
            else:
                L.append("    tb = _mm256_permute4x64_epi64(tv, 0x%02X);" % ly)
            L.append("    sp[%d] = _mm256_or_si256(_mm256_sllv_epi64(ta, "
                     "_mm256_loadu_si256((const __m256i *)LLH_CL[%d])),"
                     " _mm256_srlv_epi64(tb, "
                     "_mm256_loadu_si256((const __m256i *)LLH_CR[%d])));" % (p, p, p))
    L.append("")
    L.append("    /* ---- state[23] ^= RC[round]  (row 23 = pair 11, high lane) ---- */")
    L.append("    sp[11] = _mm256_xor_si256(sp[11],")
    L.append("        _mm256_loadu_si256((const __m256i *)&LLH_RC32[r][0]));")
    L.append("}")
    L.append("")
    L.append("static void llh_permute_avx2(word_t *row, int nrounds)")
    L.append("{")
    L.append("    __m256i sp[12];")
    L.append("    int k, r;")
    L.append("")
    L.append("    for (k = 0; k < 12; k++) {")
    L.append("        sp[k] = _mm256_loadu_si256((const __m256i *)&row[2 * k]);")
    L.append("    }")
    L.append("    for (r = 0; r < nrounds; r++) {")
    L.append("        llh_round_avx2(sp, r);")
    L.append("    }")
    L.append("    for (k = 0; k < 12; k++) {")
    L.append("        _mm256_storeu_si256((__m256i *)&row[2 * k], sp[k]);")
    L.append("    }")
    L.append("}")
    L.append("")
    L.append("/*")
    L.append(" * Absorb nblocks complete blocks with the state held in ymm registers for")
    L.append(" * the whole run.  Equivalent to nblocks calls of")
    L.append(" *   hash_process_block(ctx, data + RATE_BYTES * b)")
    L.append(" * -- save the 8 capacity pair-words (rows 8..23), 40 rounds, feed-forward")
    L.append(" * them back, then xor the 4 rate pair-words (rows 0..7) in from the")
    L.append(" * message.  Removes the per-block state load/store and the 384-byte")
    L.append(" * `State prev` copy the reference performs inside hash_process_block.")
    L.append(" */")
    L.append("static void llh_absorb_blocks_avx2(HashCtx *ctx, const uint8_t *data,")
    L.append("                                   size_t nblocks)")
    L.append("{")
    L.append("    __m256i sp[12];")
    L.append("    __m256i cap[8];")
    L.append("    int k, r;")
    L.append("    size_t b;")
    L.append("")
    L.append("    for (k = 0; k < 12; k++) {")
    L.append("        sp[k] = _mm256_loadu_si256((const __m256i *)&ctx->state.row[2 * k]);")
    L.append("    }")
    L.append("    for (b = 0; b < nblocks; b++) {")
    L.append("        const uint8_t *blk = data + b * RATE_BYTES;")
    L.append("")
    L.append("        for (k = 0; k < 8; k++) {")
    L.append("            cap[k] = sp[4 + k];")
    L.append("        }")
    L.append("        for (r = 0; r < NR_DEFAULT; r++) {")
    L.append("            llh_round_avx2(sp, r);")
    L.append("        }")
    L.append("        for (k = 0; k < 8; k++) {")
    L.append("            sp[4 + k] = _mm256_xor_si256(sp[4 + k], cap[k]);")
    L.append("        }")
    L.append("        for (k = 0; k < 4; k++) {")
    L.append("            sp[k] = _mm256_xor_si256(sp[k],")
    L.append("                _mm256_loadu_si256((const __m256i *)(blk + 32 * k)));")
    L.append("        }")
    L.append("    }")
    L.append("    for (k = 0; k < 12; k++) {")
    L.append("        _mm256_storeu_si256((__m256i *)&ctx->state.row[2 * k], sp[k]);")
    L.append("    }")
    L.append("}")
    L.append("")
    L.append("static void permutation(State *s)")
    L.append("{")
    L.append("    llh_permute_avx2(s->row, NR_DEFAULT);")
    L.append("}")
    L.append("")
    L.append("#ifdef LLH_TEST_HOOKS")
    L.append("/* G1 only; the delivery build never defines LLH_TEST_HOOKS. */")
    L.append("void llh_hook_perm(void *rows24, int nrounds)")
    L.append("{")
    L.append("    llh_permute_avx2((word_t *)rows24, nrounds);")
    L.append("}")
    L.append("void llh_hook_round(void *rows24, int r)")
    L.append("{")
    L.append("    __m256i sp[12];")
    L.append("    word_t *row = (word_t *)rows24;")
    L.append("    int k;")
    L.append("    for (k = 0; k < 12; k++) {")
    L.append("        sp[k] = _mm256_loadu_si256((const __m256i *)&row[2 * k]);")
    L.append("    }")
    L.append("    llh_round_avx2(sp, r);")
    L.append("    for (k = 0; k < 12; k++) {")
    L.append("        _mm256_storeu_si256((__m256i *)&row[2 * k], sp[k]);")
    L.append("    }")
    L.append("}")
    L.append("#endif")
    kernel = L

    # ---------------------------------------------------------------- const tables
    T = []
    T.append("/* Per-pair 128-bit rotate (SIGMA[2p], SIGMA[2p+1]) planned at generation")
    T.append("   time: out = (X << CL) | (Y >> CR) with qword-reorder immediates baked")
    T.append("   into X/Y, so no vpblendvb / no vpcmpgtq is needed at run time. */")
    T.append("static const uint64_t LLH_CL[12][4] = {")
    for p in range(12):
        _, _, cl, _ = plans[p]
        T.append("    { %s },   /* pair %2d  counts (%d,%d) */"
                 % (", ".join("%dULL" % v for v in cl), p, SIGMA[2 * p], SIGMA[2 * p + 1]))
    T.append("};")
    T.append("static const uint64_t LLH_CR[12][4] = {")
    for p in range(12):
        _, _, _, cr = plans[p]
        T.append("    { %s }," % ", ".join("%dULL" % v for v in cr))
    T.append("};")
    T.append("")
    T.append("/* 32-byte pool: [lane0 = 0, lane1 = RC[round]] so state[23] ^= rc is one")
    T.append("   memory-operand vpxor instead of inserti128 + xor. */")
    T.append("static const uint64_t LLH_RC32[40][4] = {")
    for r, (hi, lo) in enumerate(RC):
        T.append("    { 0ULL, 0ULL, 0x%sULL, 0x%sULL }," % (lo.lower(), hi.lower()))
    T.append("};")
    consts = T

    # ---------------------------------------------------------------- wrapper part
    ws, we = func_span(wrap, r"static\s+unsigned\s+char\s+reverse_low_bits\s*\(")
    cs, ce = func_span(wrap, r"int\s+CryptHash\s*\(")
    wrap_part = wrap[ws:we + 1] + [""] + wrap[cs:ce + 1] + [""]

    header = [
        "/*",
        " * llh1024.c -- GENERATED by llh/gen_llh.py.  DO NOT EDIT BY HAND.",
        " *",
        " * = official reference LLH-1024 driver (llh_core.c, 277 lines), with",
        " *   (a) the round function + permutation replaced by a pure-AVX2 kernel,",
        " *   (b) load_word/store_word replaced by unaligned 128-bit load/store,",
        " *   (c) hash_absorb replaced by a whole-block fast path,",
        " * + official API wrapper (CryptHash_AlgorithmInstance.c) verbatim.",
        " *",
        " * Build flags are the official ten:",
        " *   -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer",
        " *   -std=c99 -Wpedantic -Wall -Wextra     (+ -fPIC -shared)",
        " * No -maes/-mvaes/-march=native, no #pragma GCC target: pure AVX2 only.",
        " */",
        "#include <limits.h>",
        "#include <stddef.h>",
        "#include <stdint.h>",
        "#include <string.h>",
        "#include <immintrin.h>",
        "",
        "#define DIGEST_BIT_LENGTH 1024",
        "#define LLH_CRYPT_HASH_SUCCESS 0",
        "#define LLH_CRYPT_HASH_UNSUPPORTED_DIGEST -1",
        "#define LLH_CRYPT_HASH_INVALID_ARG -2",
        "#define HIGH_N_BIT_MASK(N) ((unsigned char)((~0U) << (8 - (N))))",
        "",
        "#define W 128",
        "",
    ]

    # ---------------------------------------------------------------- driver swaps
    setup = splice_replace(setup, "static inline word_t load_word", MY_LOAD_WORD)
    setup = splice_replace(setup, "static inline void store_word", MY_STORE_WORD)
    tail = splice_replace(tail, "void hash_absorb", MY_HASH_ABSORB)

    out = header + setup + consts + [""] + kernel + tail + wrap_part
    text = "\n".join(out)

    if "llh_round(" in text.replace("llh_round_avx2", "").replace("ref_llh_round", ""):
        die("stray llh_round reference in output")
    if "aesenc" in text or "GCC target" in text.split("*/")[-1]:
        die("forbidden construct in output")

    # ---------------------------------------------------------------- ref .inc
    inc = []
    inc.append("/* GENERATED by llh/gen_llh.py: official reference permutation with")
    inc.append("   every top-level identifier renamed ref_*, for SAME-TU G1 testing. */")
    inc.append("#define REF_W 128")
    inc.append("#define REF_ROWS 24")
    inc.append("#define REF_RATE_ROWS 8")
    inc.append("typedef __uint128_t ref_word_t;")
    inc.append("typedef struct { ref_word_t row[REF_ROWS]; } ref_State;")
    inc.append("static const int ref_SIGMA[REF_ROWS] = {")
    for i in range(0, 24, 4):
        inc.append("    " + ", ".join(str(v) for v in SIGMA[i:i + 4])
                   + ("," if i + 4 < 24 else ""))
    inc.append("};")
    inc.append("static const ref_word_t ref_RC[40] = {")
    for hi, lo in RC:
        inc.append("    (((__uint128_t)0x%sULL << 64) | 0x%sULL)," % (hi, lo))
    inc.append("};")
    inc.append("static inline ref_word_t ref_llh_rotl(ref_word_t x, unsigned int n)")
    inc.append("{")
    inc.append("    return (ref_word_t)((x << n) | (x >> (128u - n)));")
    inc.append("}")
    inc.append("#define REF_WORD_NOT(a) (~(a))")
    inc.append("#define REF_WORD_XOR(a, b) ((a) ^ (b))")
    inc.append("#define REF_WORD_AND(a, b) ((a) & (b))")
    inc.append("#define REF_MIX_FAMILY(dst, a, b, c, d) do {                        \\")
    inc.append("    state[(dst) + 0] = REF_WORD_XOR(T[(b)], REF_WORD_XOR(T[(c)], T[(d)])); \\")
    inc.append("    state[(dst) + 1] = REF_WORD_XOR(T[(a)], REF_WORD_XOR(T[(c)], T[(d)])); \\")
    inc.append("    state[(dst) + 2] = REF_WORD_XOR(T[(a)], REF_WORD_XOR(T[(b)], T[(d)])); \\")
    inc.append("    state[(dst) + 3] = REF_WORD_XOR(T[(a)], REF_WORD_XOR(T[(b)], T[(c)])); \\")
    inc.append("} while (0)")
    body = "\n".join(ref[s_round:e_round + 1])
    for pat, rep in ((r"\bWORD_XOR\b", "REF_WORD_XOR"),
                     (r"\bWORD_AND\b", "REF_WORD_AND"),
                     (r"\bWORD_NOT\b", "REF_WORD_NOT"),
                     (r"\bLLH_MIX_FAMILY\b", "REF_MIX_FAMILY"),
                     (r"\bllh_rotl\b", "ref_llh_rotl"),
                     (r"\bllh_round\b", "ref_llh_round"),
                     (r"\bSIGMA\b", "ref_SIGMA"),
                     (r"\bROWS\b", "REF_ROWS"),
                     (r"\bword_t\b", "ref_word_t"),
                     (r"\bW\b", "REF_W")):
        body = re.sub(pat, rep, body)
    inc.append("static void ref_llh_round(ref_word_t *state, ref_word_t rc)")
    brace = body.index("{")
    inc.append(body[brace:])
    inc.append("static void ref_permutation(ref_State *s)")
    inc.append("{")
    inc.append("    for (int round = 0; round < 40; round++) {")
    inc.append("        ref_llh_round(s->row, ref_RC[round]);")
    inc.append("    }")
    inc.append("}")
    inc.append("")
    inc_text = "\n".join(inc)

    # ---------------------------------------------------------------- write
    for d in (os.path.dirname(OUT_C), os.path.dirname(OUT_INC)):
        if not os.path.isdir(d):
            os.makedirs(d)
    with open(OUT_C, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    with open(OUT_INC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(inc_text)

    # ---------------------------------------------------------------- diff proof
    orig = ref_txt.split("\n")
    mine = text.split("\n")
    diff = list(difflib.unified_diff(orig, mine, "official/llh_core.c",
                                     "ours/generated llh1024.c", lineterm="", n=1))
    with open(OUT_DIFF, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(diff) + "\n")
    plus = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    minus = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))

    print("wrote %s" % OUT_C)
    print("wrote %s" % OUT_INC)
    print("wrote %s" % OUT_DIFF)
    print("port_diff: +%d/-%d lines" % (plus, minus))
    print("cut: llh_round lines %d-%d, permutation lines %d-%d (1-based)"
          % (s_round + 1, e_round + 1, s_perm + 1, e_perm + 1))
    print("SIGMA[0..3]=%s  RC[0]=(%s,%s)" % (SIGMA[:4], RC[0][0], RC[0][1]))
    print("families=%s" % (FAM,))
    print("not01=%s not23=%s" % (not01, not23))
    rot_ops = 0
    for p in range(12):
        xs, ys, _, _ = plans[p]
        rot_ops += 3 + (0 if imm_of(xs) == 0xE4 else 1) + (0 if imm_of(ys) == 0xE4 else 1)
    p5 = 6 * 3 + rot_ops - 12 * 3
    print("round budget: T=%d  mix=%d  rot=%d  rc=1  total=%d  port5=%d"
          % (44, 36, rot_ops, 44 + 36 + rot_ops + 1, p5))


if __name__ == "__main__":
    main()
