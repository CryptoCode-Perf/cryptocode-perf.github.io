# LLH-1024

Algorithm: LLH | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header LLH-1024.h, prebuilt LLH-1024.so,
KAT vector KAT_2_12_LLH-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 559aefde90f22d29bf4c50dd5fcb15d3dccb3678e3dfb510ad949587ab08b544
Speed (cpB, lower is faster): reference 23.68 / official-optimized 11.55 / optimized 9.50
Speedup: GM(S1-S8) 1.19x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
