/*
 * Litchi-1024 -- our implementation.
 *
 * The delivered object must be bit-exact with the official
 * Reference_Implementation (Litchi-1024), which is what kat_gate /
 * delivery_gate compare against, and whose API takes the message length in
 * BITS.  Structure, parameters and semantics are transcribed from
 *
 *   .../Reference_Implementation/Litchi-1024/litchi_1024.c
 *
 * with two deliberate changes, both justified in MODEL.md / RESULT.md:
 *
 *  (1) The permutation keeps the live set per 5-lane column instead of
 *      materialising all 25 chi temporaries at once.  The official
 *      Optimized_Implementation does the latter and GCC then spills: its
 *      round body is 350 instructions of which 155 are `mov` (56 of those
 *      stack traffic).  See MODEL.md section 4.
 *  (2) load64/store64 use a byte swap on an unaligned word load instead of
 *      the official per-byte shift/or assembly (bit-identical result).
 */

#include <stdint.h>
#include <string.h>

#define LC_NROUNDS 16

/* round constants -- Reference_Implementation/Litchi-1024/litchi_1024.c:27-45 */
static const uint64_t LC_RC[LC_NROUNDS] = {
    0xb7e151628aed2a6aULL, 0xaf82a3cd15dad4d7ULL,
    0x9f4546922bb529adULL, 0xfeca8c2c576ad359ULL,
    0x3dd51950aed526b1ULL, 0x7baa32a15daa4d62ULL,
    0xf7546542bb549ac4ULL, 0x2ee8cb8d76a9b58bULL,
    0x5dd1971aed536b16ULL, 0xbba32e35daa6d62cULL,
    0xb7065d63b54d2c5bULL, 0xae4cbbcf6a9ad8b5ULL,
    0x9cd97696d5353169ULL, 0xf9f2ec25aa6ae2d1ULL,
    0x33a5d94354d545a1ULL, 0x674bb286a9aa8b42ULL
};

/* ------------------------------------------------------------------------ */
/* 64-bit rotations                                                          */
/*                                                                           */
/* A one-bit-at-a-time C rotation compiles to `mov src,dst; rol $o,dst`, i.e. */
/* two instructions, because the x86 rotate is a two-operand in-place         */
/* instruction.  The 25 rol + 25 ror of one round therefore cost 50 extra     */
/* register copies, and GCC's register allocator adds another ~65 moves on    */
/* top when it runs out of registers -- the official Optimized_Implementation */
/* round body is 350 instructions of which 155 are `mov`.                     */
/*                                                                           */
/* BMI2's rorx is the three-operand form (dst can differ from src), so the    */
/* copy disappears: one rorx per rotation instead of mov+ror.  Measured: the  */
/* round body drops from 350 to 310 instructions, mov from 155 to 115.        */
/*                                                                           */
/* BMI2 is reached through inline assembly rather than a compiler flag: the   */
/* command line must stay exactly the official ten flags (and -mbmi2 is not   */
/* among them).  `rorx` exists on every x86-64 part that has AVX2 -- Haswell   */
/* (2013) and Excavator (2015) introduced both -- and the ten flags require   */
/* AVX2, so any machine able to run this object at all can run rorx.  The     */
/* residual risk is documented in RESULT.md, and `-DLC_NO_BMI2` rebuilds an   */
/* equivalent pure-C object for comparison.                                   */
/* ------------------------------------------------------------------------ */
#ifdef LC_NO_BMI2
#define LC_ROL(a, o) (((a) << (o)) ^ ((a) >> (64 - (o))))
#define LC_ROR(a, o) (((a) >> (o)) ^ ((a) << (64 - (o))))
#else
static inline uint64_t lc_rorx(uint64_t x, int n)
{
    uint64_t r;
    __asm__("rorx %2, %1, %0" : "=r"(r) : "r"(x), "i"(n));
    return r;
}
#define LC_ROL(a, o) lc_rorx((a), 64 - (int)(o))
#define LC_ROR(a, o) lc_rorx((a), (int)(o))
#endif


/* ------------------------------------------------------------------------ */
/* big-endian 64-bit load / store                                            */
/*                                                                           */
/* The official load64/store64 macros (Reference_Implementation/...c:11-23)  */
/* assemble the word one byte at a time; gcc expands that to roughly eight   */
/* shift/or instructions per word.  An unaligned word load plus a byte swap   */
/* computes exactly the same value.                                           */
/* ------------------------------------------------------------------------ */
static inline uint64_t lc_ld64(const unsigned char *p)
{
    uint64_t v;
    memcpy(&v, p, 8);
    return __builtin_bswap64(v);
}

static inline void lc_st64(unsigned char *p, uint64_t v)
{
    v = __builtin_bswap64(v);
    memcpy(p, &v, 8);
}

/* ------------------------------------------------------------------------ */
/* the F1600 permutation                                                     */
/*                                                                           */
/* Layout: the 25 lanes live in one 25-element uint64_t array.  Lane number  */
/* (5*k + j) belongs to chi column j, position k of that column.             */
/*                                                                           */
/* chi is local to a column j:  it reads in[j], in[5+j], in[10+j], in[15+j], */
/* in[20+j] and produces the five values a4,a3,a2,a1,a0, which are stored    */
/* to t[j], t[5+j], t[10+j], t[15+j], t[20+j].                               */
/*                                                                           */
/* theta (with pi folded into the write-back address, exactly as the official */
/* Optimized_Implementation does) then reads one whole row t[5i..5i+4].      */
/*                                                                           */
/* The point of splitting the round into these two passes is that each pass   */
/* needs at most ten live values, so gcc does not have to spill.             */
/* ------------------------------------------------------------------------ */

#define LC_CHI(j, in, t)                                                     \
    do {                                                                     \
        const uint64_t b0 = (in)[(j)], b1 = (in)[5 + (j)];                   \
        const uint64_t b2 = (in)[10 + (j)], b3 = (in)[15 + (j)];             \
        const uint64_t b4 = (in)[20 + (j)];                                  \
        const uint64_t a4 = (b4 & b3) ^ b0;                                  \
        const uint64_t a3 = (b3 & b2) ^ b4;                                  \
        const uint64_t a2 = (b2 & b1) ^ b3;                                  \
        const uint64_t a1 = (a4 & b1) ^ b2;                                  \
        const uint64_t a0 = (a4 & a3) ^ b1;                                  \
        (t)[(j)] = a0;                                                       \
        (t)[5 + (j)] = a1;                                                   \
        (t)[10 + (j)] = a2;                                                  \
        (t)[15 + (j)] = a3;                                                  \
        (t)[20 + (j)] = a4;                                                  \
    } while (0)

/* LC_THETA(i, T0..T4, D0..D4, t, out)
   T0..T4 = Reference_Implementation theta[i][0..4]  (litchi_1024.c:48-54)
   D0..D4 = destination lane of theta row i, lane 0..4; identical to the
            addresses written by Optimized_Implementation/litchi_1024.c:104-140
            (pi folded into the store address). */
#define LC_THETA(i, T0, T1, T2, T3, T4, D0, D1, D2, D3, D4, t, out)          \
    do {                                                                     \
        const uint64_t a0 = (t)[5 * (i) + 0], a1 = (t)[5 * (i) + 1];         \
        const uint64_t a2 = (t)[5 * (i) + 2], a3 = (t)[5 * (i) + 3];         \
        const uint64_t a4 = (t)[5 * (i) + 4];                                \
        const uint64_t P = a0 ^ a1 ^ a2 ^ a3 ^ a4;                           \
        const uint64_t Q = LC_ROL(a0, T0) ^ LC_ROL(a1, T1) ^ LC_ROL(a2, T2)  \
                         ^ LC_ROL(a3, T3) ^ LC_ROL(a4, T4);                  \
        (out)[D0] = a0 ^ LC_ROR(P, T0) ^ Q;                                  \
        (out)[D1] = a1 ^ LC_ROR(P, T1) ^ Q;                                  \
        (out)[D2] = a2 ^ LC_ROR(P, T2) ^ Q;                                  \
        (out)[D3] = a3 ^ LC_ROR(P, T3) ^ Q;                                  \
        (out)[D4] = a4 ^ LC_ROR(P, T4) ^ Q;                                  \
    } while (0)

static void lc_perm_rounds(uint64_t *A, int nrounds)
{
    uint64_t B[25];
    int r;

    for (r = 0; r < nrounds; r++) {
        A[0] ^= LC_RC[r];                     /* iota */

        LC_CHI(0, A, B);                      /* chi, per column */
        LC_CHI(1, A, B);
        LC_CHI(2, A, B);
        LC_CHI(3, A, B);
        LC_CHI(4, A, B);

        LC_THETA(0, 31, 1, 4, 21, 22,  0, 23, 16, 14,  7, B, A);
        LC_THETA(1, 19, 12, 15, 34, 13, 21, 19, 12,  5,  3, B, A);
        LC_THETA(2, 28, 35, 58,  9, 23, 17, 10,  8,  1, 24, B, A);
        LC_THETA(3, 55, 18,  5, 27, 44, 13,  6,  4, 22, 15, B, A);
        LC_THETA(4, 14, 43, 53, 20, 25,  9,  2, 20, 18, 11, B, A);
    }
}

static void lc_perm(uint64_t *A)
{
    lc_perm_rounds(A, LC_NROUNDS);
}

/* ------------------------------------------------------------------------ */
/* the sponge                                                                */
/*                                                                           */
/* Transcribed from Reference_Implementation/Litchi-1024/litchi_1024.c:117- */
/* 194, in BITS, with the block absorb written the way the official          */
/* Optimized_Implementation does it (the capacity half of the state is       */
/* carried in A directly, so no 17-word copy per block is needed).           */
/* ------------------------------------------------------------------------ */

static void lc_litchi(unsigned char *out, uint64_t outlen,
                      const unsigned char *in, uint64_t inlen,
                      uint64_t c, uint64_t fid)
{
    unsigned char tmp[200];
    uint64_t A[25];
    uint64_t M[25], S[25];
    uint64_t i, j, r = 1600 - c;
    uint64_t block = inlen / r;
    uint64_t res = inlen - block * r;
    uint64_t pos;
    const uint64_t rb = r / 64;          /* rate in 64-bit words */

    memset(tmp, 0, sizeof tmp);
    memset(A, 0, sizeof A);
    memset(S, 0, sizeof S);

    S[24] = (fid << 63) + c;
    A[24] = S[24];

    for (i = 0; i < block; i++) {
        for (j = 0; j < rb; j++)
            A[j] ^= lc_ld64(in + 8 * j);
        for (j = 0; j < 25 - rb; j++)
            S[j] = A[rb + j];            /* snapshot capacity half */
        lc_perm(A);
        for (j = 0; j < 25 - rb; j++)
            A[rb + j] ^= S[j];           /* capacity feed-forward */
        in += r / 8;
    }

    /* The reference keeps the post-absorb state in S; here it was carried in A
       (BITS: the rate half is the permuted rate, the capacity half has already
       been fed forward).  Copy it back so the squeeze below is a literal
       transcription of Reference_Implementation/litchi_1024.c:158-193. */
    memcpy(S, A, sizeof S);

    for (j = 0; j < res / 64; j++)
        M[j] = lc_ld64(in + 8 * j);
    in += (res / 64) * 8;
    if (res % 64) {
        pos = res % 64;
        memcpy(tmp, in, (size_t)(pos / 8));
        if (pos % 8) {
            tmp[pos / 8] = (unsigned char)(in[pos / 8] &
                                           (unsigned char)(0xFFu << (8 - (pos % 8))));
            tmp[pos / 8] |= (unsigned char)(1u << (7 - (pos % 8)));
        } else {
            tmp[pos / 8] = 0x80;
        }
        M[j++] = lc_ld64(tmp);
    } else {
        M[j++] = 0x8000000000000000ULL;
    }
    for (; j < rb; j++)
        M[j] = 0;

    for (i = 0; i < outlen / c; i++) {
        S[24] ^= i + 1;
        for (j = 0; j < rb; j++)
            A[j] = M[j] ^ S[j];
        for (; j < 25; j++)
            A[j] = S[j];
        lc_perm(A);
        for (j = rb; j < 25; j++)
            A[j] ^= S[j];
        for (j = 0; j < c / 64; j++)
            lc_st64(out + 8 * j, A[j + rb]);
        out += c / 8;
        S[24] ^= i + 1;
    }
    if (outlen % c) {
        res = outlen % c;
        S[24] ^= i + 1;
        for (j = 0; j < rb; j++)
            A[j] = M[j] ^ S[j];
        for (; j < 25; j++)
            A[j] = S[j];
        lc_perm(A);
        for (j = rb; j < 25; j++)
            A[j] ^= S[j];
        for (j = 0; j < c / 64; j++)
            lc_st64(tmp + 8 * j, A[j + rb]);
        memcpy(out, tmp, (size_t)(res / 8));
        if (res % 8)
            out[res / 8] = (unsigned char)(tmp[res / 8] &
                                           (unsigned char)(0xFFu << (8 - (res % 8))));
    }
}

/* ------------------------------------------------------------------------ */
/* exported entry points                                                     */
/* ------------------------------------------------------------------------ */

/* Reference_Implementation/CryptHash_AlgorithmInstance.c:14-18:
   litchi_1024(digest, msg, msg_len_bits); return 0;
   -- digest_len_bits is NOT checked and NULL pointers are NOT checked.
   We reproduce that contract exactly, because kat_gate and delivery_gate
   compare against the reference object. */
int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    (void)digest_len_bits;
    lc_litchi(digest, 1024, msg, (uint64_t)msg_len_bits, 1088, 0);
    return 0;
}

/* Same name and same (bits) convention as the reference implementation.  Note
   the official Optimized_Implementation exports a *bytes* entry of the same
   name; gates call CryptHash, never this. */
void litchi_1024(unsigned char *h, const unsigned char *in, uint64_t inlen_bits)
{
    lc_litchi(h, 1024, in, inlen_bits, 1088, 0);
}

/* ------------------------------------------------------------------------ */
/* probes used by the same-TU G1 harness                                     */
/* ------------------------------------------------------------------------ */
#ifdef LC_TEST_HOOKS
void lc_hook_perm(uint64_t *A)
{
    lc_perm(A);
}

void lc_hook_rounds(uint64_t *A, int n)
{
    uint64_t W[25];
    memcpy(W, A, sizeof W);
    lc_perm_rounds(W, n);
    memcpy(A, W, sizeof W);
}
#endif /* LC_TEST_HOOKS */
