#include <stdint.h>
#include "litchi_xof.h"
int CryptHash(int bits,const unsigned char *msg,unsigned long long n,unsigned char *out) { if(bits!=1024 || n%8) return -1; litchi_xof(out,128,msg,n/8); return 0; }
