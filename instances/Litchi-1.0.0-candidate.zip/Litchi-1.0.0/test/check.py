import ctypes,random,sys
from pathlib import Path
from kat import parse_kat
r=Path(__file__).resolve().parent.parent
rng=random.Random(20261127)
for tier,bits in [('512',512),('768',768),('1024',1024),('XOF',1024)]:
 libs=[ctypes.CDLL(str(r/'build'/f'{k}-{tier}.so')) for k in ('Reference','Optimized','CryptoCode')]
 for l in libs:l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
 records=parse_kat(str(r/'kat'/f'Litchi-{tier}.txt'))
 assert len(records)==4097 and [x[0] for x in records]==list(range(4097))
 for n,msg,dl,want in records:
  assert dl==bits
  inp=ctypes.create_string_buffer(msg or b'\0')
  for i,l in enumerate(libs):
   out=ctypes.create_string_buffer(bits//8);rc=l.CryptHash(bits,inp,n,out)
   if i==1 and n%8:assert rc!=0
   else:assert rc==0 and out.raw==want,(tier,n,i,rc)
 print(tier,'KAT reference/own 4097, optimized 513, non-byte rejected 3584',flush=True)
 lengths=sorted(set([0,1,7,8,9,511,512,513,1023,1024,1025,4095,4096,4097,65535,65536,65537]+[rng.randrange(0,131073) for _ in range(250)]))
 for n in lengths:
  msg=rng.randbytes((n+7)//8);inp=ctypes.create_string_buffer(msg or b'\0');results=[]
  for l in libs:
   out=ctypes.create_string_buffer(bits//8);rc=l.CryptHash(bits,inp,n,out);results.append((rc,out.raw))
  assert results[0][0]==results[2][0]==0 and results[0][1]==results[2][1],(tier,n)
  if n%8==0:assert results[1]==results[0],(tier,n)
  else:assert results[1][0]!=0
 print(tier,'differential cases',len(lengths),flush=True)
