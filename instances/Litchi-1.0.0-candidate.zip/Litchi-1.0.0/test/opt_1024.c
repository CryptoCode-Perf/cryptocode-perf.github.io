#include <stdint.h>
#include "litchi_1024.h"
int CryptHash(int bits,const unsigned char *msg,unsigned long long n,unsigned char *out) { if(bits!=1024 || n%8) return -1; litchi_1024(out,msg,n/8); return 0; }
