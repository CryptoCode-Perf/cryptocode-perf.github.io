#include <stdint.h>
#include "litchi_768.h"
int CryptHash(int bits,const unsigned char *msg,unsigned long long n,unsigned char *out) { if(bits!=768 || n%8) return -1; litchi_768(out,msg,n/8); return 0; }
