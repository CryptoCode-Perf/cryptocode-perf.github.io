#include <stdint.h>
#include "litchi_512.h"
int CryptHash(int bits,const unsigned char *msg,unsigned long long n,unsigned char *out) { if(bits!=512 || n%8) return -1; litchi_512(out,msg,n/8); return 0; }
