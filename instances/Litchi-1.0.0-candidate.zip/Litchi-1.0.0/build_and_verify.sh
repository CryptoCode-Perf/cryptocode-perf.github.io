#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")";mkdir -p build
for tier in 512 768 1024 XOF; do
 ref="Reference_Implementation/Litchi-$tier";opt="Optimized_Implementation/Litchi-$tier";own="CryptoCode_Implementation/Litchi-$tier";fn="${tier,,}"
 gcc -O2 -fPIC -shared -Wl,-z,defs -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" "$ref/litchi_$fn.c" -o "build/Reference-$tier.so"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" "test/opt_$tier.c" "$opt/litchi_$fn.c" -o "build/Optimized-$tier.so"
 case "$tier" in 512) defs=(-DLC_BITS=512 -DLC_CAP=576);; 768) defs=(-DLC_BITS=768 -DLC_CAP=832);; 1024) defs=();; XOF) defs=(-DLC_BITS=1024 -DLC_CAP=1024 -DLC_FID=1);; esac
 gcc -O3 -mavx2 -DLC_NO_BMI2 "${defs[@]}" -fPIC -shared -Wl,-z,defs "$own/implementation.c" -o "build/CryptoCode-$tier.so"
done
python3 test/check.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for tier in 512 768 1024 XOF; do bits=$tier; [ "$tier" = XOF ] && bits=1024; for kind in Reference CryptoCode; do ./build/guard_check "./build/$kind-$tier.so" "$bits";done;done
