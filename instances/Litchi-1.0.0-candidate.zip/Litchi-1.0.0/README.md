# Litchi candidate package

Includes Litchi-512, Litchi-768, Litchi-1024 and the report's Litchi-XOF
1024-bit-output test configuration. On x86-64 Linux with GCC, Python 3 and
AVX2, run `bash build_and_verify.sh`. Reference and CryptoCode builds each
check all 4097 known-answer vectors per configuration; official optimized
builds check 513 byte-aligned vectors and reject 3584 non-byte-aligned cases.
Selected long inputs and reference/CryptoCode guard pages are also checked.

The optimized upstream low-level functions use byte lengths, while the
reference interface uses bit lengths. `test/opt_*.c` is a test adapter that
converts aligned input lengths and rejects other inputs; it is not an upstream
API and never falls back to reference code. The packaged XOF test interface
only exposes 1024-bit output; it does not validate arbitrary output lengths.
CryptoCode builds use LC_NO_BMI2 for the stated instruction-set requirement.

Candidate only: complete XOF interface, controlled performance comparison,
independent source and license review, redistribution permission and final
release review remain pending. Tests do not prove security.
