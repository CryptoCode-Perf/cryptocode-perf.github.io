# Eijen-384

Algorithm: Eijen | Digest bits: 384 | Form: AVX2 C

Contents: implementation source/, public header Eijen-384.h, prebuilt Eijen-384.so,
KAT vector KAT_2_12_Eijen-384.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 62d8ce251d02379e685805e195f60fb5f1b81ad9b3e45763f4fad7bb1b56c3cb
Speed (cpB, lower is faster): reference 6.54 / official-optimized 2.79 / optimized 2.56
Speedup: GM(S1-S8) 1.09x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
