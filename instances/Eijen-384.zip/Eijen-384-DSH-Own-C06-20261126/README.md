# Eijen-384 — candidate_06

1024 B 正式三轮 OPT/our：1.215021, 1.249438, 1.302262；几何均值 **1.255063×**。大于1表示our较快。
硬件CPB不可用（null）；TSC代理our/OPT为 7.000539 / 8.788720 ticks/B。

包根是选中源码原字节及原始headers；original_reference为原始输入C/H。MATRIX保留8长度×三轮，evidence包含12份原始样本、正确性/重建/长KAT/guard-page/来源回放与收尾证据。官方OPT源码不包含在包中。

可使用包内同一基准源和正式指引flags编译our：

```sh
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -I. tools/guide_bench.c CryptHash_AlgorithmInstance.c eijen_ref.c -o our_bench
```

基准运行参数、环境和三轮完整结果以归档report/raw及CAP固定流程为准；此打包步骤没有重新编译或测量。

输入是原ref＋KAT、通用工具/知识与本轮自身反馈，属于known-corpus原始输入replay，不是未见盲测。源码来自DSH留存会话，组织者未改写优化C。安全/常数时间证明未评估。

搜索的provider中断及范围限制详见SOURCE_AUDIT；积分耗尽不等于算法失败或方法穷尽。requested模型路由不证明实际服务端权重或账单。
