#include "eijen.h"
#include "eijen_internal.h"

#include <string.h>
#include <immintrin.h>

const char *eijen_implementation_name(void) {
    return "Eijen x86 reference C99";
}

const eijen_config *eijen_get_config(int digest_bits) {
    return eijen_config_by_bits(digest_bits);
}

size_t eijen_digest_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->digest_bytes;
}

size_t eijen_rate_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->rate_bytes;
}

/*
 * Representation/layout transform (repaired).
 *
 * Canonical-index AVX2 layout: canonical register R[p] holds the eight state
 * words w with w % 4 == p, lane l = w / 4 (0..7).  A YMM register only holds
 * four 64-bit lanes, so R[p] is represented by a pair of registers:
 *   Rlo[p] = { state[p], state[p+4], state[p+8],  state[p+12] }
 *   Rhi[p] = { state[p+16], state[p+20], state[p+24], state[p+28] }
 * Every column is therefore one lane of (R[0],R[1],R[2],R[3]); the first four
 * lanes use RC0 and rotations (36,54,45,44,18,9), the last four use RC1 and
 * (56,46,54,34,19,51).  MixQuad is lane-uniform inside each half, so all six
 * rotations can be compile-time immediates.
 *
 * The word permutation sigma maps, in canonical coordinates,
 *   R'[0] = R[2] rotated left 5 lanes,  R'[1] = R[0],
 *   R'[2] = R[1] rotated left 7 lanes,  R'[3] = R[3] rotated left 4 lanes.
 * With the lo/hi split each of these is a 4-lane permute within one YMM plus a
 * blend between the two halves.  The linear layer is a lane-wise XOR, exactly
 * as in the reference.  State is transposed on entry/exit of the permutation.
 */

#define EIJEN_ROTL_I(x, n)                                                   \
    _mm256_or_si256(_mm256_slli_epi64((x), (n)),                             \
                    _mm256_srli_epi64((x), 64 - (n)))

/* MixQuad on four canonical registers, all eight columns of one half at once.
 * r0..r5 are the six compile-time rotation counts for this half. */
#define EIJEN_MIX(R0, R1, R2, R3, r0, r1, r2, r3, r4, r5, RC) do {            \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r0));                 \
    (R0) = _mm256_xor_si256(EIJEN_ROTL_I((R0), (r4)), (RC));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r1));                 \
    (R2) = EIJEN_ROTL_I((R2), (r5));                                         \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r2));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r3));                 \
} while (0)

/* Lane-wise four-word XOR mixing layer. */
#define EIJEN_LINEAR(R0, R1, R2, R3) do {                                    \
    __m256i _x = _mm256_xor_si256(_mm256_xor_si256((R0), (R1)),               \
                                  _mm256_xor_si256((R2), (R3)));              \
    (R0) = _mm256_xor_si256((R0), _x);                                       \
    (R1) = _mm256_xor_si256((R1), _x);                                       \
    (R2) = _mm256_xor_si256((R2), _x);                                       \
    (R3) = _mm256_xor_si256((R3), _x);                                       \
} while (0)

/* Select four 64-bit lanes of v into a YMM register (dword pairs). */
static inline __m256i eijen_perm4(__m256i v, int i0, int i1, int i2, int i3) {
    __m256i idx = _mm256_setr_epi32(2 * i0, 2 * i0 + 1,
                                    2 * i1, 2 * i1 + 1,
                                    2 * i2, 2 * i2 + 1,
                                    2 * i3, 2 * i3 + 1);
    return _mm256_permutevar8x32_epi32(v, idx);
}

/* sigma: R'[0]=R[2]<<<5 lanes, R'[1]=R[0], R'[2]=R[1]<<<7 lanes,
 *        R'[3]=R[3]<<<4 lanes.  Written out for the lo/hi register pairs. */
#define EIJEN_SIGMA(RL, RH, TL, TH) do {                                     \
    (TL)[0] = _mm256_blend_epi32(eijen_perm4((RH)[2], 1, 2, 3, 3),           \
                                 eijen_perm4((RL)[2], 3, 3, 3, 0), 0xC0);    \
    (TH)[0] = _mm256_blend_epi32(eijen_perm4((RL)[2], 1, 2, 3, 3),           \
                                 eijen_perm4((RH)[2], 3, 3, 3, 0), 0xC0);    \
    (TL)[1] = (RL)[0];                                                       \
    (TH)[1] = (RH)[0];                                                       \
    (TL)[2] = _mm256_blend_epi32(eijen_perm4((RH)[1], 3, 3, 3, 3),           \
                                 eijen_perm4((RL)[1], 0, 0, 1, 2), 0xFC);    \
    (TH)[2] = _mm256_blend_epi32(eijen_perm4((RL)[1], 3, 3, 3, 3),           \
                                 eijen_perm4((RH)[1], 0, 0, 1, 2), 0xFC);    \
    (TL)[3] = (RH)[3];                                                       \
    (TH)[3] = (RL)[3];                                                       \
    (RL)[0] = (TL)[0]; (RH)[0] = (TH)[0];                                   \
    (RL)[1] = (TL)[1]; (RH)[1] = (TH)[1];                                   \
    (RL)[2] = (TL)[2]; (RH)[2] = (TH)[2];                                   \
    (RL)[3] = (TL)[3]; (RH)[3] = (TH)[3];                                   \
} while (0)

/* Evaluate the full 16-round Eijen permutation. */
static void eijen_permutation(uint64_t state[EIJEN_STATE_WORDS]) {
    __m256i RL[4], RH[4], TL[4], TH[4];
    __m256i rcv0, rcv1;
    uint64_t v0[4], v1[4];
    int r, p;

    /* Natural -> canonical. */
    for (p = 0; p < 4; p++) {
        RL[p] = _mm256_setr_epi64x((long long)state[p],
                                   (long long)state[p + 4],
                                   (long long)state[p + 8],
                                   (long long)state[p + 12]);
        RH[p] = _mm256_setr_epi64x((long long)state[p + 16],
                                   (long long)state[p + 20],
                                   (long long)state[p + 24],
                                   (long long)state[p + 28]);
    }

    for (r = 0; r < EIJEN_ROUNDS; r++) {
        rcv0 = _mm256_set1_epi64x((long long)EIJEN_RC0[r]);
        rcv1 = _mm256_set1_epi64x((long long)EIJEN_RC1[r]);

        EIJEN_MIX(RL[0], RL[1], RL[2], RL[3],
                  36, 54, 45, 44, 18, 9, rcv0);
        EIJEN_MIX(RH[0], RH[1], RH[2], RH[3],
                  56, 46, 54, 34, 19, 51, rcv1);

        EIJEN_SIGMA(RL, RH, TL, TH);

        EIJEN_LINEAR(RL[0], RL[1], RL[2], RL[3]);
        EIJEN_LINEAR(RH[0], RH[1], RH[2], RH[3]);

        EIJEN_SIGMA(RL, RH, TL, TH);
    }

    /* Canonical -> natural. */
    for (p = 0; p < 4; p++) {
        _mm256_storeu_si256((__m256i *)v0, RL[p]);
        _mm256_storeu_si256((__m256i *)v1, RH[p]);
        state[p]      = v0[0]; state[p + 4]  = v0[1];
        state[p + 8]  = v0[2]; state[p + 12] = v0[3];
        state[p + 16] = v1[0]; state[p + 20] = v1[1];
        state[p + 24] = v1[2]; state[p + 28] = v1[3];
    }
}

static void eijen_absorb_block(eijen_ctx *ctx, const uint8_t *block, int is_last) {
    uint64_t saved_cap[17];
    int i;
    int cap_start = ctx->cfg->rate_words;
    int cap_words = ctx->cfg->capacity_words;

    for (i = 0; i < cap_words; i++) saved_cap[i] = ctx->state[cap_start + i];
    for (i = 0; i < ctx->cfg->rate_words; i++) {
        ctx->state[i] ^= eijen_load64_le(block + ((size_t)i * 8U));
    }
    if (is_last) ctx->state[EIJEN_STATE_WORDS - 1] ^= (UINT64_C(1) << 63);

    eijen_permutation(ctx->state);

    for (i = 0; i < cap_words; i++) ctx->state[cap_start + i] ^= saved_cap[i];
}

int eijen_init(eijen_ctx *ctx, int digest_bits) {
    const eijen_config *cfg;
    if (ctx == NULL) return -1;
    cfg = eijen_get_config(digest_bits);
    if (cfg == NULL) return -1;
    memset(ctx, 0, sizeof(*ctx));
    ctx->cfg = cfg;
    return 0;
}

int eijen_update(eijen_ctx *ctx, const uint8_t *data, size_t len) {
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || (data == NULL && len != 0U)) return -1;
    rb = (size_t)ctx->cfg->rate_bytes;
    while (len > 0U) {
        size_t space = rb - ctx->buf_len;
        size_t take = len < space ? len : space;
        if (ctx->buf_len == 0U && len > rb) {
            eijen_absorb_block(ctx, data, 0);
            data += rb; len -= rb; continue;
        }
        memcpy(ctx->buf + ctx->buf_len, data, take);
        ctx->buf_len += take;
        data += take; len -= take;
        if (ctx->buf_len == rb && len > 0U) {
            eijen_absorb_block(ctx, ctx->buf, 0);
            ctx->buf_len = 0U;
        }
    }
    return 0;
}

static int eijen_final_partial(eijen_ctx *ctx, uint8_t partial_byte,
                               unsigned int partial_bits, uint8_t *digest) {
    int i, ds;
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || digest == NULL || partial_bits > 7U) return -1;
    rb = (size_t)ctx->cfg->rate_bytes;
    if (ctx->buf_len == rb) {
        eijen_absorb_block(ctx, ctx->buf, 0);
        ctx->buf_len = 0U;
    }
    if (partial_bits == 0U) {
        ctx->buf[ctx->buf_len] = 0x01U;
    } else {
        uint8_t keep = (uint8_t)(0xffU << (8U - partial_bits));
        uint8_t pad = (uint8_t)(0x80U >> partial_bits);
        ctx->buf[ctx->buf_len] = (uint8_t)((partial_byte & keep) | pad);
    }
    ctx->buf_len++;
    memset(ctx->buf + ctx->buf_len, 0, rb - ctx->buf_len);
    eijen_absorb_block(ctx, ctx->buf, 1);
    ds = EIJEN_STATE_WORDS - ctx->cfg->digest_words;
    for (i = 0; i < ctx->cfg->digest_words; i++) {
        eijen_store64_le(digest + ((size_t)i * 8U), ctx->state[ds + i]);
    }
    return 0;
}

int eijen_final(eijen_ctx *ctx, uint8_t *digest) {
    return eijen_final_partial(ctx, 0U, 0U, digest);
}

int eijen_hash(int digest_bits, const uint8_t *msg, size_t len, uint8_t *digest) {
    eijen_ctx ctx;
    if (eijen_init(&ctx, digest_bits) != 0) return -1;
    if (eijen_update(&ctx, msg, len) != 0) return -1;
    return eijen_final(&ctx, digest);
}

int eijen_hash_bits(int digest_bits, const uint8_t *msg,
                    unsigned long long msg_len_bits, uint8_t *digest) {
    eijen_ctx ctx;
    unsigned long long full_bytes = msg_len_bits / 8ULL;
    unsigned int partial_bits = (unsigned int)(msg_len_bits & 7ULL);
    uint8_t partial_byte = 0U;
    if ((msg == NULL && msg_len_bits != 0ULL) || digest == NULL) return -1;
    if (full_bytes > (unsigned long long)((size_t)-1)) return -1;
    if (eijen_init(&ctx, digest_bits) != 0) return -1;
    if (eijen_update(&ctx, msg, (size_t)full_bytes) != 0) return -1;
    if (partial_bits != 0U) partial_byte = msg[full_bytes];
    return eijen_final_partial(&ctx, partial_byte, partial_bits, digest);
}
