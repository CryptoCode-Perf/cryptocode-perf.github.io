#include "eijen.h"
#include "eijen_internal.h"

#include <string.h>
#include <immintrin.h>

const char *eijen_implementation_name(void) {
    return "Eijen x86 reference C99";
}

const eijen_config *eijen_get_config(int digest_bits) {
    return eijen_config_by_bits(digest_bits);
}

size_t eijen_digest_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->digest_bytes;
}

size_t eijen_rate_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->rate_bytes;
}

/*
 * Canonical-index AVX2 layout: canonical register R[p] holds the eight state
 * words w with w % 4 == p, lane l = w / 4 (0..7).  A YMM register only holds
 * four 64-bit lanes, so R[p] is represented by a pair of registers:
 *   Rlo[p] = { state[p], state[p+4], state[p+8],  state[p+12] }
 *   Rhi[p] = { state[p+16], state[p+20], state[p+24], state[p+28] }
 * The word permutation sigma maps, in canonical coordinates,
 *   R'[0] = R[2] rotated left 5 lanes,  R'[1] = R[0],
 *   R'[2] = R[1] rotated left 7 lanes,  R'[3] = R[3] rotated left 4 lanes.
 */

#define EIJEN_ROTL_I(x, n)                                                   \
    _mm256_or_si256(_mm256_slli_epi64((x), (n)),                             \
                    _mm256_srli_epi64((x), 64 - (n)))

/* rotl(x,56) == rotr(x,8) is a one-byte rotation of each 64-bit lane; vpshufb
 * performs it in one instruction (shuffle is confined to 128-bit lanes, and
 * each qword lies wholly in one such lane). */
#define EIJEN_ROTL56(x, M) _mm256_shuffle_epi8((x), (M))

/* MixQuad on four canonical registers, all eight columns of the lo half. */
#define EIJEN_MIX(R0, R1, R2, R3, r0, r1, r2, r3, r4, r5, RC) do {            \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r0));                 \
    (R0) = _mm256_xor_si256(EIJEN_ROTL_I((R0), (r4)), (RC));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r1));                 \
    (R2) = EIJEN_ROTL_I((R2), (r5));                                         \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r2));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r3));                 \
} while (0)

/* MixQuad lo/hi variant: r0 is fixed at 56 and uses vpshufb. */
#define EIJEN_MIX_HI(R0, R1, R2, R3, r1, r2, r3, r4, r5, RC, M) do {          \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL56(_mm256_xor_si256((R3), (R0)), (M));                  \
    (R0) = _mm256_xor_si256(EIJEN_ROTL_I((R0), (r4)), (RC));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r1));                 \
    (R2) = EIJEN_ROTL_I((R2), (r5));                                         \
    (R0) = _mm256_add_epi64((R0), (R1));                                     \
    (R3) = EIJEN_ROTL_I(_mm256_xor_si256((R3), (R0)), (r2));                 \
    (R2) = _mm256_add_epi64((R2), (R3));                                     \
    (R1) = EIJEN_ROTL_I(_mm256_xor_si256((R1), (R2)), (r3));                 \
} while (0)

/* Lane-wise four-word XOR mixing layer. */
#define EIJEN_LINEAR(R0, R1, R2, R3) do {                                    \
    __m256i _x = _mm256_xor_si256(_mm256_xor_si256((R0), (R1)),               \
                                    _mm256_xor_si256((R2), (R3)));              \
    (R0) = _mm256_xor_si256((R0), _x);                                       \
    (R1) = _mm256_xor_si256((R1), _x);                                       \
    (R2) = _mm256_xor_si256((R2), _x);                                       \
    (R3) = _mm256_xor_si256((R3), _x);                                       \
} while (0)

/* In-place sigma lane rotation of the lo/hi register pairs.  Rotations of 5
 * and 7 lanes are immediate-controlled vpermq plus a dword blend; rotations
 * of 0 and 4 are the identity and a free half-swap.  The updates are ordered
 * so that every source lane is read before its slot is overwritten, avoiding
 * a full TL/TH temporary array and its eight follow-up moves. */
#define EIJEN_P1230 0x39  /* vpermq imm: qword lanes [1,2,3,0] */
#define EIJEN_P3012 0x93  /* vpermq imm: qword lanes [3,0,1,2] */

#define EIJEN_SIGMA(RL, RH) do {                                             \
    __m256i _a, _b, _s0l, _s0h, _s3l;                                        \
    /* save old R[0] (needed for R'[1]) and old R[3] (needed for swap) */     \
    _s0l = (RL)[0]; _s0h = (RH)[0];                                          \
    /* R'[0] = R[2] <<< 5: read old R[2], write slot 0 */                     \
    _a = _mm256_permute4x64_epi64((RH)[2], EIJEN_P1230);                      \
    _b = _mm256_permute4x64_epi64((RL)[2], EIJEN_P1230);                      \
    (RL)[0] = _mm256_blend_epi32(_a, _b, 0xC0);                               \
    (RH)[0] = _mm256_blend_epi32(_b, _a, 0xC0);                               \
    /* R'[2] = R[1] <<< 7: read old R[1], write slot 2 */                     \
    _a = _mm256_permute4x64_epi64((RH)[1], EIJEN_P3012);                      \
    _b = _mm256_permute4x64_epi64((RL)[1], EIJEN_P3012);                      \
    (RL)[2] = _mm256_blend_epi32(_a, _b, 0xFC);                               \
    (RH)[2] = _mm256_blend_epi32(_b, _a, 0xFC);                               \
    /* R'[1] = old R[0]; R'[3] = old R[3] <<< 4 (swap lo/hi) */               \
    (RL)[1] = _s0l; (RH)[1] = _s0h;                                          \
    _s3l = (RL)[3]; (RL)[3] = (RH)[3]; (RH)[3] = _s3l;                       \
} while (0)

/* Evaluate the full 16-round Eijen permutation. */
static void eijen_permutation(uint64_t state[EIJEN_STATE_WORDS]) {
    __m256i RL[4], RH[4];
    __m256i rcv0, rcv1;
    /* Byte mask for rotl-by-56 per 64-bit lane, repeated in both 128-bit
     * halves of a YMM register for vpshufb. */
    __m256i rot56 = _mm256_setr_epi8(
        1, 2, 3, 4, 5, 6, 7, 0,  9, 10, 11, 12, 13, 14, 15, 8,
        1, 2, 3, 4, 5, 6, 7, 0,  9, 10, 11, 12, 13, 14, 15, 8);
    uint64_t v0[4], v1[4];
    int r, p;

    /* Natural -> canonical. */
    for (p = 0; p < 4; p++) {
        RL[p] = _mm256_setr_epi64x((long long)state[p],
                                   (long long)state[p + 4],
                                   (long long)state[p + 8],
                                   (long long)state[p + 12]);
        RH[p] = _mm256_setr_epi64x((long long)state[p + 16],
                                   (long long)state[p + 20],
                                   (long long)state[p + 24],
                                   (long long)state[p + 28]);
    }

    for (r = 0; r < EIJEN_ROUNDS; r++) {
        rcv0 = _mm256_set1_epi64x((long long)EIJEN_RC0[r]);
        rcv1 = _mm256_set1_epi64x((long long)EIJEN_RC1[r]);

        EIJEN_MIX(RL[0], RL[1], RL[2], RL[3],
                  36, 54, 45, 44, 18, 9, rcv0);
        EIJEN_MIX_HI(RH[0], RH[1], RH[2], RH[3],
                     46, 54, 34, 19, 51, rcv1, rot56);

        EIJEN_SIGMA(RL, RH);

        EIJEN_LINEAR(RL[0], RL[1], RL[2], RL[3]);
        EIJEN_LINEAR(RH[0], RH[1], RH[2], RH[3]);

        EIJEN_SIGMA(RL, RH);
    }

    /* Canonical -> natural. */
    for (p = 0; p < 4; p++) {
        _mm256_storeu_si256((__m256i *)v0, RL[p]);
        _mm256_storeu_si256((__m256i *)v1, RH[p]);
        state[p]      = v0[0]; state[p + 4]  = v0[1];
        state[p + 8]  = v0[2]; state[p + 12] = v0[3];
        state[p + 16] = v1[0]; state[p + 20] = v1[1];
        state[p + 24] = v1[2]; state[p + 28] = v1[3];
    }
}

static void eijen_absorb_block(eijen_ctx *ctx, const uint8_t *block, int is_last) {
    uint64_t saved_cap[17];
    int i;
    int cap_start = ctx->cfg->rate_words;
    int cap_words = ctx->cfg->capacity_words;

    for (i = 0; i < cap_words; i++) saved_cap[i] = ctx->state[cap_start + i];
    for (i = 0; i < ctx->cfg->rate_words; i++) {
        ctx->state[i] ^= eijen_load64_le(block + ((size_t)i * 8U));
    }
    if (is_last) ctx->state[EIJEN_STATE_WORDS - 1] ^= (UINT64_C(1) << 63);

    eijen_permutation(ctx->state);

    for (i = 0; i < cap_words; i++) ctx->state[cap_start + i] ^= saved_cap[i];
}

int eijen_init(eijen_ctx *ctx, int digest_bits) {
    const eijen_config *cfg;
    if (ctx == NULL) return -1;
    cfg = eijen_get_config(digest_bits);
    if (cfg == NULL) return -1;
    memset(ctx, 0, sizeof(*ctx));
    ctx->cfg = cfg;
    return 0;
}

int eijen_update(eijen_ctx *ctx, const uint8_t *data, size_t len) {
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || (data == NULL && len != 0U)) return -1;
    rb = (size_t)ctx->cfg->rate_bytes;
    while (len > 0U) {
        size_t space = rb - ctx->buf_len;
        size_t take = len < space ? len : space;
        if (ctx->buf_len == 0U && len > rb) {
            eijen_absorb_block(ctx, data, 0);
            data += rb; len -= rb; continue;
        }
        memcpy(ctx->buf + ctx->buf_len, data, take);
        ctx->buf_len += take;
        data += take; len -= take;
        if (ctx->buf_len == rb && len > 0U) {
            eijen_absorb_block(ctx, ctx->buf, 0);
            ctx->buf_len = 0U;
        }
    }
    return 0;
}

static int eijen_final_partial(eijen_ctx *ctx, uint8_t partial_byte,
                                unsigned int partial_bits, uint8_t *digest) {
    int i, ds;
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || digest == NULL || partial_bits > 7U) return -1;
    rb = (size_t)ctx->cfg->rate_bytes;
    if (ctx->buf_len == rb) {
        eijen_absorb_block(ctx, ctx->buf, 0);
        ctx->buf_len = 0U;
    }
    if (partial_bits == 0U) {
        ctx->buf[ctx->buf_len] = 0x01U;
    } else {
        uint8_t keep = (uint8_t)(0xffU << (8U - partial_bits));
        uint8_t pad = (uint8_t)(0x80U >> partial_bits);
        ctx->buf[ctx->buf_len] = (uint8_t)((partial_byte & keep) | pad);
    }
    ctx->buf_len++;
    memset(ctx->buf + ctx->buf_len, 0, rb - ctx->buf_len);
    eijen_absorb_block(ctx, ctx->buf, 1);
    ds = EIJEN_STATE_WORDS - ctx->cfg->digest_words;
    for (i = 0; i < ctx->cfg->digest_words; i++) {
        eijen_store64_le(digest + ((size_t)i * 8U), ctx->state[ds + i]);
    }
    return 0;
}

int eijen_final(eijen_ctx *ctx, uint8_t *digest) {
    return eijen_final_partial(ctx, 0U, 0U, digest);
}

int eijen_hash(int digest_bits, const uint8_t *msg, size_t len, uint8_t *digest) {
    eijen_ctx ctx;
    if (eijen_init(&ctx, digest_bits) != 0) return -1;
    if (eijen_update(&ctx, msg, len) != 0) return -1;
    return eijen_final(&ctx, digest);
}

int eijen_hash_bits(int digest_bits, const uint8_t *msg,
                     unsigned long long msg_len_bits, uint8_t *digest) {
    eijen_ctx ctx;
    unsigned long long full_bytes = msg_len_bits / 8ULL;
    unsigned int partial_bits = (unsigned int)(msg_len_bits & 7ULL);
    uint8_t partial_byte = 0U;
    if ((msg == NULL && msg_len_bits != 0ULL) || digest == NULL) return -1;
    if (full_bytes > (unsigned long long)((size_t)-1)) return -1;
    if (eijen_init(&ctx, digest_bits) != 0) return -1;
    if (eijen_update(&ctx, msg, (size_t)full_bytes) != 0) return -1;
    if (partial_bits != 0U) partial_byte = msg[full_bytes];
    return eijen_final_partial(&ctx, partial_byte, partial_bits, digest);
}
