# FEILIAN candidate package

Instances: FEILIAN512, FEILIAN768 and FEILIAN1024. On x86-64 Linux with
GCC, Python 3 and AVX2, run `bash build_and_verify.sh`. It rebuilds reference,
official optimized and CryptoCode implementations, checks 4097 known-answer
vectors per implementation, compares deterministic long and boundary inputs,
and checks selected input/output guard pages. `CryptHash` lengths are in bits.

CryptoCode C sources were recovered from the local performance report.
Candidate only: controlled performance comparison, independent source and
license review, redistribution permission and final release review remain
pending. Tests do not prove security.
