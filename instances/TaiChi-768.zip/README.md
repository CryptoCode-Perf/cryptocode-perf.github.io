# TaiChi-768

Algorithm: TaiChi | Digest bits: 768 | Form: 标量 C

Contents: implementation source/, public header TaiChi-768.h, prebuilt TaiChi-768.so,
KAT vector KAT_2_12_TaiChi-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 795764d9bfa6001ad5a51a8dc98286d1962c2a6a0b645a0ed8adbc2996ea9200
Speed (cpB, lower is faster): reference 85.18 / official-optimized 11.17 / optimized 10.25
Speedup: GM(S1-S8) 1.24x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
