# CHAMP — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## CHAMP-1024
- 摘要位：1024；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/CHAMP-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/CHAMP-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/CHAMP-1024/`
- 优化要点：对手 = 官方 `Optimized_Implementation/CHAMP-1024/CryptHash_AlgorithmInstance.c`（733 行纯标量 C）经规范 OPT_FLAGS 编出；`_rebuild_opp_check.py` 用同一份源 + 同一组 flag 重编得 35816 B sha `2a7f6b64…`，与 `build/hash-04/champ1024/opt.so` **逐字节相同**（SAME）。 ★对手每次调用做 4 次互相独立的费马求逆（`:708-711`，每次 `p-2` 链 = 256 平方 + 203 乘 = 459 次 `mulmod`，`:378-383` 指数 / `:387-395` 循环），4 条串行依赖链，占一次调用绝大部分。 CHAMP 不是 sponge（整条消息逐位群乘，无 rate/capacity 分块），所

## CHAMP-512
- 摘要位：512；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/CHAMP-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/CHAMP-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/CHAMP-512/`
- 优化要点：把每次调用里 4 次互相独立的费马求逆（每次 459 次 `mulmod`，4 条串行依赖链）换成 1 次 Montgomery 前缀积批量求逆（4 次前缀积 + 1 次求逆 + 4 次回代）；matrix 本体、IV、padding、错误码、导出接口一字未动，只改 `CryptHash` 一个函数。全部 4097 条 KAT 通过，`delivery_gate.py` 11 个位长全过。
