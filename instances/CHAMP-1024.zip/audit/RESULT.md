# CHAMP — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| CHAMP-1024 | `CHAMP-1024.so` | 31800 B | `f46983e0ba7b8555e61bbe6740af1a53f99d3aa3b52ca99e55dccd6dccb251e3` |
| CHAMP-512 | `CHAMP-512.so` | 31768 B | `d318a504d0dc2fecf98821af5e2a4094ba9878293d4eb99265c0f531727a3f51` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| CHAMP-1024 | 1024 | 898.3008 | 170.749 | 53.205388 | 3.209243 | 2.4271 |
| CHAMP-512 | 512 | 280.3379 | 41.9554 | 17.218496 | 2.436647 | 1.9941 |

## 优化方法（逐实例原文，来自交付清单）

### CHAMP-1024
对手 = 官方 `Optimized_Implementation/CHAMP-1024/CryptHash_AlgorithmInstance.c`（733 行纯标量 C）经规范 OPT_FLAGS 编出；`_rebuild_opp_check.py` 用同一份源 + 同一组 flag 重编得 35816 B sha `2a7f6b64…`，与 `build/hash-04/champ1024/opt.so` **逐字节相同**（SAME）。 ★对手每次调用做 4 次互相独立的费马求逆（`:708-711`，每次 `p-2` 链 = 256 平方 + 203 乘 = 459 次 `mulmod`，`:378-383` 指数 / `:387-395` 循环），4 条串行依赖链，占一次调用绝大部分。 CHAMP 不是 sponge（整条消息逐位群乘，无 rate/capacity 分块），所以这 4 次求逆是**唯一**与消息无关的固定开销。 我方交付件 `_overnight/l0/champ/out/ours_champ1024.so`（`build_champ.py`：官方源挖掉 `CryptHash` 67 行保留 665 行 + 我方 132 行）换成 **1 次批量求逆**：Montgomery 前缀积 —— 10 次 `mulmod` 求前缀/后缀积、1 次求逆、再用后缀积回乘出 4 个逆元（替掉 3 次求逆）；吸收路径逐字未动。⇒ 收益全在固定开销（曲线形状可见：32 B 赢 74%，64 KiB 只赢 12.5%）。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过； A/B 两次独立复现 0.4126 / 0.4158。

### CHAMP-512
把每次调用里 4 次互相独立的费马求逆（每次 459 次 `mulmod`，4 条串行依赖链）换成 1 次 Montgomery 前缀积批量求逆（4 次前缀积 + 1 次求逆 + 4 次回代）；matrix 本体、IV、padding、错误码、导出接口一字未动，只改 `CryptHash` 一个函数。全部 4097 条 KAT 通过，`delivery_gate.py` 11 个位长全过。
