#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
champ/build_champ.py —— CHAMP-1024 我方交付件的可复现构建。

路线（MODEL.md §3 有完整论证）：
  基质 = 官方 **Optimized** `CryptHash_AlgorithmInstance.c`（逐字保留它的吸收路径：
         `small_byte_table` / `process_chunk_aligned_bytes` / `process_scalar_bytes` /
         `canonicalize_lazy_u256` / `reduce512_lazy` / `mulmod` …）。
  我方替换的只有驱动层的**摘要阶段**：
    * 官方做 **4 次独立的费马求逆**（`OPT/...c:708-711`，每次 256 次平方 + ~203 次乘法，
      4 条串行依赖链）⇒ 我方做 **1 次批量求逆**（Montgomery 前缀积法：4 乘 + 1 次求逆 +
      6 乘 = 10 次 mulmod 换掉 3 次求逆），把 4 条串行链变成 1 条。
    * 摘要写出从 1024 次单字节存改成 16 次 64 位存（x86 小端 ⇒ 逐字节等价）。
  并额外导出 `champ_absorb_state`（吸收后的规范状态），供 G1 同 TU 对拍官方 Reference 用。

子命令：build | gates | kat | asm | variants
用法：python3 champ/build_champ.py build
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
L0 = os.path.join(WORK, "_overnight", "l0")
sys.path.insert(0, os.path.join(L0, "mofang"))
import build_mofang as B  # noqa: E402

INT = os.path.join(WORK, "_overnight/l0/src/hash-04/CHAMP/Implementations and Test_Vectors/API_CryptHash/Implementations")
OPTDIR = os.path.join(INT, "Optimized_Implementation", "CHAMP-1024")
REFDIR = os.path.join(INT, "Reference_Implementation", "CHAMP-1024")
OPTSRC = os.path.join(OPTDIR, "CryptHash_AlgorithmInstance.c")
REFSRC = os.path.join(REFDIR, "CryptHash_AlgorithmInstance.c")
REFSO = os.path.join(WORK, "_overnight/l0/build/hash-04/champ1024/ref.so")
OPTSO = os.path.join(WORK, "_overnight/l0/build/hash-04/champ1024/opt.so")

GLUE = os.path.join(HERE, "glue_champ1024.c")
OUTDIR = os.path.join(HERE, "out")
SO = os.path.join(OUTDIR, "ours_champ1024.so")

CUT_SIG = "int CryptHash(int digest_len_bits, const unsigned char *msg,"

# ---------------------------------------------------------------------------
# 我方代码：批量求逆 + 摘要写出 + 测试用导出钩子
# ---------------------------------------------------------------------------
MY_CODE = r'''
/* =====================================================================
 * 以下为**我方实现**（feilian / mofang-dev）。其上全部内容为官方 Optimized
 * 源码逐字保留。
 *
 * 官方做法（OPT `CryptHash_AlgorithmInstance.c:708-711`）：
 *     if (zero) u=0; else invmod(&u, &state[i]);     // ×4
 * 每次 invmod = 256 次平方 + ~203 次乘法 = ~459 次 mulmod，且**四条链互不重叠**
 * （实测固定开销 107.7k tick ≈ 4 × 单链 24.25k + 10.8k，见 MODEL.md §4）。
 *
 * 我方做法：一次批量求逆（Montgomery 前缀积）——
 *     b[i]  = (in[i]==0) ? 1 : in[i]
 *     pre[i] = b[0]*...*b[i]
 *     acc = 1/(b0*b1*b2*b3)                        （唯一的 invmod）
 *     逆序遍历 acc *= b[i] 并从 acc 反推每个 1/b[i]
 * 代价 10 次 mulmod + 1 次求逆，替掉 3 次求逆；语义与官方逐位相同（零元仍映到 0）。
 * ===================================================================== */

static const u256 ONE_U256 = {{1, 0, 0, 0}};
static const u256 ZERO_U256_CH = {{0, 0, 0, 0}};

/* out[i] = (in[i] == 0) ? 0 : in[i]^(-1) mod p   （与官方逐位等价） */
static void invmod_batch(u256 out[4], const u256 in[4])
{
    u256 b[4];
    u256 pre[4];
    u256 acc;
    int zero[4];
    int i;

    for (i = 0; i < 4; i++) {
        zero[i] = u256_is_zero(&in[i]);
        if (zero[i]) { b[i] = ONE_U256; } else { b[i] = in[i]; }
    }

    /* 前缀积 */
    acc = ONE_U256;
    for (i = 0; i < 4; i++) {
        mulmod(&acc, &acc, &b[i]);
        pre[i] = acc;
    }

    /* 唯一的求逆 */
    invmod(&acc, &acc);

    /* 逆序回代：acc 依次变成 1/(b0..bi) */
    for (i = 3; i >= 0; i--) {
        u256 t;
        if (i == 0) {
            t = acc;
        } else {
            mulmod(&t, &acc, &pre[i - 1]);
        }
        if (zero[i]) { out[i] = ZERO_U256_CH; } else { out[i] = t; }
        if (i > 0) { mulmod(&acc, &acc, &b[i]); }
    }
}

/* 吸收阶段：与官方 `CryptHash`（OPT `...c:667-706`）逐字相同，抽出来给两个调用方复用。
 * msg_len_bits 的**单位是位**（`full_bytes = bits >> 3`），与官方一致。 */
static void champ_absorb(u256 state[4], const unsigned char *msg,
                         unsigned long long msg_len_bits)
{
    unsigned long long full_bytes, full_chunk_bytes;
    unsigned int remaining_bits;

    build_small_byte_table();
    memcpy(state, MAT_IDENTITY, sizeof(MAT_IDENTITY));

    full_bytes = msg_len_bits >> 3;
    full_chunk_bytes = full_bytes & ~7ULL;

    if (full_chunk_bytes > 0) {
        process_chunk_aligned_bytes(state, msg, 0, full_chunk_bytes);
    }
    process_scalar_bytes(state, msg, full_chunk_bytes, full_bytes);

    remaining_bits = (unsigned int)(msg_len_bits & 7u);
    if (remaining_bits > 0) {
        unsigned char byte = msg[full_bytes];
        int b;
        for (b = 7; b >= (int)(8 - remaining_bits); b--) {
            Mat2x2 tmp;
            int bit = (byte >> b) & 1;
            mat2x2_mul(tmp.m, state, bit ? GEN_B : GEN_A);
            memcpy(state, tmp.m, sizeof(tmp.m));
        }
    }

    canonicalize_lazy_u256(&state[0]);
    canonicalize_lazy_u256(&state[1]);
    canonicalize_lazy_u256(&state[2]);
    canonicalize_lazy_u256(&state[3]);
}

/* 测试/对拍钩子：把吸收后的规范状态按与摘要相同的排布（LE limb）写 128 字节。 */
void champ_absorb_state(unsigned char out[128], const unsigned char *msg,
                        unsigned long long msg_len_bits)
{
    u256 state[4];
    int ci, limb;
    champ_absorb(state, msg, msg_len_bits);
    for (ci = 0; ci < 4; ci++) {
        for (limb = 0; limb < 4; limb++) {
            uint64_t v = state[ci].w[limb];
            memcpy(out + ci * 32 + limb * 8, &v, 8);
        }
    }
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    u256 state[4];
    u256 inv[4];
    int ci, limb;

    (void)digest_len_bits; /* fixed at 1024 bits for this instance */

    champ_absorb(state, msg, msg_len_bits);

    invmod_batch(inv, (const u256 *)state);

    /* 官方写出是逐字节小端（OPT `...c:718-730`）；x86-64 上 64 位存等价。 */
    for (ci = 0; ci < 4; ci++) {
        for (limb = 0; limb < 4; limb++) {
            uint64_t v = inv[ci].w[limb];
            memcpy(digest + ci * 32 + limb * 8, &v, 8);
        }
    }
    return 0;
}
'''


def opt_text():
    return open(OPTSRC, "r", encoding="utf-8", errors="replace").read()


def make_glue(text=None, path=GLUE):
    t = opt_text() if text is None else text
    rest, cut = B.cut_function(t, CUT_SIG)
    assert cut, "官方 CryptHash 没找到"
    rest = rest.rstrip() + "\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(rest + MY_CODE)
    return path, len(cut.splitlines()), len(rest.splitlines())


def compile_so(src, out):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    log = out + ".log"
    args = ["gcc"] + B.FLAGS + ["-fPIC", "-shared", "-Wl,--no-undefined",
                                "-I", REFDIR, "-I", OPTDIR, "-o", out, src, "-lm"]
    r = subprocess.run(args, stdout=open(log, "w"), stderr=subprocess.STDOUT)
    return r.returncode, log


def nm_undef(so, tag):
    p = os.path.join(HERE, "probe", "nm_undef_%s.txt" % tag)
    with open(p, "w") as f:
        subprocess.run(["nm", "-D", "-u", so], stdout=f, stderr=subprocess.STDOUT)
    lines = [l for l in open(p).read().splitlines() if l.strip()]
    bad = [l for l in lines if ("champ" in l or "CryptHash" in l)]
    print("未定义符号 %d 个；其中含 champ/CryptHash 的 %d 个" % (len(lines), len(bad)))
    if bad:
        for l in bad:
            print("   !!", l)
        raise SystemExit("未定义符号复核失败")


def cmd_build():
    glue, cutn, restn = make_glue()
    print("glue = 官方 Optimized 源码挖掉 CryptHash（%d 行），保留 %d 行，接上我方 %d 行"
          % (cutn, restn, len(MY_CODE.splitlines())))
    rc, log = compile_so(glue, SO)
    print("build rc=%d -> %s (%d B, sha256 %s)" % (rc, SO, os.path.getsize(SO), B.sha(SO)))
    if rc != 0:
        print(open(log).read()[-4000:])
        raise SystemExit(1)
    nm_undef(SO, "ours")
    for l in open(log).read().splitlines():
        if "warning" in l:
            print("  warn:", l)
    return SO


def cmd_asm():
    for so, name in ((SO, "ours.asm"), (OPTSO, "opt.asm"), (REFSO, "ref.asm")):
        if not os.path.exists(so):
            continue
        B._objdump(so, os.path.join(HERE, "probe", name))
        print("dumped", name)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    c = sys.argv[1]
    if c == "build":
        cmd_build()
    elif c == "asm":
        cmd_asm()
    else:
        raise SystemExit("unknown subcommand: " + c)


if __name__ == "__main__":
    main()
