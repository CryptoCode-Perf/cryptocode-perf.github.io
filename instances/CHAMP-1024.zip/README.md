# CHAMP-1024

Algorithm: CHAMP | Digest bits: 1024 | Form: 标量 C

Contents: implementation source/, public header CHAMP-1024.h, prebuilt CHAMP-1024.so,
KAT vector KAT_2_12_CHAMP-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): f46983e0ba7b8555e61bbe6740af1a53f99d3aa3b52ca99e55dccd6dccb251e3
Speed (cpB, lower is faster): reference 898.30 / official-optimized 170.75 / optimized 53.21
Speedup: GM(S1-S8) 2.43x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
