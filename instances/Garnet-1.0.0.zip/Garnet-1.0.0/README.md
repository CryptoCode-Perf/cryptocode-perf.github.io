# Garnet-1.0.0

Reference, official optimized and CryptoCode implementations of the **Garnet** hash
function, instance **Garnet-768** (768-bit digest), with the vendor KAT vectors and a
single-command rebuild/verification script.

* Package version: 1.0.0
* Covered instances: Garnet-768
* Digest size: 768 bits (96 bytes)
* Length unit of the API: **bits**
* Verified on: see `results/environment.txt` (Intel Core i7-14650HX, gcc 14.2.0, Linux x86-64)

## Quick start

```sh
sh build_and_verify.sh              # all four KAT tests, including the 2^33-bit vector
sh build_and_verify.sh --skip-2-33  # faster run, skips the 2^33-bit KAT
```

The script rebuilds all three implementations from the sources in this package, runs the
KAT conformance test, cross-compares the three implementations, measures performance and
writes everything it used and produced into `results/`. Exit status 0 means PASS.

## Requirements

* Linux x86-64 with a C compiler (`gcc`) and `ar`; `taskset` (util-linux) is used when present.
* `CryptoCode_Implementation` needs the AES-NI and AVX2 instruction set extensions.
* `Reference_Implementation` needs a plain C99 toolchain only.
* `Optimized_Implementation` is vendor x86-64 assembly; it assembles with the GNU assembler.

## Directory layout

| Path | Content |
| --- | --- |
| `Reference_Implementation/Garnet-768/` | vendor reference implementation (C99), unmodified |
| `Optimized_Implementation/Garnet-768/` | vendor optimized implementation (x86-64 assembly), unmodified |
| `CryptoCode_Implementation/Garnet-768/` | CryptoCode implementation (AES-NI + AVX2 intrinsics) |
| `kat/Garnet-768/` | vendor KAT vectors (KAT_2_12, KAT_2_23, KAT_2_33, KAT_Loop) |
| `test/` | package harness: ABI adapter, digest dump, benchmark, KAT generator entry |
| `prebuilt/` | static archives and harness binaries produced by `build_and_verify.sh` |
| `results/` | environment, flags, KAT comparison, cross-comparison and performance results |
| `build_and_verify.sh` | rebuild and verify everything from this package |
| `SOURCE_MANIFEST.json` | per-file provenance, hashes and disclosures |
| `SHA256SUMS` | checksums of every delivered file except `SOURCE_MANIFEST.json` |

## API

```c
int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest);
int CryptHash_768(const unsigned char *msg, unsigned long long msg_len_bits,
                  unsigned char *digest);
```

`msg_len_bits` counts **bits**, not bytes. `digest` must hold 96 bytes. `CryptHash()`
returns 0 on success and -1 for any digest length other than 768 bits. Messages may end
on a non-byte boundary; unused low bits of the last byte are ignored by the padding rules.

## What the verification does

1. **Build.** All three implementations are compiled from this package only, with the
   flags recorded in `results/environment.txt` (reference: `-std=c99 -Wpedantic -Wall
   -Wextra -O2`; optimized and CryptoCode: `-O3 -march=x86-64 -mavx2 -mtune=native
   -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra`).
2. **KAT.** The unmodified vendor generator is linked against each implementation and
   re-run; its output must be byte-identical to the shipped vendor vectors.
   Expected/regenerated record counts and both SHA-256 values are in
   `results/kat_summary.csv` and `results/kat_sha256.txt`
   (KAT_2_12: 4097 records, KAT_2_23: 3, KAT_2_33: 3, KAT_Loop: 1).
3. **Cross-comparison.** The three implementations must produce identical digests over a
   shared 103-case matrix (`results/digests_*.txt`, `results/cross_comparison.txt`):
   empty input, lengths around every block and padding boundary from 0 to 4096 bytes, and
   non-byte-aligned lengths (bit offsets 1..7 for ten reference lengths).
4. **Performance.** `test/bench.c` measures ns/byte and TSC ticks/byte for 8 message
   lengths, 3 rounds, pinned to one CPU (`taskset -c 0`). TSC ticks/byte is a TSC-derived
   figure, **not** core cycles/byte. Raw samples: `results/perf_raw.csv`.

## Measured results (this package, one machine)

ns per byte, mean of 3 rounds, 1 KB message:

| implementation | ns/B |
| --- | --- |
| vendor reference (C99, -O2) | 15.82 |
| vendor optimized (assembly) | 28.10 |
| CryptoCode (AES-NI + AVX2) | 7.77 |

Full table (`results/perf_summary.csv`):

| bytes | reference ns/B | official ns/B | CryptoCode ns/B | official/ours | reference/ours |
| --- | --- | --- | --- | --- | --- |
| 32 | 84.45 | 151.20 | 43.15 | 3.50× | 1.96× |
| 128 | 33.41 | 61.46 | 17.34 | 3.54× | 1.93× |
| 512 | 17.97 | 31.38 | 8.22 | 3.82× | 2.19× |
| 1024 | 15.82 | 28.10 | 7.77 | 3.62× | 2.04× |
| 4096 | 13.69 | 24.22 | 6.15 | 3.94× | 2.22× |
| 8192 | 13.16 | 23.50 | 5.71 | 4.12× | 2.31× |
| 16384 | 14.83 | 22.75 | 5.70 | 3.99× | 2.60× |
| 65536 | 13.19 | 23.62 | 5.75 | 4.11× | 2.30× |

Geometric mean over the 8 lengths: CryptoCode is **3.82×** faster than the vendor
optimized implementation and **2.18×** faster than the vendor reference implementation.

## Disclosures and known limits

* **The vendor optimized assembly is slower than the vendor reference** on this platform:
  geomean(official/reference) = 1.75, i.e. the official baseline is about 75% slower
  than the reference. It is shipped unchanged as the vendor baseline, not as a
  performance target. Speedups quoted against it are therefore larger than against the
  reference; the honest figure against the vendor reference is 2.18×.
* **Interface adapters (package-authored, no hashing of their own).** The vendor
  optimized assembly exports only the core `Garnet_768(message, mlength, digest, state)`
  and expects an already padded buffer; `test/official_adapter.c` supplies that padding
  and the `CryptHash_768()` entry. The vendor adapter `CryptHash_Garnet.c` also references
  the 512- and 1024-bit instances, which are outside this package; `test/crypt_hash_shim.c`
  provides the same ABI and refuses every digest length other than 768 bits.
* **Scope: Garnet-768 only.** Garnet-512 is not included: the vendor 512-bit optimized
  assembly does not reproduce the vendor 512-bit reference (480 of 4104 harness cases
  differ at byte-aligned lengths), which is an unresolved vendor inconsistency.
* **KAT template header.** The vendor `CryptHash_Garnet.h` is a template with placeholder
  values; the unmodified template ships as
  `test/kat_generator/CryptHash_Garnet.vendor-template.h`, and
  `test/kat_generator/CryptHash_Garnet.h` only fills in the instance name, digest length
  and blank-vector flag.
* KAT conformance is **not** a security or constant-time proof; no constant-time property
  is claimed for any implementation in this package.
* **License status: unresolved.** Vendor sources and vectors keep their original ICCS
  notice; redistribution terms are not stated in the archive. See `SOURCE_MANIFEST.json`.

## Reproducing from a clean copy

```sh
unzip Garnet-1.0.0.zip -d /tmp/garnet-accept
cd /tmp/garnet-accept/Garnet-1.0.0
sha256sum -c SHA256SUMS
sh build_and_verify.sh
```

Acceptance means the checksums verify **and** the rebuild, KAT, cross-comparison and
performance steps pass in that fresh directory.
