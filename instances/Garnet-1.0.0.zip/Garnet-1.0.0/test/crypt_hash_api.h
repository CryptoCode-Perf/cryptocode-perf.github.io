/* Garnet-1.0.0 test API surface (CryptoCode release harness). */
#ifndef GARNET_TEST_CRYPT_HASH_API_H
#define GARNET_TEST_CRYPT_HASH_API_H

#define GARNET_INSTANCE_NAME "Garnet_768"
#define GARNET_DIGEST_BITS 768

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest);
int CryptHash_768(const unsigned char *msg, unsigned long long msg_len_bits,
                  unsigned char *digest);

#endif
