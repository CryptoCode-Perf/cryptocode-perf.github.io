/* Runs the vendor KAT generator unchanged; only the entry selection is replaced.
 * Select tests with GARNET_KAT_TESTS (comma separated subset of
 * KAT_2_12,KAT_2_23,KAT_2_33,KAT_Loop); the default runs all four. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define main archive_original_main
#include "KAT_CryptHash.c"
#undef main

int main(void)
{
    const char *sel = getenv("GARNET_KAT_TESTS");
    if (!sel) sel = "KAT_2_12,KAT_2_23,KAT_2_33,KAT_Loop";
    if (strstr(sel, "KAT_2_12") && gen_KAT_2_12(ALGORITHM_INSTANCE, DIGEST_BIT_LENGTH) != KAT_SUCCESS) return 1;
    if (strstr(sel, "KAT_2_23") && gen_KAT_2_23(ALGORITHM_INSTANCE, DIGEST_BIT_LENGTH) != KAT_SUCCESS) return 1;
    if (strstr(sel, "KAT_2_33") && gen_KAT_2_33(ALGORITHM_INSTANCE, DIGEST_BIT_LENGTH) != KAT_SUCCESS) return 1;
    if (strstr(sel, "KAT_Loop") && gen_KAT_Loop(ALGORITHM_INSTANCE, DIGEST_BIT_LENGTH) != KAT_SUCCESS) return 1;
    return 0;
}
