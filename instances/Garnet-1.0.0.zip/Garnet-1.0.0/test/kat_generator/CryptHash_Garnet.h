/*
 * Garnet-1.0.0 release configuration header.
 *
 * The vendor archive ships CryptHash_Garnet.h as a template whose placeholder
 * values are ALGORITHM_INSTANCE "Garnet" and DIGEST_BIT_LENGTH 512; the
 * unmodified template is preserved next to this file as
 * CryptHash_Garnet.vendor-template.h for transparency. Only the three
 * configuration macros and the instance prototype below are package-specific.
 */
#ifndef CRYPTHASH_GARNET_H
#define CRYPTHASH_GARNET_H

#define OUTPUT_BLANK_TEST_VECTORS 0
#define ALGORITHM_INSTANCE "Garnet_768"
#define DIGEST_BIT_LENGTH 768

#ifdef __cplusplus
extern "C"
{
#endif

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest);

#ifdef __cplusplus
}
#endif
#endif
