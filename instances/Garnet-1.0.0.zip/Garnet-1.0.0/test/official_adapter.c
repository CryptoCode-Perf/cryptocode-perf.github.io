/* Adapter for the vendor Optimized_Implementation.
 *
 * The vendor assembly exposes only the core entry
 *     void Garnet_768(const uint8_t *message, uint64_t mlength, uint8_t *digest,
 *                     garnet_u128_t state[16])
 * and expects an already padded message buffer; the vendor's own main_768.c
 * calls the reference pad_message() before it. That helper is static inside the
 * reference translation unit, so this adapter reproduces the same padding and
 * exposes the package-wide CryptHash_768() entry. It performs no hashing of its
 * own. Disclosed in README.md ("interface adapters"). */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct { uint64_t v[2]; } garnet_state128;

extern void Garnet_768(const uint8_t *message, uint64_t mlength, uint8_t *digest,
                       garnet_state128 state[16]);

int CryptHash_768(const unsigned char *msg, unsigned long long bits, unsigned char *digest)
{
    size_t n = (size_t)((bits + 7ULL) / 8ULL);
    unsigned char *p = (unsigned char *)calloc(n + 256u, 1u);
    garnet_state128 st[16];
    if (!p) return -1;
    if (n && msg) memcpy(p, msg, n);
    if (bits % 8ULL) {
        p[n - 1] = (unsigned char)((p[n - 1] & (0xFFu << (8u - (unsigned)(bits % 8ULL))))
                                   | (1u << (7u - (unsigned)(bits % 8ULL))));
    } else {
        p[n] = 0x80u;
    }
    memset(st, 0, sizeof st);
    Garnet_768(p, (uint64_t)bits, digest, st);
    free(p);
    return 0;
}
