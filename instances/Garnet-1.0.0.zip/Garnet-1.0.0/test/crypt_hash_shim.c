/* Thin adapter from the NGCC CryptHash() ABI to the Garnet-768 instance entry.
 * The vendor adapter (CryptHash_Garnet.c) also references the 512- and 1024-bit
 * instances, which are outside this package's verified scope; this adapter keeps
 * the same ABI and refuses every digest length other than 768 bits. */
#include "crypt_hash_api.h"

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    if (digest_len_bits != GARNET_DIGEST_BITS) return -1;
    return CryptHash_768(msg, msg_len_bits, digest);
}
