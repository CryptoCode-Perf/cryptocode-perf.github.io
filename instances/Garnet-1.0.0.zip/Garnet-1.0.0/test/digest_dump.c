/* Deterministic digest dump used for cross-implementation comparison.
 * Prints one line per case: "bits=<n> <hex digest>".
 * Covers empty input, block/padding boundaries and non-byte-aligned lengths. */
#include <stdio.h>
#include <string.h>
#include "crypt_hash_api.h"

#define MAX_BYTES 5000

static unsigned char buf[MAX_BYTES];
static unsigned char digest[GARNET_DIGEST_BITS / 8];

static void fill(unsigned char *p, unsigned long long nbytes)
{
    unsigned long long i;
    for (i = 0; i < nbytes; i++) p[i] = (unsigned char)((i * 131ULL + 17ULL) & 0xFFULL);
}

static int emit(unsigned long long bits)
{
    unsigned long long nbytes = (bits + 7ULL) / 8ULL;
    int rc, i;
    if (nbytes > MAX_BYTES) return 1;
    fill(buf, nbytes);
    if (bits % 8ULL) buf[nbytes - 1] &= (unsigned char)(0xFFU << (8U - (unsigned)(bits % 8ULL)));
    memset(digest, 0, sizeof digest);
    rc = CryptHash(GARNET_DIGEST_BITS, buf, bits, digest);
    if (rc != 0) { printf("bits=%llu ERROR=%d\n", bits, rc); return 1; }
    printf("bits=%llu ", bits);
    for (i = 0; i < GARNET_DIGEST_BITS / 8; i++) printf("%02x", digest[i]);
    printf("\n");
    return 0;
}

int main(void)
{
    static const unsigned long long whole[] = {0ULL,1ULL,2ULL,3ULL,31ULL,32ULL,33ULL,63ULL,64ULL,65ULL,
        95ULL,96ULL,97ULL,127ULL,128ULL,129ULL,191ULL,192ULL,193ULL,255ULL,256ULL,257ULL,258ULL,
        511ULL,512ULL,513ULL,767ULL,768ULL,769ULL,1023ULL,1024ULL,1025ULL,4096ULL};
    static const unsigned long long partial[] = {0ULL,1ULL,2ULL,95ULL,96ULL,127ULL,128ULL,255ULL,256ULL,257ULL};
    unsigned i, k;
    for (i = 0; i < sizeof whole / sizeof whole[0]; i++) if (emit(whole[i] * 8ULL)) return 2;
    for (i = 0; i < sizeof partial / sizeof partial[0]; i++)
        for (k = 1; k <= 7; k++) if (emit(partial[i] * 8ULL + k)) return 2;
    return 0;
}
