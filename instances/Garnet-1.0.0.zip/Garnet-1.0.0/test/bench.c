/* Self-contained benchmark: 8 message lengths, N rounds, ns/byte and TSC ticks/byte.
 * TSC ticks/byte is a TSC-derived figure, NOT core cycles/byte. */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#if defined(__x86_64__) || defined(__i386__)
#include <x86intrin.h>
#endif
#include "crypt_hash_api.h"

#define MAX_BYTES (1u << 20)

static double now_ns(void)
{
#if defined(CLOCK_MONOTONIC)
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1e9 + (double)ts.tv_nsec;
#else
    return (double)clock() * (1e9 / (double)CLOCKS_PER_SEC);
#endif
}

static unsigned long long now_tsc(void)
{
#if defined(__x86_64__) || defined(__i386__)
    return __rdtsc();
#else
    return 0ULL;
#endif
}

int main(int argc, char **argv)
{
    static const unsigned sizes[] = {32u,128u,512u,1024u,4096u,8192u,16384u,65536u};
    const char *label = (argc > 1) ? argv[1] : "impl";
    int rounds = (argc > 2) ? atoi(argv[2]) : 3;
    double target_ns = (argc > 3) ? atof(argv[3]) : 2.0e8;
    unsigned char *buf = (unsigned char *)malloc(MAX_BYTES);
    unsigned char digest[GARNET_DIGEST_BITS / 8];
    unsigned i, r, j;
    if (!buf) return 2;
    for (j = 0; j < MAX_BYTES; j++) buf[j] = (unsigned char)((j * 131u + 17u) & 0xFFu);
    printf("impl,size_bytes,round,reps,ns_per_byte,tsc_per_byte\n");
    for (i = 0; i < sizeof sizes / sizeof sizes[0]; i++) {
        unsigned sz = sizes[i];
        for (r = 0; r < rounds; r++) {
            unsigned long reps = 1, k;
            double t0, t1, dt, per_byte_ns;
            unsigned long long c0, c1, per_byte_tsc;
            for (k = 0; k < 3; k++) (void)CryptHash(GARNET_DIGEST_BITS, buf, (unsigned long long)sz * 8ULL, digest);
            for (;;) {
                t0 = now_ns();
                for (k = 0; k < reps; k++) (void)CryptHash(GARNET_DIGEST_BITS, buf, (unsigned long long)sz * 8ULL, digest);
                dt = now_ns() - t0;
                if (dt >= target_ns / 4.0) break;
                if (reps > (1UL << 26)) break;
                reps *= 2;
            }
            t0 = now_ns(); c0 = now_tsc();
            for (k = 0; k < reps; k++) (void)CryptHash(GARNET_DIGEST_BITS, buf, (unsigned long long)sz * 8ULL, digest);
            t1 = now_ns(); c1 = now_tsc();
            per_byte_ns = (t1 - t0) / ((double)reps * (double)sz);
            per_byte_tsc = (unsigned long long)((double)(c1 - c0) / ((double)reps * (double)sz) + 0.5);
            printf("%s,%u,%u,%lu,%.4f,%llu\n", label, sz, r + 1, reps, per_byte_ns, per_byte_tsc);
        }
    }
    free(buf);
    return 0;
}
