#!/bin/sh
# Garnet-1.0.0 - rebuild and verify all three implementations using this package only.
# Usage: sh build_and_verify.sh [--skip-2-33]
# All paths resolve relative to this script; nothing outside the package is read.
set -eu

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$HERE"

CC=${CC:-gcc}
AR=${AR:-ar}
REFFLAGS="-std=c99 -Wpedantic -Wall -Wextra -O2"
PERFFLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
KATTESTS="KAT_2_12,KAT_2_23,KAT_2_33,KAT_Loop"
if [ "${1:-}" = "--skip-2-33" ]; then KATTESTS="KAT_2_12,KAT_2_23,KAT_Loop"; fi

B=prebuilt
R=results
rm -rf "$R" "$B"
mkdir -p "$B" "$R/build" "$R/kat/reference" "$R/kat/official" "$R/kat/cryptocode"

fail=0
note() { printf '%s\n' "$*"; }

# ---------- 1. environment ----------
{
  note "# Garnet-1.0.0 build environment"
  note "cc_version: $($CC --version | head -1)"
  note "ar_version: $($AR --version | head -1)"
  note "kernel: $(uname -srm)"
  note "cpu_model: $(grep -m1 'model name' /proc/cpuinfo | sed 's/^[^:]*: *//')"
  note "cpu_logical: $(grep -c ^processor /proc/cpuinfo)"
  note "isa_aes: $(grep -m1 '^flags' /proc/cpuinfo | tr ' ' '\n' | grep -qx aes && echo present || echo missing)"
  note "isa_avx2: $(grep -m1 '^flags' /proc/cpuinfo | tr ' ' '\n' | grep -qx avx2 && echo present || echo missing)"
  note "reference_flags: $REFFLAGS"
  note "performance_flags: $PERFFLAGS"
  note "kat_tests: $KATTESTS"
  note "abi: int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest)"
  note "length_unit: bits"
  note "digest_bits: 768"
} > "$R/environment.txt"

# ---------- 2. build all three implementations into static archives ----------
lib_build() { # <name> <flags> <sources...>
  name=$1; flags=$2; shift 2
  log="$R/build/$name.log"
  note "impl: $name" > "$log"
  note "cmd: $CC $flags <sources> => $B/libgarnet768_$name.a" >> "$log"
  objs=""
  i=0
  for src in "$@"; do
    i=$((i + 1))
    obj="$B/${name}_$i.o"
    # shellcheck disable=SC2086
    if ! $CC $flags -c "$src" -o "$obj" >>"$log" 2>&1; then
      note "BUILD_FAILED $name ($src)"; fail=1; return 1
    fi
    objs="$objs $obj"
  done
  # shellcheck disable=SC2086
  if ! $AR rcs "$B/libgarnet768_$name.a" $objs >>"$log" 2>&1; then
    note "ARCHIVE_FAILED $name"; fail=1; return 1
  fi
  return 0
}

lib_build reference "$REFFLAGS -IReference_Implementation/Garnet-768 -Itest" \
  Reference_Implementation/Garnet-768/Garnet_768.c test/crypt_hash_shim.c || true
lib_build official "$PERFFLAGS -IReference_Implementation/Garnet-768 -Itest" \
  Optimized_Implementation/Garnet-768/Garnet_768.S test/official_adapter.c test/crypt_hash_shim.c || true
lib_build cryptocode "$PERFFLAGS -IReference_Implementation/Garnet-768 -ICryptoCode_Implementation/Garnet-768 -Itest" \
  CryptoCode_Implementation/Garnet-768/Garnet_768_aesni.c test/crypt_hash_shim.c || true

[ "$fail" -eq 0 ] || { note "FATAL: implementation build failed; see $R/build"; exit 1; }

# ---------- 3. harness binaries (dump / bench / KAT generator) ----------
harness_build() { # <binary-name> <flags> <extra-includes> <main.c> <archive>
  hb_name=$1; hb_flags=$2; hb_inc=$3; hb_main=$4; hb_lib=$5
  hb_log="$R/build/$hb_name.log"
  # shellcheck disable=SC2086
  if ! $CC $hb_flags $hb_inc "$hb_main" "$hb_lib" -o "$B/$hb_name" >>"$hb_log" 2>&1; then
    note "BUILD_FAILED $hb_name"; fail=1
  fi
}

for name in reference official cryptocode; do
  case $name in
    reference)  FLAGS="$REFFLAGS"; INCS="-IReference_Implementation/Garnet-768 -Itest" ;;
    official)   FLAGS="$PERFFLAGS"; INCS="-IReference_Implementation/Garnet-768 -Itest" ;;
    cryptocode) FLAGS="$PERFFLAGS"; INCS="-IReference_Implementation/Garnet-768 -ICryptoCode_Implementation/Garnet-768 -Itest" ;;
  esac
  harness_build "dump_$name" "$FLAGS" "$INCS" test/digest_dump.c "$B/libgarnet768_$name.a"
  harness_build "bench_$name" "$FLAGS" "$INCS" test/bench.c "$B/libgarnet768_$name.a"
  # shellcheck disable=SC2086
  if ! $CC $FLAGS $INCS -Itest/kat_generator \
        test/kat_generator/kat_main.c test/kat_generator/drng.c \
        "$B/libgarnet768_$name.a" -o "$B/katgen_$name" >>"$R/build/katgen_$name.log" 2>&1; then
    note "BUILD_FAILED katgen_$name"; fail=1
  fi
done

[ "$fail" -eq 0 ] || { note "FATAL: harness build failed; see $R/build"; exit 1; }

# ---------- 4. KAT: regenerate with the vendor generator, compare byte for byte ----------
kat_report="$R/kat_summary.csv"
note "impl,test,expected_records,regenerated_records,bytes_identical" > "$kat_report"
for name in reference official cryptocode; do
  dir="$R/kat/$name"
  if ! ( cd "$dir" && GARNET_KAT_TESTS="$KATTESTS" "$HERE/$B/katgen_$name" ) >"$dir/katgen.log" 2>&1; then
    note "KAT_RUN_FAILED $name (see $dir/katgen.log)"; fail=1
  fi
  for t in KAT_2_12 KAT_2_23 KAT_2_33 KAT_Loop; do
    case $KATTESTS in *$t*) ;; *) continue ;; esac
    f="$t"_Garnet_768.txt
    exp="kat/Garnet-768/$f"
    got="$dir/output/$f"
    expn=$(grep -c '^Dst_Len' "$exp" || true)
    if [ -f "$got" ]; then
      gotn=$(grep -c '^Dst_Len' "$got" || true)
      if cmp -s "$exp" "$got"; then same=yes; else same=no; fail=1; fi
    else
      gotn=0; same=no; fail=1
    fi
    note "$name,$t,$expn,$gotn,$same" >> "$kat_report"
    if [ -f "$got" ]; then
      note "$name $t expected=$(sha256sum "$exp" | cut -d" " -f1) regenerated=$(sha256sum "$got" | cut -d" " -f1)" \
        >> "$R/kat_sha256.txt"
    fi
  done
  # The published vectors are shipped in kat/; the regenerated copies are only
  # evidence for the comparison above, so they are dropped to keep the package lean.
  rm -rf "$dir/output"
done

# ---------- 5. cross-implementation digest comparison ----------
for name in reference official cryptocode; do
  if ! "$B/dump_$name" > "$R/digests_$name.txt"; then note "DUMP_FAILED $name"; fail=1; fi
done
cross="$R/cross_comparison.txt"
{
  note "# cross-implementation digest comparison over one shared input matrix"
  note "cases: $(wc -l < "$R/digests_reference.txt")"
  note "reference_vs_official: $(cmp -s "$R/digests_reference.txt" "$R/digests_official.txt" && echo identical || echo DIFFERENT)"
  note "reference_vs_cryptocode: $(cmp -s "$R/digests_reference.txt" "$R/digests_cryptocode.txt" && echo identical || echo DIFFERENT)"
} > "$cross"
cmp -s "$R/digests_reference.txt" "$R/digests_official.txt" || fail=1
cmp -s "$R/digests_reference.txt" "$R/digests_cryptocode.txt" || fail=1

# ---------- 6. performance: pinned, exclusive, 8 sizes, 3 rounds ----------
raw="$R/perf_raw.csv"
note "impl,size_bytes,round,reps,ns_per_byte,tsc_per_byte" > "$raw"
for name in reference official cryptocode; do
  if command -v taskset >/dev/null 2>&1; then
    taskset -c 0 "$B/bench_$name" "$name" 3 >> "$raw" || { note "BENCH_FAILED $name"; fail=1; }
  else
    "$B/bench_$name" "$name" 3 >> "$raw" || { note "BENCH_FAILED $name"; fail=1; }
  fi
done
{
  note "impl,size_bytes,mean_ns_per_byte"
  awk -F, '$1!="impl" && NF>=5 {k=$1" "$2; s[k]+=$5; n[k]++} END {for (k in s) {split(k,a," "); printf "%s,%s,%.4f\n", a[1], a[2], s[k]/n[k]}}' "$raw" \
    | sort -t, -k2,2n -k1,1
} > "$R/perf_summary.csv"

# ---------- 7. verdict ----------
{
  note "package: Garnet-1.0.0"
  note "instances: Garnet-768"
  note "build_all_three: ok"
  note "kat_byte_identical_to_published: $(awk -F, 'NR>1 && $5!="yes" {bad=1} END {print (bad?"no":"yes")}' "$kat_report")"
  note "cross_implementation_digests: $(grep -c '^reference_vs_.*: identical' "$cross")/2 identical"
  note "performance_source: $raw (3 rounds x 8 sizes, pinned to one CPU)"
  note "verdict: $( [ "$fail" -eq 0 ] && echo PASS || echo FAIL )"
} > "$R/verification_summary.txt"

cat "$R/verification_summary.txt"
[ "$fail" -eq 0 ] || exit 1
exit 0
