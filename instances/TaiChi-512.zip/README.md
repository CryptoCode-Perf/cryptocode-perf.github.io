# TaiChi-512

Algorithm: TaiChi | Digest bits: 512 | Form: 标量 C

Contents: implementation source/, public header TaiChi-512.h, prebuilt TaiChi-512.so,
KAT vector KAT_2_12_TaiChi-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 2b161fd53a4ab8cfbbfa6d2b03d55354de224a8218b41eeedd5558ced6446079
Speed (cpB, lower is faster): reference 63.34 / official-optimized 7.85 / optimized 6.18
Speedup: GM(S1-S8) 1.31x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
