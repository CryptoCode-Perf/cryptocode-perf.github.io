# TaiChi — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## TaiChi-1024
- 摘要位：1024；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/TaiChi-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/TaiChi-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/TaiChi-1024/`
- 优化要点：官方优化版 TaiChi-1024-op-per 的两处驱动层改写，与 TaiChi-512 同源（填充时 bit_pos 逐位自增 → 闭式取模，值完全相同；ROTL64 纯 C 移位 → BMI2 rorx；置换核一字未动）。交付件 _overnight/l0/taichi/out/ours_taichi1024.so，其 purec 版与在册 opt.so 逐字节相同。等价性：ref/base/cand 各 4097/4097。标准行口径：ref_cpb/opt_cpb 由 _taichi_std_add.py 本轮同会话测出

## TaiChi-512
- 摘要位：512；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/TaiChi-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/TaiChi-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/TaiChi-512/`
- 优化要点：官方优化版 TaiChi-512-op-per 的两处驱动层改写 _overnight/l0/taichi512/src/CryptHash_AlgorithmInstance_rorx_pad.c（填充时 bit_pos 逐位自增最多 895 次 → 闭式取模，值完全相同；ROTL64 纯 C 移位 → BMI2 rorx；置换核一字未动）。配方复现：按官方十字旗标重编的 base 与在册 opt.so 逐字节相同。等价性：ref/base/ours 各 4097/4097（ab_check512.py），位长扫描 0..1023 1024/1024 相同；负对照 n1 填充偏 1 与 n2 rorx 偏 1 各 1024/1024 变红、n3 rorx→标量旋转（负-负）1024/1024 保持绿

## TaiChi-768
- 摘要位：768；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/TaiChi-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/TaiChi-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/TaiChi-768/`
- 优化要点：官方优化版 TaiChi-768-op-per 的两处驱动层改写，与 TaiChi-512 同源（同上；置换核一字未动）。交付件 _overnight/l0/taichi768/out/ours_taichi768.so，由 _overnight/l0/taichi768/build768.py 逐字节可重建；负对照 n3 的 sha 与 base 相同，兼作第二次保真度证明。等价性：ref/base/ours 各 4097/4097（ab_check768.py）。标准行口径：ref_cpb/opt_cpb 由 _taichi_std_add.py 本轮同会话测出
