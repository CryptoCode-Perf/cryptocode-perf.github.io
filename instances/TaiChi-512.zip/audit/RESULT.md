# TaiChi — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| TaiChi-1024 | `TaiChi-1024.so` | 23368 B | `1611077ce812b5f8ff635424ffbbee5a024090d8f3662674c328cec5bc297886` |
| TaiChi-512 | `TaiChi-512.so` | 19272 B | `2b161fd53a4ab8cfbbfa6d2b03d55354de224a8218b41eeedd5558ced6446079` |
| TaiChi-768 | `TaiChi-768.so` | 19272 B | `795764d9bfa6001ad5a51a8dc98286d1962c2a6a0b645a0ed8adbc2996ea9200` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| TaiChi-1024 | 1024 | 123.3199 | 15.2426 | 13.517138 | 1.12765 | 1.0965 |
| TaiChi-512 | 512 | 63.3379 | 7.8469 | 6.177864 | 1.270164 | 1.3058 |
| TaiChi-768 | 768 | 85.1796 | 11.1741 | 10.251119 | 1.090037 | 1.2393 |

## 优化方法（逐实例原文，来自交付清单）

### TaiChi-1024
官方优化版 TaiChi-1024-op-per 的两处驱动层改写，与 TaiChi-512 同源（填充时 bit_pos 逐位自增 → 闭式取模，值完全相同；ROTL64 纯 C 移位 → BMI2 rorx；置换核一字未动）。交付件 _overnight/l0/taichi/out/ours_taichi1024.so，其 purec 版与在册 opt.so 逐字节相同。等价性：ref/base/cand 各 4097/4097。标准行口径：ref_cpb/opt_cpb 由 _taichi_std_add.py 本轮同会话测出

### TaiChi-512
官方优化版 TaiChi-512-op-per 的两处驱动层改写 _overnight/l0/taichi512/src/CryptHash_AlgorithmInstance_rorx_pad.c（填充时 bit_pos 逐位自增最多 895 次 → 闭式取模，值完全相同；ROTL64 纯 C 移位 → BMI2 rorx；置换核一字未动）。配方复现：按官方十字旗标重编的 base 与在册 opt.so 逐字节相同。等价性：ref/base/ours 各 4097/4097（ab_check512.py），位长扫描 0..1023 1024/1024 相同；负对照 n1 填充偏 1 与 n2 rorx 偏 1 各 1024/1024 变红、n3 rorx→标量旋转（负-负）1024/1024 保持绿

### TaiChi-768
官方优化版 TaiChi-768-op-per 的两处驱动层改写，与 TaiChi-512 同源（同上；置换核一字未动）。交付件 _overnight/l0/taichi768/out/ours_taichi768.so，由 _overnight/l0/taichi768/build768.py 逐字节可重建；负对照 n3 的 sha 与 base 相同，兼作第二次保真度证明。等价性：ref/base/ours 各 4097/4097（ab_check768.py）。标准行口径：ref_cpb/opt_cpb 由 _taichi_std_add.py 本轮同会话测出
