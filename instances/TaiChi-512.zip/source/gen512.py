#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Derive our TaiChi-512 sources from the official optimized source.

The registered h25 instance is **TaiChi-512**, but the earlier taichi/ experiment
was built against TaiChi-1024-op-per (its out/*.so are 1024-bit artifacts and
therefore cannot be A/B'd against the registered 512-bit library).  This script
re-applies the same two levers to the 512 source:

  lever A  padding bit-advance loop  -> closed form (exact, not approximate)
  lever B  ROTL64 helper             -> BMI2 rorx

Every substitution is asserted to fire exactly once, so a silent no-op patch is
impossible.

usage: python3 _overnight/l0/taichi512/gen512.py
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)

OPT = os.path.join(L0, "taichi", "official", "TaiChi", "Implementations",
                   "Optimized_Implementation", "TaiChi-512-op-per")
SRC = os.path.join(OPT, "CryptHash_AlgorithmInstance.c")
OUT = os.path.join(HERE, "src")

ROTL_ORIG = """static inline uint64_t ROTL64(uint64_t x, unsigned int n) {
    return (x << n) | (x >> ((64 - n) & 63));
}"""

ROTL_BMI2 = """#if defined(TC_NO_BMI2)
static inline uint64_t ROTL64(uint64_t x, unsigned int n) {
    return (x << n) | (x >> ((64 - n) & 63));
}
#else
static inline uint64_t tc_rorx64(uint64_t x, unsigned int n) {
    uint64_t r;
    __asm__ ("rorx %2, %1, %0" : "=r"(r) : "r"(x), "i"(n));
    return r;
}
# define ROTL64(x, n) tc_rorx64((x), (unsigned int)(64U - (unsigned int)(n)))
#endif"""

PAD_LOOP_ORIG = """        /* M || 1 || 0^j */
        while (((bit_pos + 1) % RATE_BITS) != 0) {
            bit_pos++;
        }"""

PAD_LOOP_CLOSED = """        /* M || 1 || 0^j
           (same value as the official bit-at-a-time loop: the smallest
           bit_pos >= the current one with (bit_pos + 1) % RATE_BITS == 0) */
        {
            unsigned long long pad_rem = bit_pos % RATE_BITS;
            if (pad_rem != (RATE_BITS - 1ULL))
                bit_pos += (RATE_BITS - 1ULL) - pad_rem;
        }"""


def read(path):
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def sub_once(text, old, new, what):
    n = text.count(old)
    if n != 1:
        sys.exit("FATAL: %s: expected exactly 1 occurrence, found %d" % (what, n))
    return text.replace(old, new)


def emit(mode):
    txt = read(SRC)
    base = "purec" if mode.endswith("_pad") else mode
    if base in ("purec", "rorx"):
        txt = sub_once(txt, ROTL_ORIG, ROTL_BMI2, "ROTL64 helper (BMI2)")
    else:
        sys.exit("unknown mode %r" % mode)
    if mode.endswith("_pad"):
        txt = sub_once(txt, PAD_LOOP_ORIG, PAD_LOOP_CLOSED,
                       "padding bit-advance loop (closed form)")
    os.makedirs(OUT, exist_ok=True)
    dst = os.path.join(OUT, "CryptHash_AlgorithmInstance_%s.c" % mode)
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(txt)
    print("wrote %s (%d bytes)" % (dst, len(txt)))


def main():
    for mode in ("purec", "purec_pad", "rorx", "rorx_pad"):
        emit(mode)
    return 0


if __name__ == "__main__":
    sys.exit(main())
