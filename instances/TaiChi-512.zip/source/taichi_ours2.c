/* taichi_ours2.c — TaiChi-512 完整实现 v2：MRM 扁平化（照抄官方 opt 形式）
 * + lane 并行（cols 0-3 一个 ymm）+ sponge 外壳，**全部单 TU**。
 *
 * v1 的根因：MRM 照抄了 ref 的间接索引 y[N1[i-6]]（16 步、含 6 次空转），
 * 官方 opt 把它扁平化成命名标量（只有 10 次真旋转，m=0 处退化为纯异或）。
 * 本版同时做两件事：
 *   1. 扁平化（追平 opt 的结构优势）；
 *   2. cols 0-3 打包进 ymm 的 4 lane（lane-wise，零交叉洗牌），
 *      col4 标量 → 这是相对 opt 的**增量**（4/5 的列 SIMD 化）。
 */
#include <immintrin.h>
#include <stdint.h>
#include <string.h>

#define RATE_BITS 1408
#define RATE_BYTES (RATE_BITS / 8)
#define RATE_WORDS (RATE_BITS / 64)              /* 22 */
#define CAPACITY_WORDS ((1920 - RATE_BITS) / 64) /* 8 */
#define DIGEST_BYTES 64
#define DOMAIN_AB  1
#define DOMAIN_FIN 2

#define ROTL64(x, n) ((n) == 0 ? (x) : (((x) << (n)) | ((x) >> (64 - (n)))))
static inline __m256i rotl_v(__m256i x, int n) {
    if (n == 0) return x;
    return _mm256_or_si256(_mm256_slli_epi64(x, n), _mm256_srli_epi64(x, 64 - n));
}

/* 扁平化 MRM（标量，单列）——照抄官方 opt 的命名标量形式。 */
#define MRM_SCALAR(y0,y1,y2,y3,y4,y5, out) do {                     \
    uint64_t y6  = (y0) ^ ROTL64((y1), 8);                          \
    uint64_t y7  = (y1) ^ (y2);                                     \
    uint64_t y8  = (y2) ^ (y4);                                     \
    uint64_t y9  = (y4) ^ (y3);                                     \
    uint64_t y10 = (y3) ^ (y5);                                     \
    uint64_t y11 = (y5) ^ y6;                                       \
    uint64_t y12 = y6 ^ ROTL64((y0), 23);                           \
    uint64_t y13 = y7 ^ ROTL64(y11, 62);                            \
    uint64_t y14 = y13 ^ ROTL64(y8, 35);                            \
    uint64_t y15 = y14 ^ ROTL64(y9, 14);                            \
    uint64_t y16 = y15 ^ ROTL64(y10, 48);                           \
    uint64_t y17 = y16 ^ ROTL64(y12, 1);                            \
    uint64_t y18 = y15 ^ ROTL64(y17, 57);                           \
    uint64_t y19 = y18 ^ ROTL64(y14, 63);                           \
    uint64_t y20 = y11 ^ ROTL64(y19, 58);                           \
    uint64_t y21 = y20 ^ ROTL64(y13, 22);                           \
    (out)[0] = y16; (out)[1] = ROTL64(y17,15); (out)[2] = ROTL64(y18,48); \
    (out)[3] = ROTL64(y19,63); (out)[4] = ROTL64(y20,6); (out)[5] = ROTL64(y21,33); \
} while (0)

/* 扁平化 MRM 的 SIMD 版（lane = 列，cols 0-3）。 */
#define MRM_SIMD(y, out) do {                                       \
    __m256i y6  = _mm256_xor_si256((y)[0], rotl_v((y)[1], 8));      \
    __m256i y7  = _mm256_xor_si256((y)[1], (y)[2]);                 \
    __m256i y8  = _mm256_xor_si256((y)[2], (y)[4]);                 \
    __m256i y9  = _mm256_xor_si256((y)[4], (y)[3]);                 \
    __m256i y10 = _mm256_xor_si256((y)[3], (y)[5]);                 \
    __m256i y11 = _mm256_xor_si256((y)[5], y6);                     \
    __m256i y12 = _mm256_xor_si256(y6, rotl_v((y)[0], 23));         \
    __m256i y13 = _mm256_xor_si256(y7, rotl_v(y11, 62));            \
    __m256i y14 = _mm256_xor_si256(y13, rotl_v(y8, 35));            \
    __m256i y15 = _mm256_xor_si256(y14, rotl_v(y9, 14));            \
    __m256i y16 = _mm256_xor_si256(y15, rotl_v(y10, 48));           \
    __m256i y17 = _mm256_xor_si256(y16, rotl_v(y12, 1));            \
    __m256i y18 = _mm256_xor_si256(y15, rotl_v(y17, 57));           \
    __m256i y19 = _mm256_xor_si256(y18, rotl_v(y14, 63));           \
    __m256i y20 = _mm256_xor_si256(y11, rotl_v(y19, 58));           \
    __m256i y21 = _mm256_xor_si256(y20, rotl_v(y13, 22));           \
    (out)[0] = y16; (out)[1] = rotl_v(y17,15); (out)[2] = rotl_v(y18,48); \
    (out)[3] = rotl_v(y19,63); (out)[4] = rotl_v(y20,6); (out)[5] = rotl_v(y21,33); \
} while (0)

static inline void sbox_row(uint64_t s[30], int i) {
    uint64_t a0=s[5*i+0],a1=s[5*i+1],a2=s[5*i+2],a3=s[5*i+3],a4=s[5*i+4];
    s[5*i+0] = a1 ^ (a0&a1) ^ a2 ^ (a1&a2) ^ a3 ^ (a3&a4);
    s[5*i+1] = ~0ULL ^ a1 ^ (a0&a3) ^ (a1&a3) ^ a4 ^ (a2&a4);
    s[5*i+2] = (a1&a2)^a3^(a2&a3)^a4^(a0&a4);
    s[5*i+3] = (a0&a2)^(a1&a3)^(a2&a3)^a4;
    s[5*i+4] = a0^(a2&a3)^(a1&a4);
}

static uint64_t RC_TAB[120];
static int RC_DONE = 0;
static void precompute_RC(void) {
    static const int p[7] = {0,2,3,6,13,28,59};
    uint8_t s[7] = {1,0,0,0,0,0,0};
    for (int q = 0; q < 120; q++) {
        uint64_t C = 0;
        for (int i = 0; i < 7; i++) if (s[i]) C ^= (1ULL << p[i]);
        RC_TAB[q] = C;
        uint8_t ns[7] = {s[6], s[0]^s[6], s[1], s[2], s[3], s[4], s[5]};
        for (int i=0;i<7;i++) s[i]=ns[i];
    }
    RC_DONE = 1;
}

static inline void p1920(uint64_t A[30], int b, int simd) {
    if (!RC_DONE) precompute_RC();
    for (int t = 0; t < 12; t++) {
        if (simd) {
            /* cols 0-3 打包：y[i] 的 4 lane = A[5i+0..3] */
            __m256i y[6], o[6];
            for (int i = 0; i < 6; i++)
                y[i] = _mm256_set_epi64x((long long)A[5*i+3], (long long)A[5*i+2],
                                         (long long)A[5*i+1], (long long)A[5*i+0]);
            MRM_SIMD(y, o);
            for (int i = 0; i < 6; i++) {
                uint64_t tmp[4]; _mm256_storeu_si256((__m256i *)tmp, o[i]);
                A[5*i+0]=tmp[0]; A[5*i+1]=tmp[1]; A[5*i+2]=tmp[2]; A[5*i+3]=tmp[3];
            }
            /* col4 标量 */
            uint64_t o4[6];
            MRM_SCALAR(A[0+4],A[5+4],A[10+4],A[15+4],A[20+4],A[25+4], o4);
            A[4]=o4[0];A[9]=o4[1];A[14]=o4[2];A[19]=o4[3];A[24]=o4[4];A[29]=o4[5];
        } else {
            for (int j = 0; j < 5; j++) {
                uint64_t o[6];
                MRM_SCALAR(A[0+j],A[5+j],A[10+j],A[15+j],A[20+j],A[25+j], o);
                A[0+j]=o[0];A[5+j]=o[1];A[10+j]=o[2];A[15+j]=o[3];A[20+j]=o[4];A[25+j]=o[5];
            }
        }
        for (int i = 0; i < 6; i++) sbox_row(A, i);
        /* K2 */
        uint64_t temp;
        temp=A[0];
        A[0]=A[27];A[27]=A[8];A[8]=A[3];A[3]=A[18];A[18]=A[4];A[4]=A[15];
        A[15]=A[13];A[13]=A[19];A[19]=A[1];A[1]=A[24];A[24]=A[17];A[17]=A[7];
        A[7]=A[6];A[6]=A[9];A[9]=temp;
        temp=A[2];
        A[2]=A[21];A[21]=A[26];A[26]=A[11];A[11]=A[25];A[25]=A[14];A[14]=A[16];
        A[16]=A[10];A[10]=A[28];A[28]=A[5];A[5]=A[12];A[12]=A[22];A[22]=A[23];
        A[23]=A[20];A[20]=A[29];A[29]=temp;
        for (int j = 0; j < 5; j++) A[j] ^= RC_TAB[(b-1)*60 + 5*t + j];
    }
}

static inline void taichi_step(uint64_t S[RATE_WORDS], uint64_t L[CAPACITY_WORDS],
                               uint64_t R[CAPACITY_WORDS], uint64_t M[RATE_WORDS],
                               int D) {
    uint64_t state[30] = {0};
    uint64_t B[CAPACITY_WORDS] = {0};
    for (int i = 0; i < RATE_WORDS; i++) state[i] = S[i] ^ M[i];
    for (int i = 0; i < CAPACITY_WORDS; i++) state[RATE_WORDS + i] = L[i];
    state[29] ^= (uint64_t)D;
    p1920(state, 1, 1);
    memcpy(B, state + RATE_WORDS, CAPACITY_WORDS * sizeof(uint64_t));
    for (int i = 0; i < CAPACITY_WORDS; i++) state[RATE_WORDS + i] = R[i] ^ B[i];
    p1920(state, 2, 1);
    for (int i = 0; i < RATE_WORDS; i++) S[i] = state[i];
    for (int i = 0; i < CAPACITY_WORDS; i++) {
        L[i] = state[RATE_WORDS + i];
        R[i] = B[i] ^ state[RATE_WORDS + i];
    }
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest) {
    if (digest_len_bits != 512) return -1;
    uint64_t S[RATE_WORDS] = {0};
    uint64_t L[CAPACITY_WORDS] = {0};
    uint64_t R[CAPACITY_WORDS] = {0};
    uint64_t M[RATE_WORDS];

    unsigned long long full_blocks = msg_len_bits / RATE_BITS;
    unsigned long long total_blocks = (msg_len_bits + 2 + RATE_BITS - 1) / RATE_BITS;
    unsigned long long pad_blocks = total_blocks - full_blocks;

    for (unsigned long long i = 0; i < full_blocks; i++) {
        memcpy(M, msg + i * RATE_BYTES, RATE_BYTES);
        taichi_step(S, L, R, M, DOMAIN_AB);
    }
    if (pad_blocks > 0) {
        unsigned char last_buf[RATE_BYTES * 2] = {0};
        unsigned long long rem_bits = msg_len_bits % RATE_BITS;
        unsigned long long rem_bytes = rem_bits / 8;
        unsigned int rem_tail = (unsigned int)(rem_bits % 8);
        if (rem_bytes > 0 || rem_tail > 0) {
            memcpy(last_buf, msg + full_blocks * RATE_BYTES, rem_bytes + (rem_tail?1:0));
            if (rem_tail > 0) last_buf[rem_bytes] &= (unsigned char)(0xff << (8-rem_tail));
        }
        unsigned long long bp = rem_bits;
        last_buf[bp/8] |= (unsigned char)(1 << (7 - (bp%8))); bp++;
        while (((bp+1) % RATE_BITS) != 0) bp++;
        last_buf[bp/8] |= (unsigned char)(1 << (7 - (bp%8)));
        for (unsigned long long i = 0; i < pad_blocks; i++) {
            memcpy(M, last_buf + i * RATE_BYTES, RATE_BYTES);
            taichi_step(S, L, R, M, (i == pad_blocks-1) ? DOMAIN_FIN : DOMAIN_AB);
        }
    }
    memcpy(digest, S, DIGEST_BYTES);
    return 0;
}
