#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build TaiChi-512 base (fidelity check) and our variants.

Fidelity gate: the freshly built base .so must be byte-identical to the
registered `_overnight/l0/build/hash-25/taichi512/opt.so`.  If it is not, the
recipe is wrong and we stop — a wrong baseline makes every later number
meaningless.

usage: python3 _overnight/l0/taichi512/build512.py [base|ours|all]
"""
import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0)) if False else L0

OPT = os.path.join(L0, "taichi", "official", "TaiChi", "Implementations",
                   "Optimized_Implementation", "TaiChi-512-op-per")
REFD = os.path.join(L0, "taichi", "official", "TaiChi", "Implementations",
                    "Reference_Implementation", "TaiChi-512")
OUT = os.path.join(HERE, "out")
REG = os.path.join(L0, "build", "hash-25", "taichi512", "opt.so")

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build(name, src, extra=()):
    os.makedirs(OUT, exist_ok=True)
    so = os.path.join(OUT, name + ".so")
    if os.path.exists(so):
        os.remove(so)
    cmd = ["gcc"] + FLAGS + list(extra) + ["-shared", "-fPIC", "-o", so,
                                           "-I", OPT, "-I", REFD, src, "-lm"]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        print("BUILD FAIL %s rc=%d" % (name, p.returncode))
        print(p.stderr[:2000])
        return None
    if p.stderr.strip():
        print("BUILD WARN %s (%d bytes of stderr)" % (name, len(p.stderr)))
        print(p.stderr[:1500])
    print("%-12s %7d B  sha256 %s" % (name, os.path.getsize(so), sha(so)))
    return so


def main(argv):
    what = argv[1] if len(argv) > 1 else "all"

    if what in ("base", "all"):
        base = build("base", os.path.join(OPT, "CryptHash_AlgorithmInstance.c"))
        if not base:
            return 1
        b, r = sha(base), sha(REG)
        print("registered opt.so sha256 %s" % r)
        if b != r:
            print("FATAL: base .so 与在册 opt.so 不同 ⇒ 配方不可信，停止")
            return 1
        print("base == registered opt.so  ⇒ 配方复现成立")

    if what in ("ours", "all"):
        gen = os.path.join(HERE, "gen512.py")
        p = subprocess.run([sys.executable, gen], capture_output=True, text=True)
        print(p.stdout.strip() or p.stderr.strip())
        if p.returncode != 0:
            return p.returncode
        for mode in ("purec", "purec_pad", "rorx", "rorx_pad"):
            src = os.path.join(HERE, "src",
                               "CryptHash_AlgorithmInstance_%s.c" % mode)
            extra = ("-DTC_NO_BMI2",) if mode.startswith("purec") else ()
            so = build(mode, src, extra)
            if not so:
                return 1
        ours = os.path.join(OUT, "rorx_pad.so")
        dst = os.path.join(OUT, "ours_taichi512.so")
        with open(ours, "rb") as fi, open(dst, "wb") as fo:
            fo.write(fi.read())
        print("deliver      %7d B  sha256 %s" % (os.path.getsize(dst), sha(dst)))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
