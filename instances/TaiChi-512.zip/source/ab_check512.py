#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ab_check512.py —— TaiChi-512（h25）的等价性门（A1/A2）与负对照（A3）。

与 Laurus-512 那套的区别：TaiChi 的官方接口**真的**处理位级长度
（`CryptHash_AlgorithmInstance.c:236-245` 用 `rem_bits`/`rem_tail` 做位级掩码与置位），
所以这里可以、也必须要求 **4097/4097**，不存在 Laurus 那种「只判字节对齐子集」。

A1 全量官方 KAT：
    A1a 阳性对照：官方 Reference 必须 4097/4097（先证明 KAT 与装置本身没错）
    A1b base（按官方旗标重编的 opt）必须 4097/4097
    A1c ours 必须 4097/4097，且逐条摘要与 base 相同

A2 位长扫描：0..1023 每个位长各一条伪随机消息，ours 与 base 摘要逐字节相同。
    这一条覆盖 KAT 里稀疏的位长（KAT 主要是 8 的倍数），是「两处改写语义等价」的
    直接证据，且不依赖 KAT 文件。

A3 负对照：
    n1_pad_open   把填充闭式改回「逐位加一」的前半步（少加 1）—— 必须变红
    n2_rot_wrong  把 rorx 的旋转量偏移 1（ROTL64 语义改变）—— 必须变红
    n3_rot_scalar 把 rorx 换回纯 C 旋转（语义等价，负-负对照）—— 必须保持绿

用法：python3 ab_check512.py [--skip-negctl]
"""
import ctypes
import hashlib
import os
import pickle
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, L0)
import _kat_full as KF  # noqa: E402
import build512 as B  # noqa: E402

OUT = os.path.join(HERE, "out")
OURS = os.path.join(OUT, "ours_taichi512.so")
BASE = os.path.join(OUT, "base.so")
REF = os.path.join(L0, "build", "hash-25", "taichi512", "ref.so")
KAT = os.path.join(L0, "src", "hash-25", "TaiChi", "Test_Vectors",
                   "KAT_2_12_TaiChi-512.txt")
UNI = os.path.join(HERE, "src")
NEGDIR = os.path.join(HERE, "variants")

DG_BITS = 512


def digest(lib, msg, msg_bits):
    """在子进程里调一次 CryptHash，返回 (rc, hex)（崩溃返回 None）。"""
    rfd, wfd = os.pipe()
    pid = os.fork()
    if pid == 0:
        os.close(rfd)
        try:
            dll = ctypes.CDLL(os.path.abspath(lib))
            fn = dll.CryptHash
            fn.restype = ctypes.c_int
            fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_ulonglong,
                           ctypes.c_char_p]
            n = DG_BITS // 8
            buf = ctypes.create_string_buffer(n + 16)
            rc = fn(DG_BITS, msg, ctypes.c_ulonglong(msg_bits), buf)
            res = (rc, buf.raw[:n].hex())
        except BaseException as exc:  # noqa: BLE001
            res = (-1, "exception: %r" % (exc,))
        with os.fdopen(wfd, "wb") as fh:
            pickle.dump(res, fh)
        os._exit(0)
    os.close(wfd)
    with os.fdopen(rfd, "rb") as fh:
        data = fh.read()
    os.waitpid(pid, 0)
    if not data:
        return None
    return pickle.loads(data)


def pseudo_msg(bits):
    nbytes = (bits + 7) // 8
    return bytes(((i * 131 + 17) & 0xFF) for i in range(nbytes))


def kat_check(lib, recs, label):
    n, match, first, err = KF.check_all(lib, recs)
    print("  %-22s %d/%d %s" % (label, match, n, "PASS" if match == n else "FAIL"))
    if err:
        print("      err=%s" % (err,))
    if first:
        print("      first_bad=%s" % (first,))
    return match == n


def scan(lib_a, lib_b, bits_list, label):
    same, diffs = 0, []
    for bits in bits_list:
        msg = pseudo_msg(bits)
        ra = digest(lib_a, msg, bits)
        rb = digest(lib_b, msg, bits)
        if ra is None or rb is None:
            diffs.append((bits, "crash", ra, rb))
            continue
        if ra[0] != 0 or rb[0] != 0:
            diffs.append((bits, "rc", ra[0], rb[0]))
            continue
        if ra[1] == rb[1]:
            same += 1
        else:
            diffs.append((bits, "digest", ra[1][:16], rb[1][:16]))
    print("  %-22s same %d / %d   diff %d" % (label, same, len(bits_list), len(diffs)))
    for d in diffs[:5]:
        print("      ! %s" % (d,))
    return same == len(bits_list), diffs


def sha(p):
    with open(p, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


PAD_CLOSED = """        {
            unsigned long long pad_rem = bit_pos % RATE_BITS;
            if (pad_rem != (RATE_BITS - 1ULL))
                bit_pos += (RATE_BITS - 1ULL) - pad_rem;
        }"""

PAD_OFF_BY_ONE = """        {
            unsigned long long pad_rem = bit_pos % RATE_BITS;
            if (pad_rem != (RATE_BITS - 1ULL))
                bit_pos += (RATE_BITS - 1ULL) - pad_rem - 1ULL;
        }"""

RORX_CALL = "# define ROTL64(x, n) tc_rorx64((x), (unsigned int)(64U - (unsigned int)(n)))"
RORX_SHIFTED = "# define ROTL64(x, n) tc_rorx64((x), (unsigned int)(65U - (unsigned int)(n)))"
ROTL_SCALAR = "# define ROTL64(x, n) ((x) << (n) | (x) >> ((64U - (unsigned int)(n)) & 63))"


def build_variant(name, src_path, old, new, what):
    txt = open(src_path, "r", encoding="utf-8").read()
    if txt.count(old) != 1:
        print("  [%s] 锚点不在（找到 %d 次）—— 负对照无效" % (name, txt.count(old)))
        return None
    d = os.path.join(NEGDIR, name)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "CryptHash_AlgorithmInstance.c")
    with open(p, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(txt.replace(old, new))
    print("  [%s] %s" % (name, what))
    return B.build("neg_" + name, p)


def main(argv):
    skip_neg = "--skip-negctl" in argv

    if not os.path.exists(BASE):
        print("base.so 不存在，先跑 build512.py base")
        return 1
    if not os.path.exists(OURS):
        print("ours_taichi512.so 不存在，先跑 build512.py ours")
        return 1

    recs = KF.parse_all(KAT)
    print("KAT %s ⇒ %d 条" % (os.path.basename(KAT), len(recs)))
    print("[A1] 全量 KAT（4097 条，TaiChi 接口本身按位处理，无对齐限制）")
    a1a = kat_check(REF, recs, "ref（阳性对照）")
    a1b = kat_check(BASE, recs, "base（官方旗标重编）")
    a1c = kat_check(OURS, recs, "ours（交付件）")

    print("[A2] 位长扫描 0..1023（ours vs base 逐字节）")
    a2, _ = scan(OURS, BASE, list(range(0, 1024)), "ours vs base")

    ok = a1a and a1b and a1c and a2
    if not ok:
        print("=> FAIL（A1a=%s A1b=%s A1c=%s A2=%s）" % (a1a, a1b, a1c, a2))
        return 2

    if skip_neg:
        print("=> A1/A2 全过（跳过 A3）")
        return 0

    print("[A3] 负对照（A2 必须按预期变色）")
    src_pad = os.path.join(UNI, "CryptHash_AlgorithmInstance_rorx_pad.c")
    src_rot = os.path.join(UNI, "CryptHash_AlgorithmInstance_rorx.c")

    negs = []
    n1 = build_variant("n1_pad_off_by_one", src_pad, PAD_CLOSED, PAD_OFF_BY_ONE,
                       "填充闭式少加 1（应红）")
    negs.append(("n1_pad_off_by_one", n1, False))
    n2 = build_variant("n2_rot_shifted", src_rot, RORX_CALL, RORX_SHIFTED,
                       "rorx 旋转量偏 1（应红）")
    negs.append(("n2_rot_shifted", n2, False))
    n3 = build_variant("n3_rot_scalar", src_rot, RORX_CALL, ROTL_SCALAR,
                       "rorx 换回纯 C 旋转（语义等价，应保持绿）")
    negs.append(("n3_rot_scalar", n3, True))

    allok = True
    for name, so, want_green in negs:
        if not so:
            allok = False
            continue
        print("    %-20s %d B sha256 %s" % (name, os.path.getsize(so), sha(so)))
        green, diffs = scan(so, BASE, list(range(0, 1024)), "%s vs base" % name)
        if want_green:
            verdict = "OK（期望保持绿）" if green else "BAD（本应等价却变色）"
        else:
            verdict = "OK（期望变红）" if not green else "BAD（扰动未被发现）"
        if (want_green and not green) or (not want_green and green):
            allok = False
        print("      判定：%s" % verdict)

    print("=> ALL PASS（A1 全量 KAT / A2 位长扫描 / A3 负对照三件）" if allok
          else "=> A3 FAIL")
    return 0 if allok else 3


if __name__ == "__main__":
    sys.exit(main(sys.argv))
