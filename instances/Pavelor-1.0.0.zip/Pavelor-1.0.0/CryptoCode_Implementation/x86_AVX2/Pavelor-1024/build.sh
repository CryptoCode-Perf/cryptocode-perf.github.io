#!/usr/bin/env bash
# rebuild Pavelor-1024 with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o Pavelor-1024.so unroll_k8.c
sha256sum Pavelor-1024.so
