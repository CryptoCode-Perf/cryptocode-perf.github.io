# AXIS-768

Algorithm: AXIS | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header AXIS-768.h, prebuilt AXIS-768.so,
KAT vector KAT_2_12_AXIS-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 8f4a4398db2b5c83f9f9ff5cde6eb913ae592754dab147f9d0170b15b42eb5e9
Speed (cpB, lower is faster): reference 100.80 / official-optimized 24.42 / optimized 12.40
Speedup: GM(S1-S8) 1.61x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
