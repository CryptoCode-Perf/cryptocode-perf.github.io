# C-HASH candidate package

Includes C-HASH-512 and C-HASH-1024. On x86-64 Linux with GCC, Python 3 and
AVX2, run `bash build_and_verify.sh`. It rebuilds official reference, official
optimized and CryptoCode implementations and runs full KAT, selected reference
differential and input/output guard-page tests.

The 512 candidate uses a wrapper and header recovered from the original
supplementary optimization material; origin records accompany those files.
Candidate only: performance comparison, release review and redistribution
permissions remain pending. Tests do not prove security.
