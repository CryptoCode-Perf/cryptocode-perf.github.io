#!/usr/bin/env python3
"""chash/build_chash.py -- build the C-HASH-1024 deliverable.

    python3 build_chash.py glue     # make glue_chash1024.c from the official Optimized source
    python3 build_chash.py build    # compile out/ours_chash1024.so (official ten flags, verbatim)
    python3 build_chash.py asm      # objdump the deliverable and count opcodes per symbol
    python3 build_chash.py all

The deliverable keeps the official Optimized c-hash.c verbatim except for the
two permutation entry points, whose bodies become calls into gen/ours_core.c.
No timing of any kind is performed anywhere in this file.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
WORK = os.path.abspath(os.path.join(L0, "..", ".."))

OTH = os.path.join(
    L0,
    "src/hash-03/C Hash/Others/"
    "另一份独立代码供参考，AI辅助完成，性能相当， 未在算法文档中体现",
    "Implementations",
)
REFDIR = os.path.join(OTH, "Reference_Implementation/C-HASH-1024")
OPTDIR = os.path.join(OTH, "Optimized_Implementation/C-HASH-1024")

REF_SRC = os.path.join(REFDIR, "c-hash.c")       # G1 reference (same-TU #include)
OPT_SRC = os.path.join(OPTDIR, "c-hash.c")       # skeleton for the deliverable
OPT_GLUE = os.path.join(OPTDIR, "CryptHash_AlgorithmInstance.c")

GLUE = os.path.join(HERE, "glue_chash1024.c")
CORE = os.path.join(HERE, "gen/ours_core.c")
OUTDIR = os.path.join(HERE, "out")
OUT = os.path.join(OUTDIR, "ours_chash1024.so")

# the official ten flags, verbatim (build2.json recipes for hash-03)
FLAGS = [
    "-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
    "-fomit-frame-pointer",
    "-std=c99", "-Wpedantic", "-Wall", "-Wextra",
]

FORWARD = """/* our paired-lane AVX2 core (chash/gen/ours_core.c) */
extern void chash_perm(const uint8_t *in, uint8_t *out);
extern void chash_perm_ff(const uint8_t *in, uint8_t *out);
"""


def replace_function(text, sig, new_text):
    """Replace the whole definition whose text starts at `sig` with new_text."""
    i = text.index(sig)
    b = text.index("{", i)
    depth = 0
    j = b
    while True:
        c = text[j]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                break
        j += 1
    return text[:i] + new_text + text[j + 1:]


def glue_text(text):
    """Take the official Optimized c-hash.c and forward the two permutation
    entry points into our core; everything else stays verbatim."""
    text = replace_function(
        text,
        "static inline void c_engine_permute(const uint8_t *in,uint8_t *out)",
        "static inline void c_engine_permute(const uint8_t *in,uint8_t *out){"
        "chash_perm(in,out);}",
    )
    text = replace_function(
        text,
        "static inline void c_engine_permute_ff(const uint8_t *in,uint8_t *out)",
        "static inline void c_engine_permute_ff(const uint8_t *in,uint8_t *out){"
        "chash_perm_ff(in,out);}",
    )
    # forward declarations, placed right after the last #include
    k = text.rindex("#include")
    eol = text.index("\n", k) + 1
    return text[:eol] + "\n" + FORWARD + text[eol:]


def make_glue():
    with open(OPT_SRC, encoding="latin-1") as f:
        text = f.read()
    out = glue_text(text)
    with open(GLUE, "w", encoding="latin-1", newline="\n") as f:
        f.write(out)
    print("glue <- %s" % OPT_SRC)
    print("glue %d -> %d bytes -> %s" % (len(text), len(out), GLUE))


def run(cmd):
    with open("/tmp/chash_build.log", "w") as log:
        r = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)
    with open("/tmp/chash_build.log", encoding="utf-8", errors="replace") as f:
        out = f.read()
    return r.returncode, out


def cmd_build():
    os.makedirs(OUTDIR, exist_ok=True)
    if not os.path.exists(GLUE):
        make_glue()
    cmd = ["gcc"] + FLAGS + [
        "-shared", "-fPIC",
        "-I", OPTDIR,
        "-o", OUT,
        GLUE, OPT_GLUE, CORE,
        "-lm",
    ]
    rc, out = run(cmd)
    print(out.rstrip())
    if rc != 0:
        raise SystemExit("gcc failed rc=%d" % rc)

    # gcc -shared does not diagnose unresolved symbols: check explicitly
    rc2, nm = run(["nm", "-D", "-u", OUT])
    bad = [l for l in nm.splitlines() if ("chash_perm" in l or "CryptHash" in l)]
    total = len([l for l in nm.splitlines() if l.strip()])
    print("未定义符号 %d 个；其中含 chash_perm/CryptHash 的 %d 个" % (total, len(bad)))
    if bad:
        for l in bad:
            print("  " + l)
        raise SystemExit("unresolved permutation symbol")

    st = os.stat(OUT)
    with open(OUT, "rb") as f:
        import hashlib
        h = hashlib.sha256(f.read()).hexdigest()
    print("build -> %s (%d B, sha256 %s)" % (OUT, st.st_size, h))


def cmd_asm():
    """objdump the deliverable; count opcodes for chash_perm* and the rest."""
    import collections
    import re

    log = "/tmp/chash_objdump.txt"
    with open(log, "w") as f:
        subprocess.run(["objdump", "-d", "--no-show-raw-insn", OUT], stdout=f)
    with open(log, encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()

    cur = None
    funcs = collections.OrderedDict()
    rx = re.compile(r"^[0-9a-f]+ <(.+)>:$")
    rx2 = re.compile(r"^\s+[0-9a-f]+:\s+([a-z0-9.]+)")
    for l in lines:
        m = rx.match(l)
        if m:
            cur = m.group(1)
            funcs.setdefault(cur, collections.Counter())
            continue
        if cur is None:
            continue
        m = rx2.match(l)
        if m:
            funcs[cur][m.group(1)] += 1

    # biggest functions first: LTO outlines and const-props the real bodies,
    # so filtering by the exported name alone would only show stubs.
    def p5of(v):
        return sum(v[m] for m in ("vpshufb", "vperm2i128", "vpalignr", "vpermq"))

    ranked = sorted(funcs.items(), key=lambda kv: -sum(kv[1].values()))
    print("%-34s %5s  %-9s  %s" % ("symbol", "insn", "p5-class", "top opcodes"))
    for k, v in ranked[:12]:
        tot = sum(v.values())
        if tot < 8:
            continue
        top = " ".join("%s:%d" % kv for kv in v.most_common(12))
        print("%-34s %5d  %-9d  %s" % (k[:34], tot, p5of(v), top))

    whole = collections.Counter()
    for v in funcs.values():
        whole.update(v)
    print("---- whole .text: %d insn, p5-class %d" % (sum(whole.values()), p5of(whole)))
    print("     " + " ".join("%s:%d" % kv for kv in whole.most_common(16)))


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    c = sys.argv[1]
    if c == "glue":
        make_glue()
    elif c == "build":
        cmd_build()
    elif c == "asm":
        cmd_asm()
    elif c == "all":
        make_glue()
        cmd_build()
        cmd_asm()
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
