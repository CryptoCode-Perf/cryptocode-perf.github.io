# C-HASH-1024

Algorithm: C-HASH | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header C-HASH-1024.h, prebuilt C-HASH-1024.so,
KAT vector KAT_2_12_CHash_1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 71a21553ebdcf9ebe36d8c8f7087cb69e7c35bc8340d2ba4507685ed65e9ee23
Speed (cpB, lower is faster): reference 675.48 / official-optimized 21.80 / optimized 17.91
Speedup: GM(S1-S8) 1.20x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
