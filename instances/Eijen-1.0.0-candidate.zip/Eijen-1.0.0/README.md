# Eijen candidate package

Instances: Eijen-256, Eijen-384, Eijen-512, Eijen-768, Eijen-1024.
On x86-64 Linux with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`.
This rebuilds three implementations per instance, checks 4097 known-answer
vectors each, compares deterministic long and boundary inputs, and tests
selected input/output guard-page boundaries. `CryptHash` takes input and digest
lengths in bits. Build uses -mtune=native and output varies by machine.

CryptoCode source comes from the current website candidate packages; the
local report has different implementations and remains to be compared under
the same controlled conditions. Candidate only: fastest-implementation
selection, source and license review, redistribution permission and final
release review remain pending. These tests do not prove security.
