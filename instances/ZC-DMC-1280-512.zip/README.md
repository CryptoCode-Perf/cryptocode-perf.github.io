# ZC-DMC-1280-512

Algorithm: ZC-DMC | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header ZC-DMC-1280-512.h, prebuilt ZC-DMC-1280-512.so,
KAT vector KAT_2_12_ZC-DMC-1280-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): be562d3b5a6e26262cc2457ae760bd9fa9eece93e0b855b29b1f1d2de649b2d5
Speed (cpB, lower is faster): reference 7.15 / official-optimized 5.58 / optimized 5.12
Speedup: GM(S1-S8) 1.08x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
