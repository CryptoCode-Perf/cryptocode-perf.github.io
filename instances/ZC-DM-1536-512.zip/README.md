# ZC-DM-1536-512

Algorithm: ZC-DM | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header ZC-DM-1536-512.h, prebuilt ZC-DM-1536-512.so,
KAT vector KAT_2_12_ZC-DM-1536-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 8411bf58fbca3300a78dd55b89f8b25ee933cc24b04da632aee4cd45bd776d05
Speed (cpB, lower is faster): reference 7.42 / official-optimized 4.54 / optimized 3.41
Speedup: GM(S1-S8) 1.53x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
