/*
 * MasterCube-1024 -- OUR AVX2 implementation (feilian/work/_overnight/l0/mastercube).
 *
 * Semantics derived from the official reference
 *   Optimized.../Reference_Implementation/MasterCube-1024/MasterCube-1024.c
 *   sha256 a532455e994a387ab47a3b4eaec3cad10f1b605cd28b6a328983dd7c7d3627c6  (405 lines)
 * Register layout / operand order cross-checked against the official optimized
 *   Optimized_Implementation/MasterCube-1024/MasterCube-1024.c
 *   sha256 27f432d4aa8dc800c5f3136c39a557be257e4981d6843955f052c83d0dc59e16  (521 lines)
 *
 * State layout: the 192-byte mc_state is held in 6 x __m256i.
 *   st[i] low  128-bit lane = row[2i]   (8 x uint16)
 *   st[i] high 128-bit lane = row[2i+1]
 *   halves.left  = rows 0..5   = st[0..2]
 *   halves.right = rows 6..11  = st[3..5]
 * This is exactly the mapping the official optimized version uses (its
 * union member pair64[6][4] aliases row[12][8]).
 */
#include <stdint.h>
#include <string.h>
#include <immintrin.h>

#define MC_ROUNDS        18
#define MC_BLOCK_BITS    448
#define MC_BLOCK_BYTES   56
#define MC_DIGEST_BITS   1024
#define MC_DIGEST_BYTES  128

/* ------------------------------------------------------------------ */
/* pad10*1 -- byte-for-byte the official pad10star1 (mastercube.h:16-31) */
static inline void mc_pad10star1(unsigned char *last_block, const int message_bits, const int block_bits)
{
    const int partial_bits = message_bits % 8;
    if (partial_bits != 0) {
        last_block[message_bits / 8] &= (uint8_t)(0xFFu << (8 - partial_bits));
    }
    last_block[message_bits / 8] |= (uint8_t)(0x80u >> partial_bits);
    last_block[(block_bits / 8) - 1] |= 0x01u;
}

/* ------------------------------------------------------------------ */
/* 16-bit lane rotate right by 8 = byte swap inside each uint16        */
static inline __m256i mc_ror8(__m256i x)
{
    return _mm256_shuffle_epi8(x, _mm256_setr_epi8(
        1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14,
        1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14));
}

#define MC_ROR16(x, n) _mm256_or_si256(_mm256_srli_epi16((x), (n)), \
                                       _mm256_slli_epi16((x), 16 - (n)))
/* n is always a literal here, so the ternary folds away completely. */
#define MC_ROT(x, n) ((n) == 0 ? (x) : ((n) == 8 ? mc_ror8(x) : MC_ROR16(x, n)))

/* ------------------------------------------------------------------ */
/* ShiftRows: left slice rotates each row left by i words, right slice  */
/* rotates right by i words (reference MasterCube-1024.c:55-88).        */
static inline void mc_shiftrows(__m256i *l, __m256i *r)
{
    l[0] = _mm256_shuffle_epi8(l[0], _mm256_setr_epi8(
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
        2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1));
    l[1] = _mm256_shuffle_epi8(l[1], _mm256_setr_epi8(
        4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3,
        6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5));
    l[2] = _mm256_shuffle_epi8(l[2], _mm256_setr_epi8(
        8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7,
        10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9));
    r[0] = _mm256_shuffle_epi8(r[0], _mm256_setr_epi8(
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
        14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
    r[1] = _mm256_shuffle_epi8(r[1], _mm256_setr_epi8(
        12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
        10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9));
    r[2] = _mm256_shuffle_epi8(r[2], _mm256_setr_epi8(
        8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7,
        6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5));
}

/* ------------------------------------------------------------------ */
/* AddConstant: reference XORs (c16[j] ^ rn) into row[0][j] (j<8).
   c[16] = {0x44,0x73,0x70,0x03, 0x2E,0x8A,0x19,0x13,
            0xD3,0x08,0xA3,0x85, 0x88,0x6A,0x3F,0x24}
   Precombined to 32-byte vectors (low 128 bits = c ^ rn, high = 0) so the
   whole step is one vpxor with a memory operand.                              */
static const uint64_t MC_RC[MC_ROUNDS][4] __attribute__((aligned(32))) = {
    { 0x13198A2E03707344ULL, 0x243F6A8885A308D3ULL, 0, 0 },
    { 0x13188A2F03717345ULL, 0x243E6A8985A208D2ULL, 0, 0 },
    { 0x131B8A2C03727346ULL, 0x243D6A8A85A108D1ULL, 0, 0 },
    { 0x131A8A2D03737347ULL, 0x243C6A8B85A008D0ULL, 0, 0 },
    { 0x131D8A2A03747340ULL, 0x243B6A8C85A708D7ULL, 0, 0 },
    { 0x131C8A2B03757341ULL, 0x243A6A8D85A608D6ULL, 0, 0 },
    { 0x131F8A2803767342ULL, 0x24396A8E85A508D5ULL, 0, 0 },
    { 0x131E8A2903777343ULL, 0x24386A8F85A408D4ULL, 0, 0 },
    { 0x13118A260378734CULL, 0x24376A8085AB08DBULL, 0, 0 },
    { 0x13108A270379734DULL, 0x24366A8185AA08DAULL, 0, 0 },
    { 0x13138A24037A734EULL, 0x24356A8285A908D9ULL, 0, 0 },
    { 0x13128A25037B734FULL, 0x24346A8385A808D8ULL, 0, 0 },
    { 0x13158A22037C7348ULL, 0x24336A8485AF08DFULL, 0, 0 },
    { 0x13148A23037D7349ULL, 0x24326A8585AE08DEULL, 0, 0 },
    { 0x13178A20037E734AULL, 0x24316A8685AD08DDULL, 0, 0 },
    { 0x13168A21037F734BULL, 0x24306A8785AC08DCULL, 0, 0 },
    { 0x13098A3E03607354ULL, 0x242F6A9885B308C3ULL, 0, 0 },
    { 0x13088A3F03617355ULL, 0x242E6A9985B208C2ULL, 0, 0 }
};

#define MC_ADDCONST(S, R) \
    ((S)[0] = _mm256_xor_si256((S)[0], \
        _mm256_load_si256((const __m256i *)(const void *)MC_RC[R])))

/* ------------------------------------------------------------------ */
#define MC_CROSSMIX(S) do {                                              \
    const __m256i mcc_a = _mm256_xor_si256((S)[0], (S)[3]);              \
    const __m256i mcc_b = _mm256_xor_si256((S)[1], (S)[4]);              \
    const __m256i mcc_c = _mm256_xor_si256((S)[2], (S)[5]);              \
    (S)[0] = _mm256_xor_si256(mcc_b, (S)[0]);                            \
    (S)[1] = _mm256_xor_si256(mcc_c, (S)[1]);                            \
    (S)[2] = _mm256_xor_si256(mcc_a, (S)[2]);                            \
    (S)[3] = _mm256_xor_si256(mcc_b, (S)[3]);                            \
    (S)[4] = _mm256_xor_si256(mcc_c, (S)[4]);                            \
    (S)[5] = _mm256_xor_si256(mcc_a, (S)[5]);                            \
} while (0)

#define MC_SWAPROWS(S) do {                                              \
    for (int mcs_i = 3; mcs_i < 6; ++mcs_i)                              \
        (S)[mcs_i] = _mm256_permute2x128_si256((S)[mcs_i], (S)[mcs_i], 0x01); \
} while (0)

#define MC_MANDR(L, R, A, B, G) do {                                     \
    for (int mcm_i = 0; mcm_i < 3; ++mcm_i) {                            \
        const __m256i mcm_x = (L)[mcm_i];                                \
        (R)[mcm_i] = _mm256_xor_si256(                                   \
            _mm256_xor_si256(                                            \
                _mm256_and_si256(MC_ROT(mcm_x, A), MC_ROT(mcm_x, B)),    \
                MC_ROT(mcm_x, G)),                                       \
            (R)[mcm_i]);                                                 \
    }                                                                    \
} while (0)

#define MC_MIXCOL(S) do {                                                \
    const __m256i mcx0 = _mm256_xor_si256((S)[1], (S)[2]);               \
    const __m256i mcx1 = _mm256_xor_si256((S)[0], (S)[2]);               \
    const __m256i mcx2 = _mm256_xor_si256((S)[0], mcx0);                 \
    (S)[0] = mcx0; (S)[1] = mcx1; (S)[2] = mcx2;                         \
    const __m256i mcy0 = _mm256_xor_si256((S)[3], (S)[5]);               \
    const __m256i mcy1 = _mm256_xor_si256((S)[4], (S)[5]);               \
    const __m256i mcy2 = _mm256_xor_si256((S)[4], mcy0);                 \
    (S)[3] = mcy0; (S)[4] = mcy1; (S)[5] = mcy2;                         \
} while (0)

#define MC_MIXROWS(S) do {                                               \
    for (int mcr_i = 0; mcr_i < 6; ++mcr_i) {                            \
        const __m256i mrx = (S)[mcr_i];                                  \
        (S)[mcr_i] = _mm256_xor_si256(                                   \
            _mm256_xor_si256(                                            \
                _mm256_shuffle_epi32(mrx, _MM_SHUFFLE(0, 3, 2, 1)), mrx),\
            _mm256_shuffle_epi32(mrx, _MM_SHUFFLE(2, 1, 0, 3)));         \
    }                                                                    \
} while (0)

static inline void mc_halfswap(__m256i *s)
{
    for (int i = 0; i < 3; ++i) {
        const __m256i t = s[i];
        s[i] = s[i + 3];
        s[i + 3] = t;
    }
}

/* one forward round (_core, reference :218-243).  R is the round index 0..8 */
#define MC_FWD_ROUND(S, R) do {                                          \
    MC_CROSSMIX(S); MC_SWAPROWS(S);                                      \
    MC_MANDR((S), (S) + 3, 0, 1, 8);                                     \
    MC_MANDR((S) + 3, (S), 14, 5, 0);                                    \
    MC_MANDR((S), (S) + 3, 9, 12, 8);                                    \
    MC_MANDR((S) + 3, (S), 14, 5, 0);                                    \
    MC_MANDR((S), (S) + 3, 0, 1, 8);                                     \
    MC_MANDR((S) + 3, (S), 8, 9, 0);                                     \
    MC_CROSSMIX(S); MC_SWAPROWS(S);                                      \
    MC_MIXCOL(S); mc_shiftrows((S), (S) + 3); MC_MIXROWS(S);             \
    MC_ADDCONST(S, R);                                                   \
} while (0)

/* one inverse round (_core_inverse, reference :245-277). R is i+9 */
#define MC_INV_ROUND(S, R) do {                                          \
    MC_ADDCONST(S, R);                                                   \
    MC_MIXROWS(S);                                                       \
    mc_shiftrows((S) + 3, (S));                                          \
    MC_MIXCOL(S);                                                        \
    MC_SWAPROWS(S); MC_CROSSMIX(S);                                      \
    MC_MANDR((S) + 3, (S), 8, 9, 0);                                     \
    MC_MANDR((S), (S) + 3, 0, 1, 8);                                     \
    MC_MANDR((S) + 3, (S), 14, 5, 0);                                    \
    MC_MANDR((S), (S) + 3, 9, 12, 8);                                    \
    MC_MANDR((S) + 3, (S), 14, 5, 0);                                    \
    MC_MANDR((S), (S) + 3, 0, 1, 8);                                     \
    mc_halfswap(S);                                                      \
    MC_SWAPROWS(S); MC_CROSSMIX(S);                                      \
} while (0)

/* zip_prf (reference :279-293): 9 forward rounds on state, 9 inverse rounds
   on a copy, then cellwise XOR. */
static inline void mc_zip(__m256i *st)
{
    __m256i cp[6];
    for (int i = 0; i < 6; ++i) cp[i] = st[i];

    for (int i = 0; i < MC_ROUNDS / 2; ++i) {
        MC_FWD_ROUND(st, i);
        /* _core_inverse(copy, 9) walks its own i from 8 down to 0 and uses
           AddConstant(state, i + 9)  ->  constants 17, 16, ... , 9. */
        MC_INV_ROUND(cp, MC_ROUNDS - 1 - i);
    }

    for (int i = 0; i < 6; ++i) st[i] = _mm256_xor_si256(st[i], cp[i]);
}

/* 56-byte block tail: bytes 32..55 go into the low 24 bytes of the lane */
static inline __m256i mc_loadu_tail24(const unsigned char *p)
{
    return _mm256_inserti128_si256(
        _mm256_castsi128_si256(_mm_loadu_si128((const __m128i *)(const void *)p)),
        _mm_loadl_epi64((const __m128i *)(const void *)(p + 16)), 1);
}

static inline void mc_load_state(__m256i *st, const unsigned char *p)
{
    for (int i = 0; i < 6; ++i)
        st[i] = _mm256_loadu_si256((const __m256i *)(const void *)(p + 32 * i));
}

static inline void mc_store_state(unsigned char *p, const __m256i *st)
{
    for (int i = 0; i < 6; ++i)
        _mm256_storeu_si256((__m256i *)(void *)(p + 32 * i), st[i]);
}

/* ------------------------------------------------------------------ */
static void mc_absorb(__m256i *st, const unsigned char *message, const uint64_t message_bits)
{
    for (int i = 0; i < 6; ++i) st[i] = _mm256_setzero_si256();

    const uint64_t n_block    = message_bits / MC_BLOCK_BITS;
    const uint64_t msg_bytes  = (message_bits + 7) / 8;
    const uint64_t last_index = n_block * MC_BLOCK_BYTES;
    const uint64_t last_bytes = msg_bytes - last_index;

    unsigned char last[MC_BLOCK_BYTES];
    if (last_bytes) memcpy(last, message + last_index, (size_t)last_bytes);
    memset(last + last_bytes, 0, MC_BLOCK_BYTES - (size_t)last_bytes);
    mc_pad10star1(last, (int)(message_bits % MC_BLOCK_BITS), MC_BLOCK_BITS);

    for (uint64_t i = 0; i < n_block; ++i) {
        const unsigned char *p = message + MC_BLOCK_BYTES * i;
        st[0] = _mm256_xor_si256(st[0], _mm256_loadu_si256((const __m256i *)(const void *)p));
        st[1] = _mm256_xor_si256(st[1], mc_loadu_tail24(p + 32));
        mc_zip(st);
    }

    st[0] = _mm256_xor_si256(st[0], _mm256_loadu_si256((const __m256i *)(const void *)last));
    st[1] = _mm256_xor_si256(st[1], mc_loadu_tail24(last + 32));
    mc_zip(st);
}

/* digest_bits = 1024, block_bits = 448 -> 56 + 56 + 16 bytes = two transforms */
static void mc_squeeze(__m256i *st, unsigned char *digest)
{
    _mm256_storeu_si256((__m256i *)(void *)(digest + 0), st[0]);
    _mm_storeu_si128((__m128i *)(void *)(digest + 32), _mm256_castsi256_si128(st[1]));
    _mm_storel_epi64((__m128i *)(void *)(digest + 48), _mm256_extracti128_si256(st[1], 1));

    mc_zip(st);

    _mm256_storeu_si256((__m256i *)(void *)(digest + 56), st[0]);
    _mm_storeu_si128((__m128i *)(void *)(digest + 88), _mm256_castsi256_si128(st[1]));
    _mm_storel_epi64((__m128i *)(void *)(digest + 104), _mm256_extracti128_si256(st[1], 1));

    mc_zip(st);

    _mm_storeu_si128((__m128i *)(void *)(digest + 112), _mm256_castsi256_si128(st[0]));
}

/* ------------------------------------------------------------------ */
int MasterCube1024_plain(const unsigned char *message, unsigned long long message_bit_len,
                         unsigned char *digest)
{
    __m256i st[6];
    mc_absorb(st, message, (uint64_t)message_bit_len);
    mc_squeeze(st, digest);
    return 0;
}

int MasterCube1024_avx2(const unsigned char *message, unsigned long long message_bit_len,
                        unsigned char *digest)
{
    return MasterCube1024_plain(message, message_bit_len, digest);
}

int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits,
              unsigned char *digest)
{
    if (digest_len_bits != MC_DIGEST_BITS) return 1;
    if (digest == 0) return 1;
    if (msg == 0 && msg_len_bits != 0) return 1;
    return MasterCube1024_plain(msg, msg_len_bits, digest);
}

/* ------------------------------------------------------------------ */
#ifdef MC_TEST_HOOKS
void mc_hook_zip(unsigned char *state)
{
    __m256i st[6];
    mc_load_state(st, state);
    mc_zip(st);
    mc_store_state(state, st);
}

/* n forward rounds, round indices 0,1,...,n-1 -- compares against ref__core(s, n).
   NOTE: the bodies must run in ASCENDING order, so this is an explicit loop with
   a per-index switch; a downward fall-through switch would run them backwards. */
void mc_hook_core_fwd(unsigned char *state, int n)
{
    __m256i st[6];
    mc_load_state(st, state);
    for (int i = 0; i < n && i < MC_ROUNDS / 2; ++i) {
        switch (i) {
        case 0: MC_FWD_ROUND(st, 0); break;
        case 1: MC_FWD_ROUND(st, 1); break;
        case 2: MC_FWD_ROUND(st, 2); break;
        case 3: MC_FWD_ROUND(st, 3); break;
        case 4: MC_FWD_ROUND(st, 4); break;
        case 5: MC_FWD_ROUND(st, 5); break;
        case 6: MC_FWD_ROUND(st, 6); break;
        case 7: MC_FWD_ROUND(st, 7); break;
        case 8: MC_FWD_ROUND(st, 8); break;
        default: break;
        }
    }
    mc_store_state(state, st);
}

/* n inverse rounds, constants (n-1+9), (n-2+9), ... , 9 -- compares against
   ref__core_inverse(s, n) (_core_inverse walks its own i from n-1 down to 0). */
void mc_hook_core_inv(unsigned char *state, int n)
{
    __m256i st[6];
    mc_load_state(st, state);
    for (int k = n - 1; k >= 0; --k) {
        switch (k) {
        case 0: MC_INV_ROUND(st, 9);  break;
        case 1: MC_INV_ROUND(st, 10); break;
        case 2: MC_INV_ROUND(st, 11); break;
        case 3: MC_INV_ROUND(st, 12); break;
        case 4: MC_INV_ROUND(st, 13); break;
        case 5: MC_INV_ROUND(st, 14); break;
        case 6: MC_INV_ROUND(st, 15); break;
        case 7: MC_INV_ROUND(st, 16); break;
        case 8: MC_INV_ROUND(st, 17); break;
        default: break;
        }
    }
    mc_store_state(state, st);
}
#endif
