# MasterCube candidate package

Instances: MasterCube-512, MasterCube-768 and MasterCube-1024. On x86-64
Linux with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`. It rebuilds
reference, official optimized and CryptoCode implementations, checks 4097
known-answer vectors per implementation, compares deterministic long and
boundary inputs, and checks selected input/output guard pages. `CryptHash`
lengths are in bits.

GCC may warn that the official optimized 1024-bit implementation passes a
56-byte block to a function declared with an array parameter of 136 bytes.
The parameter is a pointer in C and the inspected accesses use the 56-byte
logical block length, but independent review is still required.

CryptoCode C sources were recovered from the local performance report.
Candidate only: controlled performance comparison, independent source and
license review, redistribution permission and final release review remain
pending. Tests do not prove security.
