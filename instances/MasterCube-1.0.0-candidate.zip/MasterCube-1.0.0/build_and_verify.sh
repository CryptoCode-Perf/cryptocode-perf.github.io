#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")";mkdir -p build
for bits in 512 768 1024; do
 ref="Reference_Implementation/MasterCube-$bits";opt="Optimized_Implementation/MasterCube-$bits";own="CryptoCode_Implementation/MasterCube-$bits"
 gcc -O2 -fPIC -shared -Wl,-z,defs -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" "$ref/MasterCube-$bits.c" -o "build/Reference-$bits.so"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" "$opt/CryptHash_AlgorithmInstance.c" "$opt/MasterCube-$bits.c" -o "build/Optimized-$bits.so"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs "$own/implementation.c" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/MasterCube-$bits.txt";done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 768 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits";done;done
