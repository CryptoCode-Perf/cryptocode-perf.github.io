# AFS-TrEDM-1024

Algorithm: AFS-TrEDM | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header AFS-TrEDM-1024.h, prebuilt AFS-TrEDM-1024.so,
KAT vector KAT_2_12_AFS-TrEDM-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): eaf4dfd0f466e04fe899acf411feaefa4e80b9c0e5dfe7c5e33726b3ca7354e8
Speed (cpB, lower is faster): reference 409.83 / official-optimized 39.15 / optimized 32.73
Speedup: GM(S1-S8) 1.20x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
