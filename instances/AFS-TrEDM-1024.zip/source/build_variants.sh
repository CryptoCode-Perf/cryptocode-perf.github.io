#!/usr/bin/env bash
# Build our AFS-TrEDM-1024 variants (and their negative controls) with the
# EXACT official performance-optimized command line recorded in
#   l0/build/logs/hash-01__afstredm1024__opt.log
#
# Every variant keeps the SAME source-file ORDER on the command line; under
# -flto the LTO partition order lands in the artifact, so reordering sources
# alone changes the sha256 (lesson carried over from rorx_retrofit).
#
# Nothing outside afsedm/ is read or written except the read-only official
# tree we extracted ourselves.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
L0="$(cd "$HERE/.." && pwd)"
SHIM="$L0/scripts/shim"
AFS="$HERE/official/AFS-TrEDM/Implementations"

REF1024="$AFS/Reference_Implementation/AFS-TrEDM-1024"
OPT1024="$AFS/Optimized_Implementation/AFS-TrEDM-1024"
S6="$AFS/Optimized_Implementation/common/s6"
GEN="$S6/generated"

OUT="$HERE/out"
LOG="$HERE/logs"
mkdir -p "$OUT" "$LOG"

# Official performance-optimized flags, verbatim (ten flags + the three -D that
# the official AVX2/opt64 profile defines in its own Makefile).
FLAGS=(
  -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
  -std=c99 -Wpedantic -Wall -Wextra
  -DAFS_TREDM_OPT64_PORTABLE=1
  -DAFS_TREDM_USE_AVX2=1
  -DAFS_TREDM_S6_CANONICAL_AVX2=1
)

INCS=(-I"$SHIM" -I"$REF1024" -I"$OPT1024" -I"$S6" -I"$GEN")

build() {
  local name="$1"; shift
  local src="$1"; shift
  local extrasrc="$1"; shift
  local out="$OUT/$name.so"
  local log="$LOG/$name.build.log"
  local ex=()
  [ -n "$extrasrc" ] && ex=("$extrasrc")
  rm -f "$out"
  # Exact official source-file order for every variant; the extra source (when
  # present) is appended last, which is where the official line puts
  # afs_lmds1600_s6_opt64.c.
  gcc "${FLAGS[@]}" "$@" "${INCS[@]}" -shared -fPIC -Wl,--no-undefined \
      -o "$out" \
      "$REF1024/CryptHash_AlgorithmInstance.c" \
      "$OPT1024/afs_tredm.c" \
      "$src" \
      "$OPT1024/afs_sbox64.c" \
      "${ex[@]}" \
      -lm 2>"$log"
  if [ -s "$log" ]; then
    echo "FAIL($name): compiler produced output:"
    cat "$log"
    exit 1
  fi
  printf '%-14s %7d B  ' "$name" "$(stat -c%s "$out")"
  sha256sum "$out" | cut -d' ' -f1
}

echo "=== official-source sanity build (must match the opponent byte for byte) ==="
build base "$OPT1024/afs_p1600.c" "$S6/afs_lmds1600_s6_opt64.c"

echo "=== our variants ==="
build inl          "$HERE/src/uni/afs_p1600_inl.c"  ""
build rorx         "$HERE/src/uni/afs_p1600_rorx.c" ""
build rorx0        "$HERE/src/uni/afs_p1600_rorx0.c" ""
build inlai        "$HERE/src/uni/afs_p1600_inlai.c" ""
build rorx_no_bmi2 "$HERE/src/uni/afs_p1600_rorx.c" "" -DAFS_NO_BMI2=1

echo "=== delivered artifact (same source as 'inl') ==="
build ours_afstredm1024 "$HERE/src/uni/afs_p1600_inl.c" ""

echo "=== negative controls (same source order) ==="
build inl_noop   "$HERE/src/neg/afs_p1600_inl_noop.c"  ""
build rorx_noop  "$HERE/src/neg/afs_p1600_rorx_noop.c" ""
build inl_const  "$HERE/src/neg/afs_p1600_inl_const.c"  ""
build rorx_const "$HERE/src/neg/afs_p1600_rorx_const.c" ""

echo
echo "A/B check 1  rorx vs rorx_no_bmi2 (expect same sha as 'inl'):"
sha256sum "$OUT/inl.so" "$OUT/rorx_no_bmi2.so"
echo "A/B check 2  noop controls (expect same sha as their variant):"
sha256sum "$OUT/inl.so" "$OUT/inl_noop.so" "$OUT/rorx.so" "$OUT/rorx_noop.so"
echo
echo "=== rotate census ==="
for f in "$OUT"/*.so; do
  printf '%-24s ' "$(basename "$f")"
  objdump -d --no-show-raw-insn "$f" \
    | awk '{print $2}' \
    | grep -cE '^(rol|ror|rorx)$' | tr -d '\n'
  echo ""
done
