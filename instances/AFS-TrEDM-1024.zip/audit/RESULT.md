# AFS-TrEDM — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| AFS-TrEDM-1024 | `AFS-TrEDM-1024.so` | 52560 B | `eaf4dfd0f466e04fe899acf411feaefa4e80b9c0e5dfe7c5e33726b3ca7354e8` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| AFS-TrEDM-1024 | 1024 | 409.8301 | 39.147 | 32.734721 | 1.195886 | 1.1973 |

## 优化方法（逐实例原文，来自交付清单）

### AFS-TrEDM-1024
官方 `afs_p1600.c` 把 LMDS 线性层交给非 inline 的 `afs_lmds1600_s6_opt64(A, round)`（`:253`）：该函数靠 `round % 6` 选选择子、经 PLT 调实现，25 条 lane 每次跨函数边界全部溢出；而 24 个调用点的轮号全是编译期常量。改成 `static inline` 后动态指令数 62328 → 52134（−16.4%）。**只对 1024 档成立**：同一份 inl 源套到 512/768 反而慢 4.93% / 5.45%（判负，不入表）。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。
