# AFS-TrEDM — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## AFS-TrEDM-1024
- 摘要位：1024；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/AFS-TrEDM-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/AFS-TrEDM-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/AFS-TrEDM-1024/`
- 优化要点：官方 `afs_p1600.c` 把 LMDS 线性层交给非 inline 的 `afs_lmds1600_s6_opt64(A, round)`（`:253`）：该函数靠 `round % 6` 选选择子、经 PLT 调实现，25 条 lane 每次跨函数边界全部溢出；而 24 个调用点的轮号全是编译期常量。改成 `static inline` 后动态指令数 62328 → 52134（−16.4%）。**只对 1024 档成立**：同一份 inl 源套到 512/768 反而慢 4.93% / 5.45%（判负，不入表）。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。
