/*
 * JuziHash reference implementation (single-file, ISO C style).
 *
 * This file is self-contained. It implements the 24-round 2048-bit Juzi
 * permutation and one JuziHash instance. The public hash function accepts the
 * message length in bits; valid inputs satisfy 0 <= msg_bitlen < 2^64.
 *
 * Padding: M || 0^z || Len_1024(len), where z=(-len) mod 1024 and
 * Len_1024(len)=0^960 || enc64_be(len).
 *
 * Vectorized variant: each 32-byte state row is one AVX2 lane. The S4 nibble
 * S-box is applied with vpshufb (3 lookups per 32 bytes), the 4x4 GF(2^8) MDS
 * with byte add/compare/and, and the three round byte-permutation modes with
 * in-lane vpshufb (4-byte and 16-byte rotations) or vperm2i128 (64-byte pair
 * rotations). The six per-group round-constant snapshots are hoisted out of
 * the round loop.
 *
 * The permutation body keeps the eight rows in eight named vector locals for
 * the whole 24-round loop (no row array, no address-taking helper calls), and
 * the per-mode byte permutations use precomputed constant shuffle masks. The
 * message rate rows are absorbed directly from the caller's block pointer, so
 * a full data block is never copied into a temporary buffer.
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <immintrin.h>
#include "CryptHash_AlgorithmInstance.h"

#define JUZI_STATE_BYTES  256u
#define JUZI_BLOCK_BYTES  128u
#define JUZI512_DIGEST_BYTES   64u
#define JUZI1024_DIGEST_BYTES 128u

static void juzi_store64_be(uint8_t b[8], uint64_t x)
{
    b[0] = (uint8_t)(x >> 56);
    b[1] = (uint8_t)(x >> 48);
    b[2] = (uint8_t)(x >> 40);
    b[3] = (uint8_t)(x >> 32);
    b[4] = (uint8_t)(x >> 24);
    b[5] = (uint8_t)(x >> 16);
    b[6] = (uint8_t)(x >>  8);
    b[7] = (uint8_t)x;
}

static uint64_t juzi_data_block_count(uint64_t bitlen)
{
    return (bitlen / 1024u) + ((bitlen % 1024u) != 0u);
}

static void juzi_make_data_block(const uint8_t *msg, uint64_t bitlen,
                                 uint64_t block_index,
                                 uint8_t block[JUZI_BLOCK_BYTES])
{
    const uint64_t start_bit = block_index * 1024u;
    uint64_t rem_bits;

    memset(block, 0, JUZI_BLOCK_BYTES);
    if (start_bit >= bitlen) {
        return;
    }

    rem_bits = bitlen - start_bit;
    if (rem_bits >= 1024u) {
        memcpy(block, msg + block_index * JUZI_BLOCK_BYTES, JUZI_BLOCK_BYTES);
        return;
    }

    if (rem_bits >= 8u) {
        const size_t full_bytes = (size_t)(rem_bits / 8u);
        memcpy(block, msg + block_index * JUZI_BLOCK_BYTES, full_bytes);
    }
    if ((rem_bits % 8u) != 0u) {
        const size_t full_bytes = (size_t)(rem_bits / 8u);
        const unsigned int keep = (unsigned int)(rem_bits % 8u);
        const uint8_t mask = (uint8_t)(0xffu << (8u - keep));
        block[full_bytes] = (uint8_t)(msg[block_index * JUZI_BLOCK_BYTES + full_bytes] & mask);
    }
}

static void juzi_make_length_block(uint64_t bitlen,
                                   uint8_t block[JUZI_BLOCK_BYTES])
{
    memset(block, 0, JUZI_BLOCK_BYTES);
    juzi_store64_be(block + JUZI_BLOCK_BYTES - 8u, bitlen);
}

/* 0x1b reduction polynomial as a constant vector.  Keeping it in .rodata lets
 * the vpand consume it as a memory operand, so no per-round broadcast or
 * dedicated YMM register is needed inside the tight MDS. */
static const uint8_t jz_polyb[32] = {
    0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b,
    0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b,
    0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b,
    0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b, 0x1b
};

/* Second half of the S4 layer, folded into a single table.
 *
 * With T = S4 the layer is
 *   b1 = h ^ T[l],  b2 = l ^ T[b1],  b3 = b1 ^ T[b2],  out = (b2 << 4) | b3.
 * b1 <= 15, so (b2 << 4) and b3 occupy disjoint nibbles; replacing the OR by
 * XOR is exact and lets the shift be folded into the table
 *   out = b1 ^ ((b2 << 4) ^ T[b2]) = b1 ^ V[b2],  V[x] = (x << 4) ^ T[x].
 * That removes the per-row 16-bit shift and the OR (2 of the 11 vector ops)
 * while keeping the same three 1-uop vpshufb lookups.  V is a fixed public
 * 16-entry table replicated into both 128-bit lanes. */
static const uint8_t jz_vtab[32] = {
    0x09, 0x10, 0x24, 0x3b, 0x4d, 0x5c, 0x63, 0x7f,
    0x81, 0x9a, 0xa2, 0xb6, 0xc7, 0xd5, 0xe8, 0xfe,
    0x09, 0x10, 0x24, 0x3b, 0x4d, 0x5c, 0x63, 0x7f,
    0x81, 0x9a, 0xa2, 0xb6, 0xc7, 0xd5, 0xe8, 0xfe
};

#define JUZI_XTIME(x)                                                        \
    _mm256_xor_si256(                                                        \
        _mm256_add_epi8((x), (x)),                                           \
        _mm256_and_si256(                                                    \
            _mm256_cmpgt_epi8(_mm256_setzero_si256(), (x)),                  \
            _mm256_loadu_si256((const __m256i *)(const void *)jz_polyb)))

/* Fixed nibble S-box: r1 = l0 ^ S4[r0], r2 = r0 ^ S4[r1], r3 = r1 ^ S4[r2],
 * result = (r2 << 4) | r3, applied bytewise.  The final pack is the folded
 * b1 ^ V[b2] form described next to jz_vtab, so only three lookups and five
 * XOR/mask ops remain per row.  The V table is consumed as a vpshufb memory
 * operand, so it costs no YMM register. */
#define JUZI_SBOX(r)                                                          \
    do {                                                                      \
        __m256i _x  = (r);                                                    \
        __m256i _b0 = _mm256_and_si256(_x, jz_m0f);                           \
        __m256i _b1 = _mm256_xor_si256(                                       \
                          _mm256_and_si256(_mm256_srli_epi16(_x, 4), jz_m0f), \
                          _mm256_shuffle_epi8(jz_tf, _b0));                   \
        __m256i _b2 = _mm256_xor_si256(                                       \
                          _b0, _mm256_shuffle_epi8(jz_tf, _b1));              \
        (r) = _mm256_xor_si256(                                               \
                  _b1, _mm256_shuffle_epi8(jz_vt, _b2));                      \
    } while (0)

/* 4x4 circulant MDS over four 32-byte rows, lane-wise.
 *
 * Row outputs are  out_a = 2a ^ 3b ^ c ^ d,  out_b = a ^ 2b ^ 3c ^ d,
 * out_c = a ^ b ^ 2c ^ 3d,  out_d = 3a ^ b ^ c ^ 2d.
 *
 * Compress with the total s = a^b^c^d and the cyclic sums
 *   p0 = a^b, p1 = b^c, p2 = c^d,  p3 = d^a,   s = p0^p2
 * each row output becomes a single-xtime form
 *   out_x = xtime(x ^ x_next) ^ s ^ x
 * because s^a = b^c^d, s^b = a^c^d, s^c = a^b^d, s^d = a^b^c.
 *
 * The fourth product is then free: the four cyclic sums satisfy
 * p0^p1^p2^p3 = 0, and xtime is GF(2)-linear, so
 *   xtime(p3) = xtime(p0)^xtime(p1)^xtime(p2).
 *
 * The circulant column-coefficient sums are all one
 *   (2^1^1^3) = (3^2^1^1) = (1^3^2^1) = (1^1^3^2) = 1,
 * so out_a ^ out_b ^ out_c ^ out_d = a ^ b ^ c ^ d = s and the fourth row
 * needs neither its own xtime term nor its old value:
 *   out_d = s ^ out_a ^ out_b ^ out_c           (a three-XOR tree).
 * Cost: 4 pair/s XORs, 3 xtimes (4 ops each), 6 XORs for a,b,c, 3 XORs for
 * d => 25 vector ALU ops per MDS4, one fewer than the previous 26-op form.
 *
 * The op order is also chosen for register pressure: each xtime result is
 * consumed by its own row immediately, and out_d is formed from the already
 * updated rows, so at most four temporaries (_s, one pair sum, two xtime
 * results) are live at the same time.  The earlier form declared seven
 * simultaneously live vectors, which is what pushed this parent's allocator
 * into spilling a state row and the polynomial constant to the stack.  The
 * bits produced are identical: this is the same circulant matrix. */
#define JUZI_MDS4(a, b, c, d)                                                 \
    do {                                                                      \
        __m256i _pa = _mm256_xor_si256((a), (b));   /* p0 = a^b      */        \
        __m256i _pc = _mm256_xor_si256((c), (d));   /* p2 = c^d      */        \
        __m256i _s  = _mm256_xor_si256(_pa, _pc);   /* a^b^c^d      */        \
        __m256i _ta = JUZI_XTIME(_pa);              /* p0 dies here */         \
        __m256i _pb = _mm256_xor_si256((b), (c));   /* p1 = b^c      */        \
        __m256i _tb = JUZI_XTIME(_pb);              /* p1 dies here */         \
        (a) = _mm256_xor_si256(_mm256_xor_si256((a), _ta), _s);                \
        (b) = _mm256_xor_si256(_mm256_xor_si256((b), _tb), _s);                \
        {                                                                     \
            __m256i _tc = JUZI_XTIME(_pc);          /* p2 dies here */         \
            (c) = _mm256_xor_si256(_mm256_xor_si256((c), _tc), _s);            \
        }                                                                     \
        (d) = _mm256_xor_si256(                                                \
                  _mm256_xor_si256(_s, (a)),                                   \
                  _mm256_xor_si256((b), (c)));                                 \
    } while (0)

/* Per-row shuffle masks for round byte-permutation modes 0 and 1.
 * Mode 0 (row w rotated left by w%4 bytes inside each 4-byte group):
 *   out[i] = in[(i & ~3) | ((i + s) & 3)], s = w%4.
 * Mode 1 (each 16-byte half rotated left by 4*(w%4) bytes):
 *   out[i] = in[(i + s) & 15], s = w%4.
 * Rows 0 and 4 are the identity and are skipped.  These are fixed public
 * constants; indices do not depend on any secret. */
static const uint8_t jz_m0[4][32] = {
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
      0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 },
    { 1, 2, 3, 0, 5, 6, 7, 4, 9, 10, 11, 8, 13, 14, 15, 12,
      1, 2, 3, 0, 5, 6, 7, 4, 9, 10, 11, 8, 13, 14, 15, 12 },
    { 2, 3, 0, 1, 6, 7, 4, 5, 10, 11, 8, 9, 14, 15, 12, 13,
      2, 3, 0, 1, 6, 7, 4, 5, 10, 11, 8, 9, 14, 15, 12, 13 },
    { 3, 0, 1, 2, 7, 4, 5, 6, 11, 8, 9, 10, 15, 12, 13, 14,
      3, 0, 1, 2, 7, 4, 5, 6, 11, 8, 9, 10, 15, 12, 13, 14 }
};

static const uint8_t jz_m1[4][32] = {
    { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
      0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 },
    { 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3,
      4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3 },
    { 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7,
      8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7 },
    { 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
      12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 }
};

/* round % 3 for rounds 0..23 */
static const uint8_t jz_mode[24] = {
    0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2,
    0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2
};

/* The six per-group round-constant snapshots (each 64 bytes, big-endian per
 * 64-bit word), precomputed at compile time.  Group g holds rc after g
 * updates of rc[j] = rotl64(rc[j],3) ^ rotl64(rc[j],7) ^ rotl64(rc[j],12),
 * starting from the fractional-Pi constants.  These are fixed public values;
 * the table is identical for every hash call, so the reference's per-call
 * scalar generation is hoisted completely out of the message path. */
static const uint8_t jz_rctab[6u * 64u] = {
    /* group 0 */
    0x24, 0x3f, 0x6a, 0x88, 0x85, 0xa3, 0x08, 0xd3,
    0x13, 0x19, 0x8a, 0x2e, 0x03, 0x70, 0x73, 0x44,
    0xa4, 0x09, 0x38, 0x22, 0x29, 0x9f, 0x31, 0xd0,
    0x08, 0x2e, 0xfa, 0x98, 0xec, 0x4e, 0x6c, 0x89,
    0x45, 0x28, 0x21, 0xe6, 0x38, 0xd0, 0x13, 0x77,
    0xbe, 0x54, 0x66, 0xcf, 0x34, 0xe9, 0x0c, 0x6c,
    0xc0, 0xac, 0x29, 0xb7, 0xc9, 0x7c, 0x50, 0xdd,
    0x3f, 0x84, 0xd5, 0xb5, 0xb5, 0x47, 0x09, 0x17,
    /* group 1 */
    0xc8, 0xe6, 0x98, 0x5c, 0xcc, 0x11, 0x1d, 0x48,
    0x8c, 0xab, 0xa6, 0x46, 0xa4, 0x8e, 0x79, 0x18,
    0xb7, 0x57, 0xf2, 0x9c, 0x70, 0x7c, 0x6c, 0x97,
    0xb9, 0xa3, 0x16, 0x75, 0xa3, 0x8d, 0xb0, 0x4e,
    0x3f, 0x4f, 0x9f, 0xa0, 0xaf, 0xbe, 0x54, 0x4a,
    0x9e, 0xfc, 0xa2, 0xad, 0x43, 0x08, 0x9e, 0xdf,
    0x91, 0xee, 0xea, 0xcd, 0x30, 0xc7, 0x34, 0x04,
    0x73, 0x17, 0x2c, 0x23, 0x79, 0x2d, 0xb0, 0xde,
    /* group 2 */
    0x5d, 0xfd, 0x20, 0x41, 0x79, 0xd2, 0xc2, 0xac,
    0x8a, 0xea, 0x7b, 0x2f, 0x84, 0xde, 0xcc, 0x48,
    0x6e, 0x6f, 0x1d, 0xdc, 0x7b, 0x1c, 0x54, 0x13,
    0x2d, 0xf4, 0xd3, 0x44, 0x01, 0xb1, 0x4e, 0xb3,
    0xa4, 0x49, 0x27, 0xa9, 0x47, 0x9c, 0x24, 0xba,
    0x43, 0x9e, 0x97, 0xfb, 0x15, 0xe6, 0x60, 0xdc,
    0x96, 0xae, 0xe3, 0xfd, 0x96, 0xe3, 0xeb, 0x72,
    0x61, 0xed, 0x47, 0x35, 0x84, 0xb8, 0x0e, 0xfb,
    /* group 3 */
    0xc3, 0x7d, 0x35, 0x2a, 0x0b, 0xdd, 0x86, 0x93,
    0x85, 0xdc, 0xb6, 0xf3, 0xa5, 0x54, 0xce, 0xaf,
    0xb5, 0x2b, 0xc7, 0x6f, 0x93, 0x89, 0x9f, 0xca,
    0xd8, 0xfb, 0x78, 0x3b, 0xc1, 0xc6, 0x1e, 0xd0,
    0x94, 0xa0, 0x7d, 0x90, 0x30, 0xb8, 0xd2, 0xc3,
    0x3a, 0xc0, 0xf3, 0x0c, 0x3a, 0x0e, 0xac, 0xfa,
    0x0c, 0x39, 0x38, 0x49, 0xf8, 0x5d, 0xcb, 0xb5,
    0x2d, 0xba, 0xfb, 0x25, 0xf9, 0x28, 0xbc, 0x75,
    /* group 4 */
    0x76, 0x21, 0x9c, 0xe8, 0x68, 0x46, 0x41, 0x48,
    0x0b, 0xd1, 0xf4, 0x1a, 0xcc, 0x2b, 0xda, 0xe3,
    0x80, 0xcb, 0x75, 0x8d, 0xc1, 0x7f, 0xb0, 0x5d,
    0x0d, 0xe4, 0x60, 0x22, 0x8c, 0xd2, 0x93, 0x65,
    0xf2, 0xe4, 0x27, 0x92, 0x54, 0x83, 0xce, 0x9c,
    0xb9, 0x4e, 0xdd, 0xdc, 0x3d, 0xec, 0xb9, 0x60,
    0xee, 0xd1, 0x79, 0x36, 0x30, 0xb0, 0xd7, 0xed,
    0x1f, 0x18, 0x14, 0x41, 0xd6, 0xdc, 0x8b, 0xe4,
    /* group 5 */
    0xb8, 0x0c, 0x15, 0xf3, 0x05, 0x06, 0x29, 0x1a,
    0xa9, 0x34, 0x01, 0x72, 0xc9, 0x1d, 0x96, 0x20,
    0xd4, 0xb9, 0xb6, 0x99, 0x4f, 0x20, 0x74, 0x20,
    0xdb, 0x11, 0x38, 0x9f, 0x26, 0xeb, 0x79, 0x70,
    0xa7, 0x4b, 0xd0, 0xf0, 0xd9, 0x10, 0xf5, 0xb0,
    0x80, 0xc5, 0xc3, 0x21, 0xd2, 0xaf, 0x70, 0xcd,
    0x09, 0xa4, 0x31, 0xa2, 0xd0, 0x93, 0x97, 0x75,
    0xf5, 0x8e, 0x9f, 0x88, 0x10, 0x1f, 0xec, 0xde
};

/* Initialisation vector after the fixed IV permutation.
 *
 * The IV injection xors a constant zero rate block into the zero state, so the
 * 24-round permutation that follows is a function of compile-time constants
 * only.  Its 256-byte output is therefore a constant too; folding it removes
 * one whole permutation (24 rounds) from every hash call, since the result
 * cannot depend on the message, the length or any caller-supplied pointer.
 * The bytes below were extracted from this implementation's own
 * juzi_perm_absorb run on the zero state with state[0]=0x02, state[1]=0x00, and
 * the differential gate re-checks them against the reference permutation. */
static const uint8_t jz_iv[JUZI_STATE_BYTES] = {
    /* row 0 */
    0xda, 0x67, 0x34, 0x1b, 0xc4, 0x3d, 0x1f, 0x97, 0xc3, 0x85, 0xe9, 0x9b,
    0xae, 0x65, 0xd5, 0x9e, 0xcf, 0x1d, 0x96, 0x0d, 0xda, 0xe7, 0x79, 0x06,
    0xa6, 0xf4, 0xf9, 0x6b, 0x4a, 0x8d, 0x26, 0xc3,
    /* row 1 */
    0xf6, 0xf3, 0xa1, 0xb2, 0x13, 0x44, 0x27, 0x9d, 0x68, 0xf1, 0xa2, 0x2f,
    0x03, 0x1e, 0x77, 0x02, 0xe5, 0x03, 0xea, 0x25, 0xcb, 0xf5, 0xde, 0x30,
    0x45, 0xb4, 0x47, 0xac, 0x97, 0x32, 0x99, 0xc4,
    /* row 2 */
    0x15, 0xb5, 0x74, 0xd6, 0xcb, 0xc3, 0x3a, 0xc2, 0xa9, 0xb8, 0x7c, 0xc4,
    0x93, 0x98, 0x24, 0x23, 0x72, 0x3b, 0x51, 0x8e, 0x2f, 0x48, 0x47, 0x8c,
    0xe9, 0x04, 0xfc, 0x5c, 0x90, 0x8e, 0x99, 0xd8,
    /* row 3 */
    0x20, 0xe4, 0xc6, 0x45, 0x66, 0x23, 0x71, 0x78, 0x9d, 0x26, 0x65, 0x0d,
    0x2e, 0x8c, 0xf4, 0xcc, 0x7b, 0xb8, 0x37, 0x65, 0xec, 0x06, 0xe0, 0x9c,
    0xee, 0x89, 0x7e, 0xdb, 0x58, 0x18, 0x04, 0xd3,
    /* row 4 */
    0xf5, 0x6c, 0xef, 0xad, 0x48, 0x27, 0x37, 0x4a, 0xe8, 0xb8, 0x36, 0x5c,
    0x0c, 0x87, 0x42, 0x89, 0x0a, 0x13, 0x1c, 0x0f, 0x8b, 0x60, 0xa4, 0x27,
    0x42, 0xf9, 0x81, 0x0a, 0xc9, 0xa0, 0x08, 0x13,
    /* row 5 */
    0xdb, 0x31, 0x22, 0x54, 0x44, 0x22, 0xca, 0x4b, 0x6d, 0x13, 0x76, 0xc3,
    0xc4, 0x50, 0x80, 0xbd, 0x43, 0x44, 0x5c, 0x23, 0x12, 0xd1, 0x58, 0x4c,
    0x22, 0x8b, 0x8b, 0x11, 0xd4, 0xbc, 0x6d, 0x2f,
    /* row 6 */
    0xef, 0xb9, 0x6f, 0x8b, 0xfb, 0x01, 0xcb, 0x43, 0xde, 0x71, 0xb1, 0x4d,
    0x2b, 0xbe, 0x43, 0x32, 0x93, 0x06, 0xef, 0x5f, 0x4b, 0x77, 0xa9, 0xc1,
    0xf5, 0xec, 0xff, 0xf1, 0x68, 0x52, 0xd7, 0xee,
    /* row 7 */
    0xab, 0x6f, 0xf3, 0xfe, 0x5c, 0x5b, 0x10, 0x80, 0xfe, 0x59, 0x77, 0x13,
    0xaa, 0x71, 0x7c, 0xf5, 0xd3, 0xa0, 0x33, 0x22, 0x8d, 0xe2, 0x2e, 0x6b,
    0xa0, 0x5e, 0xc0, 0xa1, 0x0d, 0xb1, 0xab, 0xf0
};

/* Absorb the 1024-bit rate block (if block != NULL) into rate rows 0,1,4,5
 * directly from the caller's buffer, then run the 24-round permutation.  All
 * eight rows stay in named vector registers across the whole round loop. */
static void juzi_perm_absorb(uint8_t s[JUZI_STATE_BYTES],
                             const uint8_t *block,
                             const uint8_t rctab[6u * 64u])
{
    const __m256i jz_tf = _mm256_setr_epi8(
        9, 0, 4, 11, 13, 12, 3, 15, 1, 10, 2, 6, 7, 5, 8, 14,
        9, 0, 4, 11, 13, 12, 3, 15, 1, 10, 2, 6, 7, 5, 8, 14);
    const __m256i jz_m0f = _mm256_set1_epi8(0x0f);
    /* jz_vt is only referenced from the JUZI_SBOX memory operand, so it stays
     * a .rodata address rather than a live vector register. */
    const __m256i jz_vt = _mm256_loadu_si256(
        (const __m256i *)(const void *)jz_vtab);
    __m256i r0 = _mm256_loadu_si256((const __m256i *)(const void *)(s +   0u));
    __m256i r1 = _mm256_loadu_si256((const __m256i *)(const void *)(s +  32u));
    __m256i r2 = _mm256_loadu_si256((const __m256i *)(const void *)(s +  64u));
    __m256i r3 = _mm256_loadu_si256((const __m256i *)(const void *)(s +  96u));
    __m256i r4 = _mm256_loadu_si256((const __m256i *)(const void *)(s + 128u));
    __m256i r5 = _mm256_loadu_si256((const __m256i *)(const void *)(s + 160u));
    __m256i r6 = _mm256_loadu_si256((const __m256i *)(const void *)(s + 192u));
    __m256i r7 = _mm256_loadu_si256((const __m256i *)(const void *)(s + 224u));
    unsigned int group, k;

    if (block != 0) {
        r0 = _mm256_xor_si256(r0, _mm256_loadu_si256(
                (const __m256i *)(const void *)(block +   0u)));
        r1 = _mm256_xor_si256(r1, _mm256_loadu_si256(
                (const __m256i *)(const void *)(block +  32u)));
        r4 = _mm256_xor_si256(r4, _mm256_loadu_si256(
                (const __m256i *)(const void *)(block +  64u)));
        r5 = _mm256_xor_si256(r5, _mm256_loadu_si256(
                (const __m256i *)(const void *)(block +  96u)));
    }

    for (group = 0; group < 6u; group++) {
        const uint8_t *cp = rctab + group * 64u;

        r0 = _mm256_xor_si256(r0, _mm256_loadu_si256(
                (const __m256i *)(const void *)cp));
        r1 = _mm256_xor_si256(r1, _mm256_loadu_si256(
                (const __m256i *)(const void *)(cp + 32u)));

        for (k = 0; k < 4u; k++) {
            const unsigned int mode = (unsigned int)jz_mode[4u * group + k];
            __m256i a, b;

            JUZI_SBOX(r0);
            JUZI_SBOX(r1);
            JUZI_SBOX(r2);
            JUZI_SBOX(r3);
            JUZI_SBOX(r4);
            JUZI_SBOX(r5);
            JUZI_SBOX(r6);
            JUZI_SBOX(r7);
            JUZI_MDS4(r0, r1, r2, r3);
            JUZI_MDS4(r4, r5, r6, r7);

            if (mode == 0u) {
                r1 = _mm256_shuffle_epi8(r1, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m0[1]));
                r2 = _mm256_shuffle_epi8(r2, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m0[2]));
                r3 = _mm256_shuffle_epi8(r3, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m0[3]));
                r5 = _mm256_shuffle_epi8(r5, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m0[1]));
                r6 = _mm256_shuffle_epi8(r6, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m0[2]));
                r7 = _mm256_shuffle_epi8(r7, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m0[3]));
            } else if (mode == 1u) {
                r1 = _mm256_shuffle_epi8(r1, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m1[1]));
                r2 = _mm256_shuffle_epi8(r2, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m1[2]));
                r3 = _mm256_shuffle_epi8(r3, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m1[3]));
                r5 = _mm256_shuffle_epi8(r5, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m1[1]));
                r6 = _mm256_shuffle_epi8(r6, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m1[2]));
                r7 = _mm256_shuffle_epi8(r7, _mm256_loadu_si256(
                        (const __m256i *)(const void *)jz_m1[3]));
            } else {
                /* rotate the 64-byte pair (w, w+4) left by 16*w bytes */
                a = r1;
                b = r5;
                r1 = _mm256_permute2x128_si256(a, b, 0x21);
                r5 = _mm256_permute2x128_si256(a, b, 0x03);

                a = r2;
                b = r6;
                r2 = b;
                r6 = a;

                a = r3;
                b = r7;
                r3 = _mm256_permute2x128_si256(a, b, 0x03);
                r7 = _mm256_permute2x128_si256(a, b, 0x21);
            }
        }
    }

    _mm256_storeu_si256((__m256i *)(void *)(s +   0u), r0);
    _mm256_storeu_si256((__m256i *)(void *)(s +  32u), r1);
    _mm256_storeu_si256((__m256i *)(void *)(s +  64u), r2);
    _mm256_storeu_si256((__m256i *)(void *)(s +  96u), r3);
    _mm256_storeu_si256((__m256i *)(void *)(s + 128u), r4);
    _mm256_storeu_si256((__m256i *)(void *)(s + 160u), r5);
    _mm256_storeu_si256((__m256i *)(void *)(s + 192u), r6);
    _mm256_storeu_si256((__m256i *)(void *)(s + 224u), r7);
}

/* Shared sponge-style message injection: xor the 1024-bit block into the rate branch
 * words S0,S1,S4,S5 and apply the 24-round permutation. */
static void juzi_update_sp(uint8_t state[JUZI_STATE_BYTES],
                           const uint8_t block[JUZI_BLOCK_BYTES],
                           const uint8_t rctab[6u * 64u])
{
    juzi_perm_absorb(state, block, jz_rctab);
}

/* Full-state DM-like update for JuziHash-1024: after the same message injection
 * and permutation, xor the old 1024-bit capacity branch into the new capacity branch. */
static void juzi_update_dm(uint8_t state[JUZI_STATE_BYTES],
                           const uint8_t block[JUZI_BLOCK_BYTES],
                           const uint8_t rctab[6u * 64u])
{
    uint8_t old_cap[JUZI_BLOCK_BYTES];
    size_t i;
    memcpy(old_cap +  0u, state + 2u * 32u, 32u);
    memcpy(old_cap + 32u, state + 3u * 32u, 32u);
    memcpy(old_cap + 64u, state + 6u * 32u, 32u);
    memcpy(old_cap + 96u, state + 7u * 32u, 32u);

    juzi_update_sp(state, block, jz_rctab);

    for (i = 0; i < 32u; i++) {
        state[2u * 32u + i] ^= old_cap[0u * 32u + i];
        state[3u * 32u + i] ^= old_cap[1u * 32u + i];
        state[6u * 32u + i] ^= old_cap[2u * 32u + i];
        state[7u * 32u + i] ^= old_cap[3u * 32u + i];
    }
}


void juzihash512_ref(const uint8_t *msg, uint64_t msg_bitlen,
                     uint8_t digest[JUZI512_DIGEST_BYTES])
{
    uint8_t state[JUZI_STATE_BYTES];
    uint8_t block[JUZI_BLOCK_BYTES];
    const uint64_t data_blocks = juzi_data_block_count(msg_bitlen);
    uint64_t i;

    /* The zero state injected with the fixed IV bytes and run through one
     * 24-round permutation contains no message- or length-dependent input at
     * all, so that permutation is a compile-time constant: load its 256-byte
     * snapshot directly instead of re-running 24 rounds per call.  This is
     * exactly the value the un-folded code produces (verified by the
     * differential gate); the absorb below is unchanged. */
    memcpy(state, jz_iv, JUZI_STATE_BYTES);

    /* Full data blocks are absorbed straight from the message buffer. */
    for (i = 0; i < data_blocks; i++) {
        if ((i + 1u) == data_blocks && (msg_bitlen % 1024u) != 0u) {
            juzi_make_data_block(msg, msg_bitlen, i, block);
            juzi_perm_absorb(state, block, jz_rctab);
        } else {
            juzi_perm_absorb(state, msg + i * JUZI_BLOCK_BYTES, jz_rctab);
        }
    }

    juzi_make_length_block(msg_bitlen, block);
    juzi_perm_absorb(state, block, jz_rctab);

    memcpy(digest, state, JUZI512_DIGEST_BYTES);
}

#ifdef JUZIHASH_SELFTEST
static void print_hex(const uint8_t *x, size_t n)
{
    size_t i;
    for (i = 0; i < n; i++) printf("%02x", x[i]);
    printf("\n");
}

int main(void)
{
    const uint8_t msg[] = "abc";
    uint8_t out[JUZI512_DIGEST_BYTES];
    juzihash512_ref(msg, 24u, out);
    print_hex(out, sizeof(out));
    return 0;
}
#endif


/* ICCS NGCC API wrapper. */
int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    if (digest_len_bits != DIGEST_BIT_LENGTH) {
        return 1;
    }
    if (digest == 0) {
        return 2;
    }
    if (msg == 0 && msg_len_bits != 0ULL) {
        return 3;
    }
    juzihash512_ref((const uint8_t *)msg, (uint64_t)msg_len_bits, (uint8_t *)digest);
    return 0;
}
