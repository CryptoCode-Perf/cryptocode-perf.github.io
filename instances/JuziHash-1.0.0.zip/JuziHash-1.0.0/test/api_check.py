#!/usr/bin/env python3
from pathlib import Path
import ctypes,random
root=Path(__file__).resolve().parent.parent;rng=random.Random(20261127)
for bits in (512,1024):
 libs=[ctypes.CDLL(str(root/'build'/f'{kind}-{bits}.so')) for kind in ('Reference','Optimized','CryptoCode')]
 names=[f'juzihash{bits}_ref',f'juzihash{bits}_avx2',f'juzihash{bits}_'+('ref' if bits==512 else 'avx2')]
 for l,n in zip(libs,names):
  l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
  fn=getattr(l,n);fn.argtypes=[ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p];fn.restype=None
 d=bits//8;lengths=sorted(set([0,1,7,8,9,511,512,513,1023,1024,1025,4095,4096,4097,8193]+[rng.randrange(0,32769) for _ in range(100)]))
 for n in lengths:
  msg=rng.randbytes((n+7)//8);inp=ctypes.create_string_buffer(msg or b'\0');before=inp.raw;expected=ctypes.create_string_buffer(d);assert libs[0].CryptHash(bits,inp,n,expected)==0
  for l,name in zip(libs,names):
   out=ctypes.create_string_buffer(b'\xa5'*(d+32),d+32);getattr(l,name)(inp,n,ctypes.byref(out,16));assert out.raw[16:16+d]==expected.raw and out.raw[:16]==b'\xa5'*16 and out.raw[16+d:]==b'\xa5'*16,(bits,n,name)
  assert inp.raw==before
 for n in (0,1,7,8,9,511,512,513,1023,1024,1025,4095,4096,4097):
  msg=rng.randbytes((n+7)//8);inp=ctypes.create_string_buffer(msg or b'\0');expected=ctypes.create_string_buffer(d);assert libs[0].CryptHash(bits,inp,n,expected)==0
  for l in libs:
   size=max(d,len(msg));buf=ctypes.create_string_buffer(b'\xa5'*16+msg+b'\xa5'*(size-len(msg))+b'\xa5'*16,32+size);before=buf.raw;ptr=ctypes.byref(buf,16)
   assert l.CryptHash(bits,ptr,n,ptr)==0 and buf.raw[16:16+d]==expected.raw and buf.raw[:16]==before[:16] and buf.raw[16+size:]==before[16+size:],(bits,n,'in-place')
 for l in libs:
  a=ctypes.create_string_buffer(d);b=ctypes.create_string_buffer(d)
  assert l.CryptHash(bits,None,0,a)==0 and l.CryptHash(bits,b'',0,b)==0 and a.raw==b.raw
  assert l.CryptHash(bits,None,1,a)!=0 and l.CryptHash(bits,b'x',8,None)!=0 and l.CryptHash(bits-1,b'x',8,a)!=0
 print('JuziHash-%d: %d exported-helper cases plus in-place and argument checks passed'%(bits,len(lengths)),flush=True)
