#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
{ uname -a; gcc --version; lscpu; } > build/environment.txt
exec 9>build/build-commands.log
export BASH_XTRACEFD=9
set -x
flags=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -fPIC -shared -Wl,-z,defs)
opts=(-DAFS_TREDM_OPT64_PORTABLE=1 -DAFS_TREDM_USE_AVX2=1 -DAFS_TREDM_S6_CANONICAL_AVX2=1)
for bits in 512 768 1024; do
 ref="Reference_Implementation/AFS-TrEDM-$bits"; opt="Optimized_Implementation/AFS-TrEDM-$bits"; own="CryptoCode_Implementation/AFS-TrEDM-$bits"; common=Optimized_Implementation/common/s6
 gcc "${flags[@]}" -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" "$ref/afs_sbox64.c" "$ref/afs_lmds1600_s6.c" "$ref/afs_p1600.c" "$ref/afs_tredm.c" -o "build/Reference-$bits.so"
 gcc "${flags[@]}" "${opts[@]}" -I"$ref" -I"$opt" -I"$common" -I"$common/generated" "$ref/CryptHash_AlgorithmInstance.c" "$opt/afs_tredm.c" "$opt/afs_p1600.c" "$opt/afs_sbox64.c" "$common/afs_lmds1600_s6_opt64.c" -o "build/Optimized-$bits.so"
 if [ "$bits" = 512 ]; then
  gcc "${flags[@]}" -I"$own" "$own/CryptHash_AlgorithmInstance.c" "$own/afs_sbox64.c" "$own/afs_lmds1600_s6.c" "$own/afs_p1600.c" "$own/afs_tredm.c" -o "build/CryptoCode-$bits.so"
 else
  gcc "${flags[@]}" "${opts[@]}" -I"$ref" -I"$opt" -I"$common" -I"$common/generated" "$ref/CryptHash_AlgorithmInstance.c" "$opt/afs_tredm.c" "$own/afs_p1600_inl.c" "$opt/afs_sbox64.c" -o "build/CryptoCode-$bits.so"
 fi
 if [ "$bits" = 512 ] || [ "$bits" = 768 ]; then
  gcc "${flags[@]}" "${opts[@]}" -I"$ref" -I"$opt" -I"$common" -I"$common/generated" -ICryptoCode_Implementation/common "$ref/CryptHash_AlgorithmInstance.c" "$opt/afs_tredm.c" "$own/unrolled/afs_p1600_unroll.c" "$opt/afs_sbox64.c" -o "build/CryptoCodeSelected-$bits.so"
 fi
 for kind in Reference Optimized CryptoCode; do python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/AFS-TrEDM-$bits.txt"; done
 if [ "$bits" = 512 ] || [ "$bits" = 768 ]; then python3 test/kat.py "build/CryptoCodeSelected-$bits.so" 100000 0 "kat/AFS-TrEDM-$bits.txt"; fi
done
python3 test/differential.py
python3 test/helper_check.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 768 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits"; done; if [ "$bits" != 1024 ]; then ./build/guard_check "./build/CryptoCodeSelected-$bits.so" "$bits"; fi; done

set +x
