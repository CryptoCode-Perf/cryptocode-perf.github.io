#!/usr/bin/env python3
"""Check public afs_tredm_hash across valid and fixed-instance domains."""
from pathlib import Path
import ctypes,random
root=Path(__file__).resolve().parent.parent
rng=random.Random(20261127);count=0
for tier in (512,768,1024):
 kinds=('Reference','Optimized','CryptoCode','CryptoCodeSelected') if tier in (512,768) else ('Reference','Optimized','CryptoCode')
 libs=[ctypes.CDLL(str(root/'build'/f'{k}-{tier}.so')) for k in kinds]
 for lib in libs:
  lib.afs_tredm_hash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p]
  lib.afs_tredm_hash.restype=ctypes.c_int
 for bits in (512,768,1024):
  for n in (0,1,7,8,9,511,512,513,767,768,769,1023,1024,1025,4095,4096,4097,8193):
   msg=rng.randbytes((n+7)//8);inp=ctypes.create_string_buffer(msg or b'\0');before=inp.raw;values=[]
   for lib in libs:
    buf=ctypes.create_string_buffer(b'\xa5'*(bits//8+32),bits//8+32)
    rc=lib.afs_tredm_hash(bits,inp,n,ctypes.byref(buf,16))
    assert buf.raw[:16]==b'\xa5'*16 and buf.raw[16+bits//8:]==b'\xa5'*16
    values.append((rc,buf.raw[16:16+bits//8]))
   assert inp.raw==before and values[0][0]==0,(tier,bits,n)
   assert (values[1]==values[0] if bits==tier else values[1][0]==-1),(tier,bits,n,'official')
   assert (values[2]==values[0] if bits==tier or tier==512 else values[2][0]==-1),(tier,bits,n,'cryptocode')
   if len(values)==4:assert (values[3]==values[0] if bits==tier else values[3][0]==-1),(tier,bits,n,'selected')
   count+=1
 for lib in libs:
  buf=ctypes.create_string_buffer(tier//8)
  assert lib.afs_tredm_hash(tier,None,1,buf)==-2
  assert lib.afs_tredm_hash(tier,b'x',8,None)==-2
  assert lib.afs_tredm_hash(123,b'x',8,buf)==-1
print('afs_tredm_hash: %d cross-domain cases, fixed-instance rejections and argument checks passed' % count)
