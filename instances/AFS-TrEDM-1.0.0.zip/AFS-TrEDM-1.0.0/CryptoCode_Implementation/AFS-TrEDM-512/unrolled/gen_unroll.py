#!/usr/bin/env python3
"""Build an AFS-TrEDM variant whose g/h unroll with COMPILE-TIME round indices
for the 512 and 768 tiers too.

## Why

The official `afs_p1600.c` has two branches in `afs_p1600_g` / `afs_p1600_h`:

    #if AFS_P1600_SPLIT_ROUNDS == 12
        afs_p1600_round_opt(A, 0U,  AFS_RC[0]);
        ... 12 explicit calls with constant round numbers ...
    #else
        afs_p1600_permute(A, 0U, AFS_P1600_SPLIT_ROUNDS);
        afs_p1600_permute(A, AFS_P1600_SPLIT_ROUNDS, AFS_P1600_SPLIT_ROUNDS);
    #endif

`AFS_P1600_SPLIT_ROUNDS` is 12 only for the 1024-bit tier (512 -> 6, 768 -> 10,
see each tier's afs_p1600.h:31-43). So only 1024 gets constant round numbers;
512/768 go through `afs_p1600_permute(A, first, nr)` -- a runtime `for` loop.
Each round then calls `afs_lmds1600_s6_opt64(A, round)`, body
`switch (round % 6U)`, and with a runtime `round` GCC cannot fold the switch:
it emits imul/shift + indirect jump per round, and (once LMDS is inlined, as in
our "inl" route) it cannot specialize six different bodies inside one loop body,
so the dispatch survives.

Measured on the identical build (`_ab_control.log`):
  tier  split  our inl vs byte-identical official-source rebuild
  1024   12    1.160 1.189 1.196 1.187 1.199 1.192 1.185 1.198   -> win
   512    6    0.946 0.958 0.957 0.952 0.953 0.959 0.958 0.961   -> loss
   768   10    (same class as 512)

## What this script does

Takes `src/uni/afs_p1600_inl.c` and replaces ONLY the two `#else` fallbacks in
g/h with `#elif AFS_P1600_SPLIT_ROUNDS == 6` / `== 10` branches that spell out
the calls with literal round numbers (the same shape the official source uses
for 12). Everything else -- AVX2 nonlinear layer, LMDS bodies, padding,
absorption -- is untouched, and the round order/constants are identical, so the
result is the same algorithm with the same output.

Usage:  python3 gates/gen_unroll.py
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
AFSEDM = os.path.dirname(HERE)
SRC = os.path.join(AFSEDM, "src", "uni", "afs_p1600_inl.c")
OUT_C = os.path.join(AFSEDM, "src", "uni", "afs_p1600_unroll.c")


def read(p):
    with open(p, "r", encoding="utf-8") as fh:
        return fh.read()


def sub_once(text, old, new, what):
    c = text.count(old)
    if c != 1:
        raise SystemExit("FATAL: %s anchor fired %d times (want 1)" % (what, c))
    return text.replace(old, new, 1)


def calls(first, n, indent="        "):
    return "\n".join(
        "%safs_p1600_round_opt(A, %dU, AFS_RC[%d]);" % (indent, first + i, first + i)
        for i in range(n))


OLD_G = ("#else\n"
         "    afs_p1600_permute(A, 0U, AFS_P1600_SPLIT_ROUNDS);\n"
         "#endif")
OLD_H = ("#else\n"
         "    afs_p1600_permute(A, AFS_P1600_SPLIT_ROUNDS, AFS_P1600_SPLIT_ROUNDS);\n"
         "#endif")

NEW_G = """#elif AFS_P1600_SPLIT_ROUNDS == 6
%s
#elif AFS_P1600_SPLIT_ROUNDS == 10
%s
#else
    afs_p1600_permute(A, 0U, AFS_P1600_SPLIT_ROUNDS);
#endif""" % (calls(0, 6), calls(0, 10))

NEW_H = """#elif AFS_P1600_SPLIT_ROUNDS == 6
%s
#elif AFS_P1600_SPLIT_ROUNDS == 10
%s
#else
    afs_p1600_permute(A, AFS_P1600_SPLIT_ROUNDS, AFS_P1600_SPLIT_ROUNDS);
#endif""" % (calls(6, 6), calls(10, 10))


def main():
    src = read(SRC)
    src = sub_once(src, OLD_G, NEW_G, "g fallback")
    src = sub_once(src, OLD_H, NEW_H, "h fallback")
    with open(OUT_C, "w", encoding="utf-8") as fh:
        fh.write(src)
    print("wrote %s (%d bytes)" % (os.path.relpath(OUT_C, AFSEDM), len(src)))
    for n, tag in ((6, "512"), (10, "768")):
        print("  %s tier: g/h now unroll %d explicit round_opt calls" % (tag, n))


if __name__ == "__main__":
    main()
