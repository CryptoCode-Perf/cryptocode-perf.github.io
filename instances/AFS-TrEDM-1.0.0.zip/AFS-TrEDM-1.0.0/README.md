# AFS-TrEDM 1.0.0 — CryptoCode implementation

Instances: AFS-TrEDM-512, AFS-TrEDM-768 and AFS-TrEDM-1024. Requires x86-64
Linux/WSL2, AVX2, GCC, Python 3 and standard Unix tools. Run:

    bash build_selected.sh

The script rebuilds reference, official optimized and CryptoCode implementations,
checks all 4097 known-answer vectors per implementation and instance, compares
selected long and boundary inputs, checks guarded buffers and validates the
public `afs_tredm_hash` helper's supported and rejected domains. Selected
libraries are written to build/selected/. Prebuilt libraries are in prebuilt/.

`CryptHash` accepts the digest length and message length in bits. Each selected
library is built for its named digest size. The reference `afs_tredm_hash`
helper accepts 512, 768 and 1024; official optimized builds and selected
implementations are fixed to their named size. Other helper sizes are rejected
with AFS_TREDM_BAD_DIGEST_LENGTH; no reference fallback is performed. The
retained earlier 512-bit CryptoCode implementation accepts all three sizes.

The selected 512/768 sources correspond byte-for-byte to the current local
performance report binaries when rebuilt with the documented flags. The
selected 1024 binary matches both previously compared sources. Source choices
and hashes are recorded in selection.json and SOURCE_MANIFEST.json. Earlier
measurements and implementations are retained as historical evidence.

Performance results use elapsed nanoseconds, not hardware cycles. Three
101-sample rounds over eight input sizes and raw samples are in
results/2026-11-27-delivery-comparison. Reference measurements are separately
recorded in results/2026-11-27-reference-comparison. To remeasure after building:

    python3 test/measure.py --lock /path/to/shared/measurement.lock --output /path/to/new/results

The shared lock coordinates participating measurements but cannot exclude
unrelated host work. Performance depends on hardware and load. Original
source notices are retained. Tests do not prove security or constant-time
behavior. See SOURCE_MANIFEST.json for file and prebuilt hashes.
