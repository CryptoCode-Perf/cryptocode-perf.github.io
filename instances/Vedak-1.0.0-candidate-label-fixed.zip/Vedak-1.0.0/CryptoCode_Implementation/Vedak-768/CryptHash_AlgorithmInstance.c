/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).

ICCS doesn't represent or warrant that the operation of the software will be
uninterrupted or error-free in all cases. ICCS will take no responsibility for
the use of the software or the results thereof, if the software is used for any
other purposes.
*/

#include "CryptHash_AlgorithmInstance.h"

#define _CRT_SECURE_NO_WARNINGS
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <immintrin.h>

#ifndef CRYPTHASH_SUCCESS
#define CRYPTHASH_SUCCESS            0
#define CRYPTHASH_ERR_NULLPTR       -1
#define CRYPTHASH_ERR_BAD_DIGEST_LEN -2
#define CRYPTHASH_ERR_ALLOC         -3
#endif

#define VEDAKF_ROUNDS 40
#define VEDAK_STATE_WORDS 40

typedef uint64_t u64;
typedef uint8_t  u8;

/* ------------------------------------------------------------------
 * Representation note (derived from the reference source, not assumed):
 *
 * The 40-word state is indexed state[row*4 + col] with row in 0..9 and
 * col in 0..3.  Holding one __m256i per row, with 64-bit lane col, makes
 * the three linear layers line up with the ISA:
 *
 *  - apply_S is a per-byte map.  Inspecting every row of S_BOX_8 shows it
 *    is nibble separable with the SAME 16-entry permutation in both
 *    nibbles:  S_BOX_8[x] = (P[x>>4] << 4) | P[x & 15].  A byte-wise
 *    16-entry lookup is exactly vpshufb (index bit 7 clear), so no gather
 *    and no data-dependent table addressing is needed.
 *  - apply_L reads state[j + k*4] for fixed col j, i.e. the same 10x10
 *    GF(2) matrix on every lane => one vpxor per matrix edge instead of
 *    four scalar xors.
 *  - apply_P is per row: a lane permutation PI[i], an optional swap of the
 *    two 32-bit halves (ALPHA) and a rotate of each 32-bit half by
 *    RHO[i]*4 (ALPHA and the rotate commute, both act per half).
 *  - apply_AC touches only lane 0 of row 0.
 * ------------------------------------------------------------------ */

/* S_BOX_8 nibble permutation: S[x] = (P_NIB[x>>4] << 4) | P_NIB[x & 15]. */
static const u8 P_NIB[16] = {
    1, 0, 5, 6, 12, 9, 2, 8, 10, 7, 3, 15, 14, 11, 4, 13
};

/* Same permutation pre-shifted into the high nibble, OR'd with the low part. */
static const u8 P_NIB_HI[16] = {
    0x10, 0x00, 0x50, 0x60, 0xC0, 0x90, 0x20, 0x80,
    0xA0, 0x70, 0x30, 0xF0, 0xE0, 0xB0, 0x40, 0xD0
};

/* 40 round constants, pre-positioned into bits 63..32 of lane 0 only. */
#define RCV_ENTRY(x) { (u64)(x) << 32, 0u, 0u, 0u }
static const u64 RCV[VEDAKF_ROUNDS][4] = {
    RCV_ENTRY(0x2c387d69U), RCV_ENTRY(0x988cc9ddU), RCV_ENTRY(0xf0e4a1b5U), RCV_ENTRY(0x21357064U),
    RCV_ENTRY(0x8397d2c6U), RCV_ENTRY(0xc7d39682U), RCV_ENTRY(0x4f5b1e0aU), RCV_ENTRY(0x5e4a0f1bU),
    RCV_ENTRY(0x7c682d39U), RCV_ENTRY(0x392d687cU), RCV_ENTRY(0xb3a7e2f6U), RCV_ENTRY(0xa7b3f6e2U),
    RCV_ENTRY(0x8e9adfcbU), RCV_ENTRY(0xdcc88d99U), RCV_ENTRY(0x786c293dU), RCV_ENTRY(0x30246175U),
    RCV_ENTRY(0xa1b5f0e4U), RCV_ENTRY(0x8296d3c7U), RCV_ENTRY(0xc5d19480U), RCV_ENTRY(0x4a5e1b0fU),
    RCV_ENTRY(0x55410410U), RCV_ENTRY(0x6b7f3a2eU), RCV_ENTRY(0x17034652U), RCV_ENTRY(0xeffbbeaaU),
    RCV_ENTRY(0x1f0b4e5aU), RCV_ENTRY(0xffebaebaU), RCV_ENTRY(0x3f2b6e7aU), RCV_ENTRY(0xbfabeefaU),
    RCV_ENTRY(0xbeaaeffbU), RCV_ENTRY(0xbca8edf9U), RCV_ENTRY(0xb9ade8fcU), RCV_ENTRY(0xb2a6e3f7U),
    RCV_ENTRY(0xa5b1f4e0U), RCV_ENTRY(0x8b9fdaceU), RCV_ENTRY(0xd7c38692U), RCV_ENTRY(0x6f7b3e2aU),
    RCV_ENTRY(0x1e0a4f5bU), RCV_ENTRY(0xfde9acb8U), RCV_ENTRY(0x3a2e6b7fU), RCV_ENTRY(0xb4a0e5f1U)
};

/* Big-endian 64-bit lanes inside a 256-bit word (index bytes, per 128-bit lane). */
static const u8 BSWAP_MASK[32] = {
    7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8,
    7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8
};

#define VXOR(a, b) _mm256_xor_si256((a), (b))

/* rotate each 32-bit lane right by the constant n (1 <= n <= 31) */
#define VEDAK_ROR32(x, n) \
    _mm256_or_si256(_mm256_srli_epi32((x), (n)), _mm256_slli_epi32((x), 32 - (n)))

/* per-byte S_BOX_8 through the nibble-separable form */
#define VEDAK_SB(x, m0f, tlo, thi)                                        \
    _mm256_or_si256(                                                      \
        _mm256_shuffle_epi8((tlo), _mm256_and_si256((x), (m0f))),         \
        _mm256_shuffle_epi8((thi),                                        \
            _mm256_and_si256(_mm256_srli_epi32((x), 4), (m0f))))

static u64 load64_be(const u8* p)
{
    return ((u64)p[0] << 56) | ((u64)p[1] << 48) | ((u64)p[2] << 40) | ((u64)p[3] << 32) |
        ((u64)p[4] << 24) | ((u64)p[5] << 16) | ((u64)p[6] << 8) | ((u64)p[7]);
}

static void store64_be(u8* p, u64 x)
{
    p[0] = (u8)(x >> 56);
    p[1] = (u8)(x >> 48);
    p[2] = (u8)(x >> 40);
    p[3] = (u8)(x >> 32);
    p[4] = (u8)(x >> 24);
    p[5] = (u8)(x >> 16);
    p[6] = (u8)(x >> 8);
    p[7] = (u8)(x);
}

static void set_bit_msb_first(u8* buf, size_t bit_index, int bit)
{
    u8 mask = (u8)(1u << (7u - (unsigned)(bit_index & 7u)));
    if (bit) buf[bit_index >> 3] |= mask;
    else     buf[bit_index >> 3] &= (u8)~mask;
}

/* 40 rounds of S, L, P, AC with the whole state resident in YMM registers. */
static void vedak_p40(__m256i st[10])
{
    const __m256i m0f = _mm256_set1_epi8(0x0f);
    const __m256i tlo = _mm256_broadcastsi128_si256(
        _mm_loadu_si128((const __m128i*)(const void*)P_NIB));
    const __m256i thi = _mm256_broadcastsi128_si256(
        _mm_loadu_si128((const __m128i*)(const void*)P_NIB_HI));

    __m256i s0 = st[0], s1 = st[1], s2 = st[2], s3 = st[3], s4 = st[4];
    __m256i s5 = st[5], s6 = st[6], s7 = st[7], s8 = st[8], s9 = st[9];
    unsigned r;

    for (r = 0; r < VEDAKF_ROUNDS; ++r) {
        __m256i a, c, d, e, g, n0, n1, n2, n3, n4, n5, n6, n7, n8, n9, t;

        /* ---- S: byte-wise nibble permutation on all 10 rows ---- */
        s0 = VEDAK_SB(s0, m0f, tlo, thi);
        s1 = VEDAK_SB(s1, m0f, tlo, thi);
        s2 = VEDAK_SB(s2, m0f, tlo, thi);
        s3 = VEDAK_SB(s3, m0f, tlo, thi);
        s4 = VEDAK_SB(s4, m0f, tlo, thi);
        s5 = VEDAK_SB(s5, m0f, tlo, thi);
        s6 = VEDAK_SB(s6, m0f, tlo, thi);
        s7 = VEDAK_SB(s7, m0f, tlo, thi);
        s8 = VEDAK_SB(s8, m0f, tlo, thi);
        s9 = VEDAK_SB(s9, m0f, tlo, thi);

        /* ---- L: 10x10 GF(2) matrix, identical on all four lanes ---- */
        /* new0 = s0^s2^s6^s7^s8        new1 = s2^s4^s5^s8^s9
           new2 = s0^s3^s5^s6^s9        new3 = s1^s4^s5^s6^s7
           new4 = s1^s3^s7^s8^s9        new5 = s0^s1^s2^s5^s7^s9
           new6 = s0^s3^s4^s5^s7^s8     new7 = s2^s3^s4^s6^s7^s9
           new8 = s1^s2^s3^s5^s6^s8     new9 = s0^s1^s4^s6^s8^s9   */
        a = VXOR(VXOR(s0, s3), s5);
        c = VXOR(s4, s5);
        d = VXOR(s7, s8);
        e = VXOR(s6, s8);
        g = VXOR(s7, s9);

        n0 = VXOR(VXOR(VXOR(s0, s2), s6), d);
        n1 = VXOR(VXOR(VXOR(s2, c), s8), s9);
        n2 = VXOR(VXOR(a, s6), s9);
        n3 = VXOR(VXOR(VXOR(s1, c), s6), s7);
        n4 = VXOR(VXOR(VXOR(s1, s3), d), s9);
        n5 = VXOR(VXOR(VXOR(VXOR(s0, s1), s2), s5), g);
        n6 = VXOR(VXOR(VXOR(a, s4), s7), s8);
        n7 = VXOR(VXOR(VXOR(VXOR(s2, s3), s4), s6), g);
        n8 = VXOR(VXOR(VXOR(VXOR(s1, s2), s3), s5), e);
        n9 = VXOR(VXOR(VXOR(VXOR(s0, s1), s4), e), s9);

        /* ---- P: lane permutation, optional half swap, per-half rotate ----
           lane plan per row (PI / ALPHA / RHO*4):
             0: {2,3,0,1} / 1111 / 16    1: {1,0,3,2} / 0000 /  4
             2: {3,2,1,0} / 0000 / 12    3: {3,2,1,0} / 1111 /  0
             4: {1,0,3,2} / 1111 / 28    5: {0,1,2,3} / 0000 /  0
             6: {0,1,2,3} / 0101 / 20    7: {2,3,0,1} / 0101 / 12
             8: {2,3,0,1} / 1010 / 20    9: {0,1,2,3} / 1010 /  4  */
        t = _mm256_permute4x64_epi64(n0, 0x4E);          /* [2,3,0,1] */
        t = _mm256_shuffle_epi32(t, 0xB1);               /* swap halves */
        s0 = VXOR(VEDAK_ROR32(t, 16),
            _mm256_loadu_si256((const __m256i*)(const void*)RCV[r]));

        t = _mm256_permute4x64_epi64(n1, 0xB1);          /* [1,0,3,2] */
        s1 = VEDAK_ROR32(t, 4);

        t = _mm256_permute4x64_epi64(n2, 0x1B);          /* [3,2,1,0] */
        s2 = VEDAK_ROR32(t, 12);

        t = _mm256_permute4x64_epi64(n3, 0x1B);          /* [3,2,1,0] */
        s3 = _mm256_shuffle_epi32(t, 0xB1);              /* swap, no rotate */

        t = _mm256_permute4x64_epi64(n4, 0xB1);          /* [1,0,3,2] */
        t = _mm256_shuffle_epi32(t, 0xB1);
        s4 = VEDAK_ROR32(t, 28);

        s5 = n5;                                         /* identity row */

        t = _mm256_shuffle_epi32(n6, 0xB1);              /* lanes 1,3 swap */
        s6 = VEDAK_ROR32(_mm256_blend_epi32(n6, t, 0xCC), 20);

        t = _mm256_permute4x64_epi64(n7, 0x4E);          /* lanes 1,3 swap */
        s7 = VEDAK_ROR32(
            _mm256_blend_epi32(t, _mm256_shuffle_epi32(t, 0xB1), 0xCC), 12);

        t = _mm256_permute4x64_epi64(n8, 0x4E);          /* lanes 0,2 swap */
        s8 = VEDAK_ROR32(
            _mm256_blend_epi32(t, _mm256_shuffle_epi32(t, 0xB1), 0x33), 20);

        t = _mm256_shuffle_epi32(n9, 0xB1);              /* lanes 0,2 swap */
        s9 = VEDAK_ROR32(_mm256_blend_epi32(n9, t, 0x33), 4);
    }

    st[0] = s0; st[1] = s1; st[2] = s2; st[3] = s3; st[4] = s4;
    st[5] = s5; st[6] = s6; st[7] = s7; st[8] = s8; st[9] = s9;
}

static int vedak_hash_bits(const u8* msg,
    size_t msg_len_bits,
    int digest_len_bits,
    u8* digest)
{
    __m256i state[10];
    size_t r_bitlen, r_bytelen, r_celllen;
    size_t padded_bits, padded_bytes, zero_bits;
    u8* padded = NULL;
    size_t i, block, blocks, out_words, copied_words;

    if (digest_len_bits != 512 && digest_len_bits != 768 && digest_len_bits != 1024) {
        return CRYPTHASH_ERR_BAD_DIGEST_LEN;
    }

    for (i = 0; i < 10; ++i) state[i] = _mm256_setzero_si256();

    r_bitlen = 2560u - (size_t)(2 * digest_len_bits);
    r_bytelen = r_bitlen / 8u;
    r_celllen = r_bitlen / 64u;

    zero_bits = (r_bitlen - ((msg_len_bits + 2u) % r_bitlen)) % r_bitlen;
    padded_bits = msg_len_bits + 2u + zero_bits;
    padded_bytes = padded_bits / 8u;
    padded = (u8*)calloc(padded_bytes, 1u);
    if (padded == NULL) return CRYPTHASH_ERR_ALLOC;

    /* The reference rebuilds the padded buffer bit by bit with the same
       MSB-first convention used to read it, so on a byte boundary this is a
       plain copy; only the trailing partial byte needs the high bits kept. */
    {
        size_t full_bytes = msg_len_bits >> 3;
        unsigned rem_bits = (unsigned)(msg_len_bits & 7u);
        if (full_bytes != 0u) memcpy(padded, msg, full_bytes);
        if (rem_bits != 0u) {
            u8 keep = (u8)(0xFFu << (8u - rem_bits));
            padded[full_bytes] = (u8)(msg[full_bytes] & keep);
        }
    }
    set_bit_msb_first(padded, msg_len_bits, 1);
    set_bit_msb_first(padded, padded_bits - 1u, 1);

    blocks = padded_bytes / r_bytelen;
    for (block = 0; block < blocks; ++block) {
        const u8* blk = padded + block * r_bytelen;
        const __m256i bswap = _mm256_loadu_si256(
            (const __m256i*)(const void*)BSWAP_MASK);
        size_t rows = r_celllen >> 2;

        /* r_celllen is a multiple of 4 for every supported digest length, so
           every absorbed word group is a full four-lane row. */
        for (i = 0; i < rows; ++i) {
            __m256i m = _mm256_loadu_si256(
                (const __m256i*)(const void*)(blk + i * 32u));
            m = _mm256_shuffle_epi8(m, bswap);
            state[i] = VXOR(state[i], m);
        }
        for (i = rows * 4u; i < r_celllen; ++i) {
            u64 tmp[4];
            __m256i cur = state[i >> 2];
            memcpy(tmp, &cur, sizeof(tmp));
            tmp[i & 3u] ^= load64_be(blk + i * 8u);
            memcpy(&state[i >> 2], tmp, sizeof(tmp));
        }

        vedak_p40(state);
    }

    free(padded);
    padded = NULL;

    out_words = (size_t)digest_len_bits / 64u;
    copied_words = 0u;
    while (copied_words < out_words) {
        size_t take = r_celllen;
        u64 flat[VEDAK_STATE_WORDS];

        if (take > out_words - copied_words) take = out_words - copied_words;
        memcpy(flat, state, sizeof(flat));
        for (i = 0; i < take; ++i) {
            store64_be(digest + (copied_words + i) * 8u, flat[i]);
        }
        copied_words += take;
        if (copied_words < out_words) {
            vedak_p40(state);
        }
    }

    return CRYPTHASH_SUCCESS;
}

int CryptHash(int digest_len_bits,
    const unsigned char* msg,
    unsigned long long msg_len_bits,
    unsigned char* digest)
{
    if (digest == NULL) return CRYPTHASH_ERR_NULLPTR;
    if (msg_len_bits > 0ULL && msg == NULL) return CRYPTHASH_ERR_NULLPTR;
    return vedak_hash_bits((const u8*)msg, (size_t)msg_len_bits, digest_len_bits, (u8*)digest);
}
