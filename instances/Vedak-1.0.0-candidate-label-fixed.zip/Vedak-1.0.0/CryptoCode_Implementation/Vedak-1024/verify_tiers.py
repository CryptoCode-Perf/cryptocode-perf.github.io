#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""vedak/verify_tiers.py —— 一件库（`out/ours_vedak_all.so`）三档全量 KAT。

官方三档的 opt.so 逐字节相同（CryptHash 运行时按 digest_len_bits 派发），
我方交付件同样做成一件库：1024 走专用快路径，768/512 走按运行时速率的通用路径。

用法：
    python3 verify_tiers.py [--libs ours|all]
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
sys.path.insert(0, L0)

import kat_gate as K                                     # noqa: E402

K.MAX_RECORDS = 10 ** 9
K.MAX_MSG_BYTES = 1 << 20

TIERS = (512, 768, 1024)


def kat_path(bits):
    return os.path.join(L0, "src", "hash-27", "Vedak", "Test_Vectors",
                        "KAT_2_12_Vedak-%d.txt" % bits)


def libs(bits):
    bd = os.path.join(L0, "build", "hash-27", "vedak%d" % bits)
    return [("ref", os.path.join(bd, "ref.so")),
            ("opt", os.path.join(bd, "opt.so")),
            ("ours", os.path.join(HERE, "out", "ours_vedak_all.so"))]


def main():
    only_ours = "--libs=ours" in sys.argv
    rc = 0
    for bits in TIERS:
        kp = kat_path(bits)
        if not os.path.isfile(kp):
            print("!! 缺 KAT: %s" % kp)
            return 2
        recs = K.parse_kat(kp)
        print("=== Vedak-%d   KAT %d 条" % (bits, len(recs)))
        for tag, lib in libs(bits):
            if only_ours and tag != "ours":
                continue
            if not os.path.isfile(lib):
                print("    %-5s MISSING %s" % (tag, lib))
                rc = 2
                continue
            chk, match, first_bad, err = K.check(lib, recs)
            ok = (err is None and chk == match)
            print("    %-5s %d/%d  %s" % (tag, match, chk,
                                          "OK" if ok else ("FAIL " + str(err))))
            if not ok:
                print("          first_bad=%s" % (str(first_bad)[:300],))
                rc = 2
    print("判定：%s" % ("全过" if rc == 0 else "有失败"))
    return rc


if __name__ == "__main__":
    sys.exit(main())
