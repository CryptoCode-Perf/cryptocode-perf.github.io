/*
 * Vedak-1024 -- our AVX2 implementation.
 *
 * State representation (packed nibbles, one nibble per byte):
 *
 *     s[2*r + h]   lane 0 = row r, column 2h
 *                  lane 1 = row r, column 2h + 1
 *
 * i.e. the 40 64-bit state words (row major, 4 columns per row) are held in 20
 * ymm registers, ymm byte t of a lane = nibble t (most significant first) of
 * that word.  This is exactly the layout of the official optimised
 * implementation, which is why the P-layer source indices below match the ones
 * in Optimized_Implementation/Vedak-1024/CryptHash_AlgorithmInstance.c.
 *
 * One round = S (per-nibble permutation) ; L (row mixing) ; P (within-row column
 * permutation + 4-bit lane rotation) ; AddConstant.
 *
 * L is the official 25-pair XO2T butterfly.  It has been verified symbolically
 * (vedak/dbg_net.py, vedak/dbg_packed.py) that the butterfly computes the
 * reference apply_L with the rows relabelled by
 *
 *     M     = [8,7,6,9,5,4,1,2,3,0]      net row k holds L(row M[k])
 *     MINV  = [9,6,7,8,5,4,2,1,0,3]      output row i comes from net row MINV[i]
 *
 * Two things differ from the official round, both aimed at the fact that the
 * round is limited by port 5 (every vpshufb / vpshufd / vperm2i128 is p5-only
 * on Intel; the official round issues 46 of them):
 *
 *  1. the official rotates the columns with vpshufb (p5).  The rotation is a
 *     byte rotation *inside each 64-bit half* of a lane, i.e. a rotation of
 *     qwords by 8*k bits, so it can be done with vpsrlq/vpsllq/vpor -- three
 *     p015 ops instead of one p5 op.  16 rotations move off p5 that way.
 *  2. P is applied in place along the cycles of the out<-source permutation,
 *     so only one spare register is needed instead of a second 20-register
 *     array (the official keeps `t[20]` alive next to `st[20]` and spills 43
 *     vector moves to the stack inside the round body).
 *
 * p5 per round: 20 (S) + 8 (lane swaps) = 28, versus 46 for the official.
 */
#include <immintrin.h>
#include <stdint.h>
#include <string.h>

#include "vedak_tables.h"

#define VD_RATE_BYTES   64
#define VD_RATE_BITS    512
#define VD_ROUNDS       40
#define VD_DIGEST_BYTES 128

#define VD_ERR_NULLPTR       (-1)
#define VD_ERR_BAD_DIGEST_LEN (-2)
#define VD_ERR_ALLOC         (-3)

/*
 * P-layer single output ymm: pick the column pair out of source ymm
 * vd_p_src[o], optionally exchange the two 128-bit lanes, then apply mode
 *   0  nothing (register rename)
 *   1  rotate each 64-bit half left by 8*k bits  (3 p015 ops, no p5)
 *   2  vpshufb with vd_pmask[o] (also carries the ALPHA exchange)
 * `swap`, `mode`, `k` and `mi` are compile-time constants at every call site
 * (they come from constant tables), so the branches fold away.
 */
static inline __m256i vd_tf(__m256i x, int swap, int mode, int k, int mi)
{
    if (swap)
        x = _mm256_permute2x128_si256(x, x, 0x01);
    if (mode == 2)
        x = _mm256_shuffle_epi8(
                x, _mm256_load_si256((const __m256i *)vd_pmask[mi]));
    else if (mode == 1)
        x = _mm256_or_si256(_mm256_slli_epi64(x, 8 * k),
                            _mm256_srli_epi64(x, 64 - 8 * k));
    return x;
}

#define VD_F(o) \
    vd_tf(s[vd_p_src[(o)]], vd_p_swap[(o)], vd_p_mode[(o)], vd_p_k[(o)], (o))

/* L: one butterfly pair; both slot halves are updated together. */
#define VD_XOR2(a, b)                                                        \
    do {                                                                     \
        s[(a) * 2 + 0] = _mm256_xor_si256(s[(a) * 2 + 0], s[(b) * 2 + 0]);   \
        s[(a) * 2 + 1] = _mm256_xor_si256(s[(a) * 2 + 1], s[(b) * 2 + 1]);   \
    } while (0)

static inline void vd_s(__m256i s[20])
{
    const __m256i t = _mm256_load_si256((const __m256i *)vd_s256);

    /* --- S: 20 vpshufb (p5), fully unrolled so it is not a rolled loop -- */
    s[ 0] = _mm256_shuffle_epi8(t, s[ 0]);
    s[ 1] = _mm256_shuffle_epi8(t, s[ 1]);
    s[ 2] = _mm256_shuffle_epi8(t, s[ 2]);
    s[ 3] = _mm256_shuffle_epi8(t, s[ 3]);
    s[ 4] = _mm256_shuffle_epi8(t, s[ 4]);
    s[ 5] = _mm256_shuffle_epi8(t, s[ 5]);
    s[ 6] = _mm256_shuffle_epi8(t, s[ 6]);
    s[ 7] = _mm256_shuffle_epi8(t, s[ 7]);
    s[ 8] = _mm256_shuffle_epi8(t, s[ 8]);
    s[ 9] = _mm256_shuffle_epi8(t, s[ 9]);
    s[10] = _mm256_shuffle_epi8(t, s[10]);
    s[11] = _mm256_shuffle_epi8(t, s[11]);
    s[12] = _mm256_shuffle_epi8(t, s[12]);
    s[13] = _mm256_shuffle_epi8(t, s[13]);
    s[14] = _mm256_shuffle_epi8(t, s[14]);
    s[15] = _mm256_shuffle_epi8(t, s[15]);
    s[16] = _mm256_shuffle_epi8(t, s[16]);
    s[17] = _mm256_shuffle_epi8(t, s[17]);
    s[18] = _mm256_shuffle_epi8(t, s[18]);
    s[19] = _mm256_shuffle_epi8(t, s[19]);
}

static inline void vd_l(__m256i s[20])
{
    /* --- L: the official 25-pair butterfly (50 vpxor, p015) ------------ */
    VD_XOR2(5, 0); VD_XOR2(6, 1); VD_XOR2(7, 2); VD_XOR2(8, 3); VD_XOR2(9, 4);
    VD_XOR2(0, 6); VD_XOR2(1, 7); VD_XOR2(2, 8); VD_XOR2(3, 9); VD_XOR2(4, 5);
    VD_XOR2(5, 2); VD_XOR2(6, 3); VD_XOR2(7, 4); VD_XOR2(8, 0); VD_XOR2(9, 1);
    VD_XOR2(0, 5); VD_XOR2(1, 6); VD_XOR2(2, 7); VD_XOR2(3, 8); VD_XOR2(4, 9);
    VD_XOR2(5, 4); VD_XOR2(6, 0); VD_XOR2(7, 1); VD_XOR2(8, 2); VD_XOR2(9, 3);
}

static inline void vd_p(__m256i s[20])
{
    __m256i tmp;

    /* --- P, in place along the cycles of  out[o] <- net[src(o)] --------
     *
     *   cycle (0 19 7 16 1 18 6 17)   cycle (2 12 4 15)
     *   cycle (3 13 5 14)             cycle (8 10)      cycle (9 11)
     *
     * read  vd_p_src / vd_p_swap / vd_p_mode / vd_p_k / vd_pmask
     * (generated by gen_tables.py, derived from the reference PI/ALPHA/RHO and
     *  from the verified row relabelling M of the butterfly).
     */
    tmp = s[0];
    s[0]  = VD_F(0);
    s[19] = VD_F(19);
    s[7]  = VD_F(7);
    s[16] = VD_F(16);
    s[1]  = VD_F(1);
    s[18] = VD_F(18);
    s[6]  = VD_F(6);
    s[17] = vd_tf(tmp, vd_p_swap[17], vd_p_mode[17], vd_p_k[17], 17);

    tmp = s[2];
    s[2]  = VD_F(2);
    s[12] = VD_F(12);
    s[4]  = VD_F(4);
    s[15] = vd_tf(tmp, vd_p_swap[15], vd_p_mode[15], vd_p_k[15], 15);

    tmp = s[3];
    s[3]  = VD_F(3);
    s[13] = VD_F(13);
    s[5]  = VD_F(5);
    s[14] = vd_tf(tmp, vd_p_swap[14], vd_p_mode[14], vd_p_k[14], 14);

    tmp = s[8];
    s[8]  = VD_F(8);
    s[10] = vd_tf(tmp, vd_p_swap[10], vd_p_mode[10], vd_p_k[10], 10);

    tmp = s[9];
    s[9]  = VD_F(9);
    s[11] = vd_tf(tmp, vd_p_swap[11], vd_p_mode[11], vd_p_k[11], 11);
}

static inline void vd_round(__m256i s[20], int r)
{
    vd_s(s);
    vd_l(s);
    vd_p(s);
    /* --- AddConstant: state[0] ^= (u64)RC[r] << 32 --------------------- */
    s[0] = _mm256_xor_si256(s[0], VD_RC(r));
}

static inline void vd_p40(__m256i s[20])
{
    int r;
    for (r = 0; r < VD_ROUNDS; r++)
        vd_round(s, r);
}

/* 32 byte message chunk -> two nibble-packed ymm (words 4m..4m+3). */
static inline void vd_expand32(const unsigned char *p, __m256i *lo, __m256i *hi)
{
    __m256i x = _mm256_loadu_si256((const __m256i *)(const void *)p);
    __m256i lo4 = _mm256_and_si256(x, _mm256_set1_epi8(0x0f));
    __m256i hi4 = _mm256_and_si256(_mm256_srli_epi16(x, 4),
                                   _mm256_set1_epi8(0x0f));
    __m256i t0 = _mm256_unpacklo_epi8(hi4, lo4);
    __m256i t1 = _mm256_unpackhi_epi8(hi4, lo4);
    *lo = _mm256_permute2x128_si256(t0, t1, 0x20);
    *hi = _mm256_permute2x128_si256(t0, t1, 0x31);
}

/* absorb one 512-bit block into the rate part (rows 0 and 1 => s[0..3]) */
static inline void vd_absorb(__m256i s[20], const unsigned char *p)
{
    __m256i a, b;
    vd_expand32(p + 0, &a, &b);
    s[0] = _mm256_xor_si256(s[0], a);
    s[1] = _mm256_xor_si256(s[1], b);
    vd_expand32(p + 32, &a, &b);
    s[2] = _mm256_xor_si256(s[2], a);
    s[3] = _mm256_xor_si256(s[3], b);
}

/* one column pair (32 packed nibbles) -> 16 big-endian bytes (2 words) */
static inline void vd_dump16(unsigned char *out, __m256i a)
{
    const __m256i ev = _mm256_setr_epi8(0, 2, 4, 6, 8, 10, 12, 14,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80,
                                        0, 2, 4, 6, 8, 10, 12, 14,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80);
    const __m256i od = _mm256_setr_epi8(1, 3, 5, 7, 9, 11, 13, 15,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80,
                                        1, 3, 5, 7, 9, 11, 13, 15,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80, (char)0x80,
                                        (char)0x80, (char)0x80);
    __m256i r = _mm256_or_si256(_mm256_slli_epi16(_mm256_shuffle_epi8(a, ev), 4),
                                _mm256_shuffle_epi8(a, od));
    __m128i w = _mm_unpacklo_epi64(_mm256_castsi256_si128(r),
                                   _mm256_extracti128_si256(r, 1));
    _mm_storeu_si128((__m128i *)(void *)out, w);
}

/* 512-bit state bottleneck: message in bits, big-endian digest. */
static void vd_hash1024(const unsigned char *msg, uint64_t msg_bits,
                        unsigned char *out)
{
    __m256i s[20];
    unsigned char last[VD_RATE_BYTES];
    uint64_t full = msg_bits / VD_RATE_BITS;
    unsigned int tail_bits = (unsigned int)(msg_bits - full * VD_RATE_BITS);
    unsigned int tail_bytes = (tail_bits + 7u) >> 3;
    unsigned int full_byte, rem;
    uint64_t i;

    for (i = 0; i < 20; i++)
        s[i] = _mm256_setzero_si256();

    for (i = 0; i < full; i++) {
        vd_absorb(s, msg + i * VD_RATE_BYTES);
        vd_p40(s);
    }

    memset(last, 0, sizeof last);
    if (tail_bytes)
        memcpy(last, msg + full * VD_RATE_BYTES, tail_bytes);
    rem = tail_bits & 7u;
    full_byte = tail_bits >> 3;
    if (rem)
        last[full_byte] &= (unsigned char)(0xffu << (8u - rem));
    last[full_byte] |= (unsigned char)(1u << (7u - rem));   /* the '1' of 10*1 */

    if (tail_bits == VD_RATE_BITS - 1u) {
        /* the two padding bits live in different blocks */
        vd_absorb(s, last);
        vd_p40(s);
        memset(last, 0, sizeof last);
    }
    last[VD_RATE_BYTES - 1] |= 0x01u;                       /* the final '1' */

    vd_absorb(s, last);
    vd_p40(s);

    vd_dump16(out + 0, s[0]);
    vd_dump16(out + 16, s[1]);
    vd_dump16(out + 32, s[2]);
    vd_dump16(out + 48, s[3]);
    vd_p40(s);
    vd_dump16(out + 64, s[0]);
    vd_dump16(out + 80, s[1]);
    vd_dump16(out + 96, s[2]);
    vd_dump16(out + 112, s[3]);
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest);

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    if (digest == 0)
        return VD_ERR_NULLPTR;
    if (msg_len_bits > 0ULL && msg == 0)
        return VD_ERR_NULLPTR;
    if (digest_len_bits != 1024)
        return VD_ERR_BAD_DIGEST_LEN;
    vd_hash1024(msg, (uint64_t)msg_len_bits, digest);
    return 0;
}

/* same entry point as the reference implementation (bit length) */
void vedak1024_hash(const unsigned char *msg, unsigned long long msg_bits,
                    unsigned char *out);

void vedak1024_hash(const unsigned char *msg, unsigned long long msg_bits,
                    unsigned char *out)
{
    vd_hash1024(msg, (uint64_t)msg_bits, out);
}

#ifdef VEDAK_TEST_HOOKS
/* ---- hooks used by the G1 same-TU differential probe ------------------- */

void vd_hook_rounds(unsigned char *state_bytes, int nr);
void vd_hook_absorb(unsigned char *state_bytes, const unsigned char *block);
void vd_hook_dump(unsigned char *out, const unsigned char *state_bytes);
void vd_hook_s(unsigned char *state_bytes);
void vd_hook_l(unsigned char *state_bytes);
void vd_hook_pl(unsigned char *state_bytes);

void vd_hook_s(unsigned char *state_bytes)
{
    __m256i s[20];
    memcpy(s, state_bytes, sizeof s);
    vd_s(s);
    memcpy(state_bytes, s, sizeof s);
}

void vd_hook_l(unsigned char *state_bytes)
{
    __m256i s[20];
    memcpy(s, state_bytes, sizeof s);
    vd_l(s);
    memcpy(state_bytes, s, sizeof s);
}

void vd_hook_pl(unsigned char *state_bytes)
{
    __m256i s[20];
    memcpy(s, state_bytes, sizeof s);
    vd_p(s);
    memcpy(state_bytes, s, sizeof s);
}

void vd_hook_rounds(unsigned char *state_bytes, int nr)
{
    __m256i s[20];
    int i;
    memcpy(s, state_bytes, sizeof s);
    for (i = 0; i < nr; i++)
        vd_round(s, i);
    memcpy(state_bytes, s, sizeof s);
}

/* --- 40-word <-> packed conversion, for same-TU differential probes ------
 *
 * word index = row*4 + col (the reference layout); nibble t of a word is its
 * t-th most significant nibble, and lives in byte t of the packed column.
 */
static void vd_w2p(__m256i s[20], const uint64_t w[40])
{
    unsigned char sb[640];
    int row, col, t;
    for (row = 0; row < 10; row++)
        for (col = 0; col < 4; col++) {
            uint64_t x = w[row * 4 + col];
            int off = 32 * (2 * row + (col >> 1)) + 16 * (col & 1);
            for (t = 0; t < 16; t++)
                sb[off + t] = (unsigned char)((x >> (60 - 4 * t)) & 0xf);
        }
    memcpy(s, sb, sizeof sb);
}

static void vd_p2w(uint64_t w[40], const __m256i s[20])
{
    unsigned char sb[640];
    int row, col, t;
    uint64_t x;
    memcpy(sb, s, sizeof sb);
    for (row = 0; row < 10; row++)
        for (col = 0; col < 4; col++) {
            int off = 32 * (2 * row + (col >> 1)) + 16 * (col & 1);
            x = 0;
            for (t = 0; t < 16; t++)
                x |= ((uint64_t)(sb[off + t] & 0xf)) << (60 - 4 * t);
            w[row * 4 + col] = x;
        }
}

void vd_hook_w_rounds(uint64_t *w, int n);

void vd_hook_w_rounds(uint64_t *w, int n)
{
    __m256i s[20];
    uint64_t x[40];
    int i;
    for (i = 0; i < 40; i++)
        x[i] = w[i];
    vd_w2p(s, (const uint64_t *)x);
    for (i = 0; i < n; i++)
        vd_round(s, i);
    vd_p2w(x, s);
    for (i = 0; i < 40; i++)
        w[i] = x[i];
}

void vd_hook_w_absorb(uint64_t *w, const unsigned char *blk);

void vd_hook_w_absorb(uint64_t *w, const unsigned char *blk)
{
    __m256i s[20];
    uint64_t x[40];
    int i;
    for (i = 0; i < 40; i++)
        x[i] = w[i];
    vd_w2p(s, (const uint64_t *)x);
    vd_absorb(s, blk);
    vd_p2w(x, s);
    for (i = 0; i < 40; i++)
        w[i] = x[i];
}

void vd_hook_absorb(unsigned char *state_bytes, const unsigned char *block)
{
    __m256i s[20];
    memcpy(s, state_bytes, sizeof s);
    vd_absorb(s, block);
    memcpy(state_bytes, s, sizeof s);
}

void vd_hook_dump(unsigned char *out, const unsigned char *state_bytes)
{
    __m256i s[20];
    memcpy(s, state_bytes, sizeof s);
    vd_dump16(out + 0, s[0]);
    vd_dump16(out + 16, s[1]);
}
#endif
