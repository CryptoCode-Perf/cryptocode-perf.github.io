#!/usr/bin/env bash
# Build the Vedak-1024 deliverable.  MUST be run inside WSL -- never from
# MSYS/pwsh (there python3 resolves to the Windows Store stub and `set -e`
# aborts before gcc ever runs, leaving a stale .so behind).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

# official ten flags, verbatim, plus the shared-object switches
FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

mkdir -p out
rm -f out/ours_vedak1024.so out/ours_vedak1024.o out/ours_vedak1024_hooks.o

echo "== gen_tables.py =="
python3 gen_tables.py

echo "== shared object =="
gcc "${FLAGS[@]}" -fPIC -shared -o out/ours_vedak1024.so src/vedak1024.c

echo "== relocatable object (for static accounting) =="
gcc "${FLAGS[@]}" -fno-lto -c -o out/ours_vedak1024.o src/vedak1024.c

echo "== hooks object (same flags + VEDAK_TEST_HOOKS) =="
gcc "${FLAGS[@]}" -fno-lto -D VEDAK_TEST_HOOKS -c \
    -o out/ours_vedak1024_hooks.o src/vedak1024.c

echo
sha256sum out/ours_vedak1024.so out/ours_vedak1024.o out/ours_vedak1024_hooks.o
ls -l out/ours_vedak1024.so out/ours_vedak1024.o out/ours_vedak1024_hooks.o
