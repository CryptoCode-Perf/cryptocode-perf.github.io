# Eijen-256

Algorithm: Eijen | Digest bits: 256 | Form: AVX2 C

Contents: implementation source/, public header Eijen-256.h, prebuilt Eijen-256.so,
KAT vector KAT_2_12_Eijen-256.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 7c8ea6880b841912d891bd5b5db616af17e5dc78bd7462443329d51f5f0f3a98
Speed (cpB, lower is faster): reference 5.07 / official-optimized 2.08 / optimized 1.90
Speedup: GM(S1-S8) 1.10x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
