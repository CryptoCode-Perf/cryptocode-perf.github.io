# Eijen-256 controlled transfer diagnostic

This is a cross-instance transfer from Eijen-512, not a verified new-source CAP win. The measured source and raw samples are included. Ratios compare official OPT against the candidate, based on elapsed time. Timing evidence identity reconciliation and independent publication audits are pending. Hardware core cycle counters were unavailable. The previous website archive is retained separately.

Binary SHA-256: 33feb84090ea4afba0c017244c419d1a47d896fde5d4fbc61c894a2ffddf103f
