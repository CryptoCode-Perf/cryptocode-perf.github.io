#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for bits in 768 1024; do
 for kind in Reference Optimized; do
  d="${kind}_Implementation/XRH-2-$bits"
  if [ "$kind" = Reference ]; then flags=-O2; else flags="-O3 -mavx2"; fi
  extra=(); if [ "$kind" = Optimized ]; then extra=("$d/CryptHash_AlgorithmInstance_AVX2.s"); fi
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/CryptHash_AlgorithmInstance.c" "${extra[@]}" -o "build/$kind-$bits.so"
 done
 d=CryptoCode_Implementation
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$d/$bits" $d/xrh_r0_18.s "$d/vec_api_xrh2.c" "$d/$bits/glue.c" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 "test/kat_$bits.py" "build/$kind-$bits.so" 100000 0 "kat/XRH-2-$bits.txt"; done
done

python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 768 1024; do build/guard_check "build/CryptoCode-$bits.so" "$bits"; done
