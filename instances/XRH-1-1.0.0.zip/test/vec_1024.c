/* vec_1024.c —— 22 个长度（含非字节对齐）三方输出逐字节比对，dlopen 加载被测 .so。 */
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int (*hash_fn)(int, const unsigned char *, unsigned long long, unsigned char *);

int main(int argc, char **argv)
{
    if (argc != 2) { fprintf(stderr, "usage: %s <lib.so>\n", argv[0]); return 2; }
    void *h = dlopen(argv[1], RTLD_NOW);
    if (!h) { fprintf(stderr, "dlopen: %s\n", dlerror()); return 3; }
    hash_fn fn = (hash_fn)dlsym(h, "CryptHash");
    if (!fn) { fprintf(stderr, "dlsym: %s\n", dlerror()); return 4; }
    static const size_t lens[] = {0,1,7,8,9,15,16,17,31,32,33,63,64,65,127,128,129,
                                   255,256,257,1023,4097};
    unsigned char *msg = (unsigned char *)malloc(8192);
    unsigned char dig[256];
    for (size_t i = 0; i < sizeof(lens)/sizeof(lens[0]); i++) {
        size_t n = lens[i];
        for (size_t j = 0; j < n; j++) msg[j] = (unsigned char)((j * 37u + 11u) & 0xFFu);
        memset(dig, 0xA5, sizeof dig);
        int rc = fn(1024, msg, (unsigned long long)n * 8ull, dig);
        printf("len=%zu rc=%d dig=", n, rc);
        for (int k = 0; k < 1024 / 8; k++) printf("%02x", dig[k]);
        printf("\n");
    }
    free(msg);
    dlclose(h);
    return 0;
}
