#!/usr/bin/env bash
# 官方参考版：REFFLAGS。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-std=c99 -Wpedantic -Wall -Wextra -O2"
mkdir -p ../../build
gcc $FLAGS -shared -fPIC -o ../../build/ref_768.so CryptHash_AlgorithmInstance.c
echo "built build/ref_768.so"
