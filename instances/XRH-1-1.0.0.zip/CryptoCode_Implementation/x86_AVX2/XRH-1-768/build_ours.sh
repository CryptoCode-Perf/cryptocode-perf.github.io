#!/usr/bin/env bash
# XRH-1-768 的 CryptoCode 实现：四个 jasmin 生成的 .s 核 + C 外壳（glue + vec_api）。
set -euo pipefail
cd "$(dirname "$0")"
REF=../../../Reference_Implementation/XRH-1-768
OPT=../../../Optimized_Implementation/XRH-1-768
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../../build
for c in xrh_round1 xrh_r0_9 xrh_r9_18 xrh_r0_18; do
    gcc $FLAGS -c -o ../../../build/${c}.o $c.s
done
gcc $FLAGS -fPIC -c -I "$OPT" -I "$REF" -o ../../../build/vec_api.o vec_api.c
gcc $FLAGS -fPIC -c -I "$OPT" -I "$REF" -o ../../../build/glue.o glue_xrh1768.c
gcc -shared -fPIC -o ../../../build/our_768.so \
    ../../../build/xrh_round1.o ../../../build/xrh_r0_9.o \
    ../../../build/xrh_r9_18.o ../../../build/xrh_r0_18.o \
    ../../../build/vec_api.o ../../../build/glue.o
echo "built build/our_768.so"
