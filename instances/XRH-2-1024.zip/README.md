# XRH-2-1024

Algorithm: XRH-2 | Digest bits: 1024 | Form: AVX2 汇编

Contents: implementation source/, public header XRH-2-1024.h, prebuilt XRH-2-1024.so,
KAT vector KAT_2_12_XRH-2-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 481a2ccafc6c8952883ee606ab055c956cb73274ca60e8af6ba11f62dbbc45ee
Speed (cpB, lower is faster): reference 59.44 / official-optimized 49.49 / optimized 42.60
Speedup: GM(S1-S8) 1.13x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
