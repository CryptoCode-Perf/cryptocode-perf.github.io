#!/usr/bin/env bash
# MOZI 1.0.0 —— 三方编译 + 22 长度差分 + 黄金向量 + KAT 4097
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build

echo "== [MOZI-384] 1/4 编译三方 =="
bash Reference_Implementation/MOZI-384/build_ref.sh
bash Optimized_Implementation/MOZI-384/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/MOZI-384/build_ours.sh
echo "== [MOZI-384] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_384 test/vec_MOZI-384.c -ldl
./build/vec_384 build/ref_384.so > build/vec_ref_384.txt
./build/vec_384 build/off_384.so > build/vec_off_384.txt
./build/vec_384 build/our_384.so > build/vec_our_384.txt
cmp build/vec_ref_384.txt build/vec_off_384.txt
cmp build/vec_ref_384.txt build/vec_our_384.txt
cp build/vec_ref_384.txt test/golden_vectors_ref_384.txt
echo "== [MOZI-384] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_384.so 100000 0 kat/KAT_2_12_MOZI-384.txt
python3 test/kat_check.py build/off_384.so 100000 0 kat/KAT_2_12_MOZI-384.txt
python3 test/kat_check.py build/our_384.so 100000 0 kat/KAT_2_12_MOZI-384.txt
echo "== [MOZI-384] 4/4 完成 =="

echo "== [MOZI-512] 1/4 编译三方 =="
bash Reference_Implementation/MOZI-512/build_ref.sh
bash Optimized_Implementation/MOZI-512/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/MOZI-512/build_ours.sh
echo "== [MOZI-512] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_512 test/vec_MOZI-512.c -ldl
./build/vec_512 build/ref_512.so > build/vec_ref_512.txt
./build/vec_512 build/off_512.so > build/vec_off_512.txt
./build/vec_512 build/our_512.so > build/vec_our_512.txt
cmp build/vec_ref_512.txt build/vec_off_512.txt
cmp build/vec_ref_512.txt build/vec_our_512.txt
cp build/vec_ref_512.txt test/golden_vectors_ref_512.txt
echo "== [MOZI-512] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_512.so 100000 0 kat/KAT_2_12_MOZI-512.txt
python3 test/kat_check.py build/off_512.so 100000 0 kat/KAT_2_12_MOZI-512.txt
python3 test/kat_check.py build/our_512.so 100000 0 kat/KAT_2_12_MOZI-512.txt
echo "== [MOZI-512] 4/4 完成 =="

echo "== [MOZI-768] 1/4 编译三方 =="
bash Reference_Implementation/MOZI-768/build_ref.sh
bash Optimized_Implementation/MOZI-768/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/MOZI-768/build_ours.sh
echo "== [MOZI-768] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_768 test/vec_MOZI-768.c -ldl
./build/vec_768 build/ref_768.so > build/vec_ref_768.txt
./build/vec_768 build/off_768.so > build/vec_off_768.txt
./build/vec_768 build/our_768.so > build/vec_our_768.txt
cmp build/vec_ref_768.txt build/vec_off_768.txt
cmp build/vec_ref_768.txt build/vec_our_768.txt
cp build/vec_ref_768.txt test/golden_vectors_ref_768.txt
echo "== [MOZI-768] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_768.so 100000 0 kat/KAT_2_12_MOZI-768.txt
python3 test/kat_check.py build/off_768.so 100000 0 kat/KAT_2_12_MOZI-768.txt
python3 test/kat_check.py build/our_768.so 100000 0 kat/KAT_2_12_MOZI-768.txt
echo "== [MOZI-768] 4/4 完成 =="

echo "== [MOZI-1024] 1/4 编译三方 =="
bash Reference_Implementation/MOZI-1024/build_ref.sh
bash Optimized_Implementation/MOZI-1024/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/MOZI-1024/build_ours.sh
echo "== [MOZI-1024] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_1024 test/vec_MOZI-1024.c -ldl
./build/vec_1024 build/ref_1024.so > build/vec_ref_1024.txt
./build/vec_1024 build/off_1024.so > build/vec_off_1024.txt
./build/vec_1024 build/our_1024.so > build/vec_our_1024.txt
cmp build/vec_ref_1024.txt build/vec_off_1024.txt
cmp build/vec_ref_1024.txt build/vec_our_1024.txt
cp build/vec_ref_1024.txt test/golden_vectors_ref_1024.txt
echo "== [MOZI-1024] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_1024.so 100000 0 kat/KAT_2_12_MOZI-1024.txt
python3 test/kat_check.py build/off_1024.so 100000 0 kat/KAT_2_12_MOZI-1024.txt
python3 test/kat_check.py build/our_1024.so 100000 0 kat/KAT_2_12_MOZI-1024.txt
echo "== [MOZI-1024] 4/4 完成 =="

echo "== 验证全部通过 =="
