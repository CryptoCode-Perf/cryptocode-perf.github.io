#!/usr/bin/env bash
# 官方参考版：C，REFFLAGS。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-std=c99 -Wpedantic -Wall -Wextra -O2"
mkdir -p ../../build
gcc $FLAGS -shared -fPIC -o ../../build/ref_384.so CryptHash_AlgorithmInstance.c -lm
echo "built build/ref_384.so"
