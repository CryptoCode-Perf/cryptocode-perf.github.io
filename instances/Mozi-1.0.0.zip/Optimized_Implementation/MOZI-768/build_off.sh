#!/usr/bin/env bash
# 官方优化版是 C++（vendor 自己的 .cpp）：需要 C++17 编译器。
# 用 $CXX 覆盖（默认 g++）；-std=c99 换成 -std=c++17，其余 flag 不变。
set -euo pipefail
cd "$(dirname "$0")"
CXX=${CXX:-g++}
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c++17 -Wpedantic -Wall -Wextra"
mkdir -p ../../build
$CXX $FLAGS -shared -fPIC -o ../../build/off_768.so CryptHash_AlgorithmInstance_fast.cpp
echo "built build/off_768.so"
