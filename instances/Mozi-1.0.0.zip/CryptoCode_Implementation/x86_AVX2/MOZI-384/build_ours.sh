#!/usr/bin/env bash
# MOZI-384 的 CryptoCode 实现：官方外壳逐字保留 + 引擎置换核（手写外壳 + 引擎核）。
set -euo pipefail
cd "$(dirname "$0")"
REF=../../../Reference_Implementation/MOZI-384
OPT=../../../Optimized_Implementation/MOZI-384
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../../build
gcc $FLAGS -shared -fPIC -I "$REF" -I "$OPT" \
    -o ../../../build/our_384.so ref_agent.c mozi_v256b.s -lm
echo "built build/our_384.so"
