/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).

ICCS doesn't represent or warrant that the operation of the software will be
uninterrupted or error-free in all cases. ICCS will take no responsibility for
the use of the software or the results thereof, if the software is used for any
other purposes.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "CryptHash_AlgorithmInstance.h"

#include <stdint.h>
#define ULL unsigned long long

/// @brief The rotation offsets for ShiftRow
static const int rhoY[4][4] = {
    {0, 14, 20, 22},
    {0, 13, 68, 91},
    {0, 27, 42, 106},
    {0, 32, 48, 80}
};

/// @brief The round constants for AddRoundConstant
static const ULL RCON[24] = {
    0x24, 0x3f, 0x6a, 0x88, 0x85, 0xa3, 0x08, 0xd3, 0x13, 0x19, 0x8a, 0x2e,
    0x03, 0x70, 0x73, 0x44, 0xa4, 0x09, 0x38, 0x22, 0x29, 0x9f, 0x31, 0xd0
};

/// @brief The multiplication function for bit-sliced operations
static inline void MUL(ULL *x0, ULL *x1, ULL *x2, ULL *x3){
    ULL tmp = *x3; 
    *x3 = *x2; *x2 = *x1; *x1 = *x0; *x0 = tmp; // rotation
    *x1 ^= *x0; // XOR
}

/// @brief The bit-sliced MDS matrix multiplication
static inline void bitSliceMDS(ULL *x0, ULL *x1, ULL *x2, ULL *x3,
                        ULL *x4, ULL *x5, ULL *x6, ULL *x7,
                        ULL *x8, ULL *x9, ULL *xa, ULL *xb, 
                        ULL *xc, ULL *xd, ULL *xe, ULL *xf){
    *x8 ^= *xc; *x9 ^= *xd; *xa ^= *xe; *xb ^= *xf; // C ^= D
    *x0 ^= *x4; *x1 ^= *x5; *x2 ^= *x6; *x3 ^= *x7; // A ^= B
    MUL(x4, x5, x6, x7); // B = MUL(B)
    MUL(xc, xd, xe, xf); // D = MUL(D)
    *x4 ^= *x8; *x5 ^= *x9; *x6 ^= *xa; *x7 ^= *xb; // B ^= C
    *xc ^= *x0; *xd ^= *x1; *xe ^= *x2; *xf ^= *x3; // D ^= A
    MUL(x0, x1, x2, x3); // A = MUL(A)
    MUL(x0, x1, x2, x3); // A = MUL(A)
    MUL(x8, x9, xa, xb); // C = MUL(C)
    MUL(x8, x9, xa, xb); // C = MUL(C)
    *x8 ^= *xc; *x9 ^= *xd; *xa ^= *xe; *xb ^= *xf; // C ^= D
    *x0 ^= *x4; *x1 ^= *x5; *x2 ^= *x6; *x3 ^= *x7; // A ^= B
    *x4 ^= *x8; *x5 ^= *x9; *x6 ^= *xa; *x7 ^= *xb; // B ^= C
    *xc ^= *x0; *xd ^= *x1; *xe ^= *x2; *xf ^= *x3; // D ^= A
}

/// @brief The permutation function of MOZI-768
/// @param[in] state The base address of the internal state
/// @param[in] roundNum The number of rounds to execute (should be equal to 24)
/* ---- 置换核心换成引擎核（JIR -> ir_text.to_jasmin -> jasminc）----
 * 官方本函数是标量 C（A/B/C/D 四份 4x4x2 的 ULL 数组 + 8 次逐字节移位装载），
 * 内核换成本文件同目录下 mozi_perm.s 里的 mozi_perm24，轮数 24 已展开进去。
 * 其余（padding / absorb / hash_Fsponge / squeeze）逐字保留官方实现。 */
void mozi_perm24(uint64_t *p);

void permutation(unsigned char *state, int roundNum) {
    (void)roundNum;
    mozi_perm24((uint64_t *)state);
}


/// @brief The hash function based on F-sponge construction
/// @param[in] hash The hash length in BYTES (should be equal to 128)
/// @param[in] rate The rate in BYTES (should be equal to 120)
/// @param[in] input The base address of message
/// @param[in] input_len_bits The length of message in BITS
/// @param[in] output_len_bits The length of digest in BITS (should be equal to hash)
/// @param[out] output The base address of digest
/// @return 0 for success, 1 for error
int hash_Fsponge(int hash, int rate, const unsigned char *input, ULL input_len_bits, int output_len_bits, unsigned char *output){
    if (rate != 120 || hash != 128){
        printf("Invalid rate or hash length\n");
        return 1;
    }
    unsigned char state[256];
    unsigned char IV[256];
    memset(IV, 0, sizeof(IV));
    memcpy(state, IV, sizeof(IV));
    // padding
    ULL padded_input_len_bits = ((input_len_bits + rate*8) / (rate*8)) * rate*8;
    ULL padded_input_len = padded_input_len_bits / 8;
    unsigned char *padded_input = (unsigned char *)malloc(padded_input_len);
    memset(padded_input, 0, padded_input_len);
    ULL full_bytes = input_len_bits / 8;
    int remaining_bits = input_len_bits % 8;
    memcpy(padded_input, input, full_bytes);
    if (remaining_bits > 0) {
        unsigned char mask = 0xFF << (8 - remaining_bits);
        padded_input[full_bytes] = input[full_bytes] & mask;
        padded_input[full_bytes] |= 0x80 >> remaining_bits; // padding with 0x80
    } else {
        padded_input[full_bytes] = 0x80; // padding with 0x80
    }
    // absorbing phase
    int blocks = padded_input_len / rate;
    unsigned char forward[256];
    memset(forward, 0, sizeof(forward));
    for (int i = 0; i < blocks; i++) {
        for (int j = 0; j < rate; j++) {
            state[j] ^= padded_input[i * rate + j];
        }
        if (i == blocks - 1) {
            state[rate] ^= 0x80; // domain separation
        }
        memcpy(forward + rate, state + rate, 256 - rate);
        permutation(state, 24);
        // feedforward
        for (int j = rate; j < 256; j++) {
            state[j] ^= forward[j];
        }
    }
    // squeezing phase
    for (int i = 0; i < hash; i ++){
        output[i] = state[256 - hash + i];
    }
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest)
{
    return hash_Fsponge(digest_len_bits / 8, 120, msg, msg_len_bits, digest_len_bits, digest);
}