#!/usr/bin/env bash
# 官方优化版：十 flag 直接编 CryptHash_AlgorithmInstance.c（与当年测速用的对手件同配方）。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../build
gcc $FLAGS -shared -fPIC -o ../../build/off_768.so CryptHash_AlgorithmInstance.c -lm
echo "built build/off_768.so"
