#!/usr/bin/env bash
# TaiChi-1024 的 CryptoCode 实现：生成式单文件，纯 C（-DTC_NO_BMI2）。
set -euo pipefail
cd "$(dirname "$0")"
REF=../../../Reference_Implementation/TaiChi-1024
OPT=../../../Optimized_Implementation/TaiChi-1024
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../../build
gcc $FLAGS -DTC_NO_BMI2 -shared -fPIC -I "$OPT" -I "$REF" \
    -o ../../../build/our_1024.so our_taichi.c -lm
echo "built build/our_1024.so"
