#!/usr/bin/env python3
"""Generate src/qilin1024.c for QILIN-1024 (hash-23) -- OUR OWN implementation.

Reads the OFFICIAL reference source to extract n1/n2/m/rc and asserts they equal
the values hard-coded here (so a silent transcription error is impossible).

Round design
------------
REF round (CryptHash_AlgorithmInstance.c:15-64):
    linear layer : for k in 0..27  y[7+k][c] = y[n1[k]][c] ^ ROL64(y[n2[k]][c], m[k])
                   for s,c        x[s][c]   = y[28+s][(7-s+c)%7]
    S-box        : per row s, t[0..6] then x[(s+k)%7][k]
    add constant : x[0][0] ^= rc[r]

Our round:
  - linear layer vectorised over COLUMNS: columns 0..3 in one ymm pass, columns 4..6
    in a second ymm pass (4th lane is padding).  Per pass 28 steps: m==0 -> 1 op
    (vpxor), m!=0 -> 4 ops (vpsllq/vpsrlq/vpor/vpxor).  16 non-zero m per column.
    The 7 tail values (k=21..27 == y[28+s]) are stored, transposed, into T[7][8]
    with 32-byte stores.
  - S-box scalar, 7 rows, reading T[s][0..6] and writing straight into X.

There is NO scalar rotate anywhere in this design (rotates only live inside the
vectorised linear layer), so no BMI2 / rorx is needed.
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)

N1 = [5, 2, 4, 1, 6, 3, 0, 7, 10, 11, 14, 8, 16, 12, 9, 13, 11, 8, 18, 19,
      20, 24, 22, 25, 23, 21, 26, 27]
N2 = [2, 4, 1, 6, 3, 0, 7, 5, 12, 9, 13, 15, 17, 18, 19, 20, 21, 22, 23, 24,
      24, 22, 25, 23, 21, 26, 27, 20]
M = [0, 0, 0, 0, 0, 0, 1, 39, 23, 18, 46, 54, 5, 15, 26, 33, 46, 44, 9, 30,
     0, 0, 0, 0, 0, 0, 1, 39]
RC = [0x1027fd7, 0x1027fd6, 0x1027fd5, 0x1027fd3, 0x1027fc6, 0x1027f95,
      0x1027f53, 0x1027ec6, 0x1027d95, 0x1027b53, 0x10276c6, 0x1026d95,
      0x1025b53, 0x10236c6, 0x1006d95, 0x25b52]


def find_ref():
    cands = []
    for root, dirs, files in os.walk(os.path.join(L0, "src", "hash-23")):
        for f in files:
            if (f == "CryptHash_AlgorithmInstance.c" and "Reference_Implementation" in root
                    and "QILIN-1024" in root):
                cands.append(os.path.join(root, f))
    assert len(cands) == 1, cands
    return cands[0]


def grab(text, name, n):
    mrec = re.search(re.escape(name) + r"\s*(?:\s*\[[^\]]*\])+\s*=\s*\{(.*?)\}\s*;",
                     text, re.S)
    assert mrec, name
    vals = [int(x, 0) for x in re.findall(r"0[xX][0-9a-fA-F]+|\d+", mrec.group(1))]
    assert len(vals) == n, (name, len(vals))
    return vals


def parse_ref():
    src = open(find_ref(), encoding="utf-8", errors="replace").read()
    out = {}
    for name, n in (("n1", 28), ("n2", 28), ("m", 28), ("rc", 16)):
        out[name] = grab(src, name, n)
    return out


# ---------------------------------------------------------------- emit linear
def emit_pass(f, off, tag):
    f.write("    {   /* pass %s: columns %d..%d */\n" % (tag, off, off + 3))
    f.write("        const int off = %d;\n" % off)
    for i in range(7):
        f.write("        __m256i w%d = _mm256_loadu_si256((const __m256i *)(X[%d] + off));\n"
                % (i, i))
    for k in range(28):
        a, b, sh = N1[k], N2[k], M[k]
        an = "w%d" % a if a >= 7 else "w%d" % a
        bn = "w%d" % b if b >= 7 else "w%d" % b
        f.write("        __m256i w%d = QL_XR(%s, %s, %d);\n" % (7 + k, an, bn, sh))
    for s in range(7):
        f.write("        _mm256_storeu_si256((__m256i *)(T[%d] + off), w%d);\n"
                % (s, 28 + s))
    f.write("    }\n")


SBOX_T = [("&", "|"), ("|", "&")]


def emit_sbox(f):
    for s in range(7):
        f.write("    {   /* S-box row %d */\n" % s)
        f.write("        const volatile uint64_t *ps = T[%d];\n" % s)
        for k in range(7):
            f.write("        const uint64_t A%d = ps[%d];\n"
                    % (k, (k - s + 7) % 7))
        ops = ["&", "|", "&", "|", "&", "~&", "|"]
        for k in range(7):
            o = ops[k]
            if o == "~&":
                expr = "((~A%d) & A%d)" % ((k + 1) % 7, (k + 2) % 7)
            else:
                expr = "(A%d %s A%d)" % ((k + 1) % 7, o, (k + 2) % 7)
            f.write("        const uint64_t d%d = %s ^ A%d;\n" % (k, expr, k))
        fk = [(-2 * k) % 7 for k in range(8)]
        for k in range(7):
            o = ops[k]
            a, b, c = fk[k], fk[k + 1], (fk[k] + 2) % 7
            if o == "~&":
                expr = "((~d%d) & d%d)" % (a, b)
            else:
                expr = "(d%d %s d%d)" % (a, o, b)
            f.write("        X[%d][%d] = %s ^ d%d;\n"
                    % ((s + k) % 7, k, expr, c))
        f.write("    }\n")


def main():
    ref = parse_ref()
    for name, want in (("n1", N1), ("n2", N2), ("m", M), ("rc", RC)):
        assert ref[name] == want, "MISMATCH %s: ref=%s" % (name, ref[name])
        print("check ok: %s (%d entries)" % (name, len(want)))

    out = os.path.join(HERE, "src", "qilin1024.c")
    with open(out, "w", encoding="utf-8") as f:
        f.write("/* QILIN-1024 -- our own implementation.  GENERATED by gen_qilin.py;\n"
                " * do not edit by hand.  Tables are extracted from the official\n"
                " * reference source and asserted equal at generation time. */\n")
        f.write("#include <stdint.h>\n#include <string.h>\n#include <immintrin.h>\n\n")
        f.write("#define QL_STATE_BITS 3136\n#define QL_RATE_BYTES_MAX 392\n\n")
        f.write("static const uint64_t ql_rc[16] = {\n")
        for i in range(0, 16, 2):
            f.write("    0x%016xULL, 0x%016xULL,\n" % (RC[i], RC[i + 1]))
        f.write("};\n\n")
        f.write("/* a ^ (b <<< m)  (m is a compile-time constant) */\n")
        f.write("#define QL_XR(a, b, m) ((m) == 0 ? _mm256_xor_si256((a), (b)) \\\n"
                "    : _mm256_xor_si256((a), _mm256_or_si256(_mm256_slli_epi64((b), (m)), \\\n"
                "                                            _mm256_srli_epi64((b), 64 - (m)))))\n\n")
        f.write("static void ql_round(uint64_t X[7][8], uint64_t rc)\n{\n")
        f.write("    uint64_t T[7][8];\n")
        emit_pass(f, 0, "A")
        emit_pass(f, 4, "B")
        emit_sbox(f)
        f.write("    X[0][0] ^= rc;\n}\n\n")

        # ---------------------------------------------------------- driver
        f.write("""static uint64_t ql_ld64(const unsigned char *p)
{
    uint64_t v;
    memcpy(&v, p, 8);
    return v;
}

static int ql_rounds_for(int digest_len_bits)
{
    /* Mirrors the official reference exactly: it validates nothing, and only
     * 1024 / 768 change the round count; everything else uses 12. */
    if (digest_len_bits == 1024) return 16;
    if (digest_len_bits == 768)  return 14;
    return 12;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    uint64_t X[7][8];
    unsigned char last_block[QL_RATE_BYTES_MAX];
    unsigned long long processed_bits = 0, remaining_bits, remaining_bytes;
    int R = ql_rounds_for(digest_len_bits);
    int rate_bits, rate_bytes, rate_words, j, i;

    rate_bits  = QL_STATE_BITS - 2 * digest_len_bits;
    rate_bytes = rate_bits / 8;
    rate_words = rate_bits / 64;

    memset(X, 0, sizeof X);

    while (processed_bits + (unsigned long long)rate_bits <= msg_len_bits) {
        const unsigned char *p = msg + processed_bits / 8;
        for (j = 0; j < rate_words; j++)
            X[j % 7][j / 7] ^= ql_ld64(p + j * 8);
        for (i = 0; i < R; i++) ql_round(X, ql_rc[i]);
        processed_bits += (unsigned long long)rate_bits;
    }

    memset(last_block, 0, sizeof last_block);
    remaining_bits  = msg_len_bits - processed_bits;
    remaining_bytes = (remaining_bits + 7) / 8;
    if (remaining_bytes) memcpy(last_block, msg + processed_bits / 8, (size_t)remaining_bytes);
    if (remaining_bits % 8)
        last_block[remaining_bits / 8] &= (unsigned char)(0xFFu << (8 - (remaining_bits % 8)));
    last_block[remaining_bits / 8] |= (unsigned char)(1u << (7 - (remaining_bits % 8)));

    if (remaining_bits + 1 == (unsigned long long)rate_bits) {
        for (j = 0; j < rate_words; j++)
            X[j % 7][j / 7] ^= ql_ld64(last_block + j * 8);
        for (i = 0; i < R; i++) ql_round(X, ql_rc[i]);
        memset(last_block, 0, (size_t)rate_bytes);
    }

    last_block[rate_bytes - 1] |= 0x01u;

    for (j = 0; j < rate_words; j++)
        X[j % 7][j / 7] ^= ql_ld64(last_block + j * 8);
    for (i = 0; i < R; i++) ql_round(X, ql_rc[i]);

    for (i = 0; i < digest_len_bits / 64; i++) {
        uint64_t v = X[i % 7][i / 7];
        memcpy(digest + i * 8, &v, 8);
    }
    return 0;
}

#ifdef QL_TEST_HOOKS
/* G1 hooks: apply n rounds (r = 0..n-1) to a caller-provided state. */
void ql_hook_rounds(uint64_t X[7][8], int n)
{
    int i;
    for (i = 0; i < n; i++) ql_round(X, ql_rc[i]);
}
/* G5 negative control: expose the round count used for a digest length. */
int ql_hook_rounds_for(int b) { return ql_rounds_for(b); }
#endif
""")
    print("wrote", out, os.path.getsize(out), "bytes")


if __name__ == "__main__":
    sys.exit(main())
