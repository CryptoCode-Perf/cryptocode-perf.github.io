#!/usr/bin/env bash
# QILIN-1024 -- build our delivery artifact.
# MUST be run inside WSL:  wsl.exe -e bash -lc 'cd .../l0/qilin && bash build.sh'
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
mkdir -p out scratch

FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"

python3 gen_qilin.py

rm -f out/ours_qilin1024.so out/ours_qilin1024.o out/ours_qilin1024_hooks.o

gcc $FLAGS -fPIC -shared -o out/ours_qilin1024.so src/qilin1024.c
gcc $FLAGS -fno-lto -c -o out/ours_qilin1024.o src/qilin1024.c
gcc $FLAGS -fno-lto -fPIC -shared -DQL_TEST_HOOKS -o scratch/ql_hooks.so src/qilin1024.c

# disassembly + size
objdump -d --no-show-raw-insn out/ours_qilin1024.so > scratch/ours.dis
nm -S --size-sort out/ours_qilin1024.o | tail -n 5

sha256sum src/qilin1024.c out/ours_qilin1024.so out/ours_qilin1024.o
ls -l out/ours_qilin1024.so
