# QILIN-1024 (hash-23) — 交付结果（**未计时**）

**本文件不含任何时间测量。所有数字都是指令条数。** 计时由 lead 串行执行。

---

## 0. 交付件

| 文件 | 大小 | sha256 |
|---|---|---|
| `out/ours_qilin1024.so` | **19584 B** | **`c21fe02b8f64dd758a9dbe2768627215da50e3467dbeed96d7f1de082109c4d0`** |
| `out/ours_qilin1024.o` | 5592 B | `adf1fa3c18bb52ab7808af218f133e4cd034daf18e5f2bf534a9bca539a1405a` |
| `src/qilin1024.c`（生成物） | 14231 B | `c145399881aba045cb741b3f450cea9701881031e96480e80e1cd0bd694a63df` |

对手（只读，未改）：

| 文件 | 大小 | sha256 |
|---|---|---|
| `../build/hash-23/qilin1024/opt.so` | 31808 B | `e4880479c2f96401716463907ea60e5d71f90c9428ee2eacb72831a9a0744783` |
| `../build/hash-23/qilin1024/ref.so` | 15488 B | `eb28a77a79a70b04d3cd9139a64e9dd99ea98d982ad2bae1bb8d66732da18b89` |

`qilin{512,768,1024}/opt.so` **逐字节相同**（同一个 `CryptHash` 三种摘要长度，见 §3）。

构建：`bash reproduce.sh`（WSL 内）⇒ **`REPRODUCE: overall rc=0`**。
交付件用官方十 flag 编译、**零 warning**：
```
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer \
    -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o out/ours_qilin1024.so src/qilin1024.c
```

## 1. 条数一句话

**每轮 616.0 条 vs 对手 991 条 = 0.6216；每 1088 位块 10230 条 vs 15855 条 = 0.6452。**
（推导、两段分解、原始表见 `DYNCOUNT.md`。这是条数，不是时间。）

## 2. G1–G6 实测

### G1 单轮置换 / 同 TU 直调官方 —— `PASS`

```bash
python3 gates/make_ref.py        # 官方 REF 源 → gates/ref_core.inc（符号加 ref_ 前缀）
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 \
    -Wpedantic -Wall -Wextra -Wno-unused-function -o scratch/g1 gates/g1_same_tu.c
./scratch/g1
```
`gates/g1_same_tu.c` 把官方参考核心与我们的实现 **#include 进同一个 TU**（先 `#include "ref_core.inc"`，
再 `#define QL_TEST_HOOKS` + `#include "../src/qilin1024.c"`）——**没有任何跨 TU 薄包装**。

实测输出：
```
G1[1a] round chain n=1   checked=200 mismatch=0
G1[1a] round chain n=2   checked=200 mismatch=0
G1[1a] round chain n=3   checked=200 mismatch=0
G1[1a] round chain n=8   checked=200 mismatch=0
G1[1a] round chain n=16  checked=200 mismatch=0
G1[2] whole digest checked=60 mismatch=0
G1[3a] control broken-round-count is detected: yes
G1[3b] control n=0 identity: ok
G1: checked=1062 mismatch=0            rc=0
```
GCC 3 条告警全部来自**官方参考源自身**（`-Wsign-compare` 在 `ref_CryptHash` 里）与探针的
`-Wpedantic` 数组限定符，**交付件本身零 warning**（§0）。

### G2 完整 `CryptHash` 逐字节对拍 —— `PASS (103/103)`

```bash
python3 gates/g2_full.py
```
- 3 种摘要长度（1024/768/512）× 33 个位长 = **99 组**，逐字节比全部被覆写的 128/96/64 字节；
- 位长**显式传第 3 参**（绝不 `len(hex)*8`）；消息指针故意 `addressof(buf)+1`（非对齐）；
- 含 **0 位空消息**与非字节对齐（1/7/9/65/511/513/1087/1089/2047/2049 位）；
- 契约 4 条：`digest_len=1000`、512 位摘要、1 位翻转必变、A/A 自比。

实测：
```
digest lengths: 99 checks, 0 fails
contract digest_len=1000 (ref does not validate): ours rc=0 ref rc=0 digest OK
contract 512-bit digest: OK
contract 1-bit flip changes digest: OK
contract A/A same digest: OK
G2 PASS (103/103 checks pass)
```

### G3 KAT 门 —— `PASS (40/40)`

```bash
python3 gates/g3_kat.py
```
```
kat_gate from .../_overnight/l0/kat_gate.py
records=4097 vector_files=1 [.../src/hash-23/QILIN/Test_Vectors/KAT_2_12_QILIN-1024.txt]
G3: checked=40 match=40 err=None first_bad=None pass=True
```
**没有撞上包内的过时副本**：`find_kat` 选中 `Test_Vectors/` 下的 `KAT_2_12_QILIN-1024.txt`（4097 条记录里取前 `MAX_RECORDS=40`）。
包内的 6 个 `KAT_CryptHash.c` 未被选中（TASK_qilin.md 警示过 Iphe 上「三件全 0/40」的假红）。

### G4 第四道门 —— `PASS (11/11)`

```bash
python3 ../delivery_gate.py out/ours_qilin1024.so ../build/hash-23/qilin1024/ref.so 1024
```
```
   0/8/128/512/1000/1024/2048/4096/8192/16384/65536 bits  → 全部「候选写128B 参考写128B rc=0/0 一致」
判定：全过
```

### G5 负对照 + 负-负对照 —— `PASS`

```bash
python3 gates/negctl.py
```
```
baseline ours_qilin1024.so sha256=c21fe02b8f64dd758a9dbe2768627215da50e3467dbeed96d7f1de082109c4d0
none      rebuild sha256 identical: True  digests identical: True
rc0       occurrences=1  changed=8/8  unchanged=-  OK
acdest    occurrences=1  changed=8/8  unchanged=-  OK
sboxop    occurrences=7  changed=8/8  unchanged=-  OK
linrot    occurrences=2  changed=8/8  unchanged=-  OK
padlast   occurrences=1  changed=8/8  unchanged=-  OK
G5 PASS (1 negative-negative control + 5 single-site mutations)
```
- `none`：源码一字不改重编 ⇒ **.so 的 sha256 与交付件逐字节相同**、38 个位长摘要全同 ⇒ 构建可复现。
- 5 个单点变异（`ql_rc[0]` 末位、加常量目标格 `X[0][0]→X[1][0]`、S 盒首条 `&`→`|`、线性层首步 `m=0→1`、末位填充 `0x01→0x02`）
  **在全部 8 个测试位长上都改变了摘要**。位长取 `{0,1,8,1087,1088,1089,4096,17408}`；
  8 个全变也说明这些变异都作用在**每次调用都走**的路径上（`padlast` 那行 `rem==0` 时也执行）。

### G6 共享脚本回归 —— `PASS`

```bash
cd ../../.. && bash run_tests.sh          # 「失败的测试文件数: 0」
python3 test_semantics_golden.py           # 「全部通过：检查 112 项」
```

## 3. 设计决定与契约（需要 lead 知情的地方）

1. **官方 `CryptHash` 不校验 `digest_len_bits`**（`REF:67-144` 全文没有非 0 返回）。
   我们**逐字复刻**：`ql_rounds_for()` 只把 1024→16、768→14，其余（含 512、1000）→12，永不返回错误。
   `digest_len=1000` 时 rate = 1136 位 = 142 B，**双方摘要逐字节相同**（G2 已验证）。
   这是**故意**的选择：若这里「更严格地」返回 −1，G2 会因行为不一致而红。
2. **尾块缓冲放大到 392 B**（官方 265 B）。官方那 265 B 只在 `digest_len_bits ≥ 508` 时够用；
   放大不改变任何测试范围内的行为（G2 103/103），但让我们在 `digest_len_bits` 取小值时不越界写。
3. **`T` 数组的读用 `const volatile`**：语义完全相同（写 `T` 读 `T`），只为阻止 GCC 把换列合成为
   `vpextrq`/`vpinsrq` 链（实测 `ql_round` 714→609 条、每块动态 11910→10230 条）。详见 `MODEL.md` §4.3。
4. **不使用内联汇编、不使用 `rorx`**（本实现零标量旋转），因此**不提供纯 C 回退件**——回退件规则只在用 `rorx` 时适用。

## 4. 指令层账（不测时间，只给形态）

```
$ python3 ../../../insn_mix.py out/ours_qilin1024.so
  ql_round   n=611  mov=229 (37%)  vec=184  vperm=0
  CryptHash  n=311  mov=130 (42%)  vec=31   vperm=0
$ python3 ../../../insn_mix.py ../build/hash-23/qilin1024/opt.so
  CryptHash  n=3900 mov=1768 (45%) vec=13   vperm=0
```
标量旋转计数（`objdump` + `grep -oE`，`rol|ror|rorx|shlx|shrx` 全族）：
**我方 0 条；官方 opt `rol:189 ror:147`（336 条）**。
我方旋转全部落在向量线性层的 `vpsllq/vpsrlq/vpor` 里（每轮 32+32+32 条 = 96 条向量移位）。

## 5. 诚实缺口

1. **条数比 0.6452 ≠ 时间比。** 对手是**纯标量**（`vec=13`、`vperm=0`、`mov` 占 45%），
   我们是「向量线性层 + 标量 S 盒」的混合体。本项目的校准史里条数预测偏差从 **−1.0%**
   （MasterCube 0.9944 → 1.0008）到 **方向都错**（Dragon 预测赢 32% 实际输 92.7%）。**只有 lead 的计时能定案。**
2. **S 盒没能向量化**（294 条/轮，占轮体 48%）。它的输出把 7 行按对角线轮转
   （`x[(s+k)%7][k]`），且每行的布尔算子随列号轮换（`& | & | & ~& |`）——
   在向量里表达就得**每 lane 用不同算子**，AVX2 无此能力（`vpblendvb` 要逐 lane 掩码，代价超过收益）。
   ⇒ 7×7 换列只能走内存（14 条 32 B 存 + 49 条 8 B 载），这 49 条是**跨 32 字节存储的 store-forwarding**。
3. **每块多 386 条驱动开销**（占 3.8%），来自吸收循环的 `j%7`/`j/7` 索引计算与 16 次 `ql_round` 调用。
   本轮没有动它：要消掉就得把状态改成列主序，那会伤害向量线性层（换列免费的收益更大）。
4. **没有为对手的「另一种形态」准备备选**：官方三个实例（512/768/1024）共用同一个 `opt.so`，
   所以不存在「判分机换实例就换路径」的风险（与 LLH 的 AVX-512 死代码缺口不同）。
5. **`digest_len_bits` 极小（< 508）时的行为**与官方一致地诡异（rate 超过尾块缓冲），
   我们只是不越界写；没有把这段行为当作契约来验证。

## 6. 第①步排除表结论（一句话）

**官方驱动层没有可回收的结构性冗余**（吸收 17 条 xor、挤出 16 条 store、填充逻辑与 REF 一致、
无表重建、无位序重排、轮内无分支/表查），成本 96.2% 在轮函数里；
唯一「浪费」是 245 个活标量对 16 个 GPR 的溢出（对手 `mov` 占 45%，每轮约 400 条）。
我方赢在**换表示**：把「按列 28 步」向量化，用 180 条向量指令换掉对手约 500 条标量。
完整 7 条排除表见 `MODEL.md` §5。
