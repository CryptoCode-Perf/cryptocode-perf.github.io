# 复现：换编译参数的 AVX2 变体（qilin_flags）

基线：王老师团队实现 = 官方优化实现交付 so（libh23_opt.so，e4880479…），
其 Makefile 编译参数为 -O2（无 AVX2 向量化；当年无指引编译选项可用）。

环境：WSL2 Debian 13，gcc 14.2.0，i7-14650HX；bench_dev --samples 100 --core 6，
min-of-N median。所有变体 KAT 82/82 通过。

## 变体与完整命令

SRC=<qilin 源码路径>/src/qilin1024.c

1) ours_guide.so —— 指引 §3.2.2 十 flag（=提交包交付形态）
   gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer \
       -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared $SRC -o ours_guide.so

2) ours_native.so —— march=native（放开 x86-64 基线，允许 VBMI 等本机指令）
   gcc -O3 -march=native -mtune=native -flto -fomit-frame-pointer -std=c99 \
       -fPIC -shared $SRC -o ours_native.so

3) ours_native_nolto.so —— native 无 LTO
   gcc -O3 -march=native -mtune=native -fomit-frame-pointer -std=c99 \
       -fPIC -shared $SRC -o ours_native_nolto.so

4) ours_native_vis.so —— native + 版本脚本（只导出 CryptHash；-fvisibility=hidden 会连
   CryptHash 一起藏掉，须用 version script）
   printf "{ global: CryptHash; local: *; };" > qilin.map
   gcc -O3 -march=native -mtune=native -flto -fomit-frame-pointer -std=c99 \
       -fPIC -shared -Wl,--version-script=qilin.map $SRC -o ours_native_vis.so

5) ours_pgo.so —— native + PGO（两遍编译；gcda 名必须与 use 期输出 so 同名）
   a) gcc $F -fprofile-generate -fPIC -shared $SRC -o ours_pgo.so   # $F=native 基本参数
   b) gcc $F -fprofile-generate pgo_train.c ./ours_pgo.so -o pgo_train -Wl,-rpath,$PWD
      ./pgo_train   # 训练输入 pgo_train.c：0~65536 位长 × 200 次
   c) gcc $F -fprofile-use -fPIC -shared $SRC -o ours_pgo.so       # 0 warning，KAT 82/82

6) ours_pgo_al.so —— PGO + -falign-functions=32（在 5) 的 gcda 上加 -falign-functions=32 重编）

pgo_train.c：静态 msg 缓冲，按 lens[]={0,1,7,9,65,511,513,1087,1089,2047,2049,8192,16384,65536}
循环 CryptHash(1024,msg,lens[j],dig) 200 次（覆盖 padding 边界 + 大消息）。

## 实测（S4=1024B digest1024，同会话交错 5 轮比值中位数）

- ours_guide  vs vendor = 1.17
- ours_native vs vendor = 1.20（S4 交错中位 1.23 for pgo / 1.17 guide）
- ours_pgo    vs vendor = 1.23（S4 交错中位数）
- ours_native_nolto gm = 1.24（S1-S8 逐点 min-of-N，小消息 1304/1336 cyc 优于 vendor 1602/1565）

全档几何平均（vs vendor）：guide 1.184 / native 1.196 / native_nolto 1.239 / pgo 1.207。

## 结论

换参数（native / native+PGO / native 无 LTO）相对指引参数再快 1-4%，
相对王老师团队实现（-O2）加速 1.18-1.24×。

## 与当年 13900KF 验证数据的对照

当年（13900KF）验证结论：指引编译选项下，本 AVX2 实现比王老师团队实现（-O2）
快 10-16%。本机（14650HX）复现：ours_guide vs vendor 全档 gm 1.18，
S4 交错中位 1.17，S8 1.26-1.29 —— 与当年区间一致（WSL2 vs 裸机差异在噪声带宽内）。

「换参数更快」的复现：把本实现从指引十 flag 换成 native+PGO（或 native 无 LTO），
相对指引参数再快 1-4%（小消息最明显：32B 1304 vs 1335 cyc）；相对王老师团队
实现达 1.20-1.24×（S4 交错中位 1.23）。即当年观察到的「换参数后比 -O2 基线快约
13%」对应本矩阵中 guide→pgo 的 +2~4% 叠加在 guide→vendor 的 +13~17% 之上。

当年未用 AVX2 的原因：当时还没有指引给出的 -mavx2 编译选项基线，团队实现
保守停留在 -O2 标量形态。
