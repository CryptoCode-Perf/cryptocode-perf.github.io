# QILIN-512

Algorithm: QILIN | Digest bits: 512 | Form: 标量 C

Contents: implementation source/, public header QILIN-512.h, prebuilt QILIN-512.so,
KAT vector KAT_2_12_QILIN-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): c21fe02b8f64dd758a9dbe2768627215da50e3467dbeed96d7f1de082109c4d0
Speed (cpB, lower is faster): reference 25.03 / official-optimized 4.38 / optimized 4.05
Speedup: GM(S1-S8) 1.10x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
