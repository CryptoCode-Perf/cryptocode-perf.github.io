	.att_syntax
	.text
	.p2align	5
	.global	zud_permute12
	.type	zud_permute12, %function
zud_permute12:
	vmovdqu	(%rdi), %ymm0
	vmovdqu	32(%rdi), %ymm1
	vmovdqu	64(%rdi), %ymm2
	vmovdqu	96(%rdi), %ymm3
	vmovdqu	128(%rdi), %ymm4
	vpxor	glob_data + 384(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 352(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm7
	vpandn	%ymm5, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm8
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm1
	vpermq	$147, %ymm6, %ymm3
	vpsrlq	$59, %ymm3, %ymm5
	vpsllq	$5, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$57, %ymm7, %ymm3
	vpshufb	glob_data + 0(%rip), %ymm3, %ymm3
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm5
	vpermq	$147, %ymm2, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm3, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm4, %ymm6
	vpsllq	$1, %ymm4, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 320(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm3, %ymm6
	vpandn	%ymm1, %ymm7, %ymm3
	vpxor	%ymm3, %ymm4, %ymm7
	vpermq	$147, %ymm5, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm3
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm4
	vpsrlq	$63, %ymm6, %ymm5
	vpsllq	$1, %ymm6, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$78, %ymm7, %ymm5
	vpsrlq	$61, %ymm5, %ymm6
	vpsllq	$3, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm2
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm5
	vpxor	%ymm7, %ymm2, %ymm6
	vpermq	$147, %ymm3, %ymm1
	vpsrlq	$59, %ymm1, %ymm7
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm7, %ymm1
	vpermq	$57, %ymm4, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm5, %ymm7
	vpsllq	$1, %ymm5, %ymm3
	vpor	%ymm3, %ymm7, %ymm3
	vpermq	$78, %ymm6, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 288(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm5
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm4
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm1
	vpsrlq	$63, %ymm3, %ymm6
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm6, %ymm2
	vpermq	$78, %ymm5, %ymm3
	vpsrlq	$61, %ymm3, %ymm5
	vpsllq	$3, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm7
	vpxor	%ymm5, %ymm2, %ymm8
	vpxor	%ymm5, %ymm3, %ymm5
	vpermq	$147, %ymm4, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm7, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm8, %ymm6
	vpsllq	$1, %ymm8, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 256(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 224(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpermq	$147, %ymm5, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 192(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm7
	vpandn	%ymm5, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm8
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm1
	vpermq	$147, %ymm6, %ymm3
	vpsrlq	$59, %ymm3, %ymm5
	vpsllq	$5, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$57, %ymm7, %ymm7
	vpshufb	glob_data + 0(%rip), %ymm7, %ymm3
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm5
	vpermq	$147, %ymm2, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm3, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm4, %ymm6
	vpsllq	$1, %ymm4, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 160(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm8
	vpandn	%ymm1, %ymm5, %ymm3
	vpxor	%ymm3, %ymm4, %ymm5
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm3
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm4
	vpsrlq	$63, %ymm8, %ymm6
	vpsllq	$1, %ymm8, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$78, %ymm5, %ymm5
	vpsrlq	$61, %ymm5, %ymm6
	vpsllq	$3, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm2
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm8
	vpxor	%ymm5, %ymm2, %ymm5
	vpermq	$147, %ymm3, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm4, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm8, %ymm6
	vpsllq	$1, %ymm8, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 128(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm4, %ymm7
	vpermq	$147, %ymm5, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm4
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm1
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$78, %ymm7, %ymm3
	vpsrlq	$61, %ymm3, %ymm5
	vpsllq	$3, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm5
	vpxor	%ymm7, %ymm2, %ymm8
	vpxor	%ymm7, %ymm3, %ymm6
	vpermq	$147, %ymm4, %ymm1
	vpsrlq	$59, %ymm1, %ymm7
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm7, %ymm1
	vpermq	$57, %ymm5, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm6, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 96(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 64(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 32(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm6
	vpandn	%ymm7, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm8
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm4, %ymm1
	vpermq	$147, %ymm5, %ymm3
	vpsrlq	$59, %ymm3, %ymm5
	vpsllq	$5, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$57, %ymm6, %ymm3
	vpshufb	glob_data + 0(%rip), %ymm3, %ymm3
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm1
	vpermq	$147, %ymm2, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm6
	vpermq	$57, %ymm3, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm4, %ymm5
	vpsllq	$1, %ymm4, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vmovdqu	%ymm0, (%rdi)
	vmovdqu	%ymm6, 32(%rdi)
	vmovdqu	%ymm2, 64(%rdi)
	vmovdqu	%ymm3, 96(%rdi)
	vmovdqu	%ymm1, 128(%rdi)
	ret
	.data
	.p2align	5
glob_data:
G$rotr40mask:
	.byte	  5,   6,   7,   0,   1,   2,   3,   4,  13,  14,  15,   8,   9,  10,  11,  12
	.byte	  5,   6,   7,   0,   1,   2,   3,   4,  13,  14,  15,   8,   9,  10,  11,  12
G$RC11:
	.byte	 18,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC10:
	.byte	160,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC9:
	.byte	240,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC8:
	.byte	128,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC7:
	.byte	 44,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC6:
	.byte	 96,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC5:
	.byte	 20,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC4:
	.byte	 32,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC3:
	.byte	208,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC2:
	.byte	192,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC1:
	.byte	 56,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RC0:
	.byte	 88,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits

	.text
	.p2align	5
	.global	zud_absorb_blocks_dmc
	.type	zud_absorb_blocks_dmc, %function
zud_absorb_blocks_dmc:
	vmovdqu	(%rdi), %ymm0
	vmovdqu	32(%rdi), %ymm1
	vmovdqu	64(%rdi), %ymm2
	vmovdqu	96(%rdi), %ymm3
	vmovdqu	128(%rdi), %ymm4
	testq	%rdx, %rdx
	je	.Ldmc_store
.Ldmc_loop:
	vmovdqu	(%rsi), %xmm14
	vmovq	16(%rsi), %xmm15
	vinserti128	$1, %xmm15, %ymm14, %ymm14
	vpxor	%ymm14, %ymm0, %ymm0
	vmovdqa	%ymm0, %ymm9
	vmovdqa	%ymm1, %ymm10
	vmovdqa	%ymm2, %ymm11
	vmovdqa	%ymm3, %ymm12
	vmovdqa	%ymm4, %ymm13
	vpxor	glob_data + 384(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 352(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm7
	vpandn	%ymm5, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm8
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm1
	vpermq	$147, %ymm6, %ymm3
	vpsrlq	$59, %ymm3, %ymm5
	vpsllq	$5, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$57, %ymm7, %ymm3
	vpshufb	glob_data + 0(%rip), %ymm3, %ymm3
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm5
	vpermq	$147, %ymm2, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm3, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm4, %ymm6
	vpsllq	$1, %ymm4, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 320(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm3, %ymm6
	vpandn	%ymm1, %ymm7, %ymm3
	vpxor	%ymm3, %ymm4, %ymm7
	vpermq	$147, %ymm5, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm3
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm4
	vpsrlq	$63, %ymm6, %ymm5
	vpsllq	$1, %ymm6, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$78, %ymm7, %ymm5
	vpsrlq	$61, %ymm5, %ymm6
	vpsllq	$3, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm2
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm5
	vpxor	%ymm7, %ymm2, %ymm6
	vpermq	$147, %ymm3, %ymm1
	vpsrlq	$59, %ymm1, %ymm7
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm7, %ymm1
	vpermq	$57, %ymm4, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm5, %ymm7
	vpsllq	$1, %ymm5, %ymm3
	vpor	%ymm3, %ymm7, %ymm3
	vpermq	$78, %ymm6, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 288(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm5
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm4
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm1
	vpsrlq	$63, %ymm3, %ymm6
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm6, %ymm2
	vpermq	$78, %ymm5, %ymm3
	vpsrlq	$61, %ymm3, %ymm5
	vpsllq	$3, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm7
	vpxor	%ymm5, %ymm2, %ymm8
	vpxor	%ymm5, %ymm3, %ymm5
	vpermq	$147, %ymm4, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm7, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm8, %ymm6
	vpsllq	$1, %ymm8, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 256(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 224(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpermq	$147, %ymm5, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 192(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm7
	vpandn	%ymm5, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm8
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm1
	vpermq	$147, %ymm6, %ymm3
	vpsrlq	$59, %ymm3, %ymm5
	vpsllq	$5, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$57, %ymm7, %ymm7
	vpshufb	glob_data + 0(%rip), %ymm7, %ymm3
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm5
	vpermq	$147, %ymm2, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm3, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm4, %ymm6
	vpsllq	$1, %ymm4, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 160(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm8
	vpandn	%ymm1, %ymm5, %ymm3
	vpxor	%ymm3, %ymm4, %ymm5
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm3
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm4
	vpsrlq	$63, %ymm8, %ymm6
	vpsllq	$1, %ymm8, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$78, %ymm5, %ymm5
	vpsrlq	$61, %ymm5, %ymm6
	vpsllq	$3, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm2
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm8
	vpxor	%ymm5, %ymm2, %ymm5
	vpermq	$147, %ymm3, %ymm1
	vpsrlq	$59, %ymm1, %ymm6
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpermq	$57, %ymm4, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm8, %ymm6
	vpsllq	$1, %ymm8, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpermq	$78, %ymm5, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 128(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpandn	%ymm7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm4, %ymm7
	vpermq	$147, %ymm5, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm4
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm1
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$78, %ymm7, %ymm3
	vpsrlq	$61, %ymm3, %ymm5
	vpsllq	$3, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm5
	vpxor	%ymm7, %ymm2, %ymm8
	vpxor	%ymm7, %ymm3, %ymm6
	vpermq	$147, %ymm4, %ymm1
	vpsrlq	$59, %ymm1, %ymm7
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm7, %ymm1
	vpermq	$57, %ymm5, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm6, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 96(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpermq	$147, %ymm7, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 64(%rip), %ymm0, %ymm5
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm4, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm5, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpermq	$147, %ymm6, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$50, %ymm5, %ymm7
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$147, %ymm1, %ymm1
	vpsrlq	$59, %ymm1, %ymm5
	vpsllq	$5, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpermq	$57, %ymm2, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm3, %ymm5
	vpsllq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm4, %ymm4
	vpsrlq	$61, %ymm4, %ymm5
	vpsllq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpxor	glob_data + 32(%rip), %ymm0, %ymm7
	vpandn	%ymm2, %ymm1, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm3, %ymm2, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm4, %ymm3, %ymm6
	vpxor	%ymm6, %ymm2, %ymm6
	vpandn	%ymm7, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm8
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm4, %ymm1
	vpermq	$147, %ymm5, %ymm3
	vpsrlq	$59, %ymm3, %ymm5
	vpsllq	$5, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm2
	vpermq	$57, %ymm6, %ymm3
	vpshufb	glob_data + 0(%rip), %ymm3, %ymm3
	vpsrlq	$63, %ymm8, %ymm5
	vpsllq	$1, %ymm8, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpermq	$147, %ymm5, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vpsrlq	$50, %ymm5, %ymm6
	vpsllq	$14, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm1
	vpermq	$147, %ymm2, %ymm5
	vpsrlq	$59, %ymm5, %ymm6
	vpsllq	$5, %ymm5, %ymm5
	vpor	%ymm5, %ymm6, %ymm6
	vpermq	$57, %ymm3, %ymm2
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm2
	vpsrlq	$63, %ymm4, %ymm5
	vpsllq	$1, %ymm4, %ymm3
	vpor	%ymm3, %ymm5, %ymm3
	vpermq	$78, %ymm1, %ymm1
	vpsrlq	$61, %ymm1, %ymm5
	vpsllq	$3, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpand	capm24(%rip), %ymm9, %ymm14
	vpxor	%ymm14, %ymm0, %ymm0
	vpxor	%ymm10, %ymm6, %ymm6
	vpxor	%ymm11, %ymm2, %ymm2
	vpxor	%ymm12, %ymm3, %ymm3
	vpxor	%ymm13, %ymm1, %ymm1
	vmovdqa	%ymm1, %ymm4
	vmovdqa	%ymm6, %ymm1
	addq	$24, %rsi
	decq	%rdx
	jne	.Ldmc_loop
.Ldmc_store:
	vmovdqu	%ymm0, (%rdi)
	vmovdqu	%ymm1, 32(%rdi)
	vmovdqu	%ymm2, 64(%rdi)
	vmovdqu	%ymm3, 96(%rdi)
	vmovdqu	%ymm4, 128(%rdi)
	ret
	.size	zud_absorb_blocks_dmc, .-zud_absorb_blocks_dmc

	.section	.rodata
	.p2align	5
absm24:
	.quad	-1
	.quad	-1
	.quad	-1
	.quad	0
capm24:
	.quad	0
	.quad	0
	.quad	0
	.quad	-1
	.section	.note.GNU-stack, "", %progbits
