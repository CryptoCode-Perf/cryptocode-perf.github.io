# ZC-DMC candidate package

Includes ZC-DMC-1280-512/768 and ZC-DMC-1536-512/768/1024.
Run `bash build_and_verify.sh` on x86-64 Linux with GCC, Python 3 and AVX2.
The script rebuilds CryptoCode, official reference and official optimized
implementations and checks each against its full KAT. Build output is local.

This is an experimental candidate: performance measurements, independent
release review and upstream redistribution permissions remain pending.
The optimized source includes padding fixes; original official sources are
retained separately. KAT success does not establish cryptographic security.

The three top-level implementation directories contain the official reference, official optimized and CryptoCode sources. The build script reconstructs the official include hierarchy in build/ from these sources and official_tree/lib.

> 同源骨架：本包由 ZC-DM-1.0.0 的六档骨架克隆而来，官方实现与 KAT 向量全部取自 ZC-DMC 的官方发布树，CryptoCode 侧为本族的融合吸收件。
