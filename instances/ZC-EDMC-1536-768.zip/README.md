# ZC-EDMC-1536-768

Algorithm: ZC-EDMC | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header ZC-EDMC-1536-768.h, prebuilt ZC-EDMC-1536-768.so,
KAT vector KAT_2_12_ZC-EDMC-1536-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): fbfc21921e896908dafcaa3fb6db160e9b65a3a0733290e401d894ebc61ad93c
Speed (cpB, lower is faster): reference 11.93 / official-optimized 7.82 / optimized 6.66
Speedup: GM(S1-S8) 1.24x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
