#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for bits in 512 768 1024; do
 for kind in Reference Optimized CryptoCode; do
  if [ "$kind" = Reference ]; then d="Reference_Implementation/TaiChi-$bits"; flags=-O2; source=CryptHash_AlgorithmInstance.c; extra=()
  elif [ "$kind" = Optimized ]; then d="Optimized_Implementation/TaiChi-$bits-op-per"; flags="-O3 -mavx2"; source=CryptHash_AlgorithmInstance.c; extra=()
  else d="CryptoCode_Implementation/TaiChi-$bits"; flags="-O3 -mavx2"; source=CryptHash_AlgorithmInstance_rorx_pad.c; extra=(); fi
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/$source" "${extra[@]}" -o "build/$kind-$bits.so"
  python3 "test/kat_$bits.py" "build/$kind-$bits.so" 100000 0 "kat/TaiChi-$bits.txt"
 done
done

python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 768 1024; do build/guard_check "build/CryptoCode-$bits.so" "$bits"; done
