# TaiChi candidate package

Includes TaiChi-512, 768 and 1024. Requires x86-64 Linux, GCC, Python 3,
AVX2 and BMI2; the CryptoCode implementation uses rorx and has no runtime
fallback. Run `bash build_and_verify.sh`. The official performance-optimized
op-per variant is used for comparison; op-res source is retained separately.
The script rebuilds three implementations, checks full KAT, selected reference
differential and input/output guard-page tests.

Candidate only: performance comparison, release review and upstream
redistribution permissions remain pending. Tests do not prove security.
