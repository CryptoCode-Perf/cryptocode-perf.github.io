# Pavelor-768

Algorithm: Pavelor | Digest bits: 768 | Form: 标量 C

Contents: implementation source/, public header Pavelor-768.h, prebuilt Pavelor-768.so,
KAT vector KAT_2_12_Pavelor-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 964d4a83b1d3d84177abb128197df1423838ddf6d7ca4ae1630c8f5c97e99470
Speed (cpB, lower is faster): reference 172.72 / official-optimized 1.41 / optimized 1.30
Speedup: GM(S1-S8) 1.08x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
