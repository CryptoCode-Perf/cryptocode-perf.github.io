#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
flags=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -fPIC -shared -Wl,-z,defs)
for bits in 256 384 512 768 1024; do
 for kind in Reference Optimized CryptoCode; do
  dir="${kind}_Implementation/Eijen-$bits"
  case "$kind" in Optimized) core=eijen_avx2.c;; *) core=eijen_ref.c;; esac
  gcc "${flags[@]}" -I"$dir" "$dir/CryptHash_AlgorithmInstance.c" "$dir/$core" -o "build/$kind-$bits.so"
  python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/Eijen-$bits.txt"
 done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 256 384 512 768 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits"; done; done
