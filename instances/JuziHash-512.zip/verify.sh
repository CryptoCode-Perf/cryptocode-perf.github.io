#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 kat_check.py ./JuziHash-512.so 4097 0 KAT_2_12_JuziHash-512.txt
