"""JuziHash-512（hash-13）交付件生成器 —— 与 1024 档同一处驱动层结构性冗余。

## 为什么 512 档是同族同病（判据，带行号）

`diff Optimized_Implementation/JuziHash-512/CryptHash_AlgorithmInstance.c \
      Optimized_Implementation/JuziHash-1024/CryptHash_AlgorithmInstance.c`
只有两处实质差异：

  * `:287-303` `JUZI512_H0[256]`  ↔  `JUZI1024_H0[256]`  （初值表）
  * `:306-307` `juzihash512_avx2(...)` ↔ `juzihash1024_avx2(...)`（函数名/摘要长度）
  * 行数 366 ↔ 369（多出的 3 行就是函数签名换行 + 摘要字节数）

`juzi_avx2_permute(__m256i s[8])`、`juzi_avx2_add_rc`、`rc[8]` 的 8 个 `UINT64_C(...)`
字面量、递推公式、`juzi_store64_be`、`juzi_avx2_sbox8`、`juzi_avx2_mds`、
`juzi_avx2_byteperm` **两档逐字相同** ⇒ 1024 档 17.9% 的胜因（`rc` 六组编译期常量
每次置换重算 6 组 + 每组 8 个字拆成 64 次 byte store）在 512 档一字不差地存在。

## 做法

完全复用 `gen_ours.py` 的替换逻辑（同一套正则/同一张常量表/同样的自检），
只把 tier 目录换成 `JuziHash-512`、产物改名 `ours_juzi512.so`。

    cd feilian/work/_overnight/l0/juzi && python3 -u gen_ours512.py
"""
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import gen_ours as G  # noqa: E402  （复用 round_constants / c_table / 正则是同一套）

TIER = "512"
OPT = os.path.join(
    HERE, "official", "Juzi", "Implementations", "Implementation",
    "Optimized_Implementation", "JuziHash-" + TIER)
SRC = os.path.join(OPT, "CryptHash_AlgorithmInstance.c")


def main() -> int:
    src = open(SRC, encoding="utf-8").read()
    groups = G.round_constants()

    # 自检：常量表与源码里的字面量必须一致（防止我抄错初值）
    lits = re.findall(r"UINT64_C\(0x([0-9a-fA-F]{16})\)", src)
    if len(lits) != 8:
        print("!! 源码里 UINT64_C 字面量不是 8 个：%d" % len(lits))
        return 2
    want = [int(x, 16) for x in lits]
    if want != groups[0]:
        print("!! 常量表第 0 组与源码字面量不一致")
        print("   源码 :", ["%016x" % v for v in want])
        print("   递推 :", ["%016x" % v for v in groups[0]])
        return 2
    print("常量自检 OK：第 0 组与源码字面量一致；共 6 组")

    n1 = len(G.ADD_RC_OLD_RE.findall(src))
    n2 = len(G.PERMUTE_RE.findall(src))
    if n1 != 1 or n2 != 1:
        print("!! 替换锚点不唯一：add_rc=%d permute=%d" % (n1, n2))
        return 2
    out = G.ADD_RC_OLD_RE.sub("", src)
    out = G.PERMUTE_RE.sub(G.PERMUTE_NEW, out)

    anchor = "static __m256i juzi_loadu256(const void *p)"
    if out.count(anchor) != 1:
        print("!! 常量表插入锚点不唯一")
        return 2
    out = out.replace(anchor, G.c_table(groups) + "\n\n" + anchor)

    rotl_re = re.compile(
        r"static uint64_t juzi_rotl64\(uint64_t x, unsigned int n\)\s*\{.*?\n\}\n\n",
        re.S)
    if len(rotl_re.findall(out)) != 1:
        print("!! juzi_rotl64 锚点不唯一")
        return 2
    out = rotl_re.sub("", out)

    # 512 档的死代码：官方 512 驱动的吸收路径不用 update_dm（1024 档用），
    # 带官方那组 -Wall -Wextra 编 512 会报 -Wunused-function ⇒ 删掉，保持 warning-free。
    # （只删**未被引用**的静态函数，语义无影响；构建后仍由 KAT + 第四道门全量对拍。）
    if out.count("juzi_avx2_update_dm(") == 1:
        dm_re = re.compile(
            r"static void juzi_avx2_update_dm\(__m256i s\[8\].*?\n\}\n\n", re.S)
        if len(dm_re.findall(out)) != 1:
            print("!! juzi_avx2_update_dm 锚点不唯一")
            return 2
        out = dm_re.sub("", out)
        print("删掉 512 档死代码 juzi_avx2_update_dm（仅定义、无引用）")
    else:
        print("juzi_avx2_update_dm 在 512 档有引用，保留")

    # 交付件里写清来源，便于表内追溯
    out = ("/* JuziHash-512 交付件 —— 由 juzi/gen_ours512.py 从官方 "
           "Optimized_Implementation/JuziHash-512/CryptHash_AlgorithmInstance.c 生成。\n"
           " * 改动仅一处结构性冗余：rc 六组编译期常量每次置换重算 -> 静态常量表；\n"
           " * 置换核（subbytes/mds/byteperm）与官方逐字相同。 */\n") + out

    dst = os.path.join(HERE, "src", "ours512.c")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    open(dst, "w", encoding="utf-8", newline="\n").write(out)
    print("已写 %s（%d B）" % (dst, os.path.getsize(dst)))

    outdir = os.path.join(HERE, "out")
    os.makedirs(outdir, exist_ok=True)
    so = os.path.join(outdir, "ours_juzi512.so")
    log = os.path.join(HERE, "logs", "ours512.build.log")
    os.makedirs(os.path.dirname(log), exist_ok=True)
    cmd = ["gcc"] + G.FLAGS + ["-fPIC", "-shared", "-I" + OPT, "-o", so, dst, "-lm"]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    msg = r.stdout.decode("utf-8", "replace")
    open(log, "w", encoding="utf-8").write(msg)
    if r.returncode != 0 or msg.strip():
        print("!! 构建有输出（官方构建是 warning-free）：rc=%d" % r.returncode)
        print(msg[:2000])
        return 3
    print("构建 OK：%s（%d B）" % (so, os.path.getsize(so)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
