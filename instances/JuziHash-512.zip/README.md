# JuziHash-512

Algorithm: JuziHash | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header JuziHash-512.h, prebuilt JuziHash-512.so,
KAT vector KAT_2_12_JuziHash-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 21a72d5ba224b8d9b91c0867d277a55055636999b9eb32ab26decd0cc1bc3b14
Speed (cpB, lower is faster): reference 277.39 / official-optimized 10.44 / optimized 8.57
Speedup: GM(S1-S8) 1.22x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
