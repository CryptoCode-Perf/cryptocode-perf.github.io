# XRH-1-768

Algorithm: XRH-1 | Digest bits: 768 | Form: AVX2 汇编

Contents: implementation source/, public header XRH-1-768.h, prebuilt XRH-1-768.so,
KAT vector KAT_2_12_XRH-1-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): d1903c27de8fb1a8605070f15b7c2ef4bf92557ee543c7e692ec759d41514014
Speed (cpB, lower is faster): reference 25.78 / official-optimized 21.24 / optimized 19.64
Speedup: GM(S1-S8) 1.07x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
