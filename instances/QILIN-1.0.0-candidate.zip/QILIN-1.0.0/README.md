# QILIN 1.0.0 — CryptoCode AVX2 Implementation

Supports QILIN-512, QILIN-768 and QILIN-1024 through the CryptHash ABI.
Requires x86-64 Linux/WSL2, AVX2, GCC, Python 3 and standard shell tools.

Run from any directory:

```sh
bash build_and_verify.sh
```

The script rebuilds reference, official optimized and CryptoCode implementations;
compares 66 boundary vectors and frozen golden vectors; verifies all 4097 KAT
records for each digest size; and benchmarks rebuilt shared libraries for all
three digest sizes with three repetitions each. Failure returns a nonzero code.
Outputs are written to build/. Original source algorithms are unchanged.

The benchmark harness uses -O2; implementation libraries use the documented
-O3/AVX2 flags in the script. Units are TSC ticks, not hardware core cycles.
Each size reports the minimum of five batches. Results depend on environment;
this is a reproducibility result, not a universal performance guarantee.

Directory guide: CryptoCode_Implementation/ holds our optimized implementation and its generator;
Reference_Implementation/ and Optimized_Implementation/ hold baselines;
kat/ holds official vectors; test/ holds validation and benchmark tools;
prebuilt/ holds the verified rebuilt CryptoCode library; results/ records this release.
Use the checked-in CryptoCode C source for rebuilding. Regenerating source is outside
this release procedure; the generator has not been established as CryptoCode-equivalent.

CryptHash takes digest length in bits, message pointer, message length in bits,
and output pointer; allocate at least digest_bits/8 output bytes. Supported
release digest sizes are 512, 768 and 1024. AVX2 is mandatory; no runtime CPU
dispatch or fallback is supplied. No constant-time or security proof is claimed.

Third-party sources retain their existing notices. No new license grant is
invented for upstream sources. Redistribution permission still needs review.
See SOURCE_MANIFEST.json for original source identity and file hashes.
