#!/usr/bin/env bash
# QILIN-1024 (hash-23) AVX2 三方构建 + 交叉验证 + KAT 全量验证 + 测速
#
#   Reference_Implementation/QILIN-1024             官方参考实现（正确性锚点）
#   Optimized_Implementation/QILIN-1024    官方 x86 优化实现（对照组）
#   CryptoCode_Implementation/x86_AVX2/QILIN-1024    CryptoCode AVX2 优化（被测对象）
#
# 用法： bash build_and_verify.sh          （x86_64 Linux 原生，需 gcc + python3）
set -euo pipefail
cd "$(dirname "$0")"

REF=Reference_Implementation/QILIN-1024
OFF=Optimized_Implementation/QILIN-1024
OURS=CryptoCode_Implementation/x86_AVX2/QILIN-1024

mkdir -p build
uname -a > build/environment.txt
gcc --version >> build/environment.txt
lscpu >> build/environment.txt
echo "== [1/5] 编译三方实现 =="
# 官方实现用官方 Makefile 同款（-O2 默认）；三方同 flag 才公平，统一 -O3 + AVX2 flag
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
gcc $FLAGS -I$REF  $(ls $REF/*.c  | grep -v KAT) test/vec.c -o build/vec_ref
gcc $FLAGS -I$OFF  $OFF/CryptHash_AlgorithmInstance.c test/vec.c -o build/vec_official
gcc $FLAGS -I$OURS $OURS/qilin1024.c test/vec.c -o build/vec_ours


echo "   编译完成（$FLAGS）"

echo "== [2/5] 交叉验证（3 摘要档 × 22 padding 边界 = 66 组，逐字节比对） =="
./build/vec_ref      > build/v_ref.txt
./build/vec_official > build/v_official.txt
./build/vec_ours     > build/v_ours.txt

pass=1
diff -q build/v_ref.txt build/v_official.txt >/dev/null || { echo "   !! 官方优化版与参考不一致"; pass=0; }
diff -q build/v_ref.txt build/v_ours.txt     >/dev/null || { echo "   !! AVX2 版与参考不一致"; diff build/v_ref.txt build/v_ours.txt | head -4; pass=0; }

echo "== [3/5] 黄金向量比对 =="
if diff -q build/v_ref.txt test/golden_vectors_ref.txt >/dev/null 2>&1; then
    echo "   参考实现与随包黄金向量一致"
else
    echo "ERROR: golden vectors mismatch"; pass=0
fi

echo "== [4/5] KAT 全量验证（三档各 4097 条） =="
# 先编共享库版（供 python ctypes 加载）：官方 CryptHash 把摘要长度当运行时参数，
# 我方单库即覆盖 QILIN-512 / 768 / 1024 全部三档
gcc $FLAGS -I$OURS $OURS/qilin1024.c -fPIC -shared -o build/libours.so
python3 test/kat_check.py build/libours.so 100000 0 kat/KAT_2_12_QILIN-1024.txt || pass=0
python3 test/kat_check.py build/libours.so 100000 0 kat/KAT_2_12_QILIN-768.txt  || pass=0
python3 test/kat_check.py build/libours.so 100000 0 kat/KAT_2_12_QILIN-512.txt  || pass=0

echo "== [5/5] 吞吐测速（指引 S1–S8 分级，双方均为动态 so + 同一 -O2 装置，min-of-5，TSC ticks/B） =="
# 公平口径：双方都以 so 形态被同一装置加载（避免「源码编译+LTO」对官方优化的不对称伤害，
# 该口径会把加速比系统性放大 10-20%；与本报表其余口径一致的 so-vs-so 实测见 evidence/）
gcc -O2 -mavx2 test/speed.c -o build/speed -ldl -lm
gcc $FLAGS -I$OFF $OFF/CryptHash_AlgorithmInstance.c -fPIC -shared -o build/libofficial.so
for bits in 512 768 1024; do
  for rep in 1 2 3; do
    ./build/speed ./build/libours.so ./build/libofficial.so "$bits" > "build/speed_${bits}_${rep}.txt"
  done
done

[ $pass -eq 1 ] && echo "== 验证全部通过 ==" || { echo "== 验证存在失败项 =="; exit 2; }
