# Third-party material and redistribution status

The Reference_Implementation and Optimized_Implementation directories contain
material from the original QILIN submission. The kat directory contains its known
answer vectors. The source package identifies these as official submission
materials; this delivery does not claim ownership or grant rights on behalf of
their authors.

A review of the C and header files in these two directories did not identify
an explicit license or redistribution grant. This is not a legal conclusion.
Obtain and document the applicable terms or authorization before public
redistribution. Preserve all original notices and the source hashes.

CryptoCode_Implementation includes material derived from the original QILIN
interface and algorithm. Its rights and third-party dependencies likewise require
review before publication. Internal evaluation does not establish permission.
