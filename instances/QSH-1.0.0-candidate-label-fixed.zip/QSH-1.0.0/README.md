# QSH candidate package

Includes QSH-512 and QSH-768. On x86-64 Linux with GCC, Python 3 and AVX2,
run `bash build_and_verify.sh`. It rebuilds the official reference, official
optimized and CryptoCode implementations, checks full KAT, selected reference
differential and input/output guard-page tests.

Candidate only: performance comparison, release review and upstream
redistribution permissions remain pending. Tests do not prove security.
