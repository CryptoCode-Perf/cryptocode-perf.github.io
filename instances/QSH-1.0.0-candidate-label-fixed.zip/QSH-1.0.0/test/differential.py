from pathlib import Path
import ctypes,random,json,hashlib
root=Path(__file__).resolve().parent.parent;rng=random.Random(20261127);out=[]
for bits in (512,768):
 d=root/'build';libs=[ctypes.CDLL(str(d/f'Reference-{bits}.so')),ctypes.CDLL(str(d/f'CryptoCode-{bits}.so'))]
 for l in libs:l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
 lengths=sorted(set([0,1,7,8,9,511,512,513,767,768,769,1023,1024,1025,4095,4096,4097,65535,65536,65537]+[rng.randrange(0,131073) for _ in range(250)]));fails=[]
 for n in lengths:
  msg=rng.randbytes((n+7)//8);buf=ctypes.create_string_buffer(msg or b'\0');dig=[]
  for l in libs:
   result=ctypes.create_string_buffer(bits//8);rc=l.CryptHash(bits,buf,n,result);dig.append((rc,result.raw))
  if dig[0][0] != 0 or dig[1][0] != 0 or dig[0][1] != dig[1][1]:fails.append(n)
 out.append({'instance':f'QSH-{bits}','cases':len(lengths),'failures':fails,'candidate_sha256':hashlib.sha256((d/f'CryptoCode-{bits}.so').read_bytes()).hexdigest(),'reference_sha256':hashlib.sha256((d/f'Reference-{bits}.so').read_bytes()).hexdigest()});print(bits,len(lengths),'failures',fails[:10])
(root/'build'/'long-differential.json').write_text(json.dumps(out,indent=2))

if any(x["failures"] for x in out): raise SystemExit(1)
