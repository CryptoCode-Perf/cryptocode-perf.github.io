#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for bits in 512 768; do
 for kind in Reference Optimized CryptoCode; do
  d="${kind}_Implementation/QSH-$bits"; source=CryptHash_AlgorithmInstance.c; extra=()
  if [ "$kind" = Reference ]; then flags=-O2; else flags="-O3 -mavx2"; fi
  if [ "$kind" = CryptoCode ]; then source=glue_qsh512_v3.c; fi
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/$source" "${extra[@]}" -o "build/$kind-$bits.so"
  python3 "test/kat_$bits.py" "build/$kind-$bits.so" 100000 0 "kat/QSH-$bits.txt"
 done
done

python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 768; do build/guard_check "build/CryptoCode-$bits.so" "$bits"; done
