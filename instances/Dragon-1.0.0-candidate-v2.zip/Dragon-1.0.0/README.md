# Dragon candidate package

Instances: Dragon-512, Dragon-768, Dragon-1024. XOF variants are not included.
On x86-64 Linux with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`.
This rebuilds the reference, official optimized and CryptoCode implementations,
checks all 4097 known-answer vectors for each, compares deterministic long and
boundary inputs, and tests selected input and output guard-page boundaries.

Dragon-512 uses recovered wrapper and generated assembly from the recorded
website binary build; its Jasmin source is included, but the build does not
regenerate assembly from it. The other two implementations use C sources from
the local performance report. Rebuilt binaries may vary with the environment.

Candidate only: source provenance and independent review, XOF coverage,
controlled fastest-implementation comparison, redistribution permission and
final release review remain pending. These tests do not prove security.
