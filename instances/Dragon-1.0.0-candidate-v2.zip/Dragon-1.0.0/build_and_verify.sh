#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for bits in 512 768 1024; do
 for kind in Reference Optimized; do
  dir="${kind}_Implementation/Dragon-$bits"
  gcc -O3 -fPIC -shared -Wl,-z,defs -I"$dir" "$dir/CryptHash_AlgorithmInstance.c" -o "build/$kind-$bits.so"
 done
 dir="CryptoCode_Implementation/Dragon-$bits"
 flags=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -fPIC -shared -Wl,-z,defs)
 if [ "$bits" = 512 ]; then
  gcc "${flags[@]}" -IReference_Implementation/Dragon-512 "$dir/wrapper.c" "$dir/permutation.s" -o "build/CryptoCode-$bits.so"
 else
  gcc "${flags[@]}" -I"Optimized_Implementation/Dragon-$bits" "$dir/implementation.c" -o "build/CryptoCode-$bits.so"
 fi
 for kind in Reference Optimized CryptoCode; do
  python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/Dragon-$bits.txt"
 done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 768 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits"; done; done
