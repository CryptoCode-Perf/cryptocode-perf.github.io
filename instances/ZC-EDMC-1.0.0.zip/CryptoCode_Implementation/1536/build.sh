#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -fPIC -shared -Wl,-z,defs -Ilib/low/ZuD-1536/AVX2 -Ilib/low/ZuD-1536 -IImplementations/Optimized_Implementation/ZC-EDMC-1536-512 zud1536_p12.s zud1536_round.s zud1536_api.c Implementations/Optimized_Implementation/ZC-EDMC-1536-512/CryptHash_AlgorithmInstance.c -o ../../build/CryptoCode-1536.so
