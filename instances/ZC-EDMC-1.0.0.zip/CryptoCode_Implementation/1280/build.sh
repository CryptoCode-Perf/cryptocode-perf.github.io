#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -Wl,-z,defs -Ilib/low/ZuD-1280/AVX2 -Ilib/low/ZuD-1280 -IImplementations/Optimized_Implementation/ZC-EDMC-1280-512 zud_abs_edmc.s zud_gen_rounds.c zud_api.c Implementations/Optimized_Implementation/ZC-EDMC-1280-512/CryptHash_AlgorithmInstance.c -o ../../build/CryptoCode-1280.so
