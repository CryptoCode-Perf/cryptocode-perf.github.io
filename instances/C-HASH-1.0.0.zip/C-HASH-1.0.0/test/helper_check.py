#!/usr/bin/env python3
from pathlib import Path
import ctypes,random
root=Path(__file__).resolve().parent.parent;lib=ctypes.CDLL(str(root/'build/CryptoCode-512.so'));rng=random.Random(20261127)
lib.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];lib.CryptHash.restype=ctypes.c_int
lib.c_hash_512_bits.argtypes=[ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];lib.c_hash_512_bits.restype=ctypes.c_int
lib.c_hash_512.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p];lib.c_hash_512.restype=ctypes.c_int
lengths=sorted(set([0,1,7,8,9,511,512,513,1023,1024,1025,4095,4096,4097]+[rng.randrange(0,65537) for _ in range(250)]))
for n in lengths:
 msg=rng.randbytes((n+7)//8);buf=ctypes.create_string_buffer(msg or b'\0');before=buf.raw;out=[]
 for fn in ('crypt','bits','bytes'):
  if fn=='bytes' and n%8:continue
  res=ctypes.create_string_buffer(b'\xa5'*96,96);ptr=ctypes.byref(res,16)
  rc=lib.CryptHash(512,buf,n,ptr) if fn=='crypt' else lib.c_hash_512_bits(buf,n,ptr) if fn=='bits' else lib.c_hash_512(buf,n//8,ptr)
  assert rc==0 and res.raw[:16]==b'\xa5'*16 and res.raw[80:]==b'\xa5'*16;out.append(res.raw[16:80])
 assert buf.raw==before and all(x==out[0] for x in out),(n,'helper mismatch')
print('C-HASH-512 byte/bit helpers:',len(lengths),'cases passed')
