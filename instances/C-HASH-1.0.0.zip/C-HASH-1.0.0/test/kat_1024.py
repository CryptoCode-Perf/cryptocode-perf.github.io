#!/usr/bin/env python3
"""KAT spot-check against an official KAT file (4097 records).
Usage: python3 kat_check.py <lib.so> [n_first] [stride] <kat.txt>
"""
import ctypes, sys

def parse_kat(path):
    recs=[]; ml=msg=dl=dst=None
    with open(path,"r",encoding="utf-8",errors="replace") as f:
        for line in f:
            line=line.strip()
            if line.startswith("Msg_Len ="): ml=int(line.split("=")[1]); msg=None
            elif line.startswith("Msg ="):
                h=line.split("=",1)[1].strip(); msg=bytes.fromhex(h) if h else b""
            elif line.startswith("Dst_Len ="): dl=int(line.split("=")[1])
            elif line.startswith("Dst ="):
                dst=bytes.fromhex(line.split("=",1)[1].strip())
                if ml is None or msg is None or dl != 1024 or len(msg)!=(ml+7)//8 or len(dst)*8!=dl: raise ValueError("Invalid KAT record")
                recs.append((ml,msg,dl,dst))
                ml=msg=dl=dst=None
    return recs

def main():
    so=sys.argv[1]
    nfirst=int(sys.argv[2]) if len(sys.argv)>2 else 100000
    stride=int(sys.argv[3]) if len(sys.argv)>3 else 0
    kat=sys.argv[4] if len(sys.argv)>4 else ""
    lib=ctypes.CDLL(so)
    lib.CryptHash.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_ulonglong,ctypes.c_char_p]
    lib.CryptHash.restype=ctypes.c_int
    recs=parse_kat(kat)
    if len(recs)!=4097 or [x[0] for x in recs]!=list(range(4097)): raise ValueError("Incomplete or duplicate KAT records")
    picks=list(range(min(nfirst,len(recs))))
    if stride>0: picks=sorted(set(picks+list(range(0,len(recs),stride))))
    if not picks: raise ValueError("Empty KAT selection")
    bad=0
    for i in picks:
        ml,msg,dl,dst=recs[i]
        buf=ctypes.create_string_buffer(dl//8+64)
        rc=lib.CryptHash(dl,msg,ml,buf)
        got=buf.raw[:dl//8]
        if rc!=0 or got!=dst:
            bad+=1
            print("FAIL rec#%d msg_len=%d dst_len=%d rc=%d"%(i,ml,dl,rc))
    print("KAT: checked=%d match=%d total_records=%d pass=%s"%(len(picks),len(picks)-bad,len(recs),bad==0))
    return 0 if bad==0 else 1

if __name__=="__main__": sys.exit(main())
