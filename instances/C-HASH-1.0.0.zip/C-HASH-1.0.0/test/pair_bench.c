#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef int (*hash_fn)(int, const unsigned char *, unsigned long long, unsigned char *);
static volatile unsigned sink;
static uint32_t rng;
static uint32_t next_random(void) {
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng;
}
static double now(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC_RAW, &ts)) exit(10);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}
static double batch(hash_fn fn, int digest_bits, const unsigned char *msg, size_t bytes, unsigned n) {
    unsigned char output[1024]; unsigned sum = 0;
    double start = now();
    for (unsigned i = 0; i < n; ++i) {
        if (fn(digest_bits, msg, (unsigned long long)bytes * 8, output)) exit(11);
        sum += output[i % ((unsigned)digest_bits / 8)];
    }
    double elapsed = now() - start;
    sink += sum;
    return elapsed * 1e9 / n;
}
static hash_fn load(const char *path) {
    void *handle = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!handle) { fprintf(stderr, "%s\n", dlerror()); exit(12); }
    void *symbol = dlsym(handle, "CryptHash"); hash_fn fn;
    if (!symbol || sizeof(fn) != sizeof(symbol)) exit(13);
    memcpy(&fn, &symbol, sizeof(fn)); return fn;
}
int main(int argc, char **argv) {
    if (argc != 9) { fprintf(stderr, "baseline.so candidate.so digest_bits rounds batch_us seed sizes_csv label\n"); return 2; }
    int bits = atoi(argv[3]), rounds = atoi(argv[4]);
    double target = atof(argv[5]) * 1e-6;
    rng = (uint32_t)strtoul(argv[6], NULL, 10);
    if (bits < 8 || bits > 8192 || bits % 8 || rounds < 1 || target <= 0 || !rng) return 3;
    size_t sizes[32], maximum = 0; int count = 0;
    char *part = strtok(argv[7], ",");
    while (part) {
        if (count == 32) return 4;
        size_t size = (size_t)strtoull(part, NULL, 10);
        if (size == 0 || size > 16777216) return 5;
        sizes[count++] = size; if (size > maximum) maximum = size;
        part = strtok(NULL, ",");
    }
    if (!count) return 6;
    unsigned char *msg = malloc(maximum); if (!msg) return 7;
    for (size_t i = 0; i < maximum; ++i) msg[i] = (unsigned char)(i * 131u + 17u);
    hash_fn base = load(argv[1]), candidate = load(argv[2]);
    unsigned iterations[32];
    for (int s = 0; s < count; ++s) {
        unsigned n = 1;
        while (batch(base, bits, msg, sizes[s], n) * n * 1e-9 < target && n < (1u << 20)) n *= 2;
        iterations[s] = n;
    }
    puts("round,label,bytes,iterations,order,baseline_ns,candidate_ns,speedup");
    for (int round = 0; round < rounds; ++round) {
        int order[32]; for (int i = 0; i < count; ++i) order[i] = i;
        for (int i = count - 1; i > 0; --i) { int j = (int)(next_random() % (unsigned)(i + 1)); int t = order[i]; order[i] = order[j]; order[j] = t; }
        for (int k = 0; k < count; ++k) {
            int s = order[k], abba = (int)(next_random() & 1u); unsigned n = iterations[s];
            batch(base, bits, msg, sizes[s], 4); batch(candidate, bits, msg, sizes[s], 4);
            double b1, b2, c1, c2;
            if (abba) {
                b1 = batch(base,bits,msg,sizes[s],n); c1 = batch(candidate,bits,msg,sizes[s],n);
                c2 = batch(candidate,bits,msg,sizes[s],n); b2 = batch(base,bits,msg,sizes[s],n);
            } else {
                c1 = batch(candidate,bits,msg,sizes[s],n); b1 = batch(base,bits,msg,sizes[s],n);
                b2 = batch(base,bits,msg,sizes[s],n); c2 = batch(candidate,bits,msg,sizes[s],n);
            }
            double b = (b1+b2)/2, c = (c1+c2)/2;
            if (b <= 0 || c <= 0) return 8;
            printf("%d,%s,%zu,%u,%s,%.9f,%.9f,%.9f\n",round,argv[8],sizes[s],n,abba?"ABBA":"BAAB",b,c,b/c);
        }
    }
    free(msg); return 0;
}
