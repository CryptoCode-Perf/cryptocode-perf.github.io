#define _GNU_SOURCE
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
typedef int (*fn_t)(int,const unsigned char*,unsigned long long,unsigned char*);
int main(int argc,char**argv){if(argc!=3)return 2;void*h=dlopen(argv[1],RTLD_NOW);if(!h)return 3;fn_t fn=(fn_t)dlsym(h,"CryptHash");if(!fn)return 4;int bits=atoi(argv[2]);size_t page=sysconf(_SC_PAGESIZE);unsigned char*m=mmap(NULL,page*2,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(m==MAP_FAILED||mprotect(m+page,page,PROT_NONE))return 5;unsigned lengths[]={0,1,7,8,9,1279,1280,1281,1535,1536,1537,4095,4096,4097};for(unsigned i=0;i<sizeof(lengths)/sizeof(*lengths);i++){unsigned n=lengths[i],bytes=(n+7)/8;unsigned char*in=m+page-bytes;memset(in,0xa5,bytes);unsigned char*o=mmap(NULL,page*2,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);if(o==MAP_FAILED||mprotect(o+page,page,PROT_NONE))return 7;unsigned char*out=o+page-bits/8;if(fn(bits,in,n,out))return 6;munmap(o,page*2);}munmap(m,page*2);puts("guard tests passed");return 0;}
