#!/usr/bin/env python3
from pathlib import Path
import ctypes,random
root=Path(__file__).resolve().parent.parent;rng=random.Random(20261127)
for tier in (512,1024):
 libs=[ctypes.CDLL(str(root/'build'/f'{kind}-{tier}.so')) for kind in ('Reference','CryptoCode')]
 for l in libs:l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
 for bits in (512,1024):
  d=bits//8
  for n in (0,1,7,8,9,511,512,513,1023,1024,1025,4095,4096,4097,8193):
   msg=rng.randbytes((n+7)//8);source=ctypes.create_string_buffer(msg or b'\0');expect=ctypes.create_string_buffer(d);assert libs[0].CryptHash(bits,source,n,expect)==0
   size=max(d,len(msg));box=ctypes.create_string_buffer(b'\xa5'*16+msg+b'\xa5'*(size-len(msg))+b'\xa5'*16,32+size);before=box.raw;ptr=ctypes.byref(box,16)
   assert libs[1].CryptHash(bits,ptr,n,ptr)==0 and box.raw[16:16+d]==expect.raw and box.raw[:16]==before[:16] and box.raw[16+size:]==before[16+size:],(tier,bits,n,'in-place')
  for lib in libs:
   out=ctypes.create_string_buffer(d);assert lib.CryptHash(bits,None,0,out)==0
   assert lib.CryptHash(bits,None,1,out)==-3
   assert lib.CryptHash(bits,b'x',8,None)==-2
   assert lib.CryptHash(123,b'x',8,out)==-1
  a=ctypes.create_string_buffer(d);b=ctypes.create_string_buffer(d);assert libs[0].CryptHash(bits,None,0,a)==libs[1].CryptHash(bits,None,0,b)==0 and a.raw==b.raw
 print('C-HASH-%d: dual-output in-place and defined argument checks passed'%tier)
