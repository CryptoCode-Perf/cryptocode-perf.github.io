from pathlib import Path
import ctypes,random
root=Path(__file__).resolve().parent.parent;rng=random.Random(20261127);libs=[ctypes.CDLL(str(root/'build'/f'{k}-1024.so')) for k in ('Reference','Optimized','CryptoCode')]+[ctypes.CDLL(str(root/'build/CryptoCode-512.so'))]
for l in libs:l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
for bits in (512,1024):
 lengths=sorted(set([0,1,7,8,9,511,512,513,767,768,769,1023,1024,1025,4095,4096,4097,65535,65536,65537]+[rng.randrange(0,131073) for _ in range(250)]));failed=[]
 for n in lengths:
  msg=rng.randbytes((n+7)//8);buf=ctypes.create_string_buffer(msg or b'\0');before=buf.raw;results=[]
  for lib in libs:
   raw=ctypes.create_string_buffer(b'\xa5'*(bits//8+32),bits//8+32);rc=lib.CryptHash(bits,buf,n,ctypes.byref(raw,16));results.append((rc,raw.raw[16:16+bits//8],raw.raw[:16]==b'\xa5'*16 and raw.raw[16+bits//8:]==b'\xa5'*16))
  if buf.raw!=before or results[0][0]!=0 or any(not x[2] or x[:2]!=results[0][:2] for x in results):failed.append((n,[x[0] for x in results]))
 print('C-HASH dual-output libraries, output',bits,'cases',len(lengths),'failed',len(failed),failed[:5],flush=True)
 if failed:raise SystemExit(1)
