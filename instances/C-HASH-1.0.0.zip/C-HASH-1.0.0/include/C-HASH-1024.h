#ifndef CRYPTOCODE_C_HASH_1024_H
#define CRYPTOCODE_C_HASH_1024_H
#ifdef __cplusplus
extern "C" {
#endif
/* CryptHash accepts 512 and 1024 output bits; msg_len_bits is in bits. */
int CryptHash(int digest_len_bits,const unsigned char *msg,unsigned long long msg_len_bits,unsigned char *digest);
#ifdef __cplusplus
}
#endif
#endif
