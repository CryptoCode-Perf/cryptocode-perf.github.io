#ifndef CRYPTOCODE_C_HASH_512_H
#define CRYPTOCODE_C_HASH_512_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* CryptHash accepts 512 and 1024 output bits; msg_len_bits is in bits. */
int CryptHash(int digest_len_bits,const unsigned char *msg,unsigned long long msg_len_bits,unsigned char *digest);
/* These two helpers require valid input/output buffers and produce 512 bits. */
int c_hash_512(const uint8_t *msg,size_t msg_len_bytes,uint8_t digest[64]);
int c_hash_512_bits(const uint8_t *msg,unsigned long long msg_len_bits,uint8_t digest[64]);
#ifdef __cplusplus
}
#endif
#endif
