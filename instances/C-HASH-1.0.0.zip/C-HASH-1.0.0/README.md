# C-HASH 1.0.0 — CryptoCode implementation

Instances: C-HASH-512 and C-HASH-1024. Requires x86-64 Linux/WSL2, AVX2,
GCC with AddressSanitizer and UBSan, Python 3 and standard Unix tools. Run:

    bash build_and_verify.sh

The script rebuilds reference, official optimized and CryptoCode implementations,
checks 4097 known-answer vectors per instance and implementation, checks the
other valid digest size on each delivery library, compares long and boundary
inputs, tests in-place calls and documented argument errors, and exercises
guarded buffers. Both output sizes are also tested with address and undefined
behavior sanitizers. Build commands and environment are recorded under build/;
prebuilt libraries are in prebuilt/.

`CryptHash` accepts digest length and message length in bits; both delivery
libraries support 512 and 1024 output bits. The 512 library uses its own
optimized 512 core and dispatches 1024-bit output to the separately compiled
CryptoCode 1024 implementation. No reference fallback is used. Public headers
are in include/. The C-HASH-512 byte helper takes a byte length; its bit helper
takes a bit length. Both helpers require valid input and output buffers.

The current local report's 1024-bit binary rejects 512-bit output, which the
reference accepts. The selection retains the website implementation that
supports both outputs; the report-domain check is recorded in results/. The
512 wrapper and argument checks were extended as recorded in results/.
Historical generator scripts are retained for provenance and are not required
to build the included C sources.

Three 101-sample rounds over eight sizes and raw samples for rebuilt official
optimized versus delivery libraries are in results/2026-11-27-delivery-comparison.
Reference measurements are recorded separately under results/2026-11-27-reference-comparison.
Timings use elapsed nanoseconds, not hardware cycles. To remeasure after building:

    python3 test/measure.py --lock /path/to/shared/measurement.lock --output /path/to/new/results

The lock cannot exclude unrelated host work. Results depend on hardware and
load. Original source notices are retained. Tests do not prove security or
constant-time behavior. See SOURCE_MANIFEST.json for hashes.
