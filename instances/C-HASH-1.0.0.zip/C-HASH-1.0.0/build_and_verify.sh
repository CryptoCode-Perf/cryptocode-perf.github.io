#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
{ uname -a; gcc --version; lscpu; } > build/environment.txt
exec 9>build/build-commands.log
export BASH_XTRACEFD=9
set -x
for bits in 512 1024; do
 for kind in Reference Optimized CryptoCode; do
  d="${kind}_Implementation/C-HASH-$bits"; extra=()
  flags="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
  source=CryptHash_AlgorithmInstance.c
  if [ "$kind" = CryptoCode ] && [ "$bits" = 512 ]; then
   source=glue_chash512.c
   gcc $flags -fPIC -DCryptHash=chash1024_CryptHash -I CryptoCode_Implementation/C-HASH-1024 -c CryptoCode_Implementation/C-HASH-1024/CryptHash_AlgorithmInstance.c -o build/chash1024_composed.o
   extra=("$d/ours_core.c" "$d/api_wrapper.c" build/chash1024_composed.o)
  fi
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/$source" "${extra[@]}" -o "build/$kind-$bits.so"
  python3 "test/kat_$bits.py" "build/$kind-$bits.so" 100000 0 "kat/C-HASH-$bits.txt"
 done
done

python3 test/differential.py
python3 test/multi_digest_check.py
python3 test/helper_check.py
python3 test/api_check.py
python3 test/kat_1024.py build/CryptoCode-512.so 100000 0 kat/C-HASH-1024.txt
python3 test/kat_512.py build/CryptoCode-1024.so 100000 0 kat/C-HASH-512.txt
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 1024; do for kind in Reference Optimized CryptoCode; do build/guard_check "build/$kind-$bits.so" "$bits"; done; done
./build/guard_check ./build/CryptoCode-512.so 1024
./build/guard_check ./build/CryptoCode-1024.so 512

# Exercise both valid output sizes of C-HASH-1024 with instrumented code.
gcc -O1 -g -mavx2 -fsanitize=address,undefined -fno-omit-frame-pointer -I CryptoCode_Implementation/C-HASH-1024 test/san_multi_digest.c CryptoCode_Implementation/C-HASH-1024/CryptHash_AlgorithmInstance.c -ldl -o build/san_multi_digest
ASAN_OPTIONS=detect_leaks=1 ./build/san_multi_digest ./build/Reference-1024.so
san="-O1 -g -mavx2 -fsanitize=address,undefined -fno-omit-frame-pointer"
gcc $san -DCryptHash=chash1024_CryptHash -I CryptoCode_Implementation/C-HASH-1024 -c CryptoCode_Implementation/C-HASH-1024/CryptHash_AlgorithmInstance.c -o build/chash1024_san.o
gcc $san -I CryptoCode_Implementation/C-HASH-512 test/san_multi_digest.c CryptoCode_Implementation/C-HASH-512/glue_chash512.c CryptoCode_Implementation/C-HASH-512/ours_core.c CryptoCode_Implementation/C-HASH-512/api_wrapper.c build/chash1024_san.o -ldl -o build/san_composed
ASAN_OPTIONS=detect_leaks=1 ./build/san_composed ./build/Reference-512.so

set +x
