/* C-Hash (C-Hash-512 / C-Hash-1024)
 *
 * Scalar reference path preserved verbatim as a portable fallback; when the
 * translation unit is compiled for AVX2 the 1536-bit permutation runs in a
 * 32-byte *row-pair lane* representation instead:
 *
 *   - the state is 3 row pairs; one 256-bit vector holds the same 16-nibble
 *     quarter of the two rows of a pair (lane0 = row 2p, lane1 = row 2p+1),
 *     so the six rows are 12 vectors (4 quarters per pair) held in registers
 *     for the whole 28-round permutation;
 *   - the S-box becomes a per-byte table shuffle (pass 1: one shared table;
 *     pass 2: one table per row pair whose two 128-bit halves carry the two
 *     rows' column-constant-composed S-boxes);
 *   - the row-mix matrix and the L/R linear layer are both written directly in
 *     that layout, so the linear layer never reshuffles the state: the 24
 *     cross-lane permutes per round that a temporary re-pairing would need are
 *     gone, replaced by 16 permutes inside the row mix and no conversion at
 *     all around the linear layer.
 *
 * The nibble order (nibble i == byte i) is preserved exactly, so the byte
 * serialisation in state_from_bytes / state_to_bytes is unchanged.
 *
 * Compile (any mainstream C99 compiler):
 *   gcc -O2 -std=c11 CryptHash_AlgorithmInstance.c -o c_hash_plain
 */

#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>

#if defined(__AVX2__)
#include <immintrin.h>
#endif


#define ROWS          ((size_t)6)
#define NIBS_PER_ROW  ((size_t)64)
#define TOTAL_NIBS    (ROWS * NIBS_PER_ROW)


/* S 盒 */
static const uint8_t SBOX[16] = {
    0x1, 0x4, 0x0, 0xc, 0x3, 0x2, 0x5, 0xb,
    0xa, 0x8, 0x6, 0xf, 0x7, 0x9, 0xd, 0xe
};

/* 轮常数 */
static const uint32_t RC_U32[28] = {
    0x243F6A88u, 0x85A308D3u, 0x13198A2Eu, 0x03707344u,
    0xA4093822u, 0x299F31D0u, 0x082EFA98u, 0xEC4E6C89u,
    0x452821E6u, 0x38D01377u, 0xBE5466CFu, 0x34E90C6Cu,
    0xC0AC29B7u, 0xC97C50DDu, 0x3F84D5B5u, 0xB5470917u,
    0x9216D5D9u, 0x8979FB1Bu, 0xD1310BA6u, 0x98DFB5ACu,
    0x2FFD72DBu, 0xD01ADFB7u, 0xB8E1AFEDu, 0x6A267E96u,
    0xBA7C9045u, 0xF12C7F99u, 0x24A19947u, 0xB3916CF7u
};


/* 每行的列常量 */
static const uint8_t COL_CONST[6] = { 0xC, 0x9, 0x0, 0x8, 0xB, 0x2 };


/* ===================================================================== *
 *  AVX2 32-byte row-pair lane core
 * ===================================================================== */
#if defined(__AVX2__)

#define CH_VECS 12

/* 第 1 次 S 盒: 所有行共用同一个 S 盒 (列常量在行混合之后才混入), 16 项表
   复制两份供 32 字节 pshufb 的两个 128 位 lane 使用. */
static const uint8_t SBOX_DUP[32] = {
    0x1, 0x4, 0x0, 0xc, 0x3, 0x2, 0x5, 0xb,
    0xa, 0x8, 0x6, 0xf, 0x7, 0x9, 0xd, 0xe,
    0x1, 0x4, 0x0, 0xc, 0x3, 0x2, 0x5, 0xb,
    0xa, 0x8, 0x6, 0xf, 0x7, 0x9, 0xd, 0xe
};

/* 第 2 次 S 盒的复合表: T_c[x] = SBOX[x ^ c], c = COL_CONST[row].
 *
 * 行对 lane 布局下一个向量同时装着行 2p 与行 2p+1 的同一段 16 nibble, 因此
 * 表也按 lane 分开: lane0 = T_{COL_CONST[2p]}, lane1 = T_{COL_CONST[2p+1]}.
 * 一次 pshufb 就为两行同时完成 "异或列常量 + S 盒", 每轮 10 条整宽 vpxor 与
 * 5 个常驻广播常量向量都不再需要; 行对只有 3 组, 所以只需 3 张表. */
static const uint8_t SBOX_PAIR[3][32] = {
    /* rows 0/1, c = 0x0C / 0x09 */
    { 0x7,0x9,0xD,0xE,0xA,0x8,0x6,0xF,0x3,0x2,0x5,0xB,0x1,0x4,0x0,0xC,
      0x8,0xA,0xF,0x6,0x9,0x7,0xE,0xD,0x4,0x1,0xC,0x0,0x2,0x3,0xB,0x5 },
    /* rows 2/3, c = 0x00 / 0x08 */
    { 0x1,0x4,0x0,0xC,0x3,0x2,0x5,0xB,0xA,0x8,0x6,0xF,0x7,0x9,0xD,0xE,
      0xA,0x8,0x6,0xF,0x7,0x9,0xD,0xE,0x1,0x4,0x0,0xC,0x3,0x2,0x5,0xB },
    /* rows 4/5, c = 0x0B / 0x02 */
    { 0xF,0x6,0x8,0xA,0xE,0xD,0x9,0x7,0xC,0x0,0x4,0x1,0xB,0x5,0x2,0x3,
      0x0,0xC,0x1,0x4,0x5,0xB,0x3,0x2,0x6,0xF,0xA,0x8,0xD,0xE,0x7,0x9 }
};

/* 轮常数预展开表: 32 位轮常数的 8 个 nibble 落到字节 0..7 (nibble k -> 字节 k),
   其余 24 字节为 0. 初始化式是编译期常量表达式, 因此每轮只剩一条 vmovq
   (零扩展) + 一条 vpxor, 不再需要每轮 memset + 8 次标量移位/或/装配. */
#define CH_RC64(w) (                                                        \
      ((((uint64_t)(w)) >> 28) & 0x0Fu)                                     \
    | (((((uint64_t)(w)) >> 24) & 0x0Fu) <<  8)                             \
    | (((((uint64_t)(w)) >> 20) & 0x0Fu) << 16)                             \
    | (((((uint64_t)(w)) >> 16) & 0x0Fu) << 24)                             \
    | (((((uint64_t)(w)) >> 12) & 0x0Fu) << 32)                             \
    | (((((uint64_t)(w)) >>  8) & 0x0Fu) << 40)                             \
    | (((((uint64_t)(w)) >>  4) & 0x0Fu) << 48)                             \
    | ((((uint64_t)(w))       & 0x0Fu) << 56))

/* 每个轮常数直接按 32 字节向量存放 (前 8 字节是 8 个 nibble, 其余为零), 于是每轮
   注入是一条带内存操作数的 vpxor: 不再需要 vmovq + 零扩展, 也没有任何常驻常量
   寄存器占用 16 个 YMM 中的一个. */
typedef struct CH_RC32 {
    uint64_t q[4];
} CH_RC32;

static const CH_RC32 CH_RC_VEC[28] = {
    {{ CH_RC64(0x243F6A88u), 0, 0, 0 }}, {{ CH_RC64(0x85A308D3u), 0, 0, 0 }},
    {{ CH_RC64(0x13198A2Eu), 0, 0, 0 }}, {{ CH_RC64(0x03707344u), 0, 0, 0 }},
    {{ CH_RC64(0xA4093822u), 0, 0, 0 }}, {{ CH_RC64(0x299F31D0u), 0, 0, 0 }},
    {{ CH_RC64(0x082EFA98u), 0, 0, 0 }}, {{ CH_RC64(0xEC4E6C89u), 0, 0, 0 }},
    {{ CH_RC64(0x452821E6u), 0, 0, 0 }}, {{ CH_RC64(0x38D01377u), 0, 0, 0 }},
    {{ CH_RC64(0xBE5466CFu), 0, 0, 0 }}, {{ CH_RC64(0x34E90C6Cu), 0, 0, 0 }},
    {{ CH_RC64(0xC0AC29B7u), 0, 0, 0 }}, {{ CH_RC64(0xC97C50DDu), 0, 0, 0 }},
    {{ CH_RC64(0x3F84D5B5u), 0, 0, 0 }}, {{ CH_RC64(0xB5470917u), 0, 0, 0 }},
    {{ CH_RC64(0x9216D5D9u), 0, 0, 0 }}, {{ CH_RC64(0x8979FB1Bu), 0, 0, 0 }},
    {{ CH_RC64(0xD1310BA6u), 0, 0, 0 }}, {{ CH_RC64(0x98DFB5ACu), 0, 0, 0 }},
    {{ CH_RC64(0x2FFD72DBu), 0, 0, 0 }}, {{ CH_RC64(0xD01ADFB7u), 0, 0, 0 }},
    {{ CH_RC64(0xB8E1AFEDu), 0, 0, 0 }}, {{ CH_RC64(0x6A267E96u), 0, 0, 0 }},
    {{ CH_RC64(0xBA7C9045u), 0, 0, 0 }}, {{ CH_RC64(0xF12C7F99u), 0, 0, 0 }},
    {{ CH_RC64(0x24A19947u), 0, 0, 0 }}, {{ CH_RC64(0xB3916CF7u), 0, 0, 0 }}
};

/* 12 个向量 = 3 个行对 x 4 个 16-nibble 区段.
 *   行对 p, 区段 j: v[4*p + j]
 *   j = 0,1 是该对两行的 L 半 (nibble 0..15 / 16..31)
 *   j = 2,3 是该对两行的 R 半 (nibble 32..47 / 48..63)
 *   lane0 = 行 2p, lane1 = 行 2p+1.
 * 这个顺序正好是线性层 q0..q3 所需的顺序 (q0,q1 = L 的两个区段,
 * q2,q3 = R 的两个区段), 所以线性层可以完全原地进行. */
typedef struct CH_StateVec {
    __m256i v[CH_VECS];
} CH_StateVec;

/* --------------------------------------------------------------------- *
 *  行混合矩阵, 在行对 lane 布局下原地完成
 *
 *  记 A = 行对(0,1) = (r0|r1), B = 行对(2,3) = (r2|r3), C = 行对(4,5) = (r4|r5)
 *  的同一段 16 nibble (lane0 是较小的行号). 标量实现的异或顺序是
 *      3+=2; 4+=0; 5+=1; 0+=3; 1+=4; 2+=5; 3+=1; 4+=2; 5+=0
 *  每一步都只用到前一步之后的值, 下面的宏逐条对应 (每步两个 lane 同时工作):
 *      1) B ^= (0 | B.lane0)        -> 3 += 2
 *      2) C ^= A                    -> 4 += 0, 5 += 1   (整向量异或, 零洗牌)
 *      3) A ^= (B.lane1 | C.lane0)  -> 0 += 3, 1 += 4
 *      4) B ^= (C.lane1 | A.lane1)  -> 2 += 5, 3 += 1
 *      5) C ^= (B.lane0 | A.lane0)  -> 4 += 2, 5 += 0
 *  跨行对的源由一条 vperm2i128 同时选出两个 lane, 因此每 16 nibble 只要
 *  4 条洗牌 + 5 条异或, 整个行混合 16 条洗牌 + 20 条异或.
 * --------------------------------------------------------------------- */
#define CH_MIX_Q(s, j) do {                                                    \
    __m256i m_;                                                                \
    m_ = _mm256_permute2x128_si256((s)->v[4 + (j)], (s)->v[4 + (j)], 0x08);    \
    (s)->v[4 + (j)] = _mm256_xor_si256((s)->v[4 + (j)], m_);                   \
    (s)->v[8 + (j)] = _mm256_xor_si256((s)->v[8 + (j)], (s)->v[(j)]);          \
    m_ = _mm256_permute2x128_si256((s)->v[4 + (j)], (s)->v[8 + (j)], 0x21);    \
    (s)->v[(j)] = _mm256_xor_si256((s)->v[(j)], m_);                           \
    m_ = _mm256_permute2x128_si256((s)->v[8 + (j)], (s)->v[(j)], 0x31);        \
    (s)->v[4 + (j)] = _mm256_xor_si256((s)->v[4 + (j)], m_);                   \
    m_ = _mm256_permute2x128_si256((s)->v[4 + (j)], (s)->v[(j)], 0x20);        \
    (s)->v[8 + (j)] = _mm256_xor_si256((s)->v[8 + (j)], m_);                   \
} while (0)

/* R = rot_right_1(R), 即 32 nibble 左移 31 */
#define CH_PAIR_ROTR1(p2, p3) do {                        \
    __m256i va_ = _mm256_alignr_epi8((p2), (p3), 15);     \
    __m256i vb_ = _mm256_alignr_epi8((p3), (p2), 15);     \
    (p2) = va_; (p3) = vb_;                               \
} while (0)

/* 单个 L/R 子步: T = rot(L^R); L ^= T; R = rot_right1(R ^ T), 移位量 < 16
 *
 * 寄存器压力: 置换体常驻 12 个状态向量 + 1 张 S 盒表 = 13 个 YMM, 线性层只剩
 * 3 个空闲寄存器. 原写法把 ua_/ub_ 与 ta_/tb_ 同时留在寄存器里 (4 个临时量),
 * 峰值 17 > 16, GCC 只能往栈上溢出, 每轮多出若干 vmovdqa 存取. 这里改成:
 * 先算 ta_/tb_, 用 ta_/tb_ 造出 ua_ 后立即把 ua_ 异或进 p0/p2, 再用仍然有效的
 * ta_/tb_ 造 ub_ 覆写同一个临时量, 异或进 p1/p3. 运算、顺序和结果完全不变,
 * 峰值临时量 3 个 (12 + 1 + 3 = 16), 正好填满 YMM 寄存器堆. */
#define CH_PSTEP_LT(p0, p1, p2, p3, amt) do {                             \
    __m256i ta_ = _mm256_xor_si256((p0), (p2));                           \
    __m256i tb_ = _mm256_xor_si256((p1), (p3));                           \
    __m256i u_  = _mm256_alignr_epi8(tb_, ta_, (amt));                    \
    (p0) = _mm256_xor_si256((p0), u_);                                    \
    (p2) = _mm256_xor_si256((p2), u_);                                    \
    u_ = _mm256_alignr_epi8(ta_, tb_, (amt));                             \
    (p1) = _mm256_xor_si256((p1), u_);                                    \
    (p3) = _mm256_xor_si256((p3), u_);                                    \
    CH_PAIR_ROTR1(p2, p3);                                                \
} while (0)

/* 同上, 移位量 > 16 */
#define CH_PSTEP_GT(p0, p1, p2, p3, amt) do {                             \
    __m256i ta_ = _mm256_xor_si256((p0), (p2));                           \
    __m256i tb_ = _mm256_xor_si256((p1), (p3));                           \
    __m256i u_  = _mm256_alignr_epi8(ta_, tb_, (amt) - 16);               \
    (p0) = _mm256_xor_si256((p0), u_);                                    \
    (p2) = _mm256_xor_si256((p2), u_);                                    \
    u_ = _mm256_alignr_epi8(tb_, ta_, (amt) - 16);                        \
    (p1) = _mm256_xor_si256((p1), u_);                                    \
    (p3) = _mm256_xor_si256((p3), u_);                                    \
    CH_PAIR_ROTR1(p2, p3);                                                \
} while (0)

/* 移位量恰好 16: 旋转退化为两个 128 位半区交换, 无需任何洗牌 */
#define CH_PSTEP_EQ16(p0, p1, p2, p3) do {                                \
    __m256i ta_ = _mm256_xor_si256((p0), (p2));                           \
    __m256i tb_ = _mm256_xor_si256((p1), (p3));                           \
    (p0) = _mm256_xor_si256((p0), tb_);                                   \
    (p1) = _mm256_xor_si256((p1), ta_);                                   \
    (p2) = _mm256_xor_si256((p2), tb_);                                   \
    (p3) = _mm256_xor_si256((p3), ta_);                                   \
    CH_PAIR_ROTR1(p2, p3);                                                \
} while (0)

/* 一对行 (2p, 2p+1) 的 4 次 L/R 子步 (15, 7, 23, 16), 完全原地:
   q0 = 行 2p 的 nibble 0..15 | 行 2p+1 的 0..15, q1 = 两个 16..31,
   q2 = 两个 32..47, q3 = 两个 48..63 —— 正是 CH_PSTEP 期望的
   (L 前半, L 后半, R 前半, R 后半) 形式, 因此不需要任何重排. */
#define CH_LIN_PAIR_INPLACE(s, p) do {                                     \
    __m256i q0_ = (s)->v[4 * (p) + 0];                                     \
    __m256i q1_ = (s)->v[4 * (p) + 1];                                     \
    __m256i q2_ = (s)->v[4 * (p) + 2];                                     \
    __m256i q3_ = (s)->v[4 * (p) + 3];                                     \
    CH_PSTEP_LT(q0_, q1_, q2_, q3_, 15);                                   \
    CH_PSTEP_LT(q0_, q1_, q2_, q3_, 7);                                    \
    CH_PSTEP_GT(q0_, q1_, q2_, q3_, 23);                                   \
    CH_PSTEP_EQ16(q0_, q1_, q2_, q3_);                                     \
    (s)->v[4 * (p) + 0] = q0_;                                             \
    (s)->v[4 * (p) + 1] = q1_;                                             \
    (s)->v[4 * (p) + 2] = q2_;                                             \
    (s)->v[4 * (p) + 3] = q3_;                                             \
} while (0)

/* 6 行 x 32 字节 -> 12 个行对向量.
   每个行向量先拆成 (nibble 0..15|32..47) 与 (nibble 16..31|48..63) 两个中间量,
   然后**直接**把同一行对两行的低 128 位/高 128 位配对: 每对只需 4 条
   vperm2i128 (原来先造 rl/rr 再配对, 每对 8 条), 整个展开 24 -> 12 条.
   只在每次置换的开头做一次. */
static void ch_state_expand(const uint8_t b[192], CH_StateVec* s) {
    const __m256i m0f = _mm256_set1_epi8(0x0F);
    int p, k;
    for (p = 0; p < 3; ++p) {
        __m256i a[2], c[2];
        for (k = 0; k < 2; ++k) {
            const int row = 2 * p + k;
            __m256i v  = _mm256_loadu_si256((const __m256i*)(b + 32 * row));
            __m256i hn = _mm256_and_si256(_mm256_srli_epi16(v, 4), m0f);
            __m256i ln = _mm256_and_si256(v, m0f);
            a[k] = _mm256_unpacklo_epi8(hn, ln);   /* nibble 0..15 | 32..47 */
            c[k] = _mm256_unpackhi_epi8(hn, ln);   /* nibble 16..31 | 48..63 */
        }
        s->v[4 * p + 0] = _mm256_permute2x128_si256(a[0], a[1], 0x20); /*  0..15 */
        s->v[4 * p + 1] = _mm256_permute2x128_si256(c[0], c[1], 0x20); /* 16..31 */
        s->v[4 * p + 2] = _mm256_permute2x128_si256(a[0], a[1], 0x31); /* 32..47 */
        s->v[4 * p + 3] = _mm256_permute2x128_si256(c[0], c[1], 0x31); /* 48..63 */
    }
}

/* 一个 32-nibble 向量 (nibble i -> 字节 i) -> 每 16 位字 (nib_lo<<4)|nib_hi,
   即两个相邻 nibble 已按 "高 nibble 在前" 合并为一个字节, 但仍以 16 位字存放.

   vpmaddubsw: 无符号字节 x 有符号字节 y 的两两乘积累加为有符号 16 位字. 取
   x = 该向量, y 的偶数下标字节 = 0x10, 奇数下标字节 = 0x01, 于是
       word j = 16*nib[2j] + 1*nib[2j+1] = (nib_lo<<4) | nib_hi,
   因为每项 <= 15, 结果 <= 255, 不触及有符号 16 位饱和. 原来每字要
   and + slli + srli + or 四条指令, 现在一条 (与向量共享乘数常量). */
#define CH_PACKW(x, mul)                                                   \
    _mm256_maddubs_epi16((x), (mul))

/* 12 个行对向量 -> 192 字节 (高 nibble 在前), ch_state_expand 的逆过程.
   v[4p+0]/v[4p+1] 的 lane0 分别是行 2p 的 nibble 0..15 与 16..31, 所以先各自
   压成字节 (每 16 位字 = nib_lo<<4|nib_hi, 值恒 < 256), 再一条 packuswb 就得到
   lane0 = 行 2p 的字节 0..15, lane1 = 行 2p+1 的字节 0..15; 后 32 字节同理.
   两条 perm2i128 把两个半区合回整行, 于是每对只需 2 条 packuswb + 2 条
   perm2i128 + 2 条 32 字节存储. vpmaddubsw 的乘数常量整个置换只装一次. */
static void ch_state_compact(const CH_StateVec* s, uint8_t b[192]) {
    const __m256i mul = _mm256_set1_epi16(0x0110);
    int p;
    for (p = 0; p < 3; ++p) {
        __m256i lo = _mm256_packus_epi16(CH_PACKW(s->v[4 * p + 0], mul),
                                         CH_PACKW(s->v[4 * p + 1], mul));
        __m256i hi = _mm256_packus_epi16(CH_PACKW(s->v[4 * p + 2], mul),
                                         CH_PACKW(s->v[4 * p + 3], mul));
        _mm256_storeu_si256((__m256i*)(b + 64 * p),
                            _mm256_permute2x128_si256(lo, hi, 0x20));
        _mm256_storeu_si256((__m256i*)(b + 64 * p + 32),
                            _mm256_permute2x128_si256(lo, hi, 0x31));
    }
}

static void ch_round_vec(CH_StateVec* s, int r) {
    const __m256i sbf = _mm256_loadu_si256((const __m256i*)SBOX_DUP);
    const __m256i rc  = _mm256_loadu_si256((const __m256i*)CH_RC_VEC[r].q);
    int i;

    /* 第 1 次 S 盒替换: 所有行都是同一张表, 与向量内的 nibble 摆放无关. */
    for (i = 0; i < CH_VECS; ++i) {
        s->v[i] = _mm256_shuffle_epi8(sbf, s->v[i]);
    }

    /* 行混合矩阵 (行对 lane 布局, 原地完成) */
    CH_MIX_Q(s, 0);
    CH_MIX_Q(s, 1);
    CH_MIX_Q(s, 2);
    CH_MIX_Q(s, 3);

    /* 第 2 次 S 盒 (每对行一张按 lane 分列常量的复合表) + L/R 线性层, 逐行对进行. */
    {
        const __m256i t0 = _mm256_loadu_si256((const __m256i*)SBOX_PAIR[0]);
        s->v[0] = _mm256_shuffle_epi8(t0, s->v[0]);
        s->v[1] = _mm256_shuffle_epi8(t0, s->v[1]);
        s->v[2] = _mm256_shuffle_epi8(t0, s->v[2]);
        s->v[3] = _mm256_shuffle_epi8(t0, s->v[3]);
        CH_LIN_PAIR_INPLACE(s, 0);
    }
    {
        const __m256i t1 = _mm256_loadu_si256((const __m256i*)SBOX_PAIR[1]);
        s->v[4] = _mm256_shuffle_epi8(t1, s->v[4]);
        s->v[5] = _mm256_shuffle_epi8(t1, s->v[5]);
        s->v[6] = _mm256_shuffle_epi8(t1, s->v[6]);
        s->v[7] = _mm256_shuffle_epi8(t1, s->v[7]);
        CH_LIN_PAIR_INPLACE(s, 1);
    }
    {
        const __m256i t2 = _mm256_loadu_si256((const __m256i*)SBOX_PAIR[2]);
        s->v[8]  = _mm256_shuffle_epi8(t2, s->v[8]);
        s->v[9]  = _mm256_shuffle_epi8(t2, s->v[9]);
        s->v[10] = _mm256_shuffle_epi8(t2, s->v[10]);
        s->v[11] = _mm256_shuffle_epi8(t2, s->v[11]);
        CH_LIN_PAIR_INPLACE(s, 2);
    }

    /* 轮常数注入到第 0 行的前 8 个 nibble. 第 0 行是行对 0 的 lane0, 即 v[0]
       的低 128 位前 8 字节; CH_RC_VEC 的其余 24 字节为零, 故一条整宽 vpxor
       即可, 无需 vmovq/零扩展, 也不占常驻寄存器. */
    s->v[0] = _mm256_xor_si256(s->v[0], rc);
}

#endif /* __AVX2__ */


/* ===================================================================== *
 *  Scalar nibble reference path (portable fallback)
 * ===================================================================== */

/**
 * @brief 将 192 字节的状态转换为每行 64 个 nibble 的数组表示。
 *        每个字节拆分为高低两个 4 位 nibble。
 */
static void state_from_bytes(const uint8_t src_bytes[192], uint8_t nibs[TOTAL_NIBS]) {
    size_t row, k;
    for (row = 0; row < ROWS; ++row) {
        const uint8_t* p = src_bytes + row * 32;
        uint8_t* n = nibs + row * NIBS_PER_ROW;
        for (k = 0; k < 32; ++k) {
            n[2 * k + 0] = (uint8_t)((p[k] >> 4) & 0x0F);
            n[2 * k + 1] = (uint8_t)( p[k]       & 0x0F);
        }
    }
}

/**
 * @brief 将每行 64 个 nibble 的数组表示重新打包为 192 字节状态。
 */
static void state_to_bytes(const uint8_t nibs[TOTAL_NIBS], uint8_t dst_bytes[192]) {
    size_t row, k;
    for (row = 0; row < ROWS; ++row) {
        uint8_t* p = dst_bytes + row * 32;
        const uint8_t* n = nibs + row * NIBS_PER_ROW;
        for (k = 0; k < 32; ++k) {
            p[k] = (uint8_t)(((n[2 * k + 0] & 0x0F) << 4) | (n[2 * k + 1] & 0x0F));
        }
    }
}


/**
 * @brief 对 32 个 nibble 的数组执行向左循环移位 amount 位。
 *        用临时缓冲区模拟 std::rotate 的行为。
 */
static void rotate_left_nib(uint8_t* p, size_t amount) {
    uint8_t tmp[32];
    size_t i;
    amount %= 32;
    if (amount == 0) return;
    for (i = 0; i < 32; ++i) {
        tmp[i] = p[(i + amount) % 32];
    }
    memcpy(p, tmp, 32);
}


/**
 * @brief 对 32 个 nibble 的数组执行向右循环移位 1 位（即左移 31）。
 */
static void rotate_right1_nib(uint8_t* p) {
    rotate_left_nib(p, 31);
}

/**
 * @brief 将 src_row 按 nibble 异或到 dst_row。
 */
static void row_xor_row(uint8_t s[TOTAL_NIBS], size_t dst_row, size_t src_row) {
    uint8_t* d = s + dst_row * NIBS_PER_ROW;
    const uint8_t* x = s + src_row * NIBS_PER_ROW;
    size_t k;
    for (k = 0; k < NIBS_PER_ROW; ++k) d[k] ^= x[k];
}

/**
 * @brief BigU-1536 单轮置换：S 盒、行混合、列常量、再 S 盒、双层混合旋转、轮常数注入。
 * @param s 当前状态（384 个 nibble）
 * @param r 轮号 0..27
 */
static void BigU_1536_Round_plain(uint8_t s[TOTAL_NIBS], int r) {
    size_t k, row;
    static const size_t P1_AMOUNTS[4] = { 15, 7, 23, 16 };
    uint8_t T1[32];
    uint32_t rc;
    uint8_t* x0;
    int sub;

    /* 第 1 次 S 盒替换 */
    for (k = 0; k < TOTAL_NIBS; ++k) {
        s[k] = SBOX[s[k] & 0x0F];
    }

    /* 行混合矩阵 */
    row_xor_row(s, 3, 2); row_xor_row(s, 4, 0); row_xor_row(s, 5, 1);
    row_xor_row(s, 0, 3); row_xor_row(s, 1, 4); row_xor_row(s, 2, 5);
    row_xor_row(s, 3, 1); row_xor_row(s, 4, 2); row_xor_row(s, 5, 0);

    /* 每行异或列常量 */
    for (row = 0; row < ROWS; ++row) {
        uint8_t c = COL_CONST[row];
        uint8_t* p = s + row * NIBS_PER_ROW;
        for (k = 0; k < NIBS_PER_ROW; ++k) p[k] ^= c;
    }

    /* 第 2 次 S 盒替换 */
    for (k = 0; k < TOTAL_NIBS; ++k) {
        s[k] = SBOX[s[k] & 0x0F];
    }

    /* 4 次 L/R 半行的线性变换 */
    for (row = 0; row < ROWS; ++row) {
        uint8_t* L = s + row * NIBS_PER_ROW;
        uint8_t* R = L + 32;

        for (sub = 0; sub < 4; ++sub) {
            /* T1 = L ^ R, 然后循环左移 P1_AMOUNTS[sub] */
            for (k = 0; k < 32; ++k) T1[k] = L[k] ^ R[k];
            rotate_left_nib(T1, P1_AMOUNTS[sub]);

            /* L ^= T1 */
            for (k = 0; k < 32; ++k) L[k] ^= T1[k];

            /* R ^= T1 后整体右移 1 */
            for (k = 0; k < 32; ++k) R[k] ^= T1[k];
            rotate_right1_nib(R);
        }
    }

    /* 轮常数注入到第 0 行的前 8 个 nibble */
    rc = RC_U32[r];
    x0 = s + 0 * NIBS_PER_ROW;
    for (k = 0; k < 8; ++k) {
        uint8_t nib = (uint8_t)((rc >> (28 - 4 * k)) & 0x0F);
        x0[k] ^= nib;
    }
}

/**
 * @brief 以 192 字节输入/输出方式调用 28 轮置换。
 */
static void C_Engine1536_Perm28_plain(uint8_t state_bytes[192]) {
#if defined(__AVX2__)
    CH_StateVec sv;
    int r;

    ch_state_expand(state_bytes, &sv);
    for (r = 0; r < 28; ++r) {
        ch_round_vec(&sv, r);
    }
    ch_state_compact(&sv, state_bytes);
#else
    uint8_t s[TOTAL_NIBS];
    int r;
    state_from_bytes(state_bytes, s);
    for (r = 0; r < 28; ++r) {
        BigU_1536_Round_plain(s, r);
    }
    state_to_bytes(s, state_bytes);
#endif
}

/* C-Hash 相关常量 */
#define CH_B_BITS       ((size_t)1536)
#define CH_W_BITS       ((size_t)64)
#define CH_N_BITS       ((size_t)1472)
#define CH_HALF_N_BITS  ((size_t)736)

#define CH_B_BYTES      (CH_B_BITS / 8)
#define CH_N_BYTES      (CH_N_BITS / 8)
#define CH_HALF_N_BYTES (CH_HALF_N_BITS / 8)
#define CH_W_BYTES      (CH_W_BITS / 8)

#define CH_LANE_INJECT  ((uint8_t)0x01)
#define CH_LANE_GEN     ((uint8_t)0x03)


/* 模式枚举 */
typedef enum CHashMode {
    CH_CTR_PERM = 0,
    CH_CTR_FUNC = 1
} CHashMode;

typedef struct CHashVariant {
    int       hashlen_bits;
    uint8_t   iv[CH_HALF_N_BYTES];
    size_t    h_bits;
    CHashMode mode;
    uint8_t   lane_inject;
    uint8_t   lane_gen;
    uint8_t   lane_ldrh;
} CHashVariant;


/**
 * @brief 构建 IV：后两个字节写入 hashlen_bits 的大端表示。
 */
static void build_IV(int hashlen_bits, uint8_t out[CH_HALF_N_BYTES]) {
    memset(out, 0, CH_HALF_N_BYTES);
    out[CH_HALF_N_BYTES - 2] = (uint8_t)((hashlen_bits >> 8) & 0xFF);
    out[CH_HALF_N_BYTES - 1] = (uint8_t)( hashlen_bits       & 0xFF);
}

/**
 * @brief 根据摘要长度选择变体参数（512 或 1024）。
 * @return 1 成功，0 失败
 */
static int make_variant(int hashlen_bits, CHashVariant* v) {
    if (hashlen_bits == 512) {
        v->hashlen_bits = 512;
        v->h_bits       = 736;
        v->mode         = CH_CTR_PERM;
        v->lane_inject  = 0x01;   /* VIL  */
        v->lane_gen     = 0x02;   /* FIL  */
        v->lane_ldrh    = 0x03;   /* LDRH */
    } else if (hashlen_bits == 1024) {
        v->hashlen_bits = 1024;
        v->h_bits       = 1472;
        v->mode         = CH_CTR_FUNC;
        v->lane_inject  = 0x81;   /* VIL  */
        v->lane_gen     = 0x82;   /* FIL  */
        v->lane_ldrh    = 0x83;   /* LDRH */
    } else {
        return 0;
    }
    build_IV(hashlen_bits, v->iv);
    return 1;
}

/**
 * @brief 将 laneID 与 56 位计数器拼接为 8 字节大端 CTR。
 */
static void make_CTR_bytes(uint8_t laneID, uint64_t i, uint8_t out[8]) {
    uint64_t ctr = ((uint64_t)laneID << 56) | (i & ((1ULL << 56) - 1));
    int k;
    for (k = 0; k < 8; ++k) {
        out[k] = (uint8_t)(ctr >> (56 - 8 * k));
    }
}


/**
 * @brief 把 x_n 和 ctr_w 拼接成 B 字节状态。
 */
static void pack_state(const uint8_t x_n[CH_N_BYTES],
                       const uint8_t ctr_w[CH_W_BYTES],
                       uint8_t state_out[CH_B_BYTES]) {
    memcpy(state_out,              x_n,   CH_N_BYTES);
    memcpy(state_out + CH_N_BYTES, ctr_w, CH_W_BYTES);
}

/**
 * @brief 按字节异或 src 到 dst。
 */
static void xor_inplace(uint8_t* dst, const uint8_t* src, size_t n) {
    size_t k;
    for (k = 0; k < n; ++k) dst[k] ^= src[k];
}

/**
 * @brief CTR-PERM 模式：直接取置换输出的前 N 字节作为 y。
 */
static void ctr_perm(const uint8_t x_n[CH_N_BYTES],
                     const uint8_t ctr_w[CH_W_BYTES],
                     uint8_t y_n[CH_N_BYTES]) {
    uint8_t S[CH_B_BYTES];
    pack_state(x_n, ctr_w, S);
    C_Engine1536_Perm28_plain(S);
    memcpy(y_n, S, CH_N_BYTES);
}


/**
 * @brief CTR-FUNC 模式：y = perm(x || ctr)[:N] ^ x
 */
static void ctr_func(const uint8_t x_n[CH_N_BYTES],
                     const uint8_t ctr_w[CH_W_BYTES],
                     uint8_t y_n[CH_N_BYTES]) {
    uint8_t S[CH_B_BYTES];
    pack_state(x_n, ctr_w, S);
    C_Engine1536_Perm28_plain(S);
    memcpy(y_n, S, CH_N_BYTES);
    xor_inplace(y_n, x_n, CH_N_BYTES);
}

/**
 * @brief 根据 variant 选择 ctr_perm 或 ctr_func 作用到输入。
 */
static void apply_P(const CHashVariant* v,
                    const uint8_t x_n[CH_N_BYTES],
                    const uint8_t ctr_w[CH_W_BYTES],
                    uint8_t y_n[CH_N_BYTES]) {
    if (v->mode == CH_CTR_PERM) ctr_perm(x_n, ctr_w, y_n);
    else                        ctr_func(x_n, ctr_w, y_n);
}


/**
 * @brief 处理短消息(< N 位)的 LDRH 模式：对同一 x 用计数器 1、2 各做一次
 *        CTR-Perm，输出相异或后截断为摘要。
 *        x   = M || 1 || 0^(N-1-|M|)
 *        y1  = LMB(N, P(x || [LaneID||1]))
 *        y2  = LMB(N, P(x || [LaneID||2]))
 *        y   = y1 XOR y2
 * @return 输出摘要字节数
 */
static size_t C_HASH_LDRH(const CHashVariant* v,
                          const uint8_t* msg, uint64_t msg_len_bits,
                          uint8_t* digest_out) {
    uint8_t x_1472[CH_N_BYTES];
    uint8_t ctr1[CH_W_BYTES], ctr2[CH_W_BYTES];
    uint8_t y1[CH_N_BYTES], y2[CH_N_BYTES];
    uint64_t full_bytes;
    uint32_t tail_bits;
    size_t hashlen_bytes;

    memset(x_1472, 0, CH_N_BYTES);

    full_bytes = msg_len_bits / 8;
    tail_bits  = (uint32_t)(msg_len_bits % 8);
    if (full_bytes > 0) {
        memcpy(x_1472, msg, (size_t)full_bytes);
    }
    if (tail_bits > 0) {
        uint8_t mask = (uint8_t)(0xFFu << (8 - tail_bits));
        x_1472[(size_t)full_bytes] = (uint8_t)(msg[full_bytes] & mask);
    }

    /* 写入 '1' 比特作为填充起点 */
    x_1472[(size_t)(msg_len_bits / 8)] |= (uint8_t)(0x80u >> (msg_len_bits % 8));

    /* 两个计数器：[LaneID||1] 与 [LaneID||2] */
    make_CTR_bytes(v->lane_ldrh, 1, ctr1);
    make_CTR_bytes(v->lane_ldrh, 2, ctr2);

    /* 两次 CTR-Perm 输出相异或 */
    ctr_perm(x_1472, ctr1, y1);
    ctr_perm(x_1472, ctr2, y2);
    xor_inplace(y1, y2, CH_N_BYTES);

    hashlen_bytes = (size_t)(v->hashlen_bits / 8);
    memcpy(digest_out, y1, hashlen_bytes);
    return hashlen_bytes;
}

/* ===================================================================== *
 *  LDXOF —— 短消息可扩展输出模式（参考实现，独立函数）
 *
 *  注意：本函数仅作为 C-Hash “短消息可扩展输出模式 (XOF)” 的参考实现，
 *        供需要 XOF 能力的使用者参考调用；它【不】被标准 CryptHash 流程
 *        使用，也不参与 VIL 注入 / FIL 收尾。LDXOF 始终采用 CTR-Perm
 *        形式——即便是 C-Hash-1024 也不使用 CTR-Func、不做 XOR x。
 *
 *  仅处理短消息：要求 |M| < 1472 bit（即 < 184 字节）。
 *  LaneID：C-Hash-512 → 0x04，C-Hash-1024 → 0x84。
 *
 *  64 位计数器布局（大端序列化）：
 *      [ LaneID(8) | OutputByteLen(24) | Reserved(8)=0 | Index(24) ]
 *
 *  流程：
 *      x   = M || 1 || 0^(1471-|M|)                  （1472-bit 块）
 *      y0  = LMB(1472, P(x || ctr0))                 （i=0 ）
 *      ri  = y0 XOR LMB(1472, P(x || ctri))          （i=1..block_count）
 *      R   = r1 || r2 || ... || r_block_count
 *      out = LMB(OutputByteLen*8, R)
 * ===================================================================== */

/**
 * @brief 构建 LDXOF 的 64 位计数器并以 8 字节大端写出。
 * @param lane_id         LDXOF 通道号（0x04 或 0x84）
 * @param output_byte_len 用户请求的输出字节数（24 bit）
 * @param index           当前置换实例编号 i（24 bit）
 * @param out             输出的 8 字节大端计数器
 */
static void make_ldxof_counter(uint8_t lane_id, uint32_t output_byte_len,
                               uint32_t index, uint8_t out[CH_W_BYTES]) {
    uint64_t ctr = ((uint64_t)lane_id << 56)
                 | ((uint64_t)(output_byte_len & 0xFFFFFFu) << 32)
                 | ((uint64_t)0x00u << 24)
                 | ((uint64_t)(index & 0xFFFFFFu));
    int k;
    for (k = 0; k < 8; ++k) {
        out[k] = (uint8_t)(ctr >> (56 - 8 * k));
    }
}

/**
 * @brief LDXOF 短消息可扩展输出（参考实现，标准 CryptHash 流程不调用）。
 * @param variant         512 或 1024
 * @param msg             短消息指针
 * @param msg_len_bits    消息位长，要求 < 1472
 * @param output_byte_len 期望输出字节数，要求 < 2^24
 * @param out             输出缓冲区（至少 output_byte_len 字节）
 * @return 实际写出的字节数；参数非法返回 (size_t)-1
 */
size_t C_HASH_LDXOF(int variant,
                    const uint8_t* msg, uint64_t msg_len_bits,
                    uint32_t output_byte_len,
                    uint8_t* out) {
    uint8_t  lane_id;
    uint8_t  x_1472[CH_N_BYTES];
    uint8_t  ctr[CH_W_BYTES];
    uint8_t  y0[CH_N_BYTES], yi[CH_N_BYTES];
    uint64_t full_bytes;
    uint32_t tail_bits;
    size_t   block_count, idx, written;

    /* 仅处理短消息，且输出长度需落在 24 位范围内 */
    if (msg_len_bits >= CH_N_BITS)     return (size_t)-1;
    if (output_byte_len >= (1u << 24)) return (size_t)-1;
    if (variant == 512)       lane_id = 0x04;
    else if (variant == 1024) lane_id = 0x84;
    else                      return (size_t)-1;

    /* 短消息 padding：x = M || 1 || 0^(1471-|M|) */
    memset(x_1472, 0, CH_N_BYTES);
    full_bytes = msg_len_bits / 8;
    tail_bits  = (uint32_t)(msg_len_bits % 8);
    if (full_bytes > 0) memcpy(x_1472, msg, (size_t)full_bytes);
    if (tail_bits > 0) {
        uint8_t mask = (uint8_t)(0xFFu << (8 - tail_bits));
        x_1472[(size_t)full_bytes] = (uint8_t)(msg[full_bytes] & mask);
    }
    x_1472[(size_t)(msg_len_bits / 8)] |= (uint8_t)(0x80u >> (msg_len_bits % 8));
    /* y0：i=0  */
    make_ldxof_counter(lane_id, output_byte_len, 0, ctr);
    ctr_perm(x_1472, ctr, y0);

    /* block_count = ceil(OutputByteLen*8 / 1472) = ceil(OutputByteLen / 184) */
    block_count = (size_t)((output_byte_len + CH_N_BYTES - 1) / CH_N_BYTES);

    /* 逐块：ri = y0 XOR LMB(N, P(x||ctri))，拼接后截断为 OutputByteLen */
    written = 0;
    for (idx = 1; idx <= block_count; ++idx) {
        size_t copy_len;
        make_ldxof_counter(lane_id, output_byte_len, (uint32_t)idx, ctr);
        ctr_perm(x_1472, ctr, yi);
        xor_inplace(yi, y0, CH_N_BYTES);   /* ri = y0 XOR yi */

        copy_len = CH_N_BYTES;
        if (written + copy_len > (size_t)output_byte_len) {
            copy_len = (size_t)output_byte_len - written;
        }
        memcpy(out + written, yi, copy_len);
        written += copy_len;
    }
    return written;
}

/* 分块填充不再整条物化: 消息按 736-bit (92 字节) 分块, 块起点恒为字节对齐,
 * 只有含填充位 '1' 的那一块需要真正拼出来, 它之前的块整体落在消息里, 之后
 * 的块全为零 (对状态异或是恒等). 于是 calloc(l*92) + 全消息 memcpy + free
 * 全部消失, 每块只剩一次 92 字节的只读异或. */
static void ch_make_pad_block(const uint8_t* msg, uint64_t msg_len_bits,
                              size_t pad_blk, uint8_t out[CH_HALF_N_BYTES]) {
    uint64_t off_bits = (uint64_t)pad_blk * CH_HALF_N_BITS;
    const uint8_t* src = msg + pad_blk * CH_HALF_N_BYTES;
    size_t   nb = (size_t)((msg_len_bits - off_bits) / 8);
    uint32_t tb = (uint32_t)((msg_len_bits - off_bits) % 8);

    memset(out, 0, CH_HALF_N_BYTES);
    if (nb) memcpy(out, src, nb);
    if (tb) out[nb] = (uint8_t)(src[nb] & (uint8_t)(0xFFu << (8 - tb)));
    out[nb] |= (uint8_t)(0x80u >> tb);
}

/**
 * @brief C-Hash 主流程：对长消息做分块压缩，最后做生成阶段输出摘要。
 * @return 输出摘要字节数
 */
/* ===================================================================== *
 *  C_HASH 主流程 (原地块串联)
 *
 *  原来的块循环每轮都重建 x_buf = (h1^m_i)||h2, 置换到 y_buf, 再把
 *  h1/h2 从 y_buf 拷回来 (每块 6 次 92/184 字节拷贝)。观察递归
 *      x_{i+1} = P(x_i || ctr_i)[:N] ^ x_i            (CTR-FUNC)
 *      h2_i    = h2_i ^ m_i
 *  可以把 x 直接放在 192 字节状态缓冲的前 184 字节里 (后 8 字节是计数器),
 *  置换本身原地做 (ch_state_expand 先读完整个 192 字节, ch_state_compact
 *  再写回), 于是每块只剩两次 92 字节异或, CTR-PERM 模式下**零拷贝**;
 *  只有 CTR-FUNC 需要额外保存 x_i 做最后的整宽异或。
 * ===================================================================== */
static size_t C_HASH(const CHashVariant* v,
                     const uint8_t* msg, uint64_t msg_len_bits,
                     uint8_t* digest_out) {
    uint8_t st[CH_B_BYTES];        /* [0..183] = x, [184..191] = ctr */
    uint8_t xs[CH_N_BYTES];        /* CTR-FUNC: 置换前的 x */
    uint8_t pad[CH_HALF_N_BYTES];  /* 含填充位 '1' 的那一块 */
    static const uint8_t zeroblk[CH_HALF_N_BYTES] = { 0 };
    size_t l, i, pad_blk;
    size_t hashlen_bytes;

    if (msg_len_bits < CH_N_BITS) {
        return C_HASH_LDRH(v, msg, msg_len_bits, digest_out);
    }

    /* 初始状态：左半 = IV, 右半 = 0 */
    memcpy(st, v->iv, CH_HALF_N_BYTES);
    memset(st + CH_HALF_N_BYTES, 0, CH_HALF_N_BYTES);

    make_CTR_bytes(v->lane_inject, 0, st + CH_N_BYTES);
    C_Engine1536_Perm28_plain(st);

    /* CTR-FUNC: y = P(x||ctr)[:N] ^ x, x = IV || 0, 所以左半再异或一次 IV.
       然后左右半都异或 IV (右半的 "h2 ^= IV" 步骤), 于是 st 就是 h1 || h2. */
    if (v->mode == CH_CTR_FUNC) xor_inplace(st, v->iv, CH_HALF_N_BYTES);
    xor_inplace(st + CH_HALF_N_BYTES, v->iv, CH_HALF_N_BYTES);

    /* 填充消息: l 块, 块 pad_blk 是唯一含填充位 '1' 的一块 (pad_blk == l 表示
       消息长度恰为 736 的整数倍, 需要一整块纯填充块). 其后的块全为零. */
    {
        uint64_t rem = msg_len_bits % CH_HALF_N_BITS;
        uint64_t K   = (CH_HALF_N_BITS - 1 - rem) % CH_HALF_N_BITS;
        l = (size_t)((msg_len_bits + 1 + K) / CH_HALF_N_BITS);
    }
    pad_blk = (size_t)(msg_len_bits / CH_HALF_N_BITS);
    if (pad_blk < l) ch_make_pad_block(msg, msg_len_bits, pad_blk, pad);

    for (i = 1; i <= l; ++i) {
        const size_t bi = i - 1;
        const uint8_t* m_i = zeroblk;

        /* 左半 ^= m_i; 右半保持 h2 */
        if (bi < pad_blk)      m_i = msg + bi * CH_HALF_N_BYTES;
        else if (bi == pad_blk) m_i = pad;
        if (m_i != zeroblk) xor_inplace(st, m_i, CH_HALF_N_BYTES);
        if (v->mode == CH_CTR_FUNC) memcpy(xs, st, CH_N_BYTES);

        make_CTR_bytes(v->lane_inject, (uint64_t)i, st + CH_N_BYTES);
        C_Engine1536_Perm28_plain(st);          /* 原地: P(x || ctr) */

        if (v->mode == CH_CTR_FUNC) xor_inplace(st, xs, CH_N_BYTES);
        /* h2 ^= m_i, 其余部分即新的 h1 */
        if (m_i != zeroblk) xor_inplace(st + CH_HALF_N_BYTES, m_i, CH_HALF_N_BYTES);
    }

    /* 生成阶段: st 已经是 h1 || h2 */
    if (v->mode == CH_CTR_FUNC) memcpy(xs, st, CH_N_BYTES);
    make_CTR_bytes(v->lane_gen, 1, st + CH_N_BYTES);
    C_Engine1536_Perm28_plain(st);
    if (v->mode == CH_CTR_FUNC) xor_inplace(st, xs, CH_N_BYTES);

    hashlen_bytes = (size_t)(v->hashlen_bits / 8);
    memcpy(digest_out, st, hashlen_bytes);

    return hashlen_bytes;
}


/**
 * @brief 对外导出的 CryptHash 接口（纯 C 实现）。
 * @return 0 成功, 负值为错误码
 */
int CryptHash(int digest_len_bits,
              const unsigned char* msg,
              unsigned long long msg_len_bits,
              unsigned char* digest) {
    CHashVariant v;
    if (digest == NULL) return -2;
    if (msg == NULL && msg_len_bits > 0) return -3;

    if (!make_variant(digest_len_bits, &v)) return -1;

    C_HASH(&v, (const uint8_t*)msg, (uint64_t)msg_len_bits, (uint8_t*)digest);
    return 0;
}
