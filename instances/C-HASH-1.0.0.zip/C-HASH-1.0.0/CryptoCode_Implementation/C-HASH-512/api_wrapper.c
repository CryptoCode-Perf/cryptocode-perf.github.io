/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).
*/

#include "CryptHash_AlgorithmInstance.h"
#include "c-hash.h"

/* 1024-bit output uses the separately compiled CryptoCode implementation. */
int chash1024_CryptHash(int, const unsigned char *, unsigned long long, unsigned char *);
int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest)
{
    static const unsigned char empty = 0;
    if (digest == NULL) return -2;
    if (msg == NULL && msg_len_bits != 0) return -3;
    if (digest_len_bits == 1024) return chash1024_CryptHash(1024, msg, msg_len_bits, digest);
    if (digest_len_bits != 512) return -1;
    return c_hash_512_bits(msg ? msg : &empty, msg_len_bits, digest);
}
