#!/usr/bin/env bash
# rebuild LLH-1024 with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o LLH-1024.so llh1024.c
sha256sum LLH-1024.so
