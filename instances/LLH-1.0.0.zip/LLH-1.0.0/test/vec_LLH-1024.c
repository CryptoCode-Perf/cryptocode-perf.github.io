/* Cross-validation harness for LLH-1024 (x86_64 / AVX2).
 * Prints digests over padding-boundary bit lengths and the three official
 * digest tiers (1024/768/512); diff the outputs of two implementations to
 * prove equivalence. Anchor: the official reference implementation.
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest);

static const unsigned lens[] = {
    0, 1, 7, 63, 64, 65, 127, 128, 129, 255, 256,
    511, 512, 513, 1023, 1024, 1025, 2047, 2048, 2049, 8191, 16384
};
static const unsigned dtiers[] = { 1024 };

int main(void)
{
    static unsigned char msg[4096];
    unsigned char dig[128];
    for (unsigned t = 0; t < sizeof(dtiers) / sizeof(dtiers[0]); t++)
    for (unsigned i = 0; i < sizeof(lens) / sizeof(lens[0]); i++) {
        unsigned bits = lens[i], nbytes = (bits + 7) / 8;
        for (unsigned j = 0; j < nbytes; j++)
            msg[j] = (unsigned char)(j * 97u + bits * 31u + 0x9Eu);
        /* Zero unused low bits of the trailing partial byte (reference
         * semantics -- matches what the reference CryptHash absorbs). */
        if (bits % 8 != 0)
            msg[nbytes - 1] &= (unsigned char)(0xffU << (8 - bits % 8));
        if (CryptHash((int)dtiers[t], msg, bits, dig) != 0) {
            printf("ERR d=%u %u\n", dtiers[t], bits);
            return 1;
        }
        printf("d=%u bits=%u ", dtiers[t], bits);
        for (int k = 0; k < (int)(dtiers[t] / 8); k++) printf("%02X", dig[k]);
        printf("\n");
    }
    return 0;
}
