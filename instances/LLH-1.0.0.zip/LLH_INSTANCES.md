# LLH — 实例优化说明 / Instance Optimization Notes

> 对照基准：随包 `Optimized_Implementation`（官方优化实现）。
> Baseline for every comparison below: the vendor `Optimized_Implementation` shipped in the same package.
> 加速比口径 / Speed-up metric: 八档几何均值（32 B … 64 KiB），>1 为我们更快。
> Geometric mean over the eight message sizes (32 B … 64 KiB); >1 means we are faster.

---

## LLH-512 · 6 组 ymm 打包，T 层零 shuffle · 1.0583（win）

**中文**
把 24 个 64 位状态字按「6 个 ymm × 4 行」的布局常驻寄存器，一个 ymm 装同一行的 4 个字。
T 层（行移位）在这套布局下的偏移量全是 4 的倍数，因此**不需要任何 `vpshufb`/`vpermq`**——只要按编译期常数换寄存器名字即可，等价于零指令。
SIGMA 常数全部落在 1…63，不会跨 32 位半字，省掉了跨字修正的那一支。

**English**
The 24 64-bit state words live in registers as “6 ymm × 4 rows”, one ymm per row of four words.
With this layout every T-layer (row-shift) offset is a multiple of 4, so **no `vpshufb`/`vpermq` is needed at all** — the shift degenerates into compile-time register renaming, i.e. zero instructions.
All SIGMA constants are within 1…63, so no rotation ever crosses a 32-bit half-word and the cross-word fix-up branch disappears.

---

## LLH-1024 · 128 位字专用核，六路全通道 · 1.1870（win）

**中文**
1024 档的字宽是 `__uint128_t`，与 256/512/768 三档的词表长度、轮常数表都不同，因此没有沿用其它档的核，而是按 128 位字重写：6 个 ymm 覆盖全部通道，吸收与挤出都按整字打包，避免逐字拆装的访存。
该核**不可参数化**复用到其它档（这正是本族四档各自需要独立实现的原因）。

**English**
At 1024 bits the word type is `__uint128_t`, with a different word count and round-constant table from the 256/512/768 tiers, so the kernel was rewritten for 128-bit words rather than parameterised: six ymm registers cover all lanes, and absorb/squeeze pack whole words to avoid per-word load/store traffic.
This kernel is **not** parameterisable across tiers — which is why the four LLH tiers each carry their own implementation.

---

## 交付与验证 / Delivery & verification

- 包内 `build_and_verify.sh` 五步：三方同 flag 编译 → 22 个边界长度逐字节 diff → 黄金向量 → KAT 全量 → 测速。
  Five steps in the shipped `build_and_verify.sh`: build all three implementations with identical flags → byte-exact diff over 22 boundary lengths → golden vectors → full KAT → timing.
- 两档各有 3 个实现 × 4097 条 KAT 向量，全部通过 / 4097 vectors per implementation, 3 implementations per tier, all pass.
- 我方源码只允许 AVX2 及以下指令；打包件已做超标助记符扫描（`rorx/andn/shlx/bzhi/pdep/pext/vaesenc/…` 计数为 0）。
  Our sources stay within AVX2; the shipped objects were audited for out-of-scope mnemonics (all counts zero).
