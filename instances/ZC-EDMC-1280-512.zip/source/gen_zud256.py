"""256 位版 ZuD-1280 置换：状态 = 5 个 u256（每行 4 个 u64 lane）。

为什么这样摆：`A[4y+x]` 的行 y 正好是 4 个连续 lane = 一个 ymm。
于是三个步骤都变成整向量运算，一条 shuffle 都不需要（chi 的五行本来就按列对齐）：

    chi : A[y] = b_y ^ (~b_{y+1} & b_{y+2})            → 5 组 andn+xor
    rho : lane 轮转（permq）+ 每 lane 同量 rotl（vpsllq/vpsrlq/vpor）
    theta: p = 五行异或；e = rotl(rotl_lane(p,1),5) ^ rotl(rotl_lane(p,1),14)

12 轮直接展开（每轮的轮常量是 u256 立即数，避免 repeat 绑定常量的麻烦）。
输出 .jir，然后用 `ir_text.to_jasmin` → jasminc 生成汇编。
"""
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, WORK)

import ir_text as I  # noqa: E402

RC = [0x58, 0x38, 0x3C0, 0xD0, 0x120, 0x14, 0x60, 0x2C, 0x380, 0xF0, 0x1A0, 0x12]

# permq 立即数：每个 lane 占 2 位，位段 = 源 lane 号
PERM = {
    0x93: [3, 0, 1, 2],   # 行1：A[4+j] 取旧的 a1,(j+3)%4
    0x39: [1, 2, 3, 0],   # 行2
    0x4E: [2, 3, 0, 1],   # 行4
}
ROW_ROT = {1: (0x93, 5), 2: (0x39, 24), 3: (None, 1), 4: (0x4E, 3)}


def u256_const(v: int) -> str:
    return "0x%064x" % v


def emit(out_path: str, rcs=None, entry: str = "zud_permute12") -> str:
    """rcs=None 时生成 12 轮全置换（`zud_permute12`）；给一段 RC 切片时生成
    那几轮（`zud_permute6` 用 RC[6:12]，即官方 `Permute_6rounds` 的 rc6..rc1）。

    为什么要单独生成 6 轮：官方 1280 的 `Permute_6rounds` 是 rc6..rc1 六轮，
    EDMC 每个 block 调它两次。此前 `zud_api.c` 的 6rounds 直接调 6 个**标量 C**
    `zud_round_*`，导致 EDMC-1280 整块走标量路径（反汇编 `Permute_6rounds`
    只有 17 行、零向量指令），`ours/opt` 实测 1.18–1.24。1536 没有这个问题，
    因为它的 `Permute_6rounds` 调的是 jasmin 生成的 `zud1536_round`。
    """
    rcs = list(RC if rcs is None else rcs)
    L = []
    for i, rc in enumerate(rcs):
        L.append("const RC%d:u256 = %s" % (i, u256_const(rc)))

    L.append("entry %s(p: u64)" % entry)
    for y in range(5):
        L.append("  R%d:u256 = ld(p + %d)" % (y, 32 * y))

    def rot(v, k, tag):
        """rotl by k on each u64 lane。"""
        a = "%s_a" % tag
        b = "%s_b" % tag
        L.append("  %s = shl(%s, %d)" % (a, v, k))
        L.append("  %s = shr(%s, %d)" % (b, v, 64 - k))
        L.append("  %s = or(%s, %s)" % (tag, a, b))
        return tag

    def rho(src, tag):
        outv = {}
        outv[0] = src[0]
        for row in (1, 2, 3, 4):
            perm, k = ROW_ROT[row]
            v = src[row]
            if perm is not None:
                t = "%s_p%d" % (tag, row)
                L.append("  %s = permq(%s, %#x)" % (t, v, perm))
                v = t
            outv[row] = rot(v, k, "%s_r%d" % (tag, row))
        return outv

    cur = {y: "R%d" % y for y in range(5)}
    for r in range(len(rcs)):
        tag = "t%d" % r
        # iota
        L.append("  %s_i = xor(%s, RC%d)" % (tag, cur[0], r))
        s = {0: "%s_i" % tag}
        for y in range(1, 5):
            s[y] = cur[y]
        # chi
        c = {}
        for y in range(5):
            c[y] = "%s_c%d" % (tag, y)
            L.append("  %s = xor(%s, andn(%s, %s))"
                     % (c[y], s[y], s[(y + 2) % 5], s[(y + 1) % 5]))
        # rho
        r1 = rho(c, tag + "A")
        # theta
        p = "%s_p" % tag
        L.append("  %s = xor(xor(xor(xor(%s, %s), %s), %s), %s)"
                 % (p, r1[0], r1[1], r1[2], r1[3], r1[4]))
        q = "%s_q" % tag
        L.append("  %s = permq(%s, 0x93)" % (q, p))
        e5 = rot(q, 5, tag + "e5")
        e14 = rot(q, 14, tag + "e14")
        e = "%s_e" % tag
        L.append("  %s = xor(%s, %s)" % (e, e5, e14))
        u = {}
        for y in range(5):
            u[y] = "%s_u%d" % (tag, y)
            L.append("  %s = xor(%s, %s)" % (u[y], r1[y], e))
        # rho 第二次
        r2 = rho(u, tag + "B")
        cur = r2

    for y in range(5):
        L.append("  R%d = %s" % (y, cur[y]))
    for y in range(5):
        L.append("  st(p + %d, R%d)" % (32 * y, y))
    text = "\n".join(L) + "\n"
    io.open(out_path, "w", encoding="utf-8", newline="\n").write(text)
    return text


def build_one(jir_path, jazz_path, rcs, entry):
    text = emit(jir_path, rcs=rcs, entry=entry)
    print("写出 %s（%d 行）" % (jir_path, len(text.splitlines())))
    js, info = I.to_jasmin(text, nregs=16)
    io.open(jazz_path, "w", encoding="utf-8", newline="\n").write(js)
    print("  jazz %d 行；IR %d 条、峰值 %d/%d、溢出 %d"
          % (len(js.splitlines()), info["ir_instr"], info["peak"],
             info.get("nregs", 16), info["spill"]))
    return info


def main() -> int:
    build_one(os.path.join(HERE, "zud1280_v256.jir"),
              os.path.join(HERE, "zud1280_v256.jazz"),
              RC, "zud_permute12")
    # 6 轮版：官方 Permute_6rounds 是 rc6..rc1，即 RC[6:12]。EDMC 靠它。
    build_one(os.path.join(HERE, "zud1280_v256_r6.jir"),
              os.path.join(HERE, "zud1280_v256_r6.jazz"),
              RC[6:12], "zud_permute6")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
