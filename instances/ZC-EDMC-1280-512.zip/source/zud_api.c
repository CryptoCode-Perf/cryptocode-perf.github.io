/* ZuD1280_avx2_* 外壳：吸收/挤出照官方 plain 实现的语义抄，只有置换换成我们
 * 自己从 JIR 生成的 C（`zud_gen.c`）。这样比较的是"核心置换"，不是"外围结构"。
 */
#include <stdint.h>
#include <string.h>
#include <immintrin.h>
#include "ZuD1280-AVX2.h"

void zud_permute12(uint64_t *p);
void zud_permute6(uint64_t *p);
void zud_round_12(uint64_t *p);
void zud_round_11(uint64_t *p);
void zud_round_10(uint64_t *p);
void zud_round_9(uint64_t *p);
void zud_round_8(uint64_t *p);
void zud_round_7(uint64_t *p);
void zud_round_6(uint64_t *p);
void zud_round_5(uint64_t *p);
void zud_round_4(uint64_t *p);
void zud_round_3(uint64_t *p);
void zud_round_2(uint64_t *p);
void zud_round_1(uint64_t *p);

void ZuD1280_avx2_Initialize(ZuD1280_avx2_state *s) { memset(s, 0, sizeof(*s)); }

void ZuD1280_avx2_AddBytes(ZuD1280_avx2_state *s, const uint8_t *data,
                           unsigned int offset, unsigned int length)
{
    /* 32 字节 ymm 异或。判据：`zc1536_attrib/H2_TIMINGS.md` —— 把 1536 外壳换回官方
     * `.S` 的逐字节语义后退 4.8–10.9 个百分点（与 rate 字节数成正比），显式 AVX2 比
     * 「8 字节成组」再快 0.5–0.9 个百分点（三个位宽一致）。1280 侧同一函数同一改法。 */
    uint8_t *dst = ((uint8_t *)s) + offset;
    unsigned int i = 0;

    for (; i + 32u <= length; i += 32u) {
        __m256i d = _mm256_loadu_si256((const __m256i *)(const void *)(data + i));
        __m256i v = _mm256_loadu_si256((const __m256i *)(const void *)(dst + i));
        _mm256_storeu_si256((__m256i *)(void *)(dst + i), _mm256_xor_si256(v, d));
    }
    for (; i + 8u <= length; i += 8u) {
        uint64_t cur, lane;
        memcpy(&cur, dst + i, 8);
        memcpy(&lane, data + i, 8);
        cur ^= lane;
        memcpy(dst + i, &cur, 8);
    }
    for (; i < length; i++)
        dst[i] ^= data[i];
}

void ZuD1280_avx2_OverwriteBytes(ZuD1280_avx2_state *s, const uint8_t *data,
                                 unsigned int offset, unsigned int length)
{ memcpy(((uint8_t *)s) + offset, data, length); }

void ZuD1280_avx2_OverwriteWithZeroes(ZuD1280_avx2_state *s, unsigned int byteCount)
{ memset(s, 0, byteCount); }

void ZuD1280_avx2_ExtractBytes(const ZuD1280_avx2_state *s, uint8_t *data,
                               unsigned int offset, unsigned int length)
{ memcpy(data, ((const uint8_t *)s) + offset, length); }

void ZuD1280_avx2_ExtractAndAddBytes(const ZuD1280_avx2_state *s, const uint8_t *input,
                                     uint8_t *output, unsigned int offset, unsigned int length)
{
    for (unsigned int i = 0; i < length; i++)
        output[i] = input[i] ^ ((const uint8_t *)s)[offset + i];
}

void ZuD1280_avx2_Permute_12rounds(ZuD1280_avx2_state *s) { zud_permute12(s->A); }

void ZuD1280_avx2_Permute_6rounds(ZuD1280_avx2_state *s)
{
    /* 官方 plain 的 6rounds 是 rc6..rc1 各一轮（不是一轮），照抄。
     * 走 `zud_permute6`（一次调用跑完六轮，状态全程在寄存器里）。此前是六个
     * 独立的 `zud_round_*` 调用，每次都要把 20 个 lane 写回内存再读回来；在
     * 256 位构建里那六个函数还是**标量 C**，EDMC 每块调两次 ⇒ 整块走标量路径。
     */
    zud_permute6(s->A);
}

void ZuD1280_avx2_Permute_Nrounds(ZuD1280_avx2_state *s, unsigned int nr)
{
    if (nr > 12) nr = 12;
    for (unsigned int i = 12 - nr; i < 12; i++) {
        switch (i) {
        case 0: zud_round_12(s->A); break;
        case 1: zud_round_11(s->A); break;
        case 2: zud_round_10(s->A); break;
        case 3: zud_round_9(s->A); break;
        case 4: zud_round_8(s->A); break;
        case 5: zud_round_7(s->A); break;
        case 6: zud_round_6(s->A); break;
        case 7: zud_round_5(s->A); break;
        case 8: zud_round_4(s->A); break;
        case 9: zud_round_3(s->A); break;
        case 10: zud_round_2(s->A); break;
        default: zud_round_1(s->A); break;
        }
    }
}
