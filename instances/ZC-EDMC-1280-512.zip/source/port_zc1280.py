"""ZC 家族 **1280** 移植：把已交付的 ZC-DM-1280 核心（`zc/out/ours_v256_1280_*.so` 里的
`zud_permute12` / `zud_round_1..12`）接到 hash-31 ZC-DMC 与 hash-32 ZC-EDMC 的**官方胶水**上。

依据（`zc1280_port_cost.py` 实测，全部为「是」）：
  * hash-31/32 的 `lib/low/ZuD-1280/` 与 hash-30 **逐字节相同**；
  * 每个家族的 1280 三实例胶水**三份逐字节相同**；
  * 1280 胶水只引用 6 个符号（`ZuD1280_avx2_{Initialize,AddBytes,ExtractBytes,
    Permute_12rounds,Permute_6rounds,state}`），除 `_state`（typedef）外全部由
    `zc/zud_api.c` 导出。

⇒ 移植 = **换胶水后重新链接**，复用 `zc/out/{zud_api.c.o, zud_gen_rounds.c.o, zud_v.o}`，
核心与 API 零改动、零重编。

本脚本只做构建 + 三道门（置换 / KAT / 与官方 opt 全长度摘要对拍），**不测时间**。

用法：python3 port_zc1280.py [--only hash-31]
"""
import ctypes
import io
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import port_zc_family as P  # noqa: E402  复用 sh/sha256/kat_gate/delivery_compare/find_opt

L0 = P.L0
SRC = P.SRC
ZC = os.path.join(L0, "zc")      # ⚠ 1280 的核心在 `zc/`，不是 `zc1536/`（P.ZC 指的是后者）
OUT = os.path.join(HERE, "out")
LOGS = os.path.join(HERE, "logs")
OPT_FLAGS = P.OPT_FLAGS

FAMILIES = {"hash-30": "ZC-DM", "hash-31": "ZC-DMC", "hash-32": "ZC-EDMC"}
CAPS = ("512", "768", "1024")
WA = 20          # 1280 位 = 20 个 u64


def lib_1280(cid):
    return os.path.join(SRC, cid, FAMILIES[cid], "Implementations",
                        "lib", "low", "ZuD-1280")


def inc_1280(cid):
    base = os.path.join(SRC, cid, FAMILIES[cid], "Implementations")
    lib = lib_1280(cid)
    return [lib, os.path.join(lib, "plain"), os.path.join(lib, "AVX2"),
            os.path.join(base, "lib", "common")]


def glue_1280(cid, cap):
    d = os.path.join(SRC, cid, FAMILIES[cid], "Implementations", "Implementations",
                     "Optimized_Implementation",
                     "%s-1280-%s" % (FAMILIES[cid], cap))
    return os.path.join(d, "CryptHash_AlgorithmInstance.c")


def core_objs_1280():
    """复用 zc 已交付的 1280 目标文件（不重编，保证与已测交付件同源）。

    必须包含 `zud_v6.o`（6 轮 jasmin 置换 `zud_permute6`）：`zud_api.c` 的
    `Permute_6rounds` 走它，缺了会在 dlopen 时报 `undefined symbol: zud_permute6`。
    """
    objs = []
    for name in ("zud_api.c.o", "zud_gen_rounds.c.o", "zud_v.o", "zud_v6.o"):
        o = os.path.join(ZC, "out", name)
        if not os.path.exists(o):
            return None, "%s 不存在，请先跑 zc/build_ours256.py" % o
        objs.append(o)
    return objs, None


def build_family(cid, objs):
    dname = FAMILIES[cid]
    outdir = os.path.join(OUT, dname)
    os.makedirs(outdir, exist_ok=True)
    incs = inc_1280(cid)
    glue_src = glue_1280(cid, "512")      # 三实例胶水逐字节相同，任取一份
    if not os.path.exists(glue_src):
        return None, "缺胶水 %s" % glue_src
    glue_o = os.path.join(outdir, "glue_1280.o")
    cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", glue_o, "-I",
                                 os.path.dirname(glue_src)]
    for d in incs:
        cmd += ["-I", d]
    cmd.append(glue_src)
    rc, log = P.sh(cmd, "%s_glue1280_cc.log" % dname)
    if rc != 0:
        return None, "胶水编译失败：\n" + log[-2000:]
    so = os.path.join(outdir, "ours_%s_1280.so" % dname.lower())
    rc, log = P.sh(["gcc", "-shared", "-o", so, glue_o] + objs,
                   "%s_link1280.log" % dname)
    if rc != 0:
        return None, "链接失败：\n" + log[-2000:]
    print("  ✓ %s 1280：%s（%d 字节，sha256=%s）"
          % (dname, os.path.basename(so), os.path.getsize(so), P.sha256(so)[:16]))
    return so, None


def plain_so_1280(cid):
    dname = FAMILIES[cid]
    outdir = os.path.join(OUT, dname)
    os.makedirs(outdir, exist_ok=True)
    so = os.path.join(outdir, "plain_1280_%s.so" % dname.replace("-", "_").lower())
    plain_c = os.path.join(lib_1280(cid), "plain", "ZuD1280-plain.c")
    cmd = ["gcc", "-O2", "-std=c99", "-fPIC", "-shared", "-o", so]
    for d in inc_1280(cid):
        cmd += ["-I", d]
    cmd.append(plain_c)
    rc, log = P.sh(cmd, "plain1280_%s.log" % dname.replace("-", "_").lower())
    if rc != 0:
        return None, "plain 裁判构建失败：\n" + log[-2000:]
    return so, None


def perm_gate_1280(so, pso, trials=48):
    ours = ctypes.CDLL(so)
    plain = ctypes.CDLL(pso)
    PTR = ctypes.POINTER(ctypes.c_uint64)
    ours.ZuD1280_avx2_Permute_12rounds.argtypes = [PTR]
    ours.ZuD1280_avx2_Permute_6rounds.argtypes = [PTR]
    plain.ZuD1280_plain_Permute_12rounds.argtypes = [PTR]
    plain.ZuD1280_plain_Permute_6rounds.argtypes = [PTR]
    rnd = random.Random(20261106)
    res = {}
    for tag, f_o, f_p in (
            ("p12", ours.ZuD1280_avx2_Permute_12rounds, plain.ZuD1280_plain_Permute_12rounds),
            ("p6", ours.ZuD1280_avx2_Permute_6rounds, plain.ZuD1280_plain_Permute_6rounds)):
        bad = 0
        first = None
        cases = [[0] * WA, [0xFFFFFFFFFFFFFFFF] * WA] + \
                [[rnd.getrandbits(64) for _ in range(WA)] for _ in range(trials)]
        for t, st in enumerate(cases):
            a = (ctypes.c_uint64 * WA)(*st)
            b = (ctypes.c_uint64 * WA)(*st)
            f_o(a)
            f_p(b)
            if list(a) != list(b):
                bad += 1
                if first is None:
                    first = (t, [(i, hex(a[i]), hex(b[i]))
                                 for i in range(WA) if a[i] != b[i]][:3])
        res[tag] = {"ok": bad == 0, "n": len(cases), "bad": bad, "first": first}
        print("  ① %s 置换：%d/%d 一致%s"
              % (tag, len(cases) - bad, len(cases),
                 "" if not bad else "，首个 %s" % (first,)))
    return res["p12"]["ok"] and res["p6"]["ok"], res


def main():
    only = None
    if "--only" in sys.argv:
        only = sys.argv[sys.argv.index("--only") + 1]
    t0 = time.time()
    os.makedirs(OUT, exist_ok=True)
    objs, err = core_objs_1280()
    if err:
        print("✗ " + err)
        return 1
    print("复用核心目标文件：%s" % ", ".join(os.path.basename(o) for o in objs))

    results = {}
    all_ok = True
    for cid in ("hash-31", "hash-32"):
        if only and cid != only:
            continue
        dname = FAMILIES[cid]
        print("\n[%s %s 1280]" % (cid, dname))
        so, err = build_family(cid, objs)
        if err:
            print("✗ " + err)
            all_ok = False
            continue
        pso, err = plain_so_1280(cid)
        if err:
            print("✗ " + err)
            all_ok = False
            continue
        ok1, r1 = perm_gate_1280(so, pso)
        fam = {}
        ok_all = ok1
        for cap in CAPS:
            inst = "%s-1280-%s" % (dname, cap)
            ok2, r2 = P.kat_gate(so, cid, inst)
            opt_so = P.find_opt(cid, inst)
            if opt_so:
                ok3, r3 = P.delivery_compare(so, opt_so, int(cap))
            else:
                ok3, r3 = False, {"error": "找不到官方 opt .so"}
                print("  ③ 跳过：找不到 %s 的官方 opt" % inst)
            fam[inst] = {"digest_bits": int(cap), "gate_kat": r2,
                         "gate_delivery": r3,
                         "opt_so": os.path.relpath(opt_so, L0) if opt_so else None,
                         "opt_so_sha256": P.sha256(opt_so) if opt_so else None,
                         "ok": bool(ok2 and ok3)}
            ok_all = ok_all and ok2 and ok3
        results[dname] = {"so": os.path.relpath(so, HERE), "so_sha256": P.sha256(so),
                          "so_bytes": os.path.getsize(so),
                          "gate_perm": r1, "instances": fam, "ok": ok_all}
        all_ok = all_ok and ok_all

    results["_timed"] = False
    results["_elapsed_s"] = round(time.time() - t0, 1)
    results["_all_gates_ok"] = all_ok
    io.open(os.path.join(HERE, "GATES_1280.json"), "w", encoding="utf-8",
            newline="\n").write(json.dumps(results, indent=2, ensure_ascii=False) + "\n")
    print("\n%s 1280 三道门：%s（未计时）"
          % ("✓" if all_ok else "✗", "全绿" if all_ok else "有红"))
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
