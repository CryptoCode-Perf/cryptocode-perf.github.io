# ZC-EDMC — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| ZC-EDMC-1280-512 | `ZC-EDMC-1280-512.so` | 34384 B | `2134d06d8c8fb07eace78e2f553d1766f65f16fad060e961cb9265794fe1bfee` |
| ZC-EDMC-1280-768 | `ZC-EDMC-1280-768.so` | 34384 B | `2134d06d8c8fb07eace78e2f553d1766f65f16fad060e961cb9265794fe1bfee` |
| ZC-EDMC-1536-1024 | `ZC-EDMC-1536-1024.so` | 21944 B | `fbfc21921e896908dafcaa3fb6db160e9b65a3a0733290e401d894ebc61ad93c` |
| ZC-EDMC-1536-512 | `ZC-EDMC-1536-512.so` | 21944 B | `fbfc21921e896908dafcaa3fb6db160e9b65a3a0733290e401d894ebc61ad93c` |
| ZC-EDMC-1536-768 | `ZC-EDMC-1536-768.so` | 21944 B | `fbfc21921e896908dafcaa3fb6db160e9b65a3a0733290e401d894ebc61ad93c` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| ZC-EDMC-1280-512 | 512 | 4.2598 | 3.4485 | 3.2774 | 1.0522 | 1.1464 |
| ZC-EDMC-1280-768 | 768 | 7.5479 | 6.0603 | 5.7814 | 1.0483 | 1.0727 |
| ZC-EDMC-1536-1024 | 1024 | 16.8457 | 10.7509 | 9.239 | 1.1636 | 1.1859 |
| ZC-EDMC-1536-512 | 512 | 6.9541 | 4.6464 | 3.7664 | 1.2336 | 1.3781 |
| ZC-EDMC-1536-768 | 768 | 11.9346 | 7.8233 | 6.6603 | 1.1746 | 1.2403 |

## 优化方法（逐实例原文，来自交付清单）

### ZC-EDMC-1280-512
**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息长度无关 ⇒ 短消息里它占整次调用的相当比例，而 cpB 表的几何均值含 S1/S2，收益直接进总 gm。改法（`zc/try_1280_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.028875（512 B 处 1.0422、1024 B 1.0508、4096 B 1.0215、65536 B 1.0016）。ZC-EDMC 胶水每块要做完整 feedforward（容量全回），驱动层占比原本最高 ⇒ 消掉同一段 pad 空转后收益也最大。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-EDMC-1280-768
**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息长度无关 ⇒ 短消息里它占整次调用的相当比例，而 cpB 表的几何均值含 S1/S2，收益直接进总 gm。改法（`zc/try_1280_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.031365（512 B 处 1.0787、1024 B 1.0379、4096 B 1.0121、65536 B 0.9986）。ZC-EDMC 胶水每块要做完整 feedforward（容量全回），驱动层占比原本最高 ⇒ 消掉同一段 pad 空转后收益也最大。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-EDMC-1536-1024
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.022613（512 B 处 1.0553、1024 B 1.0286、4096 B 1.0082、65536 B 0.9994）。本档 rate = 56 B，pad 空转上限 447 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-EDMC 胶水每块要做完整 feedforward（容量全回），驱动层占比原本最高 ⇒ 消掉同一段 pad 空转后收益也最大。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-EDMC-1536-512
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.082380（512 B 处 1.2172、1024 B 1.0838、4096 B 1.0388、65536 B 1.0016）。本档 rate = 120 B，pad 空转上限 959 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-EDMC 胶水每块要做完整 feedforward（容量全回），驱动层占比原本最高 ⇒ 消掉同一段 pad 空转后收益也最大。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-EDMC-1536-768
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.020930（512 B 处 1.0351、1024 B 1.0341、4096 B 1.0100、65536 B 1.0049）。本档 rate = 88 B，pad 空转上限 703 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-EDMC 胶水每块要做完整 feedforward（容量全回），驱动层占比原本最高 ⇒ 消掉同一段 pad 空转后收益也最大。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。
