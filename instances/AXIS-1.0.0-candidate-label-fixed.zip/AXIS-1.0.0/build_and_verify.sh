#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for bits in 512 768 1024; do
 for kind in Reference Optimized; do
  d="${kind}_Implementation/AXIS-$bits"
  if [ "$kind" = Reference ]; then flags=-O2; else flags="-O3 -mavx2"; fi
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/axis_core.c" "$d/CryptHash_AlgorithmInstance.c" -o "build/$kind-$bits.so"
 done
 d="CryptoCode_Implementation/AXIS-$bits"
 if [ "$bits" = 1024 ]; then source=axis1024.c; else source=axis_tiers.c; fi
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$d" "$d/$source" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 "test/kat_$bits.py" "build/$kind-$bits.so" 100000 0 "kat/AXIS-$bits.txt"; done
done

python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 768 1024; do build/guard_check "build/CryptoCode-$bits.so" "$bits"; done
