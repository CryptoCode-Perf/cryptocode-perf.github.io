# AXIS candidate package

Instances: AXIS-512, AXIS-768 and AXIS-1024. On x86-64 Linux with GCC,
Python 3 and AVX2, run `bash build_and_verify.sh`. It rebuilds the official
reference, official optimized and CryptoCode implementations, checks the full
KAT, compares selected long and boundary inputs with the reference, and checks
input/output guard pages. Results and libraries are generated in build/.

Candidate only: performance comparison, release review and upstream
redistribution permissions remain pending. Tests do not prove security.
