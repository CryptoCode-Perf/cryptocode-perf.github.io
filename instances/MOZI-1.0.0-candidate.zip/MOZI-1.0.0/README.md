# MOZI candidate package

Instances: MOZI-384, MOZI-512, MOZI-768 and MOZI-1024. XOF instances are
not included. On x86-64 Linux with GCC, G++, Python 3 and AVX2, run
`bash build_and_verify.sh`. This rebuilds three implementations per instance,
checks all 4097 known-answer vectors each, compares deterministic long and
boundary inputs, and tests selected input/output guard-page boundaries.
`CryptHash` takes message and digest lengths in bits.

CryptoCode implementations use recovered C wrappers and generated assembly;
the associated Jasmin source is provided, but assembly regeneration is not
part of this build. Optimized C++ uses the AVX2 build. Candidate only: XOF
coverage, controlled fastest-implementation comparison, source and license
review, redistribution permission and final release review remain pending.
These tests do not prove security.
