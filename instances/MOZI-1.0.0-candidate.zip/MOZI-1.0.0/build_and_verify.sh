#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"; mkdir -p build
for bits in 384 512 768 1024; do
 ref="Reference_Implementation/MOZI-$bits"; opt="Optimized_Implementation/MOZI-$bits"; own="CryptoCode_Implementation/MOZI-$bits"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" -o "build/Reference-$bits.so"
 g++ -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" -I"$ref" "$opt/CryptHash_AlgorithmInstance_fast.cpp" -o "build/Optimized-$bits.so"
 if [ "$bits" = 384 ]; then gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs "$own/ref_agent.c" "$own/mozi_v256b.s" -o "build/CryptoCode-$bits.so"; else gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$ref" "$own/shell.c" "$own/permutation.s" -o "build/CryptoCode-$bits.so"; fi
 for kind in Reference Optimized CryptoCode; do python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/MOZI-$bits.txt"; done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 384 512 768 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits"; done; done
