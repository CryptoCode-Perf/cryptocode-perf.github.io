#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_sbox4.py --- S 盒「四张预移位表」等价改写（768 标量岛）。

动机（形态证据，`neulaser2/scratch/s768.txt`）：
  `nl_rnd_4_0` 1001 条里有 `movzbl 112 / shl 64 / or 48`。
  其中 `shl` 有 24 条来自 `nl_sw` 的「查表结果左移 24/16/8 位」——
  8 次调用 × 3 条移位，纯粹是为了把 4 个字节拼回一个字。

手法：把 `NL_SBOX[256]`（uint8）换成四张 uint32 表
  NL_SB0[b] = SBOX[b] << 24
  NL_SB1[b] = SBOX[b] << 16
  NL_SB2[b] = SBOX[b] << 8
  NL_SB3[b] = SBOX[b]
`nl_sw` 变成 4 次 32 位查表 + 3 条 `or`，**移位全部折进表里**（表 4 KB，L1 装得下）。
语义逐位等价，KAT 必须全过。

用法：python3 neulaser2/gen/gen_sbox4.py --mu 4 [--base sisl]
产物：gen/out/nl_sbox4_<base>_<mu>.c
"""
import argparse
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")

TAB_DEF = re.compile(r"static const uint8_t NL_SBOX\[256\] = \{\n(?:.*?\n)*?\};\n", re.M)
SW_DEF = re.compile(r"static inline uint32_t nl_sw\(uint32_t x\)\n\{\n(?:.*?\n)*?\}\n", re.M)

NEW_SW = """/* 四张预移位表：把「查表后左移 24/16/8」折进表内容（表 4 KB）。 */
static inline uint32_t nl_sw(uint32_t x)
{
    return NL_SB0[(x >> 24) & 0xFFU]
         | NL_SB1[(x >> 16) & 0xFFU]
         | NL_SB2[(x >>  8) & 0xFFU]
         | NL_SB3[ x        & 0xFFU];
}
"""


def parse_values(block):
    nums = re.findall(r"0x([0-9A-Fa-f]{2})", block)
    if len(nums) != 256:
        raise SystemExit("FATAL: 解析到 %d 个表项（应为 256）" % len(nums))
    return [int(h, 16) for h in nums]


def emit_table(name, vals, shift):
    lines = ["static const uint32_t %s[256] = {" % name]
    for i in range(0, 256, 8):
        chunk = ", ".join("0x%08XU" % ((v << shift) & 0xFFFFFFFF) for v in vals[i:i + 8])
        lines.append("    " + chunk + ",")
    lines.append("};")
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mu", type=int, required=True)
    ap.add_argument("--base", default="sisl", choices=["sisl", "noshell"])
    a = ap.parse_args()

    src = os.path.join(OUT, "nl_%s_%d.c" % (a.base, a.mu))
    if not os.path.exists(src):
        raise SystemExit("缺 %s" % src)
    txt = open(src, encoding="utf-8").read()

    m1 = TAB_DEF.search(txt)
    m2 = SW_DEF.search(txt)
    if not m1 or not m2:
        raise SystemExit("FATAL: 找不到 NL_SBOX 定义 (%s) 或 nl_sw 定义 (%s)"
                         % (bool(m1), bool(m2)))

    vals = parse_values(m1.group(0))
    tables = "".join(emit_table("NL_SB%d" % k, vals, sh)
                     for k, sh in enumerate((24, 16, 8, 0)))

    # 先替换表定义（块较长，先做），再替换 nl_sw（用 lambda 避免反斜杠转义问题）。
    txt = txt[:m1.start()] + tables + txt[m1.end():]
    m2 = SW_DEF.search(txt)
    if not m2:
        raise SystemExit("FATAL: 换表后找不到 nl_sw")
    txt = txt[:m2.start()] + NEW_SW + txt[m2.end():]

    # 断言
    if "static const uint8_t NL_SBOX[256]" in txt:
        raise SystemExit("FATAL: 旧 uint8 表还在")
    for k in range(4):
        if "NL_SB%d[256]" % k not in txt:
            raise SystemExit("FATAL: 缺 NL_SB%d" % k)
    if txt.count("NL_SB0[") < 2:
        raise SystemExit("FATAL: nl_sw 没用到新表")
    if txt.count("static void nl_rnd_") < 1:
        raise SystemExit("FATAL: 轮体不见了")

    head = "/* SBOX4-EXPERIMENT: 四张预移位表，等价改写，KAT 必须全过。gen/gen_sbox4.py */\n"
    dst = os.path.join(OUT, "nl_sbox4%s_%d.c"
                       % ("" if a.base == "noshell" else "_" + a.base, a.mu))
    with open(dst, "w", encoding="utf-8", newline="\n") as f:
        f.write(head + txt)
    print("四表改写 -> %s (%d B)" % (os.path.basename(dst), len(head + txt)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
