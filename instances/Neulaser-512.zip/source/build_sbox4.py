#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_sbox4.py --- 构建「四张预移位表」件（768 标量岛的 S 盒改写）。

源文件 `gen/out/nl_sbox4_sisl_<mu>.c` 由 `gen/gen_sbox4.py` 等价改写而来：
`NL_SBOX[256]`(uint8) → `NL_SB0..NL_SB3[256]`(uint32)，`nl_sw` 里 3 条移位折进表。
该文件里已没有 `NL_SBOX` 记号 ⇒ 与 `build_sisl.py` 的改名步骤无关（计数 0 合法）。

用法：python3 neulaser2/build_sbox4.py --mu 4
"""
from __future__ import annotations

import hashlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "gen", "out")
OUT = os.path.join(HERE, "out")

sys.path.insert(0, HERE)
import build_noshell as B  # noqa: E402

MU = 4
D = 768


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    global MU, D
    if "--mu" in sys.argv:
        MU = int(sys.argv[sys.argv.index("--mu") + 1])
        D = {3: 512, 4: 768, 5: 1024}[MU]

    src = os.path.join(GEN, "nl_sbox4_sisl_%d.c" % MU)
    if not os.path.exists(src):
        raise SystemExit("缺 %s（先跑 gen/gen_sbox4.py --mu %d --base sisl）" % (src, MU))

    txt = open(src, encoding="utf-8").read()
    if txt.count("NL_SBOX") != 0:
        raise SystemExit("NL_SBOX 出现 %d 次（四表版应为 0）" % txt.count("NL_SBOX"))
    for k in range(4):
        if "NL_SB%d[256]" % k not in txt:
            raise SystemExit("缺 NL_SB%d 表" % k)

    ren = "nl_sbox4_sisl_%d_ours.c" % MU
    with open(os.path.join(GEN, ren), "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)
    print("TU → %s (%d B)" % (ren, len(txt)))

    out, d, span, srcpath, sp = B.build(MU, tag="sbox4", counter=False,
                                        rname="nl_sbox4_sisl_%d_ours.c")
    print("产物 =", os.path.relpath(out, HERE))
    print("  大小 =", os.path.getsize(out), "B")
    print("  sha256 =", sha256(out))
    lg = os.path.join(OUT, "log_shell_%d_sbox4.txt" % d)
    if os.path.exists(lg):
        lt = open(lg, encoding="utf-8", errors="replace").read()
        print("  shell 编译：error= %d 行、warning= %d 行"
              % (lt.count("error:"), lt.count("warning:")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
