#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""try_vstore_tier.py --- Neulaser-512/1024 档「写回改 volatile 存储」单因子实验。

背景（768 档已兑现）：
  `try_768_vstore.py` 在 Neulaser-768 上把轮体尾部 32 条 `S[k] = x;`
  改成对 `volatile uint32_t *` 的存，阻止 GCC 的 SLP store-merging 把它们
  组装成 8 个 ymm（32 vmovd + 32 vpinsrd + 16 vpunpcklqdq + 8 vinserti128）。
  实测 958 条 / 尾部向量 0 条，稳定复测 1.044945 → 1.116078（+6.81%）。

本脚本是同一因子的参数化版，用于 512（mu=3，144 条写回）与
1024（mu=5，400 条写回）两档。单线程语义完全不变：写回下标互不相同、
顺序无关，volatile 只影响编译器能否合并相邻 store。

用法：python3 try_vstore_tier.py <512|1024> [build|kat|sweep|all]
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))
GENOUT = os.path.join(HERE, "gen", "out")
OUT = os.path.join(HERE, "out")
FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]
SRCDIR = os.path.join(
    L0, "src/hash-21/Neulaser/Implementations and Test_Vectors/API_CryptHash/"
        "Implementations/Optimized_Implementation")

MU = {512: 3, 768: 4, 1024: 5}
# sbox4 + 标量岛 TU 里 `S[k] = x;` 写回语句的条数（实测，按 mu 递增）
# mu=3 → 144、mu=4 → 256、mu=5 → 400；不是 32×mu，别按 32 推。
NWRITE = {3: 144, 4: 256, 5: 400}


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def wsl(inner, log=None):
    r = subprocess.run(["wsl.exe", "-d", "Debian", "bash", "-lc", inner],
                       capture_output=True)
    r.stdout = (r.stdout or b"").decode("utf-8", "replace")
    r.stderr = (r.stderr or b"").decode("utf-8", "replace")
    if log:
        open(log, "w", encoding="utf-8").write(r.stdout + "\n" + r.stderr)
    return r


def wpath(p):
    if p.startswith("/"):
        return p
    return "/mnt/c/" + p.replace("\\", "/").replace(":", "", 1)


def paths(d):
    mu = MU[d]
    return dict(
        mu=mu,
        src=os.path.join(GENOUT, "nl_sbox4_sisl_%d.c" % mu),
        wd=os.path.join(HERE, "opp%d" % d, "vstore"),
        core=os.path.join(GENOUT, "nl_vstore_sisl_%d.c" % mu),
        opp=os.path.join(L0, "build", "hash-21", "neulaser%d" % d, "opt.so"),
        so=os.path.join(OUT, "ours_neulaser2_%d_noshellvstore.so" % d),
        ref=os.path.join(L0, "build", "hash-21", "neulaser%d" % d, "ref.so"),
    )


def transform(d):
    P = paths(d)
    txt = open(P["src"], encoding="utf-8").read()
    pat = re.compile(r"^([ \t]*)S\[(\d+)\] = ([A-Za-z0-9_]+);[ \t]*$", re.M)
    n = len(pat.findall(txt))
    want = NWRITE[P["mu"]]
    if n != want:
        raise SystemExit("写回语句 %d 条（预期 %d，mu=%d）" % (n, want, P["mu"]))
    out = pat.sub(lambda m: "%s((volatile uint32_t *)S)[%s] = %s;" %
                  (m.group(1), m.group(2), m.group(3)), txt)
    if "volatile uint32_t" not in out:
        raise SystemExit("替换失败")
    hdr = "/* 单因子：写回改 volatile 存储，禁 SLP store-merging（mu=%d） */\n" % P["mu"]
    os.makedirs(P["wd"], exist_ok=True)
    dst = os.path.join(P["wd"], "nl_vstore_sisl_%d.c" % P["mu"])
    with open(dst, "w", encoding="utf-8", newline="\n") as f:
        f.write(hdr + out)
    print("替换 %d 条写回 -> %s (%d B)" % (n, os.path.relpath(dst, HERE),
                                     os.path.getsize(dst)))
    return dst


def build(d):
    P = paths(d)
    dst = transform(d)
    # 核心 .c 没有 CryptHash 入口，必须经 build_noshell 注入外壳；
    # 故先把转换结果放进 gen/out/ 供 patch_shell 的 #include 找到。
    with open(P["core"], "w", encoding="utf-8", newline="\n") as f:
        f.write(open(dst, encoding="utf-8").read())
    sys.path.insert(0, HERE)
    import build_noshell as B  # noqa: E402
    so, dd, _span, _src, _sp = B.build(
        P["mu"], tag="vstore", counter=False, rname="nl_vstore_sisl_%d.c")
    print("产物 = %s (%d B)" % (os.path.relpath(so, HERE), os.path.getsize(so)))
    print("  sha256 =", sha256(so))
    return 0


def kat(d):
    P = paths(d)
    sys.path.insert(0, WORK)
    sys.path.insert(0, os.path.join(WORK, "_std"))
    sys.path.insert(0, L0)
    import _kat_full as KF  # noqa: E402
    import kat_gate as KG  # noqa: E402
    recs, used = KG.find_kat("hash-21", "Neulaser-%d" % d)
    n, m, first, err = KF.check_all(P["so"], recs)
    print("KAT %s  n=%d match=%d first_bad=%s err=%s" % (
        os.path.basename(P["so"]), n, m, first, err))
    if m != n or err:
        return 5
    r = wsl("objdump -d '%s'" % wpath(P["so"]))
    FORB = ("rorx", "andn", "shlx", "shrx", "sarx", "bzhi", "pdep", "pext",
            "vaesenc", "vpternlog", "vprol", "vpror", "vplzcnt", "kmov")
    bad = sum(r.stdout.count("\t" + x + " ") + r.stdout.count(" " + x + " ")
              for x in FORB)
    print("forbidden=%d  ymm=%d  zmm=%d" % (
        bad, r.stdout.count("%ymm"), r.stdout.count("%zmm")))
    funcs, cur = {}, None
    for ln in r.stdout.splitlines():
        mm = re.match(r"^([0-9a-f]+) <([^>]+)>:", ln)
        if mm:
            cur = mm.group(2)
            funcs[cur] = []
        elif cur and re.match(r"^\s+[0-9a-f]+:", ln):
            funcs[cur].append(ln)
    fn = "nl_rnd_%d_0" % P["mu"]
    body = funcs.get(fn, [])
    VEC = ("vmovd", "vpinsrd", "vpunpck", "vinserti")
    print("%s total=%d  vec-tail=%d" % (
        fn, len(body), sum(1 for l in body if any(v in l for v in VEC))))
    return 0 if bad == 0 else 6


def sweep(d):
    P = paths(d)
    sys.path.insert(0, WORK)
    sys.path.insert(0, WORK + "/_std")
    import bench_proto as BP  # noqa: E402
    rows = []
    for L in (32, 512, 1024, 4096, 65536):
        res = BP.sweep(P["so"], P["opp"], lengths=[L], rounds=60,
                       cpu=BP.PIN_CPU, bits_a=d, bits_b=d)
        if not res:
            raise SystemExit("sweep 空结果（对手件缺失？%s）" % P["opp"])
        cell = res[0] if isinstance(res, list) else res[L]
        rows.append((L, cell["ratio"]))
        print("  L=%-6d ratio %.5f  iqr %.2f  batch %s" % (
            L, cell["ratio"], cell.get("iqr", 0), cell.get("batch")))
    g = 1.0
    for _, v in rows:
        g *= v
    g **= 1.0 / len(rows)
    print("geomean = %.6f  (>1 我方快)" % g)
    os.makedirs(os.path.join(HERE, "scratch"), exist_ok=True)
    json.dump({"bits": d, "rows": [{"L": L, "ratio": v} for L, v in rows],
               "geomean": g},
              open(os.path.join(HERE, "scratch", "vstore%d.json" % d), "w"),
              ensure_ascii=False, indent=1)
    return 0


def main():
    if len(sys.argv) < 2:
        raise SystemExit("用法：try_vstore_tier.py <512|1024> [build|kat|sweep|all]")
    d = int(sys.argv[1])
    if d not in (512, 1024):
        raise SystemExit("只支持 512 / 1024（768 用 try_768_vstore.py）")
    what = sys.argv[2] if len(sys.argv) > 2 else "all"
    for step, fn in (("build", build), ("kat", kat), ("sweep", sweep)):
        if what in (step, "all"):
            rc = fn(d)
            if rc:
                return rc
    return 0


if __name__ == "__main__":
    sys.exit(main())
