#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_scalar_island.py --- 把 S 盒「向量岛」改成纯标量岛（第 16 条判据的实验）。

## 为什么

`nl_psbox(__m256i x)` 的实现是「存 8 lane 到栈 → 8 次标量 `nl_sw` → 读回」：

    static inline __m256i nl_psbox(__m256i x) {
        uint32_t w[8];
        _mm256_storeu_si256((__m256i*)(void*)w, x);
        for (i = 0; i < 8; i++) w[i] = nl_sw(w[i]);
        return _mm256_loadu_si256((const __m256i*)(const void*)w);
    }

调用点则是「先攒 8 个 u32 到栈数组 → load 成向量 → 调 nl_psbox → store 回栈 → 逐字读回」。
mu=3 时数组只填 6 个（`{ lu0, lv0, lu1, lv1, lu2, lv2, 0u, 0u }`），
**向量往返处理的 2 个 lane 是纯浪费**，而且 GCC 未必能把 store/load 对消掉。

本脚本把调用点整段换成直接对有效字调 `nl_sw`：

    uint32_t zb_A_0[8] = { lu0, lv0, lu1, lv1, lu2, lv2, 0u, 0u };
    _mm256_storeu_si256(..., nl_psbox(_mm256_loadu_si256(...)));
    pl0 = zb_A_0[0]; pr0 = zb_A_0[1];
    ...
  ⇒
    pl0 = nl_sw(lu0); pr0 = nl_sw(lv0);
    ...

**语义完全等价**（`nl_psbox` 对每个 lane 就是 `nl_sw`），只是去掉向量往返。
`nl_psbox` 函数本身保留（可能还有别的引用），GCC 会把它当 static inline 丢弃。

## 纪律

* 只改调用点，不改 `nl_sw` / `nl_psbox` / 轮体算术。
* 三处断言：岛数、每个岛的 lane 数、读回语句数与初始化列表长度一致。
* 产物首行标 `SCALAR-ISLAND-EXPERIMENT`，KAT 必须全过（等价改写，不是消融）。

用法：python3 gen/gen_scalar_island.py --mu 3 [--mu 5]
"""
from __future__ import annotations

import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "out")

INIT_RE = re.compile(
    r'^[ \t]*uint32_t (zb_[A-Za-z0-9_]+)\[8\] = \{(?P<items>[^}]*)\};[ \t]*\n'
    r'^[ \t]*_mm256_storeu_si256\(\(__m256i \*\)\(void \*\)\1,'
    r'[ \t]*\n?[ \t]*nl_psbox\(_mm256_loadu_si256\(\(const __m256i \*\)\(const void \*\)\1\)\)\);[ \t]*\n',
    re.M)

READ_RE = re.compile(r'^[ \t]*((?:\w+ = zb_[A-Za-z0-9_]+\[\d+\];[ \t]*)+)[ \t]*\n', re.M)
ASSIGN_RE = re.compile(r'(\w+) = (zb_[A-Za-z0-9_]+)\[(\d+)\];')


def transform(txt):
    out = []
    pos = 0
    n_islands = 0
    lane_counts = []
    for m in INIT_RE.finditer(txt):
        name = m.group(1)
        items = [s.strip() for s in m.group("items").split(",") if s.strip()]
        # 读回语句紧跟其后（一行可能有多条赋值）
        p = m.end()
        reads = []
        while True:
            r = READ_RE.match(txt, p)
            if not r:
                break
            got = ASSIGN_RE.findall(r.group(1))
            if not got or any(g[1] != name for g in got):
                break
            reads.extend((lhs, int(idx)) for lhs, _zb, idx in got)
            p = r.end()
        if not reads:
            raise SystemExit("FATAL: 岛 %s 后面没有读回语句（模式不匹配）" % name)
        if len(items) != 8:
            raise SystemExit("FATAL: 岛 %s 初始化列表有 %d 项（应为 8）" % (name, len(items)))
        if len(reads) > len(items):
            raise SystemExit("FATAL: 岛 %s 读回 %d 次多于初始化 %d 项" % (name, len(reads), len(items)))
        lines = []
        for lhs, idx in reads:
            lines.append("    %s = nl_sw(%s);" % (lhs, items[idx]))
        out.append(txt[pos:m.start()])
        out.append("\n".join(lines) + "\n")
        pos = p
        n_islands += 1
        lane_counts.append(len(reads))
    out.append(txt[pos:])
    if n_islands == 0:
        raise SystemExit("FATAL: 一个岛都没匹配到（生成器或格式变了）")
    res = "".join(out)
    if "nl_psbox(_mm256_loadu_si256" in res:
        raise SystemExit("FATAL: 仍有未替换的 nl_psbox 调用点")
    return res, n_islands, lane_counts


def main():
    mus = [int(sys.argv[i + 1]) for i, a in enumerate(sys.argv) if a == "--mu"]
    if not mus:
        mus = [3]
    for mu in mus:
        src = os.path.join(GEN, "nl_comb_%d.c" % mu)
        if not os.path.exists(src):
            raise SystemExit("缺 %s（先跑 gen/gen_comb.py --mu %d）" % (src, mu))
        txt = open(src, encoding="utf-8").read()
        res, n, lanes = transform(txt)
        dst = os.path.join(GEN, "nl_sisl_%d.c" % mu)
        header = ("/* SCALAR-ISLAND-EXPERIMENT mu=%d：S 盒岛由「向量往返」改为直接 nl_sw。\n"
                  "   等价改写（非消融），KAT 必须全过。生成器 gen/gen_scalar_island.py */\n" % mu)
        with open(dst, "w", encoding="utf-8", newline="\n") as f:
            f.write(header + res)
        print("mu=%d: %d 个岛，每个岛读回 %s 个字 -> %s（%d B）"
              % (mu, n, lanes, os.path.basename(dst), os.path.getsize(dst)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
