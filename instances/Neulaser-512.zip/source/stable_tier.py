#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""stable_tier.py --- Neulaser 512/1024 档：多轮重复比较 base(sbox4) 与 vstore。

判据：`ratio = opt_ticks / ours_ticks`（>1 我方快）。
两件都在**同一进程内**交替测（先 base 后 vstore，每轮都重测），
这样频率状态与对手二进制都固定，差异只能来自我方件。

`WIN_T = 1.05`：gm >= 1.05 → win；<= 1/1.05 → loss；否则 tie。
跨轮极差 > 1% 判 unstable，不当结论。

用法：python3 stable_tier.py <512|1024> [轮数]   （默认 5）
"""
from __future__ import annotations

import json
import os
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))
import bench_proto as BP  # noqa: E402

LENGTHS = [512, 1024, 4096, 65536]
WIN_T = 1.05


def gm(d):
    p = 1.0
    for v in d.values():
        p *= v
    return p ** (1.0 / len(d))


def verdict(g):
    if g >= WIN_T:
        return "win"
    if g <= 1.0 / WIN_T:
        return "loss"
    return "tie"


def main():
    if len(sys.argv) < 2:
        raise SystemExit("用法：stable_tier.py <512|1024> [轮数]")
    bits = int(sys.argv[1])
    if bits not in (512, 1024):
        raise SystemExit("只支持 512 / 1024（768 用 stable768.py）")
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 5

    opp = os.path.join(L0, "build", "hash-21", "neulaser%d" % bits, "opt.so")
    base = os.path.join(HERE, "out", "ours_neulaser2_%d_noshellsbox4.so" % bits)
    vst = os.path.join(HERE, "out", "ours_neulaser2_%d_noshellvstore.so" % bits)
    for p in (opp, base, vst):
        if not os.path.exists(p):
            raise SystemExit("缺文件：%s" % p)

    def one(lib):
        rows = BP.sweep(lib, opp, lengths=LENGTHS, rounds=120, cpu=BP.PIN_CPU,
                        bits_a=bits, bits_b=bits)
        return {r["length"]: r["ratio"] for r in rows}

    bs, vs = [], []
    for i in range(n):
        b = one(base)
        v = one(vst)
        bs.append(gm(b))
        vs.append(gm(v))
        print("轮 %d: base %.6f  vstore %.6f  (逐档 base %s / vstore %s)"
              % (i + 1, bs[-1], vs[-1],
                 " ".join("%.4f" % x for x in b.values()),
                 " ".join("%.4f" % x for x in v.values())))
    for name, arr in (("base(sbox4)", bs), ("vstore", vs)):
        med = statistics.median(arr)
        spread = 100.0 * (max(arr) - min(arr)) / med
        print("%-13s median %.6f  spread %.2f%%  => %s"
              % (name, med, spread,
                 "unstable" if spread > 1.0 else verdict(med)))
    med_b, med_v = statistics.median(bs), statistics.median(vs)
    print("vstore / base = %.6f  (+%.2f%%)"
          % (med_v / med_b, 100.0 * (med_v / med_b - 1.0)))
    os.makedirs(os.path.join(HERE, "scratch"), exist_ok=True)
    json.dump({"bits": bits, "base": bs, "vstore": vs,
               "base_median": med_b, "vstore_median": med_v},
              open(os.path.join(HERE, "scratch", "stable%d.json" % bits), "w"),
              ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
