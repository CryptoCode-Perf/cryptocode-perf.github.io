#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_noshell.py — 建 out/ours_neulaser2_<d>_noshell[_tag].so（单因子：去外壳）。

与 `build_neulaser2.py` 的差别**只有一处**：注入的 `nl_update` 不再经过
`nl_round_ext`（u64 暂存 + `round % mu` 除法 + 跨 TU 调用），而是：

    static inline void nl_update(uint32_t S[5][16], const NL_Params *p, uint32_t round)
    {
        uint32_t kap[NL_MAX_MU];
        int i;
        for (i = 0; i < p->mu; i++)
            kap[i] = nl_rotl32(0x9e3779b9U ^ round ^ (uint32_t)i,
                               (unsigned int)((round + (uint32_t)i) & 31U));
        switch (round % (uint32_t)p->mu) { case r: nl_rnd_5_r((uint32_t *)S, kap); }
    }

- 轮体与 `nl_update` **同一个 TU** 且 `static` ⇒ 无 PLT；
- 状态**直接以 `uint32_t` 进轮体** ⇒ 无 u32→u64 扩宽 / u64→u32 收窄两次全量往返；
- 轮体**只在 switch 里有一个调用点** ⇒ 不复制（不 `always_inline`）；
- `round % mu` 仍是除法 —— 这是**本件故意保留的对照项**：
  `--counter` 开关才换成递增计数器（那是下一个单因子）。

**本文件不做任何计时。**
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
GENOUT = os.path.join(HERE, "gen", "out")

SRC = ("/mnt/c/Users/von/WorkBuddy/2026-10-30-16-05-28/feilian/work/_overnight/l0/src/"
       "hash-21/Neulaser/Implementations and Test_Vectors/API_CryptHash/Implementations/"
       "Optimized_Implementation")

OPT_FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
             "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

DISPATCH = r"""
/* ======================= 由 build_noshell.py 注入 =======================
 * 只替换核心轮函数 nl_update；官方外壳的其余部分逐字未改。
 * 轮体：gen/out/nl_noshell_%(mu)d.c（与 nl_update 同 TU、static、u32 ABI）。
 */
%(rounds)s

static inline void nl_update(uint32_t S[NL_MAX_MU][NL_WORDS_PER_MODULE],
                             const NL_Params *p, uint32_t round)
{
    uint32_t kap[NL_MAX_MU];
    uint32_t rmu = round;
    int i;
    (void)nl_offsets;
    for (i = 0; i < p->mu; i++)
        kap[i] = nl_rotl32(0x9e3779b9U ^ round ^ (uint32_t)i,
                           (unsigned int)((round + (uint32_t)i) & 31U));
%(idxblk)s
    switch (rmu)
    {
%(cases)s
    default: break;
    }
}
/* ===================== 注入结束 ===================== */
"""

IDX_DIV = """    /* 基准件：保留官方的 `round % mu`（gcc 已降成 imul+shr，无 div 指令） */
    rmu = (uint32_t)(round % (uint32_t)p->mu);"""
IDX_CTR = """    /* 计数器件：把 `round % mu` 换成等价的递减归约（无乘除、无状态） */
    while (rmu >= (uint32_t)p->mu)
        rmu -= (uint32_t)p->mu;"""


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(cmd, logpath):
    with open(logpath, "w", encoding="utf-8") as lf:
        r = subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT)
    txt = open(logpath, encoding="utf-8", errors="replace").read()
    if r.returncode != 0:
        print("命令失败（%d）：%s" % (r.returncode, " ".join(cmd)))
        print(txt[-4000:])
        raise SystemExit("编译失败")
    nerr = txt.count("error:")
    nwarn = txt.count("warning:")
    print("   编译：rc=0 error=%d warning=%d" % (nerr, nwarn))
    if nerr:
        raise SystemExit("有 error: 行")
    if nwarn:
        print("     告警：%s" % txt.strip()[:800])
    return txt


def cut_braces(text, sig):
    i = text.find(sig)
    if i < 0:
        raise SystemExit("找不到定义：%s" % sig)
    j = text.find("{", i)
    depth, k = 0, j
    while k < len(text):
        if text[k] == "{":
            depth += 1
        elif text[k] == "}":
            depth -= 1
            if depth == 0:
                break
        k += 1
    return i, k


def rounds_text(mu, rname="nl_noshell_%d.c"):
    p = os.path.join(GENOUT, rname % mu)
    if not os.path.exists(p):
        raise SystemExit("缺 %s，先跑对应的 gen/ 生成器 --mu %d" % (p, mu))
    txt = open(p, encoding="utf-8").read()
    n = txt.count("static void nl_rnd_%d_" % mu)
    if n != mu:
        raise SystemExit("轮体数不对：%d != %d" % (n, mu))
    return txt


def patch_shell(mu, counter=False, rname="nl_noshell_%d.c"):
    d = {3: 512, 4: 768, 5: 1024}[mu]
    path = os.path.join(SRC, "Neulaser-%d" % d, "CryptHash_AlgorithmInstance.c")
    text = open(path, encoding="utf-8").read()
    sig = ("static void nl_update(uint32_t S[NL_MAX_MU][NL_WORDS_PER_MODULE], "
           "const NL_Params *p, uint32_t round)")
    i, k = cut_braces(text, sig)
    cases = "\n".join("    case %d: nl_rnd_%d_%d((uint32_t *)S, kap); break;"
                      % (r, mu, r) for r in range(mu))
    idx = "round % (uint32_t)p->mu" if not counter else "round"
    idxblk = IDX_DIV if not counter else IDX_CTR
    block = DISPATCH % {"mu": mu, "rounds": rounds_text(mu, rname),
                        "cases": cases, "idx": idx, "idxblk": idxblk}
    return text[:i] + block + text[k + 1:], path, (i, k)


def build(mu, tag, counter=False, rname="nl_noshell_%d.c"):
    d = {3: 512, 4: 768, 5: 1024}[mu]
    inc = os.path.join(SRC, "Neulaser-%d" % d)
    shell_txt, srcpath, span = patch_shell(mu, counter, rname)
    sp = os.path.join(OUT, "shell_%d_noshell%s.c" % (d, tag))
    with open(sp, "w", encoding="utf-8", newline="\n") as f:
        f.write(shell_txt)
    so_obj = os.path.join(OUT, "shell_%d_noshell%s.o" % (d, tag))
    run(["gcc"] + OPT_FLAGS + ["-c", "-I" + inc, "-o", so_obj, sp],
        os.path.join(OUT, "log_shell_%d_noshell%s.txt" % (d, tag)))
    out = os.path.join(OUT, "ours_neulaser2_%d_noshell%s.so" % (d, tag))
    run(["gcc"] + OPT_FLAGS + ["-shared", "-o", out, so_obj],
        os.path.join(OUT, "log_link_%d_noshell%s.txt" % (d, tag)))
    lg = os.path.join(OUT, "log_nm_%d_noshell%s.txt" % (d, tag))
    with open(lg, "w", encoding="utf-8") as lf:
        subprocess.run(["nm", "-D", "-u", out], stdout=lf, stderr=subprocess.STDOUT)
    und = [l.strip() for l in open(lg, encoding="utf-8") if l.strip()]
    bad = [u for u in und if "nl_" in u or "CryptHash" in u]
    print("   未定义符号 %d 个；含 nl_/CryptHash 的 %d 个" % (len(und), len(bad)))
    if bad:
        raise SystemExit("有未定义的自家符号：%s" % bad)
    return out, d, span, srcpath, sp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", type=int, default=1024)
    ap.add_argument("--tag", default="")
    ap.add_argument("--counter", action="store_true",
                    help="下一个单因子：round%%mu 换递增计数器（默认不做）")
    ap.add_argument("--rounds", default="nl_noshell_%d.c",
                    help="用哪份轮体 TU（默认去外壳件；合并件用 nl_comb_%%d.c）")
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    info = []
    for d, mu in [(512, 3), (768, 4), (1024, 5)]:
        if a.only and a.only != d:
            continue
        print("== 建 Neulaser-%d（mu=%d，去外壳，tag=%r counter=%s rounds=%s）"
              % (d, mu, a.tag, a.counter, a.rounds))
        so, dd, span, srcpath, sp = build(mu, a.tag, a.counter, a.rounds)
        b = os.path.getsize(so)
        info.append({"instance": d, "mu": mu, "so": os.path.relpath(so, HERE),
                     "bytes": b, "sha256": sha256(so), "shell": os.path.relpath(sp, HERE),
                     "patch_span": [span[0], span[1]], "official_src": srcpath})
        print("   -> %s (%d 字节, sha256 %s…)" % (os.path.basename(so), b,
                                                 sha256(so)[:16]))
    if info:
        p = os.path.join(OUT, "build_noshell%s.json" % (a.tag or "_base"))
        json.dump(info, open(p, "w"), indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
