#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""kat_nl.py --- 用官方 KAT 向量验 Neulaser 交付件（第四道门之外的独立判据）。

第四道门比的是「与官方 opt.so 摘要相同」，本脚本比的是「与包内 Test_Vector 的
官方期望值相同」—— 两者独立：前者防实现漂移，后者防**两侧一起错**。

用法：python3 neulaser2/kat_nl.py <ours.so> <bits> [--max N]
"""
import ctypes
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
SRC = os.path.join(L0, "src")

KAT_FMT = ("hash-21/Neulaser/Implementations and Test_Vectors/API_CryptHash/"
           "Test_Vector/KAT_2_12_Neulaser-%d.txt")


def parse(path):
    """官方格式：`Msg_Len = 0` / `Msg = 80` / `Dst_Len = 512` / `Dst = 74F8…`，空行分隔。"""
    recs, cur = [], {}
    with open(path, "r", errors="replace") as fh:
        for line in fh:
            s = line.strip()
            if not s:
                if cur:
                    recs.append(cur)
                    cur = {}
                continue
            m = re.match(r'^(Msg_Len|Msg|Dst_Len|Dst)\s*=\s*(.*)$', s)
            if not m:
                continue
            cur[m.group(1)] = m.group(2).strip()
    if cur:
        recs.append(cur)
    out = []
    for r in recs:
        if "Msg" not in r or "Dst" not in r:
            continue
        msg = bytes.fromhex(r["Msg"].replace(" ", "")) if r["Msg"] else b""
        dst = bytes.fromhex(r["Dst"].replace(" ", "")) if r["Dst"] else b""
        mlb = int(r.get("Msg_Len") or len(msg) * 8)
        dlb = int(r.get("Dst_Len") or len(dst) * 8)
        out.append((mlb, msg, dlb, dst))
    return out


def main():
    so = sys.argv[1]
    bits = int(sys.argv[2])
    mx = 400
    if "--max" in sys.argv:
        mx = int(sys.argv[sys.argv.index("--max") + 1])

    kat = os.path.join(SRC, KAT_FMT % bits)
    if not os.path.exists(kat):
        raise SystemExit("缺 KAT %s" % kat)
    recs = parse(kat)
    print("KAT %s -> %d 条" % (os.path.basename(kat), len(recs)))

    lib = ctypes.CDLL(so)
    fn = lib.CryptHash
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_ulonglong,
                   ctypes.POINTER(ctypes.c_ubyte)]

    ok = bad = 0
    first_bad = None
    for mlb, msg, dlb, dst in recs[:mx]:
        n = (dlb + 7) // 8
        buf = (ctypes.c_ubyte * 512)()
        rc = fn(dlb, msg, mlb, buf)
        got = bytes(buf[:n])
        if rc == 0 and got == dst[:n]:
            ok += 1
        else:
            bad += 1
            if first_bad is None:
                first_bad = (mlb, dlb, got[:16].hex(), dst[:16].hex())
    print("检查 %d 条：通过 %d、失败 %d" % (ok + bad, ok, bad))
    if first_bad:
        print("首条失败 msg_len=%d dst_len=%d got=%s want=%s" % first_bad)
    if ok + bad == 0:
        # 判据：一条都没验过不算通过（第一版就是这样假绿的）
        print("判定：失败（一条向量都没解析到，不能算通过）")
        return 1
    print("判定：%s" % ("全过" if bad == 0 else "失败"))
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
