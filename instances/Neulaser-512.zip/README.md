# Neulaser-512

Algorithm: Neulaser | Digest bits: 512 | Form: 标量 C

Contents: implementation source/, public header Neulaser-512.h, prebuilt Neulaser-512.so,
KAT vector KAT_2_12_Neulaser-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 52f0853f791562ae98fb40bbbe96357928384ee0837c682af97634596f9663b8
Speed (cpB, lower is faster): reference 89.87 / official-optimized 47.18 / optimized 36.46
Speedup: GM(S1-S8) 1.29x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
