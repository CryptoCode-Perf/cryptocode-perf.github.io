# Neulaser — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| Neulaser-1024 | `Neulaser-1024.so` | 44096 B | `a9fee0402edcdb65cd871aa461876010b58c2193e177af893ee6fe14c06404a4` |
| Neulaser-512 | `Neulaser-512.so` | 27592 B | `52f0853f791562ae98fb40bbbe96357928384ee0837c682af97634596f9663b8` |
| Neulaser-768 | `Neulaser-768.so` | 31728 B | `1e9134b64e9e4dda60c6b5732c0226968cb5bd87d7d3579a31930d0503554756` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| Neulaser-1024 | 1024 | 76.8018 | 44.2025 | 35.421 | 1.2479 | 1.2522 |
| Neulaser-512 | 512 | 89.8711 | 47.1814 | 36.4589 | 1.2941 | 1.2902 |
| Neulaser-768 | 768 | 79.2363 | 38.6665 | 34.6176 | 1.117 | 1.1195 |

## 优化方法（逐实例原文，来自交付清单）

### Neulaser-1024
官方外壳逐字保留；核心是 gen/gen_sbox4.py 生成的标量岛轮体，在本轮做了一处改写：轮体尾部 400 条写回从 `S[k] = x` 改成 `((volatile uint32_t *)S)[k] = x`。目的是阻断 GCC 的 SLP store-merging —— sbox4 版把连续的标量 store 合并成 8 个 ymm 的组装（vmovd + vpinsrd + vpunpcklqdq + vinserti128 + vmovdqu），几十条 store 变成近百条指令；改 volatile 后同一函数尾部向量指令 0 条，整库 ymm 从 126 降到 26。单线程语义不变（写回下标互不相同），官方 KAT 4097/4097 全过，ISA 口径 forbidden=0。重复测（5 轮 × 4 档、每轮两件同进程交替）：中位 gm 1.245068、跨轮极差 0.57%，相对上一版 sbox4（中位 1.142352、极差 5.52%）快 8.99%。

### Neulaser-512
官方外壳逐字保留；核心是 gen/gen_sbox4.py 生成的标量岛轮体，在本轮做了一处改写：轮体尾部 144 条写回从 `S[k] = x` 改成 `((volatile uint32_t *)S)[k] = x`。目的是阻断 GCC 的 SLP store-merging —— sbox4 版把连续的标量 store 合并成 8 个 ymm 的组装（vmovd + vpinsrd + vpunpcklqdq + vinserti128 + vmovdqu），几十条 store 变成近百条指令；改 volatile 后同一函数尾部向量指令 0 条，整库 ymm 从 50 降到 14。单线程语义不变（写回下标互不相同），官方 KAT 4097/4097 全过，ISA 口径 forbidden=0。重复测（5 轮 × 4 档、每轮两件同进程交替）：中位 gm 1.285692、跨轮极差 0.88%，相对上一版 sbox4（中位 1.191465、极差 5.06%）快 7.91%。

### Neulaser-768
官方外壳逐字保留；核心是 gen/gen_sbox4.py 生成的标量岛轮体，在本轮做了一处改写：轮体尾部 32 条写回从 `S[k] = x` 改成 `((volatile uint32_t *)S)[k] = x`。目的是阻断 GCC 的 SLP store-merging —— 上一版把 32 条标量 store 合并成 8 个 ymm 的组装（32 vmovd + 32 vpinsrd + 16 vpunpcklqdq + 8 vinserti128 + 8 vmovdqu，共 88 条向量指令），每轮净亏 64 条；改 volatile 后同一函数尾部向量指令 0 条、整库 ymm 从 4856 降到 20。单线程语义不变（写回下标互不相同），官方 KAT 4097/4097 全过，ISA 口径 forbidden=0。重复测（5 轮 × 4 档、每轮两件同进程交替）：中位 gm 1.116078、跨轮极差 0.50%，相对上一版 sbox4（中位 1.044945、极差 6.01%）快 6.81%。
