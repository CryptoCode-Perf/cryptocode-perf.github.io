# Neulaser — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Neulaser-1024
- 摘要位：1024；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Neulaser-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Neulaser-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Neulaser-1024/`
- 优化要点：官方外壳逐字保留；核心是 gen/gen_sbox4.py 生成的标量岛轮体，在本轮做了一处改写：轮体尾部 400 条写回从 `S[k] = x` 改成 `((volatile uint32_t *)S)[k] = x`。目的是阻断 GCC 的 SLP store-merging —— sbox4 版把连续的标量 store 合并成 8 个 ymm 的组装（vmovd + vpinsrd + vpunpcklqdq + vinserti128 + vmovdqu），几十条 store 变成近百条指令；改 volatile 后同一函数尾部向量指令 0 条，整库 ymm 从 126 降到 26。单线程语义不变（写回下标互不相同），官方 KAT 4097/4097 全过，ISA 口径 forbidden=0。重复测（5 轮 × 4 档、每轮两件同进程交替）：中位 gm 1.245068、跨轮极差

## Neulaser-512
- 摘要位：512；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Neulaser-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Neulaser-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Neulaser-512/`
- 优化要点：官方外壳逐字保留；核心是 gen/gen_sbox4.py 生成的标量岛轮体，在本轮做了一处改写：轮体尾部 144 条写回从 `S[k] = x` 改成 `((volatile uint32_t *)S)[k] = x`。目的是阻断 GCC 的 SLP store-merging —— sbox4 版把连续的标量 store 合并成 8 个 ymm 的组装（vmovd + vpinsrd + vpunpcklqdq + vinserti128 + vmovdqu），几十条 store 变成近百条指令；改 volatile 后同一函数尾部向量指令 0 条，整库 ymm 从 50 降到 14。单线程语义不变（写回下标互不相同），官方 KAT 4097/4097 全过，ISA 口径 forbidden=0。重复测（5 轮 × 4 档、每轮两件同进程交替）：中位 gm 1.285692、跨轮极差 

## Neulaser-768
- 摘要位：768；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Neulaser-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Neulaser-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Neulaser-768/`
- 优化要点：官方外壳逐字保留；核心是 gen/gen_sbox4.py 生成的标量岛轮体，在本轮做了一处改写：轮体尾部 32 条写回从 `S[k] = x` 改成 `((volatile uint32_t *)S)[k] = x`。目的是阻断 GCC 的 SLP store-merging —— 上一版把 32 条标量 store 合并成 8 个 ymm 的组装（32 vmovd + 32 vpinsrd + 16 vpunpcklqdq + 8 vinserti128 + 8 vmovdqu，共 88 条向量指令），每轮净亏 64 条；改 volatile 后同一函数尾部向量指令 0 条、整库 ymm 从 4856 降到 20。单线程语义不变（写回下标互不相同），官方 KAT 4097/4097 全过，ISA 口径 forbidden=0。重复测（5 轮 × 4 档、每轮两件同进程交替）：中位 gm
