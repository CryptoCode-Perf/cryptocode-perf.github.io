# JuziHash — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| JuziHash-1024 | `JuziHash-1024.so` | 15280 B | `18ade378b81f94ba21c23e674e3b976170df71c9e1a9f50ddbe2371af1af57ba` |
| JuziHash-512 | `JuziHash-512.so` | 15280 B | `21a72d5ba224b8d9b91c0867d277a55055636999b9eb32ab26decd0cc1bc3b14` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| JuziHash-1024 | 1024 | 220.2344 | 8.0187 | 6.598588 | 1.215214 | 1.2143 |
| JuziHash-512 | 512 | 277.3867 | 10.4381 | 8.570724 | 1.217878 | 1.215 |

## 优化方法（逐实例原文，来自交付清单）

### JuziHash-1024
引擎产物 `_overnight/l0/juzi/out/ours_juzi1024.so`（对手 = 官方 `Optimized_Implementation/JuziHash-1024/CryptHash_AlgorithmInstance.c` 编出的 `build/hash-13/juzihash1024/opt.so`） ★官方热核 `:224-247 juzi_avx2_permute(__m256i s[8])` 本身已经完全向量化（354 条、`vec=187 vperm=4`），但有两处**驱动层结构性冗余**：① `rc[8]` 的 6 组取值全部是编译期常量（`:226-231` 字面量初值 + `:243-245 rc[j]=rotl(rc[j],3)^rotl(rc[j],7)^rotl(rc[j],12)` 固定递推），官方却每调用一次置换（= 每 1024 位块一次）都重算这 6 组；② `:213-222 juzi_avx2_add_rc` 把每组 8 个字逐字节拆成 64 次 byte store（每字 7 次 shift/or，`:35-45 juzi_store64_be`）。本件把轮常量提到编译期常量表并把 add_rc 写成整寄存器异或 ⇒ 快的是驱动层去重与写回方式，不是轮函数重新向量化。等价性：A1 全量 KAT 4097/4097 ×3（`KAT_2_12_JuziHash-1024.txt`）；A2 `delivery_gate.py` 11 个位长全部一致（写 128B）；A3 时间 gm 0.8095（快 19.05%，地板 0.08%）。

### JuziHash-512
与 JuziHash-1024（第 22 例）**共用同一套胜因**：`diff` 官方 Optimized 实现两档的 `CryptHash_AlgorithmInstance.c`（366 / 369 行）只有两处实质差异 —— `:287-303` 的初值表 `JUZI512_H0[256]` ↔ `JUZI1024_H0[256]`、`:306-307` 的入口函数名 `juzihash512_avx2` ↔ `juzihash1024_avx2`；`juzi_avx2_permute` / `juzi_avx2_add_rc` / `rc[8]` 的 8 个 `UINT64_C(...)` 字面量 / 递推公式 `rc[j] = rotl(rc[j],3) ^ rotl(rc[j],7) ^ rotl(rc[j],12)` / S 盒 / MDS / byteperm **两档逐字相同**。**胜因**：rc 的 6 组取值全是编译期常量，官方每次置换都重算这 6 组，且 `juzi_avx2_add_rc` 把每组 8 个字拆成 64 次 byte store（每字 7 次 shift/or）；本件用 Python 独立实现递推预计算 6 组（自检第 0 组与源码 8 个 `UINT64_C(...)` 字面量逐字相等），生成 `static const uint8_t JUZI_RC_BYTES[6][64]`，置换里两次 `_mm256_loadu_si256` 异或解决。512 档吸收路径不用 `juzi_avx2_update_dm`，生成器把该无引用静态函数定义删掉以避免 `-Wunused-function`（语义不变）。全部 4097 条 KAT 通过（`MAX_RECORDS=1e9`），`delivery_gate.py` 11 个位长全过；计时为 captain 串行 `_ab_pair.py --reps 7 --pairs 80`，`digest 全同=True`。
