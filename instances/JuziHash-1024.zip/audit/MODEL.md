# JuziHash — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## JuziHash-1024
- 摘要位：1024；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/JuziHash-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/JuziHash-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/JuziHash-1024/`
- 优化要点：引擎产物 `_overnight/l0/juzi/out/ours_juzi1024.so`（对手 = 官方 `Optimized_Implementation/JuziHash-1024/CryptHash_AlgorithmInstance.c` 编出的 `build/hash-13/juzihash1024/opt.so`） ★官方热核 `:224-247 juzi_avx2_permute(__m256i s[8])` 本身已经完全向量化（354 条、`vec=187 vperm=4`），但有两处**驱动层结构性冗余**：① `rc[8]` 的 6 组取值全部是编译期常量（`:226-231` 字面量初值 + `:243-245 rc[j]=rotl(rc[j],3)^rotl(rc[j],7)^rotl(rc[j],12)` 固定递推），官方却每调用一次置换（= 每 1024 位

## JuziHash-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/JuziHash-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/JuziHash-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/JuziHash-512/`
- 优化要点：与 JuziHash-1024（第 22 例）**共用同一套胜因**：`diff` 官方 Optimized 实现两档的 `CryptHash_AlgorithmInstance.c`（366 / 369 行）只有两处实质差异 —— `:287-303` 的初值表 `JUZI512_H0[256]` ↔ `JUZI1024_H0[256]`、`:306-307` 的入口函数名 `juzihash512_avx2` ↔ `juzihash1024_avx2`；`juzi_avx2_permute` / `juzi_avx2_add_rc` / `rc[8]` 的 8 个 `UINT64_C(...)` 字面量 / 递推公式 `rc[j] = rotl(rc[j],3) ^ rotl(rc[j],7) ^ rotl(rc[j],12)` / S 盒 / MDS / byteperm **两档逐
