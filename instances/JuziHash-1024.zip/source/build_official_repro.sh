#!/usr/bin/env bash
# Rebuild the official Opt_Implementation JuziHash-1024 with the OFFICIAL ten flags
# and check that it is byte-identical to the shipped opponent opt.so.
# Read-only w.r.t. the official tree; writes only inside l0/juzi/.
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPT="$HERE/official/Juzi/Implementations/Implementation/Optimized_Implementation/JuziHash-1024"
REF="$HERE/official/Juzi/Implementations/Implementation/Reference_Implementation/JuziHash-1024"
OUT="$HERE/out"
mkdir -p "$OUT" "$HERE/logs"

FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

build() { # $1=out name  $2=srcfile  $3=cc
  local name="$1" src="$2"
  rm -f "$OUT/$name"
  local log="$HERE/logs/$name.build.log"
  gcc "${FLAGS[@]}" -fPIC -shared -I"$OPT" -o "$OUT/$name" "$src" -lm 2>"$log"
  local rc=$?
  if [ -s "$log" ] || [ $rc -ne 0 ]; then
    echo "[FAIL] $name : rc=$rc, compiler output follows"
    cat "$log"
    return 1
  fi
  echo "[ ok ] $name  $(stat -c%s "$OUT/$name") bytes  $(sha256sum "$OUT/$name" | cut -c1-16)"
}

build repro_opt.so "$OPT/CryptHash_AlgorithmInstance.c" || exit 1
build repro_ref.so "$REF/CryptHash_AlgorithmInstance.c" || exit 1

echo "--- fidelity vs shipped opponent files ---"
OPPSO="/mnt/c/Users/von/WorkBuddy/2026-10-30-16-05-28/feilian/work/_overnight/l0/build/hash-13/juzihash1024/opt.so"
REFSO="/mnt/c/Users/von/WorkBuddy/2026-10-30-16-05-28/feilian/work/_overnight/l0/build/hash-13/juzihash1024/ref.so"
for pair in "repro_opt.so:$OPPSO" "repro_ref.so:$REFSO"; do
  mine="${pair%%:*}"; theirs="${pair##*:}"
  a=$(sha256sum "$OUT/$mine" | cut -d' ' -f1)
  b=$(sha256sum "$theirs" | cut -d' ' -f1)
  if [ "$a" = "$b" ]; then echo "FIDELITY PASS  $mine == $(basename "$theirs")  $a"
  else echo "FIDELITY FAIL  $mine=$a  $(basename "$theirs")=$b"; fi
done
