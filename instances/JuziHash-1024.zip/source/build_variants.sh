#!/usr/bin/env bash
# Build the JuziHash-1024 variants with the verbatim OFFICIAL ten flags.
# Any compiler output at all is a failure (the official build is warning-free).
# Never touches the official tree; writes only l0/juzi/out/ and l0/juzi/logs/.
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPT="$HERE/official/Juzi/Implementations/Implementation/Optimized_Implementation/JuziHash-1024"
UNI="$HERE/src/uni"
OUT="$HERE/out"
mkdir -p "$OUT" "$HERE/logs"

FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

build() { # $1 = output name, $2 = source file, $3 = extra define (may be empty)
  local name="$1" src="$2" def="${3:-}"
  local log="$HERE/logs/$name.build.log"
  rm -f "$OUT/$name"
  if [ -n "$def" ]; then
    gcc "${FLAGS[@]}" "$def" -fPIC -shared -I"$OPT" -o "$OUT/$name" "$src" -lm 2>"$log"
  else
    gcc "${FLAGS[@]}" -fPIC -shared -I"$OPT" -o "$OUT/$name" "$src" -lm 2>"$log"
  fi
  local rc=$?
  if [ $rc -ne 0 ] || [ -s "$log" ]; then
    echo "[FAIL] $name  rc=$rc  (compiler output below)"; cat "$log"; return 1
  fi
  if [ ! -f "$OUT/$name" ]; then
    echo "[FAIL] $name  no artifact produced"; return 1
  fi
  printf '[ ok ] %-22s %7s bytes  %s\n' "$name" "$(stat -c%s "$OUT/$name")" \
         "$(sha256sum "$OUT/$name" | cut -c1-16)"
}

echo "== base (official source, must equal the shipped opponent opt.so) =="
build base.so "$OPT/CryptHash_AlgorithmInstance.c" || exit 1
echo "== our variants =="
build rc.so    "$UNI/CryptHash_AlgorithmInstance_rc.c"    || exit 1
build rcdrv.so "$UNI/CryptHash_AlgorithmInstance_rcdrv.c" || exit 1

echo
echo "== rotate census (scalar only: operands without %xmm/%ymm/%zmm) =="
for f in base rc rcdrv; do
  lib="$OUT/$f.so"
  rorx=$(objdump -d --no-show-raw-insn "$lib" | grep -cE '^\s+[0-9a-f]+:\s+rorx\s')
  rol=$(objdump -d --no-show-raw-insn "$lib" | grep -cE '^\s+[0-9a-f]+:\s+rol\s')
  ror=$(objdump -d --no-show-raw-insn "$lib" | grep -cE '^\s+[0-9a-f]+:\s+ror\s')
  printf '  %-6s rorx=%-4s rol=%-4s ror=%-4s\n' "$f" "$rorx" "$rol" "$ror"
done

echo
echo "== sha256 =="
sha256sum "$OUT"/*.so
