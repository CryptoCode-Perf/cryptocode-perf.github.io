#!/usr/bin/env python3
"""Static census of a .so: per-symbol mnemonic histogram, plus optional
address-range slicing.  Read-only helper for the TaiChi task.

usage:
  disasm_stats.py <lib.so> sym <name>
  disasm_stats.py <lib.so> range <lo> <hi>
"""
import os
import re
import subprocess
import sys
from collections import Counter

SYM_RE = re.compile(r"^[0-9a-f]+ <([^>]+)>:$")
INS_RE = re.compile(r"^\s+([0-9a-f]+):\s+(\S+)")


def disasm(lib):
    out = subprocess.run(["objdump", "-d", "--no-show-raw-insn", lib],
                         stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    return out.stdout.decode("utf-8", "replace").splitlines()


def parse(lines):
    """-> list of (addr, mnemonic, text, symbol)"""
    rows = []
    sym = "?"
    for ln in lines:
        m = SYM_RE.match(ln)
        if m:
            sym = m.group(1)
            continue
        m = INS_RE.match(ln)
        if m:
            rows.append((int(m.group(1), 16), m.group(2), ln.strip(), sym))
    return rows


def hist(rows, label):
    c = Counter(r[1] for r in rows)
    vec = sum(n for k, n in c.items() if k.startswith("v"))
    mov = sum(n for k, n in c.items() if k.startswith("mov") or k.startswith("vmov"))
    rot = sum(n for k, n in c.items()
              if k in ("rol", "ror", "rolq", "rorq", "rorx", "shld", "shrd"))
    print("%s  n=%d  mov=%d (%.0f%%)  vec=%d  rot=%d"
          % (label, len(rows), mov, 100.0 * mov / max(len(rows), 1), vec, rot))
    for k, n in c.most_common(16):
        print("    %-12s %d" % (k, n))
    return c


def main():
    lib = sys.argv[1]
    rows = parse(disasm(lib))
    mode = sys.argv[2]
    if mode == "sym":
        name = sys.argv[3]
        sub = [r for r in rows if r[3] == name]
        if not sub:
            print("no such symbol: %s  (have: %s)"
                  % (name, sorted({r[3] for r in rows})))
            return 1
        hist(sub, name)
    elif mode == "range":
        lo, hi = int(sys.argv[3], 16), int(sys.argv[4], 16)
        sub = [r for r in rows if lo <= r[0] <= hi]
        hist(sub, "%#x..%#x" % (lo, hi))
    else:
        sys.exit("unknown mode %r" % mode)
    return 0


if __name__ == "__main__":
    sys.exit(main())
