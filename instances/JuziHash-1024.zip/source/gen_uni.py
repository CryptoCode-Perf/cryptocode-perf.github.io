#!/usr/bin/env python3
"""Derive our JuziHash-1024 sources from the official Optimized_Implementation.

Two independent levers, selected by mode:

  rc     -- replace the per-permute-call round-constant schedule with a
            precomputed constant table.  The official code keeps
            `uint64_t rc[8]` inside `juzi_avx2_permute()` and advances it with
            three scalar rotates per lane per group; the table depends only on
            eight fixed literals, i.e. it is message independent, yet it is
            rebuilt on every permutation call (once per block).  Emitting it as
            6 x 64 big-endian bytes removes 24 `rol` + 16 `xor` + 8 `bswap` +
            8 stores per group and frees eight general-purpose registers.

            mode `rcdrv` = `rc` plus the two driver-layer redundancies:
              * `juzi_make_data_block` zeroes all 128 bytes and then memcpy()s
                over them for every *full* block (the zeroing is dead there);
              * the state is copied H0 -> state_bytes -> vectors and, at the
                end, vectors -> state_bytes -> four 32-byte memcpy()s into the
                digest; both round trips go straight to and from the digest.

Every edit is an exact-text substitution asserted to fire exactly once, so a
silently-mismatched patch is impossible.  Nothing here touches the official
tree; output goes to l0/juzi/src/uni/.

Usage: python3 gen_uni.py [rc] [rcdrv]
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
JUZI = os.path.dirname(HERE)
OFFICIAL = os.path.join(
    JUZI, "official", "Juzi", "Implementations", "Implementation",
    "Optimized_Implementation", "JuziHash-1024",
    "CryptHash_AlgorithmInstance.c")
OUTDIR = os.path.join(JUZI, "src", "uni")

M64 = (1 << 64) - 1

# The eight literals of `rc[8]` in juzi_avx2_permute (OPT:226-231).
RC_INIT = [
    0x243f6a8885a308d3, 0x13198a2e03707344,
    0xa4093822299f31d0, 0x082efa98ec4e6c89,
    0x452821e638d01377, 0xbe5466cf34e90c6c,
    0xc0ac29b7c97c50dd, 0x3f84d5b5b5470917,
]


def rotl64(x, n):
    return ((x << n) | (x >> (64 - n))) & M64


def rc_schedule():
    """The six 8-word round-constant rows, in the order the loop uses them."""
    rows = []
    rc = list(RC_INIT)
    for _ in range(6):
        rows.append(list(rc))
        rc = [rotl64(v, 3) ^ rotl64(v, 7) ^ rotl64(v, 12) for v in rc]
    return rows


def c_bytes_table(rows):
    out = []
    for g, row in enumerate(rows):
        blob = b"".join(v.to_bytes(8, "big") for v in row)   # big-endian, as juzi_store64_be
        assert len(blob) == 64
        for half in (0, 1):
            chunk = blob[half * 32:(half + 1) * 32]
            out.append("    { /* group %d, %s */ %s }," % (
                g, "s[0]" if half == 0 else "s[1]",
                ", ".join("0x%02xu" % b for b in chunk)))
    return "\n".join(out)


RC_TABLE_DECL = """/* Big-endian byte image of the six round-constant rows.  Group g occupies
   JUZI_RC_BYTES[2*g] (XORed into s[0]) and JUZI_RC_BYTES[2*g+1] (s[1]).
   These are the exact bytes the official juzi_store64_be() produces from
   rc[] before each group, so the XOR result is bit-identical. */
static const uint8_t JUZI_RC_BYTES[12][32] __attribute__((aligned(32))) = {
%s
};

static void juzi_avx2_add_rc_group(__m256i s[8], unsigned int group)
{
    s[0] = _mm256_xor_si256(s[0], juzi_loadu256(JUZI_RC_BYTES[2u * group]));
    s[1] = _mm256_xor_si256(s[1], juzi_loadu256(JUZI_RC_BYTES[2u * group + 1u]));
}
"""

ADD_RC_ORIG = """static void juzi_avx2_add_rc(__m256i s[8], const uint64_t rc[8])
{
    uint8_t b[64];
    size_t j;
    for (j = 0; j < 8u; j++) {
        juzi_store64_be(b + j * 8u, rc[j]);
    }
    s[0] = _mm256_xor_si256(s[0], juzi_loadu256(b));
    s[1] = _mm256_xor_si256(s[1], juzi_loadu256(b + 32u));
}

"""

PERMUTE_ORIG = """static void juzi_avx2_permute(__m256i s[8])
{
    uint64_t rc[8] = {
        UINT64_C(0x243f6a8885a308d3), UINT64_C(0x13198a2e03707344),
        UINT64_C(0xa4093822299f31d0), UINT64_C(0x082efa98ec4e6c89),
        UINT64_C(0x452821e638d01377), UINT64_C(0xbe5466cf34e90c6c),
        UINT64_C(0xc0ac29b7c97c50dd), UINT64_C(0x3f84d5b5b5470917)
    };
    unsigned int group;
    unsigned int k;
    size_t j;
    for (group = 0; group < 6u; group++) {
        juzi_avx2_add_rc(s, rc);
        for (k = 0; k < 4u; k++) {
            const unsigned int round = 4u * group + k;
            juzi_avx2_subbytes(s);
            juzi_avx2_mds(s);
            juzi_avx2_byteperm(s, round);
        }
        for (j = 0; j < 8u; j++) {
            rc[j] = juzi_rotl64(rc[j], 3u) ^ juzi_rotl64(rc[j], 7u) ^ juzi_rotl64(rc[j], 12u);
        }
    }
}"""

PERMUTE_NEW = """static void juzi_avx2_permute(__m256i s[8])
{
    unsigned int group;
    unsigned int k;
    for (group = 0; group < 6u; group++) {
        juzi_avx2_add_rc_group(s, group);
        for (k = 0; k < 4u; k++) {
            const unsigned int round = 4u * group + k;
            juzi_avx2_subbytes(s);
            juzi_avx2_mds(s);
            juzi_avx2_byteperm(s, round);
        }
    }
}"""

MAKE_BLOCK_ORIG = """    memset(block, 0, JUZI_BLOCK_BYTES);
    if (start_bit >= bitlen) {
        return;
    }

    rem_bits = bitlen - start_bit;
    if (rem_bits >= 1024u) {
        memcpy(block, msg + block_index * JUZI_BLOCK_BYTES, JUZI_BLOCK_BYTES);
        return;
    }
"""

MAKE_BLOCK_NEW = """    if (start_bit >= bitlen) {
        memset(block, 0, JUZI_BLOCK_BYTES);
        return;
    }

    rem_bits = bitlen - start_bit;
    if (rem_bits >= 1024u) {
        /* Full block: every byte is overwritten, so the 128-byte zeroing the
           official code performs first is dead work. */
        memcpy(block, msg + block_index * JUZI_BLOCK_BYTES, JUZI_BLOCK_BYTES);
        return;
    }
    memset(block, 0, JUZI_BLOCK_BYTES);
"""

HASH_HEAD_ORIG = """    uint8_t state_bytes[JUZI_STATE_BYTES];
    uint8_t block[JUZI_BLOCK_BYTES];
    __m256i s[8];
    const uint64_t data_blocks = juzi_data_block_count(msg_bitlen);
    uint64_t i;

    memcpy(state_bytes, JUZI1024_H0, JUZI_STATE_BYTES);
    juzi_avx2_load_state(s, state_bytes);
"""

HASH_HEAD_NEW = """    uint8_t block[JUZI_BLOCK_BYTES];
    __m256i s[8];
    const uint64_t data_blocks = juzi_data_block_count(msg_bitlen);
    uint64_t i;

    /* JUZI1024_H0 is already the byte image the vectors want; skip the
       H0 -> stack -> register round trip. */
    juzi_avx2_load_state(s, JUZI1024_H0);
"""

HASH_TAIL_ORIG = """    juzi_avx2_store_state(state_bytes, s);
    memcpy(digest +  0u, state_bytes + 2u * 32u, 32u);
    memcpy(digest + 32u, state_bytes + 3u * 32u, 32u);
    memcpy(digest + 64u, state_bytes + 6u * 32u, 32u);
    memcpy(digest + 96u, state_bytes + 7u * 32u, 32u);
"""

HASH_TAIL_NEW = """    juzi_storeu256(digest +  0u, s[2]);
    juzi_storeu256(digest + 32u, s[3]);
    juzi_storeu256(digest + 64u, s[6]);
    juzi_storeu256(digest + 96u, s[7]);
"""


ROTL64_ORIG = """static uint64_t juzi_rotl64(uint64_t x, unsigned int n)
{
    return (x << n) | (x >> (64u - n));
}

"""

STORE_STATE_ORIG = """static void juzi_avx2_store_state(uint8_t bytes[JUZI_STATE_BYTES], const __m256i s[8])
{
    unsigned int i;
    for (i = 0; i < 8u; i++) {
        juzi_storeu256(bytes + 32u * i, s[i]);
    }
}

"""


def sub_once(text, old, new, what):
    n = text.count(old)
    if n != 1:
        raise SystemExit("[FAIL] %s: expected exactly 1 occurrence, found %d" % (what, n))
    return text.replace(old, new)


def build(mode):
    with open(OFFICIAL, "r", encoding="utf-8") as fh:
        src = fh.read()

    table = RC_TABLE_DECL % c_bytes_table(rc_schedule())
    src = sub_once(src, ADD_RC_ORIG, table + "\n", "add_rc definition -> precomputed table")
    src = sub_once(src, PERMUTE_ORIG, PERMUTE_NEW, "permute body -> table lookup")
    # The scalar rotate helper lived only in the round-constant advance loop;
    # with the table precomputed it would be an unused static function (-Wall).
    src = sub_once(src, ROTL64_ORIG, "", "drop now-unused juzi_rotl64")

    if mode == "rcdrv":
        src = sub_once(src, MAKE_BLOCK_ORIG, MAKE_BLOCK_NEW, "make_data_block dead memset")
        src = sub_once(src, HASH_HEAD_ORIG, HASH_HEAD_NEW, "hash head state round trip")
        src = sub_once(src, HASH_TAIL_ORIG, HASH_TAIL_NEW, "hash tail digest round trip")
        src = sub_once(src, STORE_STATE_ORIG, "", "drop now-unused store_state")

    out = os.path.join(OUTDIR, "CryptHash_AlgorithmInstance_%s.c" % mode)
    os.makedirs(OUTDIR, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(src)
    print("wrote %s (%d bytes, mode=%s)" % (out, len(src), mode))


def main():
    modes = sys.argv[1:] or ["rc"]
    for m in modes:
        if m not in ("rc", "rcdrv"):
            raise SystemExit("unknown mode: %s" % m)
        build(m)


if __name__ == "__main__":
    main()
