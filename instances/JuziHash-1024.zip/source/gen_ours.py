# -*- coding: utf-8 -*-
"""JuziHash-1024（hash-13）交付件生成器 —— 只做一处**驱动层结构性冗余**的消除。

## 发现的冗余（第①步的答案）

`juzi_avx2_permute`（官方 `CryptHash_AlgorithmInstance.c:224-247`）里：

```c
uint64_t rc[8] = { 8 个固定字面量 };
for (group = 0; group < 6u; group++) {
    juzi_avx2_add_rc(s, rc);            // ← 每 group 把 rc 转成大端字节再 xor
    for (k = 0; k < 4u; k++) { ... }
    for (j = 0; j < 8u; j++)
        rc[j] = rotl(rc[j],3) ^ rotl(rc[j],7) ^ rotl(rc[j],12);   // ← 每 group 重算
}
```

* `rc` 的**全部 6 组取值是编译期常量**（初值是字面量，递推是固定公式）；
* 但实现**每次调用置换**（= 每 1024 位块一次）都要重算 6 组、并且 `juzi_avx2_add_rc`
  （`:213-222`）把每组 8 个字**逐字节拆成 64 个字节写**（`juzi_store64_be` ×8 = 64 次
  byte store + 每个字 7 次 shift/or）。

⇒ 与 AXIS-1024（收尾常数流每次重建 64 次、对块号周期 6）**同型**：只依赖轮号的东西
被每块重算。改成 6 张 `static const uint8_t` 表（384 B）后，这段完全消失。

## 判据

* 生成器**自己算**这 6 组常数（独立实现递推，不复用 C 代码），并与「把官方函数原样
  跑一遍」的结果对比（用 `-DJUZIHASH_SELFTEST` 那条路不便，故在 Python 里独立算 +
  靠最终 KAT/第四道门对拍）。
* 生成物必须与官方 `opt.so` 在全部 KAT 与第四道门上一致。
"""
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OPT = os.path.join(
    HERE, "official", "Juzi", "Implementations", "Implementation",
    "Optimized_Implementation", "JuziHash-1024")
SRC = os.path.join(OPT, "CryptHash_AlgorithmInstance.c")

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

MASK64 = (1 << 64) - 1


def rotl64(x, n):
    return ((x << n) | (x >> (64 - n))) & MASK64


def round_constants():
    """独立实现官方递推，返回 6 组 × 8 字（大端字节由调用方展开）。"""
    rc = [
        0x243f6a8885a308d3, 0x13198a2e03707344,
        0xa4093822299f31d0, 0x082efa98ec4e6c89,
        0x452821e638d01377, 0xbe5466cf34e90c6c,
        0xc0ac29b7c97c50dd, 0x3f84d5b5b5470917,
    ]
    groups = []
    for _ in range(6):
        groups.append(list(rc))
        rc = [rotl64(v, 3) ^ rotl64(v, 7) ^ rotl64(v, 12) for v in rc]
    return groups


def be_bytes(vals):
    out = []
    for v in vals:
        out.extend(((v >> s) & 0xFF) for s in (56, 48, 40, 32, 24, 16, 8, 0))
    return out


def c_table(groups):
    lines = [
        "/* 由 gen_ours.py 生成：6 组的轮常量，按官方 `juzi_avx2_add_rc` 的大端字节序展开。",
        " * 官方实现每次置换都重算这 6 组（含 6×64 次 byte store），这里烘成常量表。 */",
        "static const uint8_t JUZI_RC_BYTES[6][64] = {",
    ]
    for g, vals in enumerate(groups):
        bs = be_bytes(vals)
        body = ", ".join("0x%02xu" % b for b in bs)
        lines.append("    { %s }%s" % (body, "," if g < 5 else ""))
    lines.append("};")
    return "\n".join(lines)


ADD_RC_OLD_RE = re.compile(
    r"static void juzi_avx2_add_rc\(__m256i s\[8\], const uint64_t rc\[8\]\)\s*\{.*?\n\}\n",
    re.S)
PERMUTE_RE = re.compile(
    r"static void juzi_avx2_permute\(__m256i s\[8\]\)\s*\{.*?\n\}\n", re.S)

PERMUTE_NEW = """static void juzi_avx2_permute(__m256i s[8])
{
    unsigned int group;
    unsigned int k;
    for (group = 0; group < 6u; group++) {
        /* 轮常量直接取自常量表（官方在这里每次置换重算 6 组并逐字节展开）。 */
        s[0] = _mm256_xor_si256(s[0], juzi_loadu256(JUZI_RC_BYTES[group] +  0u));
        s[1] = _mm256_xor_si256(s[1], juzi_loadu256(JUZI_RC_BYTES[group] + 32u));
        for (k = 0; k < 4u; k++) {
            const unsigned int round = 4u * group + k;
            juzi_avx2_subbytes(s);
            juzi_avx2_mds(s);
            juzi_avx2_byteperm(s, round);
        }
    }
}
"""


def main() -> int:
    src = open(SRC, encoding="utf-8").read()
    groups = round_constants()

    # 自检：常量表与源码里的字面量必须一致（防止我抄错初值）
    lits = re.findall(r"UINT64_C\(0x([0-9a-fA-F]{16})\)", src)
    if len(lits) != 8:
        print("!! 源码里 UINT64_C 字面量不是 8 个：%d" % len(lits))
        return 2
    want = [int(x, 16) for x in lits]
    if want != groups[0]:
        print("!! 常量表第 0 组与源码字面量不一致")
        print("   源码 :", ["%016x" % v for v in want])
        print("   递推 :", ["%016x" % v for v in groups[0]])
        return 2
    print("常量自检 OK：第 0 组与源码字面量一致；共 6 组")
    for g, vals in enumerate(groups):
        print("  组%d: %s" % (g, " ".join("%016x" % v for v in vals[:2]) + " …"))

    # 替换：删 add_rc，重写 permute，插入常量表
    n1 = len(ADD_RC_OLD_RE.findall(src))
    n2 = len(PERMUTE_RE.findall(src))
    if n1 != 1 or n2 != 1:
        print("!! 替换锚点不唯一：add_rc=%d permute=%d" % (n1, n2))
        return 2
    out = ADD_RC_OLD_RE.sub("", src)
    out = PERMUTE_RE.sub(PERMUTE_NEW, out)
    # 常量表必须插在 permute **之前**（C 需要先声明）；
    # 插在 JUZI1024_H0 之前会晚于 permute ⇒ 第一次就撞 undeclared。
    anchor = "static __m256i juzi_loadu256(const void *p)"
    if out.count(anchor) != 1:
        print("!! 常量表插入锚点不唯一")
        return 2
    out = out.replace(anchor, c_table(groups) + "\n\n" + anchor)
    # juzi_rotl64 在删掉 rc 递推后不再被使用（官方构建是 warning-free，必须清掉）
    rotl_re = re.compile(
        r"static uint64_t juzi_rotl64\(uint64_t x, unsigned int n\)\s*\{.*?\n\}\n\n",
        re.S)
    if len(rotl_re.findall(out)) != 1:
        print("!! juzi_rotl64 锚点不唯一")
        return 2
    out = rotl_re.sub("", out)

    dst = os.path.join(HERE, "src", "ours.c")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    open(dst, "w", encoding="utf-8", newline="\n").write(out)
    print("已写 %s（%d B，删掉 add_rc 一处、重写 permute 一处）" % (dst, os.path.getsize(dst)))

    # 构建
    outdir = os.path.join(HERE, "out")
    os.makedirs(outdir, exist_ok=True)
    so = os.path.join(outdir, "ours_juzi1024.so")
    log = os.path.join(HERE, "logs", "ours.build.log")
    os.makedirs(os.path.dirname(log), exist_ok=True)
    cmd = ["gcc"] + FLAGS + ["-fPIC", "-shared", "-I" + OPT, "-o", so, dst, "-lm"]
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    msg = r.stdout.decode("utf-8", "replace")
    open(log, "w", encoding="utf-8").write(msg)
    if r.returncode != 0 or msg.strip():
        print("!! 构建有输出（官方构建是 warning-free）：rc=%d" % r.returncode)
        print(msg[:2000])
        return 3
    print("构建 OK：%s（%d B）" % (so, os.path.getsize(so)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
