# JuziHash-1024

Algorithm: JuziHash | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header JuziHash-1024.h, prebuilt JuziHash-1024.so,
KAT vector KAT_2_12_JuziHash-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 18ade378b81f94ba21c23e674e3b976170df71c9e1a9f50ddbe2371af1af57ba
Speed (cpB, lower is faster): reference 220.23 / official-optimized 8.02 / optimized 6.60
Speedup: GM(S1-S8) 1.21x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
