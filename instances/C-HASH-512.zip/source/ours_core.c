/* chash/gen/ours_core.c
 * C-HASH-1024 our AVX2 permutation core (paired-lane layout).
 *
 * External calling convention (identical to the official c-hash.c):
 *   void chash_perm_ff(const uint8_t *in, uint8_t *out);   P(x) XOR x  (184 B)
 *   void chash_perm   (const uint8_t *in, uint8_t *out);   P(x)        (192 B)
 *
 * Layout (the whole point of this file):
 *   The official optimized implementation keeps one ROW in one full YMM
 *   (1 nibble per byte, 32 bytes = 32 nibbles = half a row of 64).  Its
 *   m_layer therefore needs  perm2i128 + palignr  (2 shuffle-uops) for
 *   every one of the four 32-nibble rotations.
 *
 *   Here two ROWS share the two 128-bit lanes of one YMM:
 *     pair p (rows 2p, 2p+1):
 *       A = [row 2p   cols  0..15 | row 2p+1 cols  0..15]
 *       B = [row 2p   cols 16..31 | row 2p+1 cols 16..31]
 *       C = [row 2p   cols 32..47 | row 2p+1 cols 32..47]
 *       D = [row 2p   cols 48..63 | row 2p+1 cols 48..63]
 *   Each lane now holds exactly one 32-nibble half-row, so a 32-nibble
 *   rotation is a LANE-LOCAL palignr -- and one palignr rotates BOTH rows
 *   at once.  M layer: 90 shuffle-uops/round -> 48.
 *
 * Shuffle-port (p5) budget per round, both implementations:
 *   official : 12 (SBOX-1) +  0 (linear) + 12 (fused SBOX) + 90 (M) = 114
 *   ours     : 12 (SBOX-1) + 12 (linear) + 12 (fused SBOX) + 48 (M) =  84
 * The linear layer pays 12 extra p5 (3 lane swaps per slot) but buys the
 * 42-p5 M-layer reduction; all six combination outputs are assembled with
 * vpblendd (p015) so they add no shuffle-port pressure.
 */
#include <immintrin.h>
#include <stdint.h>
#include <string.h>

/* ---- algorithm constants: byte-for-byte the official Reference values ---- */
static const uint8_t SB[16] = {0x1, 0x4, 0x0, 0xC, 0x3, 0x2, 0x5, 0xB,
                               0xA, 0x8, 0x6, 0xF, 0x7, 0x9, 0xD, 0xE};
static const uint8_t SCL[6] = {0xC, 0x9, 0x0, 0x8, 0xB, 0x2};
static const uint32_t RCW[28] = {
    0x243F6A88u, 0x85A308D3u, 0x13198A2Eu, 0x03707344u, 0xA4093822u,
    0x299F31D0u, 0x082EFA98u, 0xEC4E6C89u, 0x452821E6u, 0x38D01377u,
    0xBE5466CFu, 0x34E90C6Cu, 0xC0AC29B7u, 0xC97C50DDu, 0x3F84D5B5u,
    0xB5470917u, 0x9216D5D9u, 0x8979FB1Bu, 0xD1310BA6u, 0x98DFB5ACu,
    0x2FFD72DBu, 0xD01ADFB7u, 0xB8E1AFEDu, 0x6A267E96u, 0xBA7C9045u,
    0xF12C7F99u, 0x24A19947u, 0xB3916CF7u};

/* ---- constant vectors, built once per process ---- */
static __m256i g_sbox;      /* SB in both lanes                              */
static __m256i g_fused[3];  /* [TAB[2p] | TAB[2p+1]], TAB[k][x] = SB[x^SC[k]] */
static __m256i g_rc[28];    /* RC[r] nibbles 0..7 in lane0 bytes 0..7, rest 0  */
static __m256i g_nib_even;  /* gather even source bytes 0..7, zero bytes 8..15 */
static __m256i g_nib_odd;   /* gather odd  source bytes 0..7, zero bytes 8..15 */
static int g_ready = 0;

static void init_tables(void)
{
    uint8_t b[32];
    int i, p, lane, x, m, r, n;
    if (g_ready) return;

    for (i = 0; i < 16; i++) { b[i] = SB[i]; b[16 + i] = SB[i]; }
    g_sbox = _mm256_loadu_si256((const __m256i *)b);

    for (p = 0; p < 3; p++) {
        for (lane = 0; lane < 2; lane++) {
            int k = 2 * p + lane;
            for (x = 0; x < 16; x++) b[lane * 16 + x] = SB[x ^ SCL[k]];
        }
        g_fused[p] = _mm256_loadu_si256((const __m256i *)b);
    }

    for (r = 0; r < 28; r++) {
        memset(b, 0, 32);
        for (n = 0; n < 8; n++) b[n] = (uint8_t)((RCW[r] >> (28 - 4 * n)) & 0xF);
        g_rc[r] = _mm256_loadu_si256((const __m256i *)b);
    }

    for (m = 0; m < 8; m++) { b[m] = (uint8_t)(2 * m); b[16 + m] = (uint8_t)(2 * m); }
    for (m = 8; m < 16; m++) { b[m] = 0x80; b[16 + m] = 0x80; }
    g_nib_even = _mm256_loadu_si256((const __m256i *)b);
    for (m = 0; m < 8; m++) { b[m] = (uint8_t)(2 * m + 1); b[16 + m] = (uint8_t)(2 * m + 1); }
    for (m = 8; m < 16; m++) { b[m] = 0x80; b[16 + m] = 0x80; }
    g_nib_odd = _mm256_loadu_si256((const __m256i *)b);

    g_ready = 1;
}

/* ---- expand: 192 packed bytes -> paired-lane layout --------------------- */
/* packed row i = in[32i .. 32i+32), byte k carries nibble 2k (high) / 2k+1
 * (low).  After the unpack, t0 = [nx0..15 | nx32..47], t1 = [nx16..31|nx48..63]. */
static void expand(const uint8_t *in, __m256i st[12])
{
    __m256i t0[6], t1[6];
    const __m256i m0f = _mm256_set1_epi8(0x0F);
    int i, p;
    for (i = 0; i < 6; i++) {
        __m256i x = _mm256_loadu_si256((const __m256i *)(in + 32 * i));
        __m256i lo = _mm256_and_si256(x, m0f);
        __m256i hi = _mm256_and_si256(_mm256_srli_epi16(x, 4), m0f);
        t0[i] = _mm256_unpacklo_epi8(hi, lo);
        t1[i] = _mm256_unpackhi_epi8(hi, lo);
    }
    for (p = 0; p < 3; p++) {
        int a = 2 * p, c = 2 * p + 1;
        st[4 * p + 0] = _mm256_permute2x128_si256(t0[a], t0[c], 0x20); /* A */
        st[4 * p + 2] = _mm256_permute2x128_si256(t0[a], t0[c], 0x31); /* C */
        st[4 * p + 1] = _mm256_permute2x128_si256(t1[a], t1[c], 0x20); /* B */
        st[4 * p + 3] = _mm256_permute2x128_si256(t1[a], t1[c], 0x31); /* D */
    }
}

/* ---- S layer: SBOX, then the 6 linear combinations, then the fused SBOX -- */
/* Per slot the three YMMs are X0 = rows(0,1), X1 = rows(2,3), X2 = rows(4,5);
 * lane0 = first row of the pair, lane1 = second.
 *   T01 = X0^swap(X0) = (b0^b1) duplicated ; T23 = (b2^b3) ; T45 = (b4^b5)
 *   Y  = T01^T23^X2   -> lane0 = c3, lane1 = c5
 *   Yl = T01^T23^swap(X2) -> lane1 = c3
 *   Q0 = X0^T23       -> lane0 = c0
 *   V1 = T01^swap(X2) -> lane1 = c1
 *   W  = swap(X0)^X1^swap(X2) -> lane0 = c2
 *   Z  = T01^X1^T45   -> lane0 = c4
 *   O0 = [c0|c1], O1 = [c2|c3], O2 = [c4|c5]  (vpblendd, p015) */
static void s_layer(__m256i st[12])
{
    int i, sl;
    for (i = 0; i < 12; i++) st[i] = _mm256_shuffle_epi8(g_sbox, st[i]);

    for (sl = 0; sl < 4; sl++) {
        __m256i X0 = st[sl], X1 = st[4 + sl], X2 = st[8 + sl];
        __m256i sw0 = _mm256_permute2x128_si256(X0, X0, 0x01);
        __m256i sw1 = _mm256_permute2x128_si256(X1, X1, 0x01);
        __m256i sw2 = _mm256_permute2x128_si256(X2, X2, 0x01);
        __m256i T01 = _mm256_xor_si256(X0, sw0);
        __m256i T23 = _mm256_xor_si256(X1, sw1);
        __m256i T45 = _mm256_xor_si256(X2, sw2);
        __m256i P   = _mm256_xor_si256(T01, T23);
        __m256i Y   = _mm256_xor_si256(P, X2);
        __m256i Yl  = _mm256_xor_si256(P, sw2);
        __m256i Q0  = _mm256_xor_si256(X0, T23);
        __m256i V1  = _mm256_xor_si256(T01, sw2);
        __m256i W   = _mm256_xor_si256(_mm256_xor_si256(sw0, X1), sw2);
        __m256i Z   = _mm256_xor_si256(_mm256_xor_si256(T01, X1), T45);
        __m256i O0 = _mm256_blend_epi32(Q0, V1, 0xF0);
        __m256i O1 = _mm256_blend_epi32(W, Yl, 0xF0);
        __m256i O2 = _mm256_blend_epi32(Z, Y, 0xF0);
        st[sl]     = _mm256_shuffle_epi8(g_fused[0], O0);
        st[4 + sl] = _mm256_shuffle_epi8(g_fused[1], O1);
        st[8 + sl] = _mm256_shuffle_epi8(g_fused[2], O2);
    }
}

/* ---- M layer: 4 lane-local rotation iterations per row pair ------------- */
/* rot(T,k)[j] = T[(j+k)&31].  With Tlo = cols 0..15 and Thi = cols 16..31 of
 * the rotated 32-nibble vector, per 128-bit lane:
 *   low  half = Tlo[k..15] ++ Thi[0..k-1] = alignr(Thi, Tlo, k)
 *   high half = Thi[k..15] ++ Tlo[0..k-1] = alignr(Tlo, Thi, k)
 * k = 23 is NOT expressible that way: palignr's immediate is a byte count and
 * only 0..16 are meaningful per lane.  rot32(T,23) = alignr(T, swap(T), 7)
 * per lane -- the SAME two operands in the OPPOSITE order with imm 23-16 = 7.
 * That mirror form is exactly what the official optimized source writes for
 * its third iteration; the macro's SW selector picks it.
 * The R update is rot(Tr, 31) = rot(Tr, -1). */
static void m_layer(__m256i st[12])
{
    __m256i A, B, C, D, Tlo, Thi, Slo, Shi, Trlo, Trhi;
    int p;
    for (p = 0; p < 3; p++) {
        A = st[4 * p + 0]; B = st[4 * p + 1];
        C = st[4 * p + 2]; D = st[4 * p + 3];
#define CHASH_MSTEP(K, SW)                                                        \
        Tlo = _mm256_xor_si256(A, C);                                         \
        Thi = _mm256_xor_si256(B, D);                                         \
        Slo = (SW) ? _mm256_alignr_epi8(Tlo, Thi, (K)) : _mm256_alignr_epi8(Thi, Tlo, (K));                              \
        Shi = (SW) ? _mm256_alignr_epi8(Thi, Tlo, (K)) : _mm256_alignr_epi8(Tlo, Thi, (K));                              \
        A = _mm256_xor_si256(A, Slo);                                         \
        B = _mm256_xor_si256(B, Shi);                                         \
        Trlo = _mm256_xor_si256(C, Slo);                                      \
        Trhi = _mm256_xor_si256(D, Shi);                                      \
        C = _mm256_alignr_epi8(Trlo, Trhi, 15);                               \
        D = _mm256_alignr_epi8(Trhi, Trlo, 15);
        CHASH_MSTEP(15, 0)
        CHASH_MSTEP(7, 0)
        CHASH_MSTEP(7, 1)   /* sh = 23: mirrored form, imm = 23 - 16 */
        CHASH_MSTEP(16, 0)
#undef CHASH_MSTEP
        st[4 * p + 0] = A; st[4 * p + 1] = B;
        st[4 * p + 2] = C; st[4 * p + 3] = D;
    }
}

/* ---- pack: paired-lane layout -> 192 packed bytes ----------------------- */
static void pack(const __m256i st[12], uint8_t *out)
{
    int p;
    for (p = 0; p < 3; p++) {
        int a = 2 * p, c = 2 * p + 1;
        __m256i A = st[4 * p + 0], B = st[4 * p + 1];
        __m256i C = st[4 * p + 2], D = st[4 * p + 3];
        __m256i t0a = _mm256_permute2x128_si256(A, C, 0x20); /* row a: nx0..15 | nx32..47 */
        __m256i t1a = _mm256_permute2x128_si256(B, D, 0x20); /* row a: nx16..31| nx48..63 */
        __m256i t0c = _mm256_permute2x128_si256(A, C, 0x31);
        __m256i t1c = _mm256_permute2x128_si256(B, D, 0x31);
        __m256i x1a, x2a, x1c, x2c;
        x1a = _mm256_or_si256(_mm256_slli_epi16(_mm256_shuffle_epi8(t0a, g_nib_even), 4),
                              _mm256_shuffle_epi8(t0a, g_nib_odd));
        x2a = _mm256_or_si256(_mm256_slli_epi16(_mm256_shuffle_epi8(t1a, g_nib_even), 4),
                              _mm256_shuffle_epi8(t1a, g_nib_odd));
        _mm256_storeu_si256((__m256i *)(out + 32 * a),
                            _mm256_or_si256(x1a, _mm256_slli_si256(x2a, 8)));
        x1c = _mm256_or_si256(_mm256_slli_epi16(_mm256_shuffle_epi8(t0c, g_nib_even), 4),
                              _mm256_shuffle_epi8(t0c, g_nib_odd));
        x2c = _mm256_or_si256(_mm256_slli_epi16(_mm256_shuffle_epi8(t1c, g_nib_even), 4),
                              _mm256_shuffle_epi8(t1c, g_nib_odd));
        _mm256_storeu_si256((__m256i *)(out + 32 * c),
                            _mm256_or_si256(x1c, _mm256_slli_si256(x2c, 8)));
    }
}

/* ---- P(x) --------------------------------------------------------------- */
static void perm_run(const uint8_t *in, uint8_t *out)
{
    __m256i st[12];
    int r;
    init_tables();
    expand(in, st);
    for (r = 0; r < 28; r++) {
        s_layer(st);
        m_layer(st);
        st[0] = _mm256_xor_si256(st[0], g_rc[r]);
    }
    pack(st, out);
}

void chash_perm(const uint8_t *in, uint8_t *out)
{
    perm_run(in, out);
}

/* P_FF(x) = P(x) XOR x, over the 184 message bytes only.  c-hash.c:91-96
 * writes exactly 184 bytes and leaves out[184..191] untouched, so we do too. */
void chash_perm_ff(const uint8_t *in, uint8_t *out)
{
    uint8_t tmp[192] __attribute__((aligned(32)));
    int i;
    perm_run(in, tmp);
    for (i = 0; i < 184; i++) out[i] = (uint8_t)(tmp[i] ^ in[i]);
}
