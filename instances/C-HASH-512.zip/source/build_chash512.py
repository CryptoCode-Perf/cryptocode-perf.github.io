#!/usr/bin/env python3
"""chash/build_chash512.py -- build the C-HASH-512 deliverable (sibling of -1024).

    python3 build_chash512.py glue     # make glue_chash512.c from the official Optimized source
    python3 build_chash512.py build    # compile out/ours_chash512.so (official ten flags, verbatim)
    python3 build_chash512.py asm      # objdump the deliverable and count opcodes per symbol
    python3 build_chash512.py all

Why this is a genuine sibling and not a parameter tweak:

  The two official Optimized sources (C-HASH-512 / C-HASH-1024) `diff` in 80
  lines, and every structural difference is in the *driver*: HASHLEN, the
  lane IDs (0x01/0x02/0x03 vs 0x81/0x82/0x83), the digest length passed to
  lmb(), and the C-Engine *variant* -- 1024 uses P_FF(x)=P(x) XOR x, 512 uses
  pure P.  The permutation core itself (SB/RCS/SC/init_cengine/expand192/
  pack192/sl_avx2/ml_avx2/kl_avx2) is byte-for-byte identical in both files,
  because the C-Engine state is a fixed 1536 bits and is independent of the
  digest length.  So the paired-lane layout in gen/ours_core.c -- the thing
  that cuts the p5 budget from 114 to 84 per round -- transfers unchanged.

  What the 512 driver needs is therefore only the *pure* permutation; the
  feed-forward variant does not exist in the 512 source at all (verified
  below: zero occurrences of c_engine_permute_ff), so this script replaces
  exactly one function instead of the two the 1024 script replaces.

No timing of any kind is performed anywhere in this file.
"""
import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))

OTH = os.path.join(
    L0,
    "src/hash-03/C Hash/Others/"
    "另一份独立代码供参考，AI辅助完成，性能相当， 未在算法文档中体现",
    "Implementations",
)
REFDIR = os.path.join(OTH, "Reference_Implementation/C-HASH-512")
OPTDIR = os.path.join(OTH, "Optimized_Implementation/C-HASH-512")

REF_SRC = os.path.join(REFDIR, "c-hash.c")
OPT_SRC = os.path.join(OPTDIR, "c-hash.c")
OPT_GLUE = os.path.join(OPTDIR, "CryptHash_AlgorithmInstance.c")

GLUE = os.path.join(HERE, "glue_chash512.c")
CORE = os.path.join(HERE, "gen/ours_core.c")
OUTDIR = os.path.join(HERE, "out")
OUT = os.path.join(OUTDIR, "ours_chash512.so")

# the official ten flags, verbatim (build2.json recipe for hash-03)
FLAGS = [
    "-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
    "-fomit-frame-pointer",
    "-std=c99", "-Wpedantic", "-Wall", "-Wextra",
]

FORWARD = """/* our paired-lane AVX2 core (chash/gen/ours_core.c) */
extern void chash_perm(const uint8_t *in, uint8_t *out);
"""


def replace_function(text, sig, new_text):
    """Replace the whole definition whose text starts at `sig` with new_text."""
    i = text.index(sig)
    b = text.index("{", i)
    depth = 0
    j = b
    while True:
        c = text[j]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                break
        j += 1
    return text[:i] + new_text + text[j + 1:]


def glue_text(text):
    """Official Optimized C-HASH-512 c-hash.c, with the one pure-permutation
    entry point forwarded into our core; everything else stays verbatim."""
    if text.count("c_engine_permute_ff") != 0:
        raise SystemExit(
            "C-HASH-512 源码里出现了 c_engine_permute_ff（计数 %d）—— 与 1024 档同构假设不成立"
            % text.count("c_engine_permute_ff")
        )
    text = replace_function(
        text,
        "static inline void c_engine_permute(const uint8_t *in,uint8_t *out)",
        "static inline void c_engine_permute(const uint8_t *in,uint8_t *out){"
        "chash_perm(in,out);}",
    )
    # forward declaration, placed right after the last #include
    k = text.rindex("#include")
    eol = text.index("\n", k) + 1
    return text[:eol] + "\n" + FORWARD + text[eol:]


def make_glue():
    with open(OPT_SRC, encoding="latin-1") as f:
        text = f.read()
    out = glue_text(text)
    with open(GLUE, "w", encoding="latin-1", newline="\n") as f:
        f.write(out)
    print("glue <- %s" % OPT_SRC)
    print("glue %d -> %d bytes -> %s" % (len(text), len(out), GLUE))


def run(cmd, logpath="/tmp/chash512_build.log"):
    with open(logpath, "w") as log:
        r = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)
    with open(logpath, encoding="utf-8", errors="replace") as f:
        out = f.read()
    return r.returncode, out


def cmd_build():
    os.makedirs(OUTDIR, exist_ok=True)
    make_glue()          # always regenerate: the 512 glue is cheap and must match OPT_SRC
    cmd = ["gcc"] + FLAGS + [
        "-shared", "-fPIC",
        "-I", OPTDIR,
        "-o", OUT,
        GLUE, OPT_GLUE, CORE,
        "-lm",
    ]
    rc, out = run(cmd)
    print(out.rstrip())
    if rc != 0:
        raise SystemExit("gcc failed rc=%d" % rc)

    rc2, nm = run(["nm", "-D", "-u", OUT], "/tmp/chash512_nm.log")
    bad = [l for l in nm.splitlines() if ("chash_perm" in l or "CryptHash" in l)]
    total = len([l for l in nm.splitlines() if l.strip()])
    print("未定义符号 %d 个；其中含 chash_perm/CryptHash 的 %d 个" % (total, len(bad)))
    if bad:
        for l in bad:
            print("  " + l)
        raise SystemExit("unresolved permutation symbol")

    st = os.stat(OUT)
    with open(OUT, "rb") as f:
        h = hashlib.sha256(f.read()).hexdigest()
    print("build -> %s (%d B, sha256 %s)" % (OUT, st.st_size, h))

    rc3, exp = run(["nm", "-D", "--defined-only", OUT], "/tmp/chash512_exp.log")
    want = ("CryptHash", "c_hash_512", "c_hash_512_bits")
    for w in want:
        hit = [l for l in exp.splitlines() if l.split()[-1].endswith(w)]
        print("  导出 %-16s %s" % (w, "OK" if hit else "缺失"))
        if not hit:
            raise SystemExit("missing export %s" % w)


def cmd_asm():
    """objdump the deliverable; count opcodes for the permutation and the rest."""
    import collections
    import re

    log = "/tmp/chash512_objdump.txt"
    with open(log, "w") as f:
        subprocess.run(["objdump", "-d", "--no-show-raw-insn", OUT], stdout=f)
    with open(log, encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()

    cur = None
    funcs = collections.OrderedDict()
    rx = re.compile(r"^[0-9a-f]+ <(.+)>:$")
    rx2 = re.compile(r"^\s+[0-9a-f]+:\s+([a-z0-9.]+)")
    for l in lines:
        m = rx.match(l)
        if m:
            cur = m.group(1)
            funcs.setdefault(cur, collections.Counter())
            continue
        if cur is None:
            continue
        m = rx2.match(l)
        if m:
            funcs[cur][m.group(1)] += 1

    def p5of(v):
        return sum(v[m] for m in ("vpshufb", "vperm2i128", "vpalignr", "vpermq"))

    ranked = sorted(funcs.items(), key=lambda kv: -sum(kv[1].values()))
    print("%-34s %5s  %-9s  %s" % ("symbol", "insn", "p5-class", "top opcodes"))
    for k, v in ranked[:12]:
        tot = sum(v.values())
        if tot < 8:
            continue
        top = " ".join("%s:%d" % kv for kv in v.most_common(12))
        print("%-34s %5d  %-9d  %s" % (k[:34], tot, p5of(v), top))

    whole = collections.Counter()
    for v in funcs.values():
        whole.update(v)
    print("---- whole .text: %d insn, p5-class %d" % (sum(whole.values()), p5of(whole)))


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    c = sys.argv[1]
    if c == "glue":
        make_glue()
    elif c == "build":
        cmd_build()
    elif c == "asm":
        cmd_asm()
    elif c == "all":
        cmd_build()
        cmd_asm()
    else:
        raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
