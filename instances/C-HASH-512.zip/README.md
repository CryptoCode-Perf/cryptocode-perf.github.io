# C-HASH-512

Algorithm: C-HASH | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header C-HASH-512.h, prebuilt C-HASH-512.so,
KAT vector KAT_2_12_CHash_512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 9b4678d04c0c72e780e7d92542300326da2bee31cc27e86b766d3f7c521e6d18
Speed (cpB, lower is faster): reference 801.21 / official-optimized 25.23 / optimized 21.16
Speedup: GM(S1-S8) 1.19x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
