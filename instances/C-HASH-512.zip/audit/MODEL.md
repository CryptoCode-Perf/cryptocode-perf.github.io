# C-HASH — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## C-HASH-1024
- 摘要位：1024；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/C-HASH-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/C-HASH-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/C-HASH-1024/`
- 优化要点：指令层：把「一行占一个 YMM」改成「两行共用一个 YMM、各占一个 128 位通道」，使 M 层的跨通道旋转退化成通道内 `vpalignr`（一条同时算两行），M 层从 90 p5/轮降到 48 p5/轮，一轮的 p5 绑定指令 114 → 84（−26.3%）。代价是总条数略升（每轮 243 vs 235 = 1.034×），p5 端口账 0.737 说明这笔换得值。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。

## C-HASH-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/C-HASH-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/C-HASH-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/C-HASH-512/`
- 优化要点：与 C-HASH-1024（第 44 例）**共用同一份置换核**：`diff` 官方 Optimized 实现两档的 `c-hash.c`（296 / 314 行，差 80 行）后，实质差异只有五类 —— 头注释；**512 档没有 `c_engine_permute_ff`**（1024 档多 18 行 192 B 的前馈 XOR）；`#define HASHLEN 512` 与 lane 号 `LANE_VIL 0x01 / LANE_FIL 0x02 / LANE_LDRH 0x03`（1024 档 0x81/0x82/0x83）；`ldrh_512(...digest[64])` 调 `c_engine_permute`（1024 档 `ldrh_1024(...digest[128])` 调 `c_engine_permute_ff`）与 `lmb(512, ...)`；导出入
