# C-HASH — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| C-HASH-1024 | `C-HASH-1024.so` | 20280 B | `71a21553ebdcf9ebe36d8c8f7087cb69e7c35bc8340d2ba4507685ed65e9ee23` |
| C-HASH-512 | `C-HASH-512.so` | 20280 B | `9b4678d04c0c72e780e7d92542300326da2bee31cc27e86b766d3f7c521e6d18` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| C-HASH-1024 | 1024 | 675.4844 | 21.7979 | 17.909155 | 1.217137 | 1.202 |
| C-HASH-512 | 512 | 801.2061 | 25.23 | 21.157878 | 1.192464 | 1.1939 |

## 优化方法（逐实例原文，来自交付清单）

### C-HASH-1024
指令层：把「一行占一个 YMM」改成「两行共用一个 YMM、各占一个 128 位通道」，使 M 层的跨通道旋转退化成通道内 `vpalignr`（一条同时算两行），M 层从 90 p5/轮降到 48 p5/轮，一轮的 p5 绑定指令 114 → 84（−26.3%）。代价是总条数略升（每轮 243 vs 235 = 1.034×），p5 端口账 0.737 说明这笔换得值。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。

### C-HASH-512
与 C-HASH-1024（第 44 例）**共用同一份置换核**：`diff` 官方 Optimized 实现两档的 `c-hash.c`（296 / 314 行，差 80 行）后，实质差异只有五类 —— 头注释；**512 档没有 `c_engine_permute_ff`**（1024 档多 18 行 192 B 的前馈 XOR）；`#define HASHLEN 512` 与 lane 号 `LANE_VIL 0x01 / LANE_FIL 0x02 / LANE_LDRH 0x03`（1024 档 0x81/0x82/0x83）；`ldrh_512(...digest[64])` 调 `c_engine_permute`（1024 档 `ldrh_1024(...digest[128])` 调 `c_engine_permute_ff`）与 `lmb(512, ...)`；导出入口 `c_hash_512` / `c_hash_512_bits`。而 `SB/RCS/SC/init_cengine/expand192/pack192/sl_avx2/ml_avx2/kl_avx2/c_engine_permute` 两档逐字相同、且与摘要长度无关 ⇒ 直接复用 1024 档的 `gen/ours_core.c`（`chash_perm`）。**胜因（同 1024 档）**：把「一行占一个 YMM」改成「两行共用一个 YMM、各占一个 128 位通道」，M 层的跨通道旋转退化成通道内 `vpalignr`（一条同时算两行），一轮的 p5 绑定指令 114 → 84（−26.3%），代价是每轮总条数 243 vs 235（1.034×）。`chash/build_chash512.py` 只把 `static inline void c_engine_permute(...)` 整段换成 `{ chash_perm(in, out); }`，其余逐字保留；生成时断言源码里 `c_engine_permute_ff` 计数为 0，否则说明「与 1024 同构」的前提不成立、直接退出。全量 KAT 4097/4097 通过（`MAX_RECORDS=1e9`），`delivery_gate.py` 11 个位长全过；计时为 captain 串行 `_ab_pair.py`，`digest 全同=True`。
