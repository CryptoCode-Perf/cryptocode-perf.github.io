# 复现：编译参数与装置

统一十 flag：`-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra`

装置：x86_64 Linux + gcc + python3；`bash build_and_verify.sh` 一键完成编译、KAT 抽检、交叉验证、so-vs-so 测速。

官方优化实现对照 so 随包置于 `Official_Optimized_Implementation/<实例>/opt.so`（取自 hash 构建树，与清单口径一致）。
