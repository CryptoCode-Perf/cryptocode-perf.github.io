#!/usr/bin/env bash
# Verify this single instance against its KAT vector.
set -e
SO=$(ls ./*.so 2>/dev/null | head -1)
KAT=$(ls ./KAT_*.txt 2>/dev/null | head -1)
[ -n "$SO" ] || { echo "no .so found"; exit 1; }
[ -n "$KAT" ] || { echo "no KAT vector found"; exit 1; }
echo "Verifying $SO against $KAT (all records) ..."
python3 kat_check.py "$SO" 100000 0 "$KAT"
