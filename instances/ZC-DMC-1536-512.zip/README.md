# ZC-DMC-1536-512

Algorithm: ZC-DMC | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header ZC-DMC-1536-512.h, prebuilt ZC-DMC-1536-512.so,
KAT vector KAT_2_12_ZC-DMC-1536-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 7d6764f210b3915a8ff103c196424e32cc863157b1f991d89836d6420ba8440b
Speed (cpB, lower is faster): reference 11.62 / official-optimized 7.48 / optimized 5.48
Speedup: GM(S1-S8) 1.37x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
