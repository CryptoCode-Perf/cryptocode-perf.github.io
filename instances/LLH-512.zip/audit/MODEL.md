# LLH — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## LLH-1024
- 摘要位：1024；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/LLH-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/LLH-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/LLH-1024/`
- 优化要点：官方参考驱动 + 纯 AVX2 轮函数核（生成器 `gen_llh.py` 只换热点）：轮函数循环体 162 条 vs 对手 AVX2 路径 205 条，每 128B 块的驱动开销 59 vs 208。**对手按官方 `Makefile` 的 `CFLAGS_BASE`（逐字含 `-DLLH_FORCE_AVX2=1`）重编**（36456 B，KAT 4097/4097）；`build/` 里那份 373152 B 少了这个 define、把 AVX2 与标量两条路径都留在产物里，是弱对手。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。

## LLH-512
- 摘要位：512；实现形态：AVX2 四行打包（24 行 / 6 个 ymm）
- 官方参考源码：随包 `Reference_Implementation/LLH-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/LLH-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/LLH-512/`
- 优化要点：`llh/gen_llh512.py` 编成 512 档专用的 AVX2 核：状态 24 行 × 64 位，每 4 行打成一条 ymm（6 组），T 层的三处引用偏移 4/8/12 都是 4 的倍数，所以全在 lane 内、**零 shuffle**；MDS 层用 `blend_epi32` 拼 `[Ta,Tb,Tc,Td]` 后 两次 `permute4x64`（0x4E / 0xB1）得到四条 `T?^T?^T?` 组合，与官方 `LLH_MIX_FAMILY` 四行逐字一致；旋转层因为 512 档 `SIGMA[24]` 全部落在 [1,63]，`(x<<n)|(x>>(64-n))` 用 `vpsllvq|vpsrlvq|vpor` 精确，不需要 128 位字那种跨字修正。驱动层只换了 `load_word`/`store_word`（改成 `memcpy`，x86-64 小端逐位
