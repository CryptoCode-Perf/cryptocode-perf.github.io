# LLH — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| LLH-1024 | `LLH-1024.so` | 19760 B | `559aefde90f22d29bf4c50dd5fcb15d3dccb3678e3dfb510ad949587ab08b544` |
| LLH-512 | `LLH-512.so` | 15712 B | `20df07ed42001589d78971bf1e56b40d2a3b436c9b7286547e72fe70ae5d55c5` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| LLH-1024 | 1024 | 23.6807 | 11.5493 | 9.502764 | 1.215362 | 1.187 |
| LLH-512 | 512 | 14.6484 | 8.4791 | 8.1417 | 1.0414 | 1.0583 |

## 优化方法（逐实例原文，来自交付清单）

### LLH-1024
官方参考驱动 + 纯 AVX2 轮函数核（生成器 `gen_llh.py` 只换热点）：轮函数循环体 162 条 vs 对手 AVX2 路径 205 条，每 128B 块的驱动开销 59 vs 208。**对手按官方 `Makefile` 的 `CFLAGS_BASE`（逐字含 `-DLLH_FORCE_AVX2=1`）重编**（36456 B，KAT 4097/4097）；`build/` 里那份 373152 B 少了这个 define、把 AVX2 与标量两条路径都留在产物里，是弱对手。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。

### LLH-512
`llh/gen_llh512.py` 编成 512 档专用的 AVX2 核：状态 24 行 × 64 位，每 4 行打成一条 ymm（6 组），T 层的三处引用偏移 4/8/12 都是 4 的倍数，所以全在 lane 内、**零 shuffle**；MDS 层用 `blend_epi32` 拼 `[Ta,Tb,Tc,Td]` 后 两次 `permute4x64`（0x4E / 0xB1）得到四条 `T?^T?^T?` 组合，与官方 `LLH_MIX_FAMILY` 四行逐字一致；旋转层因为 512 档 `SIGMA[24]` 全部落在 [1,63]，`(x<<n)|(x>>(64-n))` 用 `vpsllvq|vpsrlvq|vpor` 精确，不需要 128 位字那种跨字修正。驱动层只换了 `load_word`/`store_word`（改成 `memcpy`，x86-64 小端逐位等价）与 `hash_absorb`（整块直喂）。对手是官方 `Optimized_Implementation`，它本身已是 AVX2 实现（1241 行，含 `avx2_round_i2`/`avx2_shiftrows_family`/`avx2_permute_state_families`），所以这不是「把标量变向量」。官方十 flag 逐字编、零 warning、forbidden=0（ymm=574 / zmm=0），官方 KAT 全量 4097 条三侧各 match=4097。预扫（32/512/1024/4096/65536 位）`opt/ours` 中位 ≈ 1.057。
