#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_llh512.py -- build our LLH-512 delivery artefact.

Method is the one used for LLH-1024 in llh/gen_llh.py ("read the official
driver, replace only the hot kernel"):
  * take the OFFICIAL REFERENCE driver `llh_core.c` (261 lines) verbatim,
  * delete exactly two functions from it (`llh_round`, `permutation`),
  * drop in OUR pure-AVX2 kernel at that position,
  * append the OFFICIAL API wrapper's `reverse_low_bits` + `CryptHash` verbatim.

Everything else (SIGMA / RC / load_word / store_word / xor_rate / squeeze_rate /
hash_process_block / hash_init / hash_absorb / hash_final / hash) stays
byte-for-byte the official reference text, so `port_diff512.txt` is a proof that
only the round function changed.

WHY THE PACKING DIFFERS FROM LLH-1024
-------------------------------------
A word here is 64 bits, so one ymm holds FOUR consecutive rows and the whole
24-row state fits in 6 ymm registers (rows 4g..4g+3 live in sp[g], lane j).

  * T layer: needs state[(i+4)%24], state[(i+8)%24], state[(i+12)%24].  All
    three offsets are multiples of 4, hence lane-local: row 4g+j reads group
    (g+1)%6, (g+2)%6, (g+3)%6 at the SAME lane j.  Zero shuffles.
  * NOT pattern: uniform inside every group (asserted below), so it is one
    vpxor with all-ones per group instead of a per-lane select.
  * rotations: every SIGMA[512] value is in [1,63], i.e. never crosses the
    word boundary, so `vpsllvq | vpsrlvq` is exact -- no rotate-fixup.
  * MDS layer: the only cross-lane step.  All six families happen to have
    a in lane0, b in lane1, c in lane2 and d in lane3 (asserted below), so
    W = [T[a],T[b],T[c],T[d]] is three vpblendd, S = Ta^Tb^Tc^Td is a
    two-step lane butterfly, and out = S ^ W yields the four reference
    combinations in one vpxor:
        lane0 = Tb^Tc^Td   lane1 = Ta^Tc^Td
        lane2 = Ta^Tb^Td   lane3 = Ta^Tb^Tc

Also emits `gates/llh_ref_perm512.inc`: the official reference round with all
top-level identifiers renamed `ref_*`, so G1 can call the reference and our
version inside the SAME translation unit (cross-TU thin wrappers are forbidden
by this project -- they have lied three times).

Outputs
  src/llh512.c                 our delivery source
  gates/llh_ref_perm512.inc    renamed official permutation for G1
  port_diff512.txt             unified diff (official+ours) vs (official)
"""

import os
import re
import sys
import difflib

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)                       # .../_overnight/l0
RELD = os.path.join("src", "hash-16", "LLH",
                    "Implementations and Test_Vectors", "LLH_C",
                    "API_CryptHash", "Implementations")
BITS = 512
TIER = "LLH-%d" % BITS
REF_DIR = os.path.join(L0, RELD, "Reference_Implementation", TIER)
REF = os.path.join(REF_DIR, "llh_core.c")
WRAP = os.path.join(REF_DIR, "CryptHash_AlgorithmInstance.c")
OUT_C = os.path.join(HERE, "src", "llh512.c")
OUT_INC = os.path.join(HERE, "gates", "llh_ref_perm512.inc")
OUT_DIFF = os.path.join(HERE, "port_diff512.txt")

ROWS = 24
NGRP = ROWS // 4                # 6 ymm registers
WORD_BITS = BITS // 8           # the reference's W: 64 for LLH-512
NR = 8 + (WORD_BITS // 32) * 8  # NR_DEFAULT: 24 rounds

FAM_RE = re.compile(r"LLH_MIX_FAMILY\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,"
                    r"\s*(\d+)\s*,\s*(\d+)\s*\)")

ALLO = "_mm256_set1_epi64x(-1)"


def die(msg):
    sys.stderr.write("gen_llh512: FATAL: %s\n" % msg)
    raise SystemExit(1)


def load_text(path):
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def func_span(lines, pat):
    """Return (start, end) 0-based inclusive line indices of a definition."""
    start = None
    for i, ln in enumerate(lines):
        if re.match(pat, ln):
            start = i
            break
    if start is None:
        die("definition not found: %s" % pat)
    depth = 0
    seen = False
    for j in range(start, len(lines)):
        for ch in lines[j]:
            if ch == "{":
                depth += 1
                seen = True
            elif ch == "}":
                depth -= 1
                if seen and depth == 0:
                    return start, j
    die("unbalanced braces for %s" % pat)


def splice_replace(lines, pat, new_lines):
    s, e = func_span(lines, pat)
    return lines[:s] + list(new_lines) + lines[e + 1:]


# ---------------------------------------------------------------------------
# Driver-level replacements.  The reference is correct but pays for two things
# the official optimised implementation does not: it assembles every 64-bit
# rate word out of two u32 halves, and it absorbs ONE BYTE at a time.  Both are
# pure overhead on x86-64; the feed-forward structure and the block sequence
# handed to the permutation are unchanged, so the digest is bit-identical.
# ---------------------------------------------------------------------------
MY_LOAD_WORD = [
    "/* Replaced: the reference builds the word from two little-endian u32",
    "   halves.  On x86-64 (little endian) one unaligned 8-byte load is",
    "   bit-identical and costs a single instruction. */",
    "static inline word_t load_word(const uint8_t *p)",
    "{",
    "    word_t w;",
    "",
    "    memcpy(&w, p, sizeof(w));",
    "    return w;",
    "}",
]

MY_STORE_WORD = [
    "/* Replaced: mirror image of load_word. */",
    "static inline void store_word(uint8_t *p, word_t w)",
    "{",
    "    memcpy(p, &w, sizeof(w));",
    "}",
]

MY_HASH_ABSORB = [
    "/* Replaced: the reference absorbs one byte at a time and only ever calls",
    "   hash_process_block() from ctx->buf.  Once the buffer is empty a whole",
    "   block can be handed to the permutation straight out of the caller",
    "   buffer: hash_process_block() only READS the block it is given (see",
    "   xor_rate), so the sequence of blocks fed to the permutation and the",
    "   final buffer state are bit-for-bit what the reference byte loop does. */",
    "void hash_absorb(HashCtx *ctx, const uint8_t *data, size_t len)",
    "{",
    "    size_t i = 0;",
    "",
    "    if (ctx->buf_len != 0) {",
    "        while (i < len && ctx->buf_len != RATE_BYTES) {",
    "            ctx->buf[ctx->buf_len++] = data[i++];",
    "        }",
    "        if (ctx->buf_len == RATE_BYTES) {",
    "            llh_absorb_blocks_avx2(ctx, ctx->buf, 1);",
    "            ctx->buf_len = 0;",
    "        }",
    "    }",
    "    if (ctx->buf_len == 0 && len - i >= RATE_BYTES) {",
    "        size_t nb = (len - i) / RATE_BYTES;",
    "",
    "        llh_absorb_blocks_avx2(ctx, data + i, nb);",
    "        i += nb * RATE_BYTES;",
    "    }",
    "    while (i < len) {",
    "        ctx->buf[ctx->buf_len++] = data[i++];",
    "    }",
    "}",
]


def group_of(i):
    return i // 4


def lane_of(i):
    return i % 4


def main():
    ref_txt = load_text(REF)
    wrap_txt = load_text(WRAP)
    ref = ref_txt.split("\n")
    wrap = wrap_txt.split("\n")

    # ---------------------------------------------------------------- cut points
    s_round, e_round = func_span(ref, r"static\s+void\s+llh_round\s*\(")
    s_perm, e_perm = func_span(ref, r"static\s+void\s+permutation\s*\(")
    if not (e_round < s_perm):
        die("llh_round must precede permutation")
    if "llh_round" in "\n".join(ref[e_perm + 1:]):
        die("tail still references llh_round")

    setup = ref[:s_round]
    tail = ref[e_perm + 1:]

    # ---------------------------------------------------------------- tables
    m = re.search(r"SIGMA\[ROWS\]\s*=\s*\{(.*?)\};", ref_txt, re.S)
    if not m:
        die("SIGMA not found")
    SIGMA = [int(x) for x in re.findall(r"\d+", m.group(1))]
    if len(SIGMA) != ROWS:
        die("SIGMA len %d" % len(SIGMA))
    for v in SIGMA:
        if not (1 <= v < 64):
            die("SIGMA value %d outside [1,63] -- 64-bit rotate plan invalid" % v)

    m = re.search(r"#define LLH_W64_RC_LIST\(X\)(.*?)\n\s*\n", ref_txt, re.S)
    if not m:
        die("RC list not found")
    RC = re.findall(r"X\(\s*([0-9A-Fa-f]+)\s*\)", m.group(1))
    if len(RC) != NR:
        die("RC len %d (want %d)" % (len(RC), NR))

    FAM = [tuple(int(x) for x in t) for t in FAM_RE.findall(ref_txt)]
    if len(FAM) != 6:
        die("expected 6 mix families, got %d" % len(FAM))

    # NOT pattern straight from the reference round body
    nround = "\n".join(ref[s_round:e_round + 1])
    notmap = {}
    for idx, body in re.findall(r"T\[(\d+)\]\s*=\s*(WORD_NOT\()?", nround):
        notmap[int(idx)] = bool(body)
    if len(notmap) != ROWS:
        die("T not-pattern incomplete (%d)" % len(notmap))
    notgrp = []
    for g in range(NGRP):
        flags = [notmap[4 * g + j] for j in range(4)]
        if len(set(flags)) != 1:
            die("NOT not lane-uniform inside group %d: %s" % (g, flags))
        notgrp.append(flags[0])

    # MDS sanity: dst groups in order, and a/b/c/d land in lane 0/1/2/3
    for mi, (dst, a, b, c, d) in enumerate(FAM):
        if dst != 4 * mi:
            die("family %d writes dst=%d, expected %d" % (mi, dst, 4 * mi))
        for idx, want in ((a, 0), (b, 1), (c, 2), (d, 3)):
            if lane_of(idx) != want:
                die("family %d index %d in lane %d, want %d"
                    % (mi, idx, lane_of(idx), want))

    # ---------------------------------------------------------------- round body
    L = []
    L.append("static inline __m256i llh_xor3(__m256i a, __m256i b, __m256i c)")
    L.append("{")
    L.append("    return _mm256_xor_si256(_mm256_xor_si256(a, b), c);")
    L.append("}")
    L.append("")
    L.append("/*")
    L.append(" * One LLH round, reference equation exactly.  Reference (llh_core.c):")
    L.append(" *   T[i] = op_i( state[i] ^ state[(i+8)%24] ^ (state[(i+4)%24] & state[(i+12)%24]) )")
    L.append(" * with op_i = WORD_NOT() for i in 0..7 and 12..19, identity otherwise.")
    L.append(" * state[g] holds rows 4g..4g+3 in lanes 0..3, so offsets 4/8/12 stay")
    L.append(" * in the same lane and the T layer needs no shuffle at all.")
    L.append(" */")
    L.append("static inline void llh_round_avx2(__m256i *sp, int r)")
    L.append("{")
    decl = ["t%d" % g for g in range(NGRP)]
    decl += ["w", "u", "s"]
    for d in decl:
        L.append("    __m256i %s;" % d)
    L.append("")
    L.append("    /* ---- T layer : 6 groups of 4 words, lane-local ---- */")
    for g in range(NGRP):
        L.append("    t%d = _mm256_and_si256(sp[%d], sp[%d]);"
                 % (g, (g + 1) % NGRP, (g + 3) % NGRP))
        L.append("    t%d = llh_xor3(sp[%d], sp[%d], t%d);"
                 % (g, g, (g + 2) % NGRP, g))
        if notgrp[g]:
            L.append("    t%d = _mm256_xor_si256(t%d, %s);" % (g, g, ALLO))
    L.append("")
    L.append("    /* ---- MDS layer : 6 families ----")
    L.append("       W = [Ta,Tb,Tc,Td] (lanes 0..3), S = Ta^Tb^Tc^Td broadcast,")
    L.append("       out = S ^ W = [Tb^Tc^Td, Ta^Tc^Td, Ta^Tb^Td, Ta^Tb^Tc]. */")
    for mi, (dst, a, b, c, d) in enumerate(FAM):
        ga, gb, gc, gd = group_of(a), group_of(b), group_of(c), group_of(d)
        L.append("    w = _mm256_blend_epi32(t%d, t%d, 0x0C);   /* [Ta,Tb,..,..] */"
                 % (ga, gb))
        L.append("    s = _mm256_blend_epi32(t%d, t%d, 0xC0);   /* [..,..,Tc,Td] */"
                 % (gc, gd))
        L.append("    w = _mm256_blend_epi32(w, s, 0xF0);        /* [Ta,Tb,Tc,Td] */")
        L.append("    u = _mm256_xor_si256(w, _mm256_permute4x64_epi64(w, 0x4E));")
        L.append("    s = _mm256_xor_si256(u, _mm256_permute4x64_epi64(u, 0xB1));")
        L.append("    sp[%d] = _mm256_xor_si256(s, w);" % mi)
    L.append("")
    L.append("    /* ---- rotate each row by SIGMA[row], then state[23] ^= RC ---- */")
    for g in range(NGRP):
        L.append("    sp[%d] = _mm256_or_si256("
                 "_mm256_sllv_epi64(sp[%d], "
                 "_mm256_loadu_si256((const __m256i *)LLH_CL[%d])),"
                 % (g, g, g))
        L.append("        _mm256_srlv_epi64(sp[%d], "
                 "_mm256_loadu_si256((const __m256i *)LLH_CR[%d])));" % (g, g))
    L.append("    sp[%d] = _mm256_xor_si256(sp[%d],"
             " _mm256_loadu_si256((const __m256i *)&LLH_RC32[r][0]));"
             % (NGRP - 1, NGRP - 1))
    L.append("}")
    L.append("")
    L.append("static void llh_permute_avx2(word_t *row, int nrounds)")
    L.append("{")
    L.append("    __m256i sp[%d];" % NGRP)
    L.append("    int k, r;")
    L.append("")
    L.append("    for (k = 0; k < %d; k++) {" % NGRP)
    L.append("        sp[k] = _mm256_loadu_si256((const __m256i *)&row[4 * k]);")
    L.append("    }")
    L.append("    for (r = 0; r < nrounds; r++) {")
    L.append("        llh_round_avx2(sp, r);")
    L.append("    }")
    L.append("    for (k = 0; k < %d; k++) {" % NGRP)
    L.append("        _mm256_storeu_si256((__m256i *)&row[4 * k], sp[k]);")
    L.append("    }")
    L.append("}")
    L.append("")
    L.append("/*")
    L.append(" * Absorb nblocks complete blocks with the state held in ymm registers")
    L.append(" * for the whole run.  Equivalent to nblocks calls of")
    L.append(" *   hash_process_block(ctx, data + RATE_BYTES * b)")
    L.append(" * -- save the 4 capacity groups (rows 8..23 = sp[2..5]), %d rounds," % NR)
    L.append(" * feed-forward them back, then xor the 2 rate groups (rows 0..7 =")
    L.append(" * sp[0..1]) in from the message.  Removes the per-block state")
    L.append(" * load/store and the `State prev` copy hash_process_block() performs.")
    L.append(" */")
    L.append("static void llh_absorb_blocks_avx2(HashCtx *ctx, const uint8_t *data,")
    L.append("                                   size_t nblocks)")
    L.append("{")
    L.append("    __m256i sp[%d];" % NGRP)
    L.append("    __m256i cap[%d];" % (NGRP - 2))
    L.append("    int k, r;")
    L.append("    size_t b;")
    L.append("")
    L.append("    for (k = 0; k < %d; k++) {" % NGRP)
    L.append("        sp[k] = _mm256_loadu_si256("
             "(const __m256i *)&ctx->state.row[4 * k]);")
    L.append("    }")
    L.append("    for (b = 0; b < nblocks; b++) {")
    L.append("        const uint8_t *blk = data + b * RATE_BYTES;")
    L.append("")
    L.append("        for (k = 0; k < %d; k++) {" % (NGRP - 2))
    L.append("            cap[k] = sp[2 + k];")
    L.append("        }")
    L.append("        for (r = 0; r < NR_DEFAULT; r++) {")
    L.append("            llh_round_avx2(sp, r);")
    L.append("        }")
    L.append("        for (k = 0; k < %d; k++) {" % (NGRP - 2))
    L.append("            sp[2 + k] = _mm256_xor_si256(sp[2 + k], cap[k]);")
    L.append("        }")
    L.append("        for (k = 0; k < 2; k++) {")
    L.append("            sp[k] = _mm256_xor_si256(sp[k],")
    L.append("                _mm256_loadu_si256((const __m256i *)(blk + 32 * k)));")
    L.append("        }")
    L.append("    }")
    L.append("    for (k = 0; k < %d; k++) {" % NGRP)
    L.append("        _mm256_storeu_si256((__m256i *)&ctx->state.row[4 * k], sp[k]);")
    L.append("    }")
    L.append("}")
    L.append("")
    L.append("static void permutation(State *s)")
    L.append("{")
    L.append("    llh_permute_avx2(s->row, NR_DEFAULT);")
    L.append("}")
    L.append("")
    L.append("#ifdef LLH_TEST_HOOKS")
    L.append("/* G1 only; the delivery build never defines LLH_TEST_HOOKS. */")
    L.append("void llh_hook_perm(void *rows24, int nrounds)")
    L.append("{")
    L.append("    llh_permute_avx2((word_t *)rows24, nrounds);")
    L.append("}")
    L.append("void llh_hook_round(void *rows24, int r)")
    L.append("{")
    L.append("    __m256i sp[%d];" % NGRP)
    L.append("    word_t *row = (word_t *)rows24;")
    L.append("    int k;")
    L.append("    for (k = 0; k < %d; k++) {" % NGRP)
    L.append("        sp[k] = _mm256_loadu_si256((const __m256i *)&row[4 * k]);")
    L.append("    }")
    L.append("    llh_round_avx2(sp, r);")
    L.append("    for (k = 0; k < %d; k++) {" % NGRP)
    L.append("        _mm256_storeu_si256((__m256i *)&row[4 * k], sp[k]);")
    L.append("    }")
    L.append("}")
    L.append("#endif")
    kernel = L

    # ---------------------------------------------------------------- const tables
    T = []
    T.append("/* Per-row rotate counts, four rows per ymm: group g rotates lane j by")
    T.append("   SIGMA[4g+j].  All values are < 64, so (x<<n)|(x>>(64-n)) is exactly")
    T.append("   one vpsllvq + one vpsrlvq + one vpor -- no cross-word fixup. */")
    T.append("static const uint64_t LLH_CL[%d][4] = {" % NGRP)
    for g in range(NGRP):
        cl = SIGMA[4 * g:4 * g + 4]
        T.append("    { %s },   /* rows %2d..%2d */"
                 % (", ".join("%dULL" % v for v in cl), 4 * g, 4 * g + 3))
    T.append("};")
    T.append("static const uint64_t LLH_CR[%d][4] = {" % NGRP)
    for g in range(NGRP):
        cr = [64 - v for v in SIGMA[4 * g:4 * g + 4]]
        T.append("    { %s }," % ", ".join("%dULL" % v for v in cr))
    T.append("};")
    T.append("")
    T.append("/* 32-byte pool: [0,0,0,RC[round]] so state[23] ^= rc (row 23 = group 5,")
    T.append("   lane 3) is one memory-operand vpxor. */")
    T.append("static const uint64_t LLH_RC32[%d][4] = {" % NR)
    for r, v in enumerate(RC):
        T.append("    { 0ULL, 0ULL, 0ULL, 0x%sULL }," % v.lower())
    T.append("};")
    consts = T

    # ---------------------------------------------------------------- wrapper part
    ws, we = func_span(wrap, r"static\s+unsigned\s+char\s+reverse_low_bits\s*\(")
    cs, ce = func_span(wrap, r"int\s+CryptHash\s*\(")
    wrap_part = wrap[ws:we + 1] + [""] + wrap[cs:ce + 1] + [""]

    header = [
        "/*",
        " * llh512.c -- GENERATED by llh/gen_llh512.py.  DO NOT EDIT BY HAND.",
        " *",
        " * = official reference LLH-512 driver (llh_core.c, 261 lines), with",
        " *   (a) the round function + permutation replaced by a pure-AVX2 kernel,",
        " *   (b) load_word/store_word replaced by unaligned 64-bit load/store,",
        " *   (c) hash_absorb replaced by a whole-block fast path,",
        " * + official API wrapper (CryptHash_AlgorithmInstance.c) verbatim.",
        " *",
        " * Build flags are the official ten:",
        " *   -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer",
        " *   -std=c99 -Wpedantic -Wall -Wextra     (+ -fPIC -shared)",
        " * No -maes/-mvaes/-march=native, no #pragma GCC target: pure AVX2 only.",
        " */",
        "#include <limits.h>",
        "#include <stddef.h>",
        "#include <stdint.h>",
        "#include <string.h>",
        "#include <immintrin.h>",
        "",
        "#define DIGEST_BIT_LENGTH %d" % BITS,
        "#define LLH_CRYPT_HASH_SUCCESS 0",
        "#define LLH_CRYPT_HASH_UNSUPPORTED_DIGEST -1",
        "#define LLH_CRYPT_HASH_INVALID_ARG -2",
        "#define HIGH_N_BIT_MASK(N) ((unsigned char)((~0U) << (8 - (N))))",
        "",
        "#define W %d" % WORD_BITS,
        "",
    ]

    # ---------------------------------------------------------------- driver swaps
    setup = splice_replace(setup, "static inline word_t load_word", MY_LOAD_WORD)
    setup = splice_replace(setup, "static inline void store_word", MY_STORE_WORD)
    tail = splice_replace(tail, "void hash_absorb", MY_HASH_ABSORB)

    out = header + setup + consts + [""] + kernel + tail + wrap_part
    text = "\n".join(out)

    if "llh_round(" in text.replace("llh_round_avx2", "").replace("ref_llh_round", ""):
        die("stray llh_round reference in output")
    if "aesenc" in text or "GCC target" in text.split("*/")[-1]:
        die("forbidden construct in output")
    if "#define DIGEST_BIT_LENGTH %d\n" % BITS not in text:
        die("digest length did not land")
    if "#define W %d\n" % WORD_BITS not in text:
        die("word width did not land")

    # ---------------------------------------------------------------- ref .inc
    inc = []
    inc.append("/* GENERATED by llh/gen_llh512.py: official reference permutation with")
    inc.append("   every top-level identifier renamed ref_*, for SAME-TU G1 testing. */")
    inc.append("#define REF_W %d" % WORD_BITS)
    inc.append("#define REF_ROWS %d" % ROWS)
    inc.append("#define REF_RATE_ROWS 8")
    inc.append("typedef uint64_t ref_word_t;")
    inc.append("typedef struct { ref_word_t row[REF_ROWS]; } ref_State;")
    inc.append("static const int ref_SIGMA[REF_ROWS] = {")
    for i in range(0, ROWS, 4):
        inc.append("    " + ", ".join(str(v) for v in SIGMA[i:i + 4])
                   + ("," if i + 4 < ROWS else ""))
    inc.append("};")
    inc.append("static const ref_word_t ref_RC[%d] = {" % NR)
    for v in RC:
        inc.append("    0x%sULL," % v)
    inc.append("};")
    inc.append("static inline ref_word_t ref_llh_rotl(ref_word_t x, unsigned int n)")
    inc.append("{")
    inc.append("    return (ref_word_t)((x << n) | (x >> (64u - n)));")
    inc.append("}")
    inc.append("#define REF_WORD_NOT(a) (~(a))")
    inc.append("#define REF_WORD_XOR(a, b) ((a) ^ (b))")
    inc.append("#define REF_WORD_AND(a, b) ((a) & (b))")
    inc.append("#define REF_MIX_FAMILY(dst, a, b, c, d) do {                        \\")
    inc.append("    state[(dst) + 0] = REF_WORD_XOR(T[(b)], REF_WORD_XOR(T[(c)], T[(d)])); \\")
    inc.append("    state[(dst) + 1] = REF_WORD_XOR(T[(a)], REF_WORD_XOR(T[(c)], T[(d)])); \\")
    inc.append("    state[(dst) + 2] = REF_WORD_XOR(T[(a)], REF_WORD_XOR(T[(b)], T[(d)])); \\")
    inc.append("    state[(dst) + 3] = REF_WORD_XOR(T[(a)], REF_WORD_XOR(T[(b)], T[(c)])); \\")
    inc.append("} while (0)")
    body = "\n".join(ref[s_round:e_round + 1])
    for pat, rep in ((r"\bWORD_XOR\b", "REF_WORD_XOR"),
                     (r"\bWORD_AND\b", "REF_WORD_AND"),
                     (r"\bWORD_NOT\b", "REF_WORD_NOT"),
                     (r"\bLLH_MIX_FAMILY\b", "REF_MIX_FAMILY"),
                     (r"\bllh_rotl\b", "ref_llh_rotl"),
                     (r"\bllh_round\b", "ref_llh_round"),
                     (r"\bSIGMA\b", "ref_SIGMA"),
                     (r"\bROWS\b", "REF_ROWS"),
                     (r"\bword_t\b", "ref_word_t"),
                     (r"\bW\b", "REF_W")):
        body = re.sub(pat, rep, body)
    inc.append("static void ref_llh_round(ref_word_t *state, ref_word_t rc)")
    brace = body.index("{")
    inc.append(body[brace:])
    inc.append("static void ref_permutation(ref_State *s)")
    inc.append("{")
    inc.append("    for (int round = 0; round < %d; round++) {" % NR)
    inc.append("        ref_llh_round(s->row, ref_RC[round]);")
    inc.append("    }")
    inc.append("}")
    inc.append("")
    inc_text = "\n".join(inc)

    # ---------------------------------------------------------------- write
    for d in (os.path.dirname(OUT_C), os.path.dirname(OUT_INC)):
        if not os.path.isdir(d):
            os.makedirs(d)
    with open(OUT_C, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    with open(OUT_INC, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(inc_text)

    # ---------------------------------------------------------------- diff proof
    orig = ref_txt.split("\n")
    mine = text.split("\n")
    diff = list(difflib.unified_diff(orig, mine, "official/llh_core.c",
                                     "ours/generated llh512.c", lineterm="", n=1))
    with open(OUT_DIFF, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(diff) + "\n")
    plus = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    minus = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))

    print("wrote %s" % OUT_C)
    print("wrote %s" % OUT_INC)
    print("wrote %s" % OUT_DIFF)
    print("port_diff: +%d/-%d lines" % (plus, minus))
    print("cut: llh_round lines %d-%d, permutation lines %d-%d (1-based)"
          % (s_round + 1, e_round + 1, s_perm + 1, e_perm + 1))
    print("SIGMA[0..3]=%s  RC[0]=%s  NR=%d" % (SIGMA[:4], RC[0], NR))
    print("families=%s" % (FAM,))
    print("not grp=%s" % (notgrp,))
    rot_ops = NGRP * 3
    total = NGRP * 3 + 6 * 8 + rot_ops + 1
    print("round budget: T=%d  mix=%d  rot=%d  rc=1  total=%d"
          % (NGRP * 3, 6 * 8, rot_ops, total))


if __name__ == "__main__":
    main()
