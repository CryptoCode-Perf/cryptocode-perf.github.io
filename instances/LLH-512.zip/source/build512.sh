#!/usr/bin/env bash
# Build the LLH-512 delivery artefact.
# Flags are the official ten, verbatim; no -maes/-mvaes/-march=native,
# no #pragma GCC target.  Pure AVX2 only.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p out scratch

FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

gcc "${FLAGS[@]}" -fPIC -shared -o out/ours_llh512.so src/llh512.c \
    > scratch/build512.log 2>&1 || { cat scratch/build512.log; exit 1; }

# Instruction histogram needs a non-LTO object.
gcc "${FLAGS[@]}" -fno-lto -c -o out/ours_llh512.o src/llh512.c \
    > scratch/build512_obj.log 2>&1 || { cat scratch/build512_obj.log; exit 1; }

ls -l out/ours_llh512.so out/ours_llh512.o
