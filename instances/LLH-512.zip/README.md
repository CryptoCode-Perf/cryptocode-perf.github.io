# LLH-512

Algorithm: LLH | Digest bits: 512 | Form: AVX2 四行打包（24 行 / 6 个 ymm）

Contents: implementation source/, public header LLH-512.h, prebuilt LLH-512.so,
KAT vector KAT_2_12_LLH-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 20df07ed42001589d78971bf1e56b40d2a3b436c9b7286547e72fe70ae5d55c5
Speed (cpB, lower is faster): reference 14.65 / official-optimized 8.48 / optimized 8.14
Speedup: GM(S1-S8) 1.06x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
