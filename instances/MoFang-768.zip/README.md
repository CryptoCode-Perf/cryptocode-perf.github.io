# MoFang-768

Algorithm: MoFang | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header MoFang-768.h, prebuilt MoFang-768.so,
KAT vector KAT_2_12_MoFang_768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 6c2a349fd93037885d93601c7366f6a16b0af98817a8a74a423db7dcf65b48ad
Speed (cpB, lower is faster): reference 20.60 / official-optimized 9.15 / optimized 4.76
Speedup: GM(S1-S8) 1.93x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
