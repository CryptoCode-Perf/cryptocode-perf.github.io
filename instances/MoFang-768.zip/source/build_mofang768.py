#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mofang/build_mofang768.py —— MoFang-768 兄弟档交付件（`out/ours_mofang768.so`）。

## 为什么这一档是「廉价兄弟档」

`diff Reference_Implementation/MoFang-768/CryptHash_AlgorithmInstance.c \
      Reference_Implementation/MoFang-1024/CryptHash_AlgorithmInstance.c`
只有 5 处（其中 2 处是行尾空格），真正影响语义的只有 3 处：

  1. `in_g[2][2] = 10;`        （1024 档是 11）—— 域分离常量
  2. 摘要第一段 `for (i < 6)`  （1024 档是 8）—— out_g 写 6 个 64 位字 = 48 B
     偏移 `output + 48 + i*8`  （1024 档是 64）—— out_h 从第 48 字节接着写

**`encrypt2` / `MoFang_BC_2_DBL` / `hash_MDPH` 的其余部分逐字相同**，所以
1024 档已验收的核心（`mofang_keys_v3.o` + `mofang_state_v3.o`）可以**原样复用**。

## 本脚本做什么

只从 `glue_mofang1024_v3b.c` 派生 `glue_mofang768_v3b.c`（3 处替换，每处断言命中 1 次），
然后与既有的两个 `.o` 链接成 `out/ours_mofang768.so`。**不重新生成 JIR、不重编核心。**

用法：
    python3 build_mofang768.py build
    python3 build_mofang768.py kat
"""

import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
HERE = os.path.join(L0, "mofang")

REFRDIR = os.path.join(L0, "src", "hash-19", "MoFang",
                       "Implementations", "Reference_Implementation", "MoFang-768")
REFHDRDIR = REFRDIR
BUILDDIR = os.path.join(L0, "build", "hash-19", "mofang768")
REFSO = os.path.join(BUILDDIR, "ref.so")
OPTSO = os.path.join(BUILDDIR, "opt.so")
OUT = os.path.join(HERE, "out")

SRC_GLUE = os.path.join(HERE, "glue_mofang1024_v3b.c")
DST_GLUE = os.path.join(HERE, "glue_mofang768_v3b.c")
SO = os.path.join(OUT, "ours_mofang768.so")

OBJS = [os.path.join(HERE, "mofang_keys_v3.o"),
        os.path.join(HERE, "mofang_state_v3.o")]

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

# ---- 三处替换：(旧串, 新串, 说明) ----
# 每处都带足以上下文，保证在整个文件里唯一。
SUBS = [
    ("    in_g[2][2] = 11;",
     "    in_g[2][2] = 10;",
     "域分离常量 11 -> 10"),

    ("    for (int i = 0; i < 8; i++) {\n"
     "        uint64_t v = out_g[i / 3][i % 3];\n"
     "        memcpy(output + i * 8, &v, 8);",
     "    for (int i = 0; i < 6; i++) {\n"
     "        uint64_t v = out_g[i / 3][i % 3];\n"
     "        memcpy(output + i * 8, &v, 8);",
     "out_g 摘要 8 字 -> 6 字"),

    ("    for (int i = 0; i < 8; i++) {\n"
     "        uint64_t v = out_h[i / 3][i % 3];\n"
     "        memcpy(output + 64 + i * 8, &v, 8);",
     "    for (int i = 0; i < 6; i++) {\n"
     "        uint64_t v = out_h[i / 3][i % 3];\n"
     "        memcpy(output + 48 + i * 8, &v, 8);",
     "out_h 摘要 8 字 @64 -> 6 字 @48"),
]

BANNER = """/* ==== 本文件由 mofang/build_mofang768.py 自动生成，勿手改 ====
 * 基质 = glue_mofang1024_v3b.c（我方 MoFang-1024 第三版 glue）
 * 三处改成 768 档：%s
 * 核心（mofang_keys_v3.o / mofang_state_v3.o）与 1024 档完全同一份 ——
 * 官方两档的 encrypt2 / MoFang_BC_2_DBL / hash_MDPH 逐字相同。
 * ================================================================= */
"""


def run(args, cwd=HERE):
    p = subprocess.run(args, cwd=cwd)
    if p.returncode != 0:
        raise SystemExit("失败 rc=%d：%s" % (p.returncode, " ".join(args)))


def cmd_glue():
    text = io.open(SRC_GLUE, encoding="utf-8", newline="").read()
    why = []
    for old, new, desc in SUBS:
        n = text.count(old)
        if n != 1:
            raise SystemExit("!! 锚点命中 %d 次（应为 1）：%s\n---\n%s" % (n, desc, old))
        text = text.replace(old, new, 1)
        why.append(desc)
    text = BANNER % "；".join(why) + text
    io.open(DST_GLUE, "w", encoding="utf-8", newline="").write(text)
    print("      glue -> %s（%d 字节）" % (os.path.basename(DST_GLUE),
                                        len(text.encode("utf-8"))))
    return 0


def cmd_build():
    os.makedirs(OUT, exist_ok=True)
    for o in OBJS:
        if not os.path.isfile(o):
            raise SystemExit("!! 缺核心目标文件：%s" % o)
    cmd_glue()
    run(["gcc"] + FLAGS + ["-fPIC", "-shared", "-o", SO, "-I", REFHDRDIR]
        + OBJS + [DST_GLUE])
    print("      -> %s  %d 字节" % (SO, os.path.getsize(SO)))
    # ---- 复核：gcc -shared 默认放过未定义符号 ----
    p = subprocess.run(["nm", "-D", "-u", SO], stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, text=True)
    bad = [ln for ln in p.stdout.splitlines()
           if ln.strip() and not ln.strip().startswith(("w", "U _"))
           and "GLIBC" not in ln]
    for ln in p.stdout.splitlines():
        s = ln.strip()
        if s and (s.startswith("U mofang") or s.startswith("U CryptHash")):
            raise SystemExit("!! 仍有未定义我方入口：%s" % s)
    if bad:
        print("      （未定义符号，非我方入口，仅供参考）%s" % bad[:4])
    return 0


def cmd_kat():
    sys.path.insert(0, os.path.join(L0, "..", ".."))
    sys.path.insert(0, L0)
    import kat_gate as K
    K.MAX_RECORDS = 10 ** 9
    K.MAX_MSG_BYTES = 1 << 20
    kat = os.path.join(L0, "src", "hash-19", "MoFang", "Test_Vectors",
                       "Test_Vector", "KAT_2_12_MoFang_768.txt")
    recs = K.parse_kat(kat)
    print("      KAT 记录 %d 条" % len(recs))
    for tag, lib in (("ref", REFSO), ("opt", OPTSO), ("ours", SO)):
        chk, match, first_bad, err = K.check(lib, recs)
        print("      %-5s %d/%d  %s" % (tag, match, chk,
                                        "OK" if err is None else ("ERR " + str(err))))
        if err is not None or match != chk:
            print("            first_bad=%s" % (first_bad,))
            return 2
    return 0


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "glue":
        return cmd_glue()
    if cmd == "build":
        return cmd_build()
    if cmd == "kat":
        return cmd_kat()
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main())
