#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_jir_v3.py —— MoFang-1024 我方核心 **第三版**：把密钥扩展搬进 u256。

## 为什么还要第三版

第二版（`gen_jir_v2.py`）已经过四道门，但 `insn_mix.py` 量出来
`mofang_keys_v2 n=1670 mov=897 (54%)`，仍远高于赢家热核的 0..4%。
captain 的判据是 **mov < 20% 且 n < 900**。

第二版的天花板是「跨轮活跃集 = 18 个 u64」（b 与 c 各 9），而 GP 寄存器只有
12~13 个可用 ⇒ 每轮约 9 读 + 9 写落在栈上（实测含 `(%rsp)` 的指令 523 条）。

## 第三版的核心想法：一个 u256 寄存器同时装 b 和 c

    K_i  = ( lane0 = b_i, lane1 = c_i, lane2/3 = 垃圾 )

`MessageExpansion2` 的两条链改写的下标不同：

    key1: new[n] = rotl( eb[SRC1[n]] , rhok[0][n] )    SRC1 = [0,6,3,4,1,7,8,5,2]
    key2: new[n] = rotl( eb[SRC2[n]] , rhok[1][n] )    SRC2 = [0,4,8,2,3,7,1,5,6]
    eb[m] = sbox 后的 key1 数组（只有 m = 0,1,2 被 Sbox 改过）

于是每轮每个字只要 **一条 blendd + 一条 vrot**：

    t_n  = blendd( eb[SRC1[n]], eb[SRC2[n]], 12 )
           ├ lane0 ← 第一个参数的 lane0 = eb[SRC1[n]] 的 b 侧 = f(b_{SRC1[n]})
           └ lane1 ← 第二个参数的 lane1 = eb[SRC2[n]] 的 c 侧 = f(c_{SRC2[n]})
    nk_n = vrot(t_n, rrk(ROT1[n]), rrk(ROT2[n]), 0, 0)
           ├ lane0 = b'_n
           └ lane1 = c'_n

**两个参数都是 Sbox 之后的数组 `eb`**，因为参考实现是
`Sbox(key1[0]); …; Sbox(key2[0]); …` —— **两条链各自做一次 Sbox**。
`Sbox` 只用 `&`/`|`/`^`（全是逐 lane 运算），所以把 `(b_i, c_i)` 装进一个
u256 之后，一条 `sbox(K0,K1,K2)` 在 lane0 算出 `f(b)`、在 lane1 同时算出
`f(c)` —— 一次到位，不需要第二次 Sbox。
（第一版曾把第二个参数写成**未 Sbox** 的 `cur[m]`，r≥1 的 c 链整条错，
`probe3/m1_check_v3.c` 的 DUMP 一眼看出：`ref c[0]=3333333333333317`
对 `our c[0]=1111111111111111`。）

`probe2/p4_vec.jir` 实测（`p4_vec.jaz` → `jasminc`）：
`vpblendd $12` 的 imm 低两位取第一个参数的 64 位通道 0、高两位取第二个参数的
通道 1；`vrot` 发成 `vpsrlvq`+`vpsllvq`+`vpor` 三条，四个通道各有独立旋转量。

**注意 Sbox 只作用在 lane0**：`Sbox(key1[0])` 只改下标 0,1,2，所以
`e0,e1,e2 = Sbox(K0,K1,K2)`（lane0 正确；lane1 是垃圾但**永远不作为 blendd 的
第一个参数被取用** —— blendd 的 lane1 取自第二个参数 `K_{SRC2[n]}`，那条没被改过），
`e3..e8 = K3..K8` 是纯别名。

⇒ 每轮 6 + 9 + 27 + 9(st) = **51 条 u256**，16 轮 = 816，加初始化 36 = **852 条**，
且跨轮活跃集只有 9 个 YMM ⇒ **不溢出**。

## 与第二版的接口差异

第二版 `kb[72*r + 8*n] = K_r[n]`（17×9 个 u64，只有 8 字节有效，状态轮用
「3 个 32 字节窗口 + permq 选通道」广播）。

第三版 `kb[32*(9*r + n)] = 第 r 组第 n 个字`，是**一个 u256**：
lane0 = b_r[n]、lane1 = c_r[n]（**未与 a 合并**，也**未做 b^c**）。
状态轮自己算：

    Y = ld(kb + 32*(9*r+n))
    Z = xor(Y, permq(Y, 225))      # permq imm 0xE1 把 lane1 换到 lane0
                                   # ⇒ Z 的 lane0/lane1 都是 b^c
    A = ld(ab0 + 32*AIDX[r][n])    # a_r[n] 已经由 glue 广播好
    S_n = xor(S_n, Z, A)

`ab0` 是 9 个 u256（glue 里把 `in_h[0..8]` 各广播成 4 个相同 u64），
`AIDX[r][n]` 是编译期常数（`gen_jir_v2.AIDX`）。
"""
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
JIRDIR = os.path.abspath(os.path.join(HERE, "..", "jir"))

import gen_jir as G          # noqa: E402
import gen_jir_v2 as G2      # noqa: E402

SRC1, SRC2 = G.SRC1, G.SRC2
ROT1, ROT2 = G.ROT1, G.ROT2
RHOY0, RHOY1 = G.RHOY0, G.RHOY1
AIDX = G2.AIDX

PERMQ_SWAP01 = 0xE1          # permq：dst0←src1, dst1←src0, dst2←src2, dst3←src3
BLEND_BC = 12                # blendd imm：低两位取第一参数的 64 位通道 0，高两位取第二参数的通道 1


def annotate(L):
    """给每条赋值补 `:u256`（宽度必须写在定义点，ir_text.py:59/1002）。"""
    out = []
    for ln in L:
        m = re.match(r"^( {2})([A-Za-z_]\w*) = (.*)$", ln)
        if m:
            ln = "%s%s:u256 = %s" % (m.group(1), m.group(2), m.group(3))
        out.append(ln)
    return out


# ---------------------------------------------------------------------------
# 函数 1：密钥扩展（纯 u256，lane0 = b，lane1 = c）
# ---------------------------------------------------------------------------
def emit_keys_v3():
    L = []
    L.append("# 自动生成，勿手改 —— 生成器 gen/gen_jir_v3.py")
    L.append("#")
    L.append("# mofang_keys_v3 —— MoFang-1024 密钥扩展（纯 u256，16 轮展开）")
    L.append("#   kinb[32*i]      = in_m[0][i] 广播成 4 个 lane（k1/b 侧）")
    L.append("#   kinb[288+32*i]  = in_m[1][i] 广播成 4 个 lane（k2/c 侧）")
    L.append("#   kb[32*(9*r+n)]  = 第 r 组第 n 个字的原始 (b, c) 对（未合并 a、未做 b^c）")
    L.append("#      r=0    ：初始密钥（encrypt2 开头那次 AddM_Key2）")
    L.append("#      r=1..16：第 r-1 轮 MessageExpansion2 之后的轮密钥")
    L.append("#")
    L.append("# CTV{r} = 轮常量 ct[r] 放在 **lane1**（c 侧），即 ct[r] << 64：")
    L.append("# u256 字面量的最低 64 位是通道 0（probe2/p5_const.jir 实测），")
    L.append("# 而参考实现是 `key2[0][0] ^= ct[round];` 写回 **c 数组**，")
    L.append("# 下一轮 `Sbox(key2[0])` 吃的是异或**后**的值 ⇒ 必须落在 lane1。")
    for r in range(16):
        L.append("const CTV%d:u256 = 0x%064x" % (r, G.CT[r] << 64))
    L.append("entry mofang_keys_v3(kinb: u64, kb: u64)")

    cur = []
    for i in range(9):
        L.append("  h%d = ld(kinb + %d)" % (i, 32 * i))
        L.append("  m%d = ld(kinb + %d)" % (i, 288 + 32 * i))
        L.append("  K%d = blendd(h%d, m%d, %d)" % (i, i, i, BLEND_BC))
        L.append("  st(kb + %d, K%d)" % (32 * i, i))
        cur.append("K%d" % i)

    for r in range(16):
        # ---- Sbox 只改 lane1；lane0 才是 b 侧 ----
        e = {}
        e[0], e[1], e[2] = G.sbox(L, "r%d_s" % r, cur[0], cur[1], cur[2])
        for m in (3, 4, 5, 6, 7, 8):
            e[m] = cur[m]
        for n in range(9):
            L.append("  r%d_t%d = blendd(%s, %s, %d)"
                     % (r, n, e[SRC1[n]], e[SRC2[n]], BLEND_BC))
            L.append("  r%d_nk%d = vrot(r%d_t%d, %d, %d, 0, 0)"
                     % (r, n, r, n, G.rrk(ROT1[n]), G.rrk(ROT2[n])))
        # 轮常量写回 c 链（参考实现 CryptHash_AlgorithmInstance.c:172
        # `key2[0][0] ^= ct[round];`）—— 只改 lane1，lane0 的 b 值不受影响。
        L.append("  r%d_c0 = xor(r%d_nk0, CTV%d)" % (r, r, r))
        cur = ["r%d_nk%d" % (r, n) for n in range(9)]
        cur[0] = "r%d_c0" % r
        for n in range(9):
            L.append("  st(kb + %d, %s)" % (32 * (9 * (r + 1) + n), cur[n]))
    L.append("end")
    return "\n".join(annotate(L)) + "\n"


# ---------------------------------------------------------------------------
# 函数 2：状态轮（纯 u256，两分支各占一个 lane）
# ---------------------------------------------------------------------------
def emit_state_v3():
    L = []
    L.append("# 自动生成，勿手改 —— 生成器 gen/gen_jir_v3.py")
    L.append("#")
    L.append("# mofang_state_v3 —— MoFang-1024 的 encrypt2 两个分支（纯 u256，16 轮展开）")
    L.append("#   lane0 = h 分支（run2），lane1 = g 分支（run1），lane2/3 = 垃圾")
    L.append("#   kb[32*(9*r+n)] 的第 r 组是**原始 (b, c) 对**，未与 a 合并")
    L.append("#   ab0[32*i] = in_h[i] 广播；a_r[n] = ab0[AIDX[r][n]]")
    L.append("entry mofang_state_v3(sin: u64, kb: u64, ab0: u64, sout: u64)")
    cur = []
    for n in range(9):
        L.append("  S%d = ld(sin + %d)" % (n, 32 * n))
        cur.append("S%d" % n)

    def addkey(r, names, tag):
        """S_n ^= a_r[n] ^ b_r[n] ^ c_r[n]（kb 第 r 组 + ab0 广播）。"""
        for n in range(9):
            L.append("  %s_y%d = ld(kb + %d)" % (tag, n, 32 * (9 * r + n)))
            L.append("  %s_z%d = xor(%s_y%d, permq(%s_y%d, %d))"
                     % (tag, n, tag, n, tag, n, PERMQ_SWAP01))
            L.append("  %s_a%d = ld(ab0 + %d)" % (tag, n, 32 * AIDX[r][n]))
            L.append("  %s_o%d = xor(xor(%s, %s_z%d), %s_a%d)"
                     % (tag, n, names[n], tag, n, tag, n))
            names[n] = "%s_o%d" % (tag, n)

    addkey(0, cur, "w0")

    for r in range(16):
        # ---- SubBytes：3 行各做一次 Sbox ----
        for row in range(3):
            i0 = 3 * row
            o0, o1, o2 = G.sbox(L, "r%d_s%d" % (r, row),
                                cur[i0], cur[i0 + 1], cur[i0 + 2])
            cur[i0], cur[i0 + 1], cur[i0 + 2] = o0, o1, o2

        # ---- MixColumns（CryptHash_AlgorithmInstance.c:98-107）----
        t = []
        for col in range(3):
            x = "r%d_t%d" % (r, col)
            L.append("  %sx = xor(%s, %s)" % (x, cur[col], cur[3 + col]))
            L.append("  %s = xor(%sx, %s)" % (x, x, cur[6 + col]))
            t.append(x)
        m1 = "r%d_m1" % r
        L.append("  %s = xor(%s, %s)" % (m1, t[0], t[2]))
        masks = [t[2], m1, t[1]]
        nxt = [None] * 9
        for col in range(3):
            for row in range(3):
                i = 3 * row + col
                nm = "r%d_mx%d" % (r, i)
                L.append("  %s = xor(%s, %s)" % (nm, cur[i], masks[col]))
                nxt[i] = nm
        cur = nxt

        # ---- ShiftRows_0/1（偶数轮 rhoy0，奇数轮 rhoy1）----
        rho = RHOY0 if r % 2 == 0 else RHOY1
        sh = [None] * 9
        for n in range(9):
            k = G.rrk(rho[n // 3][n % 3])
            if k == 0:
                sh[n] = cur[n]
            else:
                nm = "r%d_sh%d" % (r, n)
                L.append("  %s = ror(%s, %d)" % (nm, cur[n], k))
                sh[n] = nm

        # ---- AddM_Key2：用第 r+1 组轮密钥 ----
        addkey(r + 1, sh, "r%d_k" % r)
        cur = sh

    for n in range(9):
        L.append("  T%d = ld(sin + %d)" % (n, 32 * n))
        L.append("  W%d = permq(T%d, 85)" % (n, n))
        L.append("  O%d = xor(%s, W%d)" % (n, cur[n], n))
        L.append("  st(sout + %d, O%d)" % (32 * n, n))
    L.append("end")
    return "\n".join(annotate(L)) + "\n"


def main():
    if not os.path.isdir(JIRDIR):
        os.makedirs(JIRDIR)
    for name, text in (("mofang_keys_v3", emit_keys_v3()),
                       ("mofang_state_v3", emit_state_v3())):
        p = os.path.join(JIRDIR, name + ".jir")
        with open(p, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        print("写出 %s（%d 行）" % (p, text.count("\n")))


if __name__ == "__main__":
    main()
