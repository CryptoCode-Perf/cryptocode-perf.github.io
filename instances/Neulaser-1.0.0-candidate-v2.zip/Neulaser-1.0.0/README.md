# Neulaser candidate package

Instances: Neulaser-512, Neulaser-768 and Neulaser-1024. On x86-64 Linux
with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`. It rebuilds the
reference, official optimized and CryptoCode implementations, checks 4097
known-answer vectors per implementation, compares selected long and boundary
inputs among all three, and checks selected input/output guard-page boundaries.
`CryptHash` lengths are in bits.

Candidate only: controlled fastest-implementation comparison, source and
license review, redistribution permission and final release review remain
pending. Tests do not prove security.
