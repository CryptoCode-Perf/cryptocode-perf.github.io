#!/usr/bin/env bash
# 官方优化版：官方 .c（定义置换入口 XRH1280）+ 官方 AVX2 汇编（定义 CryptHash），
# 用官方十 flag 直接汇编链接 —— 与当年测速用的对手件同一份源码。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../build
gcc $FLAGS -shared -fPIC -I ../../Reference_Implementation/XRH-2-1024     -o ../../build/off_1024.so CryptHash_AlgorithmInstance.c CryptHash_AlgorithmInstance_AVX2.s
echo "built build/off_1024.so"
