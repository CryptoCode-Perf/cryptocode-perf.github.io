#!/usr/bin/env bash
# XRH-2-768 的 CryptoCode 实现：一个 jasmin 生成的 18 轮核 + C 外壳（glue + vec_api）。
set -euo pipefail
cd "$(dirname "$0")"
REF=../../../Reference_Implementation/XRH-2-768
OPT=../../../Optimized_Implementation/XRH-2-768
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../../build
gcc $FLAGS -c -o ../../../build/xrh_r0_18.o xrh_r0_18.s
gcc $FLAGS -fPIC -c -I "$OPT" -I "$REF" -o ../../../build/vec_api.o vec_api_xrh2.c
gcc $FLAGS -fPIC -c -I "$OPT" -I "$REF" -o ../../../build/glue.o glue_xrh2_768.c
gcc -shared -fPIC -o ../../../build/our_768.so \
    ../../../build/xrh_r0_18.o ../../../build/vec_api.o ../../../build/glue.o
echo "built build/our_768.so"
