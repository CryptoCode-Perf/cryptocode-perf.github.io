#!/usr/bin/env bash
# XRH-1 1.0.0 —— 三方编译 + 22 长度差分 + 黄金向量 + KAT 4097
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build

echo "== [XRH-2-768] 1/4 编译三方 =="
bash Reference_Implementation/XRH-2-768/build_ref.sh
bash Optimized_Implementation/XRH-2-768/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/XRH-2-768/build_ours.sh
echo "== [XRH-2-768] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_768 test/vec_768.c -ldl
./build/vec_768 build/ref_768.so > build/vec_ref_768.txt
./build/vec_768 build/off_768.so > build/vec_off_768.txt
./build/vec_768 build/our_768.so > build/vec_our_768.txt
cmp build/vec_ref_768.txt build/vec_off_768.txt
cmp build/vec_ref_768.txt build/vec_our_768.txt
cp build/vec_ref_768.txt test/golden_vectors_ref_768.txt
echo "== [XRH-2-768] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_768.so 100000 0 kat/KAT_2_12_XRH-2-768.txt
python3 test/kat_check.py build/off_768.so 100000 0 kat/KAT_2_12_XRH-2-768.txt
python3 test/kat_check.py build/our_768.so 100000 0 kat/KAT_2_12_XRH-2-768.txt
echo "== [XRH-2-768] 4/4 完成 =="

echo "== [XRH-2-1024] 1/4 编译三方 =="
bash Reference_Implementation/XRH-2-1024/build_ref.sh
bash Optimized_Implementation/XRH-2-1024/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/XRH-2-1024/build_ours.sh
echo "== [XRH-2-1024] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_1024 test/vec_1024.c -ldl
./build/vec_1024 build/ref_1024.so > build/vec_ref_1024.txt
./build/vec_1024 build/off_1024.so > build/vec_off_1024.txt
./build/vec_1024 build/our_1024.so > build/vec_our_1024.txt
cmp build/vec_ref_1024.txt build/vec_off_1024.txt
cmp build/vec_ref_1024.txt build/vec_our_1024.txt
cp build/vec_ref_1024.txt test/golden_vectors_ref_1024.txt
echo "== [XRH-2-1024] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_1024.so 100000 0 kat/KAT_2_12_XRH-2-1024.txt
python3 test/kat_check.py build/off_1024.so 100000 0 kat/KAT_2_12_XRH-2-1024.txt
python3 test/kat_check.py build/our_1024.so 100000 0 kat/KAT_2_12_XRH-2-1024.txt
echo "== [XRH-2-1024] 4/4 完成 =="

echo "== 验证全部通过 =="
