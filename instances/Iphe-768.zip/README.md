# Iphe-768

CAP candidate from iphe768-dsh-gate2-structural-v1; generation contract REF+KAT-only; lineage: fresh.

Run `bash verify.sh`; rebuild with `bash build.sh`, then verify again. See audit/ for scope and measurements. TSC ticks/B is not hardware CPB.
