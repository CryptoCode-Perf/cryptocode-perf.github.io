#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 kat_check.py ./Iphe-768.so 4097 0 KAT_2_12_Iphe-768.txt
