# AXIS-1024

Algorithm: AXIS | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header AXIS-1024.h, prebuilt AXIS-1024.so,
KAT vector KAT_2_12_AXIS-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 3a6485e771fc4b4f01f9374cd44c8fd0f73195b4b9eeef8319ff556a9d5b1694
Speed (cpB, lower is faster): reference 74.82 / official-optimized 27.34 / optimized 2.97
Speedup: GM(S1-S8) 5.73x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
