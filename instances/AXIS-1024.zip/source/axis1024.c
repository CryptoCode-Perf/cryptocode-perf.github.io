/*
 * AXIS-1024 (candidate hash-02) -- our implementation.
 *
 * Reference semantics were read from the ICCS optimized AXIS-1024 source at
 *   _overnight/l0/src/hash-02/AXIS/Implementations/Optimized_Implementation/AXIS-1024/
 * and are documented with line numbers in _overnight/l0/axis/MODEL.md.
 *
 * Design (see MODEL.md "route"):
 *   - one 32-beat AVX2 SoA32 core kernel (8 lanes = 8 registers, 32 bit
 *     positions of a lane = 32 bitsliced beats), used for EVERY input length;
 *   - the finalization constant stream is a pure function of
 *     (padded_bits, beat) with period 6 in the 32-beat block index, so the 64
 *     per-hash rebuilds of that stream collapse into 6 precomputed rows;
 *   - a bit-exact scalar mirror (mxc_axis1024_hash_bits_generic) is kept for
 *     differential testing against the reference scalar path.
 *
 * No #pragma GCC target; built with the official ten flags only.
 */

#include <stdint.h>
#include <string.h>
#include <immintrin.h>

#include "axis1024_stream.h"

#define MXC_EXL_0 0u
#define MXC_EXL_1 12u
#define MXC_EXL_2 32u
#define MXC_EXL_3 96u
#define MXC_EXL_4 107u
#define MXC_EXL_5 125u
#define MXC_EXL_PREV 11u

#define MXC_UPL_0 66u
#define MXC_UPL_1 75u
#define MXC_UPL_2 90u
#define MXC_UPL_3 162u
#define MXC_UPL_4 178u
#define MXC_UPL_5 188u

#define MXC_REG_BITS 192u
#define MXC_REG_WORDS 3u
#define MXC_REGS 8u
#define MXC_STREAM_BITS (MXC_REGS * MXC_REG_BITS) /* 1536 */
#define MXC_BLANK_ROUNDS 1024u
#define MXC_DIGEST_BITS 1024u
#define MXC_DIGEST_BYTES (MXC_DIGEST_BITS / 8u) /* 128 */

/* Document initial constants; also the finalization constant stream source. */
static const uint64_t k_mxc_init[MXC_REGS][MXC_REG_WORDS] = {
    {0x9E3779B97F4A7C15ULL, 0xB7E151628AED2A6AULL, 0x243F6A8885A308D3ULL},
    {0x49CA76E19F938DA4ULL, 0xD81F8650363C93F8ULL, 0x7160C6B758B90A76ULL},
    {0xCD71C257B752EEB5ULL, 0xB54CBDE35B659CC7ULL, 0x70FF7724ACB762F7ULL},
    {0x47EA14CFA7D43857ULL, 0x3120355B0549D6B9ULL, 0x4FD6E6B4FBAB7ECDULL},
    {0x5DCD2735332E4029ULL, 0x03F92D7B7FAEEF10ULL, 0x6B634EF404919AAAULL},
    {0xD57AC41E845348D4ULL, 0xCD0814056FA6E00BULL, 0x53C1A2C96C4DE7E3ULL},
    {0xABDBF53A09476735ULL, 0x352FF6633C6EFBA6ULL, 0xF3FF90522F99DAE5ULL},
    {0x0D875B906F276D2CULL, 0xD94570230179F812ULL, 0xB1A270D3653FB5B8ULL}
};

/* ------------------------------------------------------------------ */
/* scalar (generic) path -- mirrors the reference axis_step_default /   */
/* axis_reupfull recurrence exactly, including its in-place register    */
/* update order (register j reads the already-updated register j-1).    */
/* ------------------------------------------------------------------ */

static uint32_t mxc_get_bit(const uint64_t* reg, uint32_t bit_index)
{
    return (uint32_t)((reg[bit_index >> 6] >> (bit_index & 63u)) & 1ull);
}

static void mxc_flip_bit(uint64_t* reg, uint32_t bit_index, uint32_t bit)
{
    if (bit != 0u) {
        reg[bit_index >> 6] ^= 1ull << (bit_index & 63u);
    }
}

static void mxc_shift_right_one(const uint64_t* src, uint64_t* dst)
{
    dst[0] = (src[0] >> 1) | (src[1] << 63);
    dst[1] = (src[1] >> 1) | (src[2] << 63);
    dst[2] = (src[2] >> 1) | ((src[0] & 1ull) << 63);
}

static uint32_t mxc_sbox6(uint32_t x0, uint32_t x1, uint32_t x2,
                          uint32_t x3, uint32_t x4, uint32_t x5)
{
    return (x0 & x1) ^ (x2 & x3) ^ (x4 & x5);
}

static uint32_t mxc_b_value(uint64_t regs[MXC_REGS][MXC_REG_WORDS],
                            uint32_t j, uint32_t message_bit)
{
    const uint32_t prev = (j == 0u) ? (MXC_REGS - 1u) : (j - 1u);
    const uint32_t next1 = (j + 1u) % MXC_REGS;
    const uint32_t next3 = (j + 3u) % MXC_REGS;
    const uint32_t next5 = (j + 5u) % MXC_REGS;

    return message_bit
        ^ mxc_sbox6(mxc_get_bit(regs[j], MXC_EXL_5), mxc_get_bit(regs[j], MXC_EXL_2),
                    mxc_get_bit(regs[j], MXC_EXL_4), mxc_get_bit(regs[j], MXC_EXL_1),
                    mxc_get_bit(regs[j], MXC_EXL_3), mxc_get_bit(regs[j], MXC_EXL_0))
        ^ mxc_sbox6(mxc_get_bit(regs[next5], MXC_EXL_3), mxc_get_bit(regs[next5], MXC_EXL_2),
                    mxc_get_bit(regs[next3], MXC_EXL_5), mxc_get_bit(regs[next3], MXC_EXL_1),
                    mxc_get_bit(regs[next1], MXC_EXL_4), mxc_get_bit(regs[next1], MXC_EXL_0))
        ^ mxc_get_bit(regs[prev], MXC_EXL_PREV);
}

static void mxc_step_default(uint64_t regs[MXC_REGS][MXC_REG_WORDS],
                             uint32_t m0, uint32_t m1)
{
    uint64_t old_reg[MXC_REG_WORDS];
    uint32_t j;

    for (j = 0u; j < MXC_REGS; ++j) {
        const uint32_t message_bit = ((j & 1u) == 0u) ? m0 : m1;
        uint32_t b;
        uint32_t t0;
        uint32_t t1;

        memcpy(old_reg, regs[j], sizeof(old_reg));
        b = mxc_b_value(regs, j, message_bit);
        t0 = mxc_get_bit(old_reg, MXC_EXL_0) ^ mxc_get_bit(old_reg, MXC_EXL_1)
           ^ mxc_get_bit(old_reg, MXC_EXL_2) ^ b;
        t1 = mxc_get_bit(old_reg, MXC_EXL_3) ^ mxc_get_bit(old_reg, MXC_EXL_4)
           ^ mxc_get_bit(old_reg, MXC_EXL_5) ^ b;

        mxc_shift_right_one(old_reg, regs[j]);
        mxc_flip_bit(regs[j], MXC_UPL_0 - 1u, t1);
        mxc_flip_bit(regs[j], MXC_UPL_1 - 1u, t1);
        mxc_flip_bit(regs[j], MXC_UPL_2 - 1u, t1);
        mxc_flip_bit(regs[j], MXC_UPL_3 - 1u, t0);
        mxc_flip_bit(regs[j], MXC_UPL_4 - 1u, t0);
        mxc_flip_bit(regs[j], MXC_UPL_5 - 1u, t0);
    }
}

static void mxc_reupfull(uint64_t regs[MXC_REGS][MXC_REG_WORDS],
                         uint32_t constant_bits)
{
    uint64_t old_reg[MXC_REG_WORDS];
    uint32_t j;

    for (j = 0u; j < MXC_REGS; ++j) {
        const uint32_t message_bit = (constant_bits >> j) & 1u;
        uint32_t b;
        uint32_t t0;
        uint32_t t1;

        b = mxc_b_value(regs, j, message_bit);
        t0 = mxc_get_bit(regs[j], MXC_EXL_0) ^ mxc_get_bit(regs[j], MXC_EXL_1)
           ^ mxc_get_bit(regs[j], MXC_EXL_2) ^ b;
        t1 = mxc_get_bit(regs[j], MXC_EXL_3) ^ mxc_get_bit(regs[j], MXC_EXL_4)
           ^ mxc_get_bit(regs[j], MXC_EXL_5) ^ b;

        memcpy(old_reg, regs[j], sizeof(old_reg));
        mxc_flip_bit(old_reg, MXC_UPL_0, t1);
        mxc_flip_bit(old_reg, MXC_UPL_1, t1);
        mxc_flip_bit(old_reg, MXC_UPL_2, t1);
        mxc_flip_bit(old_reg, MXC_UPL_3, t0);
        mxc_flip_bit(old_reg, MXC_UPL_4, t0);
        mxc_flip_bit(old_reg, MXC_UPL_5, t0);
        mxc_shift_right_one(old_reg, regs[j]);
    }
}

static uint32_t mxc_gen1024(uint64_t regs[MXC_REGS][MXC_REG_WORDS])
{
    return mxc_get_bit(regs[6], MXC_EXL_0) ^ mxc_get_bit(regs[4], MXC_EXL_0)
         ^ (mxc_get_bit(regs[2], MXC_EXL_0) & mxc_get_bit(regs[0], MXC_EXL_0));
}

/* Finalization constant stream: bit `bit_index` of the stream that starts at
 * padded_bits in the cyclic concatenation of the eight initial constants. */
static uint32_t mxc_constant_stream_bit(uint64_t padded_bits, uint64_t bit_index)
{
    const uint64_t position = (padded_bits + bit_index) % (uint64_t)MXC_STREAM_BITS;
    const uint32_t constant_index = (uint32_t)(position / (uint64_t)MXC_REG_BITS);
    const uint32_t bit_in_constant = (uint32_t)(position % (uint64_t)MXC_REG_BITS);

    return mxc_get_bit(k_mxc_init[constant_index], bit_in_constant);
}

static uint32_t mxc_constant_byte(uint64_t padded_bits, uint64_t beat)
{
    uint32_t bits = 0u;
    uint32_t j;

    for (j = 0u; j < MXC_REGS; ++j) {
        bits |= (uint32_t)mxc_constant_stream_bit(padded_bits, beat * 8ull + j) << j;
    }
    return bits;
}

/* ------------------------------------------------------------------ */
/* AVX2 SoA32 core                                                      */
/* ------------------------------------------------------------------ */

typedef struct {
    __m256i w0l;
    __m256i w0h;
    __m256i w1l;
    __m256i w1h;
    __m256i w2l;
    __m256i w2h;
} mxc_soa32;

static void mxc_soa32_init(mxc_soa32* s)
{
    uint32_t a[MXC_REGS];
    uint32_t b[MXC_REGS];
    uint32_t c[MXC_REGS];
    uint32_t d[MXC_REGS];
    uint32_t e[MXC_REGS];
    uint32_t f[MXC_REGS];
    uint32_t i;

    for (i = 0u; i < MXC_REGS; ++i) {
        a[i] = (uint32_t)k_mxc_init[i][0];
        b[i] = (uint32_t)(k_mxc_init[i][0] >> 32);
        c[i] = (uint32_t)k_mxc_init[i][1];
        d[i] = (uint32_t)(k_mxc_init[i][1] >> 32);
        e[i] = (uint32_t)k_mxc_init[i][2];
        f[i] = (uint32_t)(k_mxc_init[i][2] >> 32);
    }
    s->w0l = _mm256_loadu_si256((const __m256i*)(const void*)a);
    s->w0h = _mm256_loadu_si256((const __m256i*)(const void*)b);
    s->w1l = _mm256_loadu_si256((const __m256i*)(const void*)c);
    s->w1h = _mm256_loadu_si256((const __m256i*)(const void*)d);
    s->w2l = _mm256_loadu_si256((const __m256i*)(const void*)e);
    s->w2h = _mm256_loadu_si256((const __m256i*)(const void*)f);
}

/* Extract the 32-beat window [bit_index, bit_index+32) of every register. */
static inline __m256i mxc_extract_seq(__m256i w0l, __m256i w0h, __m256i w1l,
                                      __m256i w1h, __m256i w2l, __m256i w2h,
                                      uint32_t bit_index)
{
    __m256i lo;
    __m256i hi;
    uint32_t shift;

    if (bit_index < 32u) {
        lo = w0l; hi = w0h; shift = bit_index;
    } else if (bit_index < 64u) {
        lo = w0h; hi = w1l; shift = bit_index - 32u;
    } else if (bit_index < 96u) {
        lo = w1l; hi = w1h; shift = bit_index - 64u;
    } else if (bit_index < 128u) {
        lo = w1h; hi = w2l; shift = bit_index - 96u;
    } else {
        lo = w2l; hi = w2h; shift = bit_index - 128u;
    }

    return _mm256_or_si256(
        _mm256_srlv_epi32(lo, _mm256_set1_epi32((int)shift)),
        _mm256_sllv_epi32(hi, _mm256_set1_epi32((int)(32u - shift))));
}

/* One 32-beat UpFull block.  Lane j is register j; bit k of a lane is beat k.
 * Waso: registers already updated inside a beat are tapped one bit further
 * along the shift chain (mask selects those lanes). */
static inline void mxc_step_vec(mxc_soa32* s, const __m256i m)
{
    const __m256i w0l = s->w0l;
    const __m256i w0h = s->w0h;
    const __m256i w1l = s->w1l;
    const __m256i w1h = s->w1h;
    const __m256i w2l = s->w2l;
    const __m256i w2h = s->w2h;
    const __m256i e0 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_0);
    const __m256i e1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_1);
    const __m256i e2 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_2);
    const __m256i e3 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_3);
    const __m256i e4 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_4);
    const __m256i e5 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_5);
    const __m256i e0a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_0 + 1u);
    const __m256i e1a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_1 + 1u);
    const __m256i e2a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_2 + 1u);
    const __m256i e3a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_3 + 1u);
    const __m256i e4a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_4 + 1u);
    const __m256i e5a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_5 + 1u);
    const __m256i prev0 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_PREV);
    const __m256i prev1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_PREV + 1u);
    const __m256i perm_next1 = _mm256_setr_epi32(1, 2, 3, 4, 5, 6, 7, 0);
    const __m256i perm_next3 = _mm256_setr_epi32(3, 4, 5, 6, 7, 0, 1, 2);
    const __m256i perm_next5 = _mm256_setr_epi32(5, 6, 7, 0, 1, 2, 3, 4);
    const __m256i perm_prev = _mm256_setr_epi32(7, 0, 1, 2, 3, 4, 5, 6);
    const __m256i t0v = _mm256_xor_si256(_mm256_xor_si256(e0, e1), e2);
    const __m256i t1v = _mm256_xor_si256(_mm256_xor_si256(e3, e4), e5);
    __m256i n5e3;
    __m256i n5e2;
    __m256i n3e5;
    __m256i n3e1;
    __m256i n1e4;
    __m256i n1e0;
    __m256i sbox_current;
    __m256i sbox_new;
    __m256i prev;
    __m256i bvec;
    __m256i t0;
    __m256i t1;

    n5e3 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e3, perm_next5),
                              _mm256_permutevar8x32_epi32(e3a1, perm_next5), 0xF8);
    n5e2 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e2, perm_next5),
                              _mm256_permutevar8x32_epi32(e2a1, perm_next5), 0xF8);
    n3e5 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e5, perm_next3),
                              _mm256_permutevar8x32_epi32(e5a1, perm_next3), 0xE0);
    n3e1 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e1, perm_next3),
                              _mm256_permutevar8x32_epi32(e1a1, perm_next3), 0xE0);
    n1e4 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e4, perm_next1),
                              _mm256_permutevar8x32_epi32(e4a1, perm_next1), 0x80);
    n1e0 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e0, perm_next1),
                              _mm256_permutevar8x32_epi32(e0a1, perm_next1), 0x80);

    sbox_current = _mm256_xor_si256(
        _mm256_xor_si256(_mm256_and_si256(e5, e2), _mm256_and_si256(e4, e1)),
        _mm256_and_si256(e3, e0));
    sbox_new = _mm256_xor_si256(
        _mm256_xor_si256(_mm256_and_si256(n5e3, n5e2), _mm256_and_si256(n3e5, n3e1)),
        _mm256_and_si256(n1e4, n1e0));
    prev = _mm256_permutevar8x32_epi32(prev0, perm_prev);
    prev = _mm256_blend_epi32(prev, _mm256_permutevar8x32_epi32(prev1, perm_prev), 0xFE);
    bvec = _mm256_xor_si256(_mm256_xor_si256(m, sbox_current),
                            _mm256_xor_si256(sbox_new, prev));
    t0 = _mm256_xor_si256(t0v, bvec);
    t1 = _mm256_xor_si256(t1v, bvec);

    s->w0l = w0h;
    s->w0h = _mm256_xor_si256(w1l,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_slli_epi32(t1, 26), _mm256_slli_epi32(t1, 11)),
                         _mm256_slli_epi32(t1, 2)));
    s->w1l = _mm256_xor_si256(w1h,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_srli_epi32(t1, 6), _mm256_srli_epi32(t1, 21)),
                         _mm256_srli_epi32(t1, 30)));
    s->w1h = w2l;
    s->w2l = _mm256_xor_si256(w2h,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_slli_epi32(t0, 28), _mm256_slli_epi32(t0, 18)),
                         _mm256_slli_epi32(t0, 2)));
    s->w2h = _mm256_xor_si256(w0l,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_srli_epi32(t0, 4), _mm256_srli_epi32(t0, 14)),
                         _mm256_srli_epi32(t0, 30)));
}

static inline void mxc_step_same(mxc_soa32* s, uint32_t seq)
{
    mxc_step_vec(s, _mm256_set1_epi32((int)seq));
}

static inline void mxc_step_rows(mxc_soa32* s, const uint32_t seq[MXC_REGS])
{
    mxc_step_vec(s, _mm256_setr_epi32((int)seq[0], (int)seq[1], (int)seq[2], (int)seq[3],
                                      (int)seq[4], (int)seq[5], (int)seq[6], (int)seq[7]));
}

/* AXIS-1024 digest generator for the block path: bits 0..31 of register word 0. */
static inline uint32_t mxc_h0_seq(const mxc_soa32* s)
{
    uint32_t v[MXC_REGS];

    _mm256_storeu_si256((__m256i*)(void*)v, s->w0l);
    return v[6] ^ v[4] ^ (v[2] & v[0]);
}

static void mxc_write_digest_seq32(uint8_t* out, uint32_t beat, uint32_t seq)
{
    /* The reference writes these 32 bits one at a time at digest bit index
     * bit_index = (1023 - beat - k) for seq bit k, at in-byte position
     * (7 - (bit_index & 7)).  For beat a multiple of 32 that places seq bit k
     * at byte (124 - beat/8 + (k >> 3)) and bit position (k & 7) -- i.e. the 32
     * bits are exactly the four bytes of seq in reverse byte order with NO bit
     * reversal inside a byte (verified against the reference writer in
     * axis/gates/t_digest.c).  Reversing the byte order while writing
     * little-endian is therefore a plain byte swap. */
    uint32_t x = seq;

    x = ((x & 0x00FF00FFu) << 8) | ((x >> 8) & 0x00FF00FFu);
    x = (x << 16) | (x >> 16);
    memcpy(out + ((MXC_DIGEST_BYTES - 4u) - (beat >> 3)), &x, 4u);
}

/* The finalization constant stream has period 1536/256 = 6 in the 32-beat
 * block index, so the 32 blank blocks and the 32 digest blocks need only six
 * distinct 8x32-bit message rows. */
static void mxc_constant_rows(uint64_t padded_bits, uint32_t rows[6][MXC_REGS])
{
    /* padded_bits is always a multiple of 64, so byte offset
     * (padded_bits/8 + 32r) mod 192 is where row r starts in the constant
     * stream.  Row r, word j, bit k is stream bit (base + 8k + j), i.e. bit j
     * of stream byte (base + k): one 32-byte bit-transpose per row. */
    const uint32_t o = (uint32_t)((padded_bits >> 3) % 192ull);
    uint32_t r;

    for (r = 0u; r < 6u; ++r) {
        const __m256i w = _mm256_loadu_si256(
            (const __m256i*)(const void*)(k_mxc_stream384 + o + 32u * r));
        uint32_t j;

        for (j = 0u; j < MXC_REGS; ++j) {
            rows[r][j] = (uint32_t)_mm256_movemask_epi8(
                _mm256_slli_epi16(w, (int)(7u - j)));
        }
    }
}

static uint32_t mxc_padded_bit(const uint8_t* msg, uint64_t message_bits,
                               uint64_t zero_count, uint64_t length_bits,
                               uint64_t padded_index)
{
    if (padded_index < message_bits) {
        return (uint32_t)((msg[padded_index >> 3] >> (7u - (padded_index & 7u))) & 1u);
    }
    padded_index -= message_bits;
    if (padded_index == 0ull) {
        return 1u;
    }
    --padded_index;
    if (padded_index < zero_count) {
        return 0u;
    }
    padded_index -= zero_count;
    if (padded_index == 0ull) {
        return 1u;
    }
    --padded_index;
    return (uint32_t)((length_bits >> (63u - padded_index)) & 1ull);
}

/* ------------------------------------------------------------------ */
/* public entry points                                                  */
/* ------------------------------------------------------------------ */

/* Uniform 32-beat block driver; valid for every bit length because
 * padded_bits is always a multiple of 64. */
int mxc_axis1024_hash_bits(const unsigned char* msg, unsigned long long msg_len_bits,
                           unsigned char* digest)
{
    const uint64_t message_bits = (uint64_t)msg_len_bits;
    const uint64_t zero_count = (64ull - ((message_bits + 2ull) & 63ull)) & 63ull;
    const uint64_t padded_bits = message_bits + 2ull + zero_count + 64ull;
    const uint64_t length_bits = message_bits;
    const int byte_aligned = ((message_bits & 7ull) == 0ull);
    mxc_soa32 s;
    uint32_t rows[6][MXC_REGS];
    uint64_t offset;
    uint32_t b;

    memset(digest, 0, MXC_DIGEST_BYTES);
    mxc_soa32_init(&s);

    for (offset = 0ull; offset + 32ull <= padded_bits; offset += 32ull) {
        const uint64_t top_index = padded_bits - 1ull - offset;
        uint32_t seq;

        if (byte_aligned && top_index < message_bits) {
            uint32_t word;
            memcpy(&word, msg + (top_index >> 3) - 3ull, sizeof(word));
            seq = (uint32_t)__builtin_bswap32(word);
        } else {
            uint32_t k;
            seq = 0u;
            for (k = 0u; k < 32u; ++k) {
                seq |= mxc_padded_bit(msg, message_bits, zero_count, length_bits,
                                      top_index - k) << k;
            }
        }
        mxc_step_same(&s, seq);
    }

    mxc_constant_rows(padded_bits, rows);
    for (b = 0u; b < 32u; ++b) {
        mxc_step_rows(&s, rows[b % 6u]);
    }
    for (b = 0u; b < 32u; ++b) {
        const uint32_t h0 = mxc_h0_seq(&s);
        mxc_write_digest_seq32(digest, 32u * b, h0);
        mxc_step_rows(&s, rows[(b + 2u) % 6u]);
    }
    return 0;
}

/* Bit-exact scalar mirror of the reference generic path; used for
 * differential testing, not by CryptHash(). */
int mxc_axis1024_hash_bits_generic(const unsigned char* msg, unsigned long long msg_len_bits,
                                   unsigned char* digest)
{
    const uint64_t message_bits = (uint64_t)msg_len_bits;
    const uint64_t zero_count = (64ull - ((message_bits + 2ull) & 63ull)) & 63ull;
    const uint64_t padded_bits = message_bits + 2ull + zero_count + 64ull;
    const uint64_t length_bits = message_bits;
    uint64_t regs[MXC_REGS][MXC_REG_WORDS];
    uint64_t offset;

    memset(digest, 0, MXC_DIGEST_BYTES);
    memcpy(regs, k_mxc_init, sizeof(regs));

    for (offset = 0ull; offset < padded_bits; ++offset) {
        const uint32_t bit = mxc_padded_bit(msg, message_bits, zero_count, length_bits,
                                            padded_bits - 1ull - offset);
        mxc_step_default(regs, bit, bit);
    }
    for (offset = 0ull; offset < (uint64_t)MXC_BLANK_ROUNDS; ++offset) {
        mxc_reupfull(regs, mxc_constant_byte(padded_bits, offset));
    }
    for (offset = 0ull; offset < (uint64_t)MXC_DIGEST_BITS; ++offset) {
        const uint32_t bit = mxc_gen1024(regs);
        const uint32_t bit_index = MXC_DIGEST_BITS - 1u - (uint32_t)offset;

        if (bit != 0u) {
            digest[bit_index >> 3] |= (uint8_t)(1u << (7u - (bit_index & 7u)));
        }
        mxc_reupfull(regs, mxc_constant_byte(padded_bits, (uint64_t)MXC_BLANK_ROUNDS + offset));
    }
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char* msg,
              unsigned long long msg_len_bits, unsigned char* digest)
{
    if (digest == 0) {
        return -1;
    }
    if (digest_len_bits != (int)MXC_DIGEST_BITS) {
        return -2;
    }
    if (msg_len_bits > 0ull && msg == 0) {
        return -3;
    }
    return mxc_axis1024_hash_bits(msg, msg_len_bits, digest);
}
