#!/usr/bin/env bash
# Build our AXIS-1024 deliverable with exactly the official performance flags.
set -euo pipefail

L0=/mnt/c/Users/von/WorkBuddy/2026-10-30-16-05-28/feilian/work/_overnight/l0
SRC="$L0/axis/src/axis1024.c"
OUT="$L0/axis/out/ours_axis1024.so"

FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra)

mkdir -p "$L0/axis/out"
python3 "$L0/axis/gates/gen_stream.py"
gcc "${FLAGS[@]}" -fPIC -shared -o "$OUT" "$SRC"
echo "built: $OUT"
ls -l "$OUT"
sha256sum "$OUT"
