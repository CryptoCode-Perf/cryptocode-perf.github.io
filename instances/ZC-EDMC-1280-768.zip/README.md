# ZC-EDMC-1280-768

Algorithm: ZC-EDMC | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header ZC-EDMC-1280-768.h, prebuilt ZC-EDMC-1280-768.so,
KAT vector KAT_2_12_ZC-EDMC-1280-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 2134d06d8c8fb07eace78e2f553d1766f65f16fad060e961cb9265794fe1bfee
Speed (cpB, lower is faster): reference 7.55 / official-optimized 6.06 / optimized 5.78
Speedup: GM(S1-S8) 1.07x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
