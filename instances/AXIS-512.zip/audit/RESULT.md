# AXIS — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| AXIS-1024 | `AXIS-1024.so` | 19504 B | `3a6485e771fc4b4f01f9374cd44c8fd0f73195b4b9eeef8319ff556a9d5b1694` |
| AXIS-512 | `AXIS-512.so` | 35760 B | `8f4a4398db2b5c83f9f9ff5cde6eb913ae592754dab147f9d0170b15b42eb5e9` |
| AXIS-768 | `AXIS-768.so` | 35760 B | `8f4a4398db2b5c83f9f9ff5cde6eb913ae592754dab147f9d0170b15b42eb5e9` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| AXIS-1024 | 1024 | 74.8154 | 27.3398 | 2.97457 | 9.191176 | 5.7303 |
| AXIS-512 | 512 | 58.7588 | 19.8458 | 8.5288 | 2.3269 | 1.8322 |
| AXIS-768 | 768 | 100.7988 | 24.4185 | 12.3952 | 1.97 | 1.6092 |

## 优化方法（逐实例原文，来自交付清单）

### AXIS-1024
官方 `axis_core.c` 有两处结构性冗余：定稿常数流每轮用 64 次逐位重建、摘要用 32 次逐位 OR 拼装；我方改成 6 行一次构造 + 1 次字节交换写，并把三阶段吸收卷积成统一的 32-beat 块驱动。动态指令数 1024 bit 处 18715 vs 对手 239603 = 0.078×。**对手按官方 `Makefile` 默认目标 `CFLAGS_BEST` 重编**（`-funroll-loops -march=native -frename-registers -DAXIS_OPT_LEVEL=3`，65576 B，KAT 4097/4097），不是 `build/` 里用通用十 flag 编的弱件。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。

### AXIS-512
**胜因 = 官方把定稿常数流每轮用 64 次逐位重建、摘要用 32 次逐位 OR 拼装**；我方改成 6 行一次构造 + 1 次字节交换写，并把三阶段吸收卷积成统一的 32-beat 块驱动（`axis/src/axis_tiers.c`，一份源码覆盖 512/768/1024 三档）。AXIS 官方三档 `axis_core.c` 逐字节相同（只差 3 处空白行），`def.h` 里 8 寄存器、`AXIS_INIT_WORDS`、EXL/UPL、`BLANK_ROUNDS` 全同，三档真正的差异只有「吸收块长 64/48/32 bit」与「摘要挤出规则」。**对手按官方 `Makefile` 默认目标 `CFLAGS_BEST` 重编**（`-funroll-loops -frename-registers -march=native -mtune=native -DAXIS_OPT_LEVEL=3`，65576 B，KAT 4097/4097），不是 `build/` 里用通用十 flag 编的弱件。脚本 `_overnight/l0/axis/build_tiers.sh` + `_build_axis512_768_contract_opp.py`。本档 gm 0.2676 ⇒ 快 73.24%（A/A 地板 1.58%、spread 19.06%）；32 B 高 9.4 倍、64 KiB 回落到 0.77 倍。全量 KAT 4097/4097 通过（`MAX_RECORDS=1e9`，ref/opt/ours 三侧）；计时为 captain 串行 `_ab_pair.py --reps 5 --pairs 60`，`digest 全同=True`、`credible=True`。构建用官方十 flag 逐字，无反汇编可见的 BMI2 / AES-NI。

### AXIS-768
**胜因 = 官方把定稿常数流每轮用 64 次逐位重建、摘要用 32 次逐位 OR 拼装**；我方改成 6 行一次构造 + 1 次字节交换写，并把三阶段吸收卷积成统一的 32-beat 块驱动（`axis/src/axis_tiers.c`，一份源码覆盖 512/768/1024 三档）。AXIS 官方三档 `axis_core.c` 逐字节相同（只差 3 处空白行），`def.h` 里 8 寄存器、`AXIS_INIT_WORDS`、EXL/UPL、`BLANK_ROUNDS` 全同，三档真正的差异只有「吸收块长 64/48/32 bit」与「摘要挤出规则」。**对手按官方 `Makefile` 默认目标 `CFLAGS_BEST` 重编**（`-funroll-loops -frename-registers -march=native -mtune=native -DAXIS_OPT_LEVEL=3`，65576 B，KAT 4097/4097），不是 `build/` 里用通用十 flag 编的弱件。脚本 `_overnight/l0/axis/build_tiers.sh` + `_build_axis512_768_contract_opp.py`。本档 768 的挤出头是 h0/h1 交替 1+2 bit（16 组 ×32 beat = 768 bit），吸收块长 48 bit 且需要 `mixed_bits` 与单 bit 尾巴；gm 0.3295 ⇒ 快 67.05%（A/A 地板 1.14%、spread 13.35%）；32 B 高 6.9 倍、64 KiB 回落到 0.74 倍。全量 KAT 4097/4097 通过（`MAX_RECORDS=1e9`，ref/opt/ours 三侧）；计时为 captain 串行 `_ab_pair.py --reps 5 --pairs 60`，`digest 全同=True`、`credible=True`。构建用官方十 flag 逐字，无反汇编可见的 BMI2 / AES-NI。
