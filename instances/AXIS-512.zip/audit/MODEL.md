# AXIS — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## AXIS-1024
- 摘要位：1024；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/AXIS-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/AXIS-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/AXIS-1024/`
- 优化要点：官方 `axis_core.c` 有两处结构性冗余：定稿常数流每轮用 64 次逐位重建、摘要用 32 次逐位 OR 拼装；我方改成 6 行一次构造 + 1 次字节交换写，并把三阶段吸收卷积成统一的 32-beat 块驱动。动态指令数 1024 bit 处 18715 vs 对手 239603 = 0.078×。**对手按官方 `Makefile` 默认目标 `CFLAGS_BEST` 重编**（`-funroll-loops -march=native -frename-registers -DAXIS_OPT_LEVEL=3`，65576 B，KAT 4097/4097），不是 `build/` 里用通用十 flag 编的弱件。 等价性：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。

## AXIS-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/AXIS-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/AXIS-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/AXIS-512/`
- 优化要点：**胜因 = 官方把定稿常数流每轮用 64 次逐位重建、摘要用 32 次逐位 OR 拼装**；我方改成 6 行一次构造 + 1 次字节交换写，并把三阶段吸收卷积成统一的 32-beat 块驱动（`axis/src/axis_tiers.c`，一份源码覆盖 512/768/1024 三档）。AXIS 官方三档 `axis_core.c` 逐字节相同（只差 3 处空白行），`def.h` 里 8 寄存器、`AXIS_INIT_WORDS`、EXL/UPL、`BLANK_ROUNDS` 全同，三档真正的差异只有「吸收块长 64/48/32 bit」与「摘要挤出规则」。**对手按官方 `Makefile` 默认目标 `CFLAGS_BEST` 重编**（`-funroll-loops -frename-registers -march=native -mtune=native -DAXIS_OPT

## AXIS-768
- 摘要位：768；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/AXIS-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/AXIS-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/AXIS-768/`
- 优化要点：**胜因 = 官方把定稿常数流每轮用 64 次逐位重建、摘要用 32 次逐位 OR 拼装**；我方改成 6 行一次构造 + 1 次字节交换写，并把三阶段吸收卷积成统一的 32-beat 块驱动（`axis/src/axis_tiers.c`，一份源码覆盖 512/768/1024 三档）。AXIS 官方三档 `axis_core.c` 逐字节相同（只差 3 处空白行），`def.h` 里 8 寄存器、`AXIS_INIT_WORDS`、EXL/UPL、`BLANK_ROUNDS` 全同，三档真正的差异只有「吸收块长 64/48/32 bit」与「摘要挤出规则」。**对手按官方 `Makefile` 默认目标 `CFLAGS_BEST` 重编**（`-funroll-loops -frename-registers -march=native -mtune=native -DAXIS_OPT
