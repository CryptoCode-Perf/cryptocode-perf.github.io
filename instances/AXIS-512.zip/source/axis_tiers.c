/*
 * AXIS-512 / AXIS-768 / AXIS-1024 (candidate hash-02) -- one parameterised
 * implementation covering all three digest sizes.
 *
 * The three official variants share everything except
 *   (a) the number of message bits consumed per 32-beat block
 *       (512 -> 64, 768 -> 48, 1024 -> 32), and
 *   (b) the digest extraction rule
 *       (512 -> h0+h1, 2 bits/beat, 256 beats;
 *        768 -> h0/h1 alternating 1+2 bits, 16 groups of 32 beats = 768 bits;
 *        1024 -> h0 only, 1 bit/beat, 1024 beats).
 * The 32-beat SoA kernel, the register constants (init / EXL / UPL), the
 * padding rule and the finalisation constant stream (period 1536 bits, i.e.
 * 6 distinct 32-beat message rows) are identical across the three variants.
 *
 * Reference semantics read from
 *   _overnight/l0/src/hash-02/AXIS/Implementations/Optimized_Implementation/AXIS-1024/
 * (AXIS-512/768/1024 axis_core.c differ by three blank lines only).
 *
 * No #pragma GCC target; built with the official ten flags only, therefore
 * no BMI2 (_pext_u64) and no AES: the packing paths below are the official
 * non-BMI2 baseline routings.
 */

#include <stdint.h>
#include <string.h>
#include <immintrin.h>

#include "axis1024_stream.h"

#define MXC_EXL_0 0u
#define MXC_EXL_1 12u
#define MXC_EXL_2 32u
#define MXC_EXL_3 96u
#define MXC_EXL_4 107u
#define MXC_EXL_5 125u
#define MXC_EXL_PREV 11u

#define MXC_UPL_0 66u
#define MXC_UPL_1 75u
#define MXC_UPL_2 90u
#define MXC_UPL_3 162u
#define MXC_UPL_4 178u
#define MXC_UPL_5 188u

#define MXC_REG_BITS 192u
#define MXC_REGS 8u
#define MXC_BLANK_ROUNDS 1024u
#define MXC_MAX_DIGEST_BITS 1024u
#define MXC_MAX_DIGEST_BYTES (MXC_MAX_DIGEST_BITS / 8u) /* 128 */

/* Document initial constants. */
static const uint64_t k_mxc_init[MXC_REGS][3] = {
    {0x9E3779B97F4A7C15ULL, 0xB7E151628AED2A6AULL, 0x243F6A8885A308D3ULL},
    {0x49CA76E19F938DA4ULL, 0xD81F8650363C93F8ULL, 0x7160C6B758B90A76ULL},
    {0xCD71C257B752EEB5ULL, 0xB54CBDE35B659CC7ULL, 0x70FF7724ACB762F7ULL},
    {0x47EA14CFA7D43857ULL, 0x3120355B0549D6B9ULL, 0x4FD6E6B4FBAB7ECDULL},
    {0x5DCD2735332E4029ULL, 0x03F92D7B7FAEEF10ULL, 0x6B634EF404919AAAULL},
    {0xD57AC41E845348D4ULL, 0xCD0814056FA6E00BULL, 0x53C1A2C96C4DE7E3ULL},
    {0xABDBF53A09476735ULL, 0x352FF6633C6EFBA6ULL, 0xF3FF90522F99DAE5ULL},
    {0x0D875B906F276D2CULL, 0xD94570230179F812ULL, 0xB1A270D3653FB5B8ULL}
};

/* ------------------------------------------------------------------ */
/* 32-beat SoA AVX2 kernel (unchanged from our AXIS-1024 delivery)      */
/* ------------------------------------------------------------------ */

typedef struct {
    __m256i w0l;
    __m256i w0h;
    __m256i w1l;
    __m256i w1h;
    __m256i w2l;
    __m256i w2h;
} mxc_soa32;

static void mxc_soa32_init(mxc_soa32* s)
{
    uint32_t j;
    uint32_t low[MXC_REGS];
    uint32_t high[MXC_REGS];

    for (j = 0u; j < MXC_REGS; ++j) {
        low[j] = (uint32_t)(k_mxc_init[j][0] & 0xFFFFFFFFull);
        high[j] = (uint32_t)(k_mxc_init[j][0] >> 32);
    }
    s->w0l = _mm256_setr_epi32((int)low[0], (int)low[1], (int)low[2], (int)low[3],
                               (int)low[4], (int)low[5], (int)low[6], (int)low[7]);
    s->w0h = _mm256_setr_epi32((int)high[0], (int)high[1], (int)high[2], (int)high[3],
                               (int)high[4], (int)high[5], (int)high[6], (int)high[7]);
    for (j = 0u; j < MXC_REGS; ++j) {
        low[j] = (uint32_t)(k_mxc_init[j][1] & 0xFFFFFFFFull);
        high[j] = (uint32_t)(k_mxc_init[j][1] >> 32);
    }
    s->w1l = _mm256_setr_epi32((int)low[0], (int)low[1], (int)low[2], (int)low[3],
                               (int)low[4], (int)low[5], (int)low[6], (int)low[7]);
    s->w1h = _mm256_setr_epi32((int)high[0], (int)high[1], (int)high[2], (int)high[3],
                               (int)high[4], (int)high[5], (int)high[6], (int)high[7]);
    for (j = 0u; j < MXC_REGS; ++j) {
        low[j] = (uint32_t)(k_mxc_init[j][2] & 0xFFFFFFFFull);
        high[j] = (uint32_t)(k_mxc_init[j][2] >> 32);
    }
    s->w2l = _mm256_setr_epi32((int)low[0], (int)low[1], (int)low[2], (int)low[3],
                               (int)low[4], (int)low[5], (int)low[6], (int)low[7]);
    s->w2h = _mm256_setr_epi32((int)high[0], (int)high[1], (int)high[2], (int)high[3],
                               (int)high[4], (int)high[5], (int)high[6], (int)high[7]);
}

/* 32 consecutive bits of every lane starting at bit_index (lane j = register j). */
static inline __m256i mxc_extract_seq(__m256i w0l, __m256i w0h, __m256i w1l,
                                      __m256i w1h, __m256i w2l, __m256i w2h,
                                      uint32_t bit_index)
{
    __m256i lo;
    __m256i hi;
    uint32_t shift;

    if (bit_index < 32u) {
        lo = w0l; hi = w0h; shift = bit_index;
    } else if (bit_index < 64u) {
        lo = w0h; hi = w1l; shift = bit_index - 32u;
    } else if (bit_index < 96u) {
        lo = w1l; hi = w1h; shift = bit_index - 64u;
    } else if (bit_index < 128u) {
        lo = w1h; hi = w2l; shift = bit_index - 96u;
    } else {
        lo = w2l; hi = w2h; shift = bit_index - 128u;
    }

    return _mm256_or_si256(
        _mm256_srlv_epi32(lo, _mm256_set1_epi32((int)shift)),
        _mm256_sllv_epi32(hi, _mm256_set1_epi32((int)(32u - shift))));
}

/* One 32-beat UpFull block.  Lane j is register j; bit k of a lane is beat k. */
static inline void mxc_step_vec(mxc_soa32* s, const __m256i m)
{
    const __m256i w0l = s->w0l;
    const __m256i w0h = s->w0h;
    const __m256i w1l = s->w1l;
    const __m256i w1h = s->w1h;
    const __m256i w2l = s->w2l;
    const __m256i w2h = s->w2h;
    const __m256i e0 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_0);
    const __m256i e1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_1);
    const __m256i e2 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_2);
    const __m256i e3 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_3);
    const __m256i e4 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_4);
    const __m256i e5 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_5);
    const __m256i e0a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_0 + 1u);
    const __m256i e1a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_1 + 1u);
    const __m256i e2a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_2 + 1u);
    const __m256i e3a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_3 + 1u);
    const __m256i e4a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_4 + 1u);
    const __m256i e5a1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_5 + 1u);
    const __m256i prev0 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_PREV);
    const __m256i prev1 = mxc_extract_seq(w0l, w0h, w1l, w1h, w2l, w2h, MXC_EXL_PREV + 1u);
    const __m256i perm_next1 = _mm256_setr_epi32(1, 2, 3, 4, 5, 6, 7, 0);
    const __m256i perm_next3 = _mm256_setr_epi32(3, 4, 5, 6, 7, 0, 1, 2);
    const __m256i perm_next5 = _mm256_setr_epi32(5, 6, 7, 0, 1, 2, 3, 4);
    const __m256i perm_prev = _mm256_setr_epi32(7, 0, 1, 2, 3, 4, 5, 6);
    const __m256i t0v = _mm256_xor_si256(_mm256_xor_si256(e0, e1), e2);
    const __m256i t1v = _mm256_xor_si256(_mm256_xor_si256(e3, e4), e5);
    __m256i n5e3;
    __m256i n5e2;
    __m256i n3e5;
    __m256i n3e1;
    __m256i n1e4;
    __m256i n1e0;
    __m256i sbox_current;
    __m256i sbox_new;
    __m256i prev;
    __m256i bvec;
    __m256i t0;
    __m256i t1;

    n5e3 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e3, perm_next5),
                              _mm256_permutevar8x32_epi32(e3a1, perm_next5), 0xF8);
    n5e2 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e2, perm_next5),
                              _mm256_permutevar8x32_epi32(e2a1, perm_next5), 0xF8);
    n3e5 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e5, perm_next3),
                              _mm256_permutevar8x32_epi32(e5a1, perm_next3), 0xE0);
    n3e1 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e1, perm_next3),
                              _mm256_permutevar8x32_epi32(e1a1, perm_next3), 0xE0);
    n1e4 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e4, perm_next1),
                              _mm256_permutevar8x32_epi32(e4a1, perm_next1), 0x80);
    n1e0 = _mm256_blend_epi32(_mm256_permutevar8x32_epi32(e0, perm_next1),
                              _mm256_permutevar8x32_epi32(e0a1, perm_next1), 0x80);

    sbox_current = _mm256_xor_si256(
        _mm256_xor_si256(_mm256_and_si256(e5, e2), _mm256_and_si256(e4, e1)),
        _mm256_and_si256(e3, e0));
    sbox_new = _mm256_xor_si256(
        _mm256_xor_si256(_mm256_and_si256(n5e3, n5e2), _mm256_and_si256(n3e5, n3e1)),
        _mm256_and_si256(n1e4, n1e0));
    prev = _mm256_permutevar8x32_epi32(prev0, perm_prev);
    prev = _mm256_blend_epi32(prev, _mm256_permutevar8x32_epi32(prev1, perm_prev), 0xFE);
    bvec = _mm256_xor_si256(_mm256_xor_si256(m, sbox_current),
                            _mm256_xor_si256(sbox_new, prev));
    t0 = _mm256_xor_si256(t0v, bvec);
    t1 = _mm256_xor_si256(t1v, bvec);

    s->w0l = w0h;
    s->w0h = _mm256_xor_si256(w1l,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_slli_epi32(t1, 26), _mm256_slli_epi32(t1, 11)),
                         _mm256_slli_epi32(t1, 2)));
    s->w1l = _mm256_xor_si256(w1h,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_srli_epi32(t1, 6), _mm256_srli_epi32(t1, 21)),
                         _mm256_srli_epi32(t1, 30)));
    s->w1h = w2l;
    s->w2l = _mm256_xor_si256(w2h,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_slli_epi32(t0, 28), _mm256_slli_epi32(t0, 18)),
                         _mm256_slli_epi32(t0, 2)));
    s->w2h = _mm256_xor_si256(w0l,
        _mm256_xor_si256(_mm256_xor_si256(_mm256_srli_epi32(t0, 4), _mm256_srli_epi32(t0, 14)),
                         _mm256_srli_epi32(t0, 30)));
}

static inline void mxc_step_same(mxc_soa32* s, uint32_t seq)
{
    mxc_step_vec(s, _mm256_set1_epi32((int)seq));
}

static inline void mxc_step_rows(mxc_soa32* s, const uint32_t seq[MXC_REGS])
{
    mxc_step_vec(s, _mm256_setr_epi32((int)seq[0], (int)seq[1], (int)seq[2], (int)seq[3],
                                      (int)seq[4], (int)seq[5], (int)seq[6], (int)seq[7]));
}

/* h0 uses registers 6,4,2,0; h1 uses 7,5,3,1 -- both at bit EXL_0 of word 0. */
static inline uint32_t mxc_h0_seq(const mxc_soa32* s)
{
    uint32_t v[MXC_REGS];

    _mm256_storeu_si256((__m256i*)(void*)v, s->w0l);
    return v[6] ^ v[4] ^ (v[2] & v[0]);
}

static inline uint32_t mxc_h1_seq(const mxc_soa32* s)
{
    uint32_t v[MXC_REGS];

    _mm256_storeu_si256((__m256i*)(void*)v, s->w0l);
    return v[7] ^ v[5] ^ (v[3] & v[1]);
}

/* Finalisation constant stream: period 6 in the 32-beat block index. */
static void mxc_constant_rows(uint64_t padded_bits, uint32_t rows[6][MXC_REGS])
{
    const uint32_t o = (uint32_t)((padded_bits >> 3) % 192ull);
    uint32_t r;

    for (r = 0u; r < 6u; ++r) {
        const __m256i w = _mm256_loadu_si256(
            (const __m256i*)(const void*)(k_mxc_stream384 + o + 32u * r));
        uint32_t j;

        for (j = 0u; j < MXC_REGS; ++j) {
            rows[r][j] = (uint32_t)_mm256_movemask_epi8(
                _mm256_slli_epi16(w, (int)(7u - j)));
        }
    }
}

static uint32_t mxc_padded_bit(const uint8_t* msg, uint64_t message_bits,
                               uint64_t zero_count, uint64_t length_bits,
                               uint64_t padded_index)
{
    if (padded_index < message_bits) {
        return (uint32_t)((msg[padded_index >> 3] >> (7u - (padded_index & 7u))) & 1u);
    }
    padded_index -= message_bits;
    if (padded_index == 0ull) {
        return 1u;
    }
    --padded_index;
    if (padded_index < zero_count) {
        return 0u;
    }
    padded_index -= zero_count;
    if (padded_index == 0ull) {
        return 1u;
    }
    --padded_index;
    return (uint32_t)((length_bits >> (63u - padded_index)) & 1ull);
}

/* ------------------------------------------------------------------ */
/* baseline (non-BMI2) message packers -- transcribed from the official */
/* portable path so that the ten flags alone are enough.                */
/* ------------------------------------------------------------------ */

static uint32_t mxc_pack_even_lsb(uint8_t v)
{
    return (uint32_t)((v & 1u) | (((v >> 2) & 1u) << 1) | (((v >> 4) & 1u) << 2) | (((v >> 6) & 1u) << 3));
}

static uint32_t mxc_pack_odd_lsb(uint8_t v)
{
    return (uint32_t)(((v >> 1) & 1u) | (((v >> 3) & 1u) << 1) | (((v >> 5) & 1u) << 2) | (((v >> 7) & 1u) << 3));
}

/* One 64-bit block (consumed high-to-low) -> m1 = even offsets, m0 = odd ones. */
static void mxc_pack64(const uint8_t* block, uint32_t* m0_seq, uint32_t* m1_seq)
{
    uint32_t even = 0u;
    uint32_t odd = 0u;
    uint32_t j;

    for (j = 0u; j < 8u; ++j) {
        const uint8_t b = block[7u - j];

        even |= mxc_pack_even_lsb(b) << (4u * j);
        odd |= mxc_pack_odd_lsb(b) << (4u * j);
    }
    *m1_seq = even;
    *m0_seq = odd;
}

/* One 48-bit block: 16 three-bit triplets split as (bit0, bit2) / (bit0, bit1). */
static void mxc_pack48(const uint8_t* block, uint32_t* m0_seq, uint32_t* m1_seq)
{
    uint64_t stream = 0ull;
    uint32_t m0 = 0u;
    uint32_t m1 = 0u;
    uint32_t r;

    for (r = 0u; r < 6u; ++r) {
        stream |= (uint64_t)block[5u - r] << (8u * r);
    }
    for (r = 0u; r < 16u; ++r) {
        const uint32_t triplet = (uint32_t)((stream >> (3u * r)) & 7ull);

        m0 |= ((triplet & 1u) != 0u ? 1u : 0u) << (2u * r);
        m0 |= ((triplet & 4u) != 0u ? 1u : 0u) << (2u * r + 1u);
        m1 |= ((triplet & 1u) != 0u ? 1u : 0u) << (2u * r);
        m1 |= ((triplet & 2u) != 0u ? 1u : 0u) << (2u * r + 1u);
    }
    *m0_seq = m0;
    *m1_seq = m1;
}

/* ------------------------------------------------------------------ */
/* digest writers                                                       */
/* ------------------------------------------------------------------ */

static inline void mxc_digest_bit(uint8_t* out, uint32_t bit_index, uint32_t bit)
{
    if (bit != 0u) {
        out[bit_index >> 3] |= (uint8_t)(1u << (7u - (bit_index & 7u)));
    }
}

/* AXIS-1024: one digest bit per beat from h0, most significant bit first. */
static void mxc_write_digest1024(uint8_t* out, uint32_t beat, uint32_t seq)
{
    uint32_t x = seq;

    x = ((x & 0x00FF00FFu) << 8) | ((x >> 8) & 0x00FF00FFu);
    x = (x << 16) | (x >> 16);
    memcpy(out + ((MXC_MAX_DIGEST_BYTES - 4u) - (beat >> 3)), &x, 4u);
}

/* AXIS-512: two digest bits per beat (h0 then h1), 4 beats packed per byte. */
static uint8_t mxc_pack512_byte(uint32_t h0_seq, uint32_t h1_seq, uint32_t group)
{
    const uint32_t shift = group * 4u;
    const uint32_t h0 = (h0_seq >> shift) & 0x0Fu;
    const uint32_t h1 = (h1_seq >> shift) & 0x0Fu;

    return (uint8_t)(
        ((h0 & 8u) << 4)
        | ((h1 & 8u) << 3)
        | ((h0 & 4u) << 3)
        | ((h1 & 4u) << 2)
        | ((h0 & 2u) << 2)
        | ((h1 & 2u) << 1)
        | ((h0 & 1u) << 1)
        | (h1 & 1u));
}

static void mxc_write_digest512(uint8_t* out, uint32_t beat, uint32_t h0_seq, uint32_t h1_seq)
{
    const uint32_t byte_index = (512u - 64u - 2u * beat) >> 3;
    uint32_t g;

    for (g = 0u; g < 8u; ++g) {
        out[byte_index + g] = mxc_pack512_byte(h0_seq, h1_seq, 7u - g);
    }
}

/* AXIS-768: alternating 1-bit (h0) and 2-bit (h0,h1) beats. */
static void mxc_write_digest768(uint8_t* out, uint32_t* bit_index, uint32_t h0_seq, uint32_t h1_seq)
{
    uint32_t k;

    for (k = 0u; k < 32u; ++k) {
        if ((k & 1u) == 0u) {
            mxc_digest_bit(out, 768u - 1u - *bit_index, (h0_seq >> k) & 1u);
            *bit_index += 1u;
        } else {
            mxc_digest_bit(out, 768u - 2u - *bit_index, (h0_seq >> k) & 1u);
            mxc_digest_bit(out, 768u - 1u - *bit_index, (h1_seq >> k) & 1u);
            *bit_index += 2u;
        }
    }
}

/* ------------------------------------------------------------------ */
/* one-shot drivers                                                     */
/* ------------------------------------------------------------------ */

/* Bits left over after the 48-bit blocks of AXIS-768 (64, 32 or 0). */
static uint64_t mxc_768_one_bit_tail(uint64_t padded_bits)
{
    const uint64_t m = (padded_bits >> 6) % 3ull;

    return (m == 1ull) ? 64ull : ((m == 2ull) ? 32ull : 0ull);
}

static void mxc_finalise(mxc_soa32* s, uint64_t padded_bits, uint8_t* digest,
                         uint32_t groups, uint32_t variant)
{
    uint32_t rows[6][MXC_REGS];
    uint32_t g;

    mxc_constant_rows(padded_bits, rows);
    for (g = 0u; g < 32u; ++g) {
        mxc_step_rows(s, rows[g % 6u]);
    }
    if (variant == 512u) {
        for (g = 0u; g < groups; ++g) {
            const uint32_t h0 = mxc_h0_seq(s);
            const uint32_t h1 = mxc_h1_seq(s);

            mxc_write_digest512(digest, 32u * g, h0, h1);
            mxc_step_rows(s, rows[(g + 2u) % 6u]);
        }
    } else if (variant == 768u) {
        uint32_t bit_index = 0u;

        for (g = 0u; g < groups; ++g) {
            const uint32_t h0 = mxc_h0_seq(s);
            const uint32_t h1 = mxc_h1_seq(s);

            mxc_write_digest768(digest, &bit_index, h0, h1);
            mxc_step_rows(s, rows[(g + 2u) % 6u]);
        }
    } else {
        for (g = 0u; g < groups; ++g) {
            const uint32_t h0 = mxc_h0_seq(s);

            mxc_write_digest1024(digest, 32u * g, h0);
            mxc_step_rows(s, rows[(g + 2u) % 6u]);
        }
    }
}

/* AXIS-512: 64 message bits per 32-beat block. */
static int mxc_hash512(const uint8_t* msg, uint64_t message_bits, uint8_t* digest)
{
    const uint64_t zero_count = (64ull - ((message_bits + 2ull) & 63ull)) & 63ull;
    const uint64_t padded_bits = message_bits + 2ull + zero_count + 64ull;
    const uint64_t length_bits = message_bits;
    const int byte_aligned = ((message_bits & 7ull) == 0ull);
    mxc_soa32 s;
    uint64_t offset;

    memset(digest, 0, 64u);
    mxc_soa32_init(&s);

    for (offset = 0ull; offset + 64ull <= padded_bits; offset += 64ull) {
        const uint64_t top_index = padded_bits - 1ull - offset;
        uint32_t m0 = 0u;
        uint32_t m1 = 0u;
        uint32_t k;

        if (byte_aligned && top_index < message_bits) {
            break;
        }
        for (k = 0u; k < 32u; ++k) {
            const uint64_t low_index = top_index - (uint64_t)(2u * k);

            m1 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, low_index) << k;
            m0 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, low_index - 1ull) << k;
        }
        mxc_step_vec(&s, _mm256_setr_epi32((int)m0, (int)m1, (int)m0, (int)m1,
                                           (int)m0, (int)m1, (int)m0, (int)m1));
    }
    if (byte_aligned && offset + 64ull <= padded_bits) {
        const uint64_t top_index = padded_bits - 1ull - offset;
        uint64_t pure_blocks = (top_index + 1ull) >> 6;

        if (pure_blocks != 0ull) {
            const uint8_t* block = msg + (top_index >> 3) - 7ull;

            offset += pure_blocks << 6;
            while (pure_blocks != 0ull) {
                uint32_t m0;
                uint32_t m1;

                mxc_pack64(block, &m0, &m1);
                mxc_step_vec(&s, _mm256_setr_epi32((int)m0, (int)m1, (int)m0, (int)m1,
                                                   (int)m0, (int)m1, (int)m0, (int)m1));
                block -= 8;
                --pure_blocks;
            }
        }
    }
    for (; offset + 64ull <= padded_bits; offset += 64ull) {
        const uint64_t top_index = padded_bits - 1ull - offset;
        uint32_t m0 = 0u;
        uint32_t m1 = 0u;
        uint32_t k;

        for (k = 0u; k < 32u; ++k) {
            const uint64_t low_index = top_index - (uint64_t)(2u * k);

            m1 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, low_index) << k;
            m0 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, low_index - 1ull) << k;
        }
        mxc_step_vec(&s, _mm256_setr_epi32((int)m0, (int)m1, (int)m0, (int)m1,
                                           (int)m0, (int)m1, (int)m0, (int)m1));
    }
    mxc_finalise(&s, padded_bits, digest, 8u, 512u);
    return 0;
}

/* AXIS-768: 48 message bits per 32-beat block (alternating 1+2 bit beats). */
static int mxc_hash768(const uint8_t* msg, uint64_t message_bits, uint8_t* digest)
{
    const uint64_t zero_count = (64ull - ((message_bits + 2ull) & 63ull)) & 63ull;
    const uint64_t padded_bits = message_bits + 2ull + zero_count + 64ull;
    const uint64_t mixed_bits = padded_bits - mxc_768_one_bit_tail(padded_bits);
    const uint64_t length_bits = message_bits;
    const int byte_aligned = ((message_bits & 7ull) == 0ull);
    mxc_soa32 s;
    uint64_t offset;

    memset(digest, 0, 96u);
    mxc_soa32_init(&s);

    for (offset = 0ull; offset + 48ull <= mixed_bits; offset += 48ull) {
        const uint64_t current_top = padded_bits - 1ull - offset;
        uint64_t block_offset = offset;
        uint32_t m0 = 0u;
        uint32_t m1 = 0u;
        uint32_t k;

        if (byte_aligned && current_top < message_bits) {
            break;
        }
        for (k = 0u; k < 32u; ++k) {
            const uint64_t top_index = padded_bits - 1ull - block_offset;

            if ((k & 1u) == 0u) {
                const uint32_t bit = mxc_padded_bit(msg, message_bits, zero_count, length_bits, top_index);

                m0 |= bit << k;
                m1 |= bit << k;
                block_offset += 1ull;
            } else {
                m0 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, top_index - 1ull) << k;
                m1 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, top_index) << k;
                block_offset += 2ull;
            }
        }
        mxc_step_vec(&s, _mm256_setr_epi32((int)m0, (int)m1, (int)m0, (int)m1,
                                           (int)m0, (int)m1, (int)m0, (int)m1));
    }
    if (byte_aligned) {
        for (; offset + 48ull <= mixed_bits; offset += 48ull) {
            const uint64_t top_index = padded_bits - 1ull - offset;
            const uint8_t* block = msg + (top_index >> 3) - 5ull;
            uint32_t m0;
            uint32_t m1;

            mxc_pack48(block, &m0, &m1);
            mxc_step_vec(&s, _mm256_setr_epi32((int)m0, (int)m1, (int)m0, (int)m1,
                                               (int)m0, (int)m1, (int)m0, (int)m1));
        }
    } else {
        for (; offset + 48ull <= mixed_bits; offset += 48ull) {
            const uint64_t current_top = padded_bits - 1ull - offset;
            uint64_t block_offset = offset;
            uint32_t m0 = 0u;
            uint32_t m1 = 0u;
            uint32_t k;

            for (k = 0u; k < 32u; ++k) {
                const uint64_t top_index = padded_bits - 1ull - block_offset;

                if ((k & 1u) == 0u) {
                    const uint32_t bit = mxc_padded_bit(msg, message_bits, zero_count, length_bits, top_index);

                    m0 |= bit << k;
                    m1 |= bit << k;
                    block_offset += 1ull;
                } else {
                    m0 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, top_index - 1ull) << k;
                    m1 |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, top_index) << k;
                    block_offset += 2ull;
                }
            }
            (void)current_top;
            mxc_step_vec(&s, _mm256_setr_epi32((int)m0, (int)m1, (int)m0, (int)m1,
                                               (int)m0, (int)m1, (int)m0, (int)m1));
        }
    }
    for (; offset + 32ull <= padded_bits; offset += 32ull) {
        const uint64_t top_index = padded_bits - 1ull - offset;
        uint32_t seq = 0u;
        uint32_t k;

        for (k = 0u; k < 32u; ++k) {
            seq |= mxc_padded_bit(msg, message_bits, zero_count, length_bits, top_index - k) << k;
        }
        mxc_step_same(&s, seq);
    }
    mxc_finalise(&s, padded_bits, digest, 16u, 768u);
    return 0;
}

/* AXIS-1024: 32 message bits per 32-beat block. */
static int mxc_hash1024(const uint8_t* msg, uint64_t message_bits, uint8_t* digest)
{
    const uint64_t zero_count = (64ull - ((message_bits + 2ull) & 63ull)) & 63ull;
    const uint64_t padded_bits = message_bits + 2ull + zero_count + 64ull;
    const uint64_t length_bits = message_bits;
    const int byte_aligned = ((message_bits & 7ull) == 0ull);
    mxc_soa32 s;
    uint64_t offset;

    memset(digest, 0, 128u);
    mxc_soa32_init(&s);

    for (offset = 0ull; offset + 32ull <= padded_bits; offset += 32ull) {
        const uint64_t top_index = padded_bits - 1ull - offset;
        uint32_t seq;

        if (byte_aligned && top_index < message_bits) {
            uint32_t word;

            memcpy(&word, msg + (top_index >> 3) - 3ull, sizeof(word));
            seq = (uint32_t)__builtin_bswap32(word);
        } else {
            uint32_t k;

            seq = 0u;
            for (k = 0u; k < 32u; ++k) {
                seq |= mxc_padded_bit(msg, message_bits, zero_count, length_bits,
                                      top_index - k) << k;
            }
        }
        mxc_step_same(&s, seq);
    }
    mxc_finalise(&s, padded_bits, digest, 32u, 1024u);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char* msg,
              unsigned long long msg_len_bits, unsigned char* digest)
{
    if (digest == 0) {
        return -1;
    }
    if (digest_len_bits != 512 && digest_len_bits != 768 && digest_len_bits != 1024) {
        return -2;
    }
    if (msg_len_bits > 0ull && msg == 0) {
        return -3;
    }
    if (digest_len_bits == 512) {
        return mxc_hash512(msg, (uint64_t)msg_len_bits, digest);
    }
    if (digest_len_bits == 768) {
        return mxc_hash768(msg, (uint64_t)msg_len_bits, digest);
    }
    return mxc_hash1024(msg, (uint64_t)msg_len_bits, digest);
}
