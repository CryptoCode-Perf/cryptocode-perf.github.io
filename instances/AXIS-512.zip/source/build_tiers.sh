#!/usr/bin/env bash
# Build the parameterised AXIS-512/768/1024 deliverable with exactly the
# official performance flags (guideline 3.2.2).  Nothing is appended.
set -euo pipefail

L0=/mnt/c/Users/von/WorkBuddy/2026-10-30-16-05-28/feilian/work/_overnight/l0
SRC="$L0/axis/src/axis_tiers.c"
OUT="$L0/axis/out/ours_axis_tiers.so"

FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra)

mkdir -p "$L0/axis/out"
python3 "$L0/axis/gates/gen_stream.py"
gcc "${FLAGS[@]}" -fPIC -shared -o "$OUT" "$SRC"
echo "built: $OUT"
ls -l "$OUT"
sha256sum "$OUT"
echo "--- undefined symbols (should be libc only) ---"
nm -D --undefined-only "$OUT" | sed 's/^/  /'
echo "--- isa census ---"
objdump -d --no-show-raw-insn "$OUT" | awk '/^ +[0-9a-f]+:/{print $2}' > /tmp/axis_tiers_mn.txt
echo "  insns=$(wc -l < /tmp/axis_tiers_mn.txt)"
for m in rorx andn shlx shrx aesenc vaesenc pext pdep; do
  printf '  %-8s %s\n' "$m" "$(grep -c "^$m" /tmp/axis_tiers_mn.txt || true)"
done
