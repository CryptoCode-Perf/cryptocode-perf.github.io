# TaiChi-1024

Algorithm: TaiChi | Digest bits: 1024 | Form: 标量 C

Contents: implementation source/, public header TaiChi-1024.h, prebuilt TaiChi-1024.so,
KAT vector KAT_2_12_TaiChi-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 1611077ce812b5f8ff635424ffbbee5a024090d8f3662674c328cec5bc297886
Speed (cpB, lower is faster): reference 123.32 / official-optimized 15.24 / optimized 13.52
Speedup: GM(S1-S8) 1.10x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
