#!/usr/bin/env bash
# Build our TaiChi-1024 artifacts.  Official ten flags, verbatim.
# Every build must produce zero compiler output and the purec fallback must be
# byte-identical to the opponent opt.so (that is the fidelity proof).
set -u
export WSL_UTF8=1
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
L0="$(cd "$HERE/.." && pwd)"
OUT="$HERE/out"
LOGS="$HERE/logs"
mkdir -p "$OUT" "$LOGS"

OPT="$HERE/official/TaiChi/Implementations/Optimized_Implementation/TaiChi-1024-op-per"
OPP="$L0/build/hash-25/taichi1024/opt.so"

FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

build() {  # build <name> <src.c> [extra -D ...]
    local name="$1"; shift
    local src="$1"; shift
    local so="$OUT/$name.so"
    local log="$LOGS/$name.build.log"
    rm -f "$so"
    gcc "${FLAGS[@]}" "$@" -shared -fPIC -o "$so" -I "$OPT" "$src" -lm 2>"$log"
    local rc=$?
    local sz
    sz=$(wc -c <"$log")
    if [ "$rc" != 0 ] || [ "$sz" != 0 ]; then
        echo "BUILD FAIL $name rc=$rc logbytes=$sz"
        sed -n '1,20p' "$log"
        return 1
    fi
    echo "OK $name  $(wc -c <"$so") bytes  $(sha256sum "$so" | cut -c1-16)"
}

echo "########## TaiChi-1024 build ##########"
python3 "$HERE/gates/gen_uni.py"   || exit 1
python3 "$HERE/gates/make_neg.py"  || exit 1

build base   "$OPT/CryptHash_AlgorithmInstance.c"
build purec  "$HERE/src/uni/CryptHash_AlgorithmInstance_purec.c" -DTC_NO_BMI2
build rorx   "$HERE/src/uni/CryptHash_AlgorithmInstance_rorx.c"
build rot0   "$HERE/src/uni/CryptHash_AlgorithmInstance_rot0.c"
build purec_pad "$HERE/src/uni/CryptHash_AlgorithmInstance_purec_pad.c" -DTC_NO_BMI2
build rorx_pad  "$HERE/src/uni/CryptHash_AlgorithmInstance_rorx_pad.c"

# negative controls (same source order as their positive twin)
build rorx_noop  "$HERE/src/neg/CryptHash_AlgorithmInstance_rorx_noop.c"
build rorx_const "$HERE/src/neg/CryptHash_AlgorithmInstance_rorx_const.c"
build purec_noop  "$HERE/src/neg/CryptHash_AlgorithmInstance_purec_noop.c" -DTC_NO_BMI2
build purec_const "$HERE/src/neg/CryptHash_AlgorithmInstance_purec_const.c" -DTC_NO_BMI2
build ours_noop  "$HERE/src/neg/CryptHash_AlgorithmInstance_rorx_pad_noop.c"
build ours_const "$HERE/src/neg/CryptHash_AlgorithmInstance_rorx_pad_const.c"

# delivered artifact = rorx + padding closed form, under its delivery name
cp -f "$OUT/rorx_pad.so" "$OUT/ours_taichi1024.so"
echo "OK deliver  $(wc -c <"$OUT/ours_taichi1024.so") bytes  $(sha256sum "$OUT/ours_taichi1024.so" | cut -c1-16)"

echo "--- fidelity: purec vs opponent opt.so ---"
if cmp -s "$OUT/purec.so" "$OPP"; then
    echo "FIDELITY PASS: purec.so is byte-identical to opt.so"
else
    echo "FIDELITY FAIL: purec.so differs from opt.so"
    sha256sum "$OUT/purec.so" "$OPP"
fi
echo "--- noop controls must be byte-identical to their positive twin ---"
for p in "rorx rorx_noop" "purec purec_noop"; do
    set -- $p
    if cmp -s "$OUT/$1.so" "$OUT/$2.so"; then echo "NOOP PASS  $1 == $2"; else echo "NOOP FAIL $1 != $2"; fi
done
echo "--- rotate census (scalar rol/ror/rorx) ---"
for s in base purec rorx rot0 rorx_noop rorx_const; do
    printf '%-12s %s\n' "$s" "$(objdump -d "$OUT/$s.so" | grep -oE '\b(rol|ror|rorx)\b' | sort | uniq -c | tr '\n' ' ')"
done
echo "--- TaiChi_Step stack frame ---"
for s in purec rorx rot0; do
    printf '%-8s %s\n' "$s" "$(objdump -d "$OUT/$s.so" | grep -E 'sub +\$0x[0-9a-f]+,%rsp' | head -3 | tr -s ' ' | tr '\n' ' ')"
done
echo "########## build done ##########"
