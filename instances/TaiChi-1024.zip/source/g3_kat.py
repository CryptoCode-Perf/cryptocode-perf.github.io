#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""G3 KAT gate for TaiChi-1024.

Imports the SHARED l0/kat_gate.py read-only and reuses its parse_kat() and
check().  l0/src/hash-25 has been pruned, so the shared find_kat() finds
nothing; the fallback below deliberately REPEATS the shared gate's file
selection convention -- glob '<official>/**/Test_Vector*/KAT_*.txt', keep the
files whose normalised basename (with "KAT_" stripped) contains the normalised
instance name, then pick the file with the most usable records (ties broken by
sorted path order, exactly like the shared code).

A bare '**/KAT_*.txt' is NOT used: in this package that would also reach stale
copies under Others/ and produce a false red that looks like an algorithm
mismatch.  (That trap has now been hit and documented four times.)

Usage: python3 g3_kat.py <candidate.so>
"""
import glob
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TAICHI = os.path.dirname(HERE)
L0 = os.path.dirname(TAICHI)
sys.path.insert(0, L0)

import kat_gate  # noqa: E402  shared, read-only

OFFICIAL = os.path.join(TAICHI, "official")
CID = "hash-25"
INSTANCE = "TaiChi-1024"


def norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def find_kat_local():
    want = norm(INSTANCE)
    allk = glob.glob(os.path.join(OFFICIAL, "**", "Test_Vector*", "KAT_*.txt"),
                     recursive=True)
    files = [p for p in allk
             if want and want in norm(os.path.basename(p).replace("KAT_", ""))]
    if not files:
        print("[warn] no KAT under a Test_Vector* directory matched %r; "
              "checking every KAT_*.txt in the package" % INSTANCE)
        files = [p for p in allk
                 if want in norm(os.path.basename(p).replace("KAT_", ""))]
    if not files:
        sys.exit("FATAL: no KAT file at all for %s" % INSTANCE)
    best, best_n, used = [], 0, []
    for path in sorted(files):
        recs = [r for r in kat_gate.parse_kat(path)
                if (r["msg_len_bits"] + 7) // 8 <= kat_gate.MAX_MSG_BYTES]
        if len(recs) > best_n:
            best, best_n, used = recs, len(recs), [path]
    return best, used


def main():
    if len(sys.argv) != 2:
        sys.exit("usage: g3_kat.py <candidate.so>")
    lib = os.path.abspath(sys.argv[1])
    recs, files = find_kat_local()
    shown = [os.path.relpath(p, L0) for p in files]
    print("KAT files selected: %s" % ", ".join(shown))
    print("records=%d (MAX_RECORDS=%d)" % (len(recs), kat_gate.MAX_RECORDS))
    checked, match, first_bad, err = kat_gate.check(lib, recs)
    print("G3: checked=%s match=%s err=%s first_bad=%s"
          % (checked, match, err, first_bad))
    ok = (err is None) and checked > 0 and checked == match
    print("G3 %s" % ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
