# ZC-DMC candidate package

Includes 1280-state 512/768 and 1536-state 512/768/1024 instances.
On x86-64 Linux with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`.
It rebuilds official reference, official optimized and CryptoCode implementations,
checks full KAT, compares selected long and boundary inputs with the reference,
and runs input/output guard-page checks. Build products are written to build/.

This is a candidate, not a final release. Performance comparisons, independent
release review and redistribution permissions remain pending. The CryptoCode
interfaces include padding repairs; official sources remain separate. KAT and
selected tests do not prove cryptographic security.
