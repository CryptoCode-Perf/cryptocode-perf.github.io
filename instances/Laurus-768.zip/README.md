# Laurus-768

Algorithm: Laurus | Digest bits: 768 | Form: 标量 C

Contents: implementation source/, public header Laurus-768.h, prebuilt Laurus-768.so,
KAT vector KAT_2_12_laurus_768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 8da7ae79bad4b78fa3a0082397758b0114944c9c9ad15b73bb1f76d83adca856
Speed (cpB, lower is faster): reference 20.98 / official-optimized 6.21 / optimized 5.78
Speedup: GM(S1-S8) 1.07x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
