# Laurus — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Laurus-1024
- 摘要位：1024；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Laurus-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Laurus-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Laurus-1024/`
- 优化要点：官方优化版 Laurus-1024 的三处接口级改写，与 Laurus-512 同源（同上；置换核一字未动）。交付件 _overnight/l0/laurusN/out/ours_laurus1024.so。KAT 口径同 h14b（ref 4097/4097；opt 侧只判字节对齐子集 513/513，kat_mode=aligned）。标准行口径：ref_cpb/opt_cpb 由 _laurus_std_add.py 本轮同会话测出

## Laurus-512
- 摘要位：512；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Laurus-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Laurus-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Laurus-512/`
- 优化要点：官方优化版的三处接口级改写 _overnight/l0/laurus512/src/ours.c（load64/store64 逐字节移位宏 → __builtin_memcpy + __builtin_bswap64；squeeze 尾部逐字节 for → __builtin_memcpy；置换核一字未动）。KAT 口径：官方 Reference 4097/4097；官方 Optimized 侧接口把位长当字节，故只用字节对齐子集 513/513（证据里 kat_mode=aligned）

## Laurus-768
- 摘要位：768；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Laurus-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Laurus-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Laurus-768/`
- 优化要点：官方优化版 Laurus-768 的三处接口级改写，与 Laurus-512 同源（load64/store64 逐字节移位宏 → __builtin_memcpy + __builtin_bswap64；squeeze 尾部逐字节 for → __builtin_memcpy；置换核一字未动）。交付件 _overnight/l0/laurusN/out/ours_laurus768.so（build 由 laurusN.py --inst 768 逐字节复现在册 opt 的 .text）。KAT 口径：官方 Reference 4097/4097；官方 Optimized 侧接口把位长当字节，故只用字节对齐子集 513/513（kat_mode=aligned）；负对照 n1/n2 各 8/1024 变红、n3（负-负）1024/1024 保持绿。标准行口径：ref_cpb/opt_cp
