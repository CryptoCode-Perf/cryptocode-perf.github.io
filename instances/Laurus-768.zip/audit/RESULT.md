# Laurus — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| Laurus-1024 | `Laurus-1024.so` | 28624 B | `04a8fe058f3ff0dd1f9387c790058906649f4d449b193b6cca3ba8a54a49da43` |
| Laurus-512 | `Laurus-512.so` | 28624 B | `934d81f778e0711a191dd3044bf6059a27c6689d5dfa1c9004b581714c8e7158` |
| Laurus-768 | `Laurus-768.so` | 28624 B | `8da7ae79bad4b78fa3a0082397758b0114944c9c9ad15b73bb1f76d83adca856` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| Laurus-1024 | 1024 | 34.8026 | 8.732 | 8.075354 | 1.081315 | 1.0644 |
| Laurus-512 | 512 | 17.8965 | 5.4525 | 5.064282 | 1.076658 | 1.0751 |
| Laurus-768 | 768 | 20.9819 | 6.2066 | 5.782069 | 1.073422 | 1.0706 |

## 优化方法（逐实例原文，来自交付清单）

### Laurus-1024
官方优化版 Laurus-1024 的三处接口级改写，与 Laurus-512 同源（同上；置换核一字未动）。交付件 _overnight/l0/laurusN/out/ours_laurus1024.so。KAT 口径同 h14b（ref 4097/4097；opt 侧只判字节对齐子集 513/513，kat_mode=aligned）。标准行口径：ref_cpb/opt_cpb 由 _laurus_std_add.py 本轮同会话测出

### Laurus-512
官方优化版的三处接口级改写 _overnight/l0/laurus512/src/ours.c（load64/store64 逐字节移位宏 → __builtin_memcpy + __builtin_bswap64；squeeze 尾部逐字节 for → __builtin_memcpy；置换核一字未动）。KAT 口径：官方 Reference 4097/4097；官方 Optimized 侧接口把位长当字节，故只用字节对齐子集 513/513（证据里 kat_mode=aligned）

### Laurus-768
官方优化版 Laurus-768 的三处接口级改写，与 Laurus-512 同源（load64/store64 逐字节移位宏 → __builtin_memcpy + __builtin_bswap64；squeeze 尾部逐字节 for → __builtin_memcpy；置换核一字未动）。交付件 _overnight/l0/laurusN/out/ours_laurus768.so（build 由 laurusN.py --inst 768 逐字节复现在册 opt 的 .text）。KAT 口径：官方 Reference 4097/4097；官方 Optimized 侧接口把位长当字节，故只用字节对齐子集 513/513（kat_mode=aligned）；负对照 n1/n2 各 8/1024 变红、n3（负-负）1024/1024 保持绿。标准行口径：ref_cpb/opt_cpb 由 _laurus_std_add.py 本轮同会话测出
