#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ab_checkN.py —— Laurus-{512,768,1024} 的等价性门（A1/A2）与负对照（A3）。

与 `laurus512/ab_check512.py` 同型，只是把实例名参数化。判据三件，缺一不算过：

  A1 全量官方 KAT，分三段（**不能只写「4097/4097」**）：
     A1a 阳性对照：官方 Reference_Implementation 必须 4097/4097。
     A1b 字节对齐子集：base 与 ours 在 Msg_Len % 8 == 0 的条目上必须全过。
     A1c 改写等价：ours 与 base 在全部记录上逐条同结论。

  ★ 为什么不是「4097/4097」：官方 Optimized_Implementation 的
  `laurus_N(void*, const uint8_t*, uint64_t inlen)` 把 inlen 当**字节**，而胶水
  CryptHash_AlgorithmInstance.c 按**位**传 msg_len_bits，shim 只能做
  `inlen_bits >> 3` ⇒ 非字节对齐的位长在 opt 侧被丢弃。base 恰好过 513 条
  （= 字节对齐条数），ref 则全过。这是官方 opt 侧接口的固有限制，不是本改写引入。

  A2 位长扫描：0..1023 每个位长各一条伪随机消息，ours 与 base 摘要必须逐字节相同。

  A3 负对照：store64 去 bswap、load64 去 bswap 必须让 A2 变红；
     squeeze 换回逐字节 for 是**负-负对照**，必须**保持绿**。

用法：python3 ab_checkN.py --inst 768 [--skip-negctl]
"""
import ctypes
import hashlib
import os
import pickle
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, L0)
import _kat_full as KF  # noqa: E402
import laurusN as LN  # noqa: E402


def neg_store_le(src):
    old = """static inline void store64(uint8_t *y, uint64_t x)
{
    uint64_t v = __builtin_bswap64(x);
    __builtin_memcpy(y, &v, 8);
}"""
    new = """static inline void store64(uint8_t *y, uint64_t x)
{
    uint64_t v = x;
    __builtin_memcpy(y, &v, 8);
}"""
    assert src.count(old) == 1
    return src.replace(old, new)


def neg_load_le(src):
    old = """static inline uint64_t load64(const uint8_t *y)
{
    uint64_t v;
    __builtin_memcpy(&v, y, 8);
    return __builtin_bswap64(v);
}"""
    new = """static inline uint64_t load64(const uint8_t *y)
{
    uint64_t v;
    __builtin_memcpy(&v, y, 8);
    return v;
}"""
    assert src.count(old) == 1
    return src.replace(old, new)


def neg_squeeze_bytecopy(src):
    old = "    __builtin_memcpy(out, t, outlen);"
    new = "    for (i = 0; i < outlen; i++)\n        out[i] = t[i];"
    assert src.count(old) == 1, "squeeze 改写锚点不在（先看 laurusN 是否变了）"
    return src.replace(old, new)


def digest(lib, msg, msg_bits, dg_bits):
    rfd, wfd = os.pipe()
    pid = os.fork()
    if pid == 0:
        os.close(rfd)
        try:
            dll = ctypes.CDLL(os.path.abspath(lib))
            fn = dll.CryptHash
            fn.restype = ctypes.c_int
            fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_ulonglong,
                           ctypes.c_char_p]
            n = dg_bits // 8
            buf = ctypes.create_string_buffer(n + 16)
            rc = fn(dg_bits, msg, ctypes.c_ulonglong(msg_bits), buf)
            res = (rc, buf.raw[:n].hex())
        except BaseException as exc:  # noqa: BLE001
            res = (-1, "exception: %r" % (exc,))
        with os.fdopen(wfd, "wb") as fh:
            pickle.dump(res, fh)
        os._exit(0)
    os.close(wfd)
    with os.fdopen(rfd, "rb") as fh:
        data = fh.read()
    os.waitpid(pid, 0)
    if not data:
        return None
    return pickle.loads(data)


def pseudo_msg(bits):
    nbytes = (bits + 7) // 8
    return bytes(((i * 131 + 17) & 0xFF) for i in range(nbytes))


def scan(lib_a, lib_b, bits_list, label, dg_bits):
    same, diffs = 0, []
    for bits in bits_list:
        msg = pseudo_msg(bits)
        ra = digest(lib_a, msg, bits, dg_bits)
        rb = digest(lib_b, msg, bits, dg_bits)
        if ra is None or rb is None:
            diffs.append((bits, "crash", ra, rb))
            continue
        if ra[0] != 0 or rb[0] != 0:
            diffs.append((bits, "rc", ra[0], rb[0]))
            continue
        if ra[1] == rb[1]:
            same += 1
        else:
            diffs.append((bits, "digest", ra[1][:16], rb[1][:16]))
    print("  %-22s same %d / %d   diff %d" % (label, same, len(bits_list), len(diffs)))
    for d in diffs[:5]:
        print("      ! %s" % (d,))
    return same == len(bits_list), diffs


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    argv = sys.argv[1:]
    inst = None
    for i, a in enumerate(argv):
        if a == "--inst":
            inst = argv[i + 1]
    if inst not in ("512", "768", "1024"):
        sys.exit("用法：python3 ab_checkN.py --inst 512|768|1024 [--skip-negctl]")
    bits_n = int(inst)
    skip = "--skip-negctl" in argv

    P = LN.paths(inst)
    OUT = P["outdir"]
    OURS = os.path.join(OUT, "ours_laurus%s.so" % inst)
    BASE = os.path.join(OUT, "base_laurus%s.so" % inst)
    REF = os.path.join(L0, "build", "hash-14", "laurus-%s" % inst, "ref.so")
    OURS_C = P["ours_c"]
    KAT = os.path.join(L0, "src", "hash-14", "Laurus", "Test_Vectors",
                       "KAT_2_12_laurus_%s.txt" % inst)
    NEGDIR = os.path.join(HERE, "variants", inst)

    if not (os.path.isfile(OURS) and os.path.isfile(BASE)):
        sys.exit("缺 %s / %s，先跑 laurusN.py --inst %s both" % (OURS, BASE, inst))

    print("[A1] 全量官方 KAT（%s）" % os.path.basename(KAT))
    recs = KF.parse_all(KAT)
    print("  记录数 %d" % len(recs))
    aligned = [r for r in recs if r["msg_len_bits"] % 8 == 0]
    print("  字节对齐 %d 条（Msg_Len %% 8 == 0）" % len(aligned))

    print("  [A1a] 阳性对照：官方 Reference_Implementation 必须全过")
    if not os.path.isfile(REF):
        print("     缺 %s ⇒ 判据不成立" % REF)
        return 1
    n, match, first, err = KF.check_all(REF, recs)
    ref_ok = (n == len(recs) and match == n and not err)
    print("     ref  %d/%d %s  %s" % (match, n, "PASS" if ref_ok else "FAIL",
                                      "" if not first else first))
    if not ref_ok:
        print("=> A1a 失败：官方参考实现都过不了，不能拿它判 base/ours")
        return 1

    print("  [A1b/A1c] base 与 ours：字节对齐子集必须全过、全量必须逐条同结论")
    res = {}
    for name, lib in (("base", BASE), ("ours", OURS)):
        n, match, first, err = KF.check_all(lib, recs)
        na, ma, firsta, erra = KF.check_all(lib, aligned)
        res[name] = {"all": (n, match, first, err), "aligned": (na, ma, firsta, erra)}
        print("     %-4s 全量 %d/%d   字节对齐 %d/%d  %s" % (
            name, match, n, ma, na,
            "" if not (first or err) else "first=%s err=%s" % (first, err)))
        if na != len(aligned) or ma != na or erra:
            print("=> A1b 失败：%s 在字节对齐子集上不全过" % name)
            return 1

    b, o = res["base"]["all"], res["ours"]["all"]
    if b[2] is not None or o[2] is not None:
        fb = None if b[2] is None else b[2].get("i")
        fo = None if o[2] is None else o[2].get("i")
        if fb != fo:
            print("=> A1c 失败：base 与 ours 首个失败记录不同（base=%s ours=%s）" % (fb, fo))
            return 1
    if b[1] != o[1]:
        print("=> A1c 失败：base 过 %d 条、ours 过 %d 条" % (b[1], o[1]))
        return 1
    print("     => A1 成立：ref %d/%d、base≡ours（同为 %d/%d，首个失败同一条）"
          % (res["base"]["all"][0], res["base"]["all"][0], b[1], b[0]))

    print("\n[A2] 位长扫描 0..1023（ours vs base）")
    bits_list = list(range(0, 1024))
    a2_ok, _ = scan(OURS, BASE, bits_list, "ours vs base", bits_n)
    if not a2_ok:
        print("=> A2 失败：三处改写改变了行为")
        return 1
    print("  => A2 成立（1024 个位长全部逐字节相同）")

    if skip:
        print("\n[A3] 已跳过（--skip-negctl）")
        return 0

    print("\n[A3] 负对照（A2 必须按预期变色）")
    cases = [("n1_store_le", neg_store_le, True),
             ("n2_load_le", neg_load_le, True),
             ("n3_squeeze_bytecopy", neg_squeeze_bytecopy, False)]
    nok = True
    for name, edit, should_break in cases:
        print("  -- %s（期望 A2 %s）" % (name, "变红" if should_break else "保持绿"))
        d = os.path.join(NEGDIR, name)
        os.makedirs(d, exist_ok=True)
        src = open(OURS_C, encoding="utf-8").read()
        new = edit(src)
        if new == src:
            print("     注入未命中（文本没变）—— 负对照无效")
            nok = False
            continue
        p = os.path.join(d, "ours.c")
        with open(p, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(new)
        so = LN.build(inst, "neg_" + name, p, P)
        same, diffs = scan(so, BASE, bits_list, name + " vs base", bits_n)
        broke = not same
        good = (broke == should_break)
        print("     判定：%s" % ("OK" if good else "不符合预期"))
        nok = nok and good
    if not nok:
        print("=> A3 失败：负对照没有按预期区分")
        return 1
    print("\n=> ALL PASS（A1 全量 KAT / A2 位长扫描 / A3 负对照三件）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
