#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""laurusN.py —— 把 Laurus-512 那一例的三处等价改写推广到 Laurus-768 / Laurus-1024。

与 `laurus512/make_ours.py` + `laurus512/build512.py` 同型，只是把实例名参数化：
官方 Optimized_Implementation/Laurus-{512,768,1024}/laurus_{N}.c 的三处锚点
（load64 宏 / store64 宏 / squeeze 尾部逐字节拷贝）行号完全相同，逐字节比对确认过。

配方逐字复刻 `_overnight/l0/fix14.py` 的 `build_opt()`：
  - OPT_FLAGS = -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
                -std=c99 -Wpedantic -Wall -Wextra
  - 对象顺序 glue(CryptHash_AlgorithmInstance.c) -> drng -> impl -> shim
  - 链接 `gcc -shared -o so <objs>`，**不带 -flto / -lm**
  - impl 用 -Dlaurus_N=laurus_N__raw 改名；shim 单独编译（不带 -D）

复现判据钉 `.text` 段（-flto 会把临时对象名落进 .symtab/.strtab，整文件 sha 不稳）。

用法：python3 laurusN.py --inst 768 [base|ours|both]
"""
import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
assert os.path.exists(os.path.join(WORK, "ir_text.py")), WORK

SRCROOT = os.path.join(L0, "src", "hash-14", "Laurus", "Implementations")

OPT_FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
             "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

LOAD_MACRO = """#define load64(y)\t((uint64_t)((y)[0] & 0xFF) << 56) | ((uint64_t)((y)[1] & 0xFF) << 48) | \\
\t\t\t\t\t((uint64_t)((y)[2] & 0xFF) << 40) | ((uint64_t)((y)[3] & 0xFF) << 32) | \\
\t\t\t\t\t((uint64_t)((y)[4] & 0xFF) << 24) | ((uint64_t)((y)[5] & 0xFF) << 16) | \\
\t\t\t\t\t((uint64_t)((y)[6] & 0xFF) << 8) |  ((uint64_t)((y)[7] & 0xFF))
"""

LOAD_NEW = """/* [ours] 逐字节拼装 -> 一次整字读 + 字节序反转（语义等价：原 load64 是 big-endian） */
static inline uint64_t load64(const uint8_t *y)
{
    uint64_t v;
    __builtin_memcpy(&v, y, 8);
    return __builtin_bswap64(v);
}
"""

STORE_MACRO = """#define store64(y, x) { (y)[0] = ((x) >> 56) & 0xFF; (y)[1] = ((x) >> 48) & 0xFF;\\
\t\t\t\t\t    (y)[2] = ((x) >> 40) & 0xFF; (y)[3] = ((x) >> 32) & 0xFF;\\
                        (y)[4] = ((x) >> 24) & 0xFF; (y)[5] = ((x) >> 16) & 0xFF;\\
\t\t\t\t\t    (y)[6] = ((x) >> 8) & 0xFF; (y)[7] = (x) & 0xFF; }
"""

STORE_NEW = """/* [ours] 逐字节写 -> 一次整字写（语义等价：原 store64 是 big-endian） */
static inline void store64(uint8_t *y, uint64_t x)
{
    uint64_t v = __builtin_bswap64(x);
    __builtin_memcpy(y, &v, 8);
}
"""

SQUEEZE_OLD = """    store64(t, state->A[state->pos / 8]);
    for (i = 0; i < outlen; i++)
        out[i] = t[i];
"""

SQUEEZE_NEW = """    store64(t, state->A[state->pos / 8]);
    __builtin_memcpy(out, t, outlen); /* [ours] 逐字节 -> memcpy */
"""

EDITS = [
    ("load64 宏", LOAD_MACRO, LOAD_NEW),
    ("store64 宏", STORE_MACRO, STORE_NEW),
    ("squeeze 尾部逐字节拷贝", SQUEEZE_OLD, SQUEEZE_NEW),
]


def run(cmd, what):
    p = subprocess.run(cmd, text=True, errors="replace", capture_output=True)
    if p.returncode != 0:
        print(p.stdout[-3000:])
        print(p.stderr[-3000:])
        sys.exit("%s 失败，rc=%d" % (what, p.returncode))
    return p


def paths(inst):
    opt = os.path.join(SRCROOT, "Optimized_Implementation", "Laurus-%s" % inst)
    ref = os.path.join(SRCROOT, "Reference_Implementation", "Laurus-%s" % inst)
    return {
        "opt": opt, "ref": ref,
        "impl_c": os.path.join(opt, "laurus_%s.c" % inst),
        "shim": os.path.join(L0, "shims", "l0_f14_laurus_%s_len.c" % inst),
        "ours_c": os.path.join(HERE, "src", "ours_%s.c" % inst),
        "outdir": os.path.join(HERE, "out"),
    }


def make_ours(inst, P):
    text = open(P["impl_c"], encoding="utf-8", errors="surrogateescape").read()
    ok = True
    for name, old, new in EDITS:
        n = text.count(old)
        print("[anchor %s] %-24s 命中 %d 次" % (inst, name, n))
        if n != 1:
            print("    !! 期望恰好 1 次，实际 %d 次 —— 拒绝改写" % n)
            ok = False
            continue
        text = text.replace(old, new)
    if not ok:
        return None
    for bad in ("#define load64", "#define store64"):
        if bad in text:
            print("    !! 仍残留 %r" % bad)
            return None
    os.makedirs(os.path.dirname(P["ours_c"]), exist_ok=True)
    with open(P["ours_c"], "w", encoding="utf-8", errors="surrogateescape",
              newline="\n") as f:
        f.write(text)
    print("[write] %s（%d 字节）" % (P["ours_c"], os.path.getsize(P["ours_c"])))
    return P["ours_c"]


def build(inst, tag, impl_c, P):
    obj = os.path.join(HERE, "build_%s" % inst, tag)
    os.makedirs(obj, exist_ok=True)
    os.makedirs(P["outdir"], exist_ok=True)
    out = os.path.join(P["outdir"], "%s_laurus%s.so" % (tag, inst))
    opt, ref = P["opt"], P["ref"]

    objs = []
    o = os.path.join(obj, "CryptHash_AlgorithmInstance.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-I", opt, "-I", ref, "-o", o,
        os.path.join(ref, "CryptHash_AlgorithmInstance.c")], tag + ".glue")
    objs.append(o)
    o = os.path.join(obj, "drng.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-I", opt, "-I", ref, "-o", o,
        os.path.join(ref, "drng.c")], tag + ".drng")
    objs.append(o)
    o = os.path.join(obj, "impl.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-Dlaurus_%s=laurus_%s__raw" % (inst, inst),
        "-I", opt, "-I", ref, "-o", o, impl_c], tag + ".impl")
    objs.append(o)
    o = os.path.join(obj, "shim.o")
    run(["gcc", "-c", "-fPIC"] + OPT_FLAGS + ["-I", opt, "-o", o, P["shim"]], tag + ".shim")
    objs.append(o)

    run(["gcc", "-shared", "-o", out] + objs, tag + ".link")
    h = hashlib.sha256(open(out, "rb").read()).hexdigest()
    print("%-4s %7d B  sha256 %s" % (tag, os.path.getsize(out), h))
    return out


def text_sha(so):
    tmp = so + ".text.bin"
    run(["objcopy", "-O", "binary", "--only-section=.text", so, tmp], "objcopy")
    h = hashlib.sha256(open(tmp, "rb").read()).hexdigest()
    n = os.path.getsize(tmp)
    os.remove(tmp)
    return n, h


def main():
    argv = sys.argv[1:]
    inst = None
    for i, a in enumerate(argv):
        if a == "--inst":
            inst = argv[i + 1]
    if inst not in ("512", "768", "1024"):
        sys.exit("用法：python3 laurusN.py --inst 512|768|1024 [base|ours|both]")
    which = [a for a in argv if a in ("base", "ours", "both")]
    which = which[0] if which else "both"

    P = paths(inst)
    for k in ("impl_c", "shim"):
        if not os.path.isfile(P[k]):
            sys.exit("缺 %s" % P[k])

    built = {}
    if which in ("base", "both"):
        built["base"] = build(inst, "base", P["impl_c"], P)
    if which in ("ours", "both"):
        ours_c = P["ours_c"]
        if not os.path.isfile(ours_c):
            ours_c = make_ours(inst, P)
            if not ours_c:
                return 1
        built["ours"] = build(inst, "ours", ours_c, P)

    print("\n[.text] 段比对（复现判据）")
    cands = [os.path.join(L0, "build", "hash-14", "laurus-%s" % inst, "opt.so"),
             os.path.join(L0, "build", "hash-14", "laurus%s" % inst, "opt.so")]
    rows = [("reg:" + os.path.basename(os.path.dirname(c)), c)
            for c in cands if os.path.isfile(c)]
    for tag in ("base", "ours"):
        if tag in built:
            rows.append((tag, built[tag]))
    shas = {}
    for name, so in rows:
        n, h = text_sha(so)
        shas[name] = h
        print("  %-18s .text %6d B  %s" % (name, n, h))
    if "base" in shas:
        regnames = [k for k in shas if k.startswith("reg:")]
        if not regnames:
            print("  => 找不到在册 opt.so，无法验配方")
        else:
            hit = [k for k in regnames if shas[k] == shas["base"]]
            if not hit:
                print("  => base .text 与任何在册 opt.so 都不同：配方不可信，停止")
                return 1
            print("  => base .text 与 %s 逐字节相同（配方复现成立）" % ", ".join(hit))
    if "ours" in shas and "base" in shas:
        if shas["ours"] == shas["base"]:
            print("  => ours .text 与 base 相同：改写没生效，停止")
            return 1
        print("  => ours .text 与 base 不同（改写已生效）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
