# MoFang — 实例优化说明 / Instance Optimization Notes

> 对照基准：随包 `Optimized_Implementation`。加速比为八档几何均值（32 B … 64 KiB）。
> Baseline: the vendor `Optimized_Implementation` in the same package; metric is the geometric mean over eight sizes.

本族六件分两组：四个定长档（1024 / 768 / 512 / 256）与两个 XOF 档（768-XOF、256-XOF）。XOF 档的差别只在「输入缓冲更深 + 挤出可以多轮」，压缩核与定长档同源。

The six instances form two groups: four fixed-length tiers (1024 / 768 / 512 / 256) and two XOF tiers (768-XOF, 256-XOF). The XOF tiers differ only by a deeper input buffer and a multi-block squeeze; the compression kernel is shared with the fixed-length tiers.

---

## 共同做法 / What we changed

**中文**
官方优化实现把密钥扩展与状态置换留在标量 C 里，靠函数调用组织轮次，每轮都有调用/返回与栈上中间量。
我方把这两段改成**完全展开的汇编核**（由我们自己的 JIR 流水线生成：`mofang_keys_v3` 做密钥扩展、`mofang_state_v3` 做状态置换），外层只留一层薄 glue 负责吸收与挤出。这样轮次之间不再有函数调用开销，中间量全部留在寄存器里。

**English**
The vendor keeps key expansion and the state permutation in scalar C, organised by function calls, so every round pays call/return and stack traffic. We replaced both with **fully unrolled assembly kernels** produced by our own JIR pipeline (`mofang_keys_v3` for the key schedule, `mofang_state_v3` for the permutation), leaving a thin glue layer that only handles absorb and squeeze. Rounds no longer pay call overhead and intermediates stay in registers.

---

## MoFang-1024 · 1.9117（win）
定长 1024 位，四件定长档里最先落地的一件，后续档位从它派生。/ Fixed 1024-bit tier; the first one built, the other fixed-length tiers derive from it.

## MoFang-768 · 1.9321（win）
定长 768 位，同一套汇编核，按 768 的状态宽度重新生成。/ Fixed 768-bit tier with the same kernels regenerated for the 768-bit state width.

## MoFang-768-XOF · 1.8308（win）
在 768 档的 glue 上派生：把内部输入缓冲从 10 字节加宽到 15 字节，并补上 XOF 的多块挤出循环。/ Derived from the 768 glue: the inner input buffer is widened from 10 to 15 bytes and a multi-block squeeze loop is added.

## MoFang-512 · 2.8119（win）
定长 512 位，短消息占比更高，因此固定开销的削减在这里放大得最多。/ Fixed 512-bit tier; with a larger share of short messages the reduction in fixed overhead shows up strongest here.

## MoFang-256 · 2.8069（win）
定长 256 位，本族最短档。/ Fixed 256-bit tier, the shortest of the family.

## MoFang-256-XOF · 2.9943（win）
256 档的 XOF 变体，做法同 768-XOF（缓冲加宽 + 挤出循环）。/ XOF variant of the 256 tier, built the same way as 768-XOF.

---

## 交付与验证 / Delivery & verification

- 六件 × 3 个实现 × 4097 条 KAT 向量，全部通过（18 组）。/ Six instances × three implementations × 4097 vectors, all pass (18 groups).
- 22 个边界长度三方逐字节一致；包内 `build_and_verify.sh` 可在干净目录从源码重建并通过全部检查。/ Byte-exact over 22 boundary lengths; the shipped `build_and_verify.sh` rebuilds from source in a clean directory and passes every check.
- 只使用 AVX2 及以下指令；打包件已做超标助记符审计。/ AVX2 only; the shipped objects were audited for out-of-scope mnemonics.

---

> 说明：本文件是给人读的摘要，工程细节以包内 `SOURCE_MANIFEST.json`、`README.md` 与源码为准。
> Note: this is a human-readable summary; for engineering detail see `SOURCE_MANIFEST.json`, `README.md` and the sources inside the package.
