	.att_syntax
	.text
	.p2align	5
	.global	mofang_keys_v3
	.type	mofang_keys_v3, %function
mofang_keys_v3:
	vmovdqu	(%rdi), %ymm0
	vmovdqu	288(%rdi), %ymm1
	vpblendd	$12, %ymm1, %ymm0, %ymm3
	vmovdqu	%ymm3, (%rsi)
	vmovdqu	32(%rdi), %ymm0
	vmovdqu	320(%rdi), %ymm2
	vpblendd	$12, %ymm2, %ymm0, %ymm9
	vmovdqu	%ymm9, 32(%rsi)
	vmovdqu	64(%rdi), %ymm0
	vmovdqu	352(%rdi), %ymm6
	vpblendd	$12, %ymm6, %ymm0, %ymm6
	vmovdqu	%ymm6, 64(%rsi)
	vmovdqu	96(%rdi), %ymm0
	vmovdqu	384(%rdi), %ymm1
	vpblendd	$12, %ymm1, %ymm0, %ymm0
	vmovdqu	%ymm0, 96(%rsi)
	vmovdqu	128(%rdi), %ymm5
	vmovdqu	416(%rdi), %ymm7
	vpblendd	$12, %ymm7, %ymm5, %ymm7
	vmovdqu	%ymm7, 128(%rsi)
	vmovdqu	160(%rdi), %ymm1
	vmovdqu	448(%rdi), %ymm2
	vpblendd	$12, %ymm2, %ymm1, %ymm2
	vmovdqu	%ymm2, 160(%rsi)
	vmovdqu	192(%rdi), %ymm1
	vmovdqu	480(%rdi), %ymm8
	vpblendd	$12, %ymm8, %ymm1, %ymm4
	vmovdqu	%ymm4, 192(%rsi)
	vmovdqu	224(%rdi), %ymm1
	vmovdqu	512(%rdi), %ymm5
	vpblendd	$12, %ymm5, %ymm1, %ymm10
	vmovdqu	%ymm10, 224(%rsi)
	vmovdqu	256(%rdi), %ymm1
	vmovdqu	544(%rdi), %ymm8
	vpblendd	$12, %ymm8, %ymm1, %ymm1
	vmovdqu	%ymm1, 256(%rsi)
	vmovdqu	%ymm9, %ymm8
	vpand	%ymm6, %ymm8, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vmovdqu	%ymm3, %ymm5
	vpand	%ymm6, %ymm5, %ymm5
	vpxor	%ymm5, %ymm9, %ymm9
	vmovdqu	%ymm3, %ymm5
	vpor	%ymm9, %ymm5, %ymm5
	vpxor	%ymm5, %ymm6, %ymm11
	vpblendd	$12, %ymm3, %ymm3, %ymm3
	vpsrlvq	glob_data + 320(%rip), %ymm3, %ymm6
	vpsllvq	glob_data + 288(%rip), %ymm3, %ymm8
	vpor	%ymm8, %ymm6, %ymm3
	vpblendd	$12, %ymm7, %ymm4, %ymm5
	vpsrlvq	glob_data + 352(%rip), %ymm5, %ymm8
	vpsllvq	glob_data + 256(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm8, %ymm5
	vpblendd	$12, %ymm1, %ymm0, %ymm6
	vpsrlvq	glob_data + 416(%rip), %ymm6, %ymm8
	vpsllvq	glob_data + 224(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm6
	vpblendd	$12, %ymm11, %ymm7, %ymm8
	vpsrlvq	glob_data + 544(%rip), %ymm8, %ymm7
	vpsllvq	glob_data + 128(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm7, %ymm7
	vpblendd	$12, %ymm0, %ymm9, %ymm0
	vpsrlvq	glob_data + 0(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 96(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm8, %ymm8
	vpblendd	$12, %ymm10, %ymm10, %ymm0
	vpsrlvq	glob_data + 384(%rip), %ymm0, %ymm10
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm10, %ymm0
	vpblendd	$12, %ymm9, %ymm1, %ymm9
	vpsrlvq	glob_data + 512(%rip), %ymm9, %ymm1
	vpsllvq	glob_data + 32(%rip), %ymm9, %ymm9
	vpor	%ymm9, %ymm1, %ymm1
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 448(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 192(%rip), %ymm2, %ymm10
	vpor	%ymm10, %ymm9, %ymm9
	vpblendd	$12, %ymm4, %ymm11, %ymm2
	vpsrlvq	glob_data + 480(%rip), %ymm2, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm4, %ymm4
	vpxor	glob_data + 1056(%rip), %ymm3, %ymm2
	vmovdqu	%ymm2, 288(%rsi)
	vmovdqu	%ymm5, 320(%rsi)
	vmovdqu	%ymm6, 352(%rsi)
	vmovdqu	%ymm7, 384(%rsi)
	vmovdqu	%ymm8, 416(%rsi)
	vmovdqu	%ymm0, 448(%rsi)
	vmovdqu	%ymm1, 480(%rsi)
	vmovdqu	%ymm9, 512(%rsi)
	vmovdqu	%ymm4, 544(%rsi)
	vmovdqu	%ymm5, %ymm10
	vpand	%ymm6, %ymm10, %ymm10
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	%ymm2, %ymm3
	vpand	%ymm6, %ymm3, %ymm3
	vpxor	%ymm3, %ymm5, %ymm11
	vmovdqu	%ymm2, %ymm10
	vpor	%ymm11, %ymm10, %ymm10
	vpxor	%ymm10, %ymm6, %ymm12
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 320(%rip), %ymm2, %ymm3
	vpsllvq	glob_data + 288(%rip), %ymm2, %ymm10
	vpor	%ymm10, %ymm3, %ymm5
	vpblendd	$12, %ymm8, %ymm1, %ymm2
	vpsrlvq	glob_data + 352(%rip), %ymm2, %ymm6
	vpsllvq	glob_data + 256(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm6, %ymm6
	vpblendd	$12, %ymm4, %ymm7, %ymm2
	vpsrlvq	glob_data + 416(%rip), %ymm2, %ymm10
	vpsllvq	glob_data + 224(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm10, %ymm10
	vpblendd	$12, %ymm12, %ymm8, %ymm2
	vpsrlvq	glob_data + 544(%rip), %ymm2, %ymm3
	vpsllvq	glob_data + 128(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm3, %ymm2
	vpblendd	$12, %ymm7, %ymm11, %ymm3
	vpsrlvq	glob_data + 0(%rip), %ymm3, %ymm7
	vpsllvq	glob_data + 96(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm7
	vpblendd	$12, %ymm9, %ymm9, %ymm3
	vpsrlvq	glob_data + 384(%rip), %ymm3, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm8, %ymm3
	vpblendd	$12, %ymm11, %ymm4, %ymm9
	vpsrlvq	glob_data + 512(%rip), %ymm9, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm9, %ymm8
	vpor	%ymm8, %ymm4, %ymm4
	vpblendd	$12, %ymm0, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 192(%rip), %ymm0, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpblendd	$12, %ymm1, %ymm12, %ymm0
	vpsrlvq	glob_data + 480(%rip), %ymm0, %ymm1
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm1, %ymm9
	vpxor	glob_data + 1024(%rip), %ymm5, %ymm0
	vmovdqu	%ymm0, 576(%rsi)
	vmovdqu	%ymm6, 608(%rsi)
	vmovdqu	%ymm10, 640(%rsi)
	vmovdqu	%ymm2, 672(%rsi)
	vmovdqu	%ymm7, 704(%rsi)
	vmovdqu	%ymm3, 736(%rsi)
	vmovdqu	%ymm4, 768(%rsi)
	vmovdqu	%ymm8, 800(%rsi)
	vmovdqu	%ymm9, 832(%rsi)
	vmovdqu	%ymm6, %ymm11
	vpand	%ymm10, %ymm11, %ymm11
	vpxor	%ymm11, %ymm0, %ymm0
	vmovdqu	%ymm0, %ymm1
	vpand	%ymm10, %ymm1, %ymm1
	vpxor	%ymm1, %ymm6, %ymm11
	vmovdqu	%ymm0, %ymm6
	vpor	%ymm11, %ymm6, %ymm6
	vpxor	%ymm6, %ymm10, %ymm12
	vpblendd	$12, %ymm0, %ymm0, %ymm0
	vpsrlvq	glob_data + 320(%rip), %ymm0, %ymm5
	vpsllvq	glob_data + 288(%rip), %ymm0, %ymm10
	vpor	%ymm10, %ymm5, %ymm5
	vpblendd	$12, %ymm7, %ymm4, %ymm0
	vpsrlvq	glob_data + 352(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm6
	vpblendd	$12, %ymm9, %ymm2, %ymm0
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm10
	vpsllvq	glob_data + 224(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm10, %ymm10
	vpblendd	$12, %ymm12, %ymm7, %ymm0
	vpsrlvq	glob_data + 544(%rip), %ymm0, %ymm1
	vpsllvq	glob_data + 128(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm1, %ymm0
	vpblendd	$12, %ymm2, %ymm11, %ymm1
	vpsrlvq	glob_data + 0(%rip), %ymm1, %ymm2
	vpsllvq	glob_data + 96(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm2, %ymm7
	vpblendd	$12, %ymm8, %ymm8, %ymm1
	vpsrlvq	glob_data + 384(%rip), %ymm1, %ymm2
	vpsllvq	glob_data + 64(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm2, %ymm1
	vpblendd	$12, %ymm11, %ymm9, %ymm8
	vpsrlvq	glob_data + 512(%rip), %ymm8, %ymm2
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm2, %ymm2
	vpblendd	$12, %ymm3, %ymm3, %ymm3
	vpsrlvq	glob_data + 448(%rip), %ymm3, %ymm8
	vpsllvq	glob_data + 192(%rip), %ymm3, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpblendd	$12, %ymm4, %ymm12, %ymm3
	vpsrlvq	glob_data + 480(%rip), %ymm3, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm4
	vpxor	glob_data + 992(%rip), %ymm5, %ymm5
	vmovdqu	%ymm5, 864(%rsi)
	vmovdqu	%ymm6, 896(%rsi)
	vmovdqu	%ymm10, 928(%rsi)
	vmovdqu	%ymm0, 960(%rsi)
	vmovdqu	%ymm7, 992(%rsi)
	vmovdqu	%ymm1, 1024(%rsi)
	vmovdqu	%ymm2, 1056(%rsi)
	vmovdqu	%ymm8, 1088(%rsi)
	vmovdqu	%ymm4, 1120(%rsi)
	vmovdqu	%ymm6, %ymm9
	vpand	%ymm10, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm5
	vmovdqu	%ymm5, %ymm3
	vpand	%ymm10, %ymm3, %ymm3
	vpxor	%ymm3, %ymm6, %ymm12
	vmovdqu	%ymm5, %ymm9
	vpor	%ymm12, %ymm9, %ymm9
	vpxor	%ymm9, %ymm10, %ymm11
	vpblendd	$12, %ymm5, %ymm5, %ymm3
	vpsrlvq	glob_data + 320(%rip), %ymm3, %ymm6
	vpsllvq	glob_data + 288(%rip), %ymm3, %ymm5
	vpor	%ymm5, %ymm6, %ymm9
	vpblendd	$12, %ymm7, %ymm2, %ymm3
	vpsrlvq	glob_data + 352(%rip), %ymm3, %ymm10
	vpsllvq	glob_data + 256(%rip), %ymm3, %ymm5
	vpor	%ymm5, %ymm10, %ymm10
	vpblendd	$12, %ymm4, %ymm0, %ymm3
	vpsrlvq	glob_data + 416(%rip), %ymm3, %ymm5
	vpsllvq	glob_data + 224(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm5
	vpblendd	$12, %ymm11, %ymm7, %ymm6
	vpsrlvq	glob_data + 544(%rip), %ymm6, %ymm3
	vpsllvq	glob_data + 128(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm3, %ymm3
	vpblendd	$12, %ymm0, %ymm12, %ymm0
	vpsrlvq	glob_data + 0(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm6
	vpblendd	$12, %ymm8, %ymm8, %ymm0
	vpsrlvq	glob_data + 384(%rip), %ymm0, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm0
	vpblendd	$12, %ymm12, %ymm4, %ymm8
	vpsrlvq	glob_data + 512(%rip), %ymm8, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpblendd	$12, %ymm1, %ymm1, %ymm1
	vpsrlvq	glob_data + 448(%rip), %ymm1, %ymm7
	vpsllvq	glob_data + 192(%rip), %ymm1, %ymm8
	vpor	%ymm8, %ymm7, %ymm7
	vpblendd	$12, %ymm2, %ymm11, %ymm1
	vpsrlvq	glob_data + 480(%rip), %ymm1, %ymm2
	vpsllvq	glob_data + 160(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm2, %ymm8
	vpxor	glob_data + 960(%rip), %ymm9, %ymm1
	vmovdqu	%ymm1, 1152(%rsi)
	vmovdqu	%ymm10, 1184(%rsi)
	vmovdqu	%ymm5, 1216(%rsi)
	vmovdqu	%ymm3, 1248(%rsi)
	vmovdqu	%ymm6, 1280(%rsi)
	vmovdqu	%ymm0, 1312(%rsi)
	vmovdqu	%ymm4, 1344(%rsi)
	vmovdqu	%ymm7, 1376(%rsi)
	vmovdqu	%ymm8, 1408(%rsi)
	vmovdqu	%ymm10, %ymm11
	vpand	%ymm5, %ymm11, %ymm11
	vpxor	%ymm11, %ymm1, %ymm1
	vmovdqu	%ymm1, %ymm2
	vpand	%ymm5, %ymm2, %ymm2
	vpxor	%ymm2, %ymm10, %ymm12
	vmovdqu	%ymm1, %ymm9
	vpor	%ymm12, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm11
	vpblendd	$12, %ymm1, %ymm1, %ymm1
	vpsrlvq	glob_data + 320(%rip), %ymm1, %ymm5
	vpsllvq	glob_data + 288(%rip), %ymm1, %ymm10
	vpor	%ymm10, %ymm5, %ymm5
	vpblendd	$12, %ymm6, %ymm4, %ymm1
	vpsrlvq	glob_data + 352(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 256(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm9, %ymm9
	vpblendd	$12, %ymm8, %ymm3, %ymm1
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm10
	vpsllvq	glob_data + 224(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm10, %ymm10
	vpblendd	$12, %ymm11, %ymm6, %ymm1
	vpsrlvq	glob_data + 544(%rip), %ymm1, %ymm2
	vpsllvq	glob_data + 128(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm2, %ymm1
	vpblendd	$12, %ymm3, %ymm12, %ymm2
	vpsrlvq	glob_data + 0(%rip), %ymm2, %ymm3
	vpsllvq	glob_data + 96(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm3, %ymm6
	vpblendd	$12, %ymm7, %ymm7, %ymm3
	vpsrlvq	glob_data + 384(%rip), %ymm3, %ymm2
	vpsllvq	glob_data + 64(%rip), %ymm3, %ymm3
	vpor	%ymm3, %ymm2, %ymm2
	vpblendd	$12, %ymm12, %ymm8, %ymm7
	vpsrlvq	glob_data + 512(%rip), %ymm7, %ymm3
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm8
	vpor	%ymm8, %ymm3, %ymm3
	vpblendd	$12, %ymm0, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm0, %ymm7
	vpsllvq	glob_data + 192(%rip), %ymm0, %ymm8
	vpor	%ymm8, %ymm7, %ymm7
	vpblendd	$12, %ymm4, %ymm11, %ymm0
	vpsrlvq	glob_data + 480(%rip), %ymm0, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm4, %ymm4
	vpxor	glob_data + 928(%rip), %ymm5, %ymm5
	vmovdqu	%ymm5, 1440(%rsi)
	vmovdqu	%ymm9, 1472(%rsi)
	vmovdqu	%ymm10, 1504(%rsi)
	vmovdqu	%ymm1, 1536(%rsi)
	vmovdqu	%ymm6, 1568(%rsi)
	vmovdqu	%ymm2, 1600(%rsi)
	vmovdqu	%ymm3, 1632(%rsi)
	vmovdqu	%ymm7, 1664(%rsi)
	vmovdqu	%ymm4, 1696(%rsi)
	vmovdqu	%ymm9, %ymm8
	vpand	%ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm5, %ymm5
	vmovdqu	%ymm5, %ymm0
	vpand	%ymm10, %ymm0, %ymm0
	vpxor	%ymm0, %ymm9, %ymm11
	vmovdqu	%ymm5, %ymm8
	vpor	%ymm11, %ymm8, %ymm8
	vpxor	%ymm8, %ymm10, %ymm12
	vpblendd	$12, %ymm5, %ymm5, %ymm0
	vpsrlvq	glob_data + 320(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 288(%rip), %ymm0, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpblendd	$12, %ymm6, %ymm3, %ymm0
	vpsrlvq	glob_data + 352(%rip), %ymm0, %ymm5
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm5
	vpblendd	$12, %ymm4, %ymm1, %ymm0
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm9
	vpsllvq	glob_data + 224(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm9, %ymm9
	vpblendd	$12, %ymm12, %ymm6, %ymm0
	vpsrlvq	glob_data + 544(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm0
	vpblendd	$12, %ymm1, %ymm11, %ymm1
	vpsrlvq	glob_data + 0(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm6
	vpblendd	$12, %ymm7, %ymm7, %ymm1
	vpsrlvq	glob_data + 384(%rip), %ymm1, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm7, %ymm1
	vpblendd	$12, %ymm11, %ymm4, %ymm7
	vpsrlvq	glob_data + 512(%rip), %ymm7, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 448(%rip), %ymm2, %ymm10
	vpsllvq	glob_data + 192(%rip), %ymm2, %ymm7
	vpor	%ymm7, %ymm10, %ymm10
	vpblendd	$12, %ymm3, %ymm12, %ymm2
	vpsrlvq	glob_data + 480(%rip), %ymm2, %ymm7
	vpsllvq	glob_data + 160(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm7, %ymm7
	vpxor	glob_data + 896(%rip), %ymm8, %ymm2
	vmovdqu	%ymm2, 1728(%rsi)
	vmovdqu	%ymm5, 1760(%rsi)
	vmovdqu	%ymm9, 1792(%rsi)
	vmovdqu	%ymm0, 1824(%rsi)
	vmovdqu	%ymm6, 1856(%rsi)
	vmovdqu	%ymm1, 1888(%rsi)
	vmovdqu	%ymm4, 1920(%rsi)
	vmovdqu	%ymm10, 1952(%rsi)
	vmovdqu	%ymm7, 1984(%rsi)
	vmovdqu	%ymm5, %ymm12
	vpand	%ymm9, %ymm12, %ymm12
	vpxor	%ymm12, %ymm2, %ymm2
	vmovdqu	%ymm2, %ymm3
	vpand	%ymm9, %ymm3, %ymm3
	vpxor	%ymm3, %ymm5, %ymm11
	vmovdqu	%ymm2, %ymm8
	vpor	%ymm11, %ymm8, %ymm8
	vpxor	%ymm8, %ymm9, %ymm12
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 320(%rip), %ymm2, %ymm3
	vpsllvq	glob_data + 288(%rip), %ymm2, %ymm9
	vpor	%ymm9, %ymm3, %ymm5
	vpblendd	$12, %ymm6, %ymm4, %ymm3
	vpsrlvq	glob_data + 352(%rip), %ymm3, %ymm8
	vpsllvq	glob_data + 256(%rip), %ymm3, %ymm2
	vpor	%ymm2, %ymm8, %ymm8
	vpblendd	$12, %ymm7, %ymm0, %ymm2
	vpsrlvq	glob_data + 416(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 224(%rip), %ymm2, %ymm3
	vpor	%ymm3, %ymm9, %ymm9
	vpblendd	$12, %ymm12, %ymm6, %ymm2
	vpsrlvq	glob_data + 544(%rip), %ymm2, %ymm3
	vpsllvq	glob_data + 128(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm3, %ymm2
	vpblendd	$12, %ymm0, %ymm11, %ymm0
	vpsrlvq	glob_data + 0(%rip), %ymm0, %ymm3
	vpsllvq	glob_data + 96(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm3, %ymm6
	vpblendd	$12, %ymm10, %ymm10, %ymm0
	vpsrlvq	glob_data + 384(%rip), %ymm0, %ymm3
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm3, %ymm3
	vpblendd	$12, %ymm11, %ymm7, %ymm10
	vpsrlvq	glob_data + 512(%rip), %ymm10, %ymm0
	vpsllvq	glob_data + 32(%rip), %ymm10, %ymm7
	vpor	%ymm7, %ymm0, %ymm0
	vpblendd	$12, %ymm1, %ymm1, %ymm7
	vpsrlvq	glob_data + 448(%rip), %ymm7, %ymm11
	vpsllvq	glob_data + 192(%rip), %ymm7, %ymm10
	vpor	%ymm10, %ymm11, %ymm7
	vpblendd	$12, %ymm4, %ymm12, %ymm1
	vpsrlvq	glob_data + 480(%rip), %ymm1, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm4, %ymm4
	vpxor	glob_data + 864(%rip), %ymm5, %ymm1
	vmovdqu	%ymm1, 2016(%rsi)
	vmovdqu	%ymm8, 2048(%rsi)
	vmovdqu	%ymm9, 2080(%rsi)
	vmovdqu	%ymm2, 2112(%rsi)
	vmovdqu	%ymm6, 2144(%rsi)
	vmovdqu	%ymm3, 2176(%rsi)
	vmovdqu	%ymm0, 2208(%rsi)
	vmovdqu	%ymm7, 2240(%rsi)
	vmovdqu	%ymm4, 2272(%rsi)
	vmovdqu	%ymm8, %ymm10
	vpand	%ymm9, %ymm10, %ymm10
	vpxor	%ymm10, %ymm1, %ymm1
	vmovdqu	%ymm1, %ymm5
	vpand	%ymm9, %ymm5, %ymm5
	vpxor	%ymm5, %ymm8, %ymm8
	vmovdqu	%ymm1, %ymm12
	vpor	%ymm8, %ymm12, %ymm12
	vpxor	%ymm12, %ymm9, %ymm12
	vpblendd	$12, %ymm1, %ymm1, %ymm1
	vpsrlvq	glob_data + 320(%rip), %ymm1, %ymm5
	vpsllvq	glob_data + 288(%rip), %ymm1, %ymm9
	vpor	%ymm9, %ymm5, %ymm5
	vpblendd	$12, %ymm6, %ymm0, %ymm1
	vpsrlvq	glob_data + 352(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 256(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm9, %ymm9
	vpblendd	$12, %ymm4, %ymm2, %ymm1
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm10
	vpsllvq	glob_data + 224(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm10, %ymm10
	vpblendd	$12, %ymm12, %ymm6, %ymm1
	vpsrlvq	glob_data + 544(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpblendd	$12, %ymm2, %ymm8, %ymm2
	vpsrlvq	glob_data + 0(%rip), %ymm2, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm6, %ymm6
	vpblendd	$12, %ymm7, %ymm7, %ymm2
	vpsrlvq	glob_data + 384(%rip), %ymm2, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm7, %ymm2
	vpblendd	$12, %ymm8, %ymm4, %ymm7
	vpsrlvq	glob_data + 512(%rip), %ymm7, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpblendd	$12, %ymm3, %ymm3, %ymm3
	vpsrlvq	glob_data + 448(%rip), %ymm3, %ymm8
	vpsllvq	glob_data + 192(%rip), %ymm3, %ymm7
	vpor	%ymm7, %ymm8, %ymm8
	vpblendd	$12, %ymm0, %ymm12, %ymm0
	vpsrlvq	glob_data + 480(%rip), %ymm0, %ymm3
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm3, %ymm3
	vpxor	glob_data + 832(%rip), %ymm5, %ymm0
	vmovdqu	%ymm0, 2304(%rsi)
	vmovdqu	%ymm9, 2336(%rsi)
	vmovdqu	%ymm10, 2368(%rsi)
	vmovdqu	%ymm1, 2400(%rsi)
	vmovdqu	%ymm6, 2432(%rsi)
	vmovdqu	%ymm2, 2464(%rsi)
	vmovdqu	%ymm4, 2496(%rsi)
	vmovdqu	%ymm8, 2528(%rsi)
	vmovdqu	%ymm3, 2560(%rsi)
	vmovdqu	%ymm9, %ymm5
	vpand	%ymm10, %ymm5, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vmovdqu	%ymm0, %ymm5
	vpand	%ymm10, %ymm5, %ymm5
	vpxor	%ymm5, %ymm9, %ymm12
	vmovdqu	%ymm0, %ymm7
	vpor	%ymm12, %ymm7, %ymm7
	vpxor	%ymm7, %ymm10, %ymm10
	vpblendd	$12, %ymm0, %ymm0, %ymm0
	vpsrlvq	glob_data + 320(%rip), %ymm0, %ymm7
	vpsllvq	glob_data + 288(%rip), %ymm0, %ymm5
	vpor	%ymm5, %ymm7, %ymm9
	vpblendd	$12, %ymm6, %ymm4, %ymm0
	vpsrlvq	glob_data + 352(%rip), %ymm0, %ymm7
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm7
	vpblendd	$12, %ymm3, %ymm1, %ymm0
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm5
	vpsllvq	glob_data + 224(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm5
	vpblendd	$12, %ymm10, %ymm6, %ymm0
	vpsrlvq	glob_data + 544(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm0
	vpblendd	$12, %ymm1, %ymm12, %ymm1
	vpsrlvq	glob_data + 0(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm6
	vpblendd	$12, %ymm8, %ymm8, %ymm1
	vpsrlvq	glob_data + 384(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm8, %ymm1
	vpblendd	$12, %ymm12, %ymm3, %ymm8
	vpsrlvq	glob_data + 512(%rip), %ymm8, %ymm3
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm3, %ymm3
	vpblendd	$12, %ymm2, %ymm2, %ymm8
	vpsrlvq	glob_data + 448(%rip), %ymm8, %ymm12
	vpsllvq	glob_data + 192(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm12, %ymm8
	vpblendd	$12, %ymm4, %ymm10, %ymm2
	vpsrlvq	glob_data + 480(%rip), %ymm2, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm4, %ymm4
	vpxor	glob_data + 800(%rip), %ymm9, %ymm2
	vmovdqu	%ymm2, 2592(%rsi)
	vmovdqu	%ymm7, 2624(%rsi)
	vmovdqu	%ymm5, 2656(%rsi)
	vmovdqu	%ymm0, 2688(%rsi)
	vmovdqu	%ymm6, 2720(%rsi)
	vmovdqu	%ymm1, 2752(%rsi)
	vmovdqu	%ymm3, 2784(%rsi)
	vmovdqu	%ymm8, 2816(%rsi)
	vmovdqu	%ymm4, 2848(%rsi)
	vmovdqu	%ymm7, %ymm10
	vpand	%ymm5, %ymm10, %ymm10
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	%ymm2, %ymm9
	vpand	%ymm5, %ymm9, %ymm9
	vpxor	%ymm9, %ymm7, %ymm7
	vmovdqu	%ymm2, %ymm9
	vpor	%ymm7, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm11
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 320(%rip), %ymm2, %ymm5
	vpsllvq	glob_data + 288(%rip), %ymm2, %ymm10
	vpor	%ymm10, %ymm5, %ymm5
	vpblendd	$12, %ymm6, %ymm3, %ymm2
	vpsrlvq	glob_data + 352(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 256(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm9, %ymm9
	vpblendd	$12, %ymm4, %ymm0, %ymm2
	vpsrlvq	glob_data + 416(%rip), %ymm2, %ymm10
	vpsllvq	glob_data + 224(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm10, %ymm10
	vpblendd	$12, %ymm11, %ymm6, %ymm2
	vpsrlvq	glob_data + 544(%rip), %ymm2, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm6, %ymm2
	vpblendd	$12, %ymm0, %ymm7, %ymm0
	vpsrlvq	glob_data + 0(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm6
	vpblendd	$12, %ymm8, %ymm8, %ymm0
	vpsrlvq	glob_data + 384(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm8, %ymm0
	vpblendd	$12, %ymm7, %ymm4, %ymm7
	vpsrlvq	glob_data + 512(%rip), %ymm7, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpblendd	$12, %ymm1, %ymm1, %ymm1
	vpsrlvq	glob_data + 448(%rip), %ymm1, %ymm7
	vpsllvq	glob_data + 192(%rip), %ymm1, %ymm8
	vpor	%ymm8, %ymm7, %ymm7
	vpblendd	$12, %ymm3, %ymm11, %ymm1
	vpsrlvq	glob_data + 480(%rip), %ymm1, %ymm3
	vpsllvq	glob_data + 160(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm3, %ymm3
	vpxor	glob_data + 768(%rip), %ymm5, %ymm1
	vmovdqu	%ymm1, 2880(%rsi)
	vmovdqu	%ymm9, 2912(%rsi)
	vmovdqu	%ymm10, 2944(%rsi)
	vmovdqu	%ymm2, 2976(%rsi)
	vmovdqu	%ymm6, 3008(%rsi)
	vmovdqu	%ymm0, 3040(%rsi)
	vmovdqu	%ymm4, 3072(%rsi)
	vmovdqu	%ymm7, 3104(%rsi)
	vmovdqu	%ymm3, 3136(%rsi)
	vmovdqu	%ymm9, %ymm8
	vpand	%ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm1, %ymm1
	vmovdqu	%ymm1, %ymm8
	vpand	%ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm9, %ymm11
	vmovdqu	%ymm1, %ymm5
	vpor	%ymm11, %ymm5, %ymm5
	vpxor	%ymm5, %ymm10, %ymm12
	vpblendd	$12, %ymm1, %ymm1, %ymm1
	vpsrlvq	glob_data + 320(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 288(%rip), %ymm1, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpblendd	$12, %ymm6, %ymm4, %ymm1
	vpsrlvq	glob_data + 352(%rip), %ymm1, %ymm5
	vpsllvq	glob_data + 256(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm5
	vpblendd	$12, %ymm3, %ymm2, %ymm1
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 224(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm9, %ymm9
	vpblendd	$12, %ymm12, %ymm6, %ymm1
	vpsrlvq	glob_data + 544(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpblendd	$12, %ymm2, %ymm11, %ymm2
	vpsrlvq	glob_data + 0(%rip), %ymm2, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm6, %ymm6
	vpblendd	$12, %ymm7, %ymm7, %ymm2
	vpsrlvq	glob_data + 384(%rip), %ymm2, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm7, %ymm2
	vpblendd	$12, %ymm11, %ymm3, %ymm7
	vpsrlvq	glob_data + 512(%rip), %ymm7, %ymm3
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm3, %ymm3
	vpblendd	$12, %ymm0, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm0, %ymm10
	vpsllvq	glob_data + 192(%rip), %ymm0, %ymm7
	vpor	%ymm7, %ymm10, %ymm10
	vpblendd	$12, %ymm4, %ymm12, %ymm0
	vpsrlvq	glob_data + 480(%rip), %ymm0, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm4, %ymm4
	vpxor	glob_data + 736(%rip), %ymm8, %ymm0
	vmovdqu	%ymm0, 3168(%rsi)
	vmovdqu	%ymm5, 3200(%rsi)
	vmovdqu	%ymm9, 3232(%rsi)
	vmovdqu	%ymm1, 3264(%rsi)
	vmovdqu	%ymm6, 3296(%rsi)
	vmovdqu	%ymm2, 3328(%rsi)
	vmovdqu	%ymm3, 3360(%rsi)
	vmovdqu	%ymm10, 3392(%rsi)
	vmovdqu	%ymm4, 3424(%rsi)
	vmovdqu	%ymm5, %ymm7
	vpand	%ymm9, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vmovdqu	%ymm0, %ymm7
	vpand	%ymm9, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm11
	vmovdqu	%ymm0, %ymm8
	vpor	%ymm11, %ymm8, %ymm8
	vpxor	%ymm8, %ymm9, %ymm12
	vpblendd	$12, %ymm0, %ymm0, %ymm0
	vpsrlvq	glob_data + 320(%rip), %ymm0, %ymm5
	vpsllvq	glob_data + 288(%rip), %ymm0, %ymm7
	vpor	%ymm7, %ymm5, %ymm5
	vpblendd	$12, %ymm6, %ymm3, %ymm0
	vpsrlvq	glob_data + 352(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 256(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm8, %ymm8
	vpblendd	$12, %ymm4, %ymm1, %ymm0
	vpsrlvq	glob_data + 416(%rip), %ymm0, %ymm7
	vpsllvq	glob_data + 224(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm7
	vpblendd	$12, %ymm12, %ymm6, %ymm0
	vpsrlvq	glob_data + 544(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm0
	vpblendd	$12, %ymm1, %ymm11, %ymm1
	vpsrlvq	glob_data + 0(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm6
	vpblendd	$12, %ymm10, %ymm10, %ymm1
	vpsrlvq	glob_data + 384(%rip), %ymm1, %ymm9
	vpsllvq	glob_data + 64(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm9, %ymm1
	vpblendd	$12, %ymm11, %ymm4, %ymm9
	vpsrlvq	glob_data + 512(%rip), %ymm9, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm9, %ymm9
	vpor	%ymm9, %ymm4, %ymm4
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 448(%rip), %ymm2, %ymm9
	vpsllvq	glob_data + 192(%rip), %ymm2, %ymm10
	vpor	%ymm10, %ymm9, %ymm9
	vpblendd	$12, %ymm3, %ymm12, %ymm2
	vpsrlvq	glob_data + 480(%rip), %ymm2, %ymm3
	vpsllvq	glob_data + 160(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm3, %ymm3
	vpxor	glob_data + 704(%rip), %ymm5, %ymm2
	vmovdqu	%ymm2, 3456(%rsi)
	vmovdqu	%ymm8, 3488(%rsi)
	vmovdqu	%ymm7, 3520(%rsi)
	vmovdqu	%ymm0, 3552(%rsi)
	vmovdqu	%ymm6, 3584(%rsi)
	vmovdqu	%ymm1, 3616(%rsi)
	vmovdqu	%ymm4, 3648(%rsi)
	vmovdqu	%ymm9, 3680(%rsi)
	vmovdqu	%ymm3, 3712(%rsi)
	vmovdqu	%ymm8, %ymm10
	vpand	%ymm7, %ymm10, %ymm10
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	%ymm2, %ymm5
	vpand	%ymm7, %ymm5, %ymm5
	vpxor	%ymm5, %ymm8, %ymm8
	vmovdqu	%ymm2, %ymm12
	vpor	%ymm8, %ymm12, %ymm12
	vpxor	%ymm12, %ymm7, %ymm12
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 320(%rip), %ymm2, %ymm5
	vpsllvq	glob_data + 288(%rip), %ymm2, %ymm10
	vpor	%ymm10, %ymm5, %ymm5
	vpblendd	$12, %ymm6, %ymm4, %ymm2
	vpsrlvq	glob_data + 352(%rip), %ymm2, %ymm7
	vpsllvq	glob_data + 256(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm7, %ymm7
	vpblendd	$12, %ymm3, %ymm0, %ymm2
	vpsrlvq	glob_data + 416(%rip), %ymm2, %ymm10
	vpsllvq	glob_data + 224(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm10, %ymm10
	vpblendd	$12, %ymm12, %ymm6, %ymm2
	vpsrlvq	glob_data + 544(%rip), %ymm2, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm6, %ymm2
	vpblendd	$12, %ymm0, %ymm8, %ymm0
	vpsrlvq	glob_data + 0(%rip), %ymm0, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm6
	vpblendd	$12, %ymm9, %ymm9, %ymm0
	vpsrlvq	glob_data + 384(%rip), %ymm0, %ymm9
	vpsllvq	glob_data + 64(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm9, %ymm0
	vpblendd	$12, %ymm8, %ymm3, %ymm8
	vpsrlvq	glob_data + 512(%rip), %ymm8, %ymm3
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm3, %ymm3
	vpblendd	$12, %ymm1, %ymm1, %ymm1
	vpsrlvq	glob_data + 448(%rip), %ymm1, %ymm8
	vpsllvq	glob_data + 192(%rip), %ymm1, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpblendd	$12, %ymm4, %ymm12, %ymm1
	vpsrlvq	glob_data + 480(%rip), %ymm1, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm4, %ymm4
	vpxor	glob_data + 672(%rip), %ymm5, %ymm1
	vmovdqu	%ymm1, 3744(%rsi)
	vmovdqu	%ymm7, 3776(%rsi)
	vmovdqu	%ymm10, 3808(%rsi)
	vmovdqu	%ymm2, 3840(%rsi)
	vmovdqu	%ymm6, 3872(%rsi)
	vmovdqu	%ymm0, 3904(%rsi)
	vmovdqu	%ymm3, 3936(%rsi)
	vmovdqu	%ymm8, 3968(%rsi)
	vmovdqu	%ymm4, 4000(%rsi)
	vmovdqu	%ymm7, %ymm5
	vpand	%ymm10, %ymm5, %ymm5
	vpxor	%ymm5, %ymm1, %ymm1
	vmovdqu	%ymm1, %ymm5
	vpand	%ymm10, %ymm5, %ymm5
	vpxor	%ymm5, %ymm7, %ymm12
	vmovdqu	%ymm1, %ymm7
	vpor	%ymm12, %ymm7, %ymm7
	vpxor	%ymm7, %ymm10, %ymm10
	vpblendd	$12, %ymm1, %ymm1, %ymm1
	vpsrlvq	glob_data + 320(%rip), %ymm1, %ymm7
	vpsllvq	glob_data + 288(%rip), %ymm1, %ymm5
	vpor	%ymm5, %ymm7, %ymm9
	vpblendd	$12, %ymm6, %ymm3, %ymm1
	vpsrlvq	glob_data + 352(%rip), %ymm1, %ymm7
	vpsllvq	glob_data + 256(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm7, %ymm7
	vpblendd	$12, %ymm4, %ymm2, %ymm1
	vpsrlvq	glob_data + 416(%rip), %ymm1, %ymm5
	vpsllvq	glob_data + 224(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm5
	vpblendd	$12, %ymm10, %ymm6, %ymm1
	vpsrlvq	glob_data + 544(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 128(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpblendd	$12, %ymm2, %ymm12, %ymm2
	vpsrlvq	glob_data + 0(%rip), %ymm2, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm6, %ymm6
	vpblendd	$12, %ymm8, %ymm8, %ymm2
	vpsrlvq	glob_data + 384(%rip), %ymm2, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm8, %ymm2
	vpblendd	$12, %ymm12, %ymm4, %ymm8
	vpsrlvq	glob_data + 512(%rip), %ymm8, %ymm4
	vpsllvq	glob_data + 32(%rip), %ymm8, %ymm8
	vpor	%ymm8, %ymm4, %ymm4
	vpblendd	$12, %ymm0, %ymm0, %ymm0
	vpsrlvq	glob_data + 448(%rip), %ymm0, %ymm8
	vpsllvq	glob_data + 192(%rip), %ymm0, %ymm11
	vpor	%ymm11, %ymm8, %ymm8
	vpblendd	$12, %ymm3, %ymm10, %ymm0
	vpsrlvq	glob_data + 480(%rip), %ymm0, %ymm3
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm3, %ymm0
	vpxor	glob_data + 640(%rip), %ymm9, %ymm3
	vmovdqu	%ymm3, 4032(%rsi)
	vmovdqu	%ymm7, 4064(%rsi)
	vmovdqu	%ymm5, 4096(%rsi)
	vmovdqu	%ymm1, 4128(%rsi)
	vmovdqu	%ymm6, 4160(%rsi)
	vmovdqu	%ymm2, 4192(%rsi)
	vmovdqu	%ymm4, 4224(%rsi)
	vmovdqu	%ymm8, 4256(%rsi)
	vmovdqu	%ymm0, 4288(%rsi)
	vmovdqu	%ymm7, %ymm10
	vpand	%ymm5, %ymm10, %ymm10
	vpxor	%ymm10, %ymm3, %ymm3
	vmovdqu	%ymm3, %ymm9
	vpand	%ymm5, %ymm9, %ymm9
	vpxor	%ymm9, %ymm7, %ymm7
	vmovdqu	%ymm3, %ymm9
	vpor	%ymm7, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm11
	vpblendd	$12, %ymm3, %ymm3, %ymm3
	vpsrlvq	glob_data + 320(%rip), %ymm3, %ymm5
	vpsllvq	glob_data + 288(%rip), %ymm3, %ymm10
	vpor	%ymm10, %ymm5, %ymm3
	vpblendd	$12, %ymm6, %ymm4, %ymm9
	vpsrlvq	glob_data + 352(%rip), %ymm9, %ymm10
	vpsllvq	glob_data + 256(%rip), %ymm9, %ymm9
	vpor	%ymm9, %ymm10, %ymm9
	vpblendd	$12, %ymm0, %ymm1, %ymm5
	vpsrlvq	glob_data + 416(%rip), %ymm5, %ymm10
	vpsllvq	glob_data + 224(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm10, %ymm10
	vpblendd	$12, %ymm11, %ymm6, %ymm6
	vpsrlvq	glob_data + 544(%rip), %ymm6, %ymm5
	vpsllvq	glob_data + 128(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm5, %ymm5
	vpblendd	$12, %ymm1, %ymm7, %ymm1
	vpsrlvq	glob_data + 0(%rip), %ymm1, %ymm6
	vpsllvq	glob_data + 96(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm6, %ymm1
	vpblendd	$12, %ymm8, %ymm8, %ymm6
	vpsrlvq	glob_data + 384(%rip), %ymm6, %ymm8
	vpsllvq	glob_data + 64(%rip), %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm6
	vpblendd	$12, %ymm7, %ymm0, %ymm7
	vpsrlvq	glob_data + 512(%rip), %ymm7, %ymm0
	vpsllvq	glob_data + 32(%rip), %ymm7, %ymm7
	vpor	%ymm7, %ymm0, %ymm0
	vpblendd	$12, %ymm2, %ymm2, %ymm2
	vpsrlvq	glob_data + 448(%rip), %ymm2, %ymm7
	vpsllvq	glob_data + 192(%rip), %ymm2, %ymm8
	vpor	%ymm8, %ymm7, %ymm7
	vpblendd	$12, %ymm4, %ymm11, %ymm2
	vpsrlvq	glob_data + 480(%rip), %ymm2, %ymm4
	vpsllvq	glob_data + 160(%rip), %ymm2, %ymm2
	vpor	%ymm2, %ymm4, %ymm2
	vpxor	glob_data + 608(%rip), %ymm3, %ymm3
	vmovdqu	%ymm3, 4320(%rsi)
	vmovdqu	%ymm9, 4352(%rsi)
	vmovdqu	%ymm10, 4384(%rsi)
	vmovdqu	%ymm5, 4416(%rsi)
	vmovdqu	%ymm1, 4448(%rsi)
	vmovdqu	%ymm6, 4480(%rsi)
	vmovdqu	%ymm0, 4512(%rsi)
	vmovdqu	%ymm7, 4544(%rsi)
	vmovdqu	%ymm2, 4576(%rsi)
	vmovdqu	%ymm9, %ymm8
	vpand	%ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vmovdqu	%ymm3, %ymm4
	vpand	%ymm10, %ymm4, %ymm4
	vpxor	%ymm4, %ymm9, %ymm9
	vmovdqu	%ymm3, %ymm8
	vpor	%ymm9, %ymm8, %ymm8
	vpxor	%ymm8, %ymm10, %ymm8
	vpblendd	$12, %ymm3, %ymm3, %ymm3
	vpsrlvq	glob_data + 320(%rip), %ymm3, %ymm4
	vpsllvq	glob_data + 288(%rip), %ymm3, %ymm12
	vpor	%ymm12, %ymm4, %ymm3
	vpblendd	$12, %ymm1, %ymm0, %ymm4
	vpsrlvq	glob_data + 352(%rip), %ymm4, %ymm11
	vpsllvq	glob_data + 256(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm11, %ymm11
	vpblendd	$12, %ymm2, %ymm5, %ymm4
	vpsrlvq	glob_data + 416(%rip), %ymm4, %ymm12
	vpsllvq	glob_data + 224(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm12, %ymm12
	vpblendd	$12, %ymm8, %ymm1, %ymm1
	vpsrlvq	glob_data + 544(%rip), %ymm1, %ymm4
	vpsllvq	glob_data + 128(%rip), %ymm1, %ymm1
	vpor	%ymm1, %ymm4, %ymm1
	vpblendd	$12, %ymm5, %ymm9, %ymm4
	vpsrlvq	glob_data + 0(%rip), %ymm4, %ymm5
	vpsllvq	glob_data + 96(%rip), %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm4
	vpblendd	$12, %ymm7, %ymm7, %ymm5
	vpsrlvq	glob_data + 384(%rip), %ymm5, %ymm7
	vpsllvq	glob_data + 64(%rip), %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm7
	vpblendd	$12, %ymm9, %ymm2, %ymm9
	vpsrlvq	glob_data + 512(%rip), %ymm9, %ymm2
	vpsllvq	glob_data + 32(%rip), %ymm9, %ymm5
	vpor	%ymm5, %ymm2, %ymm2
	vpblendd	$12, %ymm6, %ymm6, %ymm5
	vpsrlvq	glob_data + 448(%rip), %ymm5, %ymm9
	vpsllvq	glob_data + 192(%rip), %ymm5, %ymm10
	vpor	%ymm10, %ymm9, %ymm9
	vpblendd	$12, %ymm0, %ymm8, %ymm0
	vpsrlvq	glob_data + 480(%rip), %ymm0, %ymm5
	vpsllvq	glob_data + 160(%rip), %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm0
	vpxor	glob_data + 576(%rip), %ymm3, %ymm3
	vmovdqu	%ymm3, 4608(%rsi)
	vmovdqu	%ymm11, 4640(%rsi)
	vmovdqu	%ymm12, 4672(%rsi)
	vmovdqu	%ymm1, 4704(%rsi)
	vmovdqu	%ymm4, 4736(%rsi)
	vmovdqu	%ymm7, 4768(%rsi)
	vmovdqu	%ymm2, 4800(%rsi)
	vmovdqu	%ymm9, 4832(%rsi)
	vmovdqu	%ymm0, 4864(%rsi)
	ret
	.data
	.p2align	5
glob_data:
G$kvc_b0000000000000000:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,  11,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_40000000000000004000000000000000400000000000000029:
	.byte	 41,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_400000000000000040000000000000003d000000000000001f:
	.byte	 31,   0,   0,   0,   0,   0,   0,   0,  61,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_40000000000000004000000000000000350000000000000040:
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  53,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_400000000000000040000000000000002b0000000000000011:
	.byte	 17,   0,   0,   0,   0,   0,   0,   0,  43,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_4000000000000000400000000000000025000000000000003b:
	.byte	 59,   0,   0,   0,   0,   0,   0,   0,  37,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_400000000000000040000000000000001d000000000000002f:
	.byte	 47,   0,   0,   0,   0,   0,   0,   0,  29,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_4000000000000000400000000000000013000000000000000b:
	.byte	 11,   0,   0,   0,   0,   0,   0,   0,  19,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_40000000000000004000000000000000070000000000000005:
	.byte	  5,   0,   0,   0,   0,   0,   0,   0,   7,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_40000000000000004000000000000000030000000000000001:
	.byte	  1,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0
	.byte	 64,   0,   0,   0,   0,   0,   0,   0,  64,   0,   0,   0,   0,   0,   0,   0
G$kvc_3d000000000000003f:
	.byte	 63,   0,   0,   0,   0,   0,   0,   0,  61,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_39000000000000003b:
	.byte	 59,   0,   0,   0,   0,   0,   0,   0,  57,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_30000000000000021:
	.byte	 33,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_2d0000000000000035:
	.byte	 53,   0,   0,   0,   0,   0,   0,   0,  45,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_230000000000000011:
	.byte	 17,   0,   0,   0,   0,   0,   0,   0,  35,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_1b0000000000000005:
	.byte	  5,   0,   0,   0,   0,   0,   0,   0,  27,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_17:
	.byte	 23,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$kvc_15000000000000002f:
	.byte	 47,   0,   0,   0,   0,   0,   0,   0,  21,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV15:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,  68,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV14:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 115,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV13:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 112,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV12:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV11:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,  46,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV10:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 138,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV9:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,  25,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV8:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,  19,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV7:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 211,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV6:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   8,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV5:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 163,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV4:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 133,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV3:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 136,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV2:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 106,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV1:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,  63,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$CTV0:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,  36,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits
