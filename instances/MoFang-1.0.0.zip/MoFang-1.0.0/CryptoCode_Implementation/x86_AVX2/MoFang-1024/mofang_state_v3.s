	.att_syntax
	.text
	.p2align	5
	.global	mofang_state_v3
	.type	mofang_state_v3, %function
mofang_state_v3:
	vmovdqu	(%rdi), %ymm0
	vmovdqu	32(%rdi), %ymm1
	vmovdqu	64(%rdi), %ymm3
	vmovdqu	96(%rdi), %ymm6
	vmovdqu	128(%rdi), %ymm5
	vmovdqu	160(%rdi), %ymm8
	vmovdqu	192(%rdi), %ymm7
	vmovdqu	224(%rdi), %ymm9
	vmovdqu	256(%rdi), %ymm10
	vmovdqu	(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm12
	vpxor	%ymm12, %ymm2, %ymm2
	vmovdqu	(%rdx), %ymm11
	vpxor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm0
	vmovdqu	32(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm11
	vpxor	%ymm11, %ymm2, %ymm2
	vmovdqu	32(%rdx), %ymm12
	vpxor	%ymm2, %ymm1, %ymm1
	vpxor	%ymm1, %ymm12, %ymm1
	vmovdqu	64(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	64(%rdx), %ymm11
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm3, %ymm11, %ymm2
	vmovdqu	96(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vmovdqu	96(%rdx), %ymm4
	vpxor	%ymm3, %ymm6, %ymm3
	vpxor	%ymm3, %ymm4, %ymm4
	vmovdqu	128(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vmovdqu	128(%rdx), %ymm6
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm5, %ymm6, %ymm3
	vmovdqu	160(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm11
	vpxor	%ymm11, %ymm6, %ymm6
	vmovdqu	160(%rdx), %ymm5
	vpxor	%ymm6, %ymm8, %ymm8
	vpxor	%ymm8, %ymm5, %ymm5
	vmovdqu	192(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm6
	vpxor	%ymm6, %ymm8, %ymm8
	vmovdqu	192(%rdx), %ymm6
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vmovdqu	224(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm11
	vpxor	%ymm11, %ymm8, %ymm8
	vmovdqu	224(%rdx), %ymm7
	vpxor	%ymm8, %ymm9, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vmovdqu	256(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm12
	vpxor	%ymm12, %ymm8, %ymm8
	vmovdqu	256(%rdx), %ymm9
	vpxor	%ymm8, %ymm10, %ymm10
	vpxor	%ymm10, %ymm9, %ymm8
	vmovdqu	%ymm1, %ymm9
	vpand	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm0, %ymm0
	vmovdqu	%ymm0, %ymm9
	vpand	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vmovdqu	%ymm0, %ymm12
	vpor	%ymm1, %ymm12, %ymm12
	vpxor	%ymm12, %ymm2, %ymm2
	vmovdqu	%ymm3, %ymm9
	vpand	%ymm5, %ymm9, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vmovdqu	%ymm4, %ymm9
	vpand	%ymm5, %ymm9, %ymm9
	vpxor	%ymm9, %ymm3, %ymm9
	vmovdqu	%ymm4, %ymm3
	vpor	%ymm9, %ymm3, %ymm3
	vpxor	%ymm3, %ymm5, %ymm3
	vmovdqu	%ymm7, %ymm5
	vpand	%ymm8, %ymm5, %ymm5
	vpxor	%ymm5, %ymm6, %ymm11
	vmovdqu	%ymm11, %ymm12
	vpand	%ymm8, %ymm12, %ymm12
	vpxor	%ymm12, %ymm7, %ymm5
	vmovdqu	%ymm11, %ymm7
	vpor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm8, %ymm8
	vmovdqu	%ymm0, %ymm6
	vpxor	%ymm4, %ymm6, %ymm6
	vpxor	%ymm11, %ymm6, %ymm7
	vmovdqu	%ymm1, %ymm6
	vpxor	%ymm9, %ymm6, %ymm6
	vpxor	%ymm5, %ymm6, %ymm6
	vmovdqu	%ymm2, %ymm12
	vpxor	%ymm3, %ymm12, %ymm12
	vpxor	%ymm8, %ymm12, %ymm12
	vpxor	%ymm12, %ymm7, %ymm10
	vpxor	%ymm12, %ymm0, %ymm0
	vpxor	%ymm12, %ymm4, %ymm4
	vpxor	%ymm12, %ymm11, %ymm7
	vpxor	%ymm10, %ymm1, %ymm11
	vpxor	%ymm10, %ymm9, %ymm1
	vpxor	%ymm10, %ymm5, %ymm5
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm6, %ymm3, %ymm9
	vpxor	%ymm6, %ymm8, %ymm3
	vpsrlq	$61, %ymm11, %ymm6
	vpsllq	$3, %ymm11, %ymm8
	vpor	%ymm8, %ymm6, %ymm12
	vpsrlq	$58, %ymm2, %ymm6
	vpsllq	$6, %ymm2, %ymm8
	vpor	%ymm8, %ymm6, %ymm2
	vpsrlq	$55, %ymm4, %ymm6
	vpsllq	$9, %ymm4, %ymm8
	vpor	%ymm8, %ymm6, %ymm4
	vpsrlq	$52, %ymm1, %ymm6
	vpsllq	$12, %ymm1, %ymm8
	vpor	%ymm8, %ymm6, %ymm6
	vpsrlq	$49, %ymm9, %ymm1
	vpsllq	$15, %ymm9, %ymm8
	vpor	%ymm8, %ymm1, %ymm8
	vpsrlq	$46, %ymm7, %ymm1
	vpsllq	$18, %ymm7, %ymm7
	vpor	%ymm7, %ymm1, %ymm7
	vpsrlq	$43, %ymm5, %ymm1
	vpsllq	$21, %ymm5, %ymm5
	vpor	%ymm5, %ymm1, %ymm9
	vpshufb	glob_data + 64(%rip), %ymm3, %ymm10
	vmovdqu	288(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vmovdqu	(%rdx), %ymm3
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm3, %ymm11
	vmovdqu	320(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm3
	vpxor	%ymm3, %ymm0, %ymm0
	vmovdqu	128(%rdx), %ymm3
	vpxor	%ymm0, %ymm12, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vmovdqu	352(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vmovdqu	256(%rdx), %ymm5
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm2, %ymm5, %ymm0
	vmovdqu	384(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vmovdqu	64(%rdx), %ymm5
	vpxor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm4, %ymm5, %ymm1
	vmovdqu	416(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	96(%rdx), %ymm12
	vpxor	%ymm2, %ymm6, %ymm2
	vpxor	%ymm2, %ymm12, %ymm2
	vmovdqu	448(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vmovdqu	224(%rdx), %ymm4
	vpxor	%ymm5, %ymm8, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vmovdqu	480(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm5
	vpxor	%ymm5, %ymm6, %ymm6
	vmovdqu	32(%rdx), %ymm5
	vpxor	%ymm6, %ymm7, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vmovdqu	512(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vmovdqu	160(%rdx), %ymm7
	vpxor	%ymm6, %ymm9, %ymm9
	vpxor	%ymm9, %ymm7, %ymm6
	vmovdqu	544(%rsi), %ymm9
	vpermq	$225, %ymm9, %ymm7
	vpxor	%ymm7, %ymm9, %ymm9
	vmovdqu	192(%rdx), %ymm8
	vpxor	%ymm9, %ymm10, %ymm10
	vpxor	%ymm10, %ymm8, %ymm8
	vmovdqu	%ymm3, %ymm7
	vpand	%ymm0, %ymm7, %ymm7
	vpxor	%ymm7, %ymm11, %ymm11
	vmovdqu	%ymm11, %ymm7
	vpand	%ymm0, %ymm7, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vmovdqu	%ymm11, %ymm7
	vpor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vmovdqu	%ymm2, %ymm9
	vpand	%ymm4, %ymm9, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vmovdqu	%ymm1, %ymm10
	vpand	%ymm4, %ymm10, %ymm10
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	%ymm1, %ymm7
	vpor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vmovdqu	%ymm6, %ymm7
	vpand	%ymm8, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vmovdqu	%ymm5, %ymm7
	vpand	%ymm8, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm7
	vmovdqu	%ymm5, %ymm6
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm8, %ymm8
	vmovdqu	%ymm11, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpxor	%ymm5, %ymm6, %ymm6
	vmovdqu	%ymm3, %ymm9
	vpxor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm7, %ymm9, %ymm9
	vmovdqu	%ymm0, %ymm10
	vpxor	%ymm4, %ymm10, %ymm10
	vpxor	%ymm8, %ymm10, %ymm12
	vpxor	%ymm12, %ymm6, %ymm10
	vpxor	%ymm12, %ymm11, %ymm6
	vpxor	%ymm12, %ymm1, %ymm1
	vpxor	%ymm12, %ymm5, %ymm5
	vpxor	%ymm10, %ymm3, %ymm3
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm10, %ymm7, %ymm10
	vpxor	%ymm9, %ymm0, %ymm11
	vpxor	%ymm9, %ymm4, %ymm4
	vpxor	%ymm9, %ymm8, %ymm8
	vpshufb	glob_data + 64(%rip), %ymm3, %ymm0
	vpshufb	glob_data + 160(%rip), %ymm11, %ymm9
	vpshufb	glob_data + 0(%rip), %ymm1, %ymm1
	vpshufb	glob_data + 96(%rip), %ymm2, %ymm2
	vpshufb	glob_data + 192(%rip), %ymm4, %ymm7
	vpshufb	glob_data + 32(%rip), %ymm5, %ymm3
	vpshufb	glob_data + 128(%rip), %ymm10, %ymm4
	vpsrlq	$57, %ymm8, %ymm5
	vpsllq	$7, %ymm8, %ymm8
	vpor	%ymm8, %ymm5, %ymm5
	vmovdqu	576(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm10
	vpxor	%ymm10, %ymm8, %ymm8
	vmovdqu	(%rdx), %ymm11
	vpxor	%ymm8, %ymm6, %ymm6
	vpxor	%ymm6, %ymm11, %ymm6
	vmovdqu	608(%rsi), %ymm10
	vpermq	$225, %ymm10, %ymm8
	vpxor	%ymm8, %ymm10, %ymm10
	vmovdqu	96(%rdx), %ymm8
	vpxor	%ymm10, %ymm0, %ymm0
	vpxor	%ymm0, %ymm8, %ymm8
	vmovdqu	640(%rsi), %ymm12
	vpermq	$225, %ymm12, %ymm0
	vpxor	%ymm0, %ymm12, %ymm12
	vmovdqu	192(%rdx), %ymm0
	vpxor	%ymm12, %ymm9, %ymm9
	vpxor	%ymm9, %ymm0, %ymm9
	vmovdqu	672(%rsi), %ymm10
	vpermq	$225, %ymm10, %ymm0
	vpxor	%ymm0, %ymm10, %ymm10
	vmovdqu	256(%rdx), %ymm0
	vpxor	%ymm10, %ymm1, %ymm1
	vpxor	%ymm1, %ymm0, %ymm11
	vmovdqu	704(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm0
	vpxor	%ymm0, %ymm1, %ymm1
	vmovdqu	64(%rdx), %ymm0
	vpxor	%ymm1, %ymm2, %ymm2
	vpxor	%ymm2, %ymm0, %ymm1
	vmovdqu	736(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm0
	vpxor	%ymm0, %ymm2, %ymm2
	vmovdqu	160(%rdx), %ymm0
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vmovdqu	768(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm10
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	128(%rdx), %ymm7
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm3, %ymm7, %ymm2
	vmovdqu	800(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm10
	vpxor	%ymm10, %ymm7, %ymm7
	vmovdqu	224(%rdx), %ymm10
	vpxor	%ymm7, %ymm4, %ymm3
	vpxor	%ymm3, %ymm10, %ymm10
	vmovdqu	832(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vmovdqu	32(%rdx), %ymm7
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vmovdqu	%ymm8, %ymm4
	vpand	%ymm9, %ymm4, %ymm4
	vpxor	%ymm4, %ymm6, %ymm5
	vmovdqu	%ymm5, %ymm3
	vpand	%ymm9, %ymm3, %ymm3
	vpxor	%ymm3, %ymm8, %ymm4
	vmovdqu	%ymm5, %ymm3
	vpor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm9, %ymm3
	vmovdqu	%ymm1, %ymm8
	vpand	%ymm0, %ymm8, %ymm8
	vpxor	%ymm8, %ymm11, %ymm6
	vmovdqu	%ymm6, %ymm8
	vpand	%ymm0, %ymm8, %ymm8
	vpxor	%ymm8, %ymm1, %ymm1
	vmovdqu	%ymm6, %ymm9
	vpor	%ymm1, %ymm9, %ymm9
	vpxor	%ymm9, %ymm0, %ymm0
	vmovdqu	%ymm10, %ymm8
	vpand	%ymm7, %ymm8, %ymm8
	vpxor	%ymm8, %ymm2, %ymm9
	vmovdqu	%ymm9, %ymm8
	vpand	%ymm7, %ymm8, %ymm8
	vpxor	%ymm8, %ymm10, %ymm10
	vmovdqu	%ymm9, %ymm2
	vpor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm2, %ymm7, %ymm7
	vmovdqu	%ymm5, %ymm8
	vpxor	%ymm6, %ymm8, %ymm8
	vpxor	%ymm9, %ymm8, %ymm8
	vmovdqu	%ymm4, %ymm2
	vpxor	%ymm1, %ymm2, %ymm2
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	%ymm3, %ymm11
	vpxor	%ymm0, %ymm11, %ymm11
	vpxor	%ymm7, %ymm11, %ymm12
	vpxor	%ymm12, %ymm8, %ymm11
	vpxor	%ymm12, %ymm5, %ymm5
	vpxor	%ymm12, %ymm6, %ymm6
	vpxor	%ymm12, %ymm9, %ymm8
	vpxor	%ymm11, %ymm4, %ymm9
	vpxor	%ymm11, %ymm1, %ymm1
	vpxor	%ymm11, %ymm10, %ymm4
	vpxor	%ymm2, %ymm3, %ymm10
	vpxor	%ymm2, %ymm0, %ymm11
	vpxor	%ymm2, %ymm7, %ymm0
	vpsrlq	$61, %ymm9, %ymm2
	vpsllq	$3, %ymm9, %ymm7
	vpor	%ymm7, %ymm2, %ymm12
	vpsrlq	$58, %ymm10, %ymm2
	vpsllq	$6, %ymm10, %ymm7
	vpor	%ymm7, %ymm2, %ymm2
	vpsrlq	$55, %ymm6, %ymm3
	vpsllq	$9, %ymm6, %ymm7
	vpor	%ymm7, %ymm3, %ymm3
	vpsrlq	$52, %ymm1, %ymm6
	vpsllq	$12, %ymm1, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$49, %ymm11, %ymm1
	vpsllq	$15, %ymm11, %ymm7
	vpor	%ymm7, %ymm1, %ymm7
	vpsrlq	$46, %ymm8, %ymm1
	vpsllq	$18, %ymm8, %ymm8
	vpor	%ymm8, %ymm1, %ymm8
	vpsrlq	$43, %ymm4, %ymm1
	vpsllq	$21, %ymm4, %ymm4
	vpor	%ymm4, %ymm1, %ymm9
	vpshufb	glob_data + 64(%rip), %ymm0, %ymm11
	vmovdqu	864(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vmovdqu	(%rdx), %ymm1
	vpxor	%ymm0, %ymm5, %ymm4
	vpxor	%ymm4, %ymm1, %ymm10
	vmovdqu	896(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vmovdqu	64(%rdx), %ymm1
	vpxor	%ymm0, %ymm12, %ymm4
	vpxor	%ymm4, %ymm1, %ymm0
	vmovdqu	928(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm4
	vpxor	%ymm4, %ymm1, %ymm1
	vmovdqu	32(%rdx), %ymm5
	vpxor	%ymm1, %ymm2, %ymm1
	vpxor	%ymm1, %ymm5, %ymm1
	vmovdqu	960(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	192(%rdx), %ymm4
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm3, %ymm4, %ymm5
	vmovdqu	992(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm3
	vpxor	%ymm3, %ymm2, %ymm2
	vmovdqu	256(%rdx), %ymm3
	vpxor	%ymm2, %ymm6, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vmovdqu	1024(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	224(%rdx), %ymm12
	vpxor	%ymm2, %ymm7, %ymm2
	vpxor	%ymm2, %ymm12, %ymm2
	vmovdqu	1056(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vmovdqu	96(%rdx), %ymm4
	vpxor	%ymm6, %ymm8, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vmovdqu	1088(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vmovdqu	160(%rdx), %ymm7
	vpxor	%ymm6, %ymm9, %ymm6
	vpxor	%ymm6, %ymm7, %ymm6
	vmovdqu	1120(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vmovdqu	128(%rdx), %ymm9
	vpxor	%ymm7, %ymm11, %ymm11
	vpxor	%ymm11, %ymm9, %ymm7
	vmovdqu	%ymm0, %ymm11
	vpand	%ymm1, %ymm11, %ymm11
	vpxor	%ymm11, %ymm10, %ymm9
	vmovdqu	%ymm9, %ymm8
	vpand	%ymm1, %ymm8, %ymm8
	vpxor	%ymm8, %ymm0, %ymm0
	vmovdqu	%ymm9, %ymm8
	vpor	%ymm0, %ymm8, %ymm8
	vpxor	%ymm8, %ymm1, %ymm1
	vmovdqu	%ymm3, %ymm10
	vpand	%ymm2, %ymm10, %ymm10
	vpxor	%ymm10, %ymm5, %ymm5
	vmovdqu	%ymm5, %ymm11
	vpand	%ymm2, %ymm11, %ymm11
	vpxor	%ymm11, %ymm3, %ymm3
	vmovdqu	%ymm5, %ymm10
	vpor	%ymm3, %ymm10, %ymm10
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	%ymm6, %ymm8
	vpand	%ymm7, %ymm8, %ymm8
	vpxor	%ymm8, %ymm4, %ymm8
	vmovdqu	%ymm8, %ymm4
	vpand	%ymm7, %ymm4, %ymm4
	vpxor	%ymm4, %ymm6, %ymm6
	vmovdqu	%ymm8, %ymm10
	vpor	%ymm6, %ymm10, %ymm10
	vpxor	%ymm10, %ymm7, %ymm7
	vmovdqu	%ymm9, %ymm11
	vpxor	%ymm5, %ymm11, %ymm11
	vpxor	%ymm8, %ymm11, %ymm11
	vmovdqu	%ymm0, %ymm4
	vpxor	%ymm3, %ymm4, %ymm4
	vpxor	%ymm6, %ymm4, %ymm10
	vmovdqu	%ymm1, %ymm4
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm7, %ymm4, %ymm12
	vpxor	%ymm12, %ymm11, %ymm11
	vpxor	%ymm12, %ymm9, %ymm9
	vpxor	%ymm12, %ymm5, %ymm4
	vpxor	%ymm12, %ymm8, %ymm5
	vpxor	%ymm11, %ymm0, %ymm0
	vpxor	%ymm11, %ymm3, %ymm3
	vpxor	%ymm11, %ymm6, %ymm6
	vpxor	%ymm10, %ymm1, %ymm8
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm10, %ymm7, %ymm1
	vpshufb	glob_data + 64(%rip), %ymm0, %ymm7
	vpshufb	glob_data + 160(%rip), %ymm8, %ymm10
	vpshufb	glob_data + 0(%rip), %ymm4, %ymm4
	vpshufb	glob_data + 96(%rip), %ymm3, %ymm3
	vpshufb	glob_data + 192(%rip), %ymm2, %ymm0
	vpshufb	glob_data + 32(%rip), %ymm5, %ymm2
	vpshufb	glob_data + 128(%rip), %ymm6, %ymm5
	vpsrlq	$57, %ymm1, %ymm6
	vpsllq	$7, %ymm1, %ymm8
	vpor	%ymm8, %ymm6, %ymm6
	vmovdqu	1152(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm1
	vpxor	%ymm1, %ymm8, %ymm8
	vmovdqu	(%rdx), %ymm11
	vpxor	%ymm8, %ymm9, %ymm1
	vpxor	%ymm1, %ymm11, %ymm8
	vmovdqu	1184(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vmovdqu	256(%rdx), %ymm12
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm7, %ymm12, %ymm7
	vmovdqu	1216(%rsi), %ymm12
	vpermq	$225, %ymm12, %ymm1
	vpxor	%ymm1, %ymm12, %ymm12
	vmovdqu	128(%rdx), %ymm9
	vpxor	%ymm12, %ymm10, %ymm1
	vpxor	%ymm1, %ymm9, %ymm9
	vmovdqu	1248(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm10
	vpxor	%ymm10, %ymm1, %ymm1
	vmovdqu	32(%rdx), %ymm10
	vpxor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm4, %ymm10, %ymm10
	vmovdqu	1280(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vmovdqu	192(%rdx), %ymm1
	vpxor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm1, %ymm4
	vmovdqu	1312(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vmovdqu	160(%rdx), %ymm12
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm12, %ymm1
	vmovdqu	1344(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm0
	vpxor	%ymm0, %ymm3, %ymm3
	vmovdqu	64(%rdx), %ymm0
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm2, %ymm0, %ymm3
	vmovdqu	1376(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vmovdqu	224(%rdx), %ymm11
	vpxor	%ymm0, %ymm5, %ymm0
	vpxor	%ymm0, %ymm11, %ymm11
	vmovdqu	1408(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm0
	vpxor	%ymm0, %ymm5, %ymm5
	vmovdqu	96(%rdx), %ymm0
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm0, %ymm6
	vmovdqu	%ymm7, %ymm0
	vpand	%ymm9, %ymm0, %ymm0
	vpxor	%ymm0, %ymm8, %ymm0
	vmovdqu	%ymm0, %ymm5
	vpand	%ymm9, %ymm5, %ymm5
	vpxor	%ymm5, %ymm7, %ymm2
	vmovdqu	%ymm0, %ymm12
	vpor	%ymm2, %ymm12, %ymm12
	vpxor	%ymm12, %ymm9, %ymm5
	vmovdqu	%ymm4, %ymm8
	vpand	%ymm1, %ymm8, %ymm8
	vpxor	%ymm8, %ymm10, %ymm9
	vmovdqu	%ymm9, %ymm7
	vpand	%ymm1, %ymm7, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vmovdqu	%ymm9, %ymm7
	vpor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm7, %ymm1, %ymm1
	vmovdqu	%ymm11, %ymm7
	vpand	%ymm6, %ymm7, %ymm7
	vpxor	%ymm7, %ymm3, %ymm10
	vmovdqu	%ymm10, %ymm3
	vpand	%ymm6, %ymm3, %ymm3
	vpxor	%ymm3, %ymm11, %ymm3
	vmovdqu	%ymm10, %ymm8
	vpor	%ymm3, %ymm8, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm9, %ymm7, %ymm7
	vpxor	%ymm10, %ymm7, %ymm8
	vmovdqu	%ymm2, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vmovdqu	%ymm5, %ymm11
	vpxor	%ymm1, %ymm11, %ymm11
	vpxor	%ymm6, %ymm11, %ymm12
	vpxor	%ymm12, %ymm8, %ymm11
	vpxor	%ymm12, %ymm0, %ymm0
	vpxor	%ymm12, %ymm9, %ymm8
	vpxor	%ymm12, %ymm10, %ymm9
	vpxor	%ymm11, %ymm2, %ymm10
	vpxor	%ymm11, %ymm4, %ymm4
	vpxor	%ymm11, %ymm3, %ymm2
	vpxor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm7, %ymm6, %ymm11
	vpsrlq	$61, %ymm10, %ymm3
	vpsllq	$3, %ymm10, %ymm7
	vpor	%ymm7, %ymm3, %ymm12
	vpsrlq	$58, %ymm5, %ymm3
	vpsllq	$6, %ymm5, %ymm5
	vpor	%ymm5, %ymm3, %ymm3
	vpsrlq	$55, %ymm8, %ymm5
	vpsllq	$9, %ymm8, %ymm7
	vpor	%ymm7, %ymm5, %ymm5
	vpsrlq	$52, %ymm4, %ymm6
	vpsllq	$12, %ymm4, %ymm4
	vpor	%ymm4, %ymm6, %ymm6
	vpsrlq	$49, %ymm1, %ymm4
	vpsllq	$15, %ymm1, %ymm7
	vpor	%ymm7, %ymm4, %ymm7
	vpsrlq	$46, %ymm9, %ymm1
	vpsllq	$18, %ymm9, %ymm4
	vpor	%ymm4, %ymm1, %ymm8
	vpsrlq	$43, %ymm2, %ymm1
	vpsllq	$21, %ymm2, %ymm4
	vpor	%ymm4, %ymm1, %ymm9
	vpshufb	glob_data + 64(%rip), %ymm11, %ymm10
	vmovdqu	1440(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vmovdqu	(%rdx), %ymm2
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm2, %ymm11
	vmovdqu	1472(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vmovdqu	192(%rdx), %ymm1
	vpxor	%ymm0, %ymm12, %ymm0
	vpxor	%ymm0, %ymm1, %ymm1
	vmovdqu	1504(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm0
	vpxor	%ymm0, %ymm2, %ymm2
	vmovdqu	96(%rdx), %ymm0
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm3, %ymm0, %ymm0
	vmovdqu	1536(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm2
	vpxor	%ymm2, %ymm3, %ymm3
	vmovdqu	128(%rdx), %ymm4
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vmovdqu	1568(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm3
	vpxor	%ymm3, %ymm2, %ymm2
	vmovdqu	32(%rdx), %ymm3
	vpxor	%ymm2, %ymm6, %ymm5
	vpxor	%ymm5, %ymm3, %ymm2
	vmovdqu	1600(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vmovdqu	224(%rdx), %ymm5
	vpxor	%ymm3, %ymm7, %ymm6
	vpxor	%ymm6, %ymm5, %ymm3
	vmovdqu	1632(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vmovdqu	256(%rdx), %ymm5
	vpxor	%ymm7, %ymm8, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vmovdqu	1664(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vmovdqu	160(%rdx), %ymm7
	vpxor	%ymm6, %ymm9, %ymm6
	vpxor	%ymm6, %ymm7, %ymm6
	vmovdqu	1696(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vmovdqu	64(%rdx), %ymm8
	vpxor	%ymm7, %ymm10, %ymm7
	vpxor	%ymm7, %ymm8, %ymm7
	vmovdqu	%ymm1, %ymm8
	vpand	%ymm0, %ymm8, %ymm8
	vpxor	%ymm8, %ymm11, %ymm8
	vmovdqu	%ymm8, %ymm9
	vpand	%ymm0, %ymm9, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vmovdqu	%ymm8, %ymm12
	vpor	%ymm1, %ymm12, %ymm12
	vpxor	%ymm12, %ymm0, %ymm0
	vmovdqu	%ymm2, %ymm9
	vpand	%ymm3, %ymm9, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vmovdqu	%ymm4, %ymm9
	vpand	%ymm3, %ymm9, %ymm9
	vpxor	%ymm9, %ymm2, %ymm2
	vmovdqu	%ymm4, %ymm11
	vpor	%ymm2, %ymm11, %ymm11
	vpxor	%ymm11, %ymm3, %ymm3
	vmovdqu	%ymm6, %ymm9
	vpand	%ymm7, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm5
	vmovdqu	%ymm5, %ymm12
	vpand	%ymm7, %ymm12, %ymm12
	vpxor	%ymm12, %ymm6, %ymm9
	vmovdqu	%ymm5, %ymm10
	vpor	%ymm9, %ymm10, %ymm10
	vpxor	%ymm10, %ymm7, %ymm7
	vmovdqu	%ymm8, %ymm10
	vpxor	%ymm4, %ymm10, %ymm10
	vpxor	%ymm5, %ymm10, %ymm10
	vmovdqu	%ymm1, %ymm6
	vpxor	%ymm2, %ymm6, %ymm6
	vpxor	%ymm9, %ymm6, %ymm11
	vmovdqu	%ymm0, %ymm6
	vpxor	%ymm3, %ymm6, %ymm6
	vpxor	%ymm7, %ymm6, %ymm12
	vpxor	%ymm12, %ymm10, %ymm10
	vpxor	%ymm12, %ymm8, %ymm6
	vpxor	%ymm12, %ymm4, %ymm4
	vpxor	%ymm12, %ymm5, %ymm5
	vpxor	%ymm10, %ymm1, %ymm12
	vpxor	%ymm10, %ymm2, %ymm1
	vpxor	%ymm10, %ymm9, %ymm8
	vpxor	%ymm11, %ymm0, %ymm0
	vpxor	%ymm11, %ymm3, %ymm3
	vpxor	%ymm11, %ymm7, %ymm2
	vpshufb	glob_data + 64(%rip), %ymm12, %ymm12
	vpshufb	glob_data + 160(%rip), %ymm0, %ymm9
	vpshufb	glob_data + 0(%rip), %ymm4, %ymm4
	vpshufb	glob_data + 96(%rip), %ymm1, %ymm11
	vpshufb	glob_data + 192(%rip), %ymm3, %ymm0
	vpshufb	glob_data + 32(%rip), %ymm5, %ymm1
	vpshufb	glob_data + 128(%rip), %ymm8, %ymm10
	vpsrlq	$57, %ymm2, %ymm3
	vpsllq	$7, %ymm2, %ymm5
	vpor	%ymm5, %ymm3, %ymm3
	vmovdqu	1728(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm5
	vpxor	%ymm5, %ymm2, %ymm2
	vmovdqu	(%rdx), %ymm5
	vpxor	%ymm2, %ymm6, %ymm2
	vpxor	%ymm2, %ymm5, %ymm7
	vmovdqu	1760(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vmovdqu	32(%rdx), %ymm6
	vpxor	%ymm5, %ymm12, %ymm2
	vpxor	%ymm2, %ymm6, %ymm6
	vmovdqu	1792(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm8
	vpxor	%ymm8, %ymm2, %ymm2
	vmovdqu	64(%rdx), %ymm5
	vpxor	%ymm2, %ymm9, %ymm2
	vpxor	%ymm2, %ymm5, %ymm8
	vmovdqu	1824(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm2
	vpxor	%ymm2, %ymm5, %ymm5
	vmovdqu	96(%rdx), %ymm2
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm4, %ymm2, %ymm9
	vmovdqu	1856(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	128(%rdx), %ymm12
	vpxor	%ymm2, %ymm11, %ymm2
	vpxor	%ymm2, %ymm12, %ymm2
	vmovdqu	1888(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vmovdqu	160(%rdx), %ymm5
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm0, %ymm5, %ymm4
	vmovdqu	1920(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vmovdqu	192(%rdx), %ymm5
	vpxor	%ymm0, %ymm1, %ymm0
	vpxor	%ymm0, %ymm5, %ymm5
	vmovdqu	1952(%rsi), %ymm11
	vpermq	$225, %ymm11, %ymm0
	vpxor	%ymm0, %ymm11, %ymm11
	vmovdqu	224(%rdx), %ymm0
	vpxor	%ymm11, %ymm10, %ymm10
	vpxor	%ymm10, %ymm0, %ymm10
	vmovdqu	1984(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vmovdqu	256(%rdx), %ymm1
	vpxor	%ymm0, %ymm3, %ymm0
	vpxor	%ymm0, %ymm1, %ymm11
	vmovdqu	%ymm6, %ymm12
	vpand	%ymm8, %ymm12, %ymm12
	vpxor	%ymm12, %ymm7, %ymm1
	vmovdqu	%ymm1, %ymm0
	vpand	%ymm8, %ymm0, %ymm0
	vpxor	%ymm0, %ymm6, %ymm3
	vmovdqu	%ymm1, %ymm0
	vpor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm0, %ymm8, %ymm0
	vmovdqu	%ymm2, %ymm6
	vpand	%ymm4, %ymm6, %ymm6
	vpxor	%ymm6, %ymm9, %ymm6
	vmovdqu	%ymm6, %ymm8
	vpand	%ymm4, %ymm8, %ymm8
	vpxor	%ymm8, %ymm2, %ymm2
	vmovdqu	%ymm6, %ymm7
	vpor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vmovdqu	%ymm10, %ymm7
	vpand	%ymm11, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm9
	vmovdqu	%ymm9, %ymm7
	vpand	%ymm11, %ymm7, %ymm7
	vpxor	%ymm7, %ymm10, %ymm5
	vmovdqu	%ymm9, %ymm12
	vpor	%ymm5, %ymm12, %ymm12
	vpxor	%ymm12, %ymm11, %ymm11
	vmovdqu	%ymm1, %ymm8
	vpxor	%ymm6, %ymm8, %ymm8
	vpxor	%ymm9, %ymm8, %ymm8
	vmovdqu	%ymm3, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm5, %ymm7, %ymm7
	vmovdqu	%ymm0, %ymm10
	vpxor	%ymm4, %ymm10, %ymm10
	vpxor	%ymm11, %ymm10, %ymm12
	vpxor	%ymm12, %ymm8, %ymm10
	vpxor	%ymm12, %ymm1, %ymm1
	vpxor	%ymm12, %ymm6, %ymm6
	vpxor	%ymm12, %ymm9, %ymm8
	vpxor	%ymm10, %ymm3, %ymm9
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm10, %ymm5, %ymm5
	vpxor	%ymm7, %ymm0, %ymm10
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm7, %ymm11, %ymm11
	vpsrlq	$61, %ymm9, %ymm3
	vpsllq	$3, %ymm9, %ymm7
	vpor	%ymm7, %ymm3, %ymm12
	vpsrlq	$58, %ymm10, %ymm3
	vpsllq	$6, %ymm10, %ymm7
	vpor	%ymm7, %ymm3, %ymm0
	vpsrlq	$55, %ymm6, %ymm3
	vpsllq	$9, %ymm6, %ymm7
	vpor	%ymm7, %ymm3, %ymm6
	vpsrlq	$52, %ymm2, %ymm3
	vpsllq	$12, %ymm2, %ymm7
	vpor	%ymm7, %ymm3, %ymm3
	vpsrlq	$49, %ymm4, %ymm2
	vpsllq	$15, %ymm4, %ymm4
	vpor	%ymm4, %ymm2, %ymm7
	vpsrlq	$46, %ymm8, %ymm2
	vpsllq	$18, %ymm8, %ymm4
	vpor	%ymm4, %ymm2, %ymm8
	vpsrlq	$43, %ymm5, %ymm2
	vpsllq	$21, %ymm5, %ymm4
	vpor	%ymm4, %ymm2, %ymm9
	vpshufb	glob_data + 64(%rip), %ymm11, %ymm11
	vmovdqu	2016(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	(%rdx), %ymm4
	vpxor	%ymm2, %ymm1, %ymm1
	vpxor	%ymm1, %ymm4, %ymm10
	vmovdqu	2048(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vmovdqu	128(%rdx), %ymm2
	vpxor	%ymm1, %ymm12, %ymm1
	vpxor	%ymm1, %ymm2, %ymm4
	vmovdqu	2080(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm5
	vpxor	%ymm5, %ymm1, %ymm1
	vmovdqu	256(%rdx), %ymm2
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm2, %ymm0
	vmovdqu	2112(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vmovdqu	64(%rdx), %ymm5
	vpxor	%ymm1, %ymm6, %ymm2
	vpxor	%ymm2, %ymm5, %ymm1
	vmovdqu	2144(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vmovdqu	96(%rdx), %ymm6
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm3, %ymm6, %ymm2
	vmovdqu	2176(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vmovdqu	224(%rdx), %ymm3
	vpxor	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vmovdqu	2208(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vmovdqu	32(%rdx), %ymm5
	vpxor	%ymm7, %ymm8, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vmovdqu	2240(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm6
	vpxor	%ymm6, %ymm7, %ymm7
	vmovdqu	160(%rdx), %ymm8
	vpxor	%ymm7, %ymm9, %ymm6
	vpxor	%ymm6, %ymm8, %ymm8
	vmovdqu	2272(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm6
	vpxor	%ymm6, %ymm7, %ymm7
	vmovdqu	192(%rdx), %ymm6
	vpxor	%ymm7, %ymm11, %ymm9
	vpxor	%ymm9, %ymm6, %ymm6
	vmovdqu	%ymm4, %ymm7
	vpand	%ymm0, %ymm7, %ymm7
	vpxor	%ymm7, %ymm10, %ymm7
	vmovdqu	%ymm7, %ymm9
	vpand	%ymm0, %ymm9, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vmovdqu	%ymm7, %ymm12
	vpor	%ymm4, %ymm12, %ymm12
	vpxor	%ymm12, %ymm0, %ymm0
	vmovdqu	%ymm2, %ymm12
	vpand	%ymm3, %ymm12, %ymm12
	vpxor	%ymm12, %ymm1, %ymm1
	vmovdqu	%ymm1, %ymm9
	vpand	%ymm3, %ymm9, %ymm9
	vpxor	%ymm9, %ymm2, %ymm2
	vmovdqu	%ymm1, %ymm9
	vpor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vmovdqu	%ymm8, %ymm9
	vpand	%ymm6, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm10
	vmovdqu	%ymm10, %ymm5
	vpand	%ymm6, %ymm5, %ymm5
	vpxor	%ymm5, %ymm8, %ymm8
	vmovdqu	%ymm10, %ymm12
	vpor	%ymm8, %ymm12, %ymm12
	vpxor	%ymm12, %ymm6, %ymm9
	vmovdqu	%ymm7, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpxor	%ymm10, %ymm6, %ymm6
	vmovdqu	%ymm4, %ymm5
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm8, %ymm5, %ymm11
	vmovdqu	%ymm0, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm9, %ymm5, %ymm13
	vpxor	%ymm13, %ymm6, %ymm12
	vpxor	%ymm13, %ymm7, %ymm5
	vpxor	%ymm13, %ymm1, %ymm1
	vpxor	%ymm13, %ymm10, %ymm6
	vpxor	%ymm12, %ymm4, %ymm4
	vpxor	%ymm12, %ymm2, %ymm2
	vpxor	%ymm12, %ymm8, %ymm8
	vpxor	%ymm11, %ymm0, %ymm0
	vpxor	%ymm11, %ymm3, %ymm10
	vpxor	%ymm11, %ymm9, %ymm7
	vpshufb	glob_data + 64(%rip), %ymm4, %ymm3
	vpshufb	glob_data + 160(%rip), %ymm0, %ymm12
	vpshufb	glob_data + 0(%rip), %ymm1, %ymm11
	vpshufb	glob_data + 96(%rip), %ymm2, %ymm2
	vpshufb	glob_data + 192(%rip), %ymm10, %ymm0
	vpshufb	glob_data + 32(%rip), %ymm6, %ymm4
	vpshufb	glob_data + 128(%rip), %ymm8, %ymm1
	vpsrlq	$57, %ymm7, %ymm6
	vpsllq	$7, %ymm7, %ymm7
	vpor	%ymm7, %ymm6, %ymm7
	vmovdqu	2304(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm9
	vpxor	%ymm9, %ymm6, %ymm6
	vmovdqu	(%rdx), %ymm10
	vpxor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm5, %ymm10, %ymm5
	vmovdqu	2336(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm6
	vpxor	%ymm6, %ymm8, %ymm8
	vmovdqu	96(%rdx), %ymm6
	vpxor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm3, %ymm6, %ymm9
	vmovdqu	2368(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm10
	vpxor	%ymm10, %ymm6, %ymm6
	vmovdqu	192(%rdx), %ymm8
	vpxor	%ymm6, %ymm12, %ymm3
	vpxor	%ymm3, %ymm8, %ymm6
	vmovdqu	2400(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vmovdqu	256(%rdx), %ymm10
	vpxor	%ymm3, %ymm11, %ymm8
	vpxor	%ymm8, %ymm10, %ymm10
	vmovdqu	2432(%rsi), %ymm12
	vpermq	$225, %ymm12, %ymm3
	vpxor	%ymm3, %ymm12, %ymm12
	vmovdqu	64(%rdx), %ymm3
	vpxor	%ymm12, %ymm2, %ymm2
	vpxor	%ymm2, %ymm3, %ymm3
	vmovdqu	2464(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm11
	vpxor	%ymm11, %ymm8, %ymm8
	vmovdqu	160(%rdx), %ymm2
	vpxor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm0, %ymm2, %ymm2
	vmovdqu	2496(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm8
	vpxor	%ymm8, %ymm0, %ymm0
	vmovdqu	128(%rdx), %ymm8
	vpxor	%ymm0, %ymm4, %ymm4
	vpxor	%ymm4, %ymm8, %ymm0
	vmovdqu	2528(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm11
	vpxor	%ymm11, %ymm4, %ymm4
	vmovdqu	224(%rdx), %ymm8
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm1, %ymm8, %ymm8
	vmovdqu	2560(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm4
	vpxor	%ymm4, %ymm1, %ymm1
	vmovdqu	32(%rdx), %ymm11
	vpxor	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm11, %ymm7
	vmovdqu	%ymm9, %ymm4
	vpand	%ymm6, %ymm4, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vmovdqu	%ymm5, %ymm1
	vpand	%ymm6, %ymm1, %ymm1
	vpxor	%ymm1, %ymm9, %ymm1
	vmovdqu	%ymm5, %ymm4
	vpor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm4, %ymm6, %ymm4
	vmovdqu	%ymm3, %ymm6
	vpand	%ymm2, %ymm6, %ymm6
	vpxor	%ymm6, %ymm10, %ymm6
	vmovdqu	%ymm6, %ymm9
	vpand	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vmovdqu	%ymm6, %ymm9
	vpor	%ymm3, %ymm9, %ymm9
	vpxor	%ymm9, %ymm2, %ymm2
	vmovdqu	%ymm8, %ymm11
	vpand	%ymm7, %ymm11, %ymm11
	vpxor	%ymm11, %ymm0, %ymm11
	vmovdqu	%ymm11, %ymm9
	vpand	%ymm7, %ymm9, %ymm9
	vpxor	%ymm9, %ymm8, %ymm8
	vmovdqu	%ymm11, %ymm0
	vpor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm0, %ymm7, %ymm7
	vmovdqu	%ymm5, %ymm0
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm11, %ymm0, %ymm0
	vmovdqu	%ymm1, %ymm9
	vpxor	%ymm3, %ymm9, %ymm9
	vpxor	%ymm8, %ymm9, %ymm9
	vmovdqu	%ymm4, %ymm10
	vpxor	%ymm2, %ymm10, %ymm10
	vpxor	%ymm7, %ymm10, %ymm12
	vpxor	%ymm12, %ymm0, %ymm10
	vpxor	%ymm12, %ymm5, %ymm0
	vpxor	%ymm12, %ymm6, %ymm5
	vpxor	%ymm12, %ymm11, %ymm6
	vpxor	%ymm10, %ymm1, %ymm11
	vpxor	%ymm10, %ymm3, %ymm1
	vpxor	%ymm10, %ymm8, %ymm8
	vpxor	%ymm9, %ymm4, %ymm3
	vpxor	%ymm9, %ymm2, %ymm2
	vpxor	%ymm9, %ymm7, %ymm10
	vpsrlq	$61, %ymm11, %ymm4
	vpsllq	$3, %ymm11, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpsrlq	$58, %ymm3, %ymm7
	vpsllq	$6, %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm7
	vpsrlq	$55, %ymm5, %ymm3
	vpsllq	$9, %ymm5, %ymm5
	vpor	%ymm5, %ymm3, %ymm3
	vpsrlq	$52, %ymm1, %ymm5
	vpsllq	$12, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm1
	vpsrlq	$49, %ymm2, %ymm5
	vpsllq	$15, %ymm2, %ymm2
	vpor	%ymm2, %ymm5, %ymm9
	vpsrlq	$46, %ymm6, %ymm2
	vpsllq	$18, %ymm6, %ymm5
	vpor	%ymm5, %ymm2, %ymm6
	vpsrlq	$43, %ymm8, %ymm2
	vpsllq	$21, %ymm8, %ymm5
	vpor	%ymm5, %ymm2, %ymm8
	vpshufb	glob_data + 64(%rip), %ymm10, %ymm10
	vmovdqu	2592(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm2
	vpxor	%ymm2, %ymm5, %ymm5
	vmovdqu	(%rdx), %ymm11
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm11
	vmovdqu	2624(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vmovdqu	64(%rdx), %ymm2
	vpxor	%ymm0, %ymm4, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	2656(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm0
	vpxor	%ymm0, %ymm4, %ymm4
	vmovdqu	32(%rdx), %ymm0
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vmovdqu	2688(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vmovdqu	192(%rdx), %ymm5
	vpxor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm5, %ymm5
	vmovdqu	2720(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vmovdqu	256(%rdx), %ymm4
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vmovdqu	2752(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vmovdqu	224(%rdx), %ymm1
	vpxor	%ymm3, %ymm9, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vmovdqu	2784(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vmovdqu	96(%rdx), %ymm12
	vpxor	%ymm3, %ymm6, %ymm3
	vpxor	%ymm3, %ymm12, %ymm3
	vmovdqu	2816(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm9
	vpxor	%ymm9, %ymm6, %ymm6
	vmovdqu	160(%rdx), %ymm7
	vpxor	%ymm6, %ymm8, %ymm6
	vpxor	%ymm6, %ymm7, %ymm7
	vmovdqu	2848(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm9
	vpxor	%ymm9, %ymm6, %ymm6
	vmovdqu	128(%rdx), %ymm8
	vpxor	%ymm6, %ymm10, %ymm6
	vpxor	%ymm6, %ymm8, %ymm8
	vmovdqu	%ymm2, %ymm6
	vpand	%ymm0, %ymm6, %ymm6
	vpxor	%ymm6, %ymm11, %ymm6
	vmovdqu	%ymm6, %ymm9
	vpand	%ymm0, %ymm9, %ymm9
	vpxor	%ymm9, %ymm2, %ymm2
	vmovdqu	%ymm6, %ymm9
	vpor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm0, %ymm0
	vmovdqu	%ymm4, %ymm12
	vpand	%ymm1, %ymm12, %ymm12
	vpxor	%ymm12, %ymm5, %ymm5
	vmovdqu	%ymm5, %ymm9
	vpand	%ymm1, %ymm9, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vmovdqu	%ymm5, %ymm9
	vpor	%ymm4, %ymm9, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vmovdqu	%ymm7, %ymm9
	vpand	%ymm8, %ymm9, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vmovdqu	%ymm3, %ymm9
	vpand	%ymm8, %ymm9, %ymm9
	vpxor	%ymm9, %ymm7, %ymm7
	vmovdqu	%ymm3, %ymm12
	vpor	%ymm7, %ymm12, %ymm12
	vpxor	%ymm12, %ymm8, %ymm8
	vmovdqu	%ymm6, %ymm9
	vpxor	%ymm5, %ymm9, %ymm9
	vpxor	%ymm3, %ymm9, %ymm10
	vmovdqu	%ymm2, %ymm9
	vpxor	%ymm4, %ymm9, %ymm9
	vpxor	%ymm7, %ymm9, %ymm9
	vmovdqu	%ymm0, %ymm11
	vpxor	%ymm1, %ymm11, %ymm11
	vpxor	%ymm8, %ymm11, %ymm11
	vpxor	%ymm11, %ymm10, %ymm10
	vpxor	%ymm11, %ymm6, %ymm6
	vpxor	%ymm11, %ymm5, %ymm5
	vpxor	%ymm11, %ymm3, %ymm3
	vpxor	%ymm10, %ymm2, %ymm12
	vpxor	%ymm10, %ymm4, %ymm2
	vpxor	%ymm10, %ymm7, %ymm7
	vpxor	%ymm9, %ymm0, %ymm10
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm9, %ymm8, %ymm8
	vpshufb	glob_data + 64(%rip), %ymm12, %ymm0
	vpshufb	glob_data + 160(%rip), %ymm10, %ymm12
	vpshufb	glob_data + 0(%rip), %ymm5, %ymm9
	vpshufb	glob_data + 96(%rip), %ymm2, %ymm10
	vpshufb	glob_data + 192(%rip), %ymm1, %ymm4
	vpshufb	glob_data + 32(%rip), %ymm3, %ymm1
	vpshufb	glob_data + 128(%rip), %ymm7, %ymm2
	vpsrlq	$57, %ymm8, %ymm3
	vpsllq	$7, %ymm8, %ymm5
	vpor	%ymm5, %ymm3, %ymm5
	vmovdqu	2880(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vmovdqu	(%rdx), %ymm8
	vpxor	%ymm3, %ymm6, %ymm6
	vpxor	%ymm6, %ymm8, %ymm6
	vmovdqu	2912(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm3
	vpxor	%ymm3, %ymm7, %ymm7
	vmovdqu	256(%rdx), %ymm3
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm0, %ymm3, %ymm7
	vmovdqu	2944(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm0
	vpxor	%ymm0, %ymm3, %ymm3
	vmovdqu	128(%rdx), %ymm0
	vpxor	%ymm3, %ymm12, %ymm3
	vpxor	%ymm3, %ymm0, %ymm8
	vmovdqu	2976(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm3
	vpxor	%ymm3, %ymm0, %ymm0
	vmovdqu	32(%rdx), %ymm11
	vpxor	%ymm0, %ymm9, %ymm9
	vpxor	%ymm9, %ymm11, %ymm9
	vmovdqu	3008(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm12
	vpxor	%ymm12, %ymm3, %ymm3
	vmovdqu	192(%rdx), %ymm0
	vpxor	%ymm3, %ymm10, %ymm10
	vpxor	%ymm10, %ymm0, %ymm0
	vmovdqu	3040(%rsi), %ymm10
	vpermq	$225, %ymm10, %ymm11
	vpxor	%ymm11, %ymm10, %ymm10
	vmovdqu	160(%rdx), %ymm3
	vpxor	%ymm10, %ymm4, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vmovdqu	3072(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm10
	vpxor	%ymm10, %ymm4, %ymm4
	vmovdqu	64(%rdx), %ymm11
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm1, %ymm11, %ymm4
	vmovdqu	3104(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm10
	vpxor	%ymm10, %ymm1, %ymm1
	vmovdqu	224(%rdx), %ymm10
	vpxor	%ymm1, %ymm2, %ymm1
	vpxor	%ymm1, %ymm10, %ymm10
	vmovdqu	3136(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vmovdqu	96(%rdx), %ymm2
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm5, %ymm2, %ymm11
	vmovdqu	%ymm7, %ymm1
	vpand	%ymm8, %ymm1, %ymm1
	vpxor	%ymm1, %ymm6, %ymm1
	vmovdqu	%ymm1, %ymm2
	vpand	%ymm8, %ymm2, %ymm2
	vpxor	%ymm2, %ymm7, %ymm2
	vmovdqu	%ymm1, %ymm7
	vpor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm7, %ymm8, %ymm5
	vmovdqu	%ymm0, %ymm7
	vpand	%ymm3, %ymm7, %ymm7
	vpxor	%ymm7, %ymm9, %ymm6
	vmovdqu	%ymm6, %ymm7
	vpand	%ymm3, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm9
	vmovdqu	%ymm6, %ymm0
	vpor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm0, %ymm3, %ymm3
	vmovdqu	%ymm10, %ymm0
	vpand	%ymm11, %ymm0, %ymm0
	vpxor	%ymm0, %ymm4, %ymm12
	vmovdqu	%ymm12, %ymm7
	vpand	%ymm11, %ymm7, %ymm7
	vpxor	%ymm7, %ymm10, %ymm7
	vmovdqu	%ymm12, %ymm4
	vpor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm4, %ymm11, %ymm4
	vmovdqu	%ymm1, %ymm0
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm12, %ymm0, %ymm0
	vmovdqu	%ymm2, %ymm8
	vpxor	%ymm9, %ymm8, %ymm8
	vpxor	%ymm7, %ymm8, %ymm8
	vmovdqu	%ymm5, %ymm10
	vpxor	%ymm3, %ymm10, %ymm10
	vpxor	%ymm4, %ymm10, %ymm11
	vpxor	%ymm11, %ymm0, %ymm10
	vpxor	%ymm11, %ymm1, %ymm0
	vpxor	%ymm11, %ymm6, %ymm1
	vpxor	%ymm11, %ymm12, %ymm6
	vpxor	%ymm10, %ymm2, %ymm11
	vpxor	%ymm10, %ymm9, %ymm2
	vpxor	%ymm10, %ymm7, %ymm7
	vpxor	%ymm8, %ymm5, %ymm5
	vpxor	%ymm8, %ymm3, %ymm9
	vpxor	%ymm8, %ymm4, %ymm3
	vpsrlq	$61, %ymm11, %ymm4
	vpsllq	$3, %ymm11, %ymm8
	vpor	%ymm8, %ymm4, %ymm12
	vpsrlq	$58, %ymm5, %ymm4
	vpsllq	$6, %ymm5, %ymm5
	vpor	%ymm5, %ymm4, %ymm4
	vpsrlq	$55, %ymm1, %ymm5
	vpsllq	$9, %ymm1, %ymm1
	vpor	%ymm1, %ymm5, %ymm5
	vpsrlq	$52, %ymm2, %ymm1
	vpsllq	$12, %ymm2, %ymm2
	vpor	%ymm2, %ymm1, %ymm10
	vpsrlq	$49, %ymm9, %ymm1
	vpsllq	$15, %ymm9, %ymm2
	vpor	%ymm2, %ymm1, %ymm8
	vpsrlq	$46, %ymm6, %ymm1
	vpsllq	$18, %ymm6, %ymm2
	vpor	%ymm2, %ymm1, %ymm6
	vpsrlq	$43, %ymm7, %ymm1
	vpsllq	$21, %ymm7, %ymm2
	vpor	%ymm2, %ymm1, %ymm9
	vpshufb	glob_data + 64(%rip), %ymm3, %ymm7
	vmovdqu	3168(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vmovdqu	(%rdx), %ymm11
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm11
	vmovdqu	3200(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm0
	vpxor	%ymm0, %ymm2, %ymm2
	vmovdqu	192(%rdx), %ymm3
	vpxor	%ymm2, %ymm12, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vmovdqu	3232(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vmovdqu	96(%rdx), %ymm2
	vpxor	%ymm0, %ymm4, %ymm1
	vpxor	%ymm1, %ymm2, %ymm0
	vmovdqu	3264(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm1
	vpxor	%ymm1, %ymm2, %ymm2
	vmovdqu	128(%rdx), %ymm1
	vpxor	%ymm2, %ymm5, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vmovdqu	3296(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vmovdqu	32(%rdx), %ymm12
	vpxor	%ymm2, %ymm10, %ymm2
	vpxor	%ymm2, %ymm12, %ymm2
	vmovdqu	3328(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vmovdqu	224(%rdx), %ymm5
	vpxor	%ymm4, %ymm8, %ymm8
	vpxor	%ymm8, %ymm5, %ymm4
	vmovdqu	3360(%rsi), %ymm10
	vpermq	$225, %ymm10, %ymm5
	vpxor	%ymm5, %ymm10, %ymm10
	vmovdqu	256(%rdx), %ymm5
	vpxor	%ymm10, %ymm6, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vmovdqu	3392(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vmovdqu	160(%rdx), %ymm10
	vpxor	%ymm6, %ymm9, %ymm8
	vpxor	%ymm8, %ymm10, %ymm6
	vmovdqu	3424(%rsi), %ymm9
	vpermq	$225, %ymm9, %ymm10
	vpxor	%ymm10, %ymm9, %ymm9
	vmovdqu	64(%rdx), %ymm8
	vpxor	%ymm9, %ymm7, %ymm7
	vpxor	%ymm7, %ymm8, %ymm7
	vmovdqu	%ymm3, %ymm9
	vpand	%ymm0, %ymm9, %ymm9
	vpxor	%ymm9, %ymm11, %ymm8
	vmovdqu	%ymm8, %ymm9
	vpand	%ymm0, %ymm9, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vmovdqu	%ymm8, %ymm10
	vpor	%ymm3, %ymm10, %ymm10
	vpxor	%ymm10, %ymm0, %ymm0
	vmovdqu	%ymm2, %ymm9
	vpand	%ymm4, %ymm9, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vmovdqu	%ymm1, %ymm9
	vpand	%ymm4, %ymm9, %ymm9
	vpxor	%ymm9, %ymm2, %ymm2
	vmovdqu	%ymm1, %ymm9
	vpor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vmovdqu	%ymm6, %ymm9
	vpand	%ymm7, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm9
	vmovdqu	%ymm9, %ymm10
	vpand	%ymm7, %ymm10, %ymm10
	vpxor	%ymm10, %ymm6, %ymm6
	vmovdqu	%ymm9, %ymm10
	vpor	%ymm6, %ymm10, %ymm10
	vpxor	%ymm10, %ymm7, %ymm10
	vmovdqu	%ymm8, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm9, %ymm5, %ymm5
	vmovdqu	%ymm3, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm6, %ymm7, %ymm11
	vmovdqu	%ymm0, %ymm12
	vpxor	%ymm4, %ymm12, %ymm12
	vpxor	%ymm10, %ymm12, %ymm7
	vpxor	%ymm7, %ymm5, %ymm12
	vpxor	%ymm7, %ymm8, %ymm5
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm7, %ymm9, %ymm7
	vpxor	%ymm12, %ymm3, %ymm3
	vpxor	%ymm12, %ymm2, %ymm2
	vpxor	%ymm12, %ymm6, %ymm6
	vpxor	%ymm11, %ymm0, %ymm8
	vpxor	%ymm11, %ymm4, %ymm12
	vpxor	%ymm11, %ymm10, %ymm4
	vpshufb	glob_data + 64(%rip), %ymm3, %ymm0
	vpshufb	glob_data + 160(%rip), %ymm8, %ymm9
	vpshufb	glob_data + 0(%rip), %ymm1, %ymm10
	vpshufb	glob_data + 96(%rip), %ymm2, %ymm1
	vpshufb	glob_data + 192(%rip), %ymm12, %ymm2
	vpshufb	glob_data + 32(%rip), %ymm7, %ymm3
	vpshufb	glob_data + 128(%rip), %ymm6, %ymm6
	vpsrlq	$57, %ymm4, %ymm7
	vpsllq	$7, %ymm4, %ymm4
	vpor	%ymm4, %ymm7, %ymm11
	vmovdqu	3456(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm4
	vpxor	%ymm4, %ymm7, %ymm7
	vmovdqu	(%rdx), %ymm12
	vpxor	%ymm7, %ymm5, %ymm4
	vpxor	%ymm4, %ymm12, %ymm5
	vmovdqu	3488(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vmovdqu	32(%rdx), %ymm7
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm0, %ymm7, %ymm8
	vmovdqu	3520(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm4
	vpxor	%ymm4, %ymm7, %ymm7
	vmovdqu	64(%rdx), %ymm0
	vpxor	%ymm7, %ymm9, %ymm4
	vpxor	%ymm4, %ymm0, %ymm7
	vmovdqu	3552(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm12
	vpxor	%ymm12, %ymm0, %ymm0
	vmovdqu	96(%rdx), %ymm4
	vpxor	%ymm0, %ymm10, %ymm0
	vpxor	%ymm0, %ymm4, %ymm9
	vmovdqu	3584(%rsi), %ymm12
	vpermq	$225, %ymm12, %ymm0
	vpxor	%ymm0, %ymm12, %ymm12
	vmovdqu	128(%rdx), %ymm0
	vpxor	%ymm12, %ymm1, %ymm1
	vpxor	%ymm1, %ymm0, %ymm1
	vmovdqu	3616(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm4
	vpxor	%ymm4, %ymm0, %ymm0
	vmovdqu	160(%rdx), %ymm4
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm2, %ymm4, %ymm0
	vmovdqu	3648(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm12
	vpxor	%ymm12, %ymm2, %ymm2
	vmovdqu	192(%rdx), %ymm4
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm3, %ymm4, %ymm4
	vmovdqu	3680(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm10
	vpxor	%ymm10, %ymm2, %ymm2
	vmovdqu	224(%rdx), %ymm12
	vpxor	%ymm2, %ymm6, %ymm2
	vpxor	%ymm2, %ymm12, %ymm6
	vmovdqu	3712(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm3
	vpxor	%ymm3, %ymm2, %ymm2
	vmovdqu	256(%rdx), %ymm10
	vpxor	%ymm2, %ymm11, %ymm2
	vpxor	%ymm2, %ymm10, %ymm10
	vmovdqu	%ymm8, %ymm2
	vpand	%ymm7, %ymm2, %ymm2
	vpxor	%ymm2, %ymm5, %ymm2
	vmovdqu	%ymm2, %ymm3
	vpand	%ymm7, %ymm3, %ymm3
	vpxor	%ymm3, %ymm8, %ymm3
	vmovdqu	%ymm2, %ymm5
	vpor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm5, %ymm7, %ymm5
	vmovdqu	%ymm1, %ymm7
	vpand	%ymm0, %ymm7, %ymm7
	vpxor	%ymm7, %ymm9, %ymm7
	vmovdqu	%ymm7, %ymm8
	vpand	%ymm0, %ymm8, %ymm8
	vpxor	%ymm8, %ymm1, %ymm1
	vmovdqu	%ymm7, %ymm11
	vpor	%ymm1, %ymm11, %ymm11
	vpxor	%ymm11, %ymm0, %ymm0
	vmovdqu	%ymm6, %ymm8
	vpand	%ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm4, %ymm8
	vmovdqu	%ymm8, %ymm4
	vpand	%ymm10, %ymm4, %ymm4
	vpxor	%ymm4, %ymm6, %ymm6
	vmovdqu	%ymm8, %ymm12
	vpor	%ymm6, %ymm12, %ymm12
	vpxor	%ymm12, %ymm10, %ymm9
	vmovdqu	%ymm2, %ymm10
	vpxor	%ymm7, %ymm10, %ymm10
	vpxor	%ymm8, %ymm10, %ymm10
	vmovdqu	%ymm3, %ymm4
	vpxor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm6, %ymm4, %ymm4
	vmovdqu	%ymm5, %ymm11
	vpxor	%ymm0, %ymm11, %ymm11
	vpxor	%ymm9, %ymm11, %ymm12
	vpxor	%ymm12, %ymm10, %ymm11
	vpxor	%ymm12, %ymm2, %ymm2
	vpxor	%ymm12, %ymm7, %ymm7
	vpxor	%ymm12, %ymm8, %ymm8
	vpxor	%ymm11, %ymm3, %ymm10
	vpxor	%ymm11, %ymm1, %ymm1
	vpxor	%ymm11, %ymm6, %ymm6
	vpxor	%ymm4, %ymm5, %ymm3
	vpxor	%ymm4, %ymm0, %ymm5
	vpxor	%ymm4, %ymm9, %ymm9
	vpsrlq	$61, %ymm10, %ymm4
	vpsllq	$3, %ymm10, %ymm0
	vpor	%ymm0, %ymm4, %ymm12
	vpsrlq	$58, %ymm3, %ymm4
	vpsllq	$6, %ymm3, %ymm0
	vpor	%ymm0, %ymm4, %ymm3
	vpsrlq	$55, %ymm7, %ymm4
	vpsllq	$9, %ymm7, %ymm0
	vpor	%ymm0, %ymm4, %ymm4
	vpsrlq	$52, %ymm1, %ymm7
	vpsllq	$12, %ymm1, %ymm0
	vpor	%ymm0, %ymm7, %ymm1
	vpsrlq	$49, %ymm5, %ymm7
	vpsllq	$15, %ymm5, %ymm0
	vpor	%ymm0, %ymm7, %ymm10
	vpsrlq	$46, %ymm8, %ymm5
	vpsllq	$18, %ymm8, %ymm0
	vpor	%ymm0, %ymm5, %ymm8
	vpsrlq	$43, %ymm6, %ymm5
	vpsllq	$21, %ymm6, %ymm0
	vpor	%ymm0, %ymm5, %ymm7
	vpshufb	glob_data + 64(%rip), %ymm9, %ymm6
	vmovdqu	3744(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm9
	vpxor	%ymm9, %ymm0, %ymm0
	vmovdqu	(%rdx), %ymm5
	vpxor	%ymm0, %ymm2, %ymm0
	vpxor	%ymm0, %ymm5, %ymm9
	vmovdqu	3776(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vmovdqu	128(%rdx), %ymm2
	vpxor	%ymm0, %ymm12, %ymm5
	vpxor	%ymm5, %ymm2, %ymm0
	vmovdqu	3808(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm5
	vpxor	%ymm5, %ymm2, %ymm2
	vmovdqu	256(%rdx), %ymm5
	vpxor	%ymm2, %ymm3, %ymm2
	vpxor	%ymm2, %ymm5, %ymm5
	vmovdqu	3840(%rsi), %ymm11
	vpermq	$225, %ymm11, %ymm3
	vpxor	%ymm3, %ymm11, %ymm11
	vmovdqu	64(%rdx), %ymm2
	vpxor	%ymm11, %ymm4, %ymm3
	vpxor	%ymm3, %ymm2, %ymm2
	vmovdqu	3872(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm12
	vpxor	%ymm12, %ymm3, %ymm3
	vmovdqu	96(%rdx), %ymm4
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm1, %ymm4, %ymm3
	vmovdqu	3904(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm4
	vpxor	%ymm4, %ymm1, %ymm1
	vmovdqu	224(%rdx), %ymm12
	vpxor	%ymm1, %ymm10, %ymm4
	vpxor	%ymm4, %ymm12, %ymm1
	vmovdqu	3936(%rsi), %ymm10
	vpermq	$225, %ymm10, %ymm11
	vpxor	%ymm11, %ymm10, %ymm10
	vmovdqu	32(%rdx), %ymm4
	vpxor	%ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm4, %ymm4
	vmovdqu	3968(%rsi), %ymm8
	vpermq	$225, %ymm8, %ymm10
	vpxor	%ymm10, %ymm8, %ymm8
	vmovdqu	160(%rdx), %ymm10
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm7, %ymm10, %ymm11
	vmovdqu	4000(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vmovdqu	192(%rdx), %ymm10
	vpxor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm10, %ymm6
	vmovdqu	%ymm0, %ymm7
	vpand	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm9, %ymm8
	vmovdqu	%ymm8, %ymm7
	vpand	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vmovdqu	%ymm8, %ymm7
	vpor	%ymm0, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vmovdqu	%ymm3, %ymm7
	vpand	%ymm1, %ymm7, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vmovdqu	%ymm2, %ymm7
	vpand	%ymm1, %ymm7, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vmovdqu	%ymm2, %ymm7
	vpor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm7, %ymm1, %ymm1
	vmovdqu	%ymm11, %ymm7
	vpand	%ymm6, %ymm7, %ymm7
	vpxor	%ymm7, %ymm4, %ymm9
	vmovdqu	%ymm9, %ymm4
	vpand	%ymm6, %ymm4, %ymm4
	vpxor	%ymm4, %ymm11, %ymm11
	vmovdqu	%ymm9, %ymm7
	vpor	%ymm11, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm10
	vmovdqu	%ymm8, %ymm4
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm9, %ymm4, %ymm4
	vmovdqu	%ymm0, %ymm6
	vpxor	%ymm3, %ymm6, %ymm6
	vpxor	%ymm11, %ymm6, %ymm7
	vmovdqu	%ymm5, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpxor	%ymm10, %ymm6, %ymm6
	vpxor	%ymm6, %ymm4, %ymm12
	vpxor	%ymm6, %ymm8, %ymm4
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm6, %ymm9, %ymm6
	vpxor	%ymm12, %ymm0, %ymm0
	vpxor	%ymm12, %ymm3, %ymm3
	vpxor	%ymm12, %ymm11, %ymm11
	vpxor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm7, %ymm1, %ymm9
	vpxor	%ymm7, %ymm10, %ymm1
	vpshufb	glob_data + 64(%rip), %ymm0, %ymm8
	vpshufb	glob_data + 160(%rip), %ymm5, %ymm10
	vpshufb	glob_data + 0(%rip), %ymm2, %ymm5
	vpshufb	glob_data + 96(%rip), %ymm3, %ymm12
	vpshufb	glob_data + 192(%rip), %ymm9, %ymm0
	vpshufb	glob_data + 32(%rip), %ymm6, %ymm2
	vpshufb	glob_data + 128(%rip), %ymm11, %ymm6
	vpsrlq	$57, %ymm1, %ymm3
	vpsllq	$7, %ymm1, %ymm1
	vpor	%ymm1, %ymm3, %ymm7
	vmovdqu	4032(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vmovdqu	(%rdx), %ymm9
	vpxor	%ymm3, %ymm4, %ymm3
	vpxor	%ymm3, %ymm9, %ymm4
	vmovdqu	4064(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm11
	vpxor	%ymm11, %ymm1, %ymm1
	vmovdqu	96(%rdx), %ymm3
	vpxor	%ymm1, %ymm8, %ymm1
	vpxor	%ymm1, %ymm3, %ymm8
	vmovdqu	4096(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vmovdqu	192(%rdx), %ymm11
	vpxor	%ymm3, %ymm10, %ymm1
	vpxor	%ymm1, %ymm11, %ymm10
	vmovdqu	4128(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vmovdqu	256(%rdx), %ymm3
	vpxor	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm3, %ymm9
	vmovdqu	4160(%rsi), %ymm3
	vpermq	$225, %ymm3, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vmovdqu	64(%rdx), %ymm1
	vpxor	%ymm3, %ymm12, %ymm5
	vpxor	%ymm5, %ymm1, %ymm3
	vmovdqu	4192(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm5
	vpxor	%ymm5, %ymm1, %ymm1
	vmovdqu	160(%rdx), %ymm12
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm12, %ymm1
	vmovdqu	4224(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm11
	vpxor	%ymm11, %ymm5, %ymm5
	vmovdqu	128(%rdx), %ymm0
	vpxor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm2, %ymm0, %ymm5
	vmovdqu	4256(%rsi), %ymm0
	vpermq	$225, %ymm0, %ymm11
	vpxor	%ymm11, %ymm0, %ymm0
	vmovdqu	224(%rdx), %ymm11
	vpxor	%ymm0, %ymm6, %ymm2
	vpxor	%ymm2, %ymm11, %ymm6
	vmovdqu	4288(%rsi), %ymm12
	vpermq	$225, %ymm12, %ymm0
	vpxor	%ymm0, %ymm12, %ymm12
	vmovdqu	32(%rdx), %ymm0
	vpxor	%ymm12, %ymm7, %ymm2
	vpxor	%ymm2, %ymm0, %ymm7
	vmovdqu	%ymm8, %ymm0
	vpand	%ymm10, %ymm0, %ymm0
	vpxor	%ymm0, %ymm4, %ymm0
	vmovdqu	%ymm0, %ymm2
	vpand	%ymm10, %ymm2, %ymm2
	vpxor	%ymm2, %ymm8, %ymm2
	vmovdqu	%ymm0, %ymm4
	vpor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm4, %ymm10, %ymm4
	vmovdqu	%ymm3, %ymm8
	vpand	%ymm1, %ymm8, %ymm8
	vpxor	%ymm8, %ymm9, %ymm8
	vmovdqu	%ymm8, %ymm9
	vpand	%ymm1, %ymm9, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vmovdqu	%ymm8, %ymm10
	vpor	%ymm3, %ymm10, %ymm10
	vpxor	%ymm10, %ymm1, %ymm1
	vmovdqu	%ymm6, %ymm9
	vpand	%ymm7, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm9
	vmovdqu	%ymm9, %ymm10
	vpand	%ymm7, %ymm10, %ymm10
	vpxor	%ymm10, %ymm6, %ymm5
	vmovdqu	%ymm9, %ymm6
	vpor	%ymm5, %ymm6, %ymm6
	vpxor	%ymm6, %ymm7, %ymm6
	vmovdqu	%ymm0, %ymm7
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm9, %ymm7, %ymm7
	vmovdqu	%ymm2, %ymm10
	vpxor	%ymm3, %ymm10, %ymm10
	vpxor	%ymm5, %ymm10, %ymm11
	vmovdqu	%ymm4, %ymm10
	vpxor	%ymm1, %ymm10, %ymm10
	vpxor	%ymm6, %ymm10, %ymm12
	vpxor	%ymm12, %ymm7, %ymm10
	vpxor	%ymm12, %ymm0, %ymm0
	vpxor	%ymm12, %ymm8, %ymm7
	vpxor	%ymm12, %ymm9, %ymm8
	vpxor	%ymm10, %ymm2, %ymm9
	vpxor	%ymm10, %ymm3, %ymm2
	vpxor	%ymm10, %ymm5, %ymm5
	vpxor	%ymm11, %ymm4, %ymm3
	vpxor	%ymm11, %ymm1, %ymm1
	vpxor	%ymm11, %ymm6, %ymm12
	vpsrlq	$61, %ymm9, %ymm4
	vpsllq	$3, %ymm9, %ymm6
	vpor	%ymm6, %ymm4, %ymm4
	vpsrlq	$58, %ymm3, %ymm6
	vpsllq	$6, %ymm3, %ymm3
	vpor	%ymm3, %ymm6, %ymm3
	vpsrlq	$55, %ymm7, %ymm6
	vpsllq	$9, %ymm7, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpsrlq	$52, %ymm2, %ymm7
	vpsllq	$12, %ymm2, %ymm2
	vpor	%ymm2, %ymm7, %ymm2
	vpsrlq	$49, %ymm1, %ymm7
	vpsllq	$15, %ymm1, %ymm1
	vpor	%ymm1, %ymm7, %ymm11
	vpsrlq	$46, %ymm8, %ymm1
	vpsllq	$18, %ymm8, %ymm7
	vpor	%ymm7, %ymm1, %ymm7
	vpsrlq	$43, %ymm5, %ymm1
	vpsllq	$21, %ymm5, %ymm5
	vpor	%ymm5, %ymm1, %ymm10
	vpshufb	glob_data + 64(%rip), %ymm12, %ymm8
	vmovdqu	4320(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm12
	vpxor	%ymm12, %ymm1, %ymm1
	vmovdqu	(%rdx), %ymm5
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm5, %ymm9
	vmovdqu	4352(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm0
	vpxor	%ymm0, %ymm5, %ymm5
	vmovdqu	64(%rdx), %ymm0
	vpxor	%ymm5, %ymm4, %ymm1
	vpxor	%ymm1, %ymm0, %ymm1
	vmovdqu	4384(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm0
	vpxor	%ymm0, %ymm4, %ymm4
	vmovdqu	32(%rdx), %ymm0
	vpxor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm0, %ymm0
	vmovdqu	4416(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm3
	vpxor	%ymm3, %ymm4, %ymm4
	vmovdqu	192(%rdx), %ymm3
	vpxor	%ymm4, %ymm6, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vmovdqu	4448(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vmovdqu	256(%rdx), %ymm6
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm6, %ymm2
	vmovdqu	4480(%rsi), %ymm4
	vpermq	$225, %ymm4, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vmovdqu	224(%rdx), %ymm5
	vpxor	%ymm4, %ymm11, %ymm6
	vpxor	%ymm6, %ymm5, %ymm4
	vmovdqu	4512(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm11
	vpxor	%ymm11, %ymm5, %ymm5
	vmovdqu	96(%rdx), %ymm6
	vpxor	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm6, %ymm5
	vmovdqu	4544(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm11
	vpxor	%ymm11, %ymm6, %ymm6
	vmovdqu	160(%rdx), %ymm7
	vpxor	%ymm6, %ymm10, %ymm6
	vpxor	%ymm6, %ymm7, %ymm7
	vmovdqu	4576(%rsi), %ymm10
	vpermq	$225, %ymm10, %ymm12
	vpxor	%ymm12, %ymm10, %ymm10
	vmovdqu	128(%rdx), %ymm6
	vpxor	%ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vmovdqu	%ymm1, %ymm8
	vpand	%ymm0, %ymm8, %ymm8
	vpxor	%ymm8, %ymm9, %ymm8
	vmovdqu	%ymm8, %ymm10
	vpand	%ymm0, %ymm10, %ymm10
	vpxor	%ymm10, %ymm1, %ymm1
	vmovdqu	%ymm8, %ymm9
	vpor	%ymm1, %ymm9, %ymm9
	vpxor	%ymm9, %ymm0, %ymm0
	vmovdqu	%ymm2, %ymm9
	vpand	%ymm4, %ymm9, %ymm9
	vpxor	%ymm9, %ymm3, %ymm3
	vmovdqu	%ymm3, %ymm9
	vpand	%ymm4, %ymm9, %ymm9
	vpxor	%ymm9, %ymm2, %ymm2
	vmovdqu	%ymm3, %ymm9
	vpor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vmovdqu	%ymm7, %ymm10
	vpand	%ymm6, %ymm10, %ymm10
	vpxor	%ymm10, %ymm5, %ymm9
	vmovdqu	%ymm9, %ymm12
	vpand	%ymm6, %ymm12, %ymm12
	vpxor	%ymm12, %ymm7, %ymm7
	vmovdqu	%ymm9, %ymm5
	vpor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm5, %ymm6, %ymm11
	vmovdqu	%ymm8, %ymm5
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm9, %ymm5, %ymm5
	vmovdqu	%ymm1, %ymm6
	vpxor	%ymm2, %ymm6, %ymm6
	vpxor	%ymm7, %ymm6, %ymm12
	vmovdqu	%ymm0, %ymm6
	vpxor	%ymm4, %ymm6, %ymm6
	vpxor	%ymm11, %ymm6, %ymm6
	vpxor	%ymm6, %ymm5, %ymm10
	vpxor	%ymm6, %ymm8, %ymm5
	vpxor	%ymm6, %ymm3, %ymm3
	vpxor	%ymm6, %ymm9, %ymm6
	vpxor	%ymm10, %ymm1, %ymm8
	vpxor	%ymm10, %ymm2, %ymm1
	vpxor	%ymm10, %ymm7, %ymm2
	vpxor	%ymm12, %ymm0, %ymm0
	vpxor	%ymm12, %ymm4, %ymm4
	vpxor	%ymm12, %ymm11, %ymm7
	vpshufb	glob_data + 64(%rip), %ymm8, %ymm8
	vpshufb	glob_data + 160(%rip), %ymm0, %ymm9
	vpshufb	glob_data + 0(%rip), %ymm3, %ymm10
	vpshufb	glob_data + 96(%rip), %ymm1, %ymm11
	vpshufb	glob_data + 192(%rip), %ymm4, %ymm4
	vpshufb	glob_data + 32(%rip), %ymm6, %ymm1
	vpshufb	glob_data + 128(%rip), %ymm2, %ymm0
	vpsrlq	$57, %ymm7, %ymm2
	vpsllq	$7, %ymm7, %ymm3
	vpor	%ymm3, %ymm2, %ymm3
	vmovdqu	4608(%rsi), %ymm2
	vpermq	$225, %ymm2, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vmovdqu	(%rdx), %ymm6
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm5, %ymm6, %ymm2
	vmovdqu	4640(%rsi), %ymm5
	vpermq	$225, %ymm5, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vmovdqu	256(%rdx), %ymm6
	vpxor	%ymm5, %ymm8, %ymm7
	vpxor	%ymm7, %ymm6, %ymm5
	vmovdqu	4672(%rsi), %ymm6
	vpermq	$225, %ymm6, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vmovdqu	128(%rdx), %ymm8
	vpxor	%ymm6, %ymm9, %ymm7
	vpxor	%ymm7, %ymm8, %ymm6
	vmovdqu	4704(%rsi), %ymm7
	vpermq	$225, %ymm7, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vmovdqu	32(%rdx), %ymm8
	vpxor	%ymm7, %ymm10, %ymm7
	vpxor	%ymm7, %ymm8, %ymm7
	vmovdqu	4736(%rsi), %ymm9
	vpermq	$225, %ymm9, %ymm8
	vpxor	%ymm8, %ymm9, %ymm9
	vmovdqu	192(%rdx), %ymm8
	vpxor	%ymm9, %ymm11, %ymm9
	vpxor	%ymm9, %ymm8, %ymm8
	vmovdqu	4768(%rsi), %ymm9
	vpermq	$225, %ymm9, %ymm10
	vpxor	%ymm10, %ymm9, %ymm9
	vmovdqu	160(%rdx), %ymm10
	vpxor	%ymm9, %ymm4, %ymm4
	vpxor	%ymm4, %ymm10, %ymm4
	vmovdqu	4800(%rsi), %ymm9
	vpermq	$225, %ymm9, %ymm10
	vpxor	%ymm10, %ymm9, %ymm9
	vmovdqu	64(%rdx), %ymm10
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm1, %ymm10, %ymm10
	vmovdqu	4832(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm9
	vpxor	%ymm9, %ymm1, %ymm1
	vmovdqu	224(%rdx), %ymm9
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm9, %ymm0
	vmovdqu	4864(%rsi), %ymm1
	vpermq	$225, %ymm1, %ymm12
	vpxor	%ymm12, %ymm1, %ymm1
	vmovdqu	96(%rdx), %ymm9
	vpxor	%ymm1, %ymm3, %ymm3
	vpxor	%ymm3, %ymm9, %ymm9
	vmovdqu	(%rdi), %ymm1
	vpermq	$85, %ymm1, %ymm1
	vpxor	%ymm1, %ymm2, %ymm2
	vmovdqu	%ymm2, (%rcx)
	vmovdqu	32(%rdi), %ymm1
	vpermq	$85, %ymm1, %ymm1
	vpxor	%ymm1, %ymm5, %ymm3
	vmovdqu	%ymm3, 32(%rcx)
	vmovdqu	64(%rdi), %ymm2
	vpermq	$85, %ymm2, %ymm1
	vpxor	%ymm1, %ymm6, %ymm1
	vmovdqu	%ymm1, 64(%rcx)
	vmovdqu	96(%rdi), %ymm1
	vpermq	$85, %ymm1, %ymm2
	vpxor	%ymm2, %ymm7, %ymm1
	vmovdqu	%ymm1, 96(%rcx)
	vmovdqu	128(%rdi), %ymm1
	vpermq	$85, %ymm1, %ymm1
	vpxor	%ymm1, %ymm8, %ymm1
	vmovdqu	%ymm1, 128(%rcx)
	vmovdqu	160(%rdi), %ymm3
	vpermq	$85, %ymm3, %ymm2
	vpxor	%ymm2, %ymm4, %ymm1
	vmovdqu	%ymm1, 160(%rcx)
	vmovdqu	192(%rdi), %ymm1
	vpermq	$85, %ymm1, %ymm1
	vpxor	%ymm1, %ymm10, %ymm2
	vmovdqu	%ymm2, 192(%rcx)
	vmovdqu	224(%rdi), %ymm1
	vpermq	$85, %ymm1, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vmovdqu	%ymm0, 224(%rcx)
	vmovdqu	256(%rdi), %ymm0
	vpermq	$85, %ymm0, %ymm0
	vpxor	%ymm0, %ymm9, %ymm4
	vmovdqu	%ymm4, 256(%rcx)
	ret
	.data
	.p2align	5
glob_data:
G$rotr56mask:
	.byte	  7,   0,   1,   2,   3,   4,   5,   6,  15,   8,   9,  10,  11,  12,  13,  14
	.byte	  7,   0,   1,   2,   3,   4,   5,   6,  15,   8,   9,  10,  11,  12,  13,  14
G$rotr48mask:
	.byte	  6,   7,   0,   1,   2,   3,   4,   5,  14,  15,   8,   9,  10,  11,  12,  13
	.byte	  6,   7,   0,   1,   2,   3,   4,   5,  14,  15,   8,   9,  10,  11,  12,  13
G$rotr40mask:
	.byte	  5,   6,   7,   0,   1,   2,   3,   4,  13,  14,  15,   8,   9,  10,  11,  12
	.byte	  5,   6,   7,   0,   1,   2,   3,   4,  13,  14,  15,   8,   9,  10,  11,  12
G$rotr32mask:
	.byte	  4,   5,   6,   7,   0,   1,   2,   3,  12,  13,  14,  15,   8,   9,  10,  11
	.byte	  4,   5,   6,   7,   0,   1,   2,   3,  12,  13,  14,  15,   8,   9,  10,  11
G$rotr24mask:
	.byte	  3,   4,   5,   6,   7,   0,   1,   2,  11,  12,  13,  14,  15,   8,   9,  10
	.byte	  3,   4,   5,   6,   7,   0,   1,   2,  11,  12,  13,  14,  15,   8,   9,  10
G$rotr16mask:
	.byte	  2,   3,   4,   5,   6,   7,   0,   1,  10,  11,  12,  13,  14,  15,   8,   9
	.byte	  2,   3,   4,   5,   6,   7,   0,   1,  10,  11,  12,  13,  14,  15,   8,   9
G$rotr8mask:
	.byte	  1,   2,   3,   4,   5,   6,   7,   0,   9,  10,  11,  12,  13,  14,  15,   8
	.byte	  1,   2,   3,   4,   5,   6,   7,   0,   9,  10,  11,  12,  13,  14,  15,   8
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits
