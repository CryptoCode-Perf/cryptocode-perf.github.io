#!/usr/bin/env bash
# rebuild MoFang-768 with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o MoFang-768.so glue_mofang768_v3b.c CryptHash_AlgorithmInstance.h mofang_keys_v3.s mofang_state_v3.s
sha256sum MoFang-768.so
