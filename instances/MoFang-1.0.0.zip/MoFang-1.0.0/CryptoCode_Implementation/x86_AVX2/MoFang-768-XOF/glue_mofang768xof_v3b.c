/* ==== 本文件由 mofang/build_mofang768xof.py 自动生成，勿手改 ====
 * 基质 = glue_mofang768_v3b.c（我方 MoFang-768 档 glue）
 * 三处改成 768-XOF 档：域分离常量 10 -> 15（XOF 档）；去掉 (void)output_len_bits（XOF 真的会用它）；摘要写出段 -> 96 B/块的 XOF 挤出段
 * 核心（mofang_keys_v3.o / mofang_state_v3.o）与 1024 档完全同一份 ——
 * 官方 768 与 768-XOF 的 encrypt2 / MoFang_BC_2_DBL 逐字相同。
 * ================================================================= */
/* ==== 本文件由 mofang/build_mofang768.py 自动生成，勿手改 ====
 * 基质 = glue_mofang1024_v3b.c（我方 MoFang-1024 第三版 glue）
 * 三处改成 768 档：域分离常量 11 -> 10；out_g 摘要 8 字 -> 6 字；out_h 摘要 8 字 @64 -> 6 字 @48
 * 核心（mofang_keys_v3.o / mofang_state_v3.o）与 1024 档完全同一份 ——
 * 官方两档的 encrypt2 / MoFang_BC_2_DBL / hash_MDPH 逐字相同。
 * ================================================================= */
/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).

ICCS doesn't represent or warrant that the operation of the software will be
uninterrupted or error-free in all cases. ICCS will take no responsibility for
the use of the software or the results thereof, if the software is used for any
other purposes.
*/

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "CryptHash_AlgorithmInstance.h"

#define ROUND 16
// rotate table for shiftrow
// rotate table for key
/// @brief The hash function based on DBL+MDPH
/// @param[in] input The base address of message
/// @param[in] input_len_bits The length of message in BITS
/// @param[in] output_len_bits The length of digest in BITS 
/// @param[out] output The base address of digest
/* 本文件的标量核心已被整体替换：挖掉 221 行官方参考实现代码（rotl/Sbox/SubBytes/mul_row/xor_row/MixColumns/ShiftRows_0/1/AddM_Key2/MessageExpansion2/encrypt2/MoFang_BC_2_DBL + 4 张常量表）。
 * 其余（文件头、hash_MDPH、CryptHash）逐字保留。 */

/* ===================================================================
 * 我方核心（JIR 生成，见 gen/gen_jir_v3.py）
 *
 * 官方参考实现这里原本是：encrypt2 两个 run，各跑 16 轮，密钥扩展因此算了 2 遍。
 * 两个 run 的 k0/k1/k2 逐字相同、初始 state 都是 in_g、只差 state[2][2] 的 1 bit
 *   run1 -> out_g（我方 lane1）
 *   run2 -> out_h（我方 lane0，唯一带 ^1 的那一路）
 * ⇒ 合并成一条 2-lane u256 链；密钥扩展整块只算 1 遍。
 *
 * 第三版再把密钥扩展也搬进 u256：一个 YMM 同时装 (b_i, c_i)，
 * 每轮每字只要 blendd + vrot 各一条 ⇒ 跨轮活跃集从 18 个 u64 降到 9 个 YMM。
 * =================================================================== */
extern void mofang_keys_v3(uint64_t *kinb, uint64_t *kb);
extern void mofang_state_v3(uint64_t *sin, uint64_t *kb, uint64_t *ab0, uint64_t *sout);

void MoFang_BC_2_DBL(uint64_t in_g[3][3], uint64_t in_h[3][3], uint64_t in_m[2][3][3],
                     uint64_t out_g[3][3], uint64_t out_h[3][3])
{
    /* kinb：18 个 u256 广播（前 9 个 = in_m[0]，偏移 288 起 9 个 = in_m[1]） */
    uint64_t kinb[72] __attribute__((aligned(32)));
    /* ab0：9 个 u256 广播 = in_h */
    uint64_t ab0[36]  __attribute__((aligned(32)));
    uint64_t sin[36]  __attribute__((aligned(32)));
    uint64_t sout[36] __attribute__((aligned(32)));
    /* kb：17 组 × 9 个 u256 = 153 个 u256 = 612 个 u64 */
    uint64_t kb[612]  __attribute__((aligned(32)));
    int i, j, k;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            int n = i * 3 + j;
            uint64_t m0 = in_m[0][i][j];
            uint64_t m1 = in_m[1][i][j];
            uint64_t h  = in_h[i][j];
            for (k = 0; k < 4; k++) {
                kinb[4 * n + k]      = m0;
                kinb[36 + 4 * n + k] = m1;
                ab0[4 * n + k]       = h;
            }
            sin[4 * n]     = in_g[i][j] ^ (uint64_t)(n == 8);  /* h 分支的 state[2][2]^=1 */
            sin[4 * n + 1] = in_g[i][j];
            sin[4 * n + 2] = 0;
            sin[4 * n + 3] = 0;
        }
    }
    mofang_keys_v3(kinb, kb);
    mofang_state_v3(sin, kb, ab0, sout);
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            int n = i * 3 + j;
            out_g[i][j] = sout[4 * n + 1];
            out_h[i][j] = sout[4 * n] ^ (uint64_t)(n == 8);    /* out_h[2][2]^=1 */
        }
    }
}







/* ===================================================================
 * 我方 hash_MDPH —— 与官方参考实现**逐字等价**，只把两处逐字节循环换成
 * 等价的 64 位访问（**不是计时**，是静态指令数）：
 *
 *   官方  for k=7..0 { v <<= 8; v |= padded[base+k]; }
 *   ⇒     v = **小端**读 8 字节：p[base+0] 落在最低 8 位
 *          （v = Σ_k p[base+k] << 8k），所以就是一次 `memcpy(&v, p, 8)`，
 *          **不是 bswap64**。第一版我误当成大端、加了 __builtin_bswap64，
 *          `probe3/cmp_so.py` 立刻显示连 0 字节空消息都不一致。
 *   官方  output[i*8+k] = (v >> (8k)) & 0xFF;
 *   ⇒     小端存 8 字节 = memcpy(output + i*8, &v, 8)
 *
 * 其余逐字保留：padded_input_len_bits 的算法、malloc/memset/memcpy、
 * 非字节对齐尾巴的 mask 与 0x80>>rem、in_g[2][2] = 11、最后一块 ^= 2、
 * 块数与 144 字节块距、in_m 两个 72 字节半区的划分、只写前 8 个状态字
 * （i = 0..7，第 9 个字 i = 8 **不写**）、返回 0。
 * =================================================================== */
static uint64_t mofang_ld_le64(const unsigned char *p)
{
    uint64_t v;
    memcpy(&v, p, 8);
    return v;
}

int hash_MDPH(int output_len_bits, const unsigned char *input, uint64_t input_len_bits, unsigned char *output){
    uint64_t padded_input_len_bits = ((input_len_bits + 1152) / 1152) * 1152;
    uint64_t padded_bytes = padded_input_len_bits / 8;
    unsigned char *padded_input = (unsigned char *)malloc(padded_bytes);
    if (padded_input == NULL) {
        return -1;
    }
    memset(padded_input, 0, padded_bytes);
    uint64_t full_bytes = input_len_bits / 8;
    int remaining_bits = input_len_bits % 8;
    memcpy(padded_input, input, full_bytes);
    if (remaining_bits > 0) {
        unsigned char mask = 0xFF << (8 - remaining_bits);
        padded_input[full_bytes] = input[full_bytes] & mask;
        padded_input[full_bytes] |= (0x80 >> remaining_bits);
    } else {
        if (full_bytes < padded_bytes) {
            padded_input[full_bytes] = 0x80;
        }
    }

    uint64_t in_g[3][3] = {0};
    uint64_t in_h[3][3] = {0};
    uint64_t in_m[2][3][3];
    uint64_t out_g[3][3] = {0};
    uint64_t out_h[3][3] = {0};
    in_g[2][2] = 15;
    uint64_t blocks = padded_input_len_bits / 1152;

    for (uint64_t t = 0; t < blocks; t++) {
        const unsigned char *pb = padded_input + t * 144;
        if (t == blocks - 1) {
            in_g[2][2] ^= 2;
        }
        for (int n = 0; n < 9; n++) {
            in_m[0][n / 3][n % 3] = mofang_ld_le64(pb + 8 * n);
            in_m[1][n / 3][n % 3] = mofang_ld_le64(pb + 72 + 8 * n);
        }
        MoFang_BC_2_DBL(in_g, in_h, in_m, out_g, out_h);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                in_g[i][j] = out_g[i][j];
                in_h[i][j] = out_h[i][j];
            }
        }
    }

    {
        int output_blocks = (output_len_bits + 767) / 768;
        int output_len_bytes = (output_len_bits + 7) / 8;
        memset(in_m, 0, sizeof(in_m));
        for (int b = 0; b < output_blocks; b++) {
            if (b != 0) {
                in_h[2][2] ^= 2;
                MoFang_BC_2_DBL(in_g, in_h, in_m, out_g, out_h);
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        in_g[i][j] = out_g[i][j];
                        in_h[i][j] = out_h[i][j];
                    }
                }
            }
            for (int j = 0; j < 96 && b * 96 + j < output_len_bytes; j++) {
                unsigned char ss = (j < 48)
                    ? (unsigned char)((out_g[(j / 8) / 3][(j / 8) % 3]
                                       >> (8 * (j % 8))) & 0xFFu)
                    : (unsigned char)((out_h[((j - 48) / 8) / 3][((j - 48) / 8) % 3]
                                       >> (8 * ((j - 48) % 8))) & 0xFFu);
                if (b * 96 + j == output_len_bytes - 1) {
                    int remaining_bits = output_len_bits % 8;
                    if (remaining_bits == 0) remaining_bits = 8;
                    ss = (unsigned char)(ss & (unsigned char)(0xFFu << (8 - remaining_bits)));
                }
                output[b * 96 + j] = ss;
            }
        }
    }
    free(padded_input);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest)
{
    return hash_MDPH(digest_len_bits, msg, msg_len_bits,  digest);
}