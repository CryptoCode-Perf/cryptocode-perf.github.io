/* 自动生成，勿手改 —— 见 mofang/build_mofang_drv.py:make_glue() */
/* 基质 = 官方 Optimized_Implementation/MoFang-256-XOF/CryptHash_AlgorithmInstance.c */
/* 改动 = 只替换 hash_MDP 驱动层 */
/*        MoFang_BC_1 / MoFang_BC_1_DM / MixColumns / MUL / rotl 与全部静态表逐字保留 */
/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).

ICCS doesn't represent or warrant that the operation of the software will be
uninterrupted or error-free in all cases. ICCS will take no responsibility for
the use of the software or the results thereof, if the software is used for any
other purposes.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include "CryptHash_AlgorithmInstance.h"


#define ULL uint64_t

#define ROUND 16

/// @brief The rotation offsets for ShiftRow
static const int rhoy0[3][3] = {
    {0,3,6},
    {9,12,15},
    {18,21,24}
};

static const int rhoy1[3][3] = {
    {0,24,48},
    {8,32,56},
    {16,40,7}
};


/// @brief The rotation offsets for Key transposition
static const int rhok[2][3][3] = {
    {
        {1,5,11},
        {17,0,31},
        {41,47,59}
    },
    {
        {3,7,19},
        {43,53,61},
        {0,29,37},
    }
};


/// @brief The round constants for AddRoundConstant
static const ULL ct[24] = {
	0x24, 0x3f, 0x6a, 0x88, 0x85, 0xa3, 0x08, 0xd3, 0x13, 0x19, 0x8a, 0x2e,
    0x03, 0x70, 0x73, 0x44, 0xa4, 0x09, 0x38, 0x22, 0x29, 0x9f, 0x31, 0xd0
};


static inline ULL rotl(ULL x, int shift) {
    return (x << shift) | (x >> (64 - shift));
}


/// @brief The multiplication function for bit-sliced operations
static inline void MUL(ULL *x0, ULL *x1, ULL *x2){
    ULL tmp = *x2;; 
    *x2 = *x1; *x1 = *x0; *x0 = tmp; 
    *x1 ^= *x0; 
}

/// @brief The bit-sliced MDS matrix multiplication
static inline void MixColumns(ULL state[3][3]){
    ULL tmp[3]; 
    tmp[0] = state[0][0] ^ state[1][0] ^ state[2][0];       // tmp = C ^ B ^ A
    tmp[1] = state[0][1] ^ state[1][1] ^ state[2][1];
    tmp[2] = state[0][2] ^ state[1][2] ^ state[2][2];      
    MUL(&tmp[0], &tmp[1], &tmp[2]);                         //  tmp = MUL(tmp)
    state[2][0] ^= tmp[0]; state[2][1] ^= tmp[1]; state[2][2] ^= tmp[2]; //  C ^= tmp
    state[1][0] ^= tmp[0]; state[1][1] ^= tmp[1]; state[1][2] ^= tmp[2]; //  B ^= tmp
    state[0][0] ^= tmp[0]; state[0][1] ^= tmp[1]; state[0][2] ^= tmp[2]; //  A ^= tmp

}


/// @brief The based block cipher of MoFang with keylen 2n
/// @param[in] state The input internal state/chaining value
/// @param[in] Key The Key/message state
/// @param[in] roundNum The number of rounds to execute
void MoFang_BC_1(ULL state[3][3], ULL Key[2][3][3],  int roundNum){
    ULL A[3][3], B[3][3], C[3][3], X[3][3];
    ULL K[2][3][3] = {0};
    ULL TmpS[3];

    memcpy(K, Key, sizeof(K));
    for(int i=0; i<3; i++) {
        for(int j=0; j<3; j++){
            A[i][j] = state[i][j] ^ Key[0][i][j] ^ Key[1][i][j];
        }
    }

    for (int r = 0; r < roundNum; r++) {
        //keyexpansion
        //S box
        TmpS[0] = (K[0][0][1] & K[0][0][2]) ^ K[0][0][0];
        TmpS[1] = (TmpS[0] & K[0][0][2]) ^ K[0][0][1];
        TmpS[2] = (TmpS[0] | TmpS[1]) ^ K[0][0][2];

        K[0][0][0] = TmpS[0];
        K[0][0][1] = TmpS[1];
        K[0][0][2] = TmpS[2];

        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++) {
                X[i][j] = K[0][j][(j+2*i)%3];
            }
        }

        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++){
                K[0][i][j] = rotl(X[i][j], rhok[0][i][j]);
            }
        }

        TmpS[0] = (K[1][0][1] & K[1][0][2]) ^ K[1][0][0];
        TmpS[1] = (TmpS[0] & K[1][0][2]) ^ K[1][0][1];
        TmpS[2] = (TmpS[0] | TmpS[1]) ^ K[1][0][2];

        K[1][0][0] = TmpS[0];
        K[1][0][1] = TmpS[1];
        K[1][0][2] = TmpS[2];

        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++) {
                X[i][j] = K[1][(i+2*j)%3][i];
            }
        }

        
        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++){
                K[1][i][j] = rotl(X[i][j], rhok[1][i][j]);
            }
        }
        K[1][0][0] ^= ct[r];
       

        // Sbox
         for (int i = 0; i < 3; i++){ 
            B[i][0] = (A[i][1] & A[i][2]) ^ A[i][0];
            B[i][1] = (B[i][0] & A[i][2]) ^ A[i][1];
            B[i][2] = (B[i][0] | B[i][1]) ^ A[i][2];

        }
        
        // MixColumns
        MixColumns(B);
        
        // ShiftRows
        if(r%2==0) {
            for(int i=0; i<3; i++){
                for(int j=0; j<3; j++){
                    C[i][j] = rotl(B[i][j], rhoy0[i][j]);
                }
            }
        } else {
            for(int i=0; i<3; i++){
                for(int j=0; j<3; j++){
                    C[i][j] = rotl(B[i][j], rhoy1[i][j]);
                }
            }
        }
        

        for(int i=0; i<3; i++) {
            for(int j=0; j<3; j++){
                A[i][j] = C[i][j] ^ K[0][i][j] ^ K[1][i][j];
            }
        }

    }

    memcpy(state, A, sizeof(A));

}

void MoFang_BC_1_DM(ULL state[3][3], ULL Key[2][3][3],  int roundNum){
    ULL s[3][3] = {0};
    ULL k[2][3][3] = {0};
    memcpy(s, state, sizeof(s));
    memcpy(k, Key, sizeof(k));
    MoFang_BC_1(s, k, roundNum);
    for(int i=0; i<3; i++) {
        for(int j=0; j<3; j++){
            state[i][j] ^= s[i][j];
        }
    }
    
}



/// @brief The hash function based on DM+MDP
/// @param[in] input The base address of message
/// @param[in] input_len_bits The length of message in BITS
/// @param[in] output_len_bits The length of digest in BITS (should be equal to hash)
/// @param[out] output The base address of digest
/* ------------------------------------------------------------------
 * 驱动层（我方改写）。语义与官方 hash_MDP 逐字等价：
 *   padded_input_len_bits = ((input_len_bits + 1152) / 1152) * 1152
 *   10* padding（先补一个 '1' 位，再补 0 到块边界），末块 state[2][2] ^= 1
 *   每块 K[2][3][3] 由该块 144 字节按小端整数装入
 *   摘要 = state[i/3][i%3] 的小端字节，i = 0..4-1
 * 改动只在这里：不再 malloc/memset/memcpy 整条消息、不再逐字节打包、不再逐字节写摘要。
 * ------------------------------------------------------------------ */
#define MDP_RATE_BYTES    144u   /* 1152 位 */
#define MDP_RATE_BITS    1152u

static inline ULL mdp_ld64le(const unsigned char *p) {
    ULL x;
    memcpy(&x, p, sizeof(x));
    return x;
}

static inline void mdp_st64le(unsigned char *p, ULL x) {
    memcpy(p, &x, sizeof(x));
}

/* 把 144 B 消息块打成 K[2][3][3]（小端整数，等价官方逐字节 <<8/| 循环） */
static inline void mdp_pack_key(ULL K[2][3][3], const unsigned char *blk) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            K[0][i][j] = mdp_ld64le(blk + (unsigned)(i * 3 + j) * 8u);
            K[1][i][j] = mdp_ld64le(blk + 72u + (unsigned)(i * 3 + j) * 8u);
        }
    }
}

int hash_MDP(int output_len_bits, const unsigned char *input,
             ULL input_len_bits, unsigned char *output) {

    ULL padded_input_len_bits = ((input_len_bits + MDP_RATE_BITS) / MDP_RATE_BITS) * MDP_RATE_BITS;
    ULL full_bytes = input_len_bits / 8u;
    int remaining_bits = (int)(input_len_bits % 8u);
    ULL blocks = padded_input_len_bits / MDP_RATE_BITS;

    ULL state[3][3] = {{0}};
    ULL K[2][3][3];
    state[2][2] = 7;

    /* 前面 blocks-1 块全是完整消息块：直接从 input 读，不做任何拷贝 */
    for (ULL t = 0; t + 1u < blocks; t++) {
        mdp_pack_key(K, input + t * MDP_RATE_BYTES);
        MoFang_BC_1_DM(state, K, ROUND);
    }

    /* 最后一块含填充：栈缓冲 144 B */
    {
        unsigned char last[MDP_RATE_BYTES] = {0};
        ULL t = blocks - 1u;
        ULL off = t * MDP_RATE_BYTES;
        ULL rem = full_bytes - off;              /* 0 .. 143 */
        if (rem > 0u) {
            memcpy(last, input + off, (size_t)rem);
        }
        if (remaining_bits > 0) {
            unsigned char mask = (unsigned char)(0xFFu << (8 - remaining_bits));
            last[rem] = (unsigned char)(input[full_bytes] & mask);
            last[rem] = (unsigned char)(last[rem] | (0x80u >> remaining_bits));
        } else {
            last[rem] = 0x80u;
        }
        state[2][2] ^= 1;
        mdp_pack_key(K, last);
        MoFang_BC_1_DM(state, K, ROUND);
    }

    /* XOF 挤出：每块 32 B = state 前 4 个字的低端字节；块间 state[2][2] ^= 1 再跑一轮 */
    {
        int output_blocks = (output_len_bits + 255) / 256;
        int output_len_bytes = (output_len_bits + 7) / 8;
        for (int i = 0; i < output_blocks; i++) {
            if (i != 0) {
                state[2][2] ^= 1;
                MoFang_BC_1_DM(state, K, ROUND);
            }
            int base = i * 32;
            int avail = output_len_bytes - base;
            if (avail > 32) avail = 32;
            if (avail == 32 && (output_len_bits % 8) == 0) {
                for (int w = 0; w < 4; w++) {
                    mdp_st64le(output + (unsigned)base + (unsigned)w * 8u,
                               state[w / 3][w % 3]);
                }
            } else {
                for (int j = 0; j < avail; j++) {
                    unsigned char ss = (unsigned char)
                        ((state[(j / 8) / 3][(j / 8) % 3] >> (8 * (j % 8))) & 0xFFu);
                    if (base + j == output_len_bytes - 1) {
                        int rb = output_len_bits % 8;
                        if (rb == 0) rb = 8;
                        ss = (unsigned char)(ss & (unsigned char)(0xFFu << (8 - rb)));
                    }
                    output[base + j] = ss;
                }
            }
        }
    }
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest)
{
    return hash_MDP(digest_len_bits, msg, msg_len_bits,  digest);
}