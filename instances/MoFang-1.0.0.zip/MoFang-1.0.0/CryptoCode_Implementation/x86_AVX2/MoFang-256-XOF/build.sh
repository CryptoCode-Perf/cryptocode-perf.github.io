#!/usr/bin/env bash
# rebuild MoFang-256-XOF with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o MoFang-256-XOF.so glue_mofang256xofdrv.c CryptHash_AlgorithmInstance.h mofang_keys_v3.s mofang_state_v3.s
sha256sum MoFang-256-XOF.so
