# Eijen — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| Eijen-1024 | `Eijen-1024.so` | 26840 B | `a3803c644d62fbf4a295308bc0c91ee16aceca81e094f0224569d2e67e76c58d` |
| Eijen-256 | `Eijen-256.so` | 26840 B | `7c8ea6880b841912d891bd5b5db616af17e5dc78bd7462443329d51f5f0f3a98` |
| Eijen-384 | `Eijen-384.so` | 26840 B | `62d8ce251d02379e685805e195f60fb5f1b81ad9b3e45763f4fad7bb1b56c3cb` |
| Eijen-512 | `Eijen-512.so` | 26840 B | `420eac1809d93022e405888a3b6c44f967704ab226b2bcade9cc6de0275f7777` |
| Eijen-768 | `Eijen-768.so` | 26840 B | `103a3f25d75f6ca452d0e9d1b1d2503f59520d5e2bbef21a98e698e46a8e07fd` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| Eijen-1024 | 1024 | 9.6318 | 3.9527 | 3.664153 | 1.078749 | 1.0798 |
| Eijen-256 | 256 | 5.0674 | 2.0804 | 1.895244 | 1.097695 | 1.101 |
| Eijen-384 | 384 | 6.5352 | 2.7871 | 2.559115 | 1.089087 | 1.0935 |
| Eijen-512 | 512 | 6.1504 | 2.5701 | 2.414352 | 1.064509 | 1.0678 |
| Eijen-768 | 768 | 7.1104 | 2.9176 | 2.796228 | 1.043406 | 1.0555 |

## 优化方法（逐实例原文，来自交付清单）

### Eijen-1024
引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_1024.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 1024（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen_p4 1738 → 1391 条（−20.0%）、vmovdqu 169 → 0、vpand 256 → 0、vpor 304 → 176。等价性：ref/base/cand 各 4097/4097（ab_check_siblings09.py，含 512 自检）、位长扫描 1024/1024 相同、三负对照各 256/256 变色

### Eijen-256
引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_256.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 256（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen_p4 1738 → 1391 条（−20.0%）、vmovdqu 169 → 0、vpand 256 → 0、vpor 304 → 176。等价性：ref/base/cand 各 4097/4097（ab_check_siblings09.py，含 512 自检）、位长扫描 1024/1024 相同、三负对照各 256/256 变色

### Eijen-384
引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_384.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 384（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen_p4 1738 → 1391 条（−20.0%）、vmovdqu 169 → 0、vpand 256 → 0、vpor 304 → 176。等价性：ref/base/cand 各 4097/4097（ab_check_siblings09.py，含 512 自检）、位长扫描 1024/1024 相同、三负对照各 256/256 变色

### Eijen-512
引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_512.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py。布局 g{g}{k} 的 lane l = 词 16g+4l+k，8 个 ymm 承载 32 词无哑 lane；sigma 退化成 4 条纯改名 + 8 条 vpermq，不再是 32 条 load/store。等价性：ref/base/cand 各 4097/4097（ab_check_h09.py），位长扫描 1024/1024 相同

### Eijen-768
引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_768.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 768（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen_p4 1738 → 1391 条（−20.0%）、vmovdqu 169 → 0、vpand 256 → 0、vpor 304 → 176。等价性：ref/base/cand 各 4097/4097（ab_check_siblings09.py，含 512 自检）、位长扫描 1024/1024 相同、三负对照各 256/256 变色
