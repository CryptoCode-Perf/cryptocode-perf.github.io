# Eijen — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Eijen-1024
- 摘要位：1024；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/Eijen-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Eijen-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Eijen-1024/`
- 优化要点：引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_1024.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 1024（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen

## Eijen-256
- 摘要位：256；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/Eijen-256/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Eijen-256/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Eijen-256/`
- 优化要点：引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_256.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 256（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen_p

## Eijen-384
- 摘要位：384；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/Eijen-384/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Eijen-384/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Eijen-384/`
- 优化要点：引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_384.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 384（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen_p

## Eijen-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/Eijen-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Eijen-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Eijen-512/`
- 优化要点：引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_512.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py。布局 g{g}{k} 的 lane l = 词 16g+4l+k，8 个 ymm 承载 32 词无哑 lane；sigma 退化成 4 条纯改名 + 8 条 vpermq，不再是 32 条 load/store。等价性：ref/base/cand 各 4097/4097（ab_check_h09.py），位长扫描 1024/1024 相同

## Eijen-768
- 摘要位：768；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/Eijen-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Eijen-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Eijen-768/`
- 优化要点：引擎生成器 v3（sigma blend）产物 _overnight/l0/eijen2/out_blend/ours_eijen2_768.so：_eij/gen_eijen4.py → _eij/eijen4.jazz → jasminc → build_eijen2.py --bits 768（同一份生成器与同一份编译器，四件之间只有 BITS 与派发常量不同，不是同一份二进制改数字）。与 h09 的 v1/v2 同一路线，但 sigma 的「换一个 lane」由 3 条 and/or 改成单指令 #VPBLEND_8u32（imm 置位的 dword 取自第二操作数，blend_probe.c 实测确认），连带把 LANE0C/LANE3C/LANE012C/LANE123C 四个常量整体删掉——8 状态 + 8 q 已占满 16 个 ymm，常量原本每轮从内存重载。eijen_p
