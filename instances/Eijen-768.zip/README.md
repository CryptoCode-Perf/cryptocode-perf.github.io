# Eijen-768

Algorithm: Eijen | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header Eijen-768.h, prebuilt Eijen-768.so,
KAT vector KAT_2_12_Eijen-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 103a3f25d75f6ca452d0e9d1b1d2503f59520d5e2bbef21a98e698e46a8e07fd
Speed (cpB, lower is faster): reference 7.11 / official-optimized 2.92 / optimized 2.80
Speedup: GM(S1-S8) 1.06x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
