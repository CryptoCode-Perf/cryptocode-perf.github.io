#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Eijen (hash-09) 同族五个实例的三道等价门 —— 把 ab_check_h09.py 参数化。

ab_check_h09.py 的 BASE/CAND/REF/KAT 是写死在 Eijen-512 上的（那一版是第 5 例
Eijen-512 交付时写的判据）。本文件把四个路径改成按实例表取，逐实例跑同一套门：

  A1  全量 KAT 4097 条：官方 ref 必须全过（阳性对照），cand 必须全过，
      且 cand 与 base（官方 Optimized）逐条同结论。
  A2  位长扫描 0..sweep-1：cand 与 base 摘要逐条相同。
  A3  负对照：把 cand 的 .text 扰动一个字节，A2 的扫描必须变色
      （证明 A2 真的在判定，而不是两边都返回同一个常量）。

为什么每条实例都要跑：Eijen 的 rate/capacity 逐实例不同（rate 120/152/184/200/216
字节），布局改写对每个实例都是独立的一份产物，一份通过不能代表另一份。

kat_gate 的真实 API 是 parse_kat(path) / check(lib, recs)，且 check() 内部按
MAX_RECORDS 截断 —— 全量比对必须先把 MAX_RECORDS 抬上去，否则「4097/4097」
实际只是 40/40，是假读数。

用法:
  python3 ab_check_siblings09.py                  # 五个实例全跑
  python3 ab_check_siblings09.py --only Eijen-768
  python3 ab_check_siblings09.py --skip-negctl
  python3 ab_check_siblings09.py --sweep 1024      # A2 扫描位长上限
"""
import argparse
import ctypes
import hashlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))

sys.path.insert(0, L0)
import kat_gate as KG  # noqa: E402

BUILD = os.path.join(L0, "build", "hash-09")
KATDIR = os.path.join(L0, "src", "hash-09", "Eijen", "Test_Vectors")

# (instance, bits, ref, base(=官方 opt), cand)
INSTANCES = [
    ("Eijen-256", 256,
     os.path.join(BUILD, "eijen256", "ref.so"),
     os.path.join(BUILD, "eijen256", "opt.so"),
     os.path.join(HERE, "out_blend", "ours_eijen2_256.so")),
    ("Eijen-384", 384,
     os.path.join(BUILD, "eijen384", "ref.so"),
     os.path.join(BUILD, "eijen384", "opt.so"),
     os.path.join(HERE, "out_blend", "ours_eijen2_384.so")),
    ("Eijen-512", 512,
     os.path.join(BUILD, "eijen512", "ref.so"),
     os.path.join(BUILD, "eijen512", "opt.so"),
     os.path.join(HERE, "out_blend", "ours_eijen2_512.so")),
    ("Eijen-768", 768,
     os.path.join(BUILD, "eijen768", "ref.so"),
     os.path.join(BUILD, "eijen768", "opt.so"),
     os.path.join(HERE, "out_blend", "ours_eijen2_768.so")),
    ("Eijen-1024", 1024,
     os.path.join(BUILD, "eijen1024", "ref.so"),
     os.path.join(BUILD, "eijen1024", "opt.so"),
     os.path.join(HERE, "out_blend", "ours_eijen2_1024.so")),
]


def sha16(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 16), b""):
            h.update(b)
    return h.hexdigest()[:16]


def digest(lib, msg, bits, dlen_bytes):
    """直接调 CryptHash，返回 (rc, digest_hex)。dlen_bytes = 摘要字节数。"""
    dll = ctypes.CDLL(os.path.abspath(lib))
    fn = getattr(dll, "CryptHash", None)
    if fn is None:
        raise RuntimeError("no CryptHash in %s" % lib)
    fn.restype = ctypes.c_int
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_ulonglong,
                   ctypes.c_char_p]
    buf = ctypes.create_string_buffer(dlen_bytes + 16)
    rc = fn(dlen_bytes * 8, msg, ctypes.c_ulonglong(bits), buf)
    return rc, buf.raw[:dlen_bytes].hex()


def digest_forked(lib, msg, bits, dlen_bytes):
    """在子进程里取一次摘要：扰动过的 .so 会 SIGILL/SIGSEGV，
    直接在本进程调会把整个判据装置打死。子进程崩掉返回 None，
    由调用方记成「变色」。"""
    rfd, wfd = os.pipe()
    pid = os.fork()
    if pid == 0:                                  # child
        os.close(rfd)
        try:
            res = digest(lib, msg, bits, dlen_bytes)
        except BaseException:                     # noqa: BLE001
            res = None
        try:
            with os.fdopen(wfd, "wb") as fh:
                fh.write(b"" if res is None
                         else ("%d:%s" % (res[0], res[1])).encode())
        finally:
            os._exit(0)
    os.close(wfd)
    with os.fdopen(rfd, "rb") as fh:
        data = fh.read()
    os.waitpid(pid, 0)
    if not data:
        return None
    rc, h = data.decode().split(":", 1)
    return int(rc), h


def make_msg(bits):
    nbytes = (bits + 7) // 8
    return bytes(((i * 37 + bits * 11) & 0xFF) for i in range(nbytes))


def run_one(inst, bits, ref, base, cand, sweep, skip_negctl):
    dlen = bits // 8
    kat = os.path.join(KATDIR, "KAT_2_12_%s.txt" % inst)
    print("=" * 72)
    print("### %s   (bits=%d, digest=%d B)" % (inst, bits, dlen))
    print("=" * 72)

    for p in (ref, base, cand, kat):
        if not os.path.exists(p):
            print("  FATAL: 缺文件 %s" % p)
            return False

    for label, p in (("ref", ref), ("base", base), ("cand", cand)):
        print("  %-4s %-18s %8d B  sha16 %s"
              % (label, os.path.basename(p), os.path.getsize(p), sha16(p)))
    print("  KAT  %s" % os.path.basename(kat))

    recs = KG.parse_kat(kat)
    print("\n  === A1 全量 KAT（解析出 %d 条）" % len(recs))
    if len(recs) < 1000:
        print("  FATAL: 只解析出 %d 条，远少于 4097 ⇒ 判据不成立，停" % len(recs))
        return False

    # check() 内部按 MAX_RECORDS 截断；全量必须抬高，否则 4097/4097 是假读数。
    KG.MAX_RECORDS = len(recs)
    KG.MAX_MSG_BYTES = 1 << 20

    res = {}
    for tag, lib in (("ref", ref), ("base", base), ("cand", cand)):
        n, m, first, err = KG.check(lib, recs)
        res[tag] = (n, m, first, err)
        print("    %-6s %d/%d  first_bad=%s  err=%s" % (tag, m, n, first, err))

    ok_a1a = res["ref"][0] > 0 and res["ref"][0] == res["ref"][1]
    ok_a1b = res["cand"][0] > 0 and res["cand"][0] == res["cand"][1]
    ok_a1c = (res["base"][0] == res["cand"][0]
              and res["base"][2] == res["cand"][2])
    print("    A1a ref 全过            : %s" % ok_a1a)
    print("    A1b cand 全过           : %s" % ok_a1b)
    print("    A1c cand 与 base 同结论 : %s" % ok_a1c)

    print("\n  === A2 位长扫描 0..%d（cand vs base 逐条相同）" % (sweep - 1))
    same = diff = 0
    first_diff = None
    for b in range(sweep):
        msg = make_msg(b)
        rb, hb = digest(base, msg, b, dlen)
        rc_, hc = digest(cand, msg, b, dlen)
        if rb == rc_ and hb == hc:
            same += 1
        else:
            diff += 1
            if first_diff is None:
                first_diff = {"bits": b, "rc": (rb, rc_), "base": hb[:16],
                              "cand": hc[:16]}
    print("    same %d / %d   diff %d   first_diff=%s"
          % (same, same + diff, diff, first_diff))
    ok_a2 = (diff == 0 and same > 0)

    print("\n  === A3 负对照（扰动 cand 的一个字节，A2 必须变色）")
    ok_a3 = None
    if skip_negctl:
        print("    SKIPPED（--skip-negctl）：**跳过不等于通过**")
    else:
        raw = bytearray(open(cand, "rb").read())
        # 改 .text 里的一个字节：找一个非零、且不在 ELF 头/段表附近的偏移。
        # 目的只是让它坏掉，不追求「只坏一处语义」。
        idx = raw.find(b"\x48\x8b", 4096)
        if idx < 0:
            print("    FATAL: 找不到可扰动字节 ⇒ 负对照无法进行（不是通过）")
            ok_a3 = False
        else:
            neg = os.path.join(HERE, "_neg_%s.so" % inst)
            raw[idx + 1] ^= 0xFF
            open(neg, "wb").write(bytes(raw))
            chg = 0
            for b in range(0, 256):
                msg = make_msg(b)
                hc = digest(cand, msg, b, dlen)
                hn = digest_forked(neg, msg, b, dlen)
                # 扰动件可能直接 SIGILL/SIGSEGV —— 那也算「变色」：
                # 它确实坏了，只是坏得比「算错」更彻底。
                if hn is None or hc != hn:
                    chg += 1
            print("    扰动件 vs cand：%d / 256 变色（期望 >0；崩溃计为变色）" % chg)
            ok_a3 = (chg > 0)
            try:
                os.remove(neg)
            except OSError:
                pass

    allok = ok_a1a and ok_a1b and ok_a1c and ok_a2 and (ok_a3 is not False)
    print("\n  === 判决 %s" % inst)
    print("    A1a=%s A1b=%s A1c=%s A2=%s A3=%s"
          % (ok_a1a, ok_a1b, ok_a1c, ok_a2, ok_a3))
    print("    => %s" % ("ALL PASS" if allok else "FAIL"))
    print()
    return allok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None,
                    help="只跑一个实例，如 Eijen-768")
    ap.add_argument("--skip-negctl", action="store_true")
    ap.add_argument("--sweep", type=int, default=1024)
    a = ap.parse_args()

    todo = [t for t in INSTANCES if a.only is None or t[0] == a.only]
    if not todo:
        print("FATAL: --only %s 不在表里" % a.only)
        return 2

    verdicts = {}
    for inst, bits, ref, base, cand in todo:
        try:
            verdicts[inst] = run_one(inst, bits, ref, base, cand,
                                     a.sweep, a.skip_negctl)
        except Exception as exc:                   # noqa: BLE001
            print("  EXCEPTION in %s: %r" % (inst, exc))
            verdicts[inst] = False

    print("=" * 72)
    print("### 总判决")
    for inst, ok in verdicts.items():
        print("  %-12s %s" % (inst, "ALL PASS" if ok else "FAIL"))
    allok = all(verdicts.values())
    print("  => %s" % ("OVERALL: ALL PASS" if allok else "OVERALL: FAIL"))
    return 0 if allok else 1


if __name__ == "__main__":
    sys.exit(main())
