"""gen_eijen4.py — Eijen-512 置换的 4-lane 向量生成器（R2 级：状态内 SIMD）

为什么先做 Eijen：它的官方 opt 与 ref 同速（0.998×），是整个候选集里唯一
"赢 ref 就等于赢 opt" 的算法；而它的结构恰好是 4-lane 的完美适配：
8 个 4 词列，同组 4 列共用同一套旋转常数 → lane = 列号 时全部算子逐 lane。

布局（关键，决定 sigma 的成本）：
    g{g}{k}（g∈{0,1} 组，k∈{0..3} 角色 a/b/c/d）的 lane l = 词 16g+4l+k
    → 每组 4 个 ymm，共 8 个 ymm 承载 32 词，无哑 lane；
    → mixquad 逐 lane 成立（旋转常数同组一致）；
    → linear layer 退化成 3 条 xor + 4 条 xor（逐 lane）；
    → sigma 在这个布局下退化成 4 条纯改名 + 4 条「vpermq 转 1 lane 再插 1 lane」，
      每个 sigma 8 条 vpermq + 12 条逻辑，而不是 32 条 load/store。

顺序必须与 ref 严格一致：columns → sigma → linear → sigma → columns …
"""
import os

# ---- Eijen-512 参数（eijen_internal.h）-------------------------------------
ROUNDS = 16
ROT0 = (36, 54, 45, 44, 18, 9)      # 列 0..3
ROT1 = (56, 46, 54, 34, 19, 51)     # 列 4..7
RC0 = [0x243F6A8885A308D3, 0xA4093822299F31D0, 0x452821E638D01377, 0xC0AC29B7C97C50DD,
       0x9216D5D98979FB1B, 0x2FFD72DBD01ADFB7, 0xBA7C9045F12C7F99, 0x0801F2E2858EFC16,
       0xA458FEA3F4933D7E, 0x718BCD5882154AEE, 0x9C30D5392AF26013, 0xCA417918B8DB38EF,
       0x6C9E0E8BB01E8A3E, 0x78AF2FDA55605C60, 0x5748986263E81440, 0xB4CC5C341141E8CE]
RC1 = [0x13198A2E03707344, 0x082EFA98EC4E6C89, 0xBE5466CF34E90C6C, 0x3F84D5B5B5470917,
       0xD1310BA698DFB5AC, 0xB8E1AFED6A267E96, 0x24A19947B3916CF7, 0x636920D871574E69,
       0x0D95748F728EB658, 0x7B54A41DC25A59B5, 0xC5D1B023286085F0, 0x8E79DCB0603A180E,
       0xD71577C1BD314B27, 0xE65525F3AA55AB94, 0x55CA396A2AAB10B6, 0xA15486AF7C72E993]

# sigma: new[i] = old[sig[i]]（由 ref 的赋值序列反解，32-排列已断言）
SIG = [22, 0, 29, 19, 26, 4, 1, 23, 30, 8, 5, 27, 2, 12, 9, 31,
       6, 16, 13, 3, 10, 20, 17, 7, 14, 24, 21, 11, 18, 28, 25, 15]

def vperm_imm(sel):
    v = 0
    for i, s in enumerate(sel):
        v |= (s & 3) << (2 * i)
    return v

IMM_ROT1 = vperm_imm([1, 2, 3, 0])      # 57
IMM_ROTR1 = vperm_imm([3, 0, 1, 2])     # 147
IMM_BC0 = vperm_imm([0, 0, 0, 0])       # 0
IMM_BC3 = vperm_imm([3, 3, 3, 3])       # 255

# vpblendd 立即数：一个 lane = 2 个 dword；imm 置位的 dword 取自第二操作数。
IMM_BLEND_L0 = 0b00000011               # 3   → lane0 取第二操作数
IMM_BLEND_L3 = 0b11000000               # 192 → lane3 取第二操作数
IMM_BLEND_L123 = 0b11111100             # 252 → lanes1-3 取第二操作数

M64 = (1 << 64) - 1
LANE0 = M64
LANE3 = M64 << 192
LANE012 = (1 << 192) - 1
LANE123 = ((1 << 256) - 1) & ~M64

L = []
def e(s):
    L.append("  " + s)

def konst(name, value):
    L.append("u256 %s = 0x%064x;" % (name, value))

def bcast(name, v):
    konst(name, v | (v << 64) | (v << 128) | (v << 192))

def R(g, k):
    return "g%d%s" % (g, "abcd"[k])

# ---- 发射原语 --------------------------------------------------------------
def add_(dst, a, b):
    e("%s = #VPADD_4u64(%s, %s);" % (dst, a, b))

BYTE_ROT_MASK = {8, 16, 24, 32, 40, 48, 56}

def rotl(dst, src, n, lo, hi):
    """n 为 8 的倍数时 rotl 等价于 vpshufb 单指令，否则两条立即数移位 + or。"""
    if n in BYTE_ROT_MASK:
        e("%s = #VPSHUFB_256(%s, ROTM%d);" % (dst, src, n))
        return
    e("%s = #VPSLL_4u64(%s, %d);" % (lo, src, n))
    e("%s = #VPSRL_4u64(%s, %d);" % (hi, src, 64 - n))
    e("%s = %s | %s;" % (dst, lo, hi))

def mixquad(g, rcname, rot):
    a, b, c, d = R(g, 0), R(g, 1), R(g, 2), R(g, 3)
    r0, r1, r2, r3, r4, r5 = rot
    add_(a, a, b)
    e("%s = %s ^ %s;" % (d, d, a))
    rotl(d, d, r0, "q0", "q1")
    rotl(a, a, r4, "q0", "q1")
    e("%s = %s ^ %s;" % (a, a, rcname))
    add_(c, c, d)
    e("%s = %s ^ %s;" % (b, b, c))
    rotl(b, b, r1, "q0", "q1")
    rotl(c, c, r5, "q0", "q1")
    add_(a, a, b)
    e("%s = %s ^ %s;" % (d, d, a))
    rotl(d, d, r2, "q0", "q1")
    add_(c, c, d)
    e("%s = %s ^ %s;" % (b, b, c))
    rotl(b, b, r3, "q0", "q1")

def sigma():
    """4 条纯改名 + 2 对「vpermq 后互换一条 lane」。

    t0 = [g1c1, g1c2, g1c3, g0c0]
    t1 = [g0c1, g0c2, g0c3, g1c0]
      → u = rot1(g1c), v = rot1(g0c) 后直接把两者的 lane3 互换即可，
        不需要额外的广播 vpermq（原来 8 条 vpermq/sigma，现在 4 条）。
    """
    e("q2 = #VPERMQ(%s, %d);" % (R(1, 2), IMM_ROT1))     # u
    e("q3 = #VPERMQ(%s, %d);" % (R(0, 2), IMM_ROT1))     # v
    # vpblendd 一步换 lane：imm 置位的 dword 取自第二操作数。
    # 一个 lane = 2 个 dword ⇒ lane0 = 0b00000011 = 3，lane3 = 0b11000000 = 192，
    # lanes1-3 = 0b11111100 = 252。原实现每对 3 条 and/or，这里各 1 条。
    e("q4 = #VPBLEND_8u32(q2, q3, %d);" % IMM_BLEND_L3)   # t0
    e("q5 = #VPBLEND_8u32(q3, q2, %d);" % IMM_BLEND_L3)   # t1
    e("q6 = #VPERMQ(%s, %d);" % (R(0, 1), IMM_ROTR1))    # p
    e("q7 = #VPERMQ(%s, %d);" % (R(1, 1), IMM_ROTR1))    # q
    e("q0 = #VPBLEND_8u32(q6, q7, %d);" % IMM_BLEND_L0)   # t2
    e("q1 = #VPBLEND_8u32(q6, q7, %d);" % IMM_BLEND_L123) # t3
    # 改名：d 互换 → b ← a → a/c 取 t
    e("q6 = %s;" % R(0, 3))
    e("%s = %s;" % (R(0, 3), R(1, 3)))
    e("%s = %s;" % (R(1, 3), "q6"))
    e("%s = %s;" % (R(0, 1), R(0, 0)))
    e("%s = %s;" % (R(1, 1), R(1, 0)))
    e("%s = %s;" % (R(0, 0), "q4"))
    e("%s = %s;" % (R(1, 0), "q5"))
    e("%s = %s;" % (R(0, 2), "q0"))
    e("%s = %s;" % (R(1, 2), "q1"))


def linear(g):
    e("q2 = %s ^ %s;" % (R(g, 0), R(g, 1)))
    e("q2 = q2 ^ %s;" % R(g, 2))
    e("q2 = q2 ^ %s;" % R(g, 3))
    for k in range(4):
        e("%s = %s ^ q2;" % (R(g, k), R(g, k)))

# =========================== 发射 ==========================================
L.append("// Eijen-512 permutation, 4-lane AVX2 —— 由 gen_eijen4.py 生成，请勿手改")
L.append("// 布局：g{g}{k} 的 lane l = 词 16g+4l+k；同组 4 列共享旋转常数。")
for r in range(ROUNDS):
    bcast("RC0_%d" % r, RC0[r])
    bcast("RC1_%d" % r, RC1[r])
# rotl(x, 8k) 的 vpshufb 掩码：每个 64-bit 字内右移 (64-n)/8 字节
for _n in sorted(BYTE_ROT_MASK):
    _d = (64 - _n) // 8
    _idx = [(j + _d) % 8 for j in range(8)]
    _one = _idx + [8 + j for j in _idx]
    # Jasmin 的 (32u8)[...] 是**高字节在前**：列表首元素落在 byte31。
    # 实测探针：mask 写 [31..0] 得到恒等置换。故这里整表反转。
    L.append("u256 ROTM%d = (32u8)[%s];"
             % (_n, ",".join(str(x) for x in reversed(_one * 2))))
# LANE 掩码常量已不再需要：sigma 的两处 lane 交换改用 vpblendd 立即数，
# 省掉 4 个 256 位常量（它们原本每轮都要从内存重载，见 vmovdqu 计数）。
L.append("")
L.append("export")
L.append("fn eijen_p4(reg u64 p) {")
for g in range(2):
    for k in range(4):
        L.append("  reg u256 %s;" % R(g, k))
L.append("  reg u256 q0 q1 q2 q3 q4 q5 q6 q7;")
L.append("")
e("// p 指向已按 (组, 角色) 主序排好的 32 词（转置由 C 外壳做，见 eijen_ref_p4.c）")
for g in range(2):
    for k in range(4):
        e("%s = [:u256 p + %d];" % (R(g, k), 32 * (g * 4 + k)))
L.append("")
for r in range(ROUNDS):
    e("// ---- round %d ----" % r)
    mixquad(0, "RC0_%d" % r, ROT0)
    mixquad(1, "RC1_%d" % r, ROT1)
    sigma()
    linear(0)
    linear(1)
    sigma()
L.append("")
for g in range(2):
    for k in range(4):
        e("[:u256 p + %d] = %s;" % (32 * (g * 4 + k), R(g, k)))
L.append("}")

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "eijen4.jazz")
with open(out, "w", encoding="utf-8", newline="\n") as f:
    f.write("\n".join(L) + "\n")
print("wrote", out, len(L), "lines")
