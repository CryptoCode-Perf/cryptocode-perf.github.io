#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""_build_both.py --- 按「生成器 → jazz → 产物」三段钉死，一次建出 v2 与 v3。

为什么需要这个脚本（真实缺陷）：
`build_eijen2.py` **不生成 jazz**，它只把 `_eij/eijen4.jazz` 交给 `jasminc`。
而 `_eij/eijen4.jazz` 是**共享可变文件**，谁最后跑生成器就由谁决定。
⇒ 如果先跑 v3 生成器再跑 `build_eijen2.py`，`out/`（本该是 v2）里会静默出现 v3 的字节，
   而 `reproduce.sh` 第 3 步的 v2 sha 校验就会假红/假绿，取决于跑的顺序。
这就是 BRIEF §6a「产物与生成器版本绑定」的第 2 次实证（第 1 次是 ZC-1536）。

本脚本的纪律：
1. 每一代都**显式**先跑它自己的生成器，再建，再比 sha，最后**还原共享 jazz 到 v3**。
2. 任一步 sha 不符就 rc=1，不写「差不多对」。
3. 结束时打印两代的 jazz sha 与产物 sha，供报告引用。
"""
import hashlib
import io
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
EIJ = os.path.join(WORK, "_eij")
JAZZ = os.path.join(EIJ, "eijen4.jazz")
GEN_V2 = os.path.join(EIJ, "gen_eijen4_v2.py")
GEN_V3 = os.path.join(EIJ, "gen_eijen4.py")

V2 = {
    256: "ad73c1bdf0c95ec713b001ea0c7802118990ea980c7f2b3acf85500c50e3faf1",
    384: "f57fee27b4b59f98bca290b0afa1792c0ad1265f9ad972785f29c2121125a1d6",
    512: "57995463d2eafa18c8addaa40c56f2ab8a4a40f4007d5544878f1e1132e65d22",
    768: "14a4729a895c9d757b0c3403fb560ee0cded63aa3834920ba373b155e36ddd11",
    1024: "e80925b49790788256bd597e5c0c665673f941550c3887a2db38a415fe29f45e",
}
V3 = {
    256: "7c8ea6880b841912d891bd5b5db616af17e5dc78bd7462443329d51f5f0f3a98",
    384: "62d8ce251d02379e685805e195f60fb5f1b81ad9b3e45763f4fad7bb1b56c3cb",
    512: "420eac1809d93022e405888a3b6c44f967704ab226b2bcade9cc6de0275f7777",
    768: "103a3f25d75f6ca452d0e9d1b1d2503f59520d5e2bbef21a98e698e46a8e07fd",
    1024: "a3803c644d62fbf4a295308bc0c91ee16aceca81e094f0224569d2e67e76c58d",
}
JAZZ_SHA = {
    "v2": "019a83ca59580c2601033a0ef983e654f29a0672c2f77795f0109195ae1cf030",
    "v3": "7e0d47ae16dea3ccf62d43ffa5ce9e82ef9ee612983582ee331746dd37fa2f51",
}


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 16), b""):
            h.update(b)
    return h.hexdigest()


def run_one(tag, gen, outdir, expect):
    print("=" * 70)
    print("[%s] 生成器 %s" % (tag, os.path.basename(gen)))
    r = subprocess.run([sys.executable, gen], stdout=subprocess.DEVNULL,
                       stderr=subprocess.STDOUT)
    if r.returncode != 0:
        print("  FATAL: 生成器 rc=%d" % r.returncode)
        return False
    got_jazz = sha(JAZZ)
    print("  jazz sha256 = %s" % got_jazz)
    if got_jazz != JAZZ_SHA[tag]:
        print("  FATAL: jazz sha 期望 %s" % JAZZ_SHA[tag])
        return False

    env = dict(os.environ, EIJEN2_OUT=outdir)
    log = os.path.join(HERE, "scratch", "build_%s.log" % tag)
    os.makedirs(os.path.dirname(log), exist_ok=True)
    with open(log, "w") as f:
        r = subprocess.run([sys.executable, os.path.join(HERE, "build_eijen2.py"), "build"],
                           stdout=f, stderr=subprocess.STDOUT, env=env)
    if r.returncode != 0:
        print("  FATAL: build rc=%d（日志 %s）" % (r.returncode, log))
        return False

    bad = 0
    for n, want in sorted(expect.items()):
        p = os.path.join(outdir, "ours_eijen2_%d.so" % n)
        if not os.path.exists(p):
            print("  MISSING %s" % p)
            bad += 1
            continue
        got = sha(p)
        if got != want:
            print("  BAD %-5s %s（期望 %s）" % (n, got[:16], want[:16]))
            bad += 1
    print("  %s：%d/%d 逐字节相符" % (tag, len(expect) - bad, len(expect)))
    return bad == 0


def main():
    ok2 = run_one("v2", GEN_V2, os.path.join(HERE, "out"), V2)
    ok3 = run_one("v3", GEN_V3, os.path.join(HERE, "out_blend"), V3)
    # 无论成败，把共享 jazz 还原成 v3（默认开发态）
    subprocess.run([sys.executable, GEN_V3], stdout=subprocess.DEVNULL,
                   stderr=subprocess.STDOUT)
    print("=" * 70)
    print("共享 jazz 已还原为 v3（%s）" % sha(JAZZ)[:16])
    if ok2 and ok3:
        print("BUILD_BOTH: OK")
        return 0
    print("BUILD_BOTH: FAIL (v2=%s v3=%s)" % (ok2, ok3))
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
