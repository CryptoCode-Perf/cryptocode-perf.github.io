#!/usr/bin/env python3
"""build_eijen2.py —— Eijen (hash-09) 5 个负格修复版：状态常驻转置布局。

问题（lead 已定位的权威事实）
--------------------------------
`eijen/build_eijen.py` 生成的 `out/eijen_ref_p4.c` 把官方的 `eijen_permutation`
整个换成「转置入 -> eijen_p4（jasmin 向量核） -> 转置出」：每块只做 **一次** 置换，
却要做 **两次 32 词转置**（2 * 2 * 4 * 4 = 64 次 load/store）。5 个实例的 rate 只有
120/152/184/200/216 字节，转置成本摊不薄 => 权威表里 5 个实例全负（1.06~1.07）。

本版做法
--------
让 `eijen_ctx.state[32]` **从一开始就存转置后的布局**，于是：

  * `eijen_permutation(state)` 变成直接 `eijen_p4(state);`（两次转置全部删掉）；
  * 其它所有按「逻辑下标」访问状态的地方，改成按物理下标访问。

映射（B = 逻辑下标 j 的物理位置）
    p = T(j) = ((j/16)*4 + (j%16)%4)*4 + (j%16)/4
推导自官方转置那两行（本文件用正则替换的正是它们）：
    t[(g*4+k)*4 + l] = state[16g + 4l + k]
    => 逻辑 j = 16g + 4l + k 的值落到物理 p = (g*4+k)*4 + l
    => g = j/16, k = (j%16)%4, l = (j%16)/4
自检（verify_T.py 独立复算，不照抄 lead 的话）：
    T 是 32 元自逆置换：T(T(j)) == j 且 sorted(T) == range(32)
    T(31) == 31（末块置位那一位在两种布局下同址；代码里仍显式写 EIJEN_T(...)）

写域：只写 `eijen2/`。**不覆盖** `eijen/out/*`。
"""
import hashlib
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# HERE = feilian/work/_overnight/l0/eijen2  => 上溯 3 层才是 feilian/work
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
assert os.path.exists(os.path.join(WORK, "ir_text.py")), "WORK 上溯层数不对: " + WORK
REF = os.path.join(WORK, "_overnight", "l0", "src", "hash-09", "Eijen",
                   "Implementations", "Reference_Implementation", "Eijen-1024")
REFBASE = os.path.dirname(REF)
JAZZ = os.path.join(WORK, "_eij", "eijen4.jazz")
OUT = os.environ.get("EIJEN2_OUT") or os.path.join(HERE, "out")
# 产物目录可用环境变量 EIJEN2_OUT 覆盖：v3（sigma blend）落 out_blend/，v2 落 out/。
# 两者字节不同，必须分开存 —— 见 eijen2/RESULT_V3.md 与 BRIEF §6a「产物与生成器版本绑定」。
BITS = (256, 384, 512, 768, 1024)

# 官方十 flag（与对手编译口径逐字一致）
OPT_FLAGS = ("-O3 -march=x86-64 -mavx2 -mtune=native -flto "
             "-fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra")

NEW_PERM = r'''/* ================= eijen2: 状态常驻转置布局 =================
 * 物理下标 p = T(逻辑下标 j)，即 physical[T(j)] == logical[j]：
 *     T(j) = ((j/16)*4 + (j%16)%4)*4 + (j%16)/4
 * T 是 32 元自逆置换（见 verify_T.py 的断言输出）。
 * 状态从 eijen_init 起就一直存放在这个布局里，因此每次置换不再需要
 * 「转置入 + 转置出」这两趟 32 词搬运 —— 这正是本版要删掉的那笔成本。
 * 注意 T(31) == 31（末块置位那一位在两种布局下同址），但下面仍显式写成
 * EIJEN_T(...)，以免将来换布局时漏改。
 * ============================================================ */
#define EIJEN_T(j) (((((j) / 16) * 4 + ((j) % 16) % 4) * 4) + ((j) % 16) / 4)

/* ★ 但变量下标绝不能用上面的宏：j = cap_start + i 是运行期值，C 的 `/` 与 `%`
 * 对**有符号** int 需要 sar + cmovs 修正 —— 实测让 eijen_absorb_block 从 280 条
 * 膨胀到 1026 条（lea:233 sar:138 shr:68 and:70 cmovs:40），每块反而多 967 条。
 * 所以运行期访问一律走这张 32 字节的表（一次 load），常数下标会被折叠成字面量。 */
static const uint8_t eijen_tab[32] = { __EIJEN_TAB__ };

/* ---- 本实例的 rate/capacity 词数在**编译期**固定 ----------------------------
 * `EIJEN_CONFIGS`（官方 eijen_internal.h:9-15）里每个实例是一行常量：
 *     256 -> rate_words 27 / cap 5      384 -> 25 / 7     512 -> 23 / 9
 *     768 -> 19 / 13                    1024 -> 15 / 17
 * 而 eijen_init 只接受本实例自己的 digest_bits（胶水 .c 里是宏常量）。
 * 把这两个数变成编译期常量以后，下面所有 eijen_tab[...] 的下标都是常数，
 * GCC 会**全展开并折叠成字面量偏移** —— T 映射的真实代价就降到 0 条。
 * 若不给这个宏就报错，宁可不编也不要静默退回运行时查表（实测每条多 2 条指令，
 * 17 轮下来比转置本身还贵）。 */
#ifndef EIJEN2_RATE_WORDS
#error "eijen2: 必须在本实例编译时给 -DEIJEN2_RATE_WORDS=<rate_words>"
#endif
#define EIJEN2_CAP_WORDS (EIJEN_STATE_WORDS - EIJEN2_RATE_WORDS)

/* Evaluate the full 16-round Eijen permutation. */
/* ---- 由 build_eijen2.py 替换：直接进 4-lane AVX2 置换核心（_eij/eijen4.jazz）
 * 状态已是向量核要的 (组, 角色) 主序，所以这里不再有任何转置。 ---- */
void eijen_p4(uint64_t *t);

static void eijen_permutation(uint64_t state[EIJEN_STATE_WORDS]) {
    eijen_p4(state);
}
'''


def wsl(p):
    """Windows 路径 -> WSL 路径。"""
    q = p.replace("\\", "/")
    if len(q) > 1 and q[1] == ":":
        return "/mnt/" + q[0].lower() + q[2:]
    return q


def sh(cmd, log=None):
    """运行一条 shell 命令。stdout 走文件句柄（本环境禁 PIPE）。"""
    print("+ " + cmd, flush=True)
    fh = open(log, "a", encoding="utf-8") if log else None
    kw = {}
    if fh is not None:
        kw["stdout"] = fh
        kw["stderr"] = subprocess.STDOUT
    r = subprocess.run(["wsl.exe", "-e", "bash", "-lc", cmd], **kw)
    if fh is not None:
        fh.close()
        with open(log, encoding="utf-8", errors="replace") as f:
            txt = f.read()
        print(txt, flush=True)
        errors = txt.count("error:")
        print("[log error: count = %d]" % errors, flush=True)
    if r.returncode != 0:
        print("!! rc=%d" % r.returncode, flush=True)
        sys.exit(r.returncode)
    return r.returncode


def main():
    os.makedirs(OUT, exist_ok=True)
    src_path = os.path.join(REF, "eijen_ref.c")
    src = open(src_path, encoding="utf-8").read()
    if "EIJEN_T" in src:
        sys.exit("源里已经有 EIJEN_T —— 拒绝继续（宁可停，不要双重改写）")

    pat = re.compile(
        r"/\* Evaluate the full 16-round Eijen permutation\. \*/\s*"
        r"static void eijen_permutation\(uint64_t state\[EIJEN_STATE_WORDS\]\) \{.*?\n\}\n",
        re.S)
    m = pat.search(src)
    if not m:
        sys.exit("eijen_permutation 原文没对上 —— 拒绝继续（宁可停，不要静默错）")
    swapped = src[m.start():m.end()]
    # 官方原文 = 标量 16 轮循环（eijen_columns / eijen_sigma / eijen_linear_layer）。
    # 注意：官方 ref.c 里**没有**转置；那两趟转置是 `eijen/build_eijen.py`
    # 的 NEW_PERM 自己引入的，本版连「引入转置的那一版」一起替换掉。
    if "EIJEN_ROUNDS" not in swapped or "eijen_columns(" not in swapped:
        sys.exit("官方 eijen_permutation 原文不是我预期的标量 16 轮循环 —— 拒绝继续")
    # 证据：旧生成器确实引入了「转置入 + 转置出」
    old_gen = os.path.join(WORK, "_overnight", "l0", "eijen", "build_eijen.py")
    old = open(old_gen, encoding="utf-8").read()
    nd = old.count("state[16 * g + 4 * l + k]") + old.count("= t[(g * 4 + k) * 4 + l]")
    if "uint64_t t[32]" not in old or nd < 2:
        sys.exit("旧生成器 build_eijen.py 里找不到两趟转置 —— 前提变了，拒绝继续")
    print("已确认：旧生成器 %s 在每次置换首尾各做一趟 32 词转置（%d 处）"
          % (old_gen, nd), flush=True)

    # T 表（与 verify_T.py 同一份推导；这里独立再算一遍并断言）
    TAB = [((j // 16) * 4 + (j % 16) % 4) * 4 + (j % 16) // 4 for j in range(32)]
    assert sorted(TAB) == list(range(32)), "T 不是置换"
    assert all(TAB[TAB[j]] == j for j in range(32)), "T 不是自逆"
    tabstr = ", ".join(str(v) for v in TAB)
    NEW_PERM_T = NEW_PERM.replace("__EIJEN_TAB__", tabstr)
    assert "__EIJEN_TAB__" not in NEW_PERM_T

    patched = src[:m.start()] + NEW_PERM_T + src[m.end():]

    # ---- 把 rate/capacity 词数钉成编译期常量（见 NEW_PERM 里的说明）----
    old_decl = ("    int cap_start = ctx->cfg->rate_words;\n"
                "    int cap_words = ctx->cfg->capacity_words;\n")
    if patched.count(old_decl) != 1:
        sys.exit("absorb_block 里 cap_start/cap_words 声明原文没对上 —— 拒绝继续")
    old_bound = "for (i = 0; i < ctx->cfg->rate_words; i++)"
    if patched.count(old_bound) != 1:
        sys.exit("吸收循环的界原文没对上 —— 拒绝继续")
    patched = patched.replace(old_bound, "for (i = 0; i < EIJEN2_RATE_WORDS; i++)")
    # 先改名（含声明行），再把声明行换成 enum 常量；顺序反了会得到 e2_e2_cap_start
    patched = patched.replace("cap_start", "e2_cap_start").replace("cap_words", "e2_cap_words")
    renamed_decl = ("    int e2_cap_start = ctx->cfg->rate_words;\n"
                    "    int e2_cap_words = ctx->cfg->capacity_words;\n")
    if patched.count(renamed_decl) != 1:
        sys.exit("改名后的声明行没对上 —— 拒绝继续")
    patched = patched.replace(renamed_decl,
                              "    enum { e2_cap_start = EIJEN2_RATE_WORDS,\n"
                              "           e2_cap_words = EIJEN2_CAP_WORDS };\n")
    patched = patched.replace("uint64_t saved_cap[17];",
                              "uint64_t saved_cap[EIJEN2_CAP_WORDS];")

    # ---- eijen_init 里加护栏：只服务本实例（rate_words 恒定），否则直接 -1 ----
    old_init = ("    if (cfg == NULL) {\n        return -1;\n    }\n"
                "    memset(ctx, 0, sizeof(*ctx));")
    new_init = ("    if (cfg == NULL) {\n        return -1;\n    }\n"
                "    if (cfg->rate_words != EIJEN2_RATE_WORDS) {\n"
                "        /* eijen2: 本件是按 EIJEN2_RATE_WORDS 特化的；别的实例长度\n"
                "         * 一律拒绝，宁可返回 -1 也不要算错。经 CryptHash / KAT 这条\n"
                "         * 公开路径不可达（胶水 .c 传的就是本实例的 DIGEST_BIT_LENGTH）。 */\n"
                "        return -1;\n    }\n"
                "    memset(ctx, 0, sizeof(*ctx));")
    if patched.count(old_init) != 1:
        sys.exit("eijen_init 原文没对上 —— 拒绝继续")
    patched = patched.replace(old_init, new_init)

    # 所有按逻辑下标访问状态的地方 -> 物理下标
    sites = re.findall(r"ctx->state\[([^\]]+)\]", patched)
    if not sites:
        sys.exit("找不到任何 ctx->state[...] —— 拒绝继续")
    patched2, cnt = re.subn(r"ctx->state\[([^\]]+)\]",
                            r"ctx->state[eijen_tab[\1]]", patched)
    if cnt != len(sites):
        sys.exit("替换数不一致: %d vs %d" % (cnt, len(sites)))

    # 硬断言：转置真的没了、置换体真的只剩一次调用
    if "uint64_t t[32]" in patched2:
        sys.exit("转置临时数组 t[32] 仍在 —— 拒绝继续")
    if patched2.count("eijen_p4(state);") != 1:
        sys.exit("eijen_p4(state); 出现 %d 次（应为 1）" % patched2.count("eijen_p4(state);"))
    if patched2.count("#define EIJEN_T(") != 1:
        sys.exit("EIJEN_T 宏定义不是恰好 1 处")
    if patched2.count("static const uint8_t eijen_tab[32]") != 1:
        sys.exit("eijen_tab 定义不是恰好 1 处")
    if len(re.findall(r"ctx->state\[eijen_tab\[", patched2)) != cnt:
        sys.exit("ctx->state[eijen_tab[...]] 出现次数不对")
    if re.search(r"ctx->state\[(?!eijen_tab\[)", patched2):
        sys.exit("还有没被改写过的 ctx->state[...] —— 拒绝继续")
    if "EIJEN_T(" in re.sub(r"#define EIJEN_T\(.*?\n", "", patched2, flags=re.S):
        # 注释里允许出现 EIJEN_T(...)，但代码里不许（除宏定义外）
        code_only = re.sub(r"/\*.*?\*/", "", patched2, flags=re.S)
        code_only = re.sub(r"//[^\n]*", "", code_only)
        code_only = re.sub(r"#define EIJEN_T\(.*?\n", "", code_only, flags=re.S)
        if "EIJEN_T(" in code_only:
            sys.exit("代码里仍在用 EIJEN_T(...) 宏 —— 拒绝继续")

    out_c = os.path.join(OUT, "eijen2_ref_p4.c")
    open(out_c, "w", encoding="utf-8", newline="\n").write(patched2)
    print("写入 %s（%d -> %d 字节）" % (out_c, len(src), len(patched2)), flush=True)
    print("逻辑下标改写 %d 处：%s" % (cnt, sites), flush=True)

    log = os.path.join(HERE, "build.log")
    if os.path.exists(log):
        os.remove(log)

    # 共享置换核心（jasminc 生成 .s 再汇编）——产物落本目录，不碰共享文件
    sh('cd "%s" && mkdir -p "%s" && jasminc -o "%s" "%s" && '
       'gcc -x assembler -c "%s" -o "%s"'
       % (wsl(WORK), wsl(OUT), wsl(os.path.join(OUT, "eijen4.s")), wsl(JAZZ),
          wsl(os.path.join(OUT, "eijen4.s")), wsl(os.path.join(OUT, "eijen4.o"))),
       log=log)

    # 五个实例的胶水 .c 必须逐字节相同，否则「一份核心五个实例」不成立
    csha = set()
    for bits in BITS:
        p = os.path.join(REFBASE, "Eijen-%d" % bits, "CryptHash_AlgorithmInstance.c")
        csha.add(hashlib.sha256(open(p, "rb").read()).hexdigest())
    if len(csha) != 1:
        sys.exit("各实例的胶水 .c 不再是逐字节相同: %r" % csha)
    print("五个实例胶水 .c sha256 = %s" % csha.pop(), flush=True)

    outs = []
    RATE_WORDS = {256: 27, 384: 25, 512: 23, 768: 19, 1024: 15}   # 官方 EIJEN_CONFIGS
    for bits in BITS:
        inst = os.path.join(REFBASE, "Eijen-%d" % bits)
        so = os.path.join(OUT, "ours_eijen2_%d.so" % bits)
        sh('gcc %s -DEIJEN2_RATE_WORDS=%d -fPIC -shared -I "%s" -o "%s" "%s" "%s" "%s"'
           % (OPT_FLAGS, RATE_WORDS[bits], wsl(inst), wsl(so), wsl(out_c),
              wsl(os.path.join(inst, "CryptHash_AlgorithmInstance.c")),
              wsl(os.path.join(OUT, "eijen4.o"))), log=log)
        outs.append(so)

    sh("sha256sum " + " ".join('"%s"' % wsl(s) for s in outs), log=log)
    sh("stat -c '%n %s bytes' " + " ".join('"%s"' % wsl(s) for s in outs), log=log)
    print("BUILD OK", flush=True)


if __name__ == "__main__":
    main()
