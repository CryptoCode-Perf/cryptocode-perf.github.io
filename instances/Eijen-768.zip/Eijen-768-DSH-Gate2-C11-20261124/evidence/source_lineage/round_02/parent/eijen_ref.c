#include "eijen.h"
#include "eijen_internal.h"

#include <string.h>
#if defined(__AVX2__)
#include <immintrin.h>
#endif

const char *eijen_implementation_name(void) {
    return "Eijen x86 reference C99";
}

/* Look up the fixed parameter set for a supported digest length. */
const eijen_config *eijen_get_config(int digest_bits) {
    return eijen_config_by_bits(digest_bits);
}

/* Return the digest size in bytes, or zero for an unsupported instance. */
size_t eijen_digest_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->digest_bytes;
}

/* Return the absorbing rate in bytes, or zero for an unsupported instance. */
size_t eijen_rate_size(int digest_bits) {
    const eijen_config *cfg = eijen_get_config(digest_bits);
    return cfg == NULL ? 0U : (size_t)cfg->rate_bytes;
}

/*
 * Internal state storage order.
 *
 * With AVX2 the 32 state words are held as eight 256-bit registers, each
 * register packing the four same-position words of four consecutive columns:
 *
 *   R0 = {w0,  w4,  w8,  w12}    R4 = {w16, w20, w24, w28}
 *   R1 = {w1,  w5,  w9,  w13}    R5 = {w17, w21, w25, w29}
 *   R2 = {w2,  w6,  w10, w14}    R6 = {w18, w22, w26, w30}
 *   R3 = {w3,  w7,  w11, w15}    R7 = {w19, w23, w27, w31}
 *
 * state[4*r + l] holds Rr lane l.  EIJEN_NAT_TO_SLOT maps the natural word
 * index (used by absorb, capacity feed-forward and squeeze) to that storage
 * slot.  It is a fixed bijection; no message-dependent indexing is used.
 */
#if defined(__AVX2__)
static const unsigned char EIJEN_NAT_TO_SLOT[EIJEN_STATE_WORDS] = {
     0,  4,  8, 12,   1,  5,  9, 13,   2,  6, 10, 14,   3,  7, 11, 15,
    16, 20, 24, 28,  17, 21, 25, 29,  18, 22, 26, 30,  19, 23, 27, 31
};
#else
static const unsigned char EIJEN_NAT_TO_SLOT[EIJEN_STATE_WORDS] = {
     0,  1,  2,  3,   4,  5,  6,  7,   8,  9, 10, 11,  12, 13, 14, 15,
    16, 17, 18, 19,  20, 21, 22, 23,  24, 25, 26, 27,  28, 29, 30, 31
};
#endif

#if defined(__AVX2__)

/* Fixed immediate 64-bit lane rotation (AVX2 has no vprolq). */
#define EIJEN_ROTL_256(x, n) \
    _mm256_or_si256(_mm256_slli_epi64((x), (n)), \
                    _mm256_srli_epi64((x), 64 - (n)))

/* ARX MixQuad applied lane-parallel to four columns (a,b,c,d = four YMMs). */
#define EIJEN_MIXQUAD_V(a, b, c, d, r0, r1, r2, r3, r4, r5, rcv) do { \
    (a) = _mm256_add_epi64((a), (b)); \
    (d) = _mm256_xor_si256((d), (a)); \
    (d) = EIJEN_ROTL_256((d), (r0)); \
    (a) = _mm256_xor_si256(EIJEN_ROTL_256((a), (r4)), (rcv)); \
    (c) = _mm256_add_epi64((c), (d)); \
    (b) = _mm256_xor_si256((b), (c)); \
    (b) = EIJEN_ROTL_256((b), (r1)); \
    (c) = EIJEN_ROTL_256((c), (r5)); \
    (a) = _mm256_add_epi64((a), (b)); \
    (d) = _mm256_xor_si256((d), (a)); \
    (d) = EIJEN_ROTL_256((d), (r2)); \
    (c) = _mm256_add_epi64((c), (d)); \
    (b) = _mm256_xor_si256((b), (c)); \
    (b) = EIJEN_ROTL_256((b), (r3)); \
} while (0)

/*
 * Word-position permutation sigma in the packed layout.  Derived from the
 * reference cycle decomposition: writing new[i] = old[p[i]],
 *   new R0 = {R6[1],R6[2],R6[3],R2[0]}   new R4 = {R2[1],R2[2],R2[3],R6[0]}
 *   new R1 = R0                         new R5 = R4
 *   new R2 = {R5[3],R1[0],R1[1],R1[2]}   new R6 = {R1[3],R5[0],R5[1],R5[2]}
 *   new R3 = R7                         new R7 = R3
 * All new registers are formed from the old snapshot before any store.
 */
#define EIJEN_SIGMA_V(R0, R1, R2, R3, R4, R5, R6, R7) do { \
    __m256i n0 = _mm256_blend_epi32( \
        _mm256_permute4x64_epi64((R6), _MM_SHUFFLE(0,3,2,1)), \
        _mm256_permute4x64_epi64((R2), _MM_SHUFFLE(0,0,0,0)), 0xC0); \
    __m256i n1 = (R0); \
    __m256i n2 = _mm256_blend_epi32( \
        _mm256_permute4x64_epi64((R1), _MM_SHUFFLE(2,1,0,0)), \
        _mm256_permute4x64_epi64((R5), _MM_SHUFFLE(3,3,3,3)), 0x03); \
    __m256i n3 = (R7); \
    __m256i n4 = _mm256_blend_epi32( \
        _mm256_permute4x64_epi64((R2), _MM_SHUFFLE(0,3,2,1)), \
        _mm256_permute4x64_epi64((R6), _MM_SHUFFLE(0,0,0,0)), 0xC0); \
    __m256i n5 = (R4); \
    __m256i n6 = _mm256_blend_epi32( \
        _mm256_permute4x64_epi64((R5), _MM_SHUFFLE(2,1,0,0)), \
        _mm256_permute4x64_epi64((R1), _MM_SHUFFLE(3,3,3,3)), 0x03); \
    __m256i n7 = (R3); \
    (R0) = n0; (R1) = n1; (R2) = n2; (R3) = n3; \
    (R4) = n4; (R5) = n5; (R6) = n6; (R7) = n7; \
} while (0)

/* Per-column four-word XOR mixing; with packed columns this is lane-wise. */
#define EIJEN_LINEAR_V(a, b, c, d) do { \
    __m256i tv = _mm256_xor_si256((a), (b)); \
    tv = _mm256_xor_si256(tv, (c)); \
    tv = _mm256_xor_si256(tv, (d)); \
    (a) = _mm256_xor_si256((a), tv); \
    (b) = _mm256_xor_si256((b), tv); \
    (c) = _mm256_xor_si256((c), tv); \
    (d) = _mm256_xor_si256((d), tv); \
} while (0)

/* Evaluate the full 16-round Eijen permutation with the entire state live in
 * eight YMM registers; the external state object is touched only twice. */
static void eijen_permutation(uint64_t state[EIJEN_STATE_WORDS]) {
    __m256i r0 = _mm256_loadu_si256((const __m256i *)(state + 0));
    __m256i r1 = _mm256_loadu_si256((const __m256i *)(state + 4));
    __m256i r2 = _mm256_loadu_si256((const __m256i *)(state + 8));
    __m256i r3 = _mm256_loadu_si256((const __m256i *)(state + 12));
    __m256i r4 = _mm256_loadu_si256((const __m256i *)(state + 16));
    __m256i r5 = _mm256_loadu_si256((const __m256i *)(state + 20));
    __m256i r6 = _mm256_loadu_si256((const __m256i *)(state + 24));
    __m256i r7 = _mm256_loadu_si256((const __m256i *)(state + 28));
    int round;

    for (round = 0; round < EIJEN_ROUNDS; round++) {
        __m256i rc0v = _mm256_set1_epi64x((long long)EIJEN_RC0[round]);
        __m256i rc1v = _mm256_set1_epi64x((long long)EIJEN_RC1[round]);
        EIJEN_MIXQUAD_V(r0, r1, r2, r3, 36, 54, 45, 44, 18, 9, rc0v);
        EIJEN_MIXQUAD_V(r4, r5, r6, r7, 56, 46, 54, 34, 19, 51, rc1v);
        EIJEN_SIGMA_V(r0, r1, r2, r3, r4, r5, r6, r7);
        EIJEN_LINEAR_V(r0, r1, r2, r3);
        EIJEN_LINEAR_V(r4, r5, r6, r7);
        EIJEN_SIGMA_V(r0, r1, r2, r3, r4, r5, r6, r7);
    }

    _mm256_storeu_si256((__m256i *)(state + 0), r0);
    _mm256_storeu_si256((__m256i *)(state + 4), r1);
    _mm256_storeu_si256((__m256i *)(state + 8), r2);
    _mm256_storeu_si256((__m256i *)(state + 12), r3);
    _mm256_storeu_si256((__m256i *)(state + 16), r4);
    _mm256_storeu_si256((__m256i *)(state + 20), r5);
    _mm256_storeu_si256((__m256i *)(state + 24), r6);
    _mm256_storeu_si256((__m256i *)(state + 28), r7);
}

#else  /* !__AVX2__ : scalar fallback, identical to the original reference */

static void eijen_mixquad(uint64_t *a, uint64_t *b, uint64_t *c, uint64_t *d,
                          int r0, int r1, int r2, int r3, int r4, int r5,
                          uint64_t rc) {
    *a = *a + *b;
    *d ^= *a;
    *d = eijen_rotl64(*d, (unsigned int)r0);
    *a = eijen_rotl64(*a, (unsigned int)r4) ^ rc;
    *c = *c + *d;
    *b ^= *c;
    *b = eijen_rotl64(*b, (unsigned int)r1);
    *c = eijen_rotl64(*c, (unsigned int)r5);
    *a = *a + *b;
    *d ^= *a;
    *d = eijen_rotl64(*d, (unsigned int)r2);
    *c = *c + *d;
    *b ^= *c;
    *b = eijen_rotl64(*b, (unsigned int)r3);
}

static void eijen_columns(uint64_t s[EIJEN_STATE_WORDS], uint64_t rc0,
                          uint64_t rc1) {
    int i;
    for (i = 0; i < 16; i += 4) {
        eijen_mixquad(&s[i], &s[i + 1], &s[i + 2], &s[i + 3],
                      36, 54, 45, 44, 18, 9, rc0);
    }
    for (i = 16; i < 32; i += 4) {
        eijen_mixquad(&s[i], &s[i + 1], &s[i + 2], &s[i + 3],
                      56, 46, 54, 34, 19, 51, rc1);
    }
}

static void eijen_sigma(uint64_t s[EIJEN_STATE_WORDS]) {
    uint64_t t;
    t = s[0]; s[0] = s[22]; s[22] = s[17]; s[17] = s[16]; s[16] = s[6]; s[6] = s[1]; s[1] = t;
    t = s[2]; s[2] = s[29]; s[29] = s[28]; s[28] = s[18]; s[18] = s[13]; s[13] = s[12]; s[12] = t;
    t = s[3]; s[3] = s[19]; s[19] = t;
    t = s[4]; s[4] = s[26]; s[26] = s[21]; s[21] = s[20]; s[20] = s[10]; s[10] = s[5]; s[5] = t;
    t = s[7]; s[7] = s[23]; s[23] = t;
    t = s[8]; s[8] = s[30]; s[30] = s[25]; s[25] = s[24]; s[24] = s[14]; s[14] = s[9]; s[9] = t;
    t = s[11]; s[11] = s[27]; s[27] = t;
    t = s[15]; s[15] = s[31]; s[31] = t;
}

static void eijen_linear_layer(uint64_t s[EIJEN_STATE_WORDS]) {
    int col;
    for (col = 0; col < 8; col++) {
        int b = col * 4;
        uint64_t x = s[b] ^ s[b + 1] ^ s[b + 2] ^ s[b + 3];
        s[b] ^= x;
        s[b + 1] ^= x;
        s[b + 2] ^= x;
        s[b + 3] ^= x;
    }
}

static void eijen_permutation(uint64_t state[EIJEN_STATE_WORDS]) {
    int r;
    for (r = 0; r < EIJEN_ROUNDS; r++) {
        eijen_columns(state, EIJEN_RC0[r], EIJEN_RC1[r]);
        eijen_sigma(state);
        eijen_linear_layer(state);
        eijen_sigma(state);
    }
}

#endif /* __AVX2__ */

/* Absorb one complete rate block and apply capacity feed-forward. */
static void eijen_absorb_block(eijen_ctx *ctx, const uint8_t *block, int is_last) {
    uint64_t saved_cap[17];
    int i;
    int cap_start = ctx->cfg->rate_words;
    int cap_words = ctx->cfg->capacity_words;

    for (i = 0; i < cap_words; i++) {
        saved_cap[i] = ctx->state[EIJEN_NAT_TO_SLOT[cap_start + i]];
    }
    for (i = 0; i < ctx->cfg->rate_words; i++) {
        ctx->state[EIJEN_NAT_TO_SLOT[i]] ^= eijen_load64_le(block + ((size_t)i * 8U));
    }
    if (is_last) {
        ctx->state[EIJEN_NAT_TO_SLOT[EIJEN_STATE_WORDS - 1]] ^= (UINT64_C(1) << 63);
    }

    eijen_permutation(ctx->state);

    for (i = 0; i < cap_words; i++) {
        ctx->state[EIJEN_NAT_TO_SLOT[cap_start + i]] ^= saved_cap[i];
    }
}

/* Initialize the byte-streaming hash context. */
int eijen_init(eijen_ctx *ctx, int digest_bits) {
    const eijen_config *cfg;
    if (ctx == NULL) {
        return -1;
    }
    cfg = eijen_get_config(digest_bits);
    if (cfg == NULL) {
        return -1;
    }
    memset(ctx, 0, sizeof(*ctx));
    ctx->cfg = cfg;
    return 0;
}

/* Absorb a byte-aligned fragment into the streaming hash context. */
int eijen_update(eijen_ctx *ctx, const uint8_t *data, size_t len) {
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || (data == NULL && len != 0U)) {
        return -1;
    }
    rb = (size_t)ctx->cfg->rate_bytes;
    while (len > 0U) {
        size_t space = rb - ctx->buf_len;
        size_t take = len < space ? len : space;
        if (ctx->buf_len == 0U && len > rb) {
            eijen_absorb_block(ctx, data, 0);
            data += rb;
            len -= rb;
            continue;
        }
        memcpy(ctx->buf + ctx->buf_len, data, take);
        ctx->buf_len += take;
        data += take;
        len -= take;
        if (ctx->buf_len == rb && len > 0U) {
            eijen_absorb_block(ctx, ctx->buf, 0);
            ctx->buf_len = 0U;
        }
    }
    return 0;
}

/* Finalize the context, optionally including a partial MSB-first final byte. */
static int eijen_final_partial(eijen_ctx *ctx, uint8_t partial_byte,
                               unsigned int partial_bits, uint8_t *digest) {
    int i;
    int ds;
    size_t rb;
    if (ctx == NULL || ctx->cfg == NULL || digest == NULL || partial_bits > 7U) {
        return -1;
    }
    rb = (size_t)ctx->cfg->rate_bytes;
    if (ctx->buf_len == rb) {
        eijen_absorb_block(ctx, ctx->buf, 0);
        ctx->buf_len = 0U;
    }
    if (partial_bits == 0U) {
        ctx->buf[ctx->buf_len] = 0x01U;
    } else {
        uint8_t keep = (uint8_t)(0xffU << (8U - partial_bits));
        uint8_t pad = (uint8_t)(0x80U >> partial_bits);
        ctx->buf[ctx->buf_len] = (uint8_t)((partial_byte & keep) | pad);
    }
    ctx->buf_len++;
    memset(ctx->buf + ctx->buf_len, 0, rb - ctx->buf_len);
    eijen_absorb_block(ctx, ctx->buf, 1);

    ds = EIJEN_STATE_WORDS - ctx->cfg->digest_words;
    for (i = 0; i < ctx->cfg->digest_words; i++) {
        eijen_store64_le(digest + ((size_t)i * 8U),
                         ctx->state[EIJEN_NAT_TO_SLOT[ds + i]]);
    }
    return 0;
}

/* Finalize a byte-aligned message. */
int eijen_final(eijen_ctx *ctx, uint8_t *digest) {
    return eijen_final_partial(ctx, 0U, 0U, digest);
}

/* Hash a byte-aligned message in one call. */
int eijen_hash(int digest_bits, const uint8_t *msg, size_t len, uint8_t *digest) {
    eijen_ctx ctx;
    if (eijen_init(&ctx, digest_bits) != 0) {
        return -1;
    }
    if (eijen_update(&ctx, msg, len) != 0) {
        return -1;
    }
    return eijen_final(&ctx, digest);
}

/* Hash a bit-length message using the API_CryptHash partial-byte convention. */
int eijen_hash_bits(int digest_bits, const uint8_t *msg,
                    unsigned long long msg_len_bits, uint8_t *digest) {
    eijen_ctx ctx;
    unsigned long long full_bytes = msg_len_bits / 8ULL;
    unsigned int partial_bits = (unsigned int)(msg_len_bits & 7ULL);
    uint8_t partial_byte = 0U;

    if ((msg == NULL && msg_len_bits != 0ULL) || digest == NULL) {
        return -1;
    }
    if (full_bytes > (unsigned long long)((size_t)-1)) {
        return -1;
    }
    if (eijen_init(&ctx, digest_bits) != 0) {
        return -1;
    }
    if (eijen_update(&ctx, msg, (size_t)full_bytes) != 0) {
        return -1;
    }
    if (partial_bits != 0U) {
        partial_byte = msg[full_bytes];
    }
    return eijen_final_partial(&ctx, partial_byte, partial_bits, digest);
}
