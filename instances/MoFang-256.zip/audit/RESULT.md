# MoFang — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| MoFang-1024 | `MoFang-1024.so` | 35376 B | `0576cf6525bfc8b9a8074f07b4ce75de800c2613b8c8ffcb71e4b7581b9114d4` |
| MoFang-256 | `MoFang-256.so` | 15528 B | `5e7a0ac4ca2bf1b7ff2df0210ec250ea3beb24f1fdff103b5cb30e94321bb570` |
| MoFang-256-XOF | `MoFang-256-XOF.so` | 15528 B | `7fc2d51ac6b834bbe58f4220b050c594c0f3b4cf050b12ebb0aff7f14916a5d2` |
| MoFang-512 | `MoFang-512.so` | 15528 B | `3b5e5a69703c2758a1f5b1f8a18b823548a3ead3011f9109f727742028b8318a` |
| MoFang-768 | `MoFang-768.so` | 35376 B | `6c2a349fd93037885d93601c7366f6a16b0af98817a8a74a423db7dcf65b48ad` |
| MoFang-768-XOF | `MoFang-768-XOF.so` | 35376 B | `ba39b63b533a1ba4742311412171b948db4fb7f873b4095c6b3ae7946269a7e9` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| MoFang-1024 | 1024 | 20.4688 | 9.0975 | 4.762541 | 1.91022 | 1.9117 |
| MoFang-256 | 256 | 10.4004 | 6.8936 | 2.522368 | 2.732987 | 2.8069 |
| MoFang-256-XOF | 256 | 9.3037 | 6.4922 | 2.123599 | 3.057169 | 2.9943 |
| MoFang-512 | 512 | 10.9619 | 7.2321 | 2.671538 | 2.707093 | 2.8119 |
| MoFang-768 | 768 | 20.6035 | 9.1508 | 4.757501 | 1.923447 | 1.9321 |
| MoFang-768-XOF | 768 | 17.1396 | 7.9693 | 4.2666 | 1.8678 | 1.8308 |

## 优化方法（逐实例原文，来自交付清单）

### MoFang-1024
2-lane u256 引擎（`_overnight/l0/mofang/glue_mofang1024_v3b.c` + `mofang_keys_v3`/`mofang_state_v3`）`_std/out/so/MoFang-1024.so` ★官方 `Optimized_Implementation/MoFang-1024/CryptHash_AlgorithmInstance.c` 本身就是 `__m128i` 实现（`:56 ct[24]`、`:64 rotl128`、`:72 Sbox`、`:105 mul_row`、`:149 MessageExpansion2`、`:193 encrypt2`），不是标量 C，所以这一例比的是**数据布局与去重**而不是「向量化 vs 标量」：官方 `:209 MoFang_BC_2_DBL` 把 `state[3][3]`/`k[3][3][3]`/`out[3][3]` 全放在栈上（机器码 `vmovdqa` 149 条、`vmovddup` 36 条），且它的两个 run（`run1 -> out_g`、`run2 -> out_h`）k0/k1/k2 逐字相同、只差 `state[2][2]` 的 1 个 bit，却各自完整跑一遍密钥扩展与 16 轮；本件把两个 run 合并成一条 2-lane u256 链（lane0/lane1 各承载一条，`sin[4*n] = in_g[i][j] ^ (uint64_t)(n == 8)`、`out_h[i][j] = sout[4*n] ^ (uint64_t)(n == 8)`），**密钥扩展整块只算 1 遍**，全程留在 ymm 寄存器（`vpermq` 162、`vpblendd` 153、`vpsrlvq`/`vpsllvq` 各 144，无 spill）；v3b 另把官方 `hash_MDPH` 的逐字节循环换成等价 64 位访问（那个循环是**小端**读，不是大端，加 `bswap` 会全错），`hash_MDPH` 静态 390 → 164 条。`hash_MDPH` 其余部分与官方参考逐字等价、无 memo、无缓存 ⇒ 快的是布局与去重，不是少算。等价性：A1 `kat_gate` 全量（4097 条）ours/ref/opt 三方各 4097/4097；A2 `delivery_gate.py` 11 个位长（0/8/128/512/1000/1024/2048/4096/8192/16384/65536 bits）全部「候选写 128B、参考写 128B、rc=0/0、一致」；A3 时间两遍独立复现：gm 0.5183（快 48.17%，地板 0.07%）与 gm 0.5176（快 48.24%，地板 0.08%），两遍相差 0.07 个百分点、digest 全同 ⇒ 本项目至今最大单例。构建：`_overnight/l0/mofang/build_mofang_v3.py` + `accept2.sh`（重建 sha256 与首建一致）。

### MoFang-256
**胜因 = 官方 `hash_MDP` 的驱动层四病，不是置换核**。官方 Optimized 实现（`Optimized_Implementation/MoFang-256/CryptHash_AlgorithmInstance.c`）把整条消息先 `malloc` 一块 1152 位对齐的缓冲、`memset` 全零、`memcpy` 整条消息进去；每块再 `memset(K, 0, sizeof(K))` 清 144 B；再用三层循环 + `<<= 8` / `|=` **逐字节**把该块 144 B 打包成 `K[2][3][3]`（运行期每块 144 次，折算 800–1200 条动态指令）；摘要也是逐字节移位写出。这段代码静态只有约 6 条指令，静态计数完全看不出来 —— **我方与官方 opt.so 的核条数完全相同**（`MoFang_BC_1` 326 / `MoFang_BC_1_DM` 46），只有 `hash_MDP` 从 337 条降到 138 条。我方只改驱动层：前 `blocks-1` 块直接从 `input + t*144` 读（`blocks = ceil((L+1152)/1152)` 保证这些块被 `full_bytes` 完整覆盖），`K` 用 18 次未对齐 64 位读装入，末块用 `last[144]` 栈缓冲做位级填充，摘要用 8 次小端 64 位写；`MoFang_BC_1` / `MoFang_BC_1_DM` / `MUL` / `MixColumns` / 全部静态表逐字保留。脚本 `mofang/build_mofang_drv.py`。本档与 512 档逐字同构，只差 `state[2][2] = 5` 与摘要 4 个 64 位字（32 B）。gm 0.3563 ⇒ 快 64.37%（A/A 地板 0.24%、spread 2.74%）。全量 KAT 4097/4097 通过（`MAX_RECORDS=1e9`，ref/opt/ours 三侧）；计时为 captain 串行 `_ab_pair.py --reps 7 --pairs 80`，`digest 全同=True`、`credible=True`。

### MoFang-256-XOF
**胜因 = 官方 `hash_MDP` 的驱动层四病，不是置换核**。官方 Optimized 实现（`Optimized_Implementation/MoFang-256-XOF/CryptHash_AlgorithmInstance.c`）把整条消息先 `malloc` 一块 1152 位对齐的缓冲、`memset` 全零、`memcpy` 整条消息进去；每块再 `memset(K, 0, sizeof(K))` 清 144 B；再用三层循环 + `<<= 8` / `|=` **逐字节**把该块 144 B 打包成 `K[2][3][3]`（运行期每块 144 次，折算 800–1200 条动态指令）；摘要也是逐字节移位写出。这段代码静态只有约 6 条指令，静态计数完全看不出来 —— **我方与官方 opt.so 的核条数完全相同**（`MoFang_BC_1` 326 / `MoFang_BC_1_DM` 46），只有 `hash_MDP` 从 337 条降到 138 条。我方只改驱动层：前 `blocks-1` 块直接从 `input + t*144` 读（`blocks = ceil((L+1152)/1152)` 保证这些块被 `full_bytes` 完整覆盖），`K` 用 18 次未对齐 64 位读装入，末块用 `last[144]` 栈缓冲做位级填充，摘要用 8 次小端 64 位写；`MoFang_BC_1` / `MoFang_BC_1_DM` / `MUL` / `MixColumns` / 全部静态表逐字保留。脚本 `mofang/build_mofang_drv.py`。本档 `state[2][2] = 7`，挤出段是 XOF：`output_blocks = (output_len_bits + 255) / 256`，块间 `state[2][2] ^= 1` 再跑一轮 `MoFang_BC_1_DM`，末字节按 `output_len_bits % 8` 掩码。我方顺带把「逐字节取 `state[j/8/3][(j/8)%3] >> (8*(j%8))`」换成 4 次小端 64 位写。gm 0.3340 ⇒ 快 66.60%（A/A 地板 0.27%；spread 23.85% 偏大但三次 gm 全落在同一侧）。全量 KAT 4097/4097 通过（`MAX_RECORDS=1e9`，ref/opt/ours 三侧）；计时为 captain 串行 `_ab_pair.py --reps 7 --pairs 80`，`digest 全同=True`、`credible=True`。

### MoFang-512
**胜因 = 官方 `hash_MDP` 的驱动层四病，不是置换核**。官方 Optimized 实现（`Optimized_Implementation/MoFang-512/CryptHash_AlgorithmInstance.c`）把整条消息先 `malloc` 一块 1152 位对齐的缓冲、`memset` 全零、`memcpy` 整条消息进去；每块再 `memset(K, 0, sizeof(K))` 清 144 B；再用三层循环 + `<<= 8` / `|=` **逐字节**把该块 144 B 打包成 `K[2][3][3]`（运行期每块 144 次，折算 800–1200 条动态指令）；摘要也是逐字节移位写出。这段代码静态只有约 6 条指令，静态计数完全看不出来 —— **我方与官方 opt.so 的核条数完全相同**（`MoFang_BC_1` 326 / `MoFang_BC_1_DM` 46），只有 `hash_MDP` 从 337 条降到 138 条。我方只改驱动层：前 `blocks-1` 块直接从 `input + t*144` 读（`blocks = ceil((L+1152)/1152)` 保证这些块被 `full_bytes` 完整覆盖），`K` 用 18 次未对齐 64 位读装入，末块用 `last[144]` 栈缓冲做位级填充，摘要用 8 次小端 64 位写；`MoFang_BC_1` / `MoFang_BC_1_DM` / `MUL` / `MixColumns` / 全部静态表逐字保留。脚本 `mofang/build_mofang_drv.py`。本档参数：`state[2][2] = 6`、摘要 8 个 64 位字（64 B）、速率 1152 位 = 144 B。实测 `hash_MDP` 337 → 138 条，gm 0.3556 ⇒ 快 64.44%（A/A 地板 0.26%、spread 4.11%）。全量 KAT 4097/4097 通过（`MAX_RECORDS=1e9`，ref/opt/ours 三侧）；计时为 captain 串行 `_ab_pair.py --reps 7 --pairs 80`，`digest 全同=True`、`credible=True`。

### MoFang-768
与 MoFang-1024（第 33 例）**共用同一颗核心**：`diff` 官方参考实现两档的 `CryptHash_AlgorithmInstance.c` 只有 5 行差异（其中 2 行是行尾空格），真正影响语义的只有三处 —— `in_g[2][2] = 10`（1024 档是 11）、摘要第一段写 6 个字（1024 档 8 个）、`out_h` 从第 48 字节接着写（1024 档 64）。`encrypt2` / `MoFang_BC_2_DBL` / `hash_MDPH` 其余部分逐字相同 ⇒ `mofang_keys_v3.o` + `mofang_state_v3.o` 原样复用，只由 `mofang/build_mofang768.py` 派生 glue 的三处常量（每处断言命中 1 次）。**胜因同 1024 档**：官方参考把「同密钥、同初始状态、只差 1 bit」的两个分支跑两遍、密钥扩展因此算 32 遍；本件把两遍压成一条 2-lane u256 链、密钥扩展只算 16 遍。全部 4097 条 KAT 通过（`MAX_RECORDS=1e9`），`delivery_gate.py` 11 个位长全过；计时为 captain 串行 `_ab_pair.py --reps 7 --pairs 80`，`digest 全同=True`。

### MoFang-768-XOF
`mofang/glue_mofang768xof_v3b.c` 由 `build_mofang768xof.py` 从 768 档 glue `glue_mofang768_v3b.c` 派生（三处替换，每处断言命中 1 次）：域分离常量 `in_g[2][2]` 10→15；去掉 `(void)output_len_bits;`；摘要写出段整段换成官方 `MoFang-768-XOF` 的 XOF 挤出段（`output_blocks = (output_len_bits + 767) / 768`，块间 `in_h[2][2] ^= 2` 再跑一次 `MoFang_BC_2_DBL`，每块写 96 B，末字节按 `0xFF << (8 - output_len_bits % 8)` 掩码）。核心 `mofang_keys_v3.o` / `mofang_state_v3.o` 与 MoFang-1024 档完全同一份 —— 官方 768 与 768-XOF 的 `encrypt2` / `MoFang_BC_2_DBL` / `hash_MDPH` 其余部分逐字相同，所以本档既没有新写核、也没有重生成 JIR。编译走官方十 flag、forbidden=0。等价性：官方 KAT `KAT_2_12_MoFang_768_XOF.txt` 全量 4097 条 ours 实测 match=4097（first_bad=None、err=None），ref/opt 同样 4097/4097。
