# MoFang — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## MoFang-1024
- 摘要位：1024；实现形态：SSE C
- 官方参考源码：随包 `Reference_Implementation/MoFang-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MoFang-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MoFang-1024/`
- 优化要点：2-lane u256 引擎（`_overnight/l0/mofang/glue_mofang1024_v3b.c` + `mofang_keys_v3`/`mofang_state_v3`）`_std/out/so/MoFang-1024.so` ★官方 `Optimized_Implementation/MoFang-1024/CryptHash_AlgorithmInstance.c` 本身就是 `__m128i` 实现（`:56 ct[24]`、`:64 rotl128`、`:72 Sbox`、`:105 mul_row`、`:149 MessageExpansion2`、`:193 encrypt2`），不是标量 C，所以这一例比的是**数据布局与去重**而不是「向量化 vs 标量」：官方 `:209 MoFang_BC_2_DBL` 把 `state[3][3]`/`k[3]

## MoFang-256
- 摘要位：256；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/MoFang-256/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MoFang-256/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MoFang-256/`
- 优化要点：**胜因 = 官方 `hash_MDP` 的驱动层四病，不是置换核**。官方 Optimized 实现（`Optimized_Implementation/MoFang-256/CryptHash_AlgorithmInstance.c`）把整条消息先 `malloc` 一块 1152 位对齐的缓冲、`memset` 全零、`memcpy` 整条消息进去；每块再 `memset(K, 0, sizeof(K))` 清 144 B；再用三层循环 + `<<= 8` / `|=` **逐字节**把该块 144 B 打包成 `K[2][3][3]`（运行期每块 144 次，折算 800–1200 条动态指令）；摘要也是逐字节移位写出。这段代码静态只有约 6 条指令，静态计数完全看不出来 —— **我方与官方 opt.so 的核条数完全相同**（`MoFang_BC_1` 326 / `MoFan

## MoFang-256-XOF
- 摘要位：256；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/MoFang-256-XOF/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MoFang-256-XOF/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MoFang-256-XOF/`
- 优化要点：**胜因 = 官方 `hash_MDP` 的驱动层四病，不是置换核**。官方 Optimized 实现（`Optimized_Implementation/MoFang-256-XOF/CryptHash_AlgorithmInstance.c`）把整条消息先 `malloc` 一块 1152 位对齐的缓冲、`memset` 全零、`memcpy` 整条消息进去；每块再 `memset(K, 0, sizeof(K))` 清 144 B；再用三层循环 + `<<= 8` / `|=` **逐字节**把该块 144 B 打包成 `K[2][3][3]`（运行期每块 144 次，折算 800–1200 条动态指令）；摘要也是逐字节移位写出。这段代码静态只有约 6 条指令，静态计数完全看不出来 —— **我方与官方 opt.so 的核条数完全相同**（`MoFang_BC_1` 326 / `M

## MoFang-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/MoFang-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MoFang-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MoFang-512/`
- 优化要点：**胜因 = 官方 `hash_MDP` 的驱动层四病，不是置换核**。官方 Optimized 实现（`Optimized_Implementation/MoFang-512/CryptHash_AlgorithmInstance.c`）把整条消息先 `malloc` 一块 1152 位对齐的缓冲、`memset` 全零、`memcpy` 整条消息进去；每块再 `memset(K, 0, sizeof(K))` 清 144 B；再用三层循环 + `<<= 8` / `|=` **逐字节**把该块 144 B 打包成 `K[2][3][3]`（运行期每块 144 次，折算 800–1200 条动态指令）；摘要也是逐字节移位写出。这段代码静态只有约 6 条指令，静态计数完全看不出来 —— **我方与官方 opt.so 的核条数完全相同**（`MoFang_BC_1` 326 / `MoFan

## MoFang-768
- 摘要位：768；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/MoFang-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MoFang-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MoFang-768/`
- 优化要点：与 MoFang-1024（第 33 例）**共用同一颗核心**：`diff` 官方参考实现两档的 `CryptHash_AlgorithmInstance.c` 只有 5 行差异（其中 2 行是行尾空格），真正影响语义的只有三处 —— `in_g[2][2] = 10`（1024 档是 11）、摘要第一段写 6 个字（1024 档 8 个）、`out_h` 从第 48 字节接着写（1024 档 64）。`encrypt2` / `MoFang_BC_2_DBL` / `hash_MDPH` 其余部分逐字相同 ⇒ `mofang_keys_v3.o` + `mofang_state_v3.o` 原样复用，只由 `mofang/build_mofang768.py` 派生 glue 的三处常量（每处断言命中 1 次）。**胜因同 1024 档**：官方参考把「同密钥、同初始状态、只差 1 b

## MoFang-768-XOF
- 摘要位：768；实现形态：标量 C（核心复用 1024 档）
- 官方参考源码：随包 `Reference_Implementation/MoFang-768-XOF/`
- 官方优化源码：随包 `Official_Optimized_Implementation/MoFang-768-XOF/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/MoFang-768-XOF/`
- 优化要点：`mofang/glue_mofang768xof_v3b.c` 由 `build_mofang768xof.py` 从 768 档 glue `glue_mofang768_v3b.c` 派生（三处替换，每处断言命中 1 次）：域分离常量 `in_g[2][2]` 10→15；去掉 `(void)output_len_bits;`；摘要写出段整段换成官方 `MoFang-768-XOF` 的 XOF 挤出段（`output_blocks = (output_len_bits + 767) / 768`，块间 `in_h[2][2] ^= 2` 再跑一次 `MoFang_BC_2_DBL`，每块写 96 B，末字节按 `0xFF << (8 - output_len_bits % 8)` 掩码）。核心 `mofang_keys_v3.o` / `mofang_state_v3.o` 与 M
