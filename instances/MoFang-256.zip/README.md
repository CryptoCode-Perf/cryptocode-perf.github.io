# MoFang-256

Algorithm: MoFang | Digest bits: 256 | Form: AVX2 C

Contents: implementation source/, public header MoFang-256.h, prebuilt MoFang-256.so,
KAT vector KAT_2_12_MoFang_256.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 5e7a0ac4ca2bf1b7ff2df0210ec250ea3beb24f1fdff103b5cb30e94321bb570
Speed (cpB, lower is faster): reference 10.40 / official-optimized 6.89 / optimized 2.52
Speedup: GM(S1-S8) 2.81x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
