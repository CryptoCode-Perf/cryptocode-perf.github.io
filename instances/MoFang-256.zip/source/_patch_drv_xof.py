#!/usr/bin/env python3
"""给 mofang/build_mofang_drv.py 加 XOF 支持（只加 256-XOF 一档：768-XOF 是 SIMD 版驱动，形状不同）。
执行一次即可，幂等。"""
import io, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(HERE, "build_mofang_drv.py")
s = io.open(P, encoding="utf-8").read()
orig = s

# 1) TIERS 加 256xof
old = "TIERS = {256: (5, 4), 512: (6, 8)}"
new = ('TIERS = {256: (5, 4), 512: (6, 8),\n'
       '         "256xof": (7, 4)}   # 256-XOF：IV 7、摘要 256 位、按 XOF 长度挤出\n'
       'XOF_TIERS = {"256xof"}')
if s.count(old) == 1:
    s = s.replace(old, new)
elif s.count(new.split("\n")[0]) != 1:
    sys.exit("FAIL TIERS")

# 2) 摘要循环换成占位符 @SQUEEZE@
old_dig = '''    /* 摘要：小端 64 位写，等价官方逐字节移位写出 */
    for (int i = 0; i < @DW@; i++) {
        mdp_st64le(output + (unsigned)i * 8u, state[i / 3][i % 3]);
    }
    return 0;
}'''
new_dig = '''@SQUEEZE@
    return 0;
}'''
if s.count(old_dig) == 1:
    s = s.replace(old_dig, new_dig)
elif "@SQUEEZE@" not in s:
    sys.exit("FAIL digest-loop")

# 3) 插入两段挤出实现（放在 DRIVER 之后的常量区）
anchor = "'''\n\n\ndef paths(bits):"
if s.count(anchor) != 1:
    sys.exit("FAIL anchor")
insert = """'''

SQUEEZE_DIGEST = '''    /* 摘要：小端 64 位写，等价官方逐字节移位写出 */
    for (int i = 0; i < @DW@; i++) {
        mdp_st64le(output + (unsigned)i * 8u, state[i / 3][i % 3]);
    }'''

SQUEEZE_XOF = '''    /* XOF 挤出：每块 32 B = state 前 4 个字的低端字节；块间 state[2][2] ^= 1 再跑一轮 */
    {
        int output_blocks = (output_len_bits + 255) / 256;
        int output_len_bytes = (output_len_bits + 7) / 8;
        for (int i = 0; i < output_blocks; i++) {
            if (i != 0) {
                state[2][2] ^= 1;
                MoFang_BC_1_DM(state, K, ROUND);
            }
            int base = i * 32;
            int avail = output_len_bytes - base;
            if (avail > 32) avail = 32;
            if (avail == 32 && (output_len_bits % 8) == 0) {
                for (int w = 0; w < 4; w++) {
                    mdp_st64le(output + (unsigned)base + (unsigned)w * 8u,
                               state[w / 3][w % 3]);
                }
            } else {
                for (int j = 0; j < avail; j++) {
                    unsigned char ss = (unsigned char)
                        ((state[(j / 8) / 3][(j / 8) % 3] >> (8 * (j % 8))) & 0xFFu);
                    if (base + j == output_len_bytes - 1) {
                        int rb = output_len_bits % 8;
                        if (rb == 0) rb = 8;
                        ss = (unsigned char)(ss & (unsigned char)(0xFFu << (8 - rb)));
                    }
                    output[base + j] = ss;
                }
            }
        }
    }'''
"""
s = s.replace(anchor, insert + "\n\ndef paths(bits):", 1)

# 4) paths 支持字符串档位
old_paths = '''def paths(bits):
    inst = "MoFang-%d" % bits'''
new_paths = '''def paths(bits):
    if isinstance(bits, str):
        inst = "MoFang-%s-%s" % (bits.split("x")[0], "XOF")
        tag = str(bits)
    else:
        inst = "MoFang-%d" % bits
        tag = str(bits)'''
if s.count(old_paths) == 1:
    s = s.replace(old_paths, new_paths)
else:
    sys.exit("FAIL paths")

s = s.replace('''        "glue": os.path.join(HERE, "glue_mofang%ddrv.c" % bits),
        "so": os.path.join(OUTDIR, "ours_mofang%ddrv.so" % bits),
        "builddir": os.path.join(L0, "build", "hash-19", "mofang%d" % bits),''',
'''        "glue": os.path.join(HERE, "glue_mofang%sdrv.c" % tag),
        "so": os.path.join(OUTDIR, "ours_mofang%sdrv.so" % tag),
        "builddir": os.path.join(L0, "build", "hash-19", "mofang%s" % tag),''')

# 5) make_glue 里选挤出段
old_mg = '''    drv = DRIVER.replace("@IV@", str(iv)).replace("@DW@", str(dw))'''
new_mg = '''    sq = SQUEEZE_XOF if P["bits"] in XOF_TIERS else SQUEEZE_DIGEST
    drv = (DRIVER.replace("@IV@", str(iv)).replace("@DW@", str(dw))
                 .replace("@SQUEEZE@", sq.replace("@DW@", str(dw))))
    if P["bits"] in XOF_TIERS:
        drv = drv.replace("    (void)output_len_bits;\\n", "")'''
if s.count(old_mg) == 1:
    s = s.replace(old_mg, new_mg)
else:
    sys.exit("FAIL make_glue")

# 6) main 的档位检查放宽
s = s.replace('if bits not in TIERS:', 'if bits not in TIERS and bits not in XOF_TIERS:')

io.open(P, "w", encoding="utf-8", newline="\n").write(s)
print("patched %d -> %d bytes" % (len(orig), len(s)))
print("SQUEEZE_XOF 出现 %d 次 / @SQUEEZE@ 出现 %d 次" % (s.count("SQUEEZE_XOF"), s.count("@SQUEEZE@")))
