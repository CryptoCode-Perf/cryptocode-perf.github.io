#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mofang/build_mofang_drv.py -- MoFang 驱动层改写件（256 / 512 两档通用）。

只替换官方 Optimized_Implementation/MoFang-<bits> 里的 hash_MDP（驱动层），
核函数 MoFang_BC_1 / MoFang_BC_1_DM / MixColumns / MUL / rotl 与全部静态表逐字保留。

修的四个驱动层毛病（都在官方 hash_MDP 里）：
  1) 每次调用 malloc(padded_bytes) + memset + memcpy 整条消息到堆缓冲；
  2) 每块 memset(K, 0, sizeof(K)) 清 144 B 密钥状态（随后又被全部覆盖）；
  3) 每块用 144 次「<<8 / |」逐字节打包 K[2][3][3]（3 层嵌套循环，运行期真跑 144 轮）；
  4) 摘要用 64 次逐字节移位写出。
改法：满块直接从 input 读（18 次未对齐 64 位读即完成打包），
      只有最后一块用 144 B 栈缓冲做位级填充，摘要 8/4 次 64 位写。

用法：
  python3 build_mofang_drv.py 512 glue|build|asm|kat
  python3 build_mofang_drv.py 256 build
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)

RELD = os.path.join(L0, "src", "hash-19", "MoFang", "Implementations")
OUTDIR = os.path.join(HERE, "out")

# bits -> (state[2][2] 初值, 摘要 64 位字数)
TIERS = {256: (5, 4), 512: (6, 8),
         "256xof": (7, 4)}   # 256-XOF：IV 7、摘要 256 位、按 XOF 长度挤出
XOF_TIERS = {"256xof"}

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

DRIVER = r'''
/* ------------------------------------------------------------------
 * 驱动层（我方改写）。语义与官方 hash_MDP 逐字等价：
 *   padded_input_len_bits = ((input_len_bits + 1152) / 1152) * 1152
 *   10* padding（先补一个 '1' 位，再补 0 到块边界），末块 state[2][2] ^= 1
 *   每块 K[2][3][3] 由该块 144 字节按小端整数装入
 *   摘要 = state[i/3][i%3] 的小端字节，i = 0..@DW@-1
 * 改动只在这里：不再 malloc/memset/memcpy 整条消息、不再逐字节打包、不再逐字节写摘要。
 * ------------------------------------------------------------------ */
#define MDP_RATE_BYTES    144u   /* 1152 位 */
#define MDP_RATE_BITS    1152u

static inline ULL mdp_ld64le(const unsigned char *p) {
    ULL x;
    memcpy(&x, p, sizeof(x));
    return x;
}

static inline void mdp_st64le(unsigned char *p, ULL x) {
    memcpy(p, &x, sizeof(x));
}

/* 把 144 B 消息块打成 K[2][3][3]（小端整数，等价官方逐字节 <<8/| 循环） */
static inline void mdp_pack_key(ULL K[2][3][3], const unsigned char *blk) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            K[0][i][j] = mdp_ld64le(blk + (unsigned)(i * 3 + j) * 8u);
            K[1][i][j] = mdp_ld64le(blk + 72u + (unsigned)(i * 3 + j) * 8u);
        }
    }
}

int hash_MDP(int output_len_bits, const unsigned char *input,
             ULL input_len_bits, unsigned char *output) {
    (void)output_len_bits;

    ULL padded_input_len_bits = ((input_len_bits + MDP_RATE_BITS) / MDP_RATE_BITS) * MDP_RATE_BITS;
    ULL full_bytes = input_len_bits / 8u;
    int remaining_bits = (int)(input_len_bits % 8u);
    ULL blocks = padded_input_len_bits / MDP_RATE_BITS;

    ULL state[3][3] = {{0}};
    ULL K[2][3][3];
    state[2][2] = @IV@;

    /* 前面 blocks-1 块全是完整消息块：直接从 input 读，不做任何拷贝 */
    for (ULL t = 0; t + 1u < blocks; t++) {
        mdp_pack_key(K, input + t * MDP_RATE_BYTES);
        MoFang_BC_1_DM(state, K, ROUND);
    }

    /* 最后一块含填充：栈缓冲 144 B */
    {
        unsigned char last[MDP_RATE_BYTES] = {0};
        ULL t = blocks - 1u;
        ULL off = t * MDP_RATE_BYTES;
        ULL rem = full_bytes - off;              /* 0 .. 143 */
        if (rem > 0u) {
            memcpy(last, input + off, (size_t)rem);
        }
        if (remaining_bits > 0) {
            unsigned char mask = (unsigned char)(0xFFu << (8 - remaining_bits));
            last[rem] = (unsigned char)(input[full_bytes] & mask);
            last[rem] = (unsigned char)(last[rem] | (0x80u >> remaining_bits));
        } else {
            last[rem] = 0x80u;
        }
        state[2][2] ^= 1;
        mdp_pack_key(K, last);
        MoFang_BC_1_DM(state, K, ROUND);
    }

@SQUEEZE@
    return 0;
}
'''

SQUEEZE_DIGEST = '''    /* 摘要：小端 64 位写，等价官方逐字节移位写出 */
    for (int i = 0; i < @DW@; i++) {
        mdp_st64le(output + (unsigned)i * 8u, state[i / 3][i % 3]);
    }'''

SQUEEZE_XOF = '''    /* XOF 挤出：每块 32 B = state 前 4 个字的低端字节；块间 state[2][2] ^= 1 再跑一轮 */
    {
        int output_blocks = (output_len_bits + 255) / 256;
        int output_len_bytes = (output_len_bits + 7) / 8;
        for (int i = 0; i < output_blocks; i++) {
            if (i != 0) {
                state[2][2] ^= 1;
                MoFang_BC_1_DM(state, K, ROUND);
            }
            int base = i * 32;
            int avail = output_len_bytes - base;
            if (avail > 32) avail = 32;
            if (avail == 32 && (output_len_bits % 8) == 0) {
                for (int w = 0; w < 4; w++) {
                    mdp_st64le(output + (unsigned)base + (unsigned)w * 8u,
                               state[w / 3][w % 3]);
                }
            } else {
                for (int j = 0; j < avail; j++) {
                    unsigned char ss = (unsigned char)
                        ((state[(j / 8) / 3][(j / 8) % 3] >> (8 * (j % 8))) & 0xFFu);
                    if (base + j == output_len_bytes - 1) {
                        int rb = output_len_bits % 8;
                        if (rb == 0) rb = 8;
                        ss = (unsigned char)(ss & (unsigned char)(0xFFu << (8 - rb)));
                    }
                    output[base + j] = ss;
                }
            }
        }
    }'''


def paths(bits):
    if isinstance(bits, str):
        inst = "MoFang-%s-%s" % (bits.split("x")[0], "XOF")
        tag = str(bits)
    else:
        inst = "MoFang-%d" % bits
        tag = str(bits)
    optdir = os.path.join(RELD, "Optimized_Implementation", inst)
    refdir = os.path.join(RELD, "Reference_Implementation", inst)
    return {
        "bits": bits,
        "inst": inst,
        "optdir": optdir,
        "refdir": refdir,
        "optsrc": os.path.join(optdir, "CryptHash_AlgorithmInstance.c"),
        "glue": os.path.join(HERE, "glue_mofang%sdrv.c" % tag),
        "so": os.path.join(OUTDIR, "ours_mofang%sdrv.so" % tag),
        "builddir": os.path.join(L0, "build", "hash-19", "mofang%s" % tag),
        "kat": os.path.join(L0, "src", "hash-19", "MoFang", "Test_Vectors",
                            "Test_Vector", "KAT_2_12_%s.txt" % inst.replace("-", "_")),
    }


def cut_function(text, sig):
    """挖掉以 sig 开头的那个函数（括号配平），返回 (head, body, tail)。"""
    i = text.find(sig)
    if i < 0:
        raise SystemExit("找不到函数签名：%r" % sig)
    if text.count(sig) != 1:
        raise SystemExit("函数签名出现 %d 次（期望 1）：%r" % (text.count(sig), sig))
    j = text.find("{", i + len(sig))
    if j < 0:
        raise SystemExit("签名之后找不到左花括号：%r" % sig)
    depth = 0
    k = j
    while k < len(text):
        c = text[k]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                break
        k += 1
    if depth != 0:
        raise SystemExit("花括号未配平：%r" % sig)
    end = k + 1
    while end < len(text) and text[end] in "\r\n":
        end += 1
    return text[:i], text[i:end], text[end:]


def run(cmd, cwd=None):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = p.stdout.decode("utf-8", "replace")
    if p.returncode != 0:
        raise SystemExit("失败 rc=%d：%s\n%s" % (p.returncode, " ".join(cmd), out[-4000:]))
    return out


def make_glue(P):
    iv, dw = TIERS[P["bits"]]
    src = open(P["optsrc"], "r", encoding="utf-8").read()
    head, body, tail = cut_function(src, "int hash_MDP(int output_len_bits,")
    sq = SQUEEZE_XOF if P["bits"] in XOF_TIERS else SQUEEZE_DIGEST
    drv = (DRIVER.replace("@IV@", str(iv)).replace("@DW@", str(dw))
                 .replace("@SQUEEZE@", sq.replace("@DW@", str(dw))))
    if P["bits"] in XOF_TIERS:
        drv = drv.replace("    (void)output_len_bits;\n", "")
    text = head + drv.lstrip("\n") + "\n" + tail
    with open(P["glue"], "w", encoding="utf-8", newline="\n") as f:
        f.write("/* 自动生成，勿手改 —— 见 mofang/build_mofang_drv.py:make_glue() */\n")
        f.write("/* 基质 = 官方 Optimized_Implementation/%s/CryptHash_AlgorithmInstance.c */\n" % P["inst"])
        f.write("/* 改动 = 只替换 hash_MDP 驱动层 */\n")
        f.write("/*        MoFang_BC_1 / MoFang_BC_1_DM / MixColumns / MUL / rotl 与全部静态表逐字保留 */\n")
        f.write(text)
    return len(src), len(text), len(body)


def cmd_glue(P):
    a, b, c = make_glue(P)
    print("glue <- %s" % P["optsrc"])
    print("源码 %d B（hash_MDP 函数体 %d B）-> glue %d B" % (a, c, b))
    print("-> %s" % P["glue"])


def cmd_build(P):
    os.makedirs(OUTDIR, exist_ok=True)
    cmd_glue(P)
    out = run(["gcc"] + FLAGS + ["-fPIC", "-shared", "-I", P["optdir"],
                                 "-o", P["so"], P["glue"], "-lm"])
    if out.strip():
        print(out.strip())
    und = run(["nm", "-D", "-u", P["so"]])
    bad = [l for l in und.splitlines()
           if any(k in l for k in ("MoFang_BC", "hash_MDP", "CryptHash"))]
    print("未定义符号：%d 个；其中含 MoFang_BC/hash_MDP/CryptHash 的 %d 个"
          % (len([l for l in und.splitlines() if l.strip()]), len(bad)))
    if bad:
        raise SystemExit("链接不完整：%r" % bad)
    print("build -> %s (%d B)" % (P["so"], os.path.getsize(P["so"])))
    defined = run(["nm", "-D", "--defined-only", P["so"]])
    for sym in ("CryptHash", "hash_MDP"):
        print("  导出 %-10s %s" % (sym, "OK" if sym in defined else "缺失"))


def _scan(path):
    txt = run(["objdump", "-d", "--no-show-raw-insn", path])
    funcs, cur = {}, None
    for line in txt.splitlines():
        if line and line[0].isalnum() and ">:" in line and line.endswith(":"):
            cur = line.split("<", 1)[1].rsplit(">", 1)[0]
            funcs[cur] = []
        elif cur is not None and line.startswith(" ") and ":" in line:
            parts = line.split("\t")
            if len(parts) >= 2:
                funcs[cur].append(parts[1].split()[0])
    return funcs


def cmd_asm(P):
    mine = _scan(P["so"])
    off = _scan(os.path.join(P["builddir"], "opt.so"))
    print("我方 %s：函数 %d 个，总条数 %d" % (os.path.basename(P["so"]), len(mine),
                                        sum(len(v) for v in mine.values())))
    for k in sorted(mine, key=lambda n: -len(mine[n]))[:6]:
        print("  %-28s %5d 条" % (k[:28], len(mine[k])))
    print("官方 opt.so：函数 %d 个，总条数 %d" % (len(off), sum(len(v) for v in off.values())))
    for k in sorted(off, key=lambda n: -len(off[n]))[:6]:
        print("  %-28s %5d 条" % (k[:28], len(off[k])))


def cmd_kat(P):
    sys.path.insert(0, L0)
    import kat_gate as K
    K.MAX_RECORDS = 10 ** 9
    K.MAX_MSG_BYTES = 1 << 20
    recs = K.parse_kat(P["kat"])
    print("KAT %s  记录 %d 条" % (os.path.basename(P["kat"]), len(recs)))
    rc = 0
    for name, lib in (("ref", os.path.join(P["builddir"], "ref.so")),
                      ("opt", os.path.join(P["builddir"], "opt.so")),
                      ("ours", P["so"])):
        checked, match, first_bad, err = K.check(lib, recs)
        tag = "OK" if (err is None and checked == match and checked > 0) else "FAIL"
        print("  %-5s %d/%d %s%s" % (name, match, checked, tag,
                                     "" if err is None else "  err=%s" % err))
        if tag == "FAIL":
            print("        first_bad=%r" % (first_bad,))
            rc = 2
    if rc == 0:
        print("判定：全过")
    return rc


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    a = sys.argv[1]
    bits = int(a) if a.isdigit() else a
    if bits not in TIERS and bits not in XOF_TIERS:
        raise SystemExit("只支持 %r" % (sorted(TIERS),))
    P = paths(bits)
    cmd = sys.argv[2]
    if cmd == "glue":
        cmd_glue(P)
        return 0
    if cmd == "build":
        cmd_build(P)
        return 0
    if cmd == "asm":
        cmd_asm(P)
        return 0
    if cmd == "kat":
        return cmd_kat(P)
    print(__doc__)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
