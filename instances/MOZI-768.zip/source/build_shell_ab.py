#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_shell_ab.py — 隔离「外壳」差异：同一颗 MOZI 引擎核，配两种外壳。

A 外壳 = 官方 Reference_Implementation 的 .c 逐字保留、原位换掉 permutation（h20b/c/d 现在用的）
B 外壳 = alg/h20/ref_agent.c 那样的精简 sponge 外壳，由我方参数化（rate/hash/符号名）

两者共用同一份 .s 引擎核（同一个符号），所以 A/B 差异**只有外壳代码**。
目的：判明 512/768/1024 上落后官方 fast.cpp 5.7–9.1% 是「引擎核」的责任还是
「官方 .c 外壳」的责任 —— 384 档用 B 外壳时是**快**官方 6.93% 的。
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))
sys.path.insert(0, HERE)
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))

import build_mozi_siblings as S   # noqa: E402
import run_std as RS              # noqa: E402

OUT = os.path.join(WORK, "_std", "out", "so")
APIDIR = os.path.join(HERE, "shellab")

SHELL_B = """/* shell_b_%(bits)d.c — 参数化精简 sponge 外壳（build_shell_ab.py 生成）
 * 与 alg/h20/ref_agent.c 同形：malloc 整条 padded、逐字节吸收、从头挤出。
 * rate/hash/核符号名按档位填入。 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define ULL unsigned long long
#define RATE  %(rate)d
#define HASHB %(hashb)d

void %(sym)s(uint64_t *p);

static int sponge(const unsigned char *input, ULL input_len_bits,
                  unsigned char *output) {
    unsigned char state[256];
    memset(state, 0, sizeof(state));
    ULL pad_bits = ((input_len_bits + RATE * 8) / (RATE * 8)) * RATE * 8;
    ULL pad_len = pad_bits / 8;
    unsigned char *padded = (unsigned char *)malloc(pad_len);
    memset(padded, 0, pad_len);
    ULL full_bytes = input_len_bits / 8;
    int rem = (int)(input_len_bits %% 8);
    memcpy(padded, input, full_bytes);
    if (rem > 0) {
        unsigned char mask = (unsigned char)(0xFF << (8 - rem));
        padded[full_bytes] = (unsigned char)(input[full_bytes] & mask);
        padded[full_bytes] |= (unsigned char)(0x80 >> rem);
    } else {
        padded[full_bytes] = 0x80;
    }
    ULL blocks = pad_len / RATE;
    for (ULL i = 0; i < blocks; i++) {
        for (int j = 0; j < RATE; j++) state[j] ^= padded[i * RATE + j];
        %(sym)s((uint64_t *)state);
    }
    for (int i = 0; i < HASHB; i++) output[i] = state[i];
    free(padded);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest) {
    (void)digest_len_bits;
    return sponge(msg, msg_len_bits, digest);
}
"""

SHELL_BF = """/* shell_bf_%(bits)d.c — 参数化精简 F-sponge 外壳（build_shell_ab.py 生成）
 * 与官方 hash_Fsponge 同语义：末块 domain-separation 0x80、每块 feedforward、
 * 从 state[256-hash] 起挤出。rate/hash/核符号名按档位填入，均为编译期常量。
 * 官方件漏了 free(padded_input)（内存泄漏，与速度无关），这里补上。 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define ULL unsigned long long
#define RATE  %(rate)d
#define HASHB %(hashb)d

void %(sym)s(uint64_t *p);

static int fsponge(const unsigned char *input, ULL input_len_bits,
                   unsigned char *output) {
    unsigned char state[256];
    unsigned char forward[256];
    memset(state, 0, sizeof(state));
    ULL pad_bits = ((input_len_bits + RATE * 8) / (RATE * 8)) * RATE * 8;
    ULL pad_len = pad_bits / 8;
    unsigned char *padded = (unsigned char *)malloc(pad_len);
    memset(padded, 0, pad_len);
    ULL full_bytes = input_len_bits / 8;
    int rem = (int)(input_len_bits %% 8);
    memcpy(padded, input, full_bytes);
    if (rem > 0) {
        unsigned char mask = (unsigned char)(0xFF << (8 - rem));
        padded[full_bytes] = (unsigned char)(input[full_bytes] & mask);
        padded[full_bytes] |= (unsigned char)(0x80 >> rem);
    } else {
        padded[full_bytes] = 0x80;
    }
    int blocks = (int)(pad_len / RATE);
    memset(forward, 0, sizeof(forward));
    for (int i = 0; i < blocks; i++) {
        for (int j = 0; j < RATE; j++) state[j] ^= padded[i * RATE + j];
        if (i == blocks - 1) state[RATE] ^= 0x80;
        memcpy(forward + RATE, state + RATE, 256 - RATE);
        %(sym)s((uint64_t *)state);
        for (int j = RATE; j < 256; j++) state[j] ^= forward[j];
    }
    for (int i = 0; i < HASHB; i++) output[i] = state[256 - HASHB + i];
    free(padded);
    return 0;
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest) {
    (void)digest_len_bits;
    return fsponge(msg, msg_len_bits, digest);
}
"""

# (cid, instance, bits, rounds, rate, hashb)
TIERS = [("h20b", "MOZI-512", 512, 20, 128, 64),
         ("h20c", "MOZI-768", 768, 24, 152, 96),
         ("h20d", "MOZI-1024", 1024, 24, 120, 128)]


def compile_so(so, shell_c, core_s, inc):
    cmd = (["gcc"] + RS.FLAGS["opt"] + ["-shared", "-fPIC", "-I", inc, "-o", so]
           + [shell_c, core_s, "-lm"])
    p = subprocess.run(cmd, capture_output=True, text=True, errors="ignore")
    if p.returncode != 0:
        errs = [l for l in (p.stdout + p.stderr).splitlines()
                if "error" in l or "undefined reference" in l]
        return None, "\n".join(errs[:20] or (p.stdout + p.stderr).splitlines()[-20:])
    nm = subprocess.run(["nm", "-D", so], capture_output=True, text=True)
    if " T CryptHash" not in nm.stdout:
        return None, "未导出 CryptHash"
    return so, ""


def main():
    os.makedirs(APIDIR, exist_ok=True)
    cores = {}
    for rounds in (20, 24):
        core_s = os.path.join(APIDIR, "core_r%d.s" % rounds)
        jir, core_s, sym = S.gen_core(rounds, core_s)
        cores[rounds] = (core_s, sym)
    bad = 0
    for cid, inst, bits, rounds, rate, hashb in TIERS:
        core_s, sym = cores[rounds]
        refdir = inst
        shell_a, _nb, _nc = S.make_shell(bits, rounds, refdir, sym,
                                         "hash_Fsponge" if bits >= 768 else "hash_sponge")
        shell_b = os.path.join(APIDIR, "shell_b_%d.c" % bits)
        with open(shell_b, "w", encoding="utf-8", newline="\n") as f:
            f.write(SHELL_B % {"bits": bits, "rate": rate, "hashb": hashb, "sym": sym})
        shell_bf = os.path.join(APIDIR, "shell_bf_%d.c" % bits)
        with open(shell_bf, "w", encoding="utf-8", newline="\n") as f:
            f.write(SHELL_BF % {"bits": bits, "rate": rate, "hashb": hashb, "sym": sym})
        inc = os.path.join(S.REFBASE, refdir)
        for tag, sc in (("a", shell_a), ("b", shell_b), ("bf", shell_bf)):
            so = os.path.join(OUT, "lib%s_%s_ours.so" % (cid, tag))
            p, err = compile_so(so, sc, core_s, inc)
            if not p:
                print("[FAIL] %s %s: %s" % (cid, tag.upper(), err))
                bad += 1
                continue
            h = subprocess.run(["sha256sum", so], capture_output=True,
                               text=True).stdout.split()[0]
            print("%-5s %-4s %-9s -> %-26s %6d B  %s"
                  % (cid, tag.upper(), inst, os.path.basename(so),
                     os.path.getsize(so), h[:16]))
    print("DONE" if not bad else "SOME FAILED (%d)" % bad)
    return 0 if not bad else 2


if __name__ == "__main__":
    sys.exit(main())
