#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_mozi_siblings.py — MOZI-512/768/1024 三档：官方 Reference `.c` 逐字保留、
只把 `void permutation(unsigned char *state, int roundNum)` 挖掉换成调用引擎核
`mozi_perm()` 的 3 行包装，置换核由 `_cpb_tc/gen_mozi_v256b.py` 发出 JIR 再经
`ir_text.to_jasmin` / `jasminc` 落成汇编。

为什么这条路线（而不是复用 `alg/h20/ref_agent.c` 那种手写外壳）：
  * 手写外壳正是本项目要消除的东西；官方 `.c` 逐字保留后，"两侧唯一差异就是
    置换核心"可以被 diff 检验，不需要信任任何叙述。
  * 外壳里的 padding / absorb / squeeze / F-sponge feedforward 全部是官方行为，
    我们一个字都不碰 ⇒ 不会引入语义漂移。

族结构（四档同一族，只在头文件是编译期常量）：
  rate/hash（字节）= 384:160/48  512:128/64  768:152/96  1024:120/128
  轮数           = 384/512 → 20        768/1024 → 24
  384/512  = 纯 sponge（从头挤出）
  768/1024 = F-sponge（末块 domain-separation 0x80、每块 feedforward、从尾挤出）
  四档的 rhoY / RCON 常量表完全相同 ⇒ 置换核与档位无关，只跟轮数有关。

产物：`feilian/work/_std/out/so/libh20{b,c,d}_ours.so`
   h20b = MOZI-512   h20c = MOZI-768   h20d = MOZI-1024
"""
import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))
sys.path.insert(0, L0)
sys.path.insert(0, os.path.join(L0, "mofang"))

import run_std as RS            # noqa: E402
import ir_text as I             # noqa: E402
import build_mofang as B        # noqa: E402

REPO = os.path.dirname(WORK)
SRC = os.path.join(L0, "src")
REFBASE = os.path.join(SRC, "hash-20/Mozi/Implementations/Reference_Implementation")
OUT = os.path.join(WORK, "_std", "out", "so")
GEN = os.path.join(WORK, "_cpb_tc", "gen_mozi_v256b.py")

TIERS = [
    # (cid, instance, bits, rounds, ref_dir_name)
    ("h20b", "MOZI-512", 512, 20, "MOZI-512"),
    ("h20c", "MOZI-768", 768, 24, "MOZI-768"),
    ("h20d", "MOZI-1024", 1024, 24, "MOZI-1024"),
]

PERM_SIG = "void permutation(unsigned char *state, int roundNum)"

WRAPPER = """/* ---- 置换核心换成引擎核（JIR -> ir_text.to_jasmin -> jasminc）----
 * 官方本函数是标量 C（A/B/C/D 四份 4x4x2 的 ULL 数组 + 8 次逐字节移位装载），
 * 内核换成本文件同目录下 mozi_perm.s 里的 %(sym)s，轮数 %(rounds)d 已展开进去。
 * 其余（padding / absorb / %(sponge)s / squeeze）逐字保留官方实现。 */
void %(sym)s(uint64_t *p);

%(sig)s {
    (void)roundNum;
    %(sym)s((uint64_t *)state);
}
"""


def run(cmd, **kw):
    p = subprocess.run(cmd, capture_output=True, text=True, errors="ignore", **kw)
    if p.returncode != 0:
        raise SystemExit("命令失败: %s\n%s\n%s"
                         % (" ".join(cmd), p.stdout[-2000:], p.stderr[-2000:]))
    return p


def gen_core(rounds, out_s):
    """生成 rounds 轮的置换核汇编。返回 (jir_path, s_path, n_lines)。"""
    jir = os.path.join(HERE, "mozi_perm_r%d.jir" % rounds)
    jazz = os.path.join(HERE, "mozi_perm_r%d.jazz" % rounds)
    run([sys.executable, "-u", GEN, "--out", jir, "--rounds", str(rounds)])
    text = io.open(jir, encoding="utf-8").read()
    # 每档一个独立符号名，避免同一进程/同一 .so 里两个核撞名
    sym = "mozi_perm%d" % rounds
    text = text.replace("entry mozi_perm(p: u64)", "entry %s(p: u64)" % sym, 1)
    io.open(jir, "w", encoding="utf-8", newline="\n").write(text)
    jasm, info = I.to_jasmin(text, 16)
    io.open(jazz, "w", encoding="utf-8", newline="\n").write(jasm)
    run(["jasminc", "-o", out_s, jazz])
    print("  core r%-2d -> %-22s %s" % (rounds, os.path.basename(out_s), info))
    return jir, out_s, sym


def make_shell(bits, rounds, refdir, sym, sponge):
    """官方 Reference `.c` 挖掉 permutation，换 3 行包装。"""
    ref_c = os.path.join(REFBASE, refdir, "CryptHash_AlgorithmInstance.c")
    text = io.open(ref_c, encoding="utf-8", errors="replace").read()
    n_before = len(text.splitlines())
    # 原位替换（不能把包装追加到文件尾：hash_sponge 在 permutation 之前就调用它）
    i = text.index(PERM_SIG)
    _j, k = B._balanced(text, i)
    cut = text[i:k + 1]
    n_cut = len(cut.splitlines())
    text = (text[:i]
            + WRAPPER % {"sig": PERM_SIG, "sym": sym,
                         "rounds": rounds, "sponge": sponge}
            + text[k + 1:])
    # 包装用了 uint64_t
    if "#include <stdint.h>" not in text:
        text = text.replace("#define ULL unsigned long long",
                            "#include <stdint.h>\n#define ULL unsigned long long", 1)
    out_c = os.path.join(HERE, "shell_%d.c" % bits)
    io.open(out_c, "w", encoding="utf-8", newline="\n").write(text)
    print("  shell %-10s 官方 %d 行 - 置换 %d 行 + 包装 8 行 = %d 行"
          % (refdir, n_before, n_cut, len(text.splitlines())))
    return out_c, n_before, n_cut


def build(cid, bits, shell_c, core_s, refdir):
    os.makedirs(OUT, exist_ok=True)
    so = os.path.join(OUT, "lib%s_ours.so" % cid)
    inc = os.path.join(REFBASE, refdir)
    cmd = (["gcc"] + RS.FLAGS["opt"] + ["-shared", "-fPIC", "-I", inc, "-o", so]
           + [shell_c, core_s, "-lm"])
    p = subprocess.run(cmd, capture_output=True, text=True, errors="ignore")
    if p.returncode != 0:
        errs = [l for l in (p.stdout + p.stderr).splitlines()
                if "error" in l or "undefined reference" in l]
        return None, "\n".join(errs[:20] or (p.stdout + p.stderr).splitlines()[-20:])
    nwarn = len([l for l in p.stderr.splitlines() if "warning:" in l])
    if nwarn:
        print("         (gcc 警告 %d 条，非致命)" % nwarn)
    nm = subprocess.run(["nm", "-D", so], capture_output=True, text=True)
    missing = [s for s in ("CryptHash",) if (" T %s" % s) not in nm.stdout]
    if missing:
        return None, "未导出 %s" % ",".join(missing)
    return so, ""


def main():
    print("MOZI 兄弟档构建（官方 .c 逐字保留 + 引擎置换核）")
    cores = {}
    for rounds in (20, 24):
        core_s = os.path.join(HERE, "mozi_perm_r%d.s" % rounds)
        cores[rounds] = gen_core(rounds, core_s)
    ok = True
    for cid, inst, bits, rounds, refdir in TIERS:
        sponge = "hash_Fsponge" if bits >= 768 else "hash_sponge"
        jir, core_s, sym = cores[rounds]
        shell_c, nb, nc = make_shell(bits, rounds, refdir, sym, sponge)
        so, err = build(cid, bits, shell_c, core_s, refdir)
        if not so:
            print("%-5s %-10s BUILD FAIL %s" % (cid, inst, err))
            ok = False
            continue
        h = subprocess.run(["sha256sum", so], capture_output=True, text=True).stdout.split()[0]
        print("%-5s %-10s OK  %7d B  sha256 %s  core=%s"
              % (cid, inst, os.path.getsize(so), h[:16], os.path.basename(core_s)))
    print("DONE" if ok else "SOME FAILED")
    return 0 if ok else 2


if __name__ == "__main__":
    sys.exit(main())
