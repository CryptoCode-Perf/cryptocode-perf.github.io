# MOZI-768

Algorithm: Mozi | Digest bits: 768 | Form: SSE C++（对手 fast 驱动）

Contents: implementation source/, public header MOZI-768.h, prebuilt MOZI-768.so,
KAT vector KAT_2_12_MOZI-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 9899cb76364bb36f62b94617edb5d0c01b9692ecb22f4abedb8730907681c180
Speed (cpB, lower is faster): reference 15.26 / official-optimized 4.42 / optimized 4.12
Speedup: GM(S1-S8) 1.06x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
