# CHIME candidate package

Instances: CHIME-512 and CHIME-1024. On x86-64 Linux with GCC, G++, Python 3
and AVX2, run `bash build_and_verify.sh`. The script builds reference, official
optimized and CryptoCode implementations, verifies 4097 known-answer vectors
per implementation, checks selected long and boundary inputs against the
reference, and tests selected input and output guard-page boundaries.
`CryptHash` lengths are in bits.

The CryptoCode C++ wrappers and generated assembly come from the local
performance report and associated build tree. Jasmin and intermediate source
are supplied, but this build does not regenerate assembly. Candidate only:
controlled performance comparisons, independent source and license review,
redistribution permission and final release review remain pending. Tests do
not prove security.
