#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")";mkdir -p build
for bits in 512 1024; do
 ref="Reference_Implementation/CHIME-$bits";opt="Optimized_Implementation/CHIME-$bits";own="CryptoCode_Implementation/CHIME-$bits"
 gcc -O2 -fPIC -shared -Wl,-z,defs -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" -o "build/Reference-$bits.so"
 g++ -std=c++17 -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" "$opt/CryptHash_AlgorithmInstance.c" "$opt/P.cpp" "$opt/chime${bits}.cpp" -o "build/Optimized-$bits.so"
 g++ -std=c++17 -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" "$opt/CryptHash_AlgorithmInstance.c" "$opt/P.cpp" "$own/glue.cpp" "$own/permutation.s" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/CHIME-$bits.txt";done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits";done;done
