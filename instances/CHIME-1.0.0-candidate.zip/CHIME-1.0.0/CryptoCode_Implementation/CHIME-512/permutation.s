	.att_syntax
	.text
	.p2align	5
	.global	chime_perm
	.type	chime_perm, %function
chime_perm:
	vmovdqu	(%rdi), %ymm0
	vmovdqu	32(%rdi), %ymm1
	vmovdqu	64(%rdi), %ymm3
	vmovdqu	96(%rdi), %ymm4
	vmovdqu	128(%rdi), %ymm5
	vmovdqu	160(%rdi), %ymm2
	vpshufd	$57, %ymm2, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm1, %ymm3, %ymm3
	vpsrlq	$35, %ymm0, %ymm6
	vpsllq	$29, %ymm0, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vpsrlq	$33, %ymm1, %ymm6
	vpsllq	$31, %ymm1, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vpsrlq	$51, %ymm0, %ymm6
	vpsllq	$13, %ymm0, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm2, %ymm6
	vpxor	%ymm4, %ymm5, %ymm2
	vpermq	$147, %ymm0, %ymm0
	vpshufd	$78, %ymm2, %ymm5
	vpshufd	$57, %ymm4, %ymm7
	vpxor	%ymm7, %ymm6, %ymm6
	vperm2i128	$1, %ymm1, %ymm1, %ymm1
	vpxor	%ymm5, %ymm0, %ymm5
	vpshufd	$57, %ymm3, %ymm0
	vpxor	%ymm0, %ymm1, %ymm0
	vpsllq	$7, %ymm5, %ymm1
	vpxor	%ymm1, %ymm4, %ymm4
	vpsrlq	$5, %ymm0, %ymm1
	vpxor	%ymm1, %ymm6, %ymm1
	vpxor	glob_data + 608(%rip), %ymm5, %ymm7
	vpandn	%ymm2, %ymm3, %ymm6
	vpxor	%ymm7, %ymm6, %ymm5
	vpandn	%ymm7, %ymm2, %ymm6
	vpxor	%ymm3, %ymm6, %ymm6
	vpandn	%ymm3, %ymm7, %ymm3
	vpxor	%ymm3, %ymm2, %ymm2
	vpandn	%ymm1, %ymm4, %ymm3
	vpxor	%ymm0, %ymm3, %ymm3
	vpandn	%ymm0, %ymm1, %ymm7
	vpxor	%ymm4, %ymm7, %ymm7
	vpandn	%ymm4, %ymm0, %ymm0
	vpxor	%ymm0, %ymm1, %ymm0
	vpshufd	$57, %ymm2, %ymm1
	vpxor	%ymm1, %ymm6, %ymm6
	vpxor	%ymm5, %ymm3, %ymm1
	vpsrlq	$35, %ymm0, %ymm3
	vpsllq	$29, %ymm0, %ymm4
	vpor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm7, %ymm4
	vpsrlq	$33, %ymm5, %ymm3
	vpsllq	$31, %ymm5, %ymm7
	vpor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm3, %ymm6, %ymm6
	vpsrlq	$51, %ymm0, %ymm3
	vpsllq	$13, %ymm0, %ymm7
	vpor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm3, %ymm2, %ymm3
	vpxor	%ymm6, %ymm4, %ymm2
	vpermq	$147, %ymm0, %ymm0
	vpshufd	$78, %ymm2, %ymm4
	vpshufd	$57, %ymm6, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vperm2i128	$1, %ymm5, %ymm5, %ymm5
	vpxor	%ymm4, %ymm0, %ymm4
	vpshufd	$57, %ymm1, %ymm0
	vpxor	%ymm0, %ymm5, %ymm0
	vpsllq	$7, %ymm4, %ymm5
	vpxor	%ymm5, %ymm6, %ymm6
	vpsrlq	$5, %ymm0, %ymm5
	vpxor	%ymm5, %ymm3, %ymm7
	vpxor	glob_data + 576(%rip), %ymm4, %ymm4
	vpandn	%ymm7, %ymm6, %ymm3
	vpxor	%ymm4, %ymm3, %ymm5
	vpandn	%ymm4, %ymm7, %ymm3
	vpxor	%ymm6, %ymm3, %ymm3
	vpandn	%ymm6, %ymm4, %ymm6
	vpxor	%ymm6, %ymm7, %ymm4
	vpandn	%ymm2, %ymm1, %ymm6
	vpxor	%ymm0, %ymm6, %ymm6
	vpandn	%ymm0, %ymm2, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpandn	%ymm1, %ymm0, %ymm0
	vpxor	%ymm0, %ymm2, %ymm2
	vpshufd	$57, %ymm2, %ymm0
	vpxor	%ymm0, %ymm7, %ymm0
	vpxor	%ymm5, %ymm6, %ymm1
	vpsrlq	$35, %ymm4, %ymm6
	vpsllq	$29, %ymm4, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpsrlq	$33, %ymm5, %ymm6
	vpsllq	$31, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vpsrlq	$51, %ymm4, %ymm6
	vpsllq	$13, %ymm4, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm0, %ymm3, %ymm3
	vpermq	$147, %ymm4, %ymm6
	vpshufd	$78, %ymm3, %ymm4
	vpshufd	$57, %ymm0, %ymm7
	vpxor	%ymm7, %ymm2, %ymm7
	vperm2i128	$1, %ymm5, %ymm5, %ymm2
	vpxor	%ymm4, %ymm6, %ymm6
	vpshufd	$57, %ymm1, %ymm5
	vpxor	%ymm5, %ymm2, %ymm2
	vpsllq	$7, %ymm6, %ymm4
	vpxor	%ymm4, %ymm0, %ymm0
	vpsrlq	$5, %ymm2, %ymm4
	vpxor	%ymm4, %ymm7, %ymm4
	vpxor	glob_data + 544(%rip), %ymm6, %ymm7
	vpandn	%ymm3, %ymm1, %ymm6
	vpxor	%ymm7, %ymm6, %ymm5
	vpandn	%ymm7, %ymm3, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vpandn	%ymm4, %ymm0, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpandn	%ymm2, %ymm4, %ymm1
	vpxor	%ymm0, %ymm1, %ymm1
	vpandn	%ymm0, %ymm2, %ymm0
	vpxor	%ymm0, %ymm4, %ymm0
	vpshufd	$57, %ymm3, %ymm2
	vpxor	%ymm2, %ymm6, %ymm6
	vpxor	%ymm5, %ymm7, %ymm2
	vpsrlq	$35, %ymm0, %ymm4
	vpsllq	$29, %ymm0, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm4, %ymm1, %ymm1
	vpsrlq	$33, %ymm5, %ymm4
	vpsllq	$31, %ymm5, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm4, %ymm6, %ymm6
	vpsrlq	$51, %ymm0, %ymm4
	vpsllq	$13, %ymm0, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm6, %ymm1, %ymm1
	vpermq	$147, %ymm0, %ymm4
	vpshufd	$78, %ymm1, %ymm7
	vpshufd	$57, %ymm6, %ymm0
	vpxor	%ymm0, %ymm3, %ymm3
	vperm2i128	$1, %ymm5, %ymm5, %ymm0
	vpxor	%ymm7, %ymm4, %ymm4
	vpshufd	$57, %ymm2, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpsllq	$7, %ymm4, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpsrlq	$5, %ymm0, %ymm6
	vpxor	%ymm6, %ymm3, %ymm6
	vpxor	glob_data + 512(%rip), %ymm4, %ymm7
	vpandn	%ymm6, %ymm5, %ymm3
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm7, %ymm6, %ymm4
	vpxor	%ymm5, %ymm4, %ymm4
	vpandn	%ymm5, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpandn	%ymm1, %ymm2, %ymm7
	vpxor	%ymm0, %ymm7, %ymm6
	vpandn	%ymm0, %ymm1, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpandn	%ymm2, %ymm0, %ymm0
	vpxor	%ymm0, %ymm1, %ymm1
	vpshufd	$57, %ymm3, %ymm0
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm7, %ymm4, %ymm4
	vpsrlq	$35, %ymm6, %ymm0
	vpsllq	$29, %ymm6, %ymm2
	vpor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm0, %ymm5, %ymm5
	vpsrlq	$33, %ymm7, %ymm0
	vpsllq	$31, %ymm7, %ymm2
	vpor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm0, %ymm1, %ymm1
	vpsrlq	$51, %ymm6, %ymm0
	vpsllq	$13, %ymm6, %ymm2
	vpor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm0, %ymm3, %ymm0
	vpxor	%ymm1, %ymm5, %ymm3
	vpermq	$147, %ymm6, %ymm5
	vpshufd	$78, %ymm3, %ymm2
	vpshufd	$57, %ymm1, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vperm2i128	$1, %ymm7, %ymm7, %ymm7
	vpxor	%ymm2, %ymm5, %ymm5
	vpshufd	$57, %ymm4, %ymm2
	vpxor	%ymm2, %ymm7, %ymm2
	vpsllq	$7, %ymm5, %ymm6
	vpxor	%ymm6, %ymm1, %ymm1
	vpsrlq	$5, %ymm2, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	glob_data + 480(%rip), %ymm5, %ymm7
	vpandn	%ymm3, %ymm4, %ymm5
	vpxor	%ymm7, %ymm5, %ymm5
	vpandn	%ymm7, %ymm3, %ymm6
	vpxor	%ymm4, %ymm6, %ymm6
	vpandn	%ymm4, %ymm7, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vpandn	%ymm0, %ymm1, %ymm4
	vpxor	%ymm2, %ymm4, %ymm4
	vpandn	%ymm2, %ymm0, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpandn	%ymm1, %ymm2, %ymm1
	vpxor	%ymm1, %ymm0, %ymm1
	vpshufd	$57, %ymm5, %ymm2
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm6, %ymm7, %ymm0
	vpsrlq	$35, %ymm4, %ymm2
	vpsllq	$29, %ymm4, %ymm7
	vpor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vpsrlq	$33, %ymm6, %ymm2
	vpsllq	$31, %ymm6, %ymm7
	vpor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm2, %ymm3, %ymm3
	vpsrlq	$51, %ymm4, %ymm2
	vpsllq	$13, %ymm4, %ymm7
	vpor	%ymm7, %ymm2, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm3, %ymm1, %ymm1
	vpermq	$147, %ymm4, %ymm4
	vpshufd	$78, %ymm1, %ymm7
	vpshufd	$57, %ymm3, %ymm2
	vpxor	%ymm2, %ymm5, %ymm5
	vperm2i128	$1, %ymm6, %ymm6, %ymm2
	vpxor	%ymm7, %ymm4, %ymm4
	vpshufd	$57, %ymm0, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpsllq	$7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm3, %ymm6
	vpsrlq	$5, %ymm2, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vpxor	glob_data + 448(%rip), %ymm4, %ymm7
	vpandn	%ymm5, %ymm6, %ymm3
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm7, %ymm5, %ymm4
	vpxor	%ymm6, %ymm4, %ymm4
	vpandn	%ymm6, %ymm7, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vpandn	%ymm1, %ymm0, %ymm7
	vpxor	%ymm2, %ymm7, %ymm6
	vpandn	%ymm2, %ymm1, %ymm7
	vpxor	%ymm0, %ymm7, %ymm7
	vpandn	%ymm0, %ymm2, %ymm0
	vpxor	%ymm0, %ymm1, %ymm0
	vpshufd	$57, %ymm3, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm7, %ymm4, %ymm4
	vpsrlq	$35, %ymm6, %ymm2
	vpsllq	$29, %ymm6, %ymm1
	vpor	%ymm1, %ymm2, %ymm1
	vpxor	%ymm1, %ymm5, %ymm1
	vpsrlq	$33, %ymm7, %ymm2
	vpsllq	$31, %ymm7, %ymm5
	vpor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vpsrlq	$51, %ymm6, %ymm2
	vpsllq	$13, %ymm6, %ymm5
	vpor	%ymm5, %ymm2, %ymm2
	vpxor	%ymm2, %ymm3, %ymm2
	vpxor	%ymm0, %ymm1, %ymm5
	vpermq	$147, %ymm6, %ymm1
	vpshufd	$78, %ymm5, %ymm6
	vpshufd	$57, %ymm0, %ymm3
	vpxor	%ymm3, %ymm2, %ymm2
	vperm2i128	$1, %ymm7, %ymm7, %ymm7
	vpxor	%ymm6, %ymm1, %ymm3
	vpshufd	$57, %ymm4, %ymm1
	vpxor	%ymm1, %ymm7, %ymm1
	vpsllq	$7, %ymm3, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vpsrlq	$5, %ymm1, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	glob_data + 416(%rip), %ymm3, %ymm7
	vpandn	%ymm5, %ymm4, %ymm3
	vpxor	%ymm7, %ymm3, %ymm6
	vpandn	%ymm7, %ymm5, %ymm3
	vpxor	%ymm4, %ymm3, %ymm3
	vpandn	%ymm4, %ymm7, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vpandn	%ymm2, %ymm0, %ymm4
	vpxor	%ymm1, %ymm4, %ymm4
	vpandn	%ymm1, %ymm2, %ymm7
	vpxor	%ymm0, %ymm7, %ymm7
	vpandn	%ymm0, %ymm1, %ymm0
	vpxor	%ymm0, %ymm2, %ymm0
	vpshufd	$57, %ymm5, %ymm1
	vpxor	%ymm1, %ymm3, %ymm1
	vpxor	%ymm6, %ymm4, %ymm2
	vpsrlq	$35, %ymm0, %ymm3
	vpsllq	$29, %ymm0, %ymm4
	vpor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm7, %ymm7
	vpsrlq	$33, %ymm6, %ymm3
	vpsllq	$31, %ymm6, %ymm4
	vpor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm1, %ymm3
	vpsrlq	$51, %ymm0, %ymm4
	vpsllq	$13, %ymm0, %ymm1
	vpor	%ymm1, %ymm4, %ymm1
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm3, %ymm7, %ymm1
	vpermq	$147, %ymm0, %ymm0
	vpshufd	$78, %ymm1, %ymm7
	vpshufd	$57, %ymm3, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vperm2i128	$1, %ymm6, %ymm6, %ymm4
	vpxor	%ymm7, %ymm0, %ymm6
	vpshufd	$57, %ymm2, %ymm0
	vpxor	%ymm0, %ymm4, %ymm0
	vpsllq	$7, %ymm6, %ymm4
	vpxor	%ymm4, %ymm3, %ymm7
	vpsrlq	$5, %ymm0, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	glob_data + 384(%rip), %ymm6, %ymm6
	vpandn	%ymm5, %ymm7, %ymm3
	vpxor	%ymm6, %ymm3, %ymm4
	vpandn	%ymm6, %ymm5, %ymm3
	vpxor	%ymm7, %ymm3, %ymm3
	vpandn	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vpandn	%ymm1, %ymm2, %ymm6
	vpxor	%ymm0, %ymm6, %ymm6
	vpandn	%ymm0, %ymm1, %ymm7
	vpxor	%ymm2, %ymm7, %ymm7
	vpandn	%ymm2, %ymm0, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vpshufd	$57, %ymm1, %ymm0
	vpxor	%ymm0, %ymm7, %ymm2
	vpxor	%ymm4, %ymm6, %ymm0
	vpsrlq	$35, %ymm5, %ymm6
	vpsllq	$29, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpsrlq	$33, %ymm4, %ymm6
	vpsllq	$31, %ymm4, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm2, %ymm2
	vpsrlq	$51, %ymm5, %ymm6
	vpsllq	$13, %ymm5, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm2, %ymm3, %ymm3
	vpermq	$147, %ymm5, %ymm5
	vpshufd	$78, %ymm3, %ymm6
	vpshufd	$57, %ymm2, %ymm7
	vpxor	%ymm7, %ymm1, %ymm7
	vperm2i128	$1, %ymm4, %ymm4, %ymm1
	vpxor	%ymm6, %ymm5, %ymm5
	vpshufd	$57, %ymm0, %ymm4
	vpxor	%ymm4, %ymm1, %ymm4
	vpsllq	$7, %ymm5, %ymm1
	vpxor	%ymm1, %ymm2, %ymm1
	vpsrlq	$5, %ymm4, %ymm6
	vpxor	%ymm6, %ymm7, %ymm6
	vpxor	glob_data + 352(%rip), %ymm5, %ymm7
	vpandn	%ymm3, %ymm0, %ymm5
	vpxor	%ymm7, %ymm5, %ymm5
	vpandn	%ymm7, %ymm3, %ymm2
	vpxor	%ymm0, %ymm2, %ymm2
	vpandn	%ymm0, %ymm7, %ymm0
	vpxor	%ymm0, %ymm3, %ymm3
	vpandn	%ymm6, %ymm1, %ymm0
	vpxor	%ymm4, %ymm0, %ymm7
	vpandn	%ymm4, %ymm6, %ymm0
	vpxor	%ymm1, %ymm0, %ymm8
	vpandn	%ymm1, %ymm4, %ymm1
	vpxor	%ymm1, %ymm6, %ymm0
	vpshufd	$57, %ymm3, %ymm4
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm5, %ymm7, %ymm1
	vpsrlq	$35, %ymm0, %ymm4
	vpsllq	$29, %ymm0, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm4, %ymm8, %ymm6
	vpsrlq	$33, %ymm5, %ymm4
	vpsllq	$31, %ymm5, %ymm7
	vpor	%ymm7, %ymm4, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpsrlq	$51, %ymm0, %ymm4
	vpsllq	$13, %ymm0, %ymm7
	vpor	%ymm7, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm2, %ymm6, %ymm6
	vpermq	$147, %ymm0, %ymm0
	vpshufd	$78, %ymm6, %ymm7
	vpshufd	$57, %ymm2, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vperm2i128	$1, %ymm5, %ymm5, %ymm4
	vpxor	%ymm7, %ymm0, %ymm0
	vpshufd	$57, %ymm1, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vpsllq	$7, %ymm0, %ymm5
	vpxor	%ymm5, %ymm2, %ymm7
	vpsrlq	$5, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	glob_data + 320(%rip), %ymm0, %ymm5
	vpandn	%ymm3, %ymm7, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm5, %ymm3, %ymm2
	vpxor	%ymm7, %ymm2, %ymm2
	vpandn	%ymm7, %ymm5, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vpandn	%ymm6, %ymm1, %ymm7
	vpxor	%ymm4, %ymm7, %ymm5
	vpandn	%ymm4, %ymm6, %ymm7
	vpxor	%ymm1, %ymm7, %ymm7
	vpandn	%ymm1, %ymm4, %ymm1
	vpxor	%ymm1, %ymm6, %ymm1
	vpshufd	$57, %ymm0, %ymm6
	vpxor	%ymm6, %ymm1, %ymm6
	vpxor	%ymm7, %ymm2, %ymm1
	vpsrlq	$35, %ymm5, %ymm2
	vpsllq	$29, %ymm5, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm3, %ymm3
	vpsrlq	$33, %ymm7, %ymm2
	vpsllq	$31, %ymm7, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm6, %ymm6
	vpsrlq	$51, %ymm5, %ymm2
	vpsllq	$13, %ymm5, %ymm4
	vpor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vpxor	%ymm6, %ymm3, %ymm3
	vpermq	$147, %ymm5, %ymm2
	vpshufd	$78, %ymm3, %ymm5
	vpshufd	$57, %ymm6, %ymm4
	vpxor	%ymm4, %ymm0, %ymm4
	vperm2i128	$1, %ymm7, %ymm7, %ymm0
	vpxor	%ymm5, %ymm2, %ymm7
	vpshufd	$57, %ymm1, %ymm2
	vpxor	%ymm2, %ymm0, %ymm0
	vpsllq	$7, %ymm7, %ymm5
	vpxor	%ymm5, %ymm6, %ymm6
	vpsrlq	$5, %ymm0, %ymm2
	vpxor	%ymm2, %ymm4, %ymm2
	vpxor	glob_data + 288(%rip), %ymm7, %ymm7
	vpandn	%ymm3, %ymm1, %ymm4
	vpxor	%ymm7, %ymm4, %ymm4
	vpandn	%ymm7, %ymm3, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vpandn	%ymm2, %ymm6, %ymm1
	vpxor	%ymm0, %ymm1, %ymm1
	vpandn	%ymm0, %ymm2, %ymm7
	vpxor	%ymm6, %ymm7, %ymm7
	vpandn	%ymm6, %ymm0, %ymm0
	vpxor	%ymm0, %ymm2, %ymm0
	vpshufd	$57, %ymm4, %ymm2
	vpxor	%ymm2, %ymm3, %ymm6
	vpxor	%ymm5, %ymm7, %ymm3
	vpsrlq	$35, %ymm1, %ymm2
	vpsllq	$29, %ymm1, %ymm7
	vpor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm2, %ymm0, %ymm2
	vpsrlq	$33, %ymm5, %ymm0
	vpsllq	$31, %ymm5, %ymm7
	vpor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm0, %ymm6, %ymm0
	vpsrlq	$51, %ymm1, %ymm6
	vpsllq	$13, %ymm1, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm0, %ymm2, %ymm2
	vpermq	$147, %ymm1, %ymm1
	vpshufd	$78, %ymm2, %ymm6
	vpshufd	$57, %ymm0, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vperm2i128	$1, %ymm5, %ymm5, %ymm5
	vpxor	%ymm6, %ymm1, %ymm6
	vpshufd	$57, %ymm3, %ymm1
	vpxor	%ymm1, %ymm5, %ymm1
	vpsllq	$7, %ymm6, %ymm7
	vpxor	%ymm7, %ymm0, %ymm5
	vpsrlq	$5, %ymm1, %ymm0
	vpxor	%ymm0, %ymm4, %ymm7
	vpxor	glob_data + 256(%rip), %ymm6, %ymm6
	vpandn	%ymm7, %ymm5, %ymm4
	vpxor	%ymm6, %ymm4, %ymm4
	vpandn	%ymm6, %ymm7, %ymm0
	vpxor	%ymm5, %ymm0, %ymm0
	vpandn	%ymm5, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm5
	vpandn	%ymm2, %ymm3, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm1, %ymm2, %ymm7
	vpxor	%ymm3, %ymm7, %ymm7
	vpandn	%ymm3, %ymm1, %ymm1
	vpxor	%ymm1, %ymm2, %ymm1
	vpshufd	$57, %ymm4, %ymm2
	vpxor	%ymm2, %ymm1, %ymm1
	vpxor	%ymm7, %ymm0, %ymm0
	vpsrlq	$35, %ymm6, %ymm2
	vpsllq	$29, %ymm6, %ymm3
	vpor	%ymm3, %ymm2, %ymm8
	vpxor	%ymm8, %ymm5, %ymm2
	vpsrlq	$33, %ymm7, %ymm3
	vpsllq	$31, %ymm7, %ymm5
	vpor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vpsrlq	$51, %ymm6, %ymm3
	vpsllq	$13, %ymm6, %ymm5
	vpor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm3, %ymm4, %ymm4
	vpxor	%ymm1, %ymm2, %ymm2
	vpermq	$147, %ymm6, %ymm3
	vpshufd	$78, %ymm2, %ymm6
	vpshufd	$57, %ymm1, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vperm2i128	$1, %ymm7, %ymm7, %ymm5
	vpxor	%ymm6, %ymm3, %ymm6
	vpshufd	$57, %ymm0, %ymm3
	vpxor	%ymm3, %ymm5, %ymm3
	vpsllq	$7, %ymm6, %ymm5
	vpxor	%ymm5, %ymm1, %ymm1
	vpsrlq	$5, %ymm3, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	glob_data + 224(%rip), %ymm6, %ymm7
	vpandn	%ymm2, %ymm0, %ymm5
	vpxor	%ymm7, %ymm5, %ymm5
	vpandn	%ymm7, %ymm2, %ymm6
	vpxor	%ymm0, %ymm6, %ymm6
	vpandn	%ymm0, %ymm7, %ymm0
	vpxor	%ymm0, %ymm2, %ymm2
	vpandn	%ymm4, %ymm1, %ymm0
	vpxor	%ymm3, %ymm0, %ymm7
	vpandn	%ymm3, %ymm4, %ymm0
	vpxor	%ymm1, %ymm0, %ymm8
	vpandn	%ymm1, %ymm3, %ymm0
	vpxor	%ymm0, %ymm4, %ymm0
	vpshufd	$57, %ymm2, %ymm1
	vpxor	%ymm1, %ymm6, %ymm3
	vpxor	%ymm5, %ymm7, %ymm1
	vpsrlq	$35, %ymm0, %ymm4
	vpsllq	$29, %ymm0, %ymm7
	vpor	%ymm7, %ymm4, %ymm6
	vpxor	%ymm6, %ymm8, %ymm6
	vpsrlq	$33, %ymm5, %ymm4
	vpsllq	$31, %ymm5, %ymm7
	vpor	%ymm7, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm4
	vpsrlq	$51, %ymm0, %ymm3
	vpsllq	$13, %ymm0, %ymm7
	vpor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm4, %ymm6, %ymm3
	vpermq	$147, %ymm0, %ymm0
	vpshufd	$78, %ymm3, %ymm6
	vpshufd	$57, %ymm4, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vperm2i128	$1, %ymm5, %ymm5, %ymm5
	vpxor	%ymm6, %ymm0, %ymm0
	vpshufd	$57, %ymm1, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vpsllq	$7, %ymm0, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vpsrlq	$5, %ymm5, %ymm6
	vpxor	%ymm6, %ymm2, %ymm6
	vpxor	glob_data + 192(%rip), %ymm0, %ymm7
	vpandn	%ymm6, %ymm4, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpandn	%ymm7, %ymm6, %ymm2
	vpxor	%ymm4, %ymm2, %ymm2
	vpandn	%ymm4, %ymm7, %ymm4
	vpxor	%ymm4, %ymm6, %ymm4
	vpandn	%ymm3, %ymm1, %ymm7
	vpxor	%ymm5, %ymm7, %ymm7
	vpandn	%ymm5, %ymm3, %ymm6
	vpxor	%ymm1, %ymm6, %ymm6
	vpandn	%ymm1, %ymm5, %ymm1
	vpxor	%ymm1, %ymm3, %ymm3
	vpshufd	$57, %ymm3, %ymm5
	vpxor	%ymm5, %ymm6, %ymm5
	vpxor	%ymm0, %ymm7, %ymm1
	vpsrlq	$35, %ymm4, %ymm6
	vpsllq	$29, %ymm4, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm6, %ymm2, %ymm7
	vpsrlq	$33, %ymm0, %ymm2
	vpsllq	$31, %ymm0, %ymm6
	vpor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm2, %ymm5, %ymm2
	vpsrlq	$51, %ymm4, %ymm6
	vpsllq	$13, %ymm4, %ymm5
	vpor	%ymm5, %ymm6, %ymm6
	vpxor	%ymm6, %ymm3, %ymm5
	vpxor	%ymm2, %ymm7, %ymm3
	vpermq	$147, %ymm4, %ymm4
	vpshufd	$78, %ymm3, %ymm6
	vpshufd	$57, %ymm2, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vperm2i128	$1, %ymm0, %ymm0, %ymm0
	vpxor	%ymm6, %ymm4, %ymm4
	vpshufd	$57, %ymm1, %ymm6
	vpxor	%ymm6, %ymm0, %ymm6
	vpsllq	$7, %ymm4, %ymm0
	vpxor	%ymm0, %ymm2, %ymm0
	vpsrlq	$5, %ymm6, %ymm7
	vpxor	%ymm7, %ymm5, %ymm2
	vpxor	glob_data + 160(%rip), %ymm4, %ymm7
	vpandn	%ymm3, %ymm1, %ymm4
	vpxor	%ymm7, %ymm4, %ymm4
	vpandn	%ymm7, %ymm3, %ymm5
	vpxor	%ymm1, %ymm5, %ymm5
	vpandn	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm3, %ymm1
	vpandn	%ymm2, %ymm0, %ymm7
	vpxor	%ymm6, %ymm7, %ymm7
	vpandn	%ymm6, %ymm2, %ymm3
	vpxor	%ymm0, %ymm3, %ymm3
	vpandn	%ymm0, %ymm6, %ymm0
	vpxor	%ymm0, %ymm2, %ymm0
	vmovdqu	%ymm0, (%rdi)
	vmovdqu	%ymm4, 32(%rdi)
	vmovdqu	%ymm7, 64(%rdi)
	vmovdqu	%ymm5, 96(%rdi)
	vmovdqu	%ymm3, 128(%rdi)
	vmovdqu	%ymm1, 160(%rdi)
	ret
	.data
	.p2align	5
glob_data:
G$ARCCT19:
	.byte	183, 177, 209, 241, 146,  60, 248, 130, 183, 177, 209, 241, 146,  60, 248, 130
	.byte	183, 177, 209, 241, 146,  60, 248, 130, 183, 177, 209, 241, 146,  60, 248, 130
G$ARCCT18:
	.byte	157,  53, 135, 114,  43, 182, 179,  96, 157,  53, 135, 114,  43, 182, 179,  96
	.byte	157,  53, 135, 114,  43, 182, 179,  96, 157,  53, 135, 114,  43, 182, 179,  96
G$ARCCT17:
	.byte	107, 185,  60, 243, 229,  49,  75, 193, 107, 185,  60, 243, 229,  49,  75, 193
	.byte	107, 185,  60, 243, 229,  49,  75, 193, 107, 185,  60, 243, 229,  49,  75, 193
G$ARCCT16:
	.byte	117,  61, 242, 115, 190, 171,   2,  95, 117,  61, 242, 115, 190, 171,   2,  95
	.byte	117,  61, 242, 115, 190, 171,   2,  95, 117,  61, 242, 115, 190, 171,   2,  95
G$ARCCT15:
	.byte	 95, 193, 167, 244, 120,  37, 218,  61,  95, 193, 167, 244, 120,  37, 218,  61
	.byte	 95, 193, 167, 244, 120,  37, 218,  61,  95, 193, 167, 244, 120,  37, 218,  61
G$ARCCT14:
	.byte	 53,  69,  93, 117,  49, 159, 237, 155,  53,  69,  93, 117,  49, 159, 237, 155
	.byte	 53,  69,  93, 117,  49, 159, 237, 155,  53,  69,  93, 117,  49, 159, 237, 155
G$ARCCT13:
	.byte	 43, 201,  18, 246, 203,  22, 165, 121,  43, 201,  18, 246, 203,  22, 165, 121
	.byte	 43, 201,  18, 246, 203,  22, 165, 121,  43, 201,  18, 246, 203,  22, 165, 121
G$ARCCT12:
	.byte	 29,  77, 200, 118, 132, 144, 124, 214,  29,  77, 200, 118, 132, 144, 124, 214
	.byte	 29,  77, 200, 118, 132, 144, 124, 214,  29,  77, 200, 118, 132, 144, 124, 214
G$ARCCT11:
	.byte	247, 208, 125, 247,  94,  10,  52, 180, 247, 208, 125, 247,  94,  10,  52, 180
	.byte	247, 208, 125, 247,  94,  10,  52, 180, 247, 208, 125, 247,  94,  10,  52, 180
G$ARCCT10:
	.byte	237,  84,  51, 120,  23, 132, 207,  18, 237,  84,  51, 120,  23, 132, 207,  18
	.byte	237,  84,  51, 120,  23, 132, 207,  18, 237,  84,  51, 120,  23, 132, 207,  18
G$ARCCT9:
	.byte	219, 216, 232, 248, 209, 127, 135, 240, 219, 216, 232, 248, 209, 127, 135, 240
	.byte	219, 216, 232, 248, 209, 127, 135, 240, 219, 216, 232, 248, 209, 127, 135, 240
G$ARCCT8:
	.byte	181,  92, 158, 121, 106, 249,  94,  81, 181,  92, 158, 121, 106, 249,  94,  81
	.byte	181,  92, 158, 121, 106, 249,  94,  81, 181,  92, 158, 121, 106, 249,  94,  81
G$ARCCT7:
	.byte	175, 224,  83, 250,  36, 115,  22,  47, 175, 224,  83, 250,  36, 115,  22,  47
	.byte	175, 224,  83, 250,  36, 115,  22,  47, 175, 224,  83, 250,  36, 115,  22,  47
G$ARCCT6:
	.byte	149, 100,   9, 123, 253, 234,  41, 141, 149, 100,   9, 123, 253, 234,  41, 141
	.byte	149, 100,   9, 123, 253, 234,  41, 141, 149, 100,   9, 123, 253, 234,  41, 141
G$ARCCT5:
	.byte	123, 232, 190, 251, 183, 100, 225, 107, 123, 232, 190, 251, 183, 100, 225, 107
	.byte	123, 232, 190, 251, 183, 100, 225, 107, 123, 232, 190, 251, 183, 100, 225, 107
G$ARCCT4:
	.byte	109, 108, 116, 124, 112, 222, 184, 201, 109, 108, 116, 124, 112, 222, 184, 201
	.byte	109, 108, 116, 124, 112, 222, 184, 201, 109, 108, 116, 124, 112, 222, 184, 201
G$ARCCT3:
	.byte	 87, 240,  41, 253,  10,  88, 112, 166,  87, 240,  41, 253,  10,  88, 112, 166
	.byte	 87, 240,  41, 253,  10,  88, 112, 166,  87, 240,  41, 253,  10,  88, 112, 166
G$ARCCT2:
	.byte	 61, 116, 223, 125, 195, 211,  11,   4,  61, 116, 223, 125, 195, 211,  11,   4
	.byte	 61, 116, 223, 125, 195, 211,  11,   4,  61, 116, 223, 125, 195, 211,  11,   4
G$ARCCT1:
	.byte	 43, 248, 148, 254, 157,  77, 195, 226,  43, 248, 148, 254, 157,  77, 195, 226
	.byte	 43, 248, 148, 254, 157,  77, 195, 226,  43, 248, 148, 254, 157,  77, 195, 226
G$ARCCT0:
	.byte	 21, 124,  74, 127,  86, 199, 154,  64,  21, 124,  74, 127,  86, 199, 154,  64
	.byte	 21, 124,  74, 127,  86, 199, 154,  64,  21, 124,  74, 127,  86, 199, 154,  64
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits
