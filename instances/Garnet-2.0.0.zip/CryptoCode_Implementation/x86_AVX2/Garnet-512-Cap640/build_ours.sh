#!/usr/bin/env bash
# CryptoCode 实现：我方核 + 官方胶水 + 桩（512 五档带 -maes，官方 .S 的 subword 本就是 aesenc）。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -maes"
REF=../../../Reference_Implementation/Garnet-512-Cap640
mkdir -p ../../../build
gcc $FLAGS -shared -fPIC -I $REF -I $REF/include -o ../../../build/our_Garnet-512-Cap640.so \
    garnet512_cap640_core.c $REF/CryptHash_Garnet.c $REF/stubs.c -lm
echo "built build/our_Garnet-512-Cap640.so"
