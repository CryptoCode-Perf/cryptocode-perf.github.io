#!/usr/bin/env bash
# 官方优化版：汇编核 + C 外壳（重名符号加 __c）+ 胶水 + 桩。照 fix11.py 的配方。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
REF=../../Reference_Implementation/Garnet-512-Cap896
B=../../build
mkdir -p $B
syms() { nm -g --defined-only "$1" | awk '$2 ~ /^[TDBRW]$/ {print $3}' | sort; }

gcc -c $FLAGS -o $B/asm_Garnet-512-Cap896.o Garnet_512_896.S
KEEP="garnet_512 garnet_768 garnet_1024 Garnet_768 pad_message pad_message2"
for s in $(syms $B/asm_Garnet-512-Cap896.o); do
  case " $KEEP " in *" $s "*) ;; *) objcopy --localize-symbol=$s $B/asm_Garnet-512-Cap896.o ;; esac
done

gcc -c $FLAGS -I $REF -I $REF/include -o $B/c0_Garnet-512-Cap896.o $REF/Garnet_512_896.c
CLASH=$(comm -12 <(syms $B/c0_Garnet-512-Cap896.o) <(syms $B/asm_Garnet-512-Cap896.o))
REN=""
for s in $CLASH; do REN="$REN -D$s=${s}__c"; done
gcc -c $FLAGS $REN -I $REF -I $REF/include -o $B/c_Garnet-512-Cap896.o $REF/Garnet_512_896.c
gcc -c $FLAGS -I $REF -I $REF/include -o $B/glue_Garnet-512-Cap896.o $REF/CryptHash_Garnet.c
gcc -c $FLAGS -o $B/stub_Garnet-512-Cap896.o $REF/stubs.c
gcc -shared -o $B/off_Garnet-512-Cap896.so $B/glue_Garnet-512-Cap896.o $B/c_Garnet-512-Cap896.o $B/asm_Garnet-512-Cap896.o $B/stub_Garnet-512-Cap896.o
echo "built build/off_Garnet-512-Cap896.so (renamed: $CLASH)"
