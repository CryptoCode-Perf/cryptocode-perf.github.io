#!/usr/bin/env bash
# Garnet 2.0.0 —— 六档：三方编译 + 22 长度差分 + 黄金向量 + KAT 4097
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build

echo "== [Garnet-512] 1/4 编译三方 =="
bash Reference_Implementation/Garnet-512/build_ref.sh
bash Optimized_Implementation/Garnet-512/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Garnet-512/build_ours.sh
echo "== [Garnet-512] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_Garnet-512 test/vec_Garnet-512.c -ldl
./build/vec_Garnet-512 build/ref_Garnet-512.so > build/vec_ref_Garnet-512.txt
./build/vec_Garnet-512 build/off_Garnet-512.so > build/vec_off_Garnet-512.txt
./build/vec_Garnet-512 build/our_Garnet-512.so > build/vec_our_Garnet-512.txt
cmp build/vec_ref_Garnet-512.txt build/vec_off_Garnet-512.txt
cmp build/vec_ref_Garnet-512.txt build/vec_our_Garnet-512.txt
cp build/vec_ref_Garnet-512.txt test/golden_vectors_ref_Garnet-512.txt
echo "== [Garnet-512] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_Garnet-512.so 100000 0 kat/KAT_2_12_Garnet_512_Cap1024.txt
python3 test/kat_check.py build/off_Garnet-512.so 100000 0 kat/KAT_2_12_Garnet_512_Cap1024.txt
python3 test/kat_check.py build/our_Garnet-512.so 100000 0 kat/KAT_2_12_Garnet_512_Cap1024.txt
echo "== [Garnet-512] 4/4 完成 =="

echo "== [Garnet-512-Cap512] 1/4 编译三方 =="
bash Reference_Implementation/Garnet-512-Cap512/build_ref.sh
bash Optimized_Implementation/Garnet-512-Cap512/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Garnet-512-Cap512/build_ours.sh
echo "== [Garnet-512-Cap512] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_Garnet-512-Cap512 test/vec_Garnet-512-Cap512.c -ldl
./build/vec_Garnet-512-Cap512 build/ref_Garnet-512-Cap512.so > build/vec_ref_Garnet-512-Cap512.txt
./build/vec_Garnet-512-Cap512 build/off_Garnet-512-Cap512.so > build/vec_off_Garnet-512-Cap512.txt
./build/vec_Garnet-512-Cap512 build/our_Garnet-512-Cap512.so > build/vec_our_Garnet-512-Cap512.txt
cmp build/vec_ref_Garnet-512-Cap512.txt build/vec_off_Garnet-512-Cap512.txt
cmp build/vec_ref_Garnet-512-Cap512.txt build/vec_our_Garnet-512-Cap512.txt
cp build/vec_ref_Garnet-512-Cap512.txt test/golden_vectors_ref_Garnet-512-Cap512.txt
echo "== [Garnet-512-Cap512] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_Garnet-512-Cap512.so 100000 0 kat/KAT_2_12_Garnet_512_Cap512.txt
python3 test/kat_check.py build/off_Garnet-512-Cap512.so 100000 0 kat/KAT_2_12_Garnet_512_Cap512.txt
python3 test/kat_check.py build/our_Garnet-512-Cap512.so 100000 0 kat/KAT_2_12_Garnet_512_Cap512.txt
echo "== [Garnet-512-Cap512] 4/4 完成 =="

echo "== [Garnet-512-Cap640] 1/4 编译三方 =="
bash Reference_Implementation/Garnet-512-Cap640/build_ref.sh
bash Optimized_Implementation/Garnet-512-Cap640/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Garnet-512-Cap640/build_ours.sh
echo "== [Garnet-512-Cap640] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_Garnet-512-Cap640 test/vec_Garnet-512-Cap640.c -ldl
./build/vec_Garnet-512-Cap640 build/ref_Garnet-512-Cap640.so > build/vec_ref_Garnet-512-Cap640.txt
./build/vec_Garnet-512-Cap640 build/off_Garnet-512-Cap640.so > build/vec_off_Garnet-512-Cap640.txt
./build/vec_Garnet-512-Cap640 build/our_Garnet-512-Cap640.so > build/vec_our_Garnet-512-Cap640.txt
cmp build/vec_ref_Garnet-512-Cap640.txt build/vec_off_Garnet-512-Cap640.txt
cmp build/vec_ref_Garnet-512-Cap640.txt build/vec_our_Garnet-512-Cap640.txt
cp build/vec_ref_Garnet-512-Cap640.txt test/golden_vectors_ref_Garnet-512-Cap640.txt
echo "== [Garnet-512-Cap640] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_Garnet-512-Cap640.so 100000 0 kat/KAT_2_12_Garnet_512_Cap640.txt
python3 test/kat_check.py build/off_Garnet-512-Cap640.so 100000 0 kat/KAT_2_12_Garnet_512_Cap640.txt
python3 test/kat_check.py build/our_Garnet-512-Cap640.so 100000 0 kat/KAT_2_12_Garnet_512_Cap640.txt
echo "== [Garnet-512-Cap640] 4/4 完成 =="

echo "== [Garnet-512-Cap768] 1/4 编译三方 =="
bash Reference_Implementation/Garnet-512-Cap768/build_ref.sh
bash Optimized_Implementation/Garnet-512-Cap768/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Garnet-512-Cap768/build_ours.sh
echo "== [Garnet-512-Cap768] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_Garnet-512-Cap768 test/vec_Garnet-512-Cap768.c -ldl
./build/vec_Garnet-512-Cap768 build/ref_Garnet-512-Cap768.so > build/vec_ref_Garnet-512-Cap768.txt
./build/vec_Garnet-512-Cap768 build/off_Garnet-512-Cap768.so > build/vec_off_Garnet-512-Cap768.txt
./build/vec_Garnet-512-Cap768 build/our_Garnet-512-Cap768.so > build/vec_our_Garnet-512-Cap768.txt
cmp build/vec_ref_Garnet-512-Cap768.txt build/vec_off_Garnet-512-Cap768.txt
cmp build/vec_ref_Garnet-512-Cap768.txt build/vec_our_Garnet-512-Cap768.txt
cp build/vec_ref_Garnet-512-Cap768.txt test/golden_vectors_ref_Garnet-512-Cap768.txt
echo "== [Garnet-512-Cap768] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_Garnet-512-Cap768.so 100000 0 kat/KAT_2_12_Garnet_512_Cap768.txt
python3 test/kat_check.py build/off_Garnet-512-Cap768.so 100000 0 kat/KAT_2_12_Garnet_512_Cap768.txt
python3 test/kat_check.py build/our_Garnet-512-Cap768.so 100000 0 kat/KAT_2_12_Garnet_512_Cap768.txt
echo "== [Garnet-512-Cap768] 4/4 完成 =="

echo "== [Garnet-512-Cap896] 1/4 编译三方 =="
bash Reference_Implementation/Garnet-512-Cap896/build_ref.sh
bash Optimized_Implementation/Garnet-512-Cap896/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Garnet-512-Cap896/build_ours.sh
echo "== [Garnet-512-Cap896] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_Garnet-512-Cap896 test/vec_Garnet-512-Cap896.c -ldl
./build/vec_Garnet-512-Cap896 build/ref_Garnet-512-Cap896.so > build/vec_ref_Garnet-512-Cap896.txt
./build/vec_Garnet-512-Cap896 build/off_Garnet-512-Cap896.so > build/vec_off_Garnet-512-Cap896.txt
./build/vec_Garnet-512-Cap896 build/our_Garnet-512-Cap896.so > build/vec_our_Garnet-512-Cap896.txt
cmp build/vec_ref_Garnet-512-Cap896.txt build/vec_off_Garnet-512-Cap896.txt
cmp build/vec_ref_Garnet-512-Cap896.txt build/vec_our_Garnet-512-Cap896.txt
cp build/vec_ref_Garnet-512-Cap896.txt test/golden_vectors_ref_Garnet-512-Cap896.txt
echo "== [Garnet-512-Cap896] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_Garnet-512-Cap896.so 100000 0 kat/KAT_2_12_Garnet_512_Cap896.txt
python3 test/kat_check.py build/off_Garnet-512-Cap896.so 100000 0 kat/KAT_2_12_Garnet_512_Cap896.txt
python3 test/kat_check.py build/our_Garnet-512-Cap896.so 100000 0 kat/KAT_2_12_Garnet_512_Cap896.txt
echo "== [Garnet-512-Cap896] 4/4 完成 =="

echo "== [Garnet-1024] 1/4 编译三方 =="
bash Reference_Implementation/Garnet-1024/build_ref.sh
bash Optimized_Implementation/Garnet-1024/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Garnet-1024/build_ours.sh
echo "== [Garnet-1024] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_Garnet-1024 test/vec_Garnet-1024.c -ldl
./build/vec_Garnet-1024 build/ref_Garnet-1024.so > build/vec_ref_Garnet-1024.txt
./build/vec_Garnet-1024 build/off_Garnet-1024.so > build/vec_off_Garnet-1024.txt
./build/vec_Garnet-1024 build/our_Garnet-1024.so > build/vec_our_Garnet-1024.txt
cmp build/vec_ref_Garnet-1024.txt build/vec_off_Garnet-1024.txt
cmp build/vec_ref_Garnet-1024.txt build/vec_our_Garnet-1024.txt
cp build/vec_ref_Garnet-1024.txt test/golden_vectors_ref_Garnet-1024.txt
echo "== [Garnet-1024] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_Garnet-1024.so 100000 0 kat/KAT_2_12_Garnet_1024.txt
python3 test/kat_check.py build/off_Garnet-1024.so 100000 0 kat/KAT_2_12_Garnet_1024.txt
python3 test/kat_check.py build/our_Garnet-1024.so 100000 0 kat/KAT_2_12_Garnet_1024.txt
echo "== [Garnet-1024] 4/4 完成 =="

echo "== 验证全部通过 =="
