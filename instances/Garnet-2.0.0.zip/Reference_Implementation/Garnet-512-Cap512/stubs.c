/* 自动生成：胶水固定引用 CryptHash_512/768/1024，缺的补成返回 -1 的桩。
 * 本档实现的是：CryptHash_512 */
#include <stddef.h>
int CryptHash_768(const unsigned char *m, unsigned long long b, unsigned char *d){ (void)m; (void)b; (void)d; return -1; }
int CryptHash_1024(const unsigned char *m, unsigned long long b, unsigned char *d){ (void)m; (void)b; (void)d; return -1; }
