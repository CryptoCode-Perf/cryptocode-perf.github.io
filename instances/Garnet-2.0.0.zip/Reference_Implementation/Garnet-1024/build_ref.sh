#!/usr/bin/env bash
# 官方参考版：C（REFFLAGS）+ 胶水 + 缺的 CryptHash_* 桩。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-std=c99 -Wpedantic -Wall -Wextra -O2"
mkdir -p ../../build
gcc $FLAGS -shared -fPIC -I . -I include -o ../../build/ref_Garnet-1024.so \
    CryptHash_Garnet.c Garnet_1024.c stubs.c -lm
echo "built build/ref_Garnet-1024.so"
