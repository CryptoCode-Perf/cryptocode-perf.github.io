/* Cross-validation harness for Garnet-1024: dlopen a .so, dump 1024-bit digests. */
#include <stdio.h>
#include <dlfcn.h>

typedef int (*hash_fn)(int, const unsigned char *, unsigned long long, unsigned char *);

static const unsigned blens[] = {
    0, 1, 7, 8, 9, 63, 64, 65, 127, 128, 129, 255, 256, 511, 512,
    513, 1023, 1024, 2048, 4096, 8191, 16384
};

int main(int argc, char **argv)
{
    if (argc < 2) { printf("usage: %s <so>\n", argv[0]); return 2; }
    void *h = dlopen(argv[1], RTLD_NOW);
    if (!h) { printf("dlopen failed: %s\n", dlerror()); return 2; }
    hash_fn f = (hash_fn)dlsym(h, "CryptHash");
    if (!f) { printf("no CryptHash symbol\n"); return 2; }
    static unsigned char msg[30000];
    unsigned char dig[512];
    for (unsigned i = 0; i < sizeof(blens) / sizeof(blens[0]); i++) {
        unsigned bits = blens[i];
        for (unsigned j = 0; j < (bits + 7u) / 8u; j++)
            msg[j] = (unsigned char)(j * 97u + bits * 31u + 0x9Eu);
        if (f(1024, msg, bits, dig) != 0) { printf("ERR bits=%u\n", bits); return 1; }
        printf("bits=%u ", bits);
        for (int k = 0; k < 1024 / 8; k++) printf("%02X", dig[k]);
        printf("\n");
    }
    return 0;
}
