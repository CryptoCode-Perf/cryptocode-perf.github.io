#!/usr/bin/env python3
"""KAT verification for QILIN against the official KAT file
(KAT_2_12_QILIN-1024.txt, 4097 records). Checks the first N records
(default all records) plus, if requested, a stride sample through the whole file.

Usage: python3 kat_check.py <lib.so> [n_first] [stride]
Requires: the .so must export CryptHash; run on x86_64 Linux with cpython.
"""
import ctypes
import sys

def parse_kat(path):
    recs = []
    msg_len = msg = dst_len = dst = None
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if line.startswith("Msg_Len ="):
                msg_len = int(line.split("=")[1])
                msg = None
            elif line.startswith("Msg ="):
                hexstr = line.split("=", 1)[1].strip()
                msg = bytes.fromhex(hexstr) if hexstr else b""
            elif line.startswith("Dst_Len ="):
                dst_len = int(line.split("=")[1])
            elif line.startswith("Dst ="):
                dst = bytes.fromhex(line.split("=", 1)[1].strip())
                if msg_len is None or msg is None or dst_len is None:
                    raise ValueError("Incomplete KAT record")
                if msg_len < 0 or len(msg) != (msg_len + 7) // 8:
                    raise ValueError("KAT message length mismatch")
                if dst_len <= 0 or len(dst) * 8 != dst_len:
                    raise ValueError("KAT digest length mismatch")
                recs.append((msg_len, msg, dst_len, dst))
                msg_len = msg = dst_len = dst = None
    return recs

def main():
    so_path = sys.argv[1]
    n_first = int(sys.argv[2]) if len(sys.argv) > 2 else 100000
    stride = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    kat_path = sys.argv[4] if len(sys.argv) > 4 else "kat/KAT_2_12_QILIN-1024.txt"

    lib = ctypes.CDLL(so_path)
    lib.CryptHash.argtypes = [ctypes.c_int, ctypes.c_char_p,
                              ctypes.c_ulonglong, ctypes.c_char_p]

    recs = parse_kat(kat_path)
    if len(recs) != 4097:
        raise RuntimeError("Expected exactly 4097 KAT records, got %d" % len(recs))
    if [record[0] for record in recs] != list(range(4097)):
        raise RuntimeError("KAT message lengths must cover 0 through 4096 exactly once, in order")
    if len({record[2] for record in recs}) != 1:
        raise RuntimeError("KAT digest lengths are inconsistent")
    picks = list(range(min(n_first, len(recs))))
    if stride > 0:
        picks += list(range(0, len(recs), stride))
        picks = sorted(set(picks))

    if not picks:
        raise ValueError("KAT selection is empty")

    bad = 0
    for i in picks:
        msg_len, msg, dst_len, dst = recs[i]
        buf = ctypes.create_string_buffer(dst_len // 8 + 64)
        rc = lib.CryptHash(dst_len, msg, msg_len, buf)
        got = buf.raw[:dst_len // 8]
        if rc != 0 or got != dst:
            bad += 1
            print("FAIL rec#%d msg_len=%d dst_len=%d rc=%d" % (i, msg_len, dst_len, rc))
            print("  want", dst.hex()[:64], "...")
            print("  got ", got.hex()[:64], "...")
    print("KAT: checked=%d match=%d total_records=%d pass=%s"
          % (len(picks), len(picks) - bad, len(recs), bad == 0))
    return 0 if bad == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
