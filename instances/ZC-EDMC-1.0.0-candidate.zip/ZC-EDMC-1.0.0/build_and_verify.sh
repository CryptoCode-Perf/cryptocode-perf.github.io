#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/official_tree/Implementations build/official_tree/lib
cp -R official_tree/lib/. build/official_tree/lib/
cp -R Reference_Implementation Optimized_Implementation build/official_tree/Implementations/
for width in 1280 1536; do
 bash "CryptoCode_Implementation/$width/build.sh"
 for kind in Reference Optimized; do
  if [ "$kind" = Reference ]; then impl=plain; flags=-O2; else impl=AVX2; flags="-O3 -mavx2"; fi
  gcc $flags -fPIC -shared -Wl,-z,defs -Ibuild/official_tree/lib/common "build/official_tree/Implementations/${kind}_Implementation/ZC-EDMC-${width}-512/CryptHash_AlgorithmInstance.c" "build/official_tree/lib/low/ZuD-${width}/${impl}/ZuD${width}-${impl}.c" -o "build/${kind}-${width}.so"
 done
 if [ "$width" = 1280 ]; then sizes="512 768"; else sizes="512 768 1024"; fi
 for bits in $sizes; do
  for kind in CryptoCode Reference Optimized; do python3 "test/kat_${width}_${bits}.py" "build/${kind}-${width}.so" 100000 0 "kat/ZC-EDMC-${width}-${bits}.txt"; done
 done
done

python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
build/guard_check build/CryptoCode-1280.so 512
build/guard_check build/CryptoCode-1280.so 768
build/guard_check build/CryptoCode-1536.so 512
build/guard_check build/CryptoCode-1536.so 768
build/guard_check build/CryptoCode-1536.so 1024
