# Neulaser-1024

Algorithm: Neulaser | Digest bits: 1024 | Form: 标量 C

Contents: implementation source/, public header Neulaser-1024.h, prebuilt Neulaser-1024.so,
KAT vector KAT_2_12_Neulaser-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): a9fee0402edcdb65cd871aa461876010b58c2193e177af893ee6fe14c06404a4
Speed (cpB, lower is faster): reference 76.80 / official-optimized 44.20 / optimized 35.42
Speedup: GM(S1-S8) 1.25x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
