/*
The software is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).
*/

#include "CryptHash_AlgorithmInstance.h"

#include <stdint.h>
#include <stddef.h>
#include <string.h>

#define NL_P 4294967291ULL
#define NL_P32 4294967291U
#define NL_MAX_MU 5
#define NL_WORDS_PER_MODULE 16
#define NL_MAX_STATE_BYTES (NL_MAX_MU * NL_WORDS_PER_MODULE * 4)
#define NL_MAX_V_BYTES 136
#define NL_MAX_K_BYTES 184
#define NL_MAX_OUTPUT_BYTES 264
#define NL_LENGTH_FIELD_BITS 64
#define NL_BLANK_ROUNDS 32

#if defined(_MSC_VER)
#define NL_INLINE static __forceinline
#define NL_RESTRICT __restrict
#else
#define NL_INLINE static inline __attribute__((always_inline))
#define NL_RESTRICT __restrict__
#endif

typedef struct
{
    int n;
    int k;
    int v;
    int mu;
} NL_Params;

static const uint8_t NL_SBOX[256] = {
    0xA7, 0x12, 0x9B, 0x70, 0xB9, 0xEA, 0x4C, 0x73, 0x4E, 0x14, 0x01, 0x33, 0x52, 0x31, 0x2B, 0x9C,
    0xB5, 0xF5, 0x98, 0x21, 0xF4, 0xBE, 0x0B, 0x2A, 0xBB, 0xAC, 0xEC, 0x8D, 0xE1, 0x90, 0x3A, 0x38,
    0x48, 0xD2, 0x68, 0x0F, 0xDE, 0x56, 0xE4, 0x0E, 0xE8, 0xED, 0xCD, 0xE5, 0xF1, 0x05, 0x61, 0x86,
    0xA9, 0x13, 0x22, 0x2D, 0x02, 0x9E, 0xB2, 0x7E, 0x84, 0xDC, 0x3C, 0x1E, 0x69, 0xE7, 0x8E, 0xEB,
    0xB6, 0xD8, 0xFB, 0xBF, 0xA6, 0x4A, 0x15, 0x23, 0xFD, 0xA4, 0x5F, 0x71, 0xE0, 0x8B, 0x95, 0xB8,
    0xE6, 0x08, 0x82, 0x34, 0x92, 0x65, 0x60, 0xE9, 0x8C, 0xAB, 0x10, 0xC1, 0xC4, 0x0C, 0x37, 0x4F,
    0x46, 0xD6, 0x1B, 0x30, 0x83, 0x7B, 0xE2, 0xA5, 0x93, 0x3F, 0xDD, 0xCF, 0xCB, 0xF7, 0xAD, 0xB3,
    0xD0, 0x47, 0x1A, 0xC6, 0x6A, 0xB0, 0x9D, 0x7D, 0x26, 0x64, 0x87, 0x25, 0xD5, 0x99, 0x81, 0xFA,
    0x2F, 0x28, 0xFE, 0xEE, 0x89, 0x39, 0x4D, 0xF6, 0x27, 0xF2, 0x51, 0x19, 0x18, 0xD9, 0x03, 0x7F,
    0x8A, 0xD1, 0xC0, 0x43, 0x3D, 0xC3, 0xCC, 0xC5, 0x04, 0x55, 0xB1, 0x3E, 0x58, 0xBC, 0xCE, 0xAA,
    0x07, 0x42, 0x96, 0x77, 0xD3, 0x6E, 0x88, 0x45, 0xDB, 0x1D, 0x20, 0x6F, 0x44, 0xDF, 0x66, 0xA8,
    0x32, 0x54, 0xA1, 0x0A, 0x7C, 0x63, 0x94, 0x97, 0xF0, 0x76, 0x72, 0x6B, 0xEF, 0x3B, 0x35, 0x80,
    0x57, 0x74, 0x1F, 0x36, 0xF9, 0xAF, 0x6C, 0x06, 0x53, 0x24, 0xC9, 0xF3, 0xE3, 0xC7, 0x40, 0xFC,
    0x5B, 0x16, 0x0D, 0xDA, 0x9A, 0xC8, 0x75, 0xF8, 0x91, 0xBD, 0x8F, 0x59, 0xA2, 0xAE, 0x4B, 0xA3,
    0x1C, 0xFF, 0xD7, 0x50, 0x79, 0x2E, 0x17, 0x85, 0x41, 0x9F, 0x2C, 0x5C, 0xBA, 0x7A, 0xCA, 0x6D,
    0x67, 0x11, 0xA0, 0xC2, 0xB7, 0x29, 0x00, 0x49, 0x78, 0x62, 0x5E, 0x5A, 0xB4, 0xD4, 0x09, 0x5D};

NL_INLINE uint32_t nl_rotl32(uint32_t x, unsigned int r)
{
    r &= 31U;
    return r ? ((x << r) | (x >> (32U - r))) : x;
}

NL_INLINE uint32_t nl_redp32(uint32_t x)
{
    return x >= NL_P32 ? x - NL_P32 : x;
}

/* p = 2^32 - 5, hence 2^32 == 5 (mod p).  The largest value passed by
 * Neulaser's linear core needs two folds and at most one subtraction.  This
 * replaces the particularly expensive 64-bit integer division generated for
 * x % p.  Montgomery reduction is useful for chains of products in a generic
 * modulus; for these fixed small coefficients the pseudo-Mersenne fold is
 * both simpler and faster. */
NL_INLINE uint32_t nl_redp64(uint64_t x)
{
    uint64_t t = (uint64_t)(uint32_t)x + 5ULL * (x >> 32);
    t = (uint64_t)(uint32_t)t + 5ULL * (t >> 32);
    return (uint32_t)(t >= NL_P ? t - NL_P : t);
}

NL_INLINE uint32_t nl_load32_be(const uint8_t x[4])
{
    return ((uint32_t)x[0] << 24) | ((uint32_t)x[1] << 16) | ((uint32_t)x[2] << 8) | (uint32_t)x[3];
}

NL_INLINE void nl_store32_be(uint8_t out[4], uint32_t x)
{
    out[0] = (uint8_t)(x >> 24);
    out[1] = (uint8_t)(x >> 16);
    out[2] = (uint8_t)(x >> 8);
    out[3] = (uint8_t)x;
}

NL_INLINE uint32_t nl_linear_layer(uint32_t x, int layer)
{
    if (layer == 0)
        return x ^ nl_rotl32(x, 2) ^ nl_rotl32(x, 10) ^ nl_rotl32(x, 18) ^ nl_rotl32(x, 24);
    return x ^ nl_rotl32(x, 8) ^ nl_rotl32(x, 14) ^ nl_rotl32(x, 22) ^ nl_rotl32(x, 30);
}

NL_INLINE uint32_t nl_sbox_word(uint32_t x)
{
    return ((uint32_t)NL_SBOX[(x >> 24) & 0xFFU] << 24) |
           ((uint32_t)NL_SBOX[(x >> 16) & 0xFFU] << 16) |
           ((uint32_t)NL_SBOX[(x >> 8) & 0xFFU] << 8) |
           (uint32_t)NL_SBOX[x & 0xFFU];
}

NL_INLINE uint32_t nl_F(uint32_t r0, uint32_t r1, uint32_t r2, uint32_t r3)
{
    uint32_t a = r0 + r1;
    uint32_t b = r2 ^ r3;
    uint32_t u = (a << 16) | (b >> 16);
    uint32_t v = (b << 16) | (a >> 16);
    uint32_t pl = nl_sbox_word(nl_linear_layer(u, 0));
    uint32_t pr = nl_sbox_word(nl_linear_layer(v, 1));
    return (pl ^ nl_rotl32(r1, 8)) + pr;
}

NL_INLINE uint32_t nl_linear_core(const uint32_t L[NL_WORDS_PER_MODULE])
{
    uint64_t x = 0;
    x += 8193ULL * (uint64_t)L[0];
    x += 16777217ULL * (uint64_t)L[4];
    x += 4194304ULL * (uint64_t)L[9];
    x += 9ULL * (uint64_t)L[13];
    x += 524288ULL * (uint64_t)L[15];
    return nl_redp64(x);
}

static void nl_offsets(int mu, int which, int *a, int *b)
{
    static const int tab3[4][2] = {{0, 1}, {1, 2}, {2, 0}, {1, 0}};
    static const int tab4[4][2] = {{0, 1}, {2, 0}, {1, 3}, {3, 2}};
    static const int tab5[4][2] = {{0, 1}, {2, 4}, {3, 1}, {4, 3}};
    const int(*tab)[2] = (mu == 3) ? tab3 : ((mu == 4) ? tab4 : tab5);
    *a = tab[which][0];
    *b = tab[which][1];
}

NL_INLINE int nl_mod_index(int x, int mu)
{
    x %= mu;
    return x < 0 ? x + mu : x;
}


/* ======================= 由 build_noshell.py 注入 =======================
 * 只替换核心轮函数 nl_update；官方外壳的其余部分逐字未改。
 * 轮体：gen/out/nl_noshell_5.c（与 nl_update 同 TU、static、u32 ABI）。
 */
/* 单因子：写回改 volatile 存储，禁 SLP store-merging（mu=5） */
/* SBOX4-EXPERIMENT: 四张预移位表，等价改写，KAT 必须全过。gen/gen_sbox4.py */
/* SCALAR-ISLAND-EXPERIMENT mu=5：S 盒岛由「向量往返」改为直接 nl_sw。
   等价改写（非消融），KAT 必须全过。生成器 gen/gen_scalar_island.py */
/* 由 gen_vec.py 生成（勿手改）。S 盒 = 标量 256 字节字节表（neulaser2 单因子实验）。 */
#include <stdint.h>
#include <immintrin.h>

#define NL_PV 4294967291U


static inline uint32_t nl_rot(uint32_t x, int r)
{
    return (uint32_t)((x << r) | (x >> (32 - r)));
}

static inline uint32_t nl_rdp32(uint32_t x)
{
    return x >= NL_PV ? (uint32_t)(x - NL_PV) : x;
}

static inline uint32_t nl_rdp64(uint64_t x)
{
    uint64_t t = (uint64_t)(uint32_t)x + 5ULL * (x >> 32);
    t = (uint64_t)(uint32_t)t + 5ULL * (t >> 32);
    return (uint32_t)(t >= (uint64_t)NL_PV ? t - (uint64_t)NL_PV : t);
}

static inline uint32_t nl_ll0(uint32_t x)
{
    return x ^ nl_rot(x, 2) ^ nl_rot(x, 10) ^ nl_rot(x, 18) ^ nl_rot(x, 24);
}

static inline uint32_t nl_ll1(uint32_t x)
{
    return x ^ nl_rot(x, 8) ^ nl_rot(x, 14) ^ nl_rot(x, 22) ^ nl_rot(x, 30);
}

/* 标量 S 盒：256 字节字节表，直接 L1 查表（口径照官方 nl_sbox_word :101-107）。 */
static const uint32_t NL_SB0[256] = {
    0xA7000000U, 0x12000000U, 0x9B000000U, 0x70000000U, 0xB9000000U, 0xEA000000U, 0x4C000000U, 0x73000000U,
    0x4E000000U, 0x14000000U, 0x01000000U, 0x33000000U, 0x52000000U, 0x31000000U, 0x2B000000U, 0x9C000000U,
    0xB5000000U, 0xF5000000U, 0x98000000U, 0x21000000U, 0xF4000000U, 0xBE000000U, 0x0B000000U, 0x2A000000U,
    0xBB000000U, 0xAC000000U, 0xEC000000U, 0x8D000000U, 0xE1000000U, 0x90000000U, 0x3A000000U, 0x38000000U,
    0x48000000U, 0xD2000000U, 0x68000000U, 0x0F000000U, 0xDE000000U, 0x56000000U, 0xE4000000U, 0x0E000000U,
    0xE8000000U, 0xED000000U, 0xCD000000U, 0xE5000000U, 0xF1000000U, 0x05000000U, 0x61000000U, 0x86000000U,
    0xA9000000U, 0x13000000U, 0x22000000U, 0x2D000000U, 0x02000000U, 0x9E000000U, 0xB2000000U, 0x7E000000U,
    0x84000000U, 0xDC000000U, 0x3C000000U, 0x1E000000U, 0x69000000U, 0xE7000000U, 0x8E000000U, 0xEB000000U,
    0xB6000000U, 0xD8000000U, 0xFB000000U, 0xBF000000U, 0xA6000000U, 0x4A000000U, 0x15000000U, 0x23000000U,
    0xFD000000U, 0xA4000000U, 0x5F000000U, 0x71000000U, 0xE0000000U, 0x8B000000U, 0x95000000U, 0xB8000000U,
    0xE6000000U, 0x08000000U, 0x82000000U, 0x34000000U, 0x92000000U, 0x65000000U, 0x60000000U, 0xE9000000U,
    0x8C000000U, 0xAB000000U, 0x10000000U, 0xC1000000U, 0xC4000000U, 0x0C000000U, 0x37000000U, 0x4F000000U,
    0x46000000U, 0xD6000000U, 0x1B000000U, 0x30000000U, 0x83000000U, 0x7B000000U, 0xE2000000U, 0xA5000000U,
    0x93000000U, 0x3F000000U, 0xDD000000U, 0xCF000000U, 0xCB000000U, 0xF7000000U, 0xAD000000U, 0xB3000000U,
    0xD0000000U, 0x47000000U, 0x1A000000U, 0xC6000000U, 0x6A000000U, 0xB0000000U, 0x9D000000U, 0x7D000000U,
    0x26000000U, 0x64000000U, 0x87000000U, 0x25000000U, 0xD5000000U, 0x99000000U, 0x81000000U, 0xFA000000U,
    0x2F000000U, 0x28000000U, 0xFE000000U, 0xEE000000U, 0x89000000U, 0x39000000U, 0x4D000000U, 0xF6000000U,
    0x27000000U, 0xF2000000U, 0x51000000U, 0x19000000U, 0x18000000U, 0xD9000000U, 0x03000000U, 0x7F000000U,
    0x8A000000U, 0xD1000000U, 0xC0000000U, 0x43000000U, 0x3D000000U, 0xC3000000U, 0xCC000000U, 0xC5000000U,
    0x04000000U, 0x55000000U, 0xB1000000U, 0x3E000000U, 0x58000000U, 0xBC000000U, 0xCE000000U, 0xAA000000U,
    0x07000000U, 0x42000000U, 0x96000000U, 0x77000000U, 0xD3000000U, 0x6E000000U, 0x88000000U, 0x45000000U,
    0xDB000000U, 0x1D000000U, 0x20000000U, 0x6F000000U, 0x44000000U, 0xDF000000U, 0x66000000U, 0xA8000000U,
    0x32000000U, 0x54000000U, 0xA1000000U, 0x0A000000U, 0x7C000000U, 0x63000000U, 0x94000000U, 0x97000000U,
    0xF0000000U, 0x76000000U, 0x72000000U, 0x6B000000U, 0xEF000000U, 0x3B000000U, 0x35000000U, 0x80000000U,
    0x57000000U, 0x74000000U, 0x1F000000U, 0x36000000U, 0xF9000000U, 0xAF000000U, 0x6C000000U, 0x06000000U,
    0x53000000U, 0x24000000U, 0xC9000000U, 0xF3000000U, 0xE3000000U, 0xC7000000U, 0x40000000U, 0xFC000000U,
    0x5B000000U, 0x16000000U, 0x0D000000U, 0xDA000000U, 0x9A000000U, 0xC8000000U, 0x75000000U, 0xF8000000U,
    0x91000000U, 0xBD000000U, 0x8F000000U, 0x59000000U, 0xA2000000U, 0xAE000000U, 0x4B000000U, 0xA3000000U,
    0x1C000000U, 0xFF000000U, 0xD7000000U, 0x50000000U, 0x79000000U, 0x2E000000U, 0x17000000U, 0x85000000U,
    0x41000000U, 0x9F000000U, 0x2C000000U, 0x5C000000U, 0xBA000000U, 0x7A000000U, 0xCA000000U, 0x6D000000U,
    0x67000000U, 0x11000000U, 0xA0000000U, 0xC2000000U, 0xB7000000U, 0x29000000U, 0x00000000U, 0x49000000U,
    0x78000000U, 0x62000000U, 0x5E000000U, 0x5A000000U, 0xB4000000U, 0xD4000000U, 0x09000000U, 0x5D000000U,
};
static const uint32_t NL_SB1[256] = {
    0x00A70000U, 0x00120000U, 0x009B0000U, 0x00700000U, 0x00B90000U, 0x00EA0000U, 0x004C0000U, 0x00730000U,
    0x004E0000U, 0x00140000U, 0x00010000U, 0x00330000U, 0x00520000U, 0x00310000U, 0x002B0000U, 0x009C0000U,
    0x00B50000U, 0x00F50000U, 0x00980000U, 0x00210000U, 0x00F40000U, 0x00BE0000U, 0x000B0000U, 0x002A0000U,
    0x00BB0000U, 0x00AC0000U, 0x00EC0000U, 0x008D0000U, 0x00E10000U, 0x00900000U, 0x003A0000U, 0x00380000U,
    0x00480000U, 0x00D20000U, 0x00680000U, 0x000F0000U, 0x00DE0000U, 0x00560000U, 0x00E40000U, 0x000E0000U,
    0x00E80000U, 0x00ED0000U, 0x00CD0000U, 0x00E50000U, 0x00F10000U, 0x00050000U, 0x00610000U, 0x00860000U,
    0x00A90000U, 0x00130000U, 0x00220000U, 0x002D0000U, 0x00020000U, 0x009E0000U, 0x00B20000U, 0x007E0000U,
    0x00840000U, 0x00DC0000U, 0x003C0000U, 0x001E0000U, 0x00690000U, 0x00E70000U, 0x008E0000U, 0x00EB0000U,
    0x00B60000U, 0x00D80000U, 0x00FB0000U, 0x00BF0000U, 0x00A60000U, 0x004A0000U, 0x00150000U, 0x00230000U,
    0x00FD0000U, 0x00A40000U, 0x005F0000U, 0x00710000U, 0x00E00000U, 0x008B0000U, 0x00950000U, 0x00B80000U,
    0x00E60000U, 0x00080000U, 0x00820000U, 0x00340000U, 0x00920000U, 0x00650000U, 0x00600000U, 0x00E90000U,
    0x008C0000U, 0x00AB0000U, 0x00100000U, 0x00C10000U, 0x00C40000U, 0x000C0000U, 0x00370000U, 0x004F0000U,
    0x00460000U, 0x00D60000U, 0x001B0000U, 0x00300000U, 0x00830000U, 0x007B0000U, 0x00E20000U, 0x00A50000U,
    0x00930000U, 0x003F0000U, 0x00DD0000U, 0x00CF0000U, 0x00CB0000U, 0x00F70000U, 0x00AD0000U, 0x00B30000U,
    0x00D00000U, 0x00470000U, 0x001A0000U, 0x00C60000U, 0x006A0000U, 0x00B00000U, 0x009D0000U, 0x007D0000U,
    0x00260000U, 0x00640000U, 0x00870000U, 0x00250000U, 0x00D50000U, 0x00990000U, 0x00810000U, 0x00FA0000U,
    0x002F0000U, 0x00280000U, 0x00FE0000U, 0x00EE0000U, 0x00890000U, 0x00390000U, 0x004D0000U, 0x00F60000U,
    0x00270000U, 0x00F20000U, 0x00510000U, 0x00190000U, 0x00180000U, 0x00D90000U, 0x00030000U, 0x007F0000U,
    0x008A0000U, 0x00D10000U, 0x00C00000U, 0x00430000U, 0x003D0000U, 0x00C30000U, 0x00CC0000U, 0x00C50000U,
    0x00040000U, 0x00550000U, 0x00B10000U, 0x003E0000U, 0x00580000U, 0x00BC0000U, 0x00CE0000U, 0x00AA0000U,
    0x00070000U, 0x00420000U, 0x00960000U, 0x00770000U, 0x00D30000U, 0x006E0000U, 0x00880000U, 0x00450000U,
    0x00DB0000U, 0x001D0000U, 0x00200000U, 0x006F0000U, 0x00440000U, 0x00DF0000U, 0x00660000U, 0x00A80000U,
    0x00320000U, 0x00540000U, 0x00A10000U, 0x000A0000U, 0x007C0000U, 0x00630000U, 0x00940000U, 0x00970000U,
    0x00F00000U, 0x00760000U, 0x00720000U, 0x006B0000U, 0x00EF0000U, 0x003B0000U, 0x00350000U, 0x00800000U,
    0x00570000U, 0x00740000U, 0x001F0000U, 0x00360000U, 0x00F90000U, 0x00AF0000U, 0x006C0000U, 0x00060000U,
    0x00530000U, 0x00240000U, 0x00C90000U, 0x00F30000U, 0x00E30000U, 0x00C70000U, 0x00400000U, 0x00FC0000U,
    0x005B0000U, 0x00160000U, 0x000D0000U, 0x00DA0000U, 0x009A0000U, 0x00C80000U, 0x00750000U, 0x00F80000U,
    0x00910000U, 0x00BD0000U, 0x008F0000U, 0x00590000U, 0x00A20000U, 0x00AE0000U, 0x004B0000U, 0x00A30000U,
    0x001C0000U, 0x00FF0000U, 0x00D70000U, 0x00500000U, 0x00790000U, 0x002E0000U, 0x00170000U, 0x00850000U,
    0x00410000U, 0x009F0000U, 0x002C0000U, 0x005C0000U, 0x00BA0000U, 0x007A0000U, 0x00CA0000U, 0x006D0000U,
    0x00670000U, 0x00110000U, 0x00A00000U, 0x00C20000U, 0x00B70000U, 0x00290000U, 0x00000000U, 0x00490000U,
    0x00780000U, 0x00620000U, 0x005E0000U, 0x005A0000U, 0x00B40000U, 0x00D40000U, 0x00090000U, 0x005D0000U,
};
static const uint32_t NL_SB2[256] = {
    0x0000A700U, 0x00001200U, 0x00009B00U, 0x00007000U, 0x0000B900U, 0x0000EA00U, 0x00004C00U, 0x00007300U,
    0x00004E00U, 0x00001400U, 0x00000100U, 0x00003300U, 0x00005200U, 0x00003100U, 0x00002B00U, 0x00009C00U,
    0x0000B500U, 0x0000F500U, 0x00009800U, 0x00002100U, 0x0000F400U, 0x0000BE00U, 0x00000B00U, 0x00002A00U,
    0x0000BB00U, 0x0000AC00U, 0x0000EC00U, 0x00008D00U, 0x0000E100U, 0x00009000U, 0x00003A00U, 0x00003800U,
    0x00004800U, 0x0000D200U, 0x00006800U, 0x00000F00U, 0x0000DE00U, 0x00005600U, 0x0000E400U, 0x00000E00U,
    0x0000E800U, 0x0000ED00U, 0x0000CD00U, 0x0000E500U, 0x0000F100U, 0x00000500U, 0x00006100U, 0x00008600U,
    0x0000A900U, 0x00001300U, 0x00002200U, 0x00002D00U, 0x00000200U, 0x00009E00U, 0x0000B200U, 0x00007E00U,
    0x00008400U, 0x0000DC00U, 0x00003C00U, 0x00001E00U, 0x00006900U, 0x0000E700U, 0x00008E00U, 0x0000EB00U,
    0x0000B600U, 0x0000D800U, 0x0000FB00U, 0x0000BF00U, 0x0000A600U, 0x00004A00U, 0x00001500U, 0x00002300U,
    0x0000FD00U, 0x0000A400U, 0x00005F00U, 0x00007100U, 0x0000E000U, 0x00008B00U, 0x00009500U, 0x0000B800U,
    0x0000E600U, 0x00000800U, 0x00008200U, 0x00003400U, 0x00009200U, 0x00006500U, 0x00006000U, 0x0000E900U,
    0x00008C00U, 0x0000AB00U, 0x00001000U, 0x0000C100U, 0x0000C400U, 0x00000C00U, 0x00003700U, 0x00004F00U,
    0x00004600U, 0x0000D600U, 0x00001B00U, 0x00003000U, 0x00008300U, 0x00007B00U, 0x0000E200U, 0x0000A500U,
    0x00009300U, 0x00003F00U, 0x0000DD00U, 0x0000CF00U, 0x0000CB00U, 0x0000F700U, 0x0000AD00U, 0x0000B300U,
    0x0000D000U, 0x00004700U, 0x00001A00U, 0x0000C600U, 0x00006A00U, 0x0000B000U, 0x00009D00U, 0x00007D00U,
    0x00002600U, 0x00006400U, 0x00008700U, 0x00002500U, 0x0000D500U, 0x00009900U, 0x00008100U, 0x0000FA00U,
    0x00002F00U, 0x00002800U, 0x0000FE00U, 0x0000EE00U, 0x00008900U, 0x00003900U, 0x00004D00U, 0x0000F600U,
    0x00002700U, 0x0000F200U, 0x00005100U, 0x00001900U, 0x00001800U, 0x0000D900U, 0x00000300U, 0x00007F00U,
    0x00008A00U, 0x0000D100U, 0x0000C000U, 0x00004300U, 0x00003D00U, 0x0000C300U, 0x0000CC00U, 0x0000C500U,
    0x00000400U, 0x00005500U, 0x0000B100U, 0x00003E00U, 0x00005800U, 0x0000BC00U, 0x0000CE00U, 0x0000AA00U,
    0x00000700U, 0x00004200U, 0x00009600U, 0x00007700U, 0x0000D300U, 0x00006E00U, 0x00008800U, 0x00004500U,
    0x0000DB00U, 0x00001D00U, 0x00002000U, 0x00006F00U, 0x00004400U, 0x0000DF00U, 0x00006600U, 0x0000A800U,
    0x00003200U, 0x00005400U, 0x0000A100U, 0x00000A00U, 0x00007C00U, 0x00006300U, 0x00009400U, 0x00009700U,
    0x0000F000U, 0x00007600U, 0x00007200U, 0x00006B00U, 0x0000EF00U, 0x00003B00U, 0x00003500U, 0x00008000U,
    0x00005700U, 0x00007400U, 0x00001F00U, 0x00003600U, 0x0000F900U, 0x0000AF00U, 0x00006C00U, 0x00000600U,
    0x00005300U, 0x00002400U, 0x0000C900U, 0x0000F300U, 0x0000E300U, 0x0000C700U, 0x00004000U, 0x0000FC00U,
    0x00005B00U, 0x00001600U, 0x00000D00U, 0x0000DA00U, 0x00009A00U, 0x0000C800U, 0x00007500U, 0x0000F800U,
    0x00009100U, 0x0000BD00U, 0x00008F00U, 0x00005900U, 0x0000A200U, 0x0000AE00U, 0x00004B00U, 0x0000A300U,
    0x00001C00U, 0x0000FF00U, 0x0000D700U, 0x00005000U, 0x00007900U, 0x00002E00U, 0x00001700U, 0x00008500U,
    0x00004100U, 0x00009F00U, 0x00002C00U, 0x00005C00U, 0x0000BA00U, 0x00007A00U, 0x0000CA00U, 0x00006D00U,
    0x00006700U, 0x00001100U, 0x0000A000U, 0x0000C200U, 0x0000B700U, 0x00002900U, 0x00000000U, 0x00004900U,
    0x00007800U, 0x00006200U, 0x00005E00U, 0x00005A00U, 0x0000B400U, 0x0000D400U, 0x00000900U, 0x00005D00U,
};
static const uint32_t NL_SB3[256] = {
    0x000000A7U, 0x00000012U, 0x0000009BU, 0x00000070U, 0x000000B9U, 0x000000EAU, 0x0000004CU, 0x00000073U,
    0x0000004EU, 0x00000014U, 0x00000001U, 0x00000033U, 0x00000052U, 0x00000031U, 0x0000002BU, 0x0000009CU,
    0x000000B5U, 0x000000F5U, 0x00000098U, 0x00000021U, 0x000000F4U, 0x000000BEU, 0x0000000BU, 0x0000002AU,
    0x000000BBU, 0x000000ACU, 0x000000ECU, 0x0000008DU, 0x000000E1U, 0x00000090U, 0x0000003AU, 0x00000038U,
    0x00000048U, 0x000000D2U, 0x00000068U, 0x0000000FU, 0x000000DEU, 0x00000056U, 0x000000E4U, 0x0000000EU,
    0x000000E8U, 0x000000EDU, 0x000000CDU, 0x000000E5U, 0x000000F1U, 0x00000005U, 0x00000061U, 0x00000086U,
    0x000000A9U, 0x00000013U, 0x00000022U, 0x0000002DU, 0x00000002U, 0x0000009EU, 0x000000B2U, 0x0000007EU,
    0x00000084U, 0x000000DCU, 0x0000003CU, 0x0000001EU, 0x00000069U, 0x000000E7U, 0x0000008EU, 0x000000EBU,
    0x000000B6U, 0x000000D8U, 0x000000FBU, 0x000000BFU, 0x000000A6U, 0x0000004AU, 0x00000015U, 0x00000023U,
    0x000000FDU, 0x000000A4U, 0x0000005FU, 0x00000071U, 0x000000E0U, 0x0000008BU, 0x00000095U, 0x000000B8U,
    0x000000E6U, 0x00000008U, 0x00000082U, 0x00000034U, 0x00000092U, 0x00000065U, 0x00000060U, 0x000000E9U,
    0x0000008CU, 0x000000ABU, 0x00000010U, 0x000000C1U, 0x000000C4U, 0x0000000CU, 0x00000037U, 0x0000004FU,
    0x00000046U, 0x000000D6U, 0x0000001BU, 0x00000030U, 0x00000083U, 0x0000007BU, 0x000000E2U, 0x000000A5U,
    0x00000093U, 0x0000003FU, 0x000000DDU, 0x000000CFU, 0x000000CBU, 0x000000F7U, 0x000000ADU, 0x000000B3U,
    0x000000D0U, 0x00000047U, 0x0000001AU, 0x000000C6U, 0x0000006AU, 0x000000B0U, 0x0000009DU, 0x0000007DU,
    0x00000026U, 0x00000064U, 0x00000087U, 0x00000025U, 0x000000D5U, 0x00000099U, 0x00000081U, 0x000000FAU,
    0x0000002FU, 0x00000028U, 0x000000FEU, 0x000000EEU, 0x00000089U, 0x00000039U, 0x0000004DU, 0x000000F6U,
    0x00000027U, 0x000000F2U, 0x00000051U, 0x00000019U, 0x00000018U, 0x000000D9U, 0x00000003U, 0x0000007FU,
    0x0000008AU, 0x000000D1U, 0x000000C0U, 0x00000043U, 0x0000003DU, 0x000000C3U, 0x000000CCU, 0x000000C5U,
    0x00000004U, 0x00000055U, 0x000000B1U, 0x0000003EU, 0x00000058U, 0x000000BCU, 0x000000CEU, 0x000000AAU,
    0x00000007U, 0x00000042U, 0x00000096U, 0x00000077U, 0x000000D3U, 0x0000006EU, 0x00000088U, 0x00000045U,
    0x000000DBU, 0x0000001DU, 0x00000020U, 0x0000006FU, 0x00000044U, 0x000000DFU, 0x00000066U, 0x000000A8U,
    0x00000032U, 0x00000054U, 0x000000A1U, 0x0000000AU, 0x0000007CU, 0x00000063U, 0x00000094U, 0x00000097U,
    0x000000F0U, 0x00000076U, 0x00000072U, 0x0000006BU, 0x000000EFU, 0x0000003BU, 0x00000035U, 0x00000080U,
    0x00000057U, 0x00000074U, 0x0000001FU, 0x00000036U, 0x000000F9U, 0x000000AFU, 0x0000006CU, 0x00000006U,
    0x00000053U, 0x00000024U, 0x000000C9U, 0x000000F3U, 0x000000E3U, 0x000000C7U, 0x00000040U, 0x000000FCU,
    0x0000005BU, 0x00000016U, 0x0000000DU, 0x000000DAU, 0x0000009AU, 0x000000C8U, 0x00000075U, 0x000000F8U,
    0x00000091U, 0x000000BDU, 0x0000008FU, 0x00000059U, 0x000000A2U, 0x000000AEU, 0x0000004BU, 0x000000A3U,
    0x0000001CU, 0x000000FFU, 0x000000D7U, 0x00000050U, 0x00000079U, 0x0000002EU, 0x00000017U, 0x00000085U,
    0x00000041U, 0x0000009FU, 0x0000002CU, 0x0000005CU, 0x000000BAU, 0x0000007AU, 0x000000CAU, 0x0000006DU,
    0x00000067U, 0x00000011U, 0x000000A0U, 0x000000C2U, 0x000000B7U, 0x00000029U, 0x00000000U, 0x00000049U,
    0x00000078U, 0x00000062U, 0x0000005EU, 0x0000005AU, 0x000000B4U, 0x000000D4U, 0x00000009U, 0x0000005DU,
};

/* 四张预移位表：把「查表后左移 24/16/8」折进表内容（表 4 KB）。 */
static inline uint32_t nl_sw(uint32_t x)
{
    return NL_SB0[(x >> 24) & 0xFFU]
         | NL_SB1[(x >> 16) & 0xFFU]
         | NL_SB2[(x >>  8) & 0xFFU]
         | NL_SB3[ x        & 0xFFU];
}

static inline __m256i nl_psbox(__m256i x)
{
    uint32_t w[8];
    int i;
    _mm256_storeu_si256((__m256i *)(void *)w, x);
    for (i = 0; i < 8; i++)
        w[i] = nl_sw(w[i]);
    return _mm256_loadu_si256((const __m256i *)(const void *)w);
}


/* ==== 合并件：标量 S 盒（因子①）+ 去外壳（因子②），单 TU，u32 ABI ==== */
    /* 核心轮 mu=5 rmu=0 */
    static void nl_rnd_5_0(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y0 = s2_9 + s4_6;
    uint32_t Z0 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W0 = s4_1 + s3_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y1 = s3_9 + s0_6;
    uint32_t Z1 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W1 = s0_1 + s4_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y2 = s4_9 + s1_6;
    uint32_t Z2 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W2 = s1_1 + s0_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y3 = s0_9 + s2_6;
    uint32_t Z3 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W3 = s2_1 + s1_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y4 = s1_9 + s3_6;
    uint32_t Z4 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W4 = s3_1 + s2_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    ((volatile uint32_t *)S)[0] = s0_1;
    ((volatile uint32_t *)S)[1] = s0_2;
    ((volatile uint32_t *)S)[2] = s0_3;
    ((volatile uint32_t *)S)[3] = t0_3;
    ((volatile uint32_t *)S)[4] = s0_5;
    ((volatile uint32_t *)S)[5] = s0_6;
    ((volatile uint32_t *)S)[6] = s0_7;
    ((volatile uint32_t *)S)[7] = t0_7;
    ((volatile uint32_t *)S)[8] = s0_9;
    ((volatile uint32_t *)S)[9] = s0_10;
    ((volatile uint32_t *)S)[10] = s0_11;
    ((volatile uint32_t *)S)[11] = t0_11;
    ((volatile uint32_t *)S)[12] = s0_13;
    ((volatile uint32_t *)S)[13] = s0_14;
    ((volatile uint32_t *)S)[14] = s0_15;
    ((volatile uint32_t *)S)[15] = t0_15;
    ((volatile uint32_t *)S)[16] = s1_1;
    ((volatile uint32_t *)S)[17] = s1_2;
    ((volatile uint32_t *)S)[18] = s1_3;
    ((volatile uint32_t *)S)[19] = t1_3;
    ((volatile uint32_t *)S)[20] = s1_5;
    ((volatile uint32_t *)S)[21] = s1_6;
    ((volatile uint32_t *)S)[22] = s1_7;
    ((volatile uint32_t *)S)[23] = t1_7;
    ((volatile uint32_t *)S)[24] = s1_9;
    ((volatile uint32_t *)S)[25] = s1_10;
    ((volatile uint32_t *)S)[26] = s1_11;
    ((volatile uint32_t *)S)[27] = t1_11;
    ((volatile uint32_t *)S)[28] = s1_13;
    ((volatile uint32_t *)S)[29] = s1_14;
    ((volatile uint32_t *)S)[30] = s1_15;
    ((volatile uint32_t *)S)[31] = t1_15;
    ((volatile uint32_t *)S)[32] = s2_1;
    ((volatile uint32_t *)S)[33] = s2_2;
    ((volatile uint32_t *)S)[34] = s2_3;
    ((volatile uint32_t *)S)[35] = t2_3;
    ((volatile uint32_t *)S)[36] = s2_5;
    ((volatile uint32_t *)S)[37] = s2_6;
    ((volatile uint32_t *)S)[38] = s2_7;
    ((volatile uint32_t *)S)[39] = t2_7;
    ((volatile uint32_t *)S)[40] = s2_9;
    ((volatile uint32_t *)S)[41] = s2_10;
    ((volatile uint32_t *)S)[42] = s2_11;
    ((volatile uint32_t *)S)[43] = t2_11;
    ((volatile uint32_t *)S)[44] = s2_13;
    ((volatile uint32_t *)S)[45] = s2_14;
    ((volatile uint32_t *)S)[46] = s2_15;
    ((volatile uint32_t *)S)[47] = t2_15;
    ((volatile uint32_t *)S)[48] = s3_1;
    ((volatile uint32_t *)S)[49] = s3_2;
    ((volatile uint32_t *)S)[50] = s3_3;
    ((volatile uint32_t *)S)[51] = t3_3;
    ((volatile uint32_t *)S)[52] = s3_5;
    ((volatile uint32_t *)S)[53] = s3_6;
    ((volatile uint32_t *)S)[54] = s3_7;
    ((volatile uint32_t *)S)[55] = t3_7;
    ((volatile uint32_t *)S)[56] = s3_9;
    ((volatile uint32_t *)S)[57] = s3_10;
    ((volatile uint32_t *)S)[58] = s3_11;
    ((volatile uint32_t *)S)[59] = t3_11;
    ((volatile uint32_t *)S)[60] = s3_13;
    ((volatile uint32_t *)S)[61] = s3_14;
    ((volatile uint32_t *)S)[62] = s3_15;
    ((volatile uint32_t *)S)[63] = t3_15;
    ((volatile uint32_t *)S)[64] = s4_1;
    ((volatile uint32_t *)S)[65] = s4_2;
    ((volatile uint32_t *)S)[66] = s4_3;
    ((volatile uint32_t *)S)[67] = t4_3;
    ((volatile uint32_t *)S)[68] = s4_5;
    ((volatile uint32_t *)S)[69] = s4_6;
    ((volatile uint32_t *)S)[70] = s4_7;
    ((volatile uint32_t *)S)[71] = t4_7;
    ((volatile uint32_t *)S)[72] = s4_9;
    ((volatile uint32_t *)S)[73] = s4_10;
    ((volatile uint32_t *)S)[74] = s4_11;
    ((volatile uint32_t *)S)[75] = t4_11;
    ((volatile uint32_t *)S)[76] = s4_13;
    ((volatile uint32_t *)S)[77] = s4_14;
    ((volatile uint32_t *)S)[78] = s4_15;
    ((volatile uint32_t *)S)[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=1 */
    static void nl_rnd_5_1(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y0 = s3_9 + s0_6;
    uint32_t Z0 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W0 = s0_1 + s4_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y1 = s4_9 + s1_6;
    uint32_t Z1 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W1 = s1_1 + s0_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y2 = s0_9 + s2_6;
    uint32_t Z2 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W2 = s2_1 + s1_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y3 = s1_9 + s3_6;
    uint32_t Z3 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W3 = s3_1 + s2_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y4 = s2_9 + s4_6;
    uint32_t Z4 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W4 = s4_1 + s3_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    ((volatile uint32_t *)S)[0] = s0_1;
    ((volatile uint32_t *)S)[1] = s0_2;
    ((volatile uint32_t *)S)[2] = s0_3;
    ((volatile uint32_t *)S)[3] = t0_3;
    ((volatile uint32_t *)S)[4] = s0_5;
    ((volatile uint32_t *)S)[5] = s0_6;
    ((volatile uint32_t *)S)[6] = s0_7;
    ((volatile uint32_t *)S)[7] = t0_7;
    ((volatile uint32_t *)S)[8] = s0_9;
    ((volatile uint32_t *)S)[9] = s0_10;
    ((volatile uint32_t *)S)[10] = s0_11;
    ((volatile uint32_t *)S)[11] = t0_11;
    ((volatile uint32_t *)S)[12] = s0_13;
    ((volatile uint32_t *)S)[13] = s0_14;
    ((volatile uint32_t *)S)[14] = s0_15;
    ((volatile uint32_t *)S)[15] = t0_15;
    ((volatile uint32_t *)S)[16] = s1_1;
    ((volatile uint32_t *)S)[17] = s1_2;
    ((volatile uint32_t *)S)[18] = s1_3;
    ((volatile uint32_t *)S)[19] = t1_3;
    ((volatile uint32_t *)S)[20] = s1_5;
    ((volatile uint32_t *)S)[21] = s1_6;
    ((volatile uint32_t *)S)[22] = s1_7;
    ((volatile uint32_t *)S)[23] = t1_7;
    ((volatile uint32_t *)S)[24] = s1_9;
    ((volatile uint32_t *)S)[25] = s1_10;
    ((volatile uint32_t *)S)[26] = s1_11;
    ((volatile uint32_t *)S)[27] = t1_11;
    ((volatile uint32_t *)S)[28] = s1_13;
    ((volatile uint32_t *)S)[29] = s1_14;
    ((volatile uint32_t *)S)[30] = s1_15;
    ((volatile uint32_t *)S)[31] = t1_15;
    ((volatile uint32_t *)S)[32] = s2_1;
    ((volatile uint32_t *)S)[33] = s2_2;
    ((volatile uint32_t *)S)[34] = s2_3;
    ((volatile uint32_t *)S)[35] = t2_3;
    ((volatile uint32_t *)S)[36] = s2_5;
    ((volatile uint32_t *)S)[37] = s2_6;
    ((volatile uint32_t *)S)[38] = s2_7;
    ((volatile uint32_t *)S)[39] = t2_7;
    ((volatile uint32_t *)S)[40] = s2_9;
    ((volatile uint32_t *)S)[41] = s2_10;
    ((volatile uint32_t *)S)[42] = s2_11;
    ((volatile uint32_t *)S)[43] = t2_11;
    ((volatile uint32_t *)S)[44] = s2_13;
    ((volatile uint32_t *)S)[45] = s2_14;
    ((volatile uint32_t *)S)[46] = s2_15;
    ((volatile uint32_t *)S)[47] = t2_15;
    ((volatile uint32_t *)S)[48] = s3_1;
    ((volatile uint32_t *)S)[49] = s3_2;
    ((volatile uint32_t *)S)[50] = s3_3;
    ((volatile uint32_t *)S)[51] = t3_3;
    ((volatile uint32_t *)S)[52] = s3_5;
    ((volatile uint32_t *)S)[53] = s3_6;
    ((volatile uint32_t *)S)[54] = s3_7;
    ((volatile uint32_t *)S)[55] = t3_7;
    ((volatile uint32_t *)S)[56] = s3_9;
    ((volatile uint32_t *)S)[57] = s3_10;
    ((volatile uint32_t *)S)[58] = s3_11;
    ((volatile uint32_t *)S)[59] = t3_11;
    ((volatile uint32_t *)S)[60] = s3_13;
    ((volatile uint32_t *)S)[61] = s3_14;
    ((volatile uint32_t *)S)[62] = s3_15;
    ((volatile uint32_t *)S)[63] = t3_15;
    ((volatile uint32_t *)S)[64] = s4_1;
    ((volatile uint32_t *)S)[65] = s4_2;
    ((volatile uint32_t *)S)[66] = s4_3;
    ((volatile uint32_t *)S)[67] = t4_3;
    ((volatile uint32_t *)S)[68] = s4_5;
    ((volatile uint32_t *)S)[69] = s4_6;
    ((volatile uint32_t *)S)[70] = s4_7;
    ((volatile uint32_t *)S)[71] = t4_7;
    ((volatile uint32_t *)S)[72] = s4_9;
    ((volatile uint32_t *)S)[73] = s4_10;
    ((volatile uint32_t *)S)[74] = s4_11;
    ((volatile uint32_t *)S)[75] = t4_11;
    ((volatile uint32_t *)S)[76] = s4_13;
    ((volatile uint32_t *)S)[77] = s4_14;
    ((volatile uint32_t *)S)[78] = s4_15;
    ((volatile uint32_t *)S)[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=2 */
    static void nl_rnd_5_2(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y0 = s4_9 + s1_6;
    uint32_t Z0 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W0 = s1_1 + s0_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y1 = s0_9 + s2_6;
    uint32_t Z1 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W1 = s2_1 + s1_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y2 = s1_9 + s3_6;
    uint32_t Z2 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W2 = s3_1 + s2_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y3 = s2_9 + s4_6;
    uint32_t Z3 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W3 = s4_1 + s3_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y4 = s3_9 + s0_6;
    uint32_t Z4 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W4 = s0_1 + s4_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    ((volatile uint32_t *)S)[0] = s0_1;
    ((volatile uint32_t *)S)[1] = s0_2;
    ((volatile uint32_t *)S)[2] = s0_3;
    ((volatile uint32_t *)S)[3] = t0_3;
    ((volatile uint32_t *)S)[4] = s0_5;
    ((volatile uint32_t *)S)[5] = s0_6;
    ((volatile uint32_t *)S)[6] = s0_7;
    ((volatile uint32_t *)S)[7] = t0_7;
    ((volatile uint32_t *)S)[8] = s0_9;
    ((volatile uint32_t *)S)[9] = s0_10;
    ((volatile uint32_t *)S)[10] = s0_11;
    ((volatile uint32_t *)S)[11] = t0_11;
    ((volatile uint32_t *)S)[12] = s0_13;
    ((volatile uint32_t *)S)[13] = s0_14;
    ((volatile uint32_t *)S)[14] = s0_15;
    ((volatile uint32_t *)S)[15] = t0_15;
    ((volatile uint32_t *)S)[16] = s1_1;
    ((volatile uint32_t *)S)[17] = s1_2;
    ((volatile uint32_t *)S)[18] = s1_3;
    ((volatile uint32_t *)S)[19] = t1_3;
    ((volatile uint32_t *)S)[20] = s1_5;
    ((volatile uint32_t *)S)[21] = s1_6;
    ((volatile uint32_t *)S)[22] = s1_7;
    ((volatile uint32_t *)S)[23] = t1_7;
    ((volatile uint32_t *)S)[24] = s1_9;
    ((volatile uint32_t *)S)[25] = s1_10;
    ((volatile uint32_t *)S)[26] = s1_11;
    ((volatile uint32_t *)S)[27] = t1_11;
    ((volatile uint32_t *)S)[28] = s1_13;
    ((volatile uint32_t *)S)[29] = s1_14;
    ((volatile uint32_t *)S)[30] = s1_15;
    ((volatile uint32_t *)S)[31] = t1_15;
    ((volatile uint32_t *)S)[32] = s2_1;
    ((volatile uint32_t *)S)[33] = s2_2;
    ((volatile uint32_t *)S)[34] = s2_3;
    ((volatile uint32_t *)S)[35] = t2_3;
    ((volatile uint32_t *)S)[36] = s2_5;
    ((volatile uint32_t *)S)[37] = s2_6;
    ((volatile uint32_t *)S)[38] = s2_7;
    ((volatile uint32_t *)S)[39] = t2_7;
    ((volatile uint32_t *)S)[40] = s2_9;
    ((volatile uint32_t *)S)[41] = s2_10;
    ((volatile uint32_t *)S)[42] = s2_11;
    ((volatile uint32_t *)S)[43] = t2_11;
    ((volatile uint32_t *)S)[44] = s2_13;
    ((volatile uint32_t *)S)[45] = s2_14;
    ((volatile uint32_t *)S)[46] = s2_15;
    ((volatile uint32_t *)S)[47] = t2_15;
    ((volatile uint32_t *)S)[48] = s3_1;
    ((volatile uint32_t *)S)[49] = s3_2;
    ((volatile uint32_t *)S)[50] = s3_3;
    ((volatile uint32_t *)S)[51] = t3_3;
    ((volatile uint32_t *)S)[52] = s3_5;
    ((volatile uint32_t *)S)[53] = s3_6;
    ((volatile uint32_t *)S)[54] = s3_7;
    ((volatile uint32_t *)S)[55] = t3_7;
    ((volatile uint32_t *)S)[56] = s3_9;
    ((volatile uint32_t *)S)[57] = s3_10;
    ((volatile uint32_t *)S)[58] = s3_11;
    ((volatile uint32_t *)S)[59] = t3_11;
    ((volatile uint32_t *)S)[60] = s3_13;
    ((volatile uint32_t *)S)[61] = s3_14;
    ((volatile uint32_t *)S)[62] = s3_15;
    ((volatile uint32_t *)S)[63] = t3_15;
    ((volatile uint32_t *)S)[64] = s4_1;
    ((volatile uint32_t *)S)[65] = s4_2;
    ((volatile uint32_t *)S)[66] = s4_3;
    ((volatile uint32_t *)S)[67] = t4_3;
    ((volatile uint32_t *)S)[68] = s4_5;
    ((volatile uint32_t *)S)[69] = s4_6;
    ((volatile uint32_t *)S)[70] = s4_7;
    ((volatile uint32_t *)S)[71] = t4_7;
    ((volatile uint32_t *)S)[72] = s4_9;
    ((volatile uint32_t *)S)[73] = s4_10;
    ((volatile uint32_t *)S)[74] = s4_11;
    ((volatile uint32_t *)S)[75] = t4_11;
    ((volatile uint32_t *)S)[76] = s4_13;
    ((volatile uint32_t *)S)[77] = s4_14;
    ((volatile uint32_t *)S)[78] = s4_15;
    ((volatile uint32_t *)S)[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=3 */
    static void nl_rnd_5_3(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y0 = s0_9 + s2_6;
    uint32_t Z0 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W0 = s2_1 + s1_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y1 = s1_9 + s3_6;
    uint32_t Z1 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W1 = s3_1 + s2_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y2 = s2_9 + s4_6;
    uint32_t Z2 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W2 = s4_1 + s3_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y3 = s3_9 + s0_6;
    uint32_t Z3 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W3 = s0_1 + s4_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y4 = s4_9 + s1_6;
    uint32_t Z4 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W4 = s1_1 + s0_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    ((volatile uint32_t *)S)[0] = s0_1;
    ((volatile uint32_t *)S)[1] = s0_2;
    ((volatile uint32_t *)S)[2] = s0_3;
    ((volatile uint32_t *)S)[3] = t0_3;
    ((volatile uint32_t *)S)[4] = s0_5;
    ((volatile uint32_t *)S)[5] = s0_6;
    ((volatile uint32_t *)S)[6] = s0_7;
    ((volatile uint32_t *)S)[7] = t0_7;
    ((volatile uint32_t *)S)[8] = s0_9;
    ((volatile uint32_t *)S)[9] = s0_10;
    ((volatile uint32_t *)S)[10] = s0_11;
    ((volatile uint32_t *)S)[11] = t0_11;
    ((volatile uint32_t *)S)[12] = s0_13;
    ((volatile uint32_t *)S)[13] = s0_14;
    ((volatile uint32_t *)S)[14] = s0_15;
    ((volatile uint32_t *)S)[15] = t0_15;
    ((volatile uint32_t *)S)[16] = s1_1;
    ((volatile uint32_t *)S)[17] = s1_2;
    ((volatile uint32_t *)S)[18] = s1_3;
    ((volatile uint32_t *)S)[19] = t1_3;
    ((volatile uint32_t *)S)[20] = s1_5;
    ((volatile uint32_t *)S)[21] = s1_6;
    ((volatile uint32_t *)S)[22] = s1_7;
    ((volatile uint32_t *)S)[23] = t1_7;
    ((volatile uint32_t *)S)[24] = s1_9;
    ((volatile uint32_t *)S)[25] = s1_10;
    ((volatile uint32_t *)S)[26] = s1_11;
    ((volatile uint32_t *)S)[27] = t1_11;
    ((volatile uint32_t *)S)[28] = s1_13;
    ((volatile uint32_t *)S)[29] = s1_14;
    ((volatile uint32_t *)S)[30] = s1_15;
    ((volatile uint32_t *)S)[31] = t1_15;
    ((volatile uint32_t *)S)[32] = s2_1;
    ((volatile uint32_t *)S)[33] = s2_2;
    ((volatile uint32_t *)S)[34] = s2_3;
    ((volatile uint32_t *)S)[35] = t2_3;
    ((volatile uint32_t *)S)[36] = s2_5;
    ((volatile uint32_t *)S)[37] = s2_6;
    ((volatile uint32_t *)S)[38] = s2_7;
    ((volatile uint32_t *)S)[39] = t2_7;
    ((volatile uint32_t *)S)[40] = s2_9;
    ((volatile uint32_t *)S)[41] = s2_10;
    ((volatile uint32_t *)S)[42] = s2_11;
    ((volatile uint32_t *)S)[43] = t2_11;
    ((volatile uint32_t *)S)[44] = s2_13;
    ((volatile uint32_t *)S)[45] = s2_14;
    ((volatile uint32_t *)S)[46] = s2_15;
    ((volatile uint32_t *)S)[47] = t2_15;
    ((volatile uint32_t *)S)[48] = s3_1;
    ((volatile uint32_t *)S)[49] = s3_2;
    ((volatile uint32_t *)S)[50] = s3_3;
    ((volatile uint32_t *)S)[51] = t3_3;
    ((volatile uint32_t *)S)[52] = s3_5;
    ((volatile uint32_t *)S)[53] = s3_6;
    ((volatile uint32_t *)S)[54] = s3_7;
    ((volatile uint32_t *)S)[55] = t3_7;
    ((volatile uint32_t *)S)[56] = s3_9;
    ((volatile uint32_t *)S)[57] = s3_10;
    ((volatile uint32_t *)S)[58] = s3_11;
    ((volatile uint32_t *)S)[59] = t3_11;
    ((volatile uint32_t *)S)[60] = s3_13;
    ((volatile uint32_t *)S)[61] = s3_14;
    ((volatile uint32_t *)S)[62] = s3_15;
    ((volatile uint32_t *)S)[63] = t3_15;
    ((volatile uint32_t *)S)[64] = s4_1;
    ((volatile uint32_t *)S)[65] = s4_2;
    ((volatile uint32_t *)S)[66] = s4_3;
    ((volatile uint32_t *)S)[67] = t4_3;
    ((volatile uint32_t *)S)[68] = s4_5;
    ((volatile uint32_t *)S)[69] = s4_6;
    ((volatile uint32_t *)S)[70] = s4_7;
    ((volatile uint32_t *)S)[71] = t4_7;
    ((volatile uint32_t *)S)[72] = s4_9;
    ((volatile uint32_t *)S)[73] = s4_10;
    ((volatile uint32_t *)S)[74] = s4_11;
    ((volatile uint32_t *)S)[75] = t4_11;
    ((volatile uint32_t *)S)[76] = s4_13;
    ((volatile uint32_t *)S)[77] = s4_14;
    ((volatile uint32_t *)S)[78] = s4_15;
    ((volatile uint32_t *)S)[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=4 */
    static void nl_rnd_5_4(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y0 = s1_9 + s3_6;
    uint32_t Z0 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W0 = s3_1 + s2_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y1 = s2_9 + s4_6;
    uint32_t Z1 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W1 = s4_1 + s3_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y2 = s3_9 + s0_6;
    uint32_t Z2 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W2 = s0_1 + s4_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y3 = s4_9 + s1_6;
    uint32_t Z3 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W3 = s1_1 + s0_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y4 = s0_9 + s2_6;
    uint32_t Z4 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W4 = s2_1 + s1_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    ((volatile uint32_t *)S)[0] = s0_1;
    ((volatile uint32_t *)S)[1] = s0_2;
    ((volatile uint32_t *)S)[2] = s0_3;
    ((volatile uint32_t *)S)[3] = t0_3;
    ((volatile uint32_t *)S)[4] = s0_5;
    ((volatile uint32_t *)S)[5] = s0_6;
    ((volatile uint32_t *)S)[6] = s0_7;
    ((volatile uint32_t *)S)[7] = t0_7;
    ((volatile uint32_t *)S)[8] = s0_9;
    ((volatile uint32_t *)S)[9] = s0_10;
    ((volatile uint32_t *)S)[10] = s0_11;
    ((volatile uint32_t *)S)[11] = t0_11;
    ((volatile uint32_t *)S)[12] = s0_13;
    ((volatile uint32_t *)S)[13] = s0_14;
    ((volatile uint32_t *)S)[14] = s0_15;
    ((volatile uint32_t *)S)[15] = t0_15;
    ((volatile uint32_t *)S)[16] = s1_1;
    ((volatile uint32_t *)S)[17] = s1_2;
    ((volatile uint32_t *)S)[18] = s1_3;
    ((volatile uint32_t *)S)[19] = t1_3;
    ((volatile uint32_t *)S)[20] = s1_5;
    ((volatile uint32_t *)S)[21] = s1_6;
    ((volatile uint32_t *)S)[22] = s1_7;
    ((volatile uint32_t *)S)[23] = t1_7;
    ((volatile uint32_t *)S)[24] = s1_9;
    ((volatile uint32_t *)S)[25] = s1_10;
    ((volatile uint32_t *)S)[26] = s1_11;
    ((volatile uint32_t *)S)[27] = t1_11;
    ((volatile uint32_t *)S)[28] = s1_13;
    ((volatile uint32_t *)S)[29] = s1_14;
    ((volatile uint32_t *)S)[30] = s1_15;
    ((volatile uint32_t *)S)[31] = t1_15;
    ((volatile uint32_t *)S)[32] = s2_1;
    ((volatile uint32_t *)S)[33] = s2_2;
    ((volatile uint32_t *)S)[34] = s2_3;
    ((volatile uint32_t *)S)[35] = t2_3;
    ((volatile uint32_t *)S)[36] = s2_5;
    ((volatile uint32_t *)S)[37] = s2_6;
    ((volatile uint32_t *)S)[38] = s2_7;
    ((volatile uint32_t *)S)[39] = t2_7;
    ((volatile uint32_t *)S)[40] = s2_9;
    ((volatile uint32_t *)S)[41] = s2_10;
    ((volatile uint32_t *)S)[42] = s2_11;
    ((volatile uint32_t *)S)[43] = t2_11;
    ((volatile uint32_t *)S)[44] = s2_13;
    ((volatile uint32_t *)S)[45] = s2_14;
    ((volatile uint32_t *)S)[46] = s2_15;
    ((volatile uint32_t *)S)[47] = t2_15;
    ((volatile uint32_t *)S)[48] = s3_1;
    ((volatile uint32_t *)S)[49] = s3_2;
    ((volatile uint32_t *)S)[50] = s3_3;
    ((volatile uint32_t *)S)[51] = t3_3;
    ((volatile uint32_t *)S)[52] = s3_5;
    ((volatile uint32_t *)S)[53] = s3_6;
    ((volatile uint32_t *)S)[54] = s3_7;
    ((volatile uint32_t *)S)[55] = t3_7;
    ((volatile uint32_t *)S)[56] = s3_9;
    ((volatile uint32_t *)S)[57] = s3_10;
    ((volatile uint32_t *)S)[58] = s3_11;
    ((volatile uint32_t *)S)[59] = t3_11;
    ((volatile uint32_t *)S)[60] = s3_13;
    ((volatile uint32_t *)S)[61] = s3_14;
    ((volatile uint32_t *)S)[62] = s3_15;
    ((volatile uint32_t *)S)[63] = t3_15;
    ((volatile uint32_t *)S)[64] = s4_1;
    ((volatile uint32_t *)S)[65] = s4_2;
    ((volatile uint32_t *)S)[66] = s4_3;
    ((volatile uint32_t *)S)[67] = t4_3;
    ((volatile uint32_t *)S)[68] = s4_5;
    ((volatile uint32_t *)S)[69] = s4_6;
    ((volatile uint32_t *)S)[70] = s4_7;
    ((volatile uint32_t *)S)[71] = t4_7;
    ((volatile uint32_t *)S)[72] = s4_9;
    ((volatile uint32_t *)S)[73] = s4_10;
    ((volatile uint32_t *)S)[74] = s4_11;
    ((volatile uint32_t *)S)[75] = t4_11;
    ((volatile uint32_t *)S)[76] = s4_13;
    ((volatile uint32_t *)S)[77] = s4_14;
    ((volatile uint32_t *)S)[78] = s4_15;
    ((volatile uint32_t *)S)[79] = t4_15;
    }


static inline void nl_update(uint32_t S[NL_MAX_MU][NL_WORDS_PER_MODULE],
                             const NL_Params *p, uint32_t round)
{
    uint32_t kap[NL_MAX_MU];
    uint32_t rmu = round;
    int i;
    (void)nl_offsets;
    for (i = 0; i < p->mu; i++)
        kap[i] = nl_rotl32(0x9e3779b9U ^ round ^ (uint32_t)i,
                           (unsigned int)((round + (uint32_t)i) & 31U));
    /* 基准件：保留官方的 `round % mu`（gcc 已降成 imul+shr，无 div 指令） */
    rmu = (uint32_t)(round % (uint32_t)p->mu);
    switch (rmu)
    {
    case 0: nl_rnd_5_0((uint32_t *)S, kap); break;
    case 1: nl_rnd_5_1((uint32_t *)S, kap); break;
    case 2: nl_rnd_5_2((uint32_t *)S, kap); break;
    case 3: nl_rnd_5_3((uint32_t *)S, kap); break;
    case 4: nl_rnd_5_4((uint32_t *)S, kap); break;
    default: break;
    }
}
/* ===================== 注入结束 ===================== */


static int nl_params_from_digest(int digest_len_bits, NL_Params *p)
{
    if (digest_len_bits == 512)
    {
        p->n = 512;
        p->k = 960;
        p->v = 576;
        p->mu = 3;
        return 0;
    }
    if (digest_len_bits == 768)
    {
        p->n = 768;
        p->k = 1216;
        p->v = 832;
        p->mu = 4;
        return 0;
    }
    if (digest_len_bits == 1024)
    {
        p->n = 1024;
        p->k = 1472;
        p->v = 1088;
        p->mu = 5;
        return 0;
    }
    return -1;
}

static void nl_make_iv(const NL_Params *p, uint8_t V[NL_MAX_V_BYTES])
{
    int words = p->v / 32;
    memset(V, 0, (size_t)p->v / 8U);
    for (int i = 0; i < words; i++)
    {
        uint32_t x = (uint32_t)(0x9e3779b9U * (uint32_t)(i + 1));
        x = nl_rotl32(x, (unsigned int)i) ^ nl_rotl32(0x6a09e667U ^ 1024U, (unsigned int)((7 * i) & 31));
        nl_store32_be(V + 4 * i, x);
    }
}

static void nl_xor_block_constant(uint8_t V[NL_MAX_V_BYTES], size_t v_bytes, unsigned long long index)
{
    size_t off = v_bytes - 8U;
    uint32_t hi = (uint32_t)(index >> 32);
    uint32_t lo = (uint32_t)index;
    V[off + 0] ^= (uint8_t)(hi >> 24);
    V[off + 1] ^= (uint8_t)(hi >> 16);
    V[off + 2] ^= (uint8_t)(hi >> 8);
    V[off + 3] ^= (uint8_t)hi;
    V[off + 4] ^= (uint8_t)(lo >> 24);
    V[off + 5] ^= (uint8_t)(lo >> 16);
    V[off + 6] ^= (uint8_t)(lo >> 8);
    V[off + 7] ^= (uint8_t)lo;
}

static void nl_init_state(uint32_t S[NL_MAX_MU][NL_WORDS_PER_MODULE],
                          const NL_Params *p,
                          const uint8_t V[NL_MAX_V_BYTES],
                          const uint8_t K[NL_MAX_K_BYTES])
{
    size_t v_bytes = (size_t)p->v / 8U;
    size_t k_bytes = (size_t)p->k / 8U;
    int words = p->mu * NL_WORDS_PER_MODULE;
    for (int w = 0; w < words; w++)
    {
        size_t off = (size_t)w * 4U;
        const uint8_t *src = off < v_bytes ? V + off : K + off - v_bytes;
        S[w / NL_WORDS_PER_MODULE][w % NL_WORDS_PER_MODULE] = nl_load32_be(src);
    }
    (void)k_bytes;
}

static void nl_prng(const NL_Params *p,
                    const uint8_t V[NL_MAX_V_BYTES],
                    const uint8_t K[NL_MAX_K_BYTES],
                    uint8_t *out,
                    size_t out_len)
{
    uint32_t S[NL_MAX_MU][NL_WORDS_PER_MODULE];
    size_t produced = 0;
    uint32_t tau = 0;

    nl_init_state(S, p, V, K);
    for (uint32_t r = 0; r < NL_BLANK_ROUNDS; r++)
        nl_update(S, p, r);

    while (produced < out_len)
    {
        nl_update(S, p, NL_BLANK_ROUNDS + tau);
        for (int i = 0; i < p->mu && produced < out_len; i++)
        {
            uint32_t left = S[i][13] ^ S[(i + 1) % p->mu][8];
            uint32_t right = S[(i + 2) % p->mu][4] ^ S[(i + 3) % p->mu][2];
            uint32_t word = left + right;
            uint8_t tmp[4];
            size_t take = out_len - produced;
            if (take > 4U)
                take = 4U;
            nl_store32_be(tmp, word);
            memcpy(out + produced, tmp, take);
            produced += take;
        }
        tau++;
    }
}

static void nl_set_bit(uint8_t *x, unsigned int bit_in_block)
{
    x[bit_in_block >> 3] |= (uint8_t)(0x80U >> (bit_in_block & 7U));
}

static unsigned long long nl_padding_zero_bits(unsigned long long msg_len_bits, int k)
{
    unsigned long long used = (msg_len_bits + 1ULL + NL_LENGTH_FIELD_BITS) % (unsigned long long)k;
    return used ? (unsigned long long)k - used : 0ULL;
}

static void nl_build_padded_block(const NL_Params *p,
                                  const unsigned char *msg,
                                  unsigned long long msg_len_bits,
                                  unsigned long long zero_bits,
                                  unsigned long long block_index,
                                  uint8_t block[NL_MAX_K_BYTES])
{
    unsigned long long block_start = block_index * (unsigned long long)p->k;
    unsigned long long block_end = block_start + (unsigned long long)p->k;
    unsigned long long length_start = msg_len_bits + 1ULL + zero_bits;
    size_t k_bytes = (size_t)p->k / 8U;

    memset(block, 0, k_bytes);

    if (block_start < msg_len_bits)
    {
        unsigned long long msg_bits_here = msg_len_bits - block_start;
        if (msg_bits_here > (unsigned long long)p->k)
            msg_bits_here = (unsigned long long)p->k;
        size_t whole = (size_t)(msg_bits_here / 8ULL);
        unsigned int rem = (unsigned int)(msg_bits_here & 7ULL);
        if (whole)
            memcpy(block, msg + block_start / 8ULL, whole);
        if (rem)
            block[whole] = (uint8_t)(msg[block_start / 8ULL + whole] & (uint8_t)(0xFFU << (8U - rem)));
    }

    if (msg_len_bits >= block_start && msg_len_bits < block_end)
        nl_set_bit(block, (unsigned int)(msg_len_bits - block_start));

    /* The API benchmark and virtually all callers use byte-sized messages.
     * In that common case the length field is independent of the chaining
     * value and can be written as eight bytes instead of testing 64 bits. */
    if ((length_start & 7ULL) == 0ULL && length_start >= block_start &&
        length_start + NL_LENGTH_FIELD_BITS <= block_end)
    {
        size_t off = (size_t)((length_start - block_start) >> 3);
        nl_store32_be(block + off, (uint32_t)(msg_len_bits >> 32));
        nl_store32_be(block + off + 4U, (uint32_t)msg_len_bits);
    }
    else if (length_start < block_end && length_start + NL_LENGTH_FIELD_BITS > block_start)
    {
        for (unsigned int j = 0; j < NL_LENGTH_FIELD_BITS; j++)
        {
            unsigned long long pos = length_start + (unsigned long long)j;
            if (pos >= block_start && pos < block_end)
            {
                if ((msg_len_bits >> (63U - j)) & 1ULL)
                    nl_set_bit(block, (unsigned int)(pos - block_start));
            }
        }
    }
}

int CryptHash(int digest_len_bits, const unsigned char *NL_RESTRICT msg,
              unsigned long long msg_len_bits, unsigned char *NL_RESTRICT digest)
{
    NL_Params p;
    uint8_t V[NL_MAX_V_BYTES];
    uint8_t block[NL_MAX_K_BYTES];
    uint8_t stream[NL_MAX_OUTPUT_BYTES];
    unsigned long long zero_bits;
    unsigned long long total_bits;
    unsigned long long block_count;
    size_t v_bytes;
    size_t n_bytes;

    if (digest == 0 || (msg == 0 && msg_len_bits != 0ULL))
        return -1;
    if (digest_len_bits != DIGEST_BIT_LENGTH)
        return -2;
    if (nl_params_from_digest(digest_len_bits, &p) != 0)
        return -3;

    v_bytes = (size_t)p.v / 8U;
    n_bytes = (size_t)p.n / 8U;
    zero_bits = nl_padding_zero_bits(msg_len_bits, p.k);
    total_bits = msg_len_bits + 1ULL + zero_bits + NL_LENGTH_FIELD_BITS;
    block_count = total_bits / (unsigned long long)p.k;

    nl_make_iv(&p, V);
    nl_xor_block_constant(V, v_bytes, 0ULL);

    for (unsigned long long i = 0; i < block_count; i++)
    {
        int last = (i + 1ULL == block_count);
        size_t out_len = last ? (v_bytes + n_bytes) : v_bytes;
        nl_build_padded_block(&p, msg, msg_len_bits, zero_bits, i, block);
        nl_prng(&p, V, block, stream, out_len);
        if (last)
        {
            memcpy(digest, stream + v_bytes, n_bytes);
        }
        else
        {
            memcpy(V, stream, v_bytes);
            nl_xor_block_constant(V, v_bytes, i + 1ULL);
        }
    }

    return 0;
}
