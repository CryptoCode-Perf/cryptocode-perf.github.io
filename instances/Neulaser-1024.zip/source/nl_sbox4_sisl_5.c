/* SBOX4-EXPERIMENT: 四张预移位表，等价改写，KAT 必须全过。gen/gen_sbox4.py */
/* SCALAR-ISLAND-EXPERIMENT mu=5：S 盒岛由「向量往返」改为直接 nl_sw。
   等价改写（非消融），KAT 必须全过。生成器 gen/gen_scalar_island.py */
/* 由 gen_vec.py 生成（勿手改）。S 盒 = 标量 256 字节字节表（neulaser2 单因子实验）。 */
#include <stdint.h>
#include <immintrin.h>

#define NL_PV 4294967291U


static inline uint32_t nl_rot(uint32_t x, int r)
{
    return (uint32_t)((x << r) | (x >> (32 - r)));
}

static inline uint32_t nl_rdp32(uint32_t x)
{
    return x >= NL_PV ? (uint32_t)(x - NL_PV) : x;
}

static inline uint32_t nl_rdp64(uint64_t x)
{
    uint64_t t = (uint64_t)(uint32_t)x + 5ULL * (x >> 32);
    t = (uint64_t)(uint32_t)t + 5ULL * (t >> 32);
    return (uint32_t)(t >= (uint64_t)NL_PV ? t - (uint64_t)NL_PV : t);
}

static inline uint32_t nl_ll0(uint32_t x)
{
    return x ^ nl_rot(x, 2) ^ nl_rot(x, 10) ^ nl_rot(x, 18) ^ nl_rot(x, 24);
}

static inline uint32_t nl_ll1(uint32_t x)
{
    return x ^ nl_rot(x, 8) ^ nl_rot(x, 14) ^ nl_rot(x, 22) ^ nl_rot(x, 30);
}

/* 标量 S 盒：256 字节字节表，直接 L1 查表（口径照官方 nl_sbox_word :101-107）。 */
static const uint32_t NL_SB0[256] = {
    0xA7000000U, 0x12000000U, 0x9B000000U, 0x70000000U, 0xB9000000U, 0xEA000000U, 0x4C000000U, 0x73000000U,
    0x4E000000U, 0x14000000U, 0x01000000U, 0x33000000U, 0x52000000U, 0x31000000U, 0x2B000000U, 0x9C000000U,
    0xB5000000U, 0xF5000000U, 0x98000000U, 0x21000000U, 0xF4000000U, 0xBE000000U, 0x0B000000U, 0x2A000000U,
    0xBB000000U, 0xAC000000U, 0xEC000000U, 0x8D000000U, 0xE1000000U, 0x90000000U, 0x3A000000U, 0x38000000U,
    0x48000000U, 0xD2000000U, 0x68000000U, 0x0F000000U, 0xDE000000U, 0x56000000U, 0xE4000000U, 0x0E000000U,
    0xE8000000U, 0xED000000U, 0xCD000000U, 0xE5000000U, 0xF1000000U, 0x05000000U, 0x61000000U, 0x86000000U,
    0xA9000000U, 0x13000000U, 0x22000000U, 0x2D000000U, 0x02000000U, 0x9E000000U, 0xB2000000U, 0x7E000000U,
    0x84000000U, 0xDC000000U, 0x3C000000U, 0x1E000000U, 0x69000000U, 0xE7000000U, 0x8E000000U, 0xEB000000U,
    0xB6000000U, 0xD8000000U, 0xFB000000U, 0xBF000000U, 0xA6000000U, 0x4A000000U, 0x15000000U, 0x23000000U,
    0xFD000000U, 0xA4000000U, 0x5F000000U, 0x71000000U, 0xE0000000U, 0x8B000000U, 0x95000000U, 0xB8000000U,
    0xE6000000U, 0x08000000U, 0x82000000U, 0x34000000U, 0x92000000U, 0x65000000U, 0x60000000U, 0xE9000000U,
    0x8C000000U, 0xAB000000U, 0x10000000U, 0xC1000000U, 0xC4000000U, 0x0C000000U, 0x37000000U, 0x4F000000U,
    0x46000000U, 0xD6000000U, 0x1B000000U, 0x30000000U, 0x83000000U, 0x7B000000U, 0xE2000000U, 0xA5000000U,
    0x93000000U, 0x3F000000U, 0xDD000000U, 0xCF000000U, 0xCB000000U, 0xF7000000U, 0xAD000000U, 0xB3000000U,
    0xD0000000U, 0x47000000U, 0x1A000000U, 0xC6000000U, 0x6A000000U, 0xB0000000U, 0x9D000000U, 0x7D000000U,
    0x26000000U, 0x64000000U, 0x87000000U, 0x25000000U, 0xD5000000U, 0x99000000U, 0x81000000U, 0xFA000000U,
    0x2F000000U, 0x28000000U, 0xFE000000U, 0xEE000000U, 0x89000000U, 0x39000000U, 0x4D000000U, 0xF6000000U,
    0x27000000U, 0xF2000000U, 0x51000000U, 0x19000000U, 0x18000000U, 0xD9000000U, 0x03000000U, 0x7F000000U,
    0x8A000000U, 0xD1000000U, 0xC0000000U, 0x43000000U, 0x3D000000U, 0xC3000000U, 0xCC000000U, 0xC5000000U,
    0x04000000U, 0x55000000U, 0xB1000000U, 0x3E000000U, 0x58000000U, 0xBC000000U, 0xCE000000U, 0xAA000000U,
    0x07000000U, 0x42000000U, 0x96000000U, 0x77000000U, 0xD3000000U, 0x6E000000U, 0x88000000U, 0x45000000U,
    0xDB000000U, 0x1D000000U, 0x20000000U, 0x6F000000U, 0x44000000U, 0xDF000000U, 0x66000000U, 0xA8000000U,
    0x32000000U, 0x54000000U, 0xA1000000U, 0x0A000000U, 0x7C000000U, 0x63000000U, 0x94000000U, 0x97000000U,
    0xF0000000U, 0x76000000U, 0x72000000U, 0x6B000000U, 0xEF000000U, 0x3B000000U, 0x35000000U, 0x80000000U,
    0x57000000U, 0x74000000U, 0x1F000000U, 0x36000000U, 0xF9000000U, 0xAF000000U, 0x6C000000U, 0x06000000U,
    0x53000000U, 0x24000000U, 0xC9000000U, 0xF3000000U, 0xE3000000U, 0xC7000000U, 0x40000000U, 0xFC000000U,
    0x5B000000U, 0x16000000U, 0x0D000000U, 0xDA000000U, 0x9A000000U, 0xC8000000U, 0x75000000U, 0xF8000000U,
    0x91000000U, 0xBD000000U, 0x8F000000U, 0x59000000U, 0xA2000000U, 0xAE000000U, 0x4B000000U, 0xA3000000U,
    0x1C000000U, 0xFF000000U, 0xD7000000U, 0x50000000U, 0x79000000U, 0x2E000000U, 0x17000000U, 0x85000000U,
    0x41000000U, 0x9F000000U, 0x2C000000U, 0x5C000000U, 0xBA000000U, 0x7A000000U, 0xCA000000U, 0x6D000000U,
    0x67000000U, 0x11000000U, 0xA0000000U, 0xC2000000U, 0xB7000000U, 0x29000000U, 0x00000000U, 0x49000000U,
    0x78000000U, 0x62000000U, 0x5E000000U, 0x5A000000U, 0xB4000000U, 0xD4000000U, 0x09000000U, 0x5D000000U,
};
static const uint32_t NL_SB1[256] = {
    0x00A70000U, 0x00120000U, 0x009B0000U, 0x00700000U, 0x00B90000U, 0x00EA0000U, 0x004C0000U, 0x00730000U,
    0x004E0000U, 0x00140000U, 0x00010000U, 0x00330000U, 0x00520000U, 0x00310000U, 0x002B0000U, 0x009C0000U,
    0x00B50000U, 0x00F50000U, 0x00980000U, 0x00210000U, 0x00F40000U, 0x00BE0000U, 0x000B0000U, 0x002A0000U,
    0x00BB0000U, 0x00AC0000U, 0x00EC0000U, 0x008D0000U, 0x00E10000U, 0x00900000U, 0x003A0000U, 0x00380000U,
    0x00480000U, 0x00D20000U, 0x00680000U, 0x000F0000U, 0x00DE0000U, 0x00560000U, 0x00E40000U, 0x000E0000U,
    0x00E80000U, 0x00ED0000U, 0x00CD0000U, 0x00E50000U, 0x00F10000U, 0x00050000U, 0x00610000U, 0x00860000U,
    0x00A90000U, 0x00130000U, 0x00220000U, 0x002D0000U, 0x00020000U, 0x009E0000U, 0x00B20000U, 0x007E0000U,
    0x00840000U, 0x00DC0000U, 0x003C0000U, 0x001E0000U, 0x00690000U, 0x00E70000U, 0x008E0000U, 0x00EB0000U,
    0x00B60000U, 0x00D80000U, 0x00FB0000U, 0x00BF0000U, 0x00A60000U, 0x004A0000U, 0x00150000U, 0x00230000U,
    0x00FD0000U, 0x00A40000U, 0x005F0000U, 0x00710000U, 0x00E00000U, 0x008B0000U, 0x00950000U, 0x00B80000U,
    0x00E60000U, 0x00080000U, 0x00820000U, 0x00340000U, 0x00920000U, 0x00650000U, 0x00600000U, 0x00E90000U,
    0x008C0000U, 0x00AB0000U, 0x00100000U, 0x00C10000U, 0x00C40000U, 0x000C0000U, 0x00370000U, 0x004F0000U,
    0x00460000U, 0x00D60000U, 0x001B0000U, 0x00300000U, 0x00830000U, 0x007B0000U, 0x00E20000U, 0x00A50000U,
    0x00930000U, 0x003F0000U, 0x00DD0000U, 0x00CF0000U, 0x00CB0000U, 0x00F70000U, 0x00AD0000U, 0x00B30000U,
    0x00D00000U, 0x00470000U, 0x001A0000U, 0x00C60000U, 0x006A0000U, 0x00B00000U, 0x009D0000U, 0x007D0000U,
    0x00260000U, 0x00640000U, 0x00870000U, 0x00250000U, 0x00D50000U, 0x00990000U, 0x00810000U, 0x00FA0000U,
    0x002F0000U, 0x00280000U, 0x00FE0000U, 0x00EE0000U, 0x00890000U, 0x00390000U, 0x004D0000U, 0x00F60000U,
    0x00270000U, 0x00F20000U, 0x00510000U, 0x00190000U, 0x00180000U, 0x00D90000U, 0x00030000U, 0x007F0000U,
    0x008A0000U, 0x00D10000U, 0x00C00000U, 0x00430000U, 0x003D0000U, 0x00C30000U, 0x00CC0000U, 0x00C50000U,
    0x00040000U, 0x00550000U, 0x00B10000U, 0x003E0000U, 0x00580000U, 0x00BC0000U, 0x00CE0000U, 0x00AA0000U,
    0x00070000U, 0x00420000U, 0x00960000U, 0x00770000U, 0x00D30000U, 0x006E0000U, 0x00880000U, 0x00450000U,
    0x00DB0000U, 0x001D0000U, 0x00200000U, 0x006F0000U, 0x00440000U, 0x00DF0000U, 0x00660000U, 0x00A80000U,
    0x00320000U, 0x00540000U, 0x00A10000U, 0x000A0000U, 0x007C0000U, 0x00630000U, 0x00940000U, 0x00970000U,
    0x00F00000U, 0x00760000U, 0x00720000U, 0x006B0000U, 0x00EF0000U, 0x003B0000U, 0x00350000U, 0x00800000U,
    0x00570000U, 0x00740000U, 0x001F0000U, 0x00360000U, 0x00F90000U, 0x00AF0000U, 0x006C0000U, 0x00060000U,
    0x00530000U, 0x00240000U, 0x00C90000U, 0x00F30000U, 0x00E30000U, 0x00C70000U, 0x00400000U, 0x00FC0000U,
    0x005B0000U, 0x00160000U, 0x000D0000U, 0x00DA0000U, 0x009A0000U, 0x00C80000U, 0x00750000U, 0x00F80000U,
    0x00910000U, 0x00BD0000U, 0x008F0000U, 0x00590000U, 0x00A20000U, 0x00AE0000U, 0x004B0000U, 0x00A30000U,
    0x001C0000U, 0x00FF0000U, 0x00D70000U, 0x00500000U, 0x00790000U, 0x002E0000U, 0x00170000U, 0x00850000U,
    0x00410000U, 0x009F0000U, 0x002C0000U, 0x005C0000U, 0x00BA0000U, 0x007A0000U, 0x00CA0000U, 0x006D0000U,
    0x00670000U, 0x00110000U, 0x00A00000U, 0x00C20000U, 0x00B70000U, 0x00290000U, 0x00000000U, 0x00490000U,
    0x00780000U, 0x00620000U, 0x005E0000U, 0x005A0000U, 0x00B40000U, 0x00D40000U, 0x00090000U, 0x005D0000U,
};
static const uint32_t NL_SB2[256] = {
    0x0000A700U, 0x00001200U, 0x00009B00U, 0x00007000U, 0x0000B900U, 0x0000EA00U, 0x00004C00U, 0x00007300U,
    0x00004E00U, 0x00001400U, 0x00000100U, 0x00003300U, 0x00005200U, 0x00003100U, 0x00002B00U, 0x00009C00U,
    0x0000B500U, 0x0000F500U, 0x00009800U, 0x00002100U, 0x0000F400U, 0x0000BE00U, 0x00000B00U, 0x00002A00U,
    0x0000BB00U, 0x0000AC00U, 0x0000EC00U, 0x00008D00U, 0x0000E100U, 0x00009000U, 0x00003A00U, 0x00003800U,
    0x00004800U, 0x0000D200U, 0x00006800U, 0x00000F00U, 0x0000DE00U, 0x00005600U, 0x0000E400U, 0x00000E00U,
    0x0000E800U, 0x0000ED00U, 0x0000CD00U, 0x0000E500U, 0x0000F100U, 0x00000500U, 0x00006100U, 0x00008600U,
    0x0000A900U, 0x00001300U, 0x00002200U, 0x00002D00U, 0x00000200U, 0x00009E00U, 0x0000B200U, 0x00007E00U,
    0x00008400U, 0x0000DC00U, 0x00003C00U, 0x00001E00U, 0x00006900U, 0x0000E700U, 0x00008E00U, 0x0000EB00U,
    0x0000B600U, 0x0000D800U, 0x0000FB00U, 0x0000BF00U, 0x0000A600U, 0x00004A00U, 0x00001500U, 0x00002300U,
    0x0000FD00U, 0x0000A400U, 0x00005F00U, 0x00007100U, 0x0000E000U, 0x00008B00U, 0x00009500U, 0x0000B800U,
    0x0000E600U, 0x00000800U, 0x00008200U, 0x00003400U, 0x00009200U, 0x00006500U, 0x00006000U, 0x0000E900U,
    0x00008C00U, 0x0000AB00U, 0x00001000U, 0x0000C100U, 0x0000C400U, 0x00000C00U, 0x00003700U, 0x00004F00U,
    0x00004600U, 0x0000D600U, 0x00001B00U, 0x00003000U, 0x00008300U, 0x00007B00U, 0x0000E200U, 0x0000A500U,
    0x00009300U, 0x00003F00U, 0x0000DD00U, 0x0000CF00U, 0x0000CB00U, 0x0000F700U, 0x0000AD00U, 0x0000B300U,
    0x0000D000U, 0x00004700U, 0x00001A00U, 0x0000C600U, 0x00006A00U, 0x0000B000U, 0x00009D00U, 0x00007D00U,
    0x00002600U, 0x00006400U, 0x00008700U, 0x00002500U, 0x0000D500U, 0x00009900U, 0x00008100U, 0x0000FA00U,
    0x00002F00U, 0x00002800U, 0x0000FE00U, 0x0000EE00U, 0x00008900U, 0x00003900U, 0x00004D00U, 0x0000F600U,
    0x00002700U, 0x0000F200U, 0x00005100U, 0x00001900U, 0x00001800U, 0x0000D900U, 0x00000300U, 0x00007F00U,
    0x00008A00U, 0x0000D100U, 0x0000C000U, 0x00004300U, 0x00003D00U, 0x0000C300U, 0x0000CC00U, 0x0000C500U,
    0x00000400U, 0x00005500U, 0x0000B100U, 0x00003E00U, 0x00005800U, 0x0000BC00U, 0x0000CE00U, 0x0000AA00U,
    0x00000700U, 0x00004200U, 0x00009600U, 0x00007700U, 0x0000D300U, 0x00006E00U, 0x00008800U, 0x00004500U,
    0x0000DB00U, 0x00001D00U, 0x00002000U, 0x00006F00U, 0x00004400U, 0x0000DF00U, 0x00006600U, 0x0000A800U,
    0x00003200U, 0x00005400U, 0x0000A100U, 0x00000A00U, 0x00007C00U, 0x00006300U, 0x00009400U, 0x00009700U,
    0x0000F000U, 0x00007600U, 0x00007200U, 0x00006B00U, 0x0000EF00U, 0x00003B00U, 0x00003500U, 0x00008000U,
    0x00005700U, 0x00007400U, 0x00001F00U, 0x00003600U, 0x0000F900U, 0x0000AF00U, 0x00006C00U, 0x00000600U,
    0x00005300U, 0x00002400U, 0x0000C900U, 0x0000F300U, 0x0000E300U, 0x0000C700U, 0x00004000U, 0x0000FC00U,
    0x00005B00U, 0x00001600U, 0x00000D00U, 0x0000DA00U, 0x00009A00U, 0x0000C800U, 0x00007500U, 0x0000F800U,
    0x00009100U, 0x0000BD00U, 0x00008F00U, 0x00005900U, 0x0000A200U, 0x0000AE00U, 0x00004B00U, 0x0000A300U,
    0x00001C00U, 0x0000FF00U, 0x0000D700U, 0x00005000U, 0x00007900U, 0x00002E00U, 0x00001700U, 0x00008500U,
    0x00004100U, 0x00009F00U, 0x00002C00U, 0x00005C00U, 0x0000BA00U, 0x00007A00U, 0x0000CA00U, 0x00006D00U,
    0x00006700U, 0x00001100U, 0x0000A000U, 0x0000C200U, 0x0000B700U, 0x00002900U, 0x00000000U, 0x00004900U,
    0x00007800U, 0x00006200U, 0x00005E00U, 0x00005A00U, 0x0000B400U, 0x0000D400U, 0x00000900U, 0x00005D00U,
};
static const uint32_t NL_SB3[256] = {
    0x000000A7U, 0x00000012U, 0x0000009BU, 0x00000070U, 0x000000B9U, 0x000000EAU, 0x0000004CU, 0x00000073U,
    0x0000004EU, 0x00000014U, 0x00000001U, 0x00000033U, 0x00000052U, 0x00000031U, 0x0000002BU, 0x0000009CU,
    0x000000B5U, 0x000000F5U, 0x00000098U, 0x00000021U, 0x000000F4U, 0x000000BEU, 0x0000000BU, 0x0000002AU,
    0x000000BBU, 0x000000ACU, 0x000000ECU, 0x0000008DU, 0x000000E1U, 0x00000090U, 0x0000003AU, 0x00000038U,
    0x00000048U, 0x000000D2U, 0x00000068U, 0x0000000FU, 0x000000DEU, 0x00000056U, 0x000000E4U, 0x0000000EU,
    0x000000E8U, 0x000000EDU, 0x000000CDU, 0x000000E5U, 0x000000F1U, 0x00000005U, 0x00000061U, 0x00000086U,
    0x000000A9U, 0x00000013U, 0x00000022U, 0x0000002DU, 0x00000002U, 0x0000009EU, 0x000000B2U, 0x0000007EU,
    0x00000084U, 0x000000DCU, 0x0000003CU, 0x0000001EU, 0x00000069U, 0x000000E7U, 0x0000008EU, 0x000000EBU,
    0x000000B6U, 0x000000D8U, 0x000000FBU, 0x000000BFU, 0x000000A6U, 0x0000004AU, 0x00000015U, 0x00000023U,
    0x000000FDU, 0x000000A4U, 0x0000005FU, 0x00000071U, 0x000000E0U, 0x0000008BU, 0x00000095U, 0x000000B8U,
    0x000000E6U, 0x00000008U, 0x00000082U, 0x00000034U, 0x00000092U, 0x00000065U, 0x00000060U, 0x000000E9U,
    0x0000008CU, 0x000000ABU, 0x00000010U, 0x000000C1U, 0x000000C4U, 0x0000000CU, 0x00000037U, 0x0000004FU,
    0x00000046U, 0x000000D6U, 0x0000001BU, 0x00000030U, 0x00000083U, 0x0000007BU, 0x000000E2U, 0x000000A5U,
    0x00000093U, 0x0000003FU, 0x000000DDU, 0x000000CFU, 0x000000CBU, 0x000000F7U, 0x000000ADU, 0x000000B3U,
    0x000000D0U, 0x00000047U, 0x0000001AU, 0x000000C6U, 0x0000006AU, 0x000000B0U, 0x0000009DU, 0x0000007DU,
    0x00000026U, 0x00000064U, 0x00000087U, 0x00000025U, 0x000000D5U, 0x00000099U, 0x00000081U, 0x000000FAU,
    0x0000002FU, 0x00000028U, 0x000000FEU, 0x000000EEU, 0x00000089U, 0x00000039U, 0x0000004DU, 0x000000F6U,
    0x00000027U, 0x000000F2U, 0x00000051U, 0x00000019U, 0x00000018U, 0x000000D9U, 0x00000003U, 0x0000007FU,
    0x0000008AU, 0x000000D1U, 0x000000C0U, 0x00000043U, 0x0000003DU, 0x000000C3U, 0x000000CCU, 0x000000C5U,
    0x00000004U, 0x00000055U, 0x000000B1U, 0x0000003EU, 0x00000058U, 0x000000BCU, 0x000000CEU, 0x000000AAU,
    0x00000007U, 0x00000042U, 0x00000096U, 0x00000077U, 0x000000D3U, 0x0000006EU, 0x00000088U, 0x00000045U,
    0x000000DBU, 0x0000001DU, 0x00000020U, 0x0000006FU, 0x00000044U, 0x000000DFU, 0x00000066U, 0x000000A8U,
    0x00000032U, 0x00000054U, 0x000000A1U, 0x0000000AU, 0x0000007CU, 0x00000063U, 0x00000094U, 0x00000097U,
    0x000000F0U, 0x00000076U, 0x00000072U, 0x0000006BU, 0x000000EFU, 0x0000003BU, 0x00000035U, 0x00000080U,
    0x00000057U, 0x00000074U, 0x0000001FU, 0x00000036U, 0x000000F9U, 0x000000AFU, 0x0000006CU, 0x00000006U,
    0x00000053U, 0x00000024U, 0x000000C9U, 0x000000F3U, 0x000000E3U, 0x000000C7U, 0x00000040U, 0x000000FCU,
    0x0000005BU, 0x00000016U, 0x0000000DU, 0x000000DAU, 0x0000009AU, 0x000000C8U, 0x00000075U, 0x000000F8U,
    0x00000091U, 0x000000BDU, 0x0000008FU, 0x00000059U, 0x000000A2U, 0x000000AEU, 0x0000004BU, 0x000000A3U,
    0x0000001CU, 0x000000FFU, 0x000000D7U, 0x00000050U, 0x00000079U, 0x0000002EU, 0x00000017U, 0x00000085U,
    0x00000041U, 0x0000009FU, 0x0000002CU, 0x0000005CU, 0x000000BAU, 0x0000007AU, 0x000000CAU, 0x0000006DU,
    0x00000067U, 0x00000011U, 0x000000A0U, 0x000000C2U, 0x000000B7U, 0x00000029U, 0x00000000U, 0x00000049U,
    0x00000078U, 0x00000062U, 0x0000005EU, 0x0000005AU, 0x000000B4U, 0x000000D4U, 0x00000009U, 0x0000005DU,
};

/* 四张预移位表：把「查表后左移 24/16/8」折进表内容（表 4 KB）。 */
static inline uint32_t nl_sw(uint32_t x)
{
    return NL_SB0[(x >> 24) & 0xFFU]
         | NL_SB1[(x >> 16) & 0xFFU]
         | NL_SB2[(x >>  8) & 0xFFU]
         | NL_SB3[ x        & 0xFFU];
}

static inline __m256i nl_psbox(__m256i x)
{
    uint32_t w[8];
    int i;
    _mm256_storeu_si256((__m256i *)(void *)w, x);
    for (i = 0; i < 8; i++)
        w[i] = nl_sw(w[i]);
    return _mm256_loadu_si256((const __m256i *)(const void *)w);
}


/* ==== 合并件：标量 S 盒（因子①）+ 去外壳（因子②），单 TU，u32 ABI ==== */
    /* 核心轮 mu=5 rmu=0 */
    static void nl_rnd_5_0(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y0 = s2_9 + s4_6;
    uint32_t Z0 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W0 = s4_1 + s3_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y1 = s3_9 + s0_6;
    uint32_t Z1 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W1 = s0_1 + s4_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y2 = s4_9 + s1_6;
    uint32_t Z2 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W2 = s1_1 + s0_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y3 = s0_9 + s2_6;
    uint32_t Z3 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W3 = s2_1 + s1_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y4 = s1_9 + s3_6;
    uint32_t Z4 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W4 = s3_1 + s2_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    S[0] = s0_1;
    S[1] = s0_2;
    S[2] = s0_3;
    S[3] = t0_3;
    S[4] = s0_5;
    S[5] = s0_6;
    S[6] = s0_7;
    S[7] = t0_7;
    S[8] = s0_9;
    S[9] = s0_10;
    S[10] = s0_11;
    S[11] = t0_11;
    S[12] = s0_13;
    S[13] = s0_14;
    S[14] = s0_15;
    S[15] = t0_15;
    S[16] = s1_1;
    S[17] = s1_2;
    S[18] = s1_3;
    S[19] = t1_3;
    S[20] = s1_5;
    S[21] = s1_6;
    S[22] = s1_7;
    S[23] = t1_7;
    S[24] = s1_9;
    S[25] = s1_10;
    S[26] = s1_11;
    S[27] = t1_11;
    S[28] = s1_13;
    S[29] = s1_14;
    S[30] = s1_15;
    S[31] = t1_15;
    S[32] = s2_1;
    S[33] = s2_2;
    S[34] = s2_3;
    S[35] = t2_3;
    S[36] = s2_5;
    S[37] = s2_6;
    S[38] = s2_7;
    S[39] = t2_7;
    S[40] = s2_9;
    S[41] = s2_10;
    S[42] = s2_11;
    S[43] = t2_11;
    S[44] = s2_13;
    S[45] = s2_14;
    S[46] = s2_15;
    S[47] = t2_15;
    S[48] = s3_1;
    S[49] = s3_2;
    S[50] = s3_3;
    S[51] = t3_3;
    S[52] = s3_5;
    S[53] = s3_6;
    S[54] = s3_7;
    S[55] = t3_7;
    S[56] = s3_9;
    S[57] = s3_10;
    S[58] = s3_11;
    S[59] = t3_11;
    S[60] = s3_13;
    S[61] = s3_14;
    S[62] = s3_15;
    S[63] = t3_15;
    S[64] = s4_1;
    S[65] = s4_2;
    S[66] = s4_3;
    S[67] = t4_3;
    S[68] = s4_5;
    S[69] = s4_6;
    S[70] = s4_7;
    S[71] = t4_7;
    S[72] = s4_9;
    S[73] = s4_10;
    S[74] = s4_11;
    S[75] = t4_11;
    S[76] = s4_13;
    S[77] = s4_14;
    S[78] = s4_15;
    S[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=1 */
    static void nl_rnd_5_1(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y0 = s3_9 + s0_6;
    uint32_t Z0 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W0 = s0_1 + s4_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y1 = s4_9 + s1_6;
    uint32_t Z1 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W1 = s1_1 + s0_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y2 = s0_9 + s2_6;
    uint32_t Z2 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W2 = s2_1 + s1_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y3 = s1_9 + s3_6;
    uint32_t Z3 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W3 = s3_1 + s2_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y4 = s2_9 + s4_6;
    uint32_t Z4 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W4 = s4_1 + s3_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    S[0] = s0_1;
    S[1] = s0_2;
    S[2] = s0_3;
    S[3] = t0_3;
    S[4] = s0_5;
    S[5] = s0_6;
    S[6] = s0_7;
    S[7] = t0_7;
    S[8] = s0_9;
    S[9] = s0_10;
    S[10] = s0_11;
    S[11] = t0_11;
    S[12] = s0_13;
    S[13] = s0_14;
    S[14] = s0_15;
    S[15] = t0_15;
    S[16] = s1_1;
    S[17] = s1_2;
    S[18] = s1_3;
    S[19] = t1_3;
    S[20] = s1_5;
    S[21] = s1_6;
    S[22] = s1_7;
    S[23] = t1_7;
    S[24] = s1_9;
    S[25] = s1_10;
    S[26] = s1_11;
    S[27] = t1_11;
    S[28] = s1_13;
    S[29] = s1_14;
    S[30] = s1_15;
    S[31] = t1_15;
    S[32] = s2_1;
    S[33] = s2_2;
    S[34] = s2_3;
    S[35] = t2_3;
    S[36] = s2_5;
    S[37] = s2_6;
    S[38] = s2_7;
    S[39] = t2_7;
    S[40] = s2_9;
    S[41] = s2_10;
    S[42] = s2_11;
    S[43] = t2_11;
    S[44] = s2_13;
    S[45] = s2_14;
    S[46] = s2_15;
    S[47] = t2_15;
    S[48] = s3_1;
    S[49] = s3_2;
    S[50] = s3_3;
    S[51] = t3_3;
    S[52] = s3_5;
    S[53] = s3_6;
    S[54] = s3_7;
    S[55] = t3_7;
    S[56] = s3_9;
    S[57] = s3_10;
    S[58] = s3_11;
    S[59] = t3_11;
    S[60] = s3_13;
    S[61] = s3_14;
    S[62] = s3_15;
    S[63] = t3_15;
    S[64] = s4_1;
    S[65] = s4_2;
    S[66] = s4_3;
    S[67] = t4_3;
    S[68] = s4_5;
    S[69] = s4_6;
    S[70] = s4_7;
    S[71] = t4_7;
    S[72] = s4_9;
    S[73] = s4_10;
    S[74] = s4_11;
    S[75] = t4_11;
    S[76] = s4_13;
    S[77] = s4_14;
    S[78] = s4_15;
    S[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=2 */
    static void nl_rnd_5_2(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y0 = s4_9 + s1_6;
    uint32_t Z0 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W0 = s1_1 + s0_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y1 = s0_9 + s2_6;
    uint32_t Z1 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W1 = s2_1 + s1_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y2 = s1_9 + s3_6;
    uint32_t Z2 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W2 = s3_1 + s2_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y3 = s2_9 + s4_6;
    uint32_t Z3 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W3 = s4_1 + s3_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y4 = s3_9 + s0_6;
    uint32_t Z4 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W4 = s0_1 + s4_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    S[0] = s0_1;
    S[1] = s0_2;
    S[2] = s0_3;
    S[3] = t0_3;
    S[4] = s0_5;
    S[5] = s0_6;
    S[6] = s0_7;
    S[7] = t0_7;
    S[8] = s0_9;
    S[9] = s0_10;
    S[10] = s0_11;
    S[11] = t0_11;
    S[12] = s0_13;
    S[13] = s0_14;
    S[14] = s0_15;
    S[15] = t0_15;
    S[16] = s1_1;
    S[17] = s1_2;
    S[18] = s1_3;
    S[19] = t1_3;
    S[20] = s1_5;
    S[21] = s1_6;
    S[22] = s1_7;
    S[23] = t1_7;
    S[24] = s1_9;
    S[25] = s1_10;
    S[26] = s1_11;
    S[27] = t1_11;
    S[28] = s1_13;
    S[29] = s1_14;
    S[30] = s1_15;
    S[31] = t1_15;
    S[32] = s2_1;
    S[33] = s2_2;
    S[34] = s2_3;
    S[35] = t2_3;
    S[36] = s2_5;
    S[37] = s2_6;
    S[38] = s2_7;
    S[39] = t2_7;
    S[40] = s2_9;
    S[41] = s2_10;
    S[42] = s2_11;
    S[43] = t2_11;
    S[44] = s2_13;
    S[45] = s2_14;
    S[46] = s2_15;
    S[47] = t2_15;
    S[48] = s3_1;
    S[49] = s3_2;
    S[50] = s3_3;
    S[51] = t3_3;
    S[52] = s3_5;
    S[53] = s3_6;
    S[54] = s3_7;
    S[55] = t3_7;
    S[56] = s3_9;
    S[57] = s3_10;
    S[58] = s3_11;
    S[59] = t3_11;
    S[60] = s3_13;
    S[61] = s3_14;
    S[62] = s3_15;
    S[63] = t3_15;
    S[64] = s4_1;
    S[65] = s4_2;
    S[66] = s4_3;
    S[67] = t4_3;
    S[68] = s4_5;
    S[69] = s4_6;
    S[70] = s4_7;
    S[71] = t4_7;
    S[72] = s4_9;
    S[73] = s4_10;
    S[74] = s4_11;
    S[75] = t4_11;
    S[76] = s4_13;
    S[77] = s4_14;
    S[78] = s4_15;
    S[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=3 */
    static void nl_rnd_5_3(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y0 = s0_9 + s2_6;
    uint32_t Z0 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W0 = s2_1 + s1_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y1 = s1_9 + s3_6;
    uint32_t Z1 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W1 = s3_1 + s2_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y2 = s2_9 + s4_6;
    uint32_t Z2 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W2 = s4_1 + s3_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y3 = s3_9 + s0_6;
    uint32_t Z3 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W3 = s0_1 + s4_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y4 = s4_9 + s1_6;
    uint32_t Z4 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W4 = s1_1 + s0_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    S[0] = s0_1;
    S[1] = s0_2;
    S[2] = s0_3;
    S[3] = t0_3;
    S[4] = s0_5;
    S[5] = s0_6;
    S[6] = s0_7;
    S[7] = t0_7;
    S[8] = s0_9;
    S[9] = s0_10;
    S[10] = s0_11;
    S[11] = t0_11;
    S[12] = s0_13;
    S[13] = s0_14;
    S[14] = s0_15;
    S[15] = t0_15;
    S[16] = s1_1;
    S[17] = s1_2;
    S[18] = s1_3;
    S[19] = t1_3;
    S[20] = s1_5;
    S[21] = s1_6;
    S[22] = s1_7;
    S[23] = t1_7;
    S[24] = s1_9;
    S[25] = s1_10;
    S[26] = s1_11;
    S[27] = t1_11;
    S[28] = s1_13;
    S[29] = s1_14;
    S[30] = s1_15;
    S[31] = t1_15;
    S[32] = s2_1;
    S[33] = s2_2;
    S[34] = s2_3;
    S[35] = t2_3;
    S[36] = s2_5;
    S[37] = s2_6;
    S[38] = s2_7;
    S[39] = t2_7;
    S[40] = s2_9;
    S[41] = s2_10;
    S[42] = s2_11;
    S[43] = t2_11;
    S[44] = s2_13;
    S[45] = s2_14;
    S[46] = s2_15;
    S[47] = t2_15;
    S[48] = s3_1;
    S[49] = s3_2;
    S[50] = s3_3;
    S[51] = t3_3;
    S[52] = s3_5;
    S[53] = s3_6;
    S[54] = s3_7;
    S[55] = t3_7;
    S[56] = s3_9;
    S[57] = s3_10;
    S[58] = s3_11;
    S[59] = t3_11;
    S[60] = s3_13;
    S[61] = s3_14;
    S[62] = s3_15;
    S[63] = t3_15;
    S[64] = s4_1;
    S[65] = s4_2;
    S[66] = s4_3;
    S[67] = t4_3;
    S[68] = s4_5;
    S[69] = s4_6;
    S[70] = s4_7;
    S[71] = t4_7;
    S[72] = s4_9;
    S[73] = s4_10;
    S[74] = s4_11;
    S[75] = t4_11;
    S[76] = s4_13;
    S[77] = s4_14;
    S[78] = s4_15;
    S[79] = t4_15;
    }

    /* 核心轮 mu=5 rmu=4 */
    static void nl_rnd_5_4(uint32_t *S, const uint32_t *kap)
    {
    /* --- 取状态 --- */
    uint32_t s0_0 = S[0];
    uint32_t s0_1 = S[1];
    uint32_t s0_2 = S[2];
    uint32_t s0_3 = S[3];
    uint32_t s0_4 = S[4];
    uint32_t s0_5 = S[5];
    uint32_t s0_6 = S[6];
    uint32_t s0_7 = S[7];
    uint32_t s0_8 = S[8];
    uint32_t s0_9 = S[9];
    uint32_t s0_10 = S[10];
    uint32_t s0_11 = S[11];
    uint32_t s0_12 = S[12];
    uint32_t s0_13 = S[13];
    uint32_t s0_14 = S[14];
    uint32_t s0_15 = S[15];
    uint32_t s1_0 = S[16];
    uint32_t s1_1 = S[17];
    uint32_t s1_2 = S[18];
    uint32_t s1_3 = S[19];
    uint32_t s1_4 = S[20];
    uint32_t s1_5 = S[21];
    uint32_t s1_6 = S[22];
    uint32_t s1_7 = S[23];
    uint32_t s1_8 = S[24];
    uint32_t s1_9 = S[25];
    uint32_t s1_10 = S[26];
    uint32_t s1_11 = S[27];
    uint32_t s1_12 = S[28];
    uint32_t s1_13 = S[29];
    uint32_t s1_14 = S[30];
    uint32_t s1_15 = S[31];
    uint32_t s2_0 = S[32];
    uint32_t s2_1 = S[33];
    uint32_t s2_2 = S[34];
    uint32_t s2_3 = S[35];
    uint32_t s2_4 = S[36];
    uint32_t s2_5 = S[37];
    uint32_t s2_6 = S[38];
    uint32_t s2_7 = S[39];
    uint32_t s2_8 = S[40];
    uint32_t s2_9 = S[41];
    uint32_t s2_10 = S[42];
    uint32_t s2_11 = S[43];
    uint32_t s2_12 = S[44];
    uint32_t s2_13 = S[45];
    uint32_t s2_14 = S[46];
    uint32_t s2_15 = S[47];
    uint32_t s3_0 = S[48];
    uint32_t s3_1 = S[49];
    uint32_t s3_2 = S[50];
    uint32_t s3_3 = S[51];
    uint32_t s3_4 = S[52];
    uint32_t s3_5 = S[53];
    uint32_t s3_6 = S[54];
    uint32_t s3_7 = S[55];
    uint32_t s3_8 = S[56];
    uint32_t s3_9 = S[57];
    uint32_t s3_10 = S[58];
    uint32_t s3_11 = S[59];
    uint32_t s3_12 = S[60];
    uint32_t s3_13 = S[61];
    uint32_t s3_14 = S[62];
    uint32_t s3_15 = S[63];
    uint32_t s4_0 = S[64];
    uint32_t s4_1 = S[65];
    uint32_t s4_2 = S[66];
    uint32_t s4_3 = S[67];
    uint32_t s4_4 = S[68];
    uint32_t s4_5 = S[69];
    uint32_t s4_6 = S[70];
    uint32_t s4_7 = S[71];
    uint32_t s4_8 = S[72];
    uint32_t s4_9 = S[73];
    uint32_t s4_10 = S[74];
    uint32_t s4_11 = S[75];
    uint32_t s4_12 = S[76];
    uint32_t s4_13 = S[77];
    uint32_t s4_14 = S[78];
    uint32_t s4_15 = S[79];
    uint32_t k0 = kap[0];
    uint32_t k1 = kap[1];
    uint32_t k2 = kap[2];
    uint32_t k3 = kap[3];
    uint32_t k4 = kap[4];
    /* --- 相位 1：线性核 + 非线性（S 盒批处理） --- */
    uint32_t lin0 = nl_rdp64(8193ULL * s0_0 + 16777217ULL * s0_4 + ((uint64_t)s0_9 << 22) + 9ULL * s0_13 + ((uint64_t)s0_15 << 19));
    uint32_t a0 = s0_15 + s0_10;
    uint32_t b0 = s0_5 ^ s0_0;
    uint32_t u0 = (a0 << 16) | (b0 >> 16);
    uint32_t v0 = (b0 << 16) | (a0 >> 16);
    uint32_t lu0 = nl_ll0(u0);
    uint32_t lv0 = nl_ll1(v0);
    uint32_t lin1 = nl_rdp64(8193ULL * s1_0 + 16777217ULL * s1_4 + ((uint64_t)s1_9 << 22) + 9ULL * s1_13 + ((uint64_t)s1_15 << 19));
    uint32_t a1 = s1_15 + s1_10;
    uint32_t b1 = s1_5 ^ s1_0;
    uint32_t u1 = (a1 << 16) | (b1 >> 16);
    uint32_t v1 = (b1 << 16) | (a1 >> 16);
    uint32_t lu1 = nl_ll0(u1);
    uint32_t lv1 = nl_ll1(v1);
    uint32_t lin2 = nl_rdp64(8193ULL * s2_0 + 16777217ULL * s2_4 + ((uint64_t)s2_9 << 22) + 9ULL * s2_13 + ((uint64_t)s2_15 << 19));
    uint32_t a2 = s2_15 + s2_10;
    uint32_t b2 = s2_5 ^ s2_0;
    uint32_t u2 = (a2 << 16) | (b2 >> 16);
    uint32_t v2 = (b2 << 16) | (a2 >> 16);
    uint32_t lu2 = nl_ll0(u2);
    uint32_t lv2 = nl_ll1(v2);
    uint32_t lin3 = nl_rdp64(8193ULL * s3_0 + 16777217ULL * s3_4 + ((uint64_t)s3_9 << 22) + 9ULL * s3_13 + ((uint64_t)s3_15 << 19));
    uint32_t a3 = s3_15 + s3_10;
    uint32_t b3 = s3_5 ^ s3_0;
    uint32_t u3 = (a3 << 16) | (b3 >> 16);
    uint32_t v3 = (b3 << 16) | (a3 >> 16);
    uint32_t lu3 = nl_ll0(u3);
    uint32_t lv3 = nl_ll1(v3);
    uint32_t lin4 = nl_rdp64(8193ULL * s4_0 + 16777217ULL * s4_4 + ((uint64_t)s4_9 << 22) + 9ULL * s4_13 + ((uint64_t)s4_15 << 19));
    uint32_t a4 = s4_15 + s4_10;
    uint32_t b4 = s4_5 ^ s4_0;
    uint32_t u4 = (a4 << 16) | (b4 >> 16);
    uint32_t v4 = (b4 << 16) | (a4 >> 16);
    uint32_t lu4 = nl_ll0(u4);
    uint32_t lv4 = nl_ll1(v4);
    uint32_t pl0, pr0;
    uint32_t pl1, pr1;
    uint32_t pl2, pr2;
    uint32_t pl3, pr3;
    uint32_t pl4, pr4;
    pl0 = nl_sw(lu0);
    pr0 = nl_sw(lv0);
    pl1 = nl_sw(lu1);
    pr1 = nl_sw(lv1);
    pl2 = nl_sw(lu2);
    pr2 = nl_sw(lv2);
    pl3 = nl_sw(lu3);
    pr3 = nl_sw(lv3);
    pl4 = nl_sw(lu4);
    pr4 = nl_sw(lv4);
    uint32_t phi0 = nl_rdp64((uint64_t)lin0 + (uint32_t)((pl0 ^ nl_rot(s0_10, 8)) + pr0));
    uint32_t phi1 = nl_rdp64((uint64_t)lin1 + (uint32_t)((pl1 ^ nl_rot(s1_10, 8)) + pr1));
    uint32_t phi2 = nl_rdp64((uint64_t)lin2 + (uint32_t)((pl2 ^ nl_rot(s2_10, 8)) + pr2));
    uint32_t phi3 = nl_rdp64((uint64_t)lin3 + (uint32_t)((pl3 ^ nl_rot(s3_10, 8)) + pr3));
    uint32_t phi4 = nl_rdp64((uint64_t)lin4 + (uint32_t)((pl4 ^ nl_rot(s4_10, 8)) + pr4));
    /* --- 相位 2：跨 module 混合 + 第二个 nl_F（S 盒批处理） --- */
    uint32_t X0 = s4_14 ^ nl_rot(s0_9, 7);
    uint32_t Y0 = s1_9 + s3_6;
    uint32_t Z0 = s2_6 ^ nl_rot(s0_1, 11);
    uint32_t W0 = s3_1 + s2_14;
    uint32_t a20 = X0 + Y0;
    uint32_t b20 = Z0 ^ W0;
    uint32_t u20 = (a20 << 16) | (b20 >> 16);
    uint32_t v20 = (b20 << 16) | (a20 >> 16);
    uint32_t lu20 = nl_ll0(u20);
    uint32_t lv20 = nl_ll1(v20);
    uint32_t ql0, qr0;
    uint32_t X1 = s0_14 ^ nl_rot(s1_9, 7);
    uint32_t Y1 = s2_9 + s4_6;
    uint32_t Z1 = s3_6 ^ nl_rot(s1_1, 11);
    uint32_t W1 = s4_1 + s3_14;
    uint32_t a21 = X1 + Y1;
    uint32_t b21 = Z1 ^ W1;
    uint32_t u21 = (a21 << 16) | (b21 >> 16);
    uint32_t v21 = (b21 << 16) | (a21 >> 16);
    uint32_t lu21 = nl_ll0(u21);
    uint32_t lv21 = nl_ll1(v21);
    uint32_t ql1, qr1;
    uint32_t X2 = s1_14 ^ nl_rot(s2_9, 7);
    uint32_t Y2 = s3_9 + s0_6;
    uint32_t Z2 = s4_6 ^ nl_rot(s2_1, 11);
    uint32_t W2 = s0_1 + s4_14;
    uint32_t a22 = X2 + Y2;
    uint32_t b22 = Z2 ^ W2;
    uint32_t u22 = (a22 << 16) | (b22 >> 16);
    uint32_t v22 = (b22 << 16) | (a22 >> 16);
    uint32_t lu22 = nl_ll0(u22);
    uint32_t lv22 = nl_ll1(v22);
    uint32_t ql2, qr2;
    uint32_t X3 = s2_14 ^ nl_rot(s3_9, 7);
    uint32_t Y3 = s4_9 + s1_6;
    uint32_t Z3 = s0_6 ^ nl_rot(s3_1, 11);
    uint32_t W3 = s1_1 + s0_14;
    uint32_t a23 = X3 + Y3;
    uint32_t b23 = Z3 ^ W3;
    uint32_t u23 = (a23 << 16) | (b23 >> 16);
    uint32_t v23 = (b23 << 16) | (a23 >> 16);
    uint32_t lu23 = nl_ll0(u23);
    uint32_t lv23 = nl_ll1(v23);
    uint32_t ql3, qr3;
    uint32_t X4 = s3_14 ^ nl_rot(s4_9, 7);
    uint32_t Y4 = s0_9 + s2_6;
    uint32_t Z4 = s1_6 ^ nl_rot(s4_1, 11);
    uint32_t W4 = s2_1 + s1_14;
    uint32_t a24 = X4 + Y4;
    uint32_t b24 = Z4 ^ W4;
    uint32_t u24 = (a24 << 16) | (b24 >> 16);
    uint32_t v24 = (b24 << 16) | (a24 >> 16);
    uint32_t lu24 = nl_ll0(u24);
    uint32_t lv24 = nl_ll1(v24);
    uint32_t ql4, qr4;
    ql0 = nl_sw(lu20);
    qr0 = nl_sw(lv20);
    ql1 = nl_sw(lu21);
    qr1 = nl_sw(lv21);
    ql2 = nl_sw(lu22);
    qr2 = nl_sw(lv22);
    ql3 = nl_sw(lu23);
    qr3 = nl_sw(lv23);
    ql4 = nl_sw(lu24);
    qr4 = nl_sw(lv24);
    uint32_t gam0 = (uint32_t)((ql0 ^ nl_rot(Y0, 8)) + qr0) ^ k0;
    uint32_t gam1 = (uint32_t)((ql1 ^ nl_rot(Y1, 8)) + qr1) ^ k1;
    uint32_t gam2 = (uint32_t)((ql2 ^ nl_rot(Y2, 8)) + qr2) ^ k2;
    uint32_t gam3 = (uint32_t)((ql3 ^ nl_rot(Y3, 8)) + qr3) ^ k3;
    uint32_t gam4 = (uint32_t)((ql4 ^ nl_rot(Y4, 8)) + qr4) ^ k4;
    /* --- 相位 3：行移位 + 注入 --- */
    uint32_t t0_3 = nl_rdp32(s0_4 ^ nl_rot(gam1, 5));
    uint32_t t0_7 = nl_rdp32(s0_8 ^ nl_rot(gam2, 13));
    uint32_t t0_11 = nl_rdp32(s0_12 ^ nl_rot(gam3, 21));
    uint32_t t0_15 = nl_rdp32(phi0 ^ gam0);
    uint32_t t1_3 = nl_rdp32(s1_4 ^ nl_rot(gam2, 5));
    uint32_t t1_7 = nl_rdp32(s1_8 ^ nl_rot(gam3, 13));
    uint32_t t1_11 = nl_rdp32(s1_12 ^ nl_rot(gam4, 21));
    uint32_t t1_15 = nl_rdp32(phi1 ^ gam1);
    uint32_t t2_3 = nl_rdp32(s2_4 ^ nl_rot(gam3, 5));
    uint32_t t2_7 = nl_rdp32(s2_8 ^ nl_rot(gam4, 13));
    uint32_t t2_11 = nl_rdp32(s2_12 ^ nl_rot(gam0, 21));
    uint32_t t2_15 = nl_rdp32(phi2 ^ gam2);
    uint32_t t3_3 = nl_rdp32(s3_4 ^ nl_rot(gam4, 5));
    uint32_t t3_7 = nl_rdp32(s3_8 ^ nl_rot(gam0, 13));
    uint32_t t3_11 = nl_rdp32(s3_12 ^ nl_rot(gam1, 21));
    uint32_t t3_15 = nl_rdp32(phi3 ^ gam3);
    uint32_t t4_3 = nl_rdp32(s4_4 ^ nl_rot(gam0, 5));
    uint32_t t4_7 = nl_rdp32(s4_8 ^ nl_rot(gam1, 13));
    uint32_t t4_11 = nl_rdp32(s4_12 ^ nl_rot(gam2, 21));
    uint32_t t4_15 = nl_rdp32(phi4 ^ gam4);
    S[0] = s0_1;
    S[1] = s0_2;
    S[2] = s0_3;
    S[3] = t0_3;
    S[4] = s0_5;
    S[5] = s0_6;
    S[6] = s0_7;
    S[7] = t0_7;
    S[8] = s0_9;
    S[9] = s0_10;
    S[10] = s0_11;
    S[11] = t0_11;
    S[12] = s0_13;
    S[13] = s0_14;
    S[14] = s0_15;
    S[15] = t0_15;
    S[16] = s1_1;
    S[17] = s1_2;
    S[18] = s1_3;
    S[19] = t1_3;
    S[20] = s1_5;
    S[21] = s1_6;
    S[22] = s1_7;
    S[23] = t1_7;
    S[24] = s1_9;
    S[25] = s1_10;
    S[26] = s1_11;
    S[27] = t1_11;
    S[28] = s1_13;
    S[29] = s1_14;
    S[30] = s1_15;
    S[31] = t1_15;
    S[32] = s2_1;
    S[33] = s2_2;
    S[34] = s2_3;
    S[35] = t2_3;
    S[36] = s2_5;
    S[37] = s2_6;
    S[38] = s2_7;
    S[39] = t2_7;
    S[40] = s2_9;
    S[41] = s2_10;
    S[42] = s2_11;
    S[43] = t2_11;
    S[44] = s2_13;
    S[45] = s2_14;
    S[46] = s2_15;
    S[47] = t2_15;
    S[48] = s3_1;
    S[49] = s3_2;
    S[50] = s3_3;
    S[51] = t3_3;
    S[52] = s3_5;
    S[53] = s3_6;
    S[54] = s3_7;
    S[55] = t3_7;
    S[56] = s3_9;
    S[57] = s3_10;
    S[58] = s3_11;
    S[59] = t3_11;
    S[60] = s3_13;
    S[61] = s3_14;
    S[62] = s3_15;
    S[63] = t3_15;
    S[64] = s4_1;
    S[65] = s4_2;
    S[66] = s4_3;
    S[67] = t4_3;
    S[68] = s4_5;
    S[69] = s4_6;
    S[70] = s4_7;
    S[71] = t4_7;
    S[72] = s4_9;
    S[73] = s4_10;
    S[74] = s4_11;
    S[75] = t4_11;
    S[76] = s4_13;
    S[77] = s4_14;
    S[78] = s4_15;
    S[79] = t4_15;
    }
