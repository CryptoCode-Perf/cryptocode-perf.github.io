# ZC-DM-1280-512

Algorithm: ZC-DM | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header ZC-DM-1280-512.h, prebuilt ZC-DM-1280-512.so,
KAT vector KAT_2_12_ZC-DM-1280-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 19d694eacd5a635b2c2836c23f9e5e362b630d5e941bf2ecef47603a3a60ff48
Speed (cpB, lower is faster): reference 4.54 / official-optimized 3.27 / optimized 3.12
Speedup: GM(S1-S8) 1.15x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
