# ZC-DMC-1536-1024

Algorithm: ZC-DMC | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header ZC-DMC-1536-1024.h, prebuilt ZC-DMC-1536-1024.so,
KAT vector KAT_2_12_ZC-DMC-1536-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 7d6764f210b3915a8ff103c196424e32cc863157b1f991d89836d6420ba8440b
Speed (cpB, lower is faster): reference 24.13 / official-optimized 15.07 / optimized 11.66
Speedup: GM(S1-S8) 1.32x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
