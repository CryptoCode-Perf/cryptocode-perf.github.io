#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""try_768_vstore.py --- 763 档「写回改为 volatile 存储」单因子实验。

动机（实测依据）：
  `nl_rnd_4_0` 共 953 条指令，其中 88 条是向量指令，全部集中在尾部
  681-941 区间：GCC 的 SLP store-merging 把「32 条连续 u32 写回」
  变成了 8 个 ymm 的组装（32 vmovd + 32 vpinsrd + 16 vpunpcklqdq +
  8 vinserti128）+ 8 条 vmovdqu。也就是说 32 条标量 store 被换成了
  96 条指令 —— 净亏 64 条/轮 × 32 轮。

  已有的 `gen_store_order.py`（rev/odd_even/stride4 重排）三件 sha256
  全等于基准，说明 GCC 在 SLP 阶段把顺序归一化了 ⇒ 重排无效。

  本实验改语义无关的另一面：把写回改成对 `volatile uint32_t *` 的存，
  强制 32 条独立标量 store，禁止 SLP 跨语句合并。单线程语义完全不变。

用法：python3 try_768_vstore.py [build|kat|sweep|all]
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))
GENOUT = os.path.join(HERE, "gen", "out")
OUT = os.path.join(HERE, "out")
WD = os.path.join(HERE, "opp768", "vstore")
SRC768 = os.path.join(GENOUT, "nl_sbox4_sisl_4.c")
FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]
SRCDIR = os.path.join(
    L0, "src/hash-21/Neulaser/Implementations and Test_Vectors/API_CryptHash/"
        "Implementations/Optimized_Implementation")
OPP = os.path.join(L0, "build", "hash-21", "neulaser768", "opt.so")
SO = os.path.join(OUT, "ours_neulaser2_768_noshellvstore.so")


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def wsl(inner, log=None):
    args = ["wsl.exe", "-d", "Debian", "bash", "-lc", inner]
    r = subprocess.run(args, capture_output=True)
    r.stdout = (r.stdout or b"").decode("utf-8", "replace")
    r.stderr = (r.stderr or b"").decode("utf-8", "replace")
    if log:
        open(log, "w", encoding="utf-8").write(r.stdout + "\n" + r.stderr)
    return r


def wpath(p):
    if p.startswith("/"):
        return p          # 已经在 WSL 里（/mnt/c/...），不要再加前缀
    return "/mnt/c/" + p.replace("\\", "/").replace(":", "", 1)


def transform():
    txt = open(SRC768, encoding="utf-8").read()
    pat = re.compile(r"^([ \t]*)S\[(\d+)\] = ([A-Za-z0-9_]+);[ \t]*$", re.M)
    n = len(pat.findall(txt))
    if n < 32:
        raise SystemExit("写回语句只有 %d 条（预期 >= 32）" % n)
    # 只改轮体里的写回（nl_rnd_* 内），函数外的 S[k] 读写不动
    out = pat.sub(lambda m: "%s((volatile uint32_t *)S)[%s] = %s;" %
                  (m.group(1), m.group(2), m.group(3)), txt)
    if "volatile uint32_t" not in out:
        raise SystemExit("替换失败")
    hdr = ("/* 单因子：写回改 volatile 存储，禁 SLP store-merging */\n")
    os.makedirs(WD, exist_ok=True)
    dst = os.path.join(WD, "nl_vstore_sisl_4.c")
    with open(dst, "w", encoding="utf-8", newline="\n") as f:
        f.write(hdr + out)
    print("替换 %d 条写回 -> %s (%d B)" % (n, os.path.relpath(dst, HERE),
                                     os.path.getsize(dst)))
    return dst


def build():
    dst = transform()
    os.makedirs(WD, exist_ok=True)
    # 核心 .c 里没有 CryptHash 入口 —— 必须经 build_noshell 注入外壳后再编，
    # 所以先把转换结果放进 gen/out/ 供 patch_shell 的 #include 找得到。
    core = os.path.join(GENOUT, "nl_vstore_sisl_%d.c" % 4)
    with open(core, "w", encoding="utf-8", newline="\n") as f:
        f.write(open(dst, encoding="utf-8").read())
    sys.path.insert(0, HERE)
    import build_noshell as B  # noqa: E402
    so, d, _span, _srcpath, _sp = B.build(
        4, tag="vstore", counter=False, rname="nl_vstore_sisl_%d.c")
    print("产物 = %s (%d B)" % (os.path.relpath(so, HERE), os.path.getsize(so)))
    print("  sha256 =", sha256(so))
    return 0


def kat():
    sys.path.insert(0, WORK)
    sys.path.insert(0, os.path.join(WORK, "_std"))
    sys.path.insert(0, L0)
    import _kat_full as KF  # noqa: E402
    import kat_gate as KG  # noqa: E402
    recs, used = KG.find_kat("hash-21", "Neulaser-768")
    n, m, first, err = KF.check_all(SO, recs)
    print("KAT %s  n=%d match=%d first_bad=%s err=%s" % (
        os.path.basename(SO), n, m, first, err))
    if m != n or err:
        return 5
    # ISA 复扫
    r = wsl("objdump -d '%s'" % wpath(SO))
    FORB = ("rorx", "andn", "shlx", "shrx", "sarx", "bzhi", "pdep", "pext",
            "vaesenc", "vpternlog", "vprol", "vpror", "vplzcnt", "kmov")
    bad = sum(r.stdout.count("\t" + m2 + " ") + r.stdout.count(" " + m2 + " ")
              for m2 in FORB)
    print("forbidden=%d  ymm=%d  zmm=%d" % (
        bad, r.stdout.count("%ymm"), r.stdout.count("%zmm")))
    # 轮体指令构成
    funcs, cur = {}, None
    for ln in r.stdout.splitlines():
        mm = re.match(r"^([0-9a-f]+) <([^>]+)>:", ln)
        if mm:
            cur = mm.group(2)
            funcs[cur] = []
        elif cur and re.match(r"^\s+[0-9a-f]+:", ln):
            funcs[cur].append(ln)
    b = funcs.get("nl_rnd_4_0", [])
    VEC = ("vmovd", "vpinsrd", "vpunpck", "vinserti")
    print("nl_rnd_4_0 total=%d  vec-tail=%d" % (
        len(b), sum(1 for l in b if any(v in l for v in VEC))))
    return 0 if bad == 0 else 6


def sweep():
    sys.path.insert(0, WORK)
    sys.path.insert(0, WORK + "/_std")
    import bench_proto as BP  # noqa: E402
    rows = []
    for L in (32, 512, 1024, 4096, 65536):
        res = BP.sweep(SO, OPP, lengths=[L], rounds=60, cpu=BP.PIN_CPU,
                       bits_a=768, bits_b=768)
        cell = res[0] if isinstance(res, list) else res[L]
        rows.append((L, cell["ratio"]))
        print("  L=%-6d ratio %.5f  iqr %.2f  batch %s" % (
            L, cell["ratio"], cell.get("iqr", 0), cell.get("batch")))
    g = 1.0
    for _, v in rows:
        g *= v
    g **= 1.0 / len(rows)
    print("geomean = %.6f  (>1 我方快)" % g)
    json.dump({"rows": [{"L": L, "ratio": v} for L, v in rows],
               "geomean": g}, open(os.path.join(HERE, "scratch", "vstore768.json"), "w"),
              ensure_ascii=False, indent=1)
    return 0


def main():
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    if what in ("build", "all"):
        rc = build()
        if rc:
            return rc
    if what in ("kat", "all"):
        rc = kat()
        if rc:
            return rc
    if what in ("sweep", "all"):
        rc = sweep()
        if rc:
            return rc
    return 0


if __name__ == "__main__":
    sys.exit(main())
