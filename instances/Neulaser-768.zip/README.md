# Neulaser-768

Algorithm: Neulaser | Digest bits: 768 | Form: 标量 C

Contents: implementation source/, public header Neulaser-768.h, prebuilt Neulaser-768.so,
KAT vector KAT_2_12_Neulaser-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 1e9134b64e9e4dda60c6b5732c0226968cb5bd87d7d3579a31930d0503554756
Speed (cpB, lower is faster): reference 79.24 / official-optimized 38.67 / optimized 34.62
Speedup: GM(S1-S8) 1.12x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
