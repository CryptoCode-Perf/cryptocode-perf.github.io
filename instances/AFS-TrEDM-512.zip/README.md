# AFS-TrEDM-512

CAP candidate from afstredm512-dsh-pinned-continue-v1; generation contract REF+KAT-only; lineage: own-history continuation.

Run `bash verify.sh`; rebuild with `bash build.sh`, then verify again. See audit/ for scope and measurements. TSC ticks/B is not hardware CPB.
