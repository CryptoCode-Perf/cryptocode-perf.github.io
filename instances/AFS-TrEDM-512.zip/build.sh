#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -Isource source/CryptHash_AlgorithmInstance.c source/afs_sbox64.c source/afs_lmds1600_s6.c source/afs_p1600.c source/afs_tredm.c -o AFS-TrEDM-512.so
