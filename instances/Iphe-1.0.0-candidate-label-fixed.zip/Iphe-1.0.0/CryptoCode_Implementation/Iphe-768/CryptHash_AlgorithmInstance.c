/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).
*/

#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <immintrin.h>

typedef uint64_t word_t;

/* The round constants are expressed as literal macros so that the compiled
   constant-product table below is a genuine C integer constant expression
   (a static const C array element is not a constant expression in C99). */
#define CV0  UINT64_C(0x243f6a8885a308d3)
#define CV1  UINT64_C(0x13198a2e03707344)
#define CV2  UINT64_C(0xa4093822299f31d0)
#define CV3  UINT64_C(0x082efa98ec4e6c89)
#define CV4  UINT64_C(0x452821e638d01377)
#define CV5  UINT64_C(0xbe5466cf34e90c6c)
#define CV6  UINT64_C(0xc0ac29b7c97c50dd)
#define CV7  UINT64_C(0x3f84d5b5b5470917)
#define CV8  UINT64_C(0x9216d5d98979fb1b)
#define CV9  UINT64_C(0xd1310ba698dfb5ac)
#define CV10 UINT64_C(0x2ffd72dbd01adfb7)
#define CV11 UINT64_C(0xb8e1afed6a267e96)
#define CV12 UINT64_C(0xba7c9045f12c7f99)
#define CV13 UINT64_C(0x24a19947b3916cf7)
#define CV14 UINT64_C(0x0801f2e2858efc16)
#define CV15 UINT64_C(0x636920d871574e69)
#define CV16 UINT64_C(0xa458fea3f4933d7e)
#define CV17 UINT64_C(0x0d95748f728eb658)
#define CV18 UINT64_C(0x718bcd5882154aee)
#define CV19 UINT64_C(0x7b54a41dc25a59b5)
#define CV20 UINT64_C(0x9c30d5392af26013)
#define CV21 UINT64_C(0xc5d1b023286085f0)
#define CV22 UINT64_C(0xca417918b8db38ef)
#define CV23 UINT64_C(0x8e79dcb0603a180e)
#define CV24 UINT64_C(0x6c9e0e8bb01e8a3e)
#define CV25 UINT64_C(0xd71577c1bd314b27)

/* Compile-time symbolic folding of the entire round-constant algebra.
   For the layer with group size G = 2<<i in round r the reference XORed
       C[k] ^ C[16+i] ^ C[21+r]
   into every G-th cell (k = index of that cell within its sub-block group).
   The parent folded that XOR into the v0 reduction load and the OUT0 scatter
   load, but still materialised  C[k] ^ rc  at run time with a movabs+xor for
   every one of the 310 per-permutation uses.  There are only
   5 rounds x 5 layers x 16 sub-block indices = 400 distinct combinations;
   compute all of them at compile time and index the resulting table.  Only
   k in [0,16) is ever used (the G=2 layer has the largest M range, 0..15). */
#define CI0  CV16
#define CI1  CV17
#define CI2  CV18
#define CI3  CV19
#define CI4  CV20
#define CR0  CV21
#define CR1  CV22
#define CR2  CV23
#define CR3  CV24
#define CR4  CV25

#define X3(k,i,r) (CV##k ^ CI##i ^ CR##r)
#define KR(i,r) { X3(0,i,r),X3(1,i,r),X3(2,i,r),X3(3,i,r),               \
                  X3(4,i,r),X3(5,i,r),X3(6,i,r),X3(7,i,r),               \
                  X3(8,i,r),X3(9,i,r),X3(10,i,r),X3(11,i,r),             \
                  X3(12,i,r),X3(13,i,r),X3(14,i,r),X3(15,i,r) }
#define KR5(r) { KR(0,r), KR(1,r), KR(2,r), KR(3,r), KR(4,r) }

static const word_t KT[5][5][16] = {
    KR5(0), KR5(1), KR5(2), KR5(3), KR5(4)
};

static word_t rotl64(word_t x, unsigned n)
{
    return (x << n) | (x >> (64U - n));
}

/* Compile-time index/rotation algebra (unchanged from the parent). */
#define ROTV(IDX)  (((7 * (IDX)) % 32) + 16)
#define DEST(IDX)  ((IDX) / 2 + ((IDX) % 2) * 16)

/* KQ points at KT[r][i], so KQ[k] == C[k] ^ C[16+i] ^ C[21+r].
   OUTK reads L+k (k>=1), never a multiple of G, so it needs no constant. */
#define OUT0F(IDX,KK) do { pb[DEST(IDX)] = rotl64((pa[IDX] ^ KQ[KK]) + 3U * s, ROTV(IDX)); } while (0)
#define OUTK(IDX,K)   do { pb[DEST(IDX)] = rotl64(pa[IDX] ^ (s + (s << ((K) + 1))), ROTV(IDX)); } while (0)

/* M indexes the sub-block (v0 constant KQ[M]); L is the output base, a
   multiple of G (OUT0 constant KQ[L/G]). */
#define SB32(M,L) do {                                                         \
    word_t v0 =pa[(M)*32] ^ KQ[(M)], v1 =pa[(M)*32+1], v2 =pa[(M)*32+2], v3 =pa[(M)*32+3];  \
    word_t v4 =pa[(M)*32+4],  v5 =pa[(M)*32+5],  v6 =pa[(M)*32+6],  v7 =pa[(M)*32+7];  \
    word_t v8 =pa[(M)*32+8],  v9 =pa[(M)*32+9],  v10=pa[(M)*32+10], v11=pa[(M)*32+11]; \
    word_t v12=pa[(M)*32+12], v13=pa[(M)*32+13], v14=pa[(M)*32+14], v15=pa[(M)*32+15]; \
    word_t v16=pa[(M)*32+16], v17=pa[(M)*32+17], v18=pa[(M)*32+18], v19=pa[(M)*32+19]; \
    word_t v20=pa[(M)*32+20], v21=pa[(M)*32+21], v22=pa[(M)*32+22], v23=pa[(M)*32+23]; \
    word_t v24=pa[(M)*32+24], v25=pa[(M)*32+25], v26=pa[(M)*32+26], v27=pa[(M)*32+27]; \
    word_t v28=pa[(M)*32+28], v29=pa[(M)*32+29], v30=pa[(M)*32+30], v31=pa[(M)*32+31], s; \
    s = ((((v0+v1)^(v2+v3)) + ((v4+v5)^(v6+v7))) ^                            \
           (((v8+v9)^(v10+v11)) + ((v12+v13)^(v14+v15)))) +                      \
          ((((v16+v17)^(v18+v19)) + ((v20+v21)^(v22+v23))) ^                     \
           (((v24+v25)^(v26+v27)) + ((v28+v29)^(v30+v31))));                     \
    OUT0F((L),((L)/32));                                                       \
    OUTK((L)+1,1);  OUTK((L)+2,2);  OUTK((L)+3,3);  OUTK((L)+4,4);             \
    OUTK((L)+5,5);  OUTK((L)+6,6);  OUTK((L)+7,7);  OUTK((L)+8,8);             \
    OUTK((L)+9,9);  OUTK((L)+10,10);OUTK((L)+11,11);OUTK((L)+12,12);           \
    OUTK((L)+13,13);OUTK((L)+14,14);OUTK((L)+15,15);OUTK((L)+16,16);           \
    OUTK((L)+17,17);OUTK((L)+18,18);OUTK((L)+19,19);OUTK((L)+20,20);           \
    OUTK((L)+21,21);OUTK((L)+22,22);OUTK((L)+23,23);OUTK((L)+24,24);           \
    OUTK((L)+25,25);OUTK((L)+26,26);OUTK((L)+27,27);OUTK((L)+28,28);           \
    OUTK((L)+29,29);OUTK((L)+30,30);OUTK((L)+31,31);                           \
} while (0)

#define SB2(M,L) do {                                                          \
    word_t v0=pa[(M)*2] ^ KQ[(M)], v1=pa[(M)*2+1], s;                          \
    s = v0 + v1;                                                               \
    OUT0F((L),((L)/2)); OUTK((L)+1,1);                                         \
} while (0)

#define SB4(M,L) do {                                                          \
    word_t v0=pa[(M)*4] ^ KQ[(M)], v1=pa[(M)*4+1], v2=pa[(M)*4+2], v3=pa[(M)*4+3], s; \
    s = (v0 + v1) ^ (v2 + v3);                                                 \
    OUT0F((L),((L)/4)); OUTK((L)+1,1); OUTK((L)+2,2); OUTK((L)+3,3);          \
} while (0)

#define SB8(M,L) do {                                                          \
    word_t v0=pa[(M)*8] ^ KQ[(M)], v1=pa[(M)*8+1],v2=pa[(M)*8+2],v3=pa[(M)*8+3]; \
    word_t v4=pa[(M)*8+4],v5=pa[(M)*8+5],v6=pa[(M)*8+6],v7=pa[(M)*8+7],s;     \
    s = ((v0+v1) ^ (v2+v3)) + ((v4+v5) ^ (v6+v7));                             \
    OUT0F((L),((L)/8)); OUTK((L)+1,1); OUTK((L)+2,2); OUTK((L)+3,3);          \
    OUTK((L)+4,4); OUTK((L)+5,5); OUTK((L)+6,6); OUTK((L)+7,7);                \
} while (0)

#define SB16(M,L) do {                                                         \
    word_t v0=pa[(M)*16] ^ KQ[(M)], v1=pa[(M)*16+1],v2=pa[(M)*16+2],v3=pa[(M)*16+3]; \
    word_t v4=pa[(M)*16+4],v5=pa[(M)*16+5],v6=pa[(M)*16+6],v7=pa[(M)*16+7];   \
    word_t v8=pa[(M)*16+8],v9=pa[(M)*16+9],v10=pa[(M)*16+10],v11=pa[(M)*16+11]; \
    word_t v12=pa[(M)*16+12],v13=pa[(M)*16+13],v14=pa[(M)*16+14],v15=pa[(M)*16+15],s; \
    s = (((v0+v1) ^ (v2+v3)) + ((v4+v5) ^ (v6+v7))) ^                         \
        (((v8+v9) ^ (v10+v11)) + ((v12+v13) ^ (v14+v15)));                     \
    OUT0F((L),((L)/16));                                                       \
    OUTK((L)+1,1);  OUTK((L)+2,2);  OUTK((L)+3,3);  OUTK((L)+4,4);             \
    OUTK((L)+5,5);  OUTK((L)+6,6);  OUTK((L)+7,7);  OUTK((L)+8,8);             \
    OUTK((L)+9,9);  OUTK((L)+10,10);OUTK((L)+11,11);OUTK((L)+12,12);           \
    OUTK((L)+13,13);OUTK((L)+14,14);OUTK((L)+15,15);                           \
} while (0)

static void layer_2(word_t *pa, word_t *pb, const word_t *KQ)
{
    SB2(0,16);  SB2(1,18);  SB2(2,20);  SB2(3,22);
    SB2(4,24);  SB2(5,26);  SB2(6,28);  SB2(7,30);
    SB2(8,8);   SB2(9,10);  SB2(10,12); SB2(11,14);
    SB2(12,4);  SB2(13,6);  SB2(14,2);  SB2(15,0);
}

static void layer_4(word_t *pa, word_t *pb, const word_t *KQ)
{
    SB4(0,16); SB4(1,20); SB4(2,24); SB4(3,28);
    SB4(4,8);  SB4(5,12); SB4(6,4);  SB4(7,0);
}

static void layer_8(word_t *pa, word_t *pb, const word_t *KQ)
{
    SB8(0,16); SB8(1,24); SB8(2,8); SB8(3,0);
}

static void layer_16(word_t *pa, word_t *pb, const word_t *KQ)
{
    SB16(0,16); SB16(1,0);
}

static void layer_32(word_t *pa, word_t *pb, const word_t *KQ)
{
    SB32(0,0);
}

void CryptHash_AlgorithmInstance_permutation(word_t x[32])
{
    word_t a[32], *pa = x, *pb = a, *tmp;
    int j;

#define SWAP_LAYERS() do { tmp = pa; pa = pb; pb = tmp; } while (0)
#define ROUND_5(R) do {                                                       \
    layer_2 (pa, pb, KT[(R)][0]); SWAP_LAYERS();                              \
    layer_4 (pa, pb, KT[(R)][1]); SWAP_LAYERS();                              \
    layer_8 (pa, pb, KT[(R)][2]); SWAP_LAYERS();                              \
    layer_16(pa, pb, KT[(R)][3]); SWAP_LAYERS();                              \
    layer_32(pa, pb, KT[(R)][4]); SWAP_LAYERS();                              \
} while (0)

    ROUND_5(0);
    ROUND_5(1);
    ROUND_5(2);
    ROUND_5(3);
    ROUND_5(4);

#undef ROUND_5
#undef SWAP_LAYERS

    for (j = 0; j < 32; j++)
        x[j] = pa[j];
}

static word_t reverse_bytes64(word_t x)
{
    x = ((x & UINT64_C(0xf0f0f0f0f0f0f0f0)) >> 4) |
        ((x & UINT64_C(0x0f0f0f0f0f0f0f0f)) << 4);
    x = ((x & UINT64_C(0xcccccccccccccccc)) >> 2) |
        ((x & UINT64_C(0x3333333333333333)) << 2);
    x = ((x & UINT64_C(0xaaaaaaaaaaaaaaaa)) >> 1) |
        ((x & UINT64_C(0x5555555555555555)) << 1);
    return x;
}

/* reverse_bytes64's masks repeat every byte, so it is eight independent
   per-byte bit reversals: output byte j = rev8(msg[j]).  With rev4(n) the
   4-bit reversal, rev8(b) = (rev4(b&15) << 4) | rev4(b>>4).  Two 16-byte
   pshufb tables hold the low- and high-nibble contributions directly. */
static const unsigned char rev4lo[16] = {
    0x0, 0x8, 0x4, 0xc, 0x2, 0xa, 0x6, 0xe,
    0x1, 0x9, 0x5, 0xd, 0x3, 0xb, 0x7, 0xf
};
static const unsigned char rev4hi[16] = {
    0x00, 0x80, 0x40, 0xc0, 0x20, 0xa0, 0x60, 0xe0,
    0x10, 0x90, 0x50, 0xd0, 0x30, 0xb0, 0x70, 0xf0
};

/* Vectorized whole-block ingest: rev8 each of 16 bytes with two pshufb
   lookups, then XOR the resulting 19 rate words into state in pairs.  The
   odd final word uses a scalar tail to avoid reading past the buffer. */
static void absorb_full_block(word_t state[32], const unsigned char *msg,
                              unsigned long long block,
                              unsigned rate_words)
{
    const __m128i tabhi = _mm_loadu_si128((const __m128i *)rev4hi);
    const __m128i tablo = _mm_loadu_si128((const __m128i *)rev4lo);
    const __m128i mask0f = _mm_set1_epi8((char)0x0f);
    const unsigned long long base = block / 8U;
    unsigned i;

    for (i = 0; i + 1 < rate_words; i += 2) {
        __m128i raw = _mm_loadu_si128((const __m128i *)(msg + base + 8U * i));
        __m128i rev = _mm_or_si128(
            _mm_shuffle_epi8(tabhi, _mm_and_si128(raw, mask0f)),
            _mm_shuffle_epi8(tablo, _mm_and_si128(_mm_srli_epi16(raw, 4), mask0f)));
        word_t w[2] __attribute__((aligned(16)));
        _mm_store_si128((__m128i *)w, rev);
        state[i] ^= w[0];
        state[i + 1] ^= w[1];
    }
    if (i < rate_words) {
        unsigned b;
        word_t r = 0;
        for (b = 0; b < 8U; b++) {
            unsigned char v = msg[base + 8U * i + b];
            r |= (word_t)(rev4lo[v >> 4] | rev4hi[v & 15U]) << (8U * b);
        }
        state[i] ^= r;
    }
}

static word_t load_final_word(const unsigned char *msg,
                              unsigned long long final_base,
                              unsigned long long remaining_bits,
                              unsigned final_bits, unsigned local_base)
{
    unsigned long long lb = (unsigned long long)local_base;
    unsigned long long d = 0, need;
    unsigned b, nvalid = 0;
    word_t raw = 0, lt = 0, eq0 = 0, eq1 = 0;

    if (remaining_bits > lb) {
        d = remaining_bits - lb;
        need = (d >= 64U) ? 64U : d;
        nvalid = (unsigned)((need + 7U) / 8U);
    }

    if (nvalid) {
        unsigned long long byte_base = (final_base + lb) / 8U;
        for (b = 0; b < nvalid; b++)
            raw |= (word_t)msg[byte_base + b] << (8U * b);
    }

    if (d >= 64U)
        lt = ~(word_t)0;
    else if (d)
        lt = ((word_t)1 << (unsigned)d) - 1U;

    if (remaining_bits >= lb && d < 64U)
        eq0 = (word_t)1 << (unsigned)d;

    if (final_bits > lb) {
        unsigned long long e = (unsigned long long)final_bits - 1U - lb;
        if (e < 64U)
            eq1 = (word_t)1 << (unsigned)e;
    }

    return (reverse_bytes64(raw) & lt) | eq0 | eq1;
}

static void store64_le(unsigned char *out, word_t x)
{
    unsigned i;

    for (i = 0; i < 8U; i++)
        out[i] = (unsigned char)(x >> (8U * i));
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    word_t state[32] = {0};
    unsigned rate_bits, rate_words, capacity_words, out_words;
    unsigned long long full_blocks, final_base, block_number, block;
    unsigned remaining_bits, padding_blocks, final_bits, padding_block, i;

    if (digest == 0 || (msg == 0 && msg_len_bits != 0))
        return -1;
    if (digest_len_bits != DIGEST_BIT_LENGTH)
        return -1;

    rate_bits = 2048U - (unsigned)digest_len_bits - 64U;
    rate_words = rate_bits / 64U;
    capacity_words = 32U - rate_words;
    out_words = (unsigned)digest_len_bits / 64U;
    full_blocks = msg_len_bits / rate_bits;
    remaining_bits = (unsigned)(msg_len_bits % rate_bits);
    padding_blocks = remaining_bits > rate_bits - 2U ? 2U : 1U;
    final_bits = padding_blocks * rate_bits;

    for (block_number = 0; block_number < full_blocks; block_number++) {
        word_t feed_forward[17];
        block = block_number * rate_bits;

        absorb_full_block(state, msg, block, rate_words);

        for (i = 0; i < capacity_words; i++)
            feed_forward[i] = state[rate_words + i];

        CryptHash_AlgorithmInstance_permutation(state);

        for (i = 0; i < capacity_words; i++)
            state[rate_words + i] ^= feed_forward[i];
    }

    final_base = full_blocks * rate_bits;
    for (padding_block = 0; padding_block < padding_blocks; padding_block++) {
        word_t feed_forward[17];

        for (i = 0; i < rate_words; i++)
            state[i] ^= load_final_word(msg, final_base, remaining_bits,
                                        final_bits,
                                        padding_block * rate_bits + 64U * i);

        for (i = 0; i < capacity_words; i++)
            feed_forward[i] = state[rate_words + i];

        CryptHash_AlgorithmInstance_permutation(state);

        for (i = 0; i < capacity_words; i++)
            state[rate_words + i] ^= feed_forward[i];
    }

    for (i = 0; i < out_words; i++)
        store64_le(digest + 8U * i, state[rate_words + i]);

    return 0;
}
