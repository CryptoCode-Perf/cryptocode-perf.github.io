/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).
*/

#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <string.h>
#include <immintrin.h>

typedef uint64_t word_t;
typedef __m256i vec;

static const word_t C[26] = {
    UINT64_C(0x243f6a8885a308d3),
    UINT64_C(0x13198a2e03707344),
    UINT64_C(0xa4093822299f31d0),
    UINT64_C(0x082efa98ec4e6c89),
    UINT64_C(0x452821e638d01377),
    UINT64_C(0xbe5466cf34e90c6c),
    UINT64_C(0xc0ac29b7c97c50dd),
    UINT64_C(0x3f84d5b5b5470917),
    UINT64_C(0x9216d5d98979fb1b),
    UINT64_C(0xd1310ba698dfb5ac),
    UINT64_C(0x2ffd72dbd01adfb7),
    UINT64_C(0xb8e1afed6a267e96),
    UINT64_C(0xba7c9045f12c7f99),
    UINT64_C(0x24a19947b3916cf7),
    UINT64_C(0x0801f2e2858efc16),
    UINT64_C(0x636920d871574e69),
    UINT64_C(0xa458fea3f4933d7e),
    UINT64_C(0x0d95748f728eb658),
    UINT64_C(0x718bcd5882154aee),
    UINT64_C(0x7b54a41dc25a59b5),
    UINT64_C(0x9c30d5392af26013),
    UINT64_C(0xc5d1b023286085f0),
    UINT64_C(0xca417918b8db38ef),
    UINT64_C(0x8e79dcb0603a180e),
    UINT64_C(0x6c9e0e8bb01e8a3e),
    UINT64_C(0xd71577c1bd314b27)
};

/*
 * Vector view of the reference permutation.
 *
 * Eight 256-bit registers hold four state words each: register m keeps the
 * natural words 4m..4m+3 in lanes 0..3.  For a layer of group size g the
 * reference computes, per group starting at L,
 *     s      = S(x + L, g)
 *     y[L]   = x[L] + 3*s
 *     y[L+k] = x[L+k] ^ (s + (s << (k+1)))      k = 1..g-1
 * then rotates y[j] by PROT(j) = (7j mod 32)+16 and finally scatters
 *     x[j/2 + (j%2)*16] = y[j],
 * i.e. destination words 0..15 receive the even natural words and 16..31 the
 * odd ones, all in increasing natural order.
 *
 * Hence every layer ends with the *same* fixed deinterleave: destination
 * register n (n<4) gathers the even lanes of source registers 2n and 2n+1,
 * and destination register 4+n gathers their odd lanes.  The group sums S2,
 * S4, S8, S16, S32 are formed with one lane swap plus xor/add trees, the
 * multiply by (1 + 2^(k+1)) is a per-lane shift (vpsllvq) and one add, and
 * only the k == 0 lane takes the "+" form (selected by a blend).  The state
 * therefore stays in registers for all 25 layers.
 */

#define VADD(a, b) _mm256_add_epi64((a), (b))
#define VXOR(a, b) _mm256_xor_si256((a), (b))

/* (l0+l1, l1+l0, l2+l3, l3+l2): pair sums duplicated inside each pair. */
#define S2V(v) VADD((v), _mm256_shuffle_epi32((v), 0x4E))

/* (l0+l1)^(l2+l3) broadcast to all four lanes. */
static inline vec s4v(vec v)
{
    vec a = VADD(v, _mm256_shuffle_epi32(v, 0x4E));
    return VXOR(a, _mm256_permute4x64_epi64(a, 0x4E));
}

/* y = x (+|^) s*(1 + 2^(k+1)) with per-lane k; the k == 0 lane uses "+". */
#define UPD(V, S, SHIFTS, IMM) do {                                    \
    vec sv_ = (S);                                                     \
    vec pv_ = VADD(sv_, _mm256_sllv_epi64(sv_, (SHIFTS)));             \
    (V) = _mm256_blend_epi32(VADD((V), pv_), VXOR((V), pv_), (IMM));   \
} while (0)

/*
 * Every 64-bit lane of this register uses the XOR form (mask 0xFF), so the
 * lane-wise add and the blend that would select it are dead: emit the single
 * xor of the precomputed s*(1 + 2^(k+1)) term.
 */
#define UPDX(V, S, SHIFTS) do {                                        \
    vec pv_ = (S);                                                     \
    pv_ = VADD(pv_, _mm256_sllv_epi64(pv_, (SHIFTS)));                 \
    (V) = VXOR((V), pv_);                                              \
} while (0)

/* rotl by per-lane counts: shift counts and their 64-complements. */
#define ROTV(V, RL, RR)                                                \
    _mm256_or_si256(_mm256_sllv_epi64((V), (RL)),                      \
                    _mm256_srlv_epi64((V), (RR)))

/* prefix XOR: only group starts (the listed lanes) are touched. */
#define PFX2(V, V0, V1) \
    (V) = VXOR((V), _mm256_set_epi64x(0, (long long)(V1), 0, (long long)(V0)))
#define PFX1(V, VAL) \
    (V) = VXOR((V), _mm256_set_epi64x(0, 0, 0, (long long)(VAL)))
#define PB(I, RC) (C[16 + (I)] ^ (RC))

/* shift counts k+1 in natural lane order. */
#define SH14   _mm256_set_epi64x(4, 3, 2, 1)
#define SH58   _mm256_set_epi64x(8, 7, 6, 5)
#define SH912  _mm256_set_epi64x(12, 11, 10, 9)
#define SH1316 _mm256_set_epi64x(16, 15, 14, 13)
#define SH1720 _mm256_set_epi64x(20, 19, 18, 17)
#define SH2124 _mm256_set_epi64x(24, 23, 22, 21)
#define SH2528 _mm256_set_epi64x(28, 27, 26, 25)
#define SH2932 _mm256_set_epi64x(32, 31, 30, 29)
#define SH12   _mm256_set_epi64x(2, 1, 2, 1)

/* PROT(j) for natural j = 4m..4m+3, and its 64-complement. */
#define R0 _mm256_set_epi64x(37, 30, 23, 16)
#define R1 _mm256_set_epi64x(33, 26, 19, 44)
#define R2 _mm256_set_epi64x(29, 22, 47, 40)
#define R3 _mm256_set_epi64x(25, 18, 43, 36)
#define R4 _mm256_set_epi64x(21, 46, 39, 32)
#define R5 _mm256_set_epi64x(17, 42, 35, 28)
#define R6 _mm256_set_epi64x(45, 38, 31, 24)
#define R7 _mm256_set_epi64x(41, 34, 27, 20)

#define Q0 _mm256_set_epi64x(27, 34, 41, 48)
#define Q1 _mm256_set_epi64x(31, 38, 45, 20)
#define Q2 _mm256_set_epi64x(35, 42, 17, 24)
#define Q3 _mm256_set_epi64x(39, 46, 21, 28)
#define Q4 _mm256_set_epi64x(43, 18, 25, 32)
#define Q5 _mm256_set_epi64x(47, 22, 29, 36)
#define Q6 _mm256_set_epi64x(19, 26, 33, 40)
#define Q7 _mm256_set_epi64x(23, 30, 37, 44)

/* (a0,a2,b0,b2) / (a1,a3,b1,b3): the even / odd natural words. */
#define DEIN(A, B, E, O) do {                                          \
    (E) = _mm256_permute4x64_epi64(_mm256_unpacklo_epi64((A), (B)), 0xD8); \
    (O) = _mm256_permute4x64_epi64(_mm256_unpackhi_epi64((A), (B)), 0xD8); \
} while (0)

/* rotate in natural order, then scatter into DST via the fixed deinterleave. */
#define PUBLISH(SRC, DST) do {                                          \
    vec e_, o_;                                                        \
    SRC[0] = ROTV(SRC[0], R0, Q0);                                     \
    SRC[1] = ROTV(SRC[1], R1, Q1);                                     \
    SRC[2] = ROTV(SRC[2], R2, Q2);                                     \
    SRC[3] = ROTV(SRC[3], R3, Q3);                                     \
    SRC[4] = ROTV(SRC[4], R4, Q4);                                     \
    SRC[5] = ROTV(SRC[5], R5, Q5);                                     \
    SRC[6] = ROTV(SRC[6], R6, Q6);                                     \
    SRC[7] = ROTV(SRC[7], R7, Q7);                                     \
    DEIN(SRC[0], SRC[1], e_, o_); (DST)[0] = e_; (DST)[4] = o_;        \
    DEIN(SRC[2], SRC[3], e_, o_); (DST)[1] = e_; (DST)[5] = o_;        \
    DEIN(SRC[4], SRC[5], e_, o_); (DST)[2] = e_; (DST)[6] = o_;        \
    DEIN(SRC[6], SRC[7], e_, o_); (DST)[3] = e_; (DST)[7] = o_;        \
} while (0)

/* ---- i = 0, g = 2: every register holds two groups ----
 * target group L <- source group J:  L=0<-30, 2<-28, 4<-24, 6<-26, 8<-16,
 * 10<-18, 12<-20, 14<-22, 16<-0, 18<-2, 20<-4, 22<-6, 24<-8, 26<-10,
 * 28<-12, 30<-14.  k = 0 or 1 inside each pair, so the shift counts are
 * (2,1,2,1) and only the two even lanes take the "+" form (mask 0x33). */
#define LAYER2(SRC, DST, I, RC) do {                                    \
    vec t0_, t1_, t2_, t3_, t4_, t5_, t6_, t7_;                        \
    PFX2(SRC[0], (C[0]  ^ PB(I, RC)), (C[1]  ^ PB(I, RC)));            \
    PFX2(SRC[1], (C[2]  ^ PB(I, RC)), (C[3]  ^ PB(I, RC)));            \
    PFX2(SRC[2], (C[4]  ^ PB(I, RC)), (C[5]  ^ PB(I, RC)));            \
    PFX2(SRC[3], (C[6]  ^ PB(I, RC)), (C[7]  ^ PB(I, RC)));            \
    PFX2(SRC[4], (C[8]  ^ PB(I, RC)), (C[9]  ^ PB(I, RC)));            \
    PFX2(SRC[5], (C[10] ^ PB(I, RC)), (C[11] ^ PB(I, RC)));            \
    PFX2(SRC[6], (C[12] ^ PB(I, RC)), (C[13] ^ PB(I, RC)));            \
    PFX2(SRC[7], (C[14] ^ PB(I, RC)), (C[15] ^ PB(I, RC)));            \
    t0_ = _mm256_permute4x64_epi64(S2V(SRC[7]), 0x4E);                 \
    t1_ = S2V(SRC[6]);                                                 \
    t2_ = S2V(SRC[4]);                                                 \
    t3_ = S2V(SRC[5]);                                                 \
    t4_ = S2V(SRC[0]);                                                 \
    t5_ = S2V(SRC[1]);                                                 \
    t6_ = S2V(SRC[2]);                                                 \
    t7_ = S2V(SRC[3]);                                                 \
    UPD(SRC[0], t0_, SH12, 0xCC);                                      \
    UPD(SRC[1], t1_, SH12, 0xCC);                                      \
    UPD(SRC[2], t2_, SH12, 0xCC);                                      \
    UPD(SRC[3], t3_, SH12, 0xCC);                                      \
    UPD(SRC[4], t4_, SH12, 0xCC);                                      \
    UPD(SRC[5], t5_, SH12, 0xCC);                                      \
    UPD(SRC[6], t6_, SH12, 0xCC);                                      \
    UPD(SRC[7], t7_, SH12, 0xCC);                                      \
    PUBLISH(SRC, DST);                                                 \
} while (0)

/* ---- i = 1, g = 4: one group per register ----
 * L=0<-16, 4<-20, 8<-24, 12<-28, 16<-8, 20<-12, 24<-4, 28<-0, i.e. target
 * register m takes the S4 broadcast of source register order 7,6,4,5,0,1,2,3.
 * k = lane, so (2,3,4,5) and only lane 0 uses "+" (mask 0xFC). */
#define LAYER4(SRC, DST, I, RC) do {                                    \
    vec t0_, t1_, t2_, t3_, t4_, t5_, t6_, t7_;                        \
    PFX1(SRC[0], (C[0] ^ PB(I, RC)));                                  \
    PFX1(SRC[1], (C[1] ^ PB(I, RC)));                                  \
    PFX1(SRC[2], (C[2] ^ PB(I, RC)));                                  \
    PFX1(SRC[3], (C[3] ^ PB(I, RC)));                                  \
    PFX1(SRC[4], (C[4] ^ PB(I, RC)));                                  \
    PFX1(SRC[5], (C[5] ^ PB(I, RC)));                                  \
    PFX1(SRC[6], (C[6] ^ PB(I, RC)));                                  \
    PFX1(SRC[7], (C[7] ^ PB(I, RC)));                                  \
    t0_ = s4v(SRC[7]);                                                 \
    t1_ = s4v(SRC[6]);                                                 \
    t2_ = s4v(SRC[4]);                                                 \
    t3_ = s4v(SRC[5]);                                                 \
    t4_ = s4v(SRC[0]);                                                 \
    t5_ = s4v(SRC[1]);                                                 \
    t6_ = s4v(SRC[2]);                                                 \
    t7_ = s4v(SRC[3]);                                                 \
    UPD(SRC[0], t0_, SH14, 0xFC);                                      \
    UPD(SRC[1], t1_, SH14, 0xFC);                                      \
    UPD(SRC[2], t2_, SH14, 0xFC);                                      \
    UPD(SRC[3], t3_, SH14, 0xFC);                                      \
    UPD(SRC[4], t4_, SH14, 0xFC);                                      \
    UPD(SRC[5], t5_, SH14, 0xFC);                                      \
    UPD(SRC[6], t6_, SH14, 0xFC);                                      \
    UPD(SRC[7], t7_, SH14, 0xFC);                                      \
    PUBLISH(SRC, DST);                                                 \
} while (0)

/* ---- i = 2, g = 8: two registers per group ----
 * L=0<-24, 8<-16, 16<-0, 24<-8; k = p - L within the group. */
#define LAYER8(SRC, DST, I, RC) do {                                    \
    vec t0_, t1_, t2_, t3_;                                            \
    PFX1(SRC[0], (C[0] ^ PB(I, RC)));                                  \
    PFX1(SRC[2], (C[1] ^ PB(I, RC)));                                  \
    PFX1(SRC[4], (C[2] ^ PB(I, RC)));                                  \
    PFX1(SRC[6], (C[3] ^ PB(I, RC)));                                  \
    t0_ = VADD(s4v(SRC[0]), s4v(SRC[1]));                              \
    t1_ = VADD(s4v(SRC[2]), s4v(SRC[3]));                              \
    t2_ = VADD(s4v(SRC[4]), s4v(SRC[5]));                              \
    t3_ = VADD(s4v(SRC[6]), s4v(SRC[7]));                              \
    UPD(SRC[0], t3_, SH14, 0xFC);                                      \
    UPDX(SRC[1], t3_, SH58);                                           \
    UPD(SRC[2], t2_, SH14, 0xFC);                                      \
    UPDX(SRC[3], t2_, SH58);                                           \
    UPD(SRC[4], t0_, SH14, 0xFC);                                      \
    UPDX(SRC[5], t0_, SH58);                                           \
    UPD(SRC[6], t1_, SH14, 0xFC);                                      \
    UPDX(SRC[7], t1_, SH58);                                           \
    PUBLISH(SRC, DST);                                                 \
} while (0)

/* ---- i = 3, g = 16: four registers per group ----
 * L=0<-16, 16<-0. */
#define LAYER16(SRC, DST, I, RC) do {                                   \
    vec a_, b_;                                                        \
    PFX1(SRC[0], (C[0] ^ PB(I, RC)));                                  \
    PFX1(SRC[4], (C[1] ^ PB(I, RC)));                                  \
    a_ = VXOR(VADD(s4v(SRC[0]), s4v(SRC[1])),                          \
              VADD(s4v(SRC[2]), s4v(SRC[3])));                         \
    b_ = VXOR(VADD(s4v(SRC[4]), s4v(SRC[5])),                          \
              VADD(s4v(SRC[6]), s4v(SRC[7])));                         \
    UPD(SRC[0], b_, SH14, 0xFC);                                       \
    UPDX(SRC[1], b_, SH58);                                            \
    UPDX(SRC[2], b_, SH912);                                           \
    UPDX(SRC[3], b_, SH1316);                                          \
    UPD(SRC[4], a_, SH14, 0xFC);                                       \
    UPDX(SRC[5], a_, SH58);                                            \
    UPDX(SRC[6], a_, SH912);                                           \
    UPDX(SRC[7], a_, SH1316);                                          \
    PUBLISH(SRC, DST);                                                 \
} while (0)

/* ---- i = 4, g = 32: the whole state is one group ---- */
#define LAYER32(SRC, DST, I, RC) do {                                   \
    vec a_, b_;                                                        \
    PFX1(SRC[0], (C[0] ^ PB(I, RC)));                                  \
    a_ = VXOR(VADD(s4v(SRC[0]), s4v(SRC[1])),                          \
              VADD(s4v(SRC[2]), s4v(SRC[3])));                         \
    b_ = VXOR(VADD(s4v(SRC[4]), s4v(SRC[5])),                          \
              VADD(s4v(SRC[6]), s4v(SRC[7])));                         \
    a_ = VADD(a_, b_);                                                 \
    UPD(SRC[0], a_, SH14, 0xFC);                                       \
    UPDX(SRC[1], a_, SH58);                                            \
    UPDX(SRC[2], a_, SH912);                                           \
    UPDX(SRC[3], a_, SH1316);                                          \
    UPDX(SRC[4], a_, SH1720);                                          \
    UPDX(SRC[5], a_, SH2124);                                          \
    UPDX(SRC[6], a_, SH2528);                                          \
    UPDX(SRC[7], a_, SH2932);                                          \
    PUBLISH(SRC, DST);                                                 \
} while (0)

#define RND(SRC, DST, RC) do {                                          \
    LAYER2(SRC, DST, 0, RC);                                            \
    LAYER4(DST, SRC, 1, RC);                                            \
    LAYER8(SRC, DST, 2, RC);                                            \
    LAYER16(DST, SRC, 3, RC);                                           \
    LAYER32(SRC, DST, 4, RC);                                           \
} while (0)

void CryptHash_AlgorithmInstance_permutation(word_t x[32])
{
    vec v[8], w[8];
    unsigned i;

    for (i = 0; i < 8U; i++)
        v[i] = _mm256_loadu_si256((const __m256i *)(const void *)(x + 4U * i));

    RND(v, w, C[21]);
    RND(w, v, C[22]);
    RND(v, w, C[23]);
    RND(w, v, C[24]);
    RND(v, w, C[25]);

    for (i = 0; i < 8U; i++)
        _mm256_storeu_si256((__m256i *)(void *)(x + 4U * i), w[i]);
}

/* Bit-reverse each byte of v independently (the reference reverse8 per byte). */
static word_t rev8_each(word_t v)
{
    v = ((v & UINT64_C(0x5555555555555555)) << 1) |
        ((v >> 1) & UINT64_C(0x5555555555555555));
    v = ((v & UINT64_C(0x3333333333333333)) << 2) |
        ((v >> 2) & UINT64_C(0x3333333333333333));
    v = ((v & UINT64_C(0x0f0f0f0f0f0f0f0f)) << 4) |
        ((v >> 4) & UINT64_C(0x0f0f0f0f0f0f0f0f));
    return v;
}

static word_t load_message_word(const unsigned char *msg, unsigned long long base)
{
    const unsigned char *q = msg + (base >> 3);
    word_t v;

    memcpy(&v, q, sizeof v);
    return rev8_each(v);
}

/* Reverse the bits of each byte of four words at once. */
static inline __m256i rev8_each_x4(__m256i v)
{
    const __m256i m1 = _mm256_set1_epi64x((long long)UINT64_C(0x5555555555555555));
    const __m256i m2 = _mm256_set1_epi64x((long long)UINT64_C(0x3333333333333333));
    const __m256i m3 = _mm256_set1_epi64x((long long)UINT64_C(0x0f0f0f0f0f0f0f0f));
    v = _mm256_or_si256(_mm256_slli_epi64(_mm256_and_si256(v, m1), 1),
                        _mm256_and_si256(_mm256_srli_epi64(v, 1), m1));
    v = _mm256_or_si256(_mm256_slli_epi64(_mm256_and_si256(v, m2), 2),
                        _mm256_and_si256(_mm256_srli_epi64(v, 2), m2));
    v = _mm256_or_si256(_mm256_slli_epi64(_mm256_and_si256(v, m3), 4),
                        _mm256_and_si256(_mm256_srli_epi64(v, 4), m3));
    return v;
}

/* Reverse the bits of each byte of two words at once. */
static inline __m128i rev8_each_x2(__m128i v)
{
    const __m128i m1 = _mm_set1_epi64x((long long)UINT64_C(0x5555555555555555));
    const __m128i m2 = _mm_set1_epi64x((long long)UINT64_C(0x3333333333333333));
    const __m128i m3 = _mm_set1_epi64x((long long)UINT64_C(0x0f0f0f0f0f0f0f0f));
    v = _mm_or_si128(_mm_slli_epi64(_mm_and_si128(v, m1), 1),
                     _mm_and_si128(_mm_srli_epi64(v, 1), m1));
    v = _mm_or_si128(_mm_slli_epi64(_mm_and_si128(v, m2), 2),
                     _mm_and_si128(_mm_srli_epi64(v, 2), m2));
    v = _mm_or_si128(_mm_slli_epi64(_mm_and_si128(v, m3), 4),
                     _mm_and_si128(_mm_srli_epi64(v, 4), m3));
    return v;
}

/*
 * Absorb one full rate block: state[i] ^= rev8(le64(msg[block/8 + 8*i])).
 * Four words are consumed per AVX2 step; the tail stays scalar.  Every load
 * is within the block, so no over-read is introduced.
 */
static void absorb_block(word_t *state, const unsigned char *msg,
                         unsigned long long block, unsigned rate_words)
{
    const unsigned char *q = msg + (block >> 3);
    unsigned i = 0;

    for (; i + 3U < rate_words; i += 4U) {
        __m256i raw, rev, st;
        memcpy(&raw, q + 8U * i, sizeof raw);
        rev = rev8_each_x4(raw);
        memcpy(&st, state + i, sizeof st);
        st = _mm256_xor_si256(st, rev);
        memcpy(state + i, &st, sizeof st);
    }
    for (; i + 1U < rate_words; i += 2U) {
        __m128i raw, rev, st;
        memcpy(&raw, q + 8U * i, sizeof raw);
        rev = rev8_each_x2(raw);
        memcpy(&st, state + i, sizeof st);
        st = _mm_xor_si128(st, rev);
        memcpy(state + i, &st, sizeof st);
    }
    for (; i < rate_words; i++)
        state[i] ^= load_message_word(msg, block + 64ULL * i);
}

/*
 * Absorb one final padding block: state[i] ^= load_final_word(...) for every
 * rate word.  Identical bit semantics to the reference bit loop, but the
 * message window of each word is loaded directly: a whole word is a single
 * constant-size load when it lies fully below remaining_bits, and only the
 * (at most one) partial word needs a variable-size copy.  The terminator and
 * final-length bits are OR-ed into whichever word contains them.  No message
 * byte beyond the last available one is read, and msg may be NULL when no
 * message bits exist because then no load is emitted at all.
 */
static void absorb_final(word_t *state, const unsigned char *msg,
                         unsigned long long final_base,
                         unsigned long long remaining_bits,
                         unsigned final_bits,
                         unsigned long long block_base,
                         unsigned rate_words)
{
    const unsigned char *q = msg ? msg + (final_base >> 3) : msg;
    unsigned full = 0, i = 0;

    if (remaining_bits > block_base) {
        unsigned long long availbits = remaining_bits - block_base;
        full = (unsigned)(availbits >> 6);
        if (full > rate_words)
            full = rate_words;
    }
    for (; i + 3U < full; i += 4U) {
        __m256i raw, rev, st;
        memcpy(&raw, q + 8U * i, sizeof raw);
        rev = rev8_each_x4(raw);
        memcpy(&st, state + i, sizeof st);
        st = _mm256_xor_si256(st, rev);
        memcpy(state + i, &st, sizeof st);
    }
    for (; i + 1U < full; i += 2U) {
        __m128i raw, rev, st;
        memcpy(&raw, q + 8U * i, sizeof raw);
        rev = rev8_each_x2(raw);
        memcpy(&st, state + i, sizeof st);
        st = _mm_xor_si128(st, rev);
        memcpy(state + i, &st, sizeof st);
    }
    for (; i < full; i++) {
        word_t w;
        memcpy(&w, q + 8U * i, sizeof w);
        state[i] ^= rev8_each(w);
    }
    if (full < rate_words) {
        unsigned long long lo = block_base + 64ULL * full;
        if (lo < remaining_bits) {
            unsigned avail = (unsigned)(remaining_bits - lo);   /* 1..63 */
            unsigned nbytes = (avail + 7U) >> 3;
            word_t w = 0;

            memcpy(&w, q + 8U * full, nbytes);
            w = rev8_each(w);
            w &= ((word_t)1 << avail) - 1U;
            state[full] ^= w;
        }
    }
    {
        unsigned long long span = 64ULL * (unsigned long long)rate_words;
        unsigned long long p = remaining_bits;

        if (p >= block_base && (p - block_base) < span) {
            unsigned long long d = p - block_base;
            state[(unsigned)(d >> 6)] ^= (word_t)1 << (unsigned)(d & 63ULL);
        }
        p = (unsigned long long)final_bits - 1ULL;
        if (p >= block_base && (p - block_base) < span) {
            unsigned long long d = p - block_base;
            state[(unsigned)(d >> 6)] ^= (word_t)1 << (unsigned)(d & 63ULL);
        }
    }
}

static void store64_le(unsigned char *out, word_t x)
{
    memcpy(out, &x, sizeof x);
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    word_t state[32] = {0};
    unsigned rate_bits, rate_words, capacity_words, out_words;
    unsigned long long full_blocks, final_base, block_number, block;
    unsigned remaining_bits, padding_blocks, final_bits, padding_block, i;

    if (digest == 0 || (msg == 0 && msg_len_bits != 0))
        return -1;
    if (digest_len_bits != DIGEST_BIT_LENGTH)
        return -1;

    rate_bits = 2048U - (unsigned)digest_len_bits - 64U;
    rate_words = rate_bits / 64U;
    capacity_words = 32U - rate_words;
    out_words = (unsigned)digest_len_bits / 64U;
    full_blocks = msg_len_bits / rate_bits;
    remaining_bits = (unsigned)(msg_len_bits % rate_bits);
    padding_blocks = remaining_bits > rate_bits - 2U ? 2U : 1U;
    final_bits = padding_blocks * rate_bits;

    for (block_number = 0; block_number < full_blocks; block_number++) {
        word_t feed_forward[17];
        block = block_number * rate_bits;

        absorb_block(state, msg, block, rate_words);

        for (i = 0; i < capacity_words; i++)
            feed_forward[i] = state[rate_words + i];

        CryptHash_AlgorithmInstance_permutation(state);

        for (i = 0; i < capacity_words; i++)
            state[rate_words + i] ^= feed_forward[i];
    }

    final_base = full_blocks * rate_bits;
    for (padding_block = 0; padding_block < padding_blocks; padding_block++) {
        word_t feed_forward[17];

        absorb_final(state, msg, final_base, remaining_bits, final_bits,
                     (unsigned long long)padding_block * rate_bits, rate_words);

        for (i = 0; i < capacity_words; i++)
            feed_forward[i] = state[rate_words + i];

        CryptHash_AlgorithmInstance_permutation(state);

        for (i = 0; i < capacity_words; i++)
            state[rate_words + i] ^= feed_forward[i];
    }

    for (i = 0; i < out_words; i++)
        store64_le(digest + 8U * i, state[rate_words + i]);

    return 0;
}
