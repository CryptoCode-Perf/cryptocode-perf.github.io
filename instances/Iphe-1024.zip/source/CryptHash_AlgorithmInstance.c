/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).
*/

#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <string.h>

typedef uint64_t word_t;

static const word_t C[26] = {
    UINT64_C(0x243f6a8885a308d3),
    UINT64_C(0x13198a2e03707344),
    UINT64_C(0xa4093822299f31d0),
    UINT64_C(0x082efa98ec4e6c89),
    UINT64_C(0x452821e638d01377),
    UINT64_C(0xbe5466cf34e90c6c),
    UINT64_C(0xc0ac29b7c97c50dd),
    UINT64_C(0x3f84d5b5b5470917),
    UINT64_C(0x9216d5d98979fb1b),
    UINT64_C(0xd1310ba698dfb5ac),
    UINT64_C(0x2ffd72dbd01adfb7),
    UINT64_C(0xb8e1afed6a267e96),
    UINT64_C(0xba7c9045f12c7f99),
    UINT64_C(0x24a19947b3916cf7),
    UINT64_C(0x0801f2e2858efc16),
    UINT64_C(0x636920d871574e69),
    UINT64_C(0xa458fea3f4933d7e),
    UINT64_C(0x0d95748f728eb658),
    UINT64_C(0x718bcd5882154aee),
    UINT64_C(0x7b54a41dc25a59b5),
    UINT64_C(0x9c30d5392af26013),
    UINT64_C(0xc5d1b023286085f0),
    UINT64_C(0xca417918b8db38ef),
    UINT64_C(0x8e79dcb0603a180e),
    UINT64_C(0x6c9e0e8bb01e8a3e),
    UINT64_C(0xd71577c1bd314b27)
};

/*
 * Specialized permutation.
 *
 * The reference walks 5x5 sub-rounds with a runtime group size g = 2 << i,
 * a recursive subgroup mixer S(x, g), a runtime tweak kt = C[16+i] ^ C[21+r],
 * and a final perfect shuffle x[j/2 + (j%2)*16] = y[j].  Everything is emitted
 * here with constant indices and constant tweaks:
 *
 *   - the mixer tree is inlined (S(x,g) resolves to an add/xor tree that
 *     depends only on g: g=2 add, g=4 xor, g=8 add, g=16 xor, g=32 add),
 *   - the destination base l produced by the reference's bit-reversal scan
 *     ("for (k = 32; k > (l|g); ) { k >>= 1; l ^= k; }") is a compile-time
 *     constant for each (g, j),
 *   - the rotation amount 16 + 7*j%32 and the shuffle index j/2 + (j%2)*16
 *     are folded into the store, so no y[] round trip and no index
 *     arithmetic remain,
 *   - the five outer rounds are unrolled, so every absorb tweak
 *     C[j/g] ^ C[16+i] ^ C[21+r] is a compile-time constant and no runtime
 *     kt value, and no round counter, survives,
 *   - the two 32-word buffers alternate roles: each sub-round reads one
 *     buffer and writes the other, and consecutive sub-rounds already read
 *     the buffer the previous one wrote, so the per-round b -> a copy of the
 *     reference disappears; only the final result is written out.
 *
 * The arithmetic performed and the value written to every lane are exactly
 * those of the reference; only addressing work, the runtime tweak xor and
 * the redundant buffer copies are removed.
 */

#define ROTL64C(v, n)  (((v) << (n)) | ((v) >> (64 - (n))))
#define SHUF(m)        (((m) >> 1) + (((m) & 1) << 4))
#define ROTN(m)        (16 + ((7 * (m)) & 31))

/* reference absorb tweak: C[j] ^ C[16+i] ^ C[21+r], folded per lane */
#define KTW(i, j, rr)  (C[(j)] ^ C[16 + (i)] ^ C[21 + (rr)])

#define S2(xa, o)   ((xa)[(o)] + (xa)[(o) + 1])
#define S4(xa, o)   (S2(xa, o) ^ S2(xa, (o) + 2))
#define S8(xa, o)   (S4(xa, o) + S4(xa, (o) + 4))
#define S16(xa, o)  (S8(xa, o) ^ S8(xa, (o) + 8))
#define S32(xa, o)  (S16(xa, o) + S16(xa, (o) + 16))

#define LANE0(xa, za, m, sv)      (za)[SHUF(m)] = ROTL64C((xa)[(m)] + 3U * (sv), ROTN(m))
#define LANEK(xa, za, m, sv, sh)  (za)[SHUF(m)] = ROTL64C((xa)[(m)] ^ ((sv) + ((sv) << (sh))), ROTN(m))

#define GRP2(xa, za, j, l) do { \
    word_t s_ = S2(xa, j); \
    LANE0(xa, za, (l), s_); \
    LANEK(xa, za, (l) + 1, s_, 2); \
} while (0)

#define GRP4(xa, za, j, l) do { \
    word_t s_ = S4(xa, j); \
    LANE0(xa, za, (l), s_); \
    LANEK(xa, za, (l) + 1, s_, 2); \
    LANEK(xa, za, (l) + 2, s_, 3); \
    LANEK(xa, za, (l) + 3, s_, 4); \
} while (0)

#define GRP8(xa, za, j, l) do { \
    word_t s_ = S8(xa, j); \
    LANE0(xa, za, (l), s_); \
    LANEK(xa, za, (l) + 1, s_, 2); \
    LANEK(xa, za, (l) + 2, s_, 3); \
    LANEK(xa, za, (l) + 3, s_, 4); \
    LANEK(xa, za, (l) + 4, s_, 5); \
    LANEK(xa, za, (l) + 5, s_, 6); \
    LANEK(xa, za, (l) + 6, s_, 7); \
    LANEK(xa, za, (l) + 7, s_, 8); \
} while (0)

#define GRP16(xa, za, j, l) do { \
    word_t s_ = S16(xa, j); \
    LANE0(xa, za, (l), s_); \
    LANEK(xa, za, (l) + 1, s_, 2); \
    LANEK(xa, za, (l) + 2, s_, 3); \
    LANEK(xa, za, (l) + 3, s_, 4); \
    LANEK(xa, za, (l) + 4, s_, 5); \
    LANEK(xa, za, (l) + 5, s_, 6); \
    LANEK(xa, za, (l) + 6, s_, 7); \
    LANEK(xa, za, (l) + 7, s_, 8); \
    LANEK(xa, za, (l) + 8, s_, 9); \
    LANEK(xa, za, (l) + 9, s_, 10); \
    LANEK(xa, za, (l) + 10, s_, 11); \
    LANEK(xa, za, (l) + 11, s_, 12); \
    LANEK(xa, za, (l) + 12, s_, 13); \
    LANEK(xa, za, (l) + 13, s_, 14); \
    LANEK(xa, za, (l) + 14, s_, 15); \
    LANEK(xa, za, (l) + 15, s_, 16); \
} while (0)

#define GRP32(xa, za, j, l) do { \
    word_t s_ = S32(xa, j); \
    LANE0(xa, za, (l), s_); \
    LANEK(xa, za, (l) + 1, s_, 2); \
    LANEK(xa, za, (l) + 2, s_, 3); \
    LANEK(xa, za, (l) + 3, s_, 4); \
    LANEK(xa, za, (l) + 4, s_, 5); \
    LANEK(xa, za, (l) + 5, s_, 6); \
    LANEK(xa, za, (l) + 6, s_, 7); \
    LANEK(xa, za, (l) + 7, s_, 8); \
    LANEK(xa, za, (l) + 8, s_, 9); \
    LANEK(xa, za, (l) + 9, s_, 10); \
    LANEK(xa, za, (l) + 10, s_, 11); \
    LANEK(xa, za, (l) + 11, s_, 12); \
    LANEK(xa, za, (l) + 12, s_, 13); \
    LANEK(xa, za, (l) + 13, s_, 14); \
    LANEK(xa, za, (l) + 14, s_, 15); \
    LANEK(xa, za, (l) + 15, s_, 16); \
    LANEK(xa, za, (l) + 16, s_, 17); \
    LANEK(xa, za, (l) + 17, s_, 18); \
    LANEK(xa, za, (l) + 18, s_, 19); \
    LANEK(xa, za, (l) + 19, s_, 20); \
    LANEK(xa, za, (l) + 20, s_, 21); \
    LANEK(xa, za, (l) + 21, s_, 22); \
    LANEK(xa, za, (l) + 22, s_, 23); \
    LANEK(xa, za, (l) + 23, s_, 24); \
    LANEK(xa, za, (l) + 24, s_, 25); \
    LANEK(xa, za, (l) + 25, s_, 26); \
    LANEK(xa, za, (l) + 26, s_, 27); \
    LANEK(xa, za, (l) + 27, s_, 28); \
    LANEK(xa, za, (l) + 28, s_, 29); \
    LANEK(xa, za, (l) + 29, s_, 30); \
    LANEK(xa, za, (l) + 30, s_, 31); \
    LANEK(xa, za, (l) + 31, s_, 32); \
} while (0)

/* i = 0, g = 2, absorb constant C[16] */
#define SUB2K(xa, za, rr) do { \
    (xa)[0] ^= KTW(0, 0, rr);   (xa)[2] ^= KTW(0, 1, rr); \
    (xa)[4] ^= KTW(0, 2, rr);   (xa)[6] ^= KTW(0, 3, rr); \
    (xa)[8] ^= KTW(0, 4, rr);   (xa)[10] ^= KTW(0, 5, rr); \
    (xa)[12] ^= KTW(0, 6, rr);  (xa)[14] ^= KTW(0, 7, rr); \
    (xa)[16] ^= KTW(0, 8, rr);  (xa)[18] ^= KTW(0, 9, rr); \
    (xa)[20] ^= KTW(0, 10, rr); (xa)[22] ^= KTW(0, 11, rr); \
    (xa)[24] ^= KTW(0, 12, rr); (xa)[26] ^= KTW(0, 13, rr); \
    (xa)[28] ^= KTW(0, 14, rr); (xa)[30] ^= KTW(0, 15, rr); \
    GRP2(xa, za, 0, 16);  GRP2(xa, za, 2, 18); \
    GRP2(xa, za, 4, 20);  GRP2(xa, za, 6, 22); \
    GRP2(xa, za, 8, 24);  GRP2(xa, za, 10, 26); \
    GRP2(xa, za, 12, 28); GRP2(xa, za, 14, 30); \
    GRP2(xa, za, 16, 8);  GRP2(xa, za, 18, 10); \
    GRP2(xa, za, 20, 12); GRP2(xa, za, 22, 14); \
    GRP2(xa, za, 24, 4);  GRP2(xa, za, 26, 6); \
    GRP2(xa, za, 28, 2);  GRP2(xa, za, 30, 0); \
} while (0)

/* i = 1, g = 4, absorb constant C[17] */
#define SUB4K(xa, za, rr) do { \
    (xa)[0] ^= KTW(1, 0, rr);  (xa)[4] ^= KTW(1, 1, rr); \
    (xa)[8] ^= KTW(1, 2, rr);  (xa)[12] ^= KTW(1, 3, rr); \
    (xa)[16] ^= KTW(1, 4, rr); (xa)[20] ^= KTW(1, 5, rr); \
    (xa)[24] ^= KTW(1, 6, rr); (xa)[28] ^= KTW(1, 7, rr); \
    GRP4(xa, za, 0, 16);  GRP4(xa, za, 4, 20); \
    GRP4(xa, za, 8, 24);  GRP4(xa, za, 12, 28); \
    GRP4(xa, za, 16, 8);  GRP4(xa, za, 20, 12); \
    GRP4(xa, za, 24, 4);  GRP4(xa, za, 28, 0); \
} while (0)

/* i = 2, g = 8, absorb constant C[18] */
#define SUB8K(xa, za, rr) do { \
    (xa)[0] ^= KTW(2, 0, rr);  (xa)[8] ^= KTW(2, 1, rr); \
    (xa)[16] ^= KTW(2, 2, rr); (xa)[24] ^= KTW(2, 3, rr); \
    GRP8(xa, za, 0, 16);  GRP8(xa, za, 8, 24); \
    GRP8(xa, za, 16, 8);  GRP8(xa, za, 24, 0); \
} while (0)

/* i = 3, g = 16, absorb constant C[19] */
#define SUB16K(xa, za, rr) do { \
    (xa)[0] ^= KTW(3, 0, rr); (xa)[16] ^= KTW(3, 1, rr); \
    GRP16(xa, za, 0, 16); GRP16(xa, za, 16, 0); \
} while (0)

/* i = 4, g = 32, absorb constant C[20] */
#define SUB32K(xa, za, rr) do { \
    (xa)[0] ^= KTW(4, 0, rr); \
    GRP32(xa, za, 0, 0); \
} while (0)

/*
 * Round scheduling without the caller-state copy.
 *
 * The five sub-rounds of a round are strictly sequential: each one consumes
 * the whole buffer produced by its predecessor, so exactly two 32-word
 * buffers are live at any point.  The reference materialises a third copy of
 * the state (x[] -> a[] on entry, b[] -> x[] on exit, 64 loads + 64 stores per
 * sub-round in the parent).  Here the *alternation itself* is the schedule:
 * the first sub-round reads the caller's x[] in place (its writes all target
 * the other buffer, so every source lane is still live when it is read), and
 * the last sub-round stores straight back into x[].  Every intermediate
 * sub-round therefore renames buffers instead of moving data, and the only
 * remaining state traffic is the 32 calloc'd words of the secondary buffer.
 *
 * Lane arithmetic, tweak constants, rotation amounts, mixer trees and the
 * SHUF de-interleave are untouched: this is a pure buffer-lifetime rewrite.
 */
#define ROUND_A(rr) do { \
    SUB2K(a, b, rr);  SUB4K(b, a, rr);  SUB8K(a, b, rr); \
    SUB16K(b, a, rr); SUB32K(a, b, rr); \
} while (0)

/* a round that starts by reading buffer b and leaves its result in buffer a */
#define ROUND_B(rr) do { \
    SUB2K(b, a, rr);  SUB4K(a, b, rr);  SUB8K(b, a, rr); \
    SUB16K(a, b, rr); SUB32K(b, a, rr); \
} while (0)

/* the first round reads the caller's x[] directly and leaves its result in b */
#define ROUND_IN(rr) do { \
    SUB2K(x, b, rr);  SUB4K(b, a, rr);  SUB8K(a, b, rr); \
    SUB16K(b, a, rr); SUB32K(a, b, rr); \
} while (0)

/* the last round starts from a and writes the result straight back to x[] */
#define ROUND_OUT(rr) do { \
    SUB2K(a, x, rr);  SUB4K(x, a, rr);  SUB8K(a, b, rr); \
    SUB16K(b, a, rr); SUB32K(a, x, rr); \
} while (0)

void CryptHash_AlgorithmInstance_permutation(word_t x[32])
{
    word_t a[32], b[32];

    /* reads x, then b, a, b, a; the result of the fifth round lands in x */
    ROUND_IN(0);
    ROUND_B(1);
    ROUND_A(2);
    ROUND_B(3);
    ROUND_OUT(4);
}

static int get_message_bit(const unsigned char *msg, unsigned long long pos)
{
    return (msg[pos / 8U] >> (7U - (unsigned)(pos % 8U))) & 1U;
}

/*
 * Message-word bit map, derived rather than composed.
 *
 * The reference builds a word by reversing the bits of each message byte
 * separately (eight reverse8() calls) and then assembling those bytes
 * little-endian, i.e. result byte k = reverse8(msg[base/8 + k]).
 *
 * In the parent this was expressed as "big-endian assemble, then bit-reverse
 * the whole 64-bit word".  That composition is the identity
 *
 *     bitrev64(bswap_le(v)) == reverse the bits inside every byte of v
 *
 * because bitrev64(bswap(v)) sends bit 8i+j to bit 63-(8(7-i)+j) = 8i+(7-j),
 * so the byte positions are untouched and only the eight bits of each byte
 * are mirrored.  Written that way the affine layer collapses from seven
 * masked swap stages over the whole word (byte swaps at 8/16/32 plus bit
 * swaps at 1/2/4, ~45 operations and a serial depth of 16) to the three
 * within-byte stages below (12 operations, serial depth 6), and the
 * big-endian byte assembly disappears into a single natural load.
 *
 * The evaluator target is x86-64, where the natural load is little-endian and
 * byte k of the loaded word is msg[base/8 + k], exactly the byte the
 * reference's reverse8() consumes.  No boundary behaviour changes: the same
 * eight bytes are read, and a partially covered word still goes through the
 * bounded per-bit loop in CryptHash().
 */
static word_t reverse_bits_in_bytes(word_t v)
{
    v = ((v >> 1) & UINT64_C(0x5555555555555555)) |
        ((v << 1) & UINT64_C(0xaaaaaaaaaaaaaaaa));
    v = ((v >> 2) & UINT64_C(0x3333333333333333)) |
        ((v << 2) & UINT64_C(0xcccccccccccccccc));
    return ((v >> 4) & UINT64_C(0x0f0f0f0f0f0f0f0f)) |
           ((v << 4) & UINT64_C(0xf0f0f0f0f0f0f0f0));
}

static word_t load_message_word(const unsigned char *msg, unsigned long long base)
{
    word_t w;

    memcpy(&w, msg + (base >> 3), sizeof w);
    return reverse_bits_in_bytes(w);
}

static void store64_le(unsigned char *out, word_t x)
{
    unsigned i;

    for (i = 0; i < 8U; i++)
        out[i] = (unsigned char)(x >> (8U * i));
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    word_t state[32] = {0};
    unsigned rate_bits, rate_words, capacity_words, out_words;
    unsigned long long full_blocks, final_base, block_number, block;
    unsigned remaining_bits, padding_blocks, final_bits, padding_block, i;
    unsigned bit;

    if (digest == 0 || (msg == 0 && msg_len_bits != 0))
        return -1;
    if (digest_len_bits != DIGEST_BIT_LENGTH)
        return -1;

    rate_bits = 2048U - (unsigned)digest_len_bits - 64U;
    rate_words = rate_bits / 64U;
    capacity_words = 32U - rate_words;
    out_words = (unsigned)digest_len_bits / 64U;
    full_blocks = msg_len_bits / rate_bits;
    remaining_bits = (unsigned)(msg_len_bits % rate_bits);
    padding_blocks = remaining_bits > rate_bits - 2U ? 2U : 1U;
    final_bits = padding_blocks * rate_bits;

    for (block_number = 0; block_number < full_blocks; block_number++) {
        word_t feed_forward[17];
        block = block_number * rate_bits;

        for (i = 0; i < rate_words; i++)
            state[i] ^= load_message_word(msg, block + 64ULL * i);

        for (i = 0; i < capacity_words; i++)
            feed_forward[i] = state[rate_words + i];

        CryptHash_AlgorithmInstance_permutation(state);

        for (i = 0; i < capacity_words; i++)
            state[rate_words + i] ^= feed_forward[i];
    }

    /*
     * Final block(s), built at word granularity.
     *
     * The reference loads these words with a 64-step per-bit loop:
     *   bit b of word i carries message bit (local_base + b) when that
     *   position is still inside the message, plus the two padding marker
     *   bits at local positions remaining_bits and final_bits - 1.
     *
     * Because load_message_word() already yields "bit b = message bit b",
     * every fully covered word is one reversed byte load; only the single
     * word that straddles remaining_bits needs a bounded bit loop, and the
     * two marker bits are placed directly.  No message byte outside the
     * valid remaining bits is ever read.
     */
    final_base = full_blocks * rate_bits;
    for (padding_block = 0; padding_block < padding_blocks; padding_block++) {
        word_t feed_forward[17];

        for (i = 0; i < rate_words; i++) {
            unsigned long long lb = (unsigned long long)padding_block * rate_bits
                                    + 64ULL * (unsigned long long)i;
            unsigned long long rem = (unsigned long long)remaining_bits;
            unsigned long long last = (unsigned long long)final_bits - 1ULL;
            word_t w;

            if (lb + 64ULL <= rem) {
                w = load_message_word(msg, final_base + lb);
            } else if (lb >= rem) {
                w = 0;
            } else {
                unsigned long long pos;

                w = 0;
                for (bit = 0, pos = lb;
                     bit < 64U && pos < rem;
                     bit++, pos++)
                    if (get_message_bit(msg, final_base + pos))
                        w |= (word_t)1 << bit;
            }

            if (rem >= lb && rem - lb < 64ULL)
                w |= (word_t)1 << (unsigned)(rem - lb);
            if (last >= lb && last - lb < 64ULL)
                w |= (word_t)1 << (unsigned)(last - lb);

            state[i] ^= w;
        }

        for (i = 0; i < capacity_words; i++)
            feed_forward[i] = state[rate_words + i];

        CryptHash_AlgorithmInstance_permutation(state);

        for (i = 0; i < capacity_words; i++)
            state[rate_words + i] ^= feed_forward[i];
    }

    for (i = 0; i < out_words; i++)
        store64_le(digest + 8U * i, state[rate_words + i]);

    return 0;
}
