# Pavelor candidate package

Includes Pavelor-512, 768 and 1024. Requires x86-64 Linux, GCC, Python 3,
AVX2 and AES-NI. Run `bash build_and_verify.sh`. It rebuilds official reference,
official optimized and CryptoCode implementations, checks full KAT, selected
reference differential and input/output guard-page tests. Optimized builds use
`-maes`; there is no runtime CPU dispatch or fallback.

Candidate only: performance comparison, release review and upstream
redistribution permissions remain pending. Tests do not prove security.
