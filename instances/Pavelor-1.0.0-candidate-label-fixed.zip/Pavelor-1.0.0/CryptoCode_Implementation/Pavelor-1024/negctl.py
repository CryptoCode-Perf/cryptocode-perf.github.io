#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pavelor-1024 交付件的三组负对照（判据必须有反例才算判据）。

n1_rc      : 改 `RC_BYTES[0][0]` 一个字节 ⇒ 摘要**必须**变（若不变 = 该常量是死数据）
n2_round   : 展开从 24 条减到 23 条（少跑一轮）⇒ 摘要**必须**变
n3_noop    : permute24 函数体首插 `(void)0;` ⇒ 摘要**必须不变**（负-负对照）

用法：python3 pavelor/negctl.py
退出码 0 = 三组全部符合预期。
"""
import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
SRC = os.path.join(HERE, "src", "unroll.c")
OUTD = os.path.join(HERE, "out")
OPT = os.path.join(L0, "src", "hash-22", "Pavelor",
                   "Implementations and Test_Vectors", "API_CryptHash",
                   "Implementations", "Optimized_Implementation", "Pavelor-1024")
REF = os.path.join(OUTD, "ref.so")
GATE = os.path.join(L0, "delivery_gate.py")

FLAGS = ("-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer "
         "-std=c99 -Wpedantic -Wall -Wextra -maes -msse2").split()


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def build(tag, text):
    src = os.path.join(OUTD, "neg_%s.c" % tag)
    so = os.path.join(OUTD, "neg_%s.so" % tag)
    open(src, "w", encoding="utf-8", newline="\n").write(text)
    log = os.path.join(OUTD, "neg_%s.build.log" % tag)
    with open(log, "w", encoding="utf-8") as lf:
        r = subprocess.run(["gcc", "-shared", "-fPIC"] + FLAGS +
                           ["-I", OPT, "-I", os.path.join(HERE, "src"),
                            "-o", so, src, os.path.join(OPT, "drng.c")],
                           text=True, stdout=lf, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        sys.exit("构建 %s 失败（看 %s）" % (tag, log))
    return so


def gate_ok(so):
    """返回 (rc, 末行)。rc==0 表示与官方 ref 全等。"""
    log = os.path.join(OUTD, "neg_%s.gate.log" % os.path.basename(so)[4:-3])
    with open(log, "w", encoding="utf-8") as lf:
        r = subprocess.run([sys.executable, GATE, so, REF, "1024"],
                           cwd=L0, text=True, stdout=lf, stderr=subprocess.STDOUT)
    lines = open(log, encoding="utf-8").read().strip().splitlines()
    return r.returncode, (lines[-1] if lines else "")


def main():
    base = open(SRC, encoding="utf-8").read()
    cases = []

    # n1：改一个 RC 字节（RC_BYTES[0][0] 的第一个十六进制字节）
    anchor = "static const CH_ALIGN16 uint8_t RC_BYTES[24][16] = {"
    i = base.find(anchor)
    if i < 0:
        sys.exit("找不到 RC_BYTES 定义")
    j = base.find("0x", i)
    old = base[j:j + 4]
    new = "0x%02x" % ((int(old, 16) ^ 0x01) & 0xFF)
    t1 = base[:j] + new + base[j + 4:]
    if t1 == base:
        sys.exit("n1 替换无效")
    print("n1_rc      : RC_BYTES 首个字节 %s -> %s" % (old, new))
    cases.append(("n1_rc", t1, "必须变"))

    # n2：少跑一轮（24 -> 23）
    last = "    round_local(st, 23u);\n"
    if base.count(last) != 1:
        sys.exit("n2 锚点命中 %d 次" % base.count(last))
    t2 = base.replace(last, "")
    print("n2_round   : 删除 `round_local(st, 23u);`（24 轮 -> 23 轮）")
    cases.append(("n2_round", t2, "必须变"))

    # n3：空操作（permute24 体首插 (void)0;）
    k = base.find("static CH_FORCE_INLINE void permute24(CHState* st)\n{\n")
    if k < 0:
        sys.exit("n3 锚点找不到")
    ins = k + len("static CH_FORCE_INLINE void permute24(CHState* st)\n{\n")
    t3 = base[:ins] + "    (void)0;\n" + base[ins:]
    print("n3_noop    : permute24 体首插 (void)0;")
    cases.append(("n3_noop", t3, "必须不变"))

    print()
    bad = 0
    for tag, text, expect in cases:
        so = build(tag, text)
        rc, last_line = gate_ok(so)
        changed = (rc != 0)
        want_changed = (expect == "必须变")
        ok = (changed == want_changed)
        print("%-10s %-14s rc=%d  %-22s  %s" % (
            tag, sha(so)[:14], rc, last_line,
            "✓ 符合（%s）" % expect if ok else "✗ 不符（期望%s）" % expect))
        if not ok:
            bad += 1
    print()
    print("三组负对照：%s" % ("全部符合预期" if bad == 0 else "%d 组不符" % bad))
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
