#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_unroll_k.py --- Pavelor-1024 置换展开因子 k 的敏感度实验。

背景（`pavelor/RESULT.md` §8.4 自己标的缺口）：
  现行交付件 `out/ours_unroll.so` 把 `permute24` 完全展开成 24 条
  `round_local(st, <常量>);`，代码从 24176 B 涨到 65136 B（4.3×），
  RESULT 里写着「未做敏感性实验 —— 若判分环境有 I-cache 压力，
  收益可能缩小」。站内该档 gm = 1.0474，离 win 线 1.05 只差 0.3%。

本脚本按 k∈{1,2,3,4,6,8,12,24} 生成 8 个变体（k=1 即官方滚动循环原样），
每个变体都保持 `r` 在组内是常量、循环回边从 24 次降到 24/k 次。
k 必须整除 24。

用法：python3 gen_unroll_k.py <k>     → src/unroll_k<k>.c
      python3 gen_unroll_k.py all     → 全部生成
"""
from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
BASE = os.path.join(L0, "src", "hash-22", "Pavelor",
                    "Implementations and Test_Vectors", "API_CryptHash",
                    "Implementations", "Optimized_Implementation", "Pavelor-1024",
                    "CryptHash_AlgorithmInstance.c")
OUTDIR = os.path.join(HERE, "src")
ROUNDS = 24

OLD = """static CH_FORCE_INLINE void permute24(CHState* st)
{
    unsigned r;
    for (r = 0u; r < CH_ROUNDS; ++r) {
        round_local(st, r);
    }
}"""


def body_for(k):
    if k == 1:
        return OLD           # 原样 = 官方滚动循环
    if ROUNDS % k:
        raise SystemExit("k=%d 不整除 %d" % (k, ROUNDS))
    lines = ["static CH_FORCE_INLINE void permute24(CHState* st)", "{"]
    lines.append("    /* %d 轮，按 k=%d 分组成 %d 次外循环：组内 r 是编译期常量，"
                 % (ROUNDS, k, ROUNDS // k))
    lines.append("     * 轮常量寻址变常量、循环回边从 %d 次降到 %d 次。"
                 % (ROUNDS, ROUNDS // k))
    lines.append("     * 语义与官方滚动循环逐位等价（round_local 只依赖 st 与 r）。 */")
    lines.append("    unsigned g;")
    lines.append("    for (g = 0u; g < %du; g += %du) {" % (ROUNDS, k))
    for j in range(k):
        lines.append("        round_local(st, %2du + g);" % j)
    lines.append("    }")
    lines.append("}")
    return "\n".join(lines)


def gen(k):
    if not os.path.exists(BASE):
        raise SystemExit("缺源：%s" % BASE)
    txt = open(BASE, "r", encoding="utf-8", errors="replace").read()
    if txt.count(OLD) != 1:
        raise SystemExit("permute24 锚点命中 %d 次（必须恰好 1）" % txt.count(OLD))
    out = os.path.join(OUTDIR, "unroll_k%d.c" % k)
    os.makedirs(OUTDIR, exist_ok=True)
    open(out, "w", encoding="utf-8", newline="\n").write(txt.replace(OLD, body_for(k)))
    print("k=%2d -> %s（%d 字节）" % (k, os.path.relpath(out, HERE),
                                 os.path.getsize(out)))
    return 0


def main():
    if len(sys.argv) < 2:
        raise SystemExit("用法：gen_unroll_k.py <k|all>")
    a = sys.argv[1]
    ks = [1, 2, 3, 4, 6, 8, 12, 24] if a == "all" else [int(a)]
    for k in ks:
        gen(k)
    return 0


if __name__ == "__main__":
    sys.exit(main())
