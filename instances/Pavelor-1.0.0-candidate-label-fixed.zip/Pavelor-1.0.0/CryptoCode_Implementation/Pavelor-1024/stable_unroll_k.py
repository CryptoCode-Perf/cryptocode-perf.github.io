#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""stable_unroll_k.py --- Pavelor-1024 展开因子多轮稳健复测。

单跑一轮的 32B 档噪声可以到 ±20%（`pick_unroll_k.log` 里 k=8 的 32B
是 1.1918，比其它档高出一大截），所以判 win/tie/loss 必须多轮重复。

口径：
  * `ratio = opt_ticks / ours_ticks`（>1 我方快）
  * 对手 `out/opt_maes.so`（sha 与 rows/hash-22.json 的 opt.so 一致）
  * 每轮把候选逐个测一遍（同一进程、同一频率状态）
  * 长度去掉 32 B（短消息置信度最低），留 512/1024/4096/65536
  * `WIN_T = 1.05`；跨轮极差 > 1% 判 unstable，不当结论

用法：python3 stable_unroll_k.py [轮数，默认 5] [k ...]
"""
from __future__ import annotations

import json
import os
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
WORK = os.path.dirname(os.path.dirname(L0))
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))
import bench_proto as BP  # noqa: E402

OPP = os.path.join(HERE, "out", "opt_maes.so")
LENGTHS = [512, 1024, 4096, 65536]
WIN_T = 1.05
BITS = 1024


def gm(d):
    p = 1.0
    for v in d.values():
        p *= v
    return p ** (1.0 / len(d))


def verdict(g):
    if g >= WIN_T:
        return "win"
    if g <= 1.0 / WIN_T:
        return "loss"
    return "tie"


def one(cand):
    rows = BP.sweep(cand, OPP, lengths=LENGTHS, rounds=120, cpu=BP.PIN_CPU,
                    bits_a=BITS, bits_b=BITS)
    return {r["length"]: r["ratio"] for r in rows}


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    ks = [int(x) for x in sys.argv[2:]] or [1, 3, 8, 24]
    cands = {}
    for k in ks:
        p = os.path.join(HERE, "out", "ours_unroll_k%d.so" % k)
        if not os.path.exists(p):
            raise SystemExit("缺 %s" % p)
        cands[k] = p
    if not os.path.exists(OPP):
        raise SystemExit("缺对手件 %s" % OPP)

    acc = {k: [] for k in ks}
    for i in range(n):
        parts = []
        for k in ks:
            g = gm(one(cands[k]))
            acc[k].append(g)
            parts.append("k%-2d %.6f" % (k, g))
        print("轮 %d: %s" % (i + 1, "  ".join(parts)))

    print()
    res = {}
    for k in ks:
        med = statistics.median(acc[k])
        spread = 100.0 * (max(acc[k]) - min(acc[k])) / med
        v = "unstable" if spread > 1.0 else verdict(med)
        res["k%d" % k] = {"median": med, "spread_pct": spread, "verdict": v,
                          "rounds": acc[k]}
        print("k=%-2d median %.6f  spread %.2f%%  => %s" % (k, med, spread, v))

    ok = [(r["median"], k) for k, r in res.items() if r["verdict"] == "win"]
    if ok:
        ok.sort(reverse=True)
        print("\n可用作交付件的最优：%s  median %.6f" % (ok[0][1], ok[0][0]))
    dst = os.path.join(HERE, "out", "stable_unroll_k.json")
    json.dump(res, open(dst, "w"), ensure_ascii=False, indent=1)
    print("写出 %s" % dst)
    return 0


if __name__ == "__main__":
    sys.exit(main())
