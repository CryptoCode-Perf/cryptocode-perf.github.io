#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pick_unroll_k.py --- 串行扫 8 个展开因子，量 `ratio = opt_ticks / cand_ticks`。

判据：>1 我方快。对手取 `pavelor/out/opt_maes.so`（与 rows/hash-22.json
记录的 opt.so 同 sha `973f87dc…`），也就是站内 cpb 表用的那一件。

严格串行：一个 k 测完再测下一个，同一进程内逐 k 扫同一组长度，
这样频率状态一致。

用法：python3 pick_unroll_k.py [reps]
"""
from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
WORK = os.path.dirname(os.path.dirname(L0))
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))
import bench_proto as BP  # noqa: E402

OPP = os.path.join(HERE, "out", "opt_maes.so")
LENGTHS = [32, 512, 1024, 4096, 65536]
KS = [1, 2, 3, 4, 6, 8, 12, 24]
BITS = 1024


def gm(vals):
    p = 1.0
    for v in vals:
        p *= v
    return p ** (1.0 / len(vals))


def main():
    reps = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    if not os.path.exists(OPP):
        raise SystemExit("缺对手件：%s" % OPP)
    out = {}
    for k in KS:
        cand = os.path.join(HERE, "out", "ours_unroll_k%d.so" % k)
        if not os.path.exists(cand):
            print("跳过 k=%d（缺件）" % k)
            continue
        vals = []
        line = []
        for L in LENGTHS:
            best = []
            for _ in range(reps):
                res = BP.sweep(cand, OPP, lengths=[L], rounds=60,
                               cpu=BP.PIN_CPU, bits_a=BITS, bits_b=BITS)
                if not res:
                    raise SystemExit("sweep 空结果 k=%d L=%d" % (k, L))
                cell = res[0] if isinstance(res, list) else res[L]
                best.append(cell["ratio"])
            v = max(best)          # reps>1 时取最好（噪声只往上抖）
            vals.append(v)
            line.append("%d:%.4f" % (L, v))
        out["k%d" % k] = {"rows": dict(zip([str(x) for x in LENGTHS], vals)),
                          "geomean": gm(vals)}
        print("k=%2d  gm=%.6f   %s" % (k, out["k%d" % k]["geomean"],
                                       " ".join(line)))
    dst = os.path.join(HERE, "out", "pick_unroll_k.json")
    json.dump(out, open(dst, "w"), ensure_ascii=False, indent=1)
    best = max(out.items(), key=lambda kv: kv[1]["geomean"])
    print("\n最优：%s  gm=%.6f" % (best[0], best[1]["geomean"]))
    print("写出 %s" % dst)
    return 0


if __name__ == "__main__":
    sys.exit(main())
