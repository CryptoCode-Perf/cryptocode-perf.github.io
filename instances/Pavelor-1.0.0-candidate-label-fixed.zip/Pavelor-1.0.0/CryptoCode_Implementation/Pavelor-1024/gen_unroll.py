#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""hash-22 Pavelor-1024 交付件：把 24 轮置换**完全展开**，让状态留在寄存器里。

依据（captain 实测 objdump）：
  官方 opt 的 CryptHash.part.0 = 752 条，其中
      vmovdqa 384 条（51%）、vaesenc 133 条、rsp 引用 346 处
  ⇒ 置换的状态（20 个 __m128i）每轮都经内存往返；且 `permute24` 是
     `for (r=0; r<24; ++r) round_local(st, r);` 的**滚动循环**，
     `load_rc(r)` 的 r 是运行时变量 ⇒ 轮常量也从内存取。

做法（语义零改动）：
  把 permute24 的循环体展开成 24 条 `round_local(st, <常量>);`
  ⇒ r 变编译期常量 ⇒ 轮常量寻址变常量、循环回边消失、GCC 可跨轮做寄存器分配。

不做的事：不动 round_local 的 20 条 aesenc/xor 结构、不动 IV/RC 表、
          不动 padding、不动 squeeze、不动错误码。
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
BASE = os.path.join(L0, "src", "hash-22", "Pavelor",
                    "Implementations and Test_Vectors", "API_CryptHash",
                    "Implementations", "Optimized_Implementation", "Pavelor-1024",
                    "CryptHash_AlgorithmInstance.c")
OUT = os.path.join(HERE, "src", "unroll.c")

OLD = """static CH_FORCE_INLINE void permute24(CHState* st)
{
    unsigned r;
    for (r = 0u; r < CH_ROUNDS; ++r) {
        round_local(st, r);
    }
}"""


def main():
    if not os.path.exists(BASE):
        sys.exit("缺源：%s" % BASE)
    txt = open(BASE, "r", encoding="utf-8", errors="replace").read()
    if txt.count(OLD) != 1:
        sys.exit("permute24 锚点命中 %d 次（必须恰好 1）" % txt.count(OLD))

    lines = ["static CH_FORCE_INLINE void permute24(CHState* st)",
             "{",
             "    /* 24 轮完全展开：r 为编译期常量，轮常量寻址变常量，循环回边消失。",
             "     * 语义与官方 `for (r = 0u; r < CH_ROUNDS; ++r) round_local(st, r);` 逐位等价。 */"]
    for r in range(24):
        lines.append("    round_local(st, %2du);" % r)
    lines.append("}")
    new = "\n".join(lines)

    txt = txt.replace(OLD, new)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, "w", encoding="utf-8", newline="\n").write(txt)
    print("源：%s（%d 字节）" % (BASE, os.path.getsize(BASE)))
    print("产物：%s（%d 字节）" % (OUT, os.path.getsize(OUT)))
    print("已改：permute24 滚动循环 -> 24 条 round_local 常量调用")
    print("未动：round_local 的 20 条 aesenc/xor、IV_BYTES、RC_BYTES、padding、squeeze、错误码")
    return 0


if __name__ == "__main__":
    sys.exit(main())
