#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_unroll_k.py --- 按官方十 flag 编 8 个展开因子变体，并做 KAT + ISA 自检。

编译命令行照 `rows/hash-22.json` 里记录的对手配方逐字：
  -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
  -std=c99 -Wpedantic -Wall -Wextra -maes -msse2
（Pavelor 的算法本体要 AES-NI，官方 README 逐字要求 -maes -msse2，
  这是本站「诚实边界」里唯一允许用 AES 的候选。）

判据：returncode（本仓官方基线本身带 warning，不能拿 log 非空当失败）。
KAT：`_kat_full.check_all` + `kat_gate.find_kat("hash-22","Pavelor-1024")`。
ISA：forbidden 只扫 AVX2 之外的（Pavelor 允许 aesenc，故 aesenc 不进 forbidden）。

用法：python3 build_unroll_k.py
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.abspath(os.path.join(HERE, ".."))
WORK = os.path.dirname(os.path.dirname(L0))
SRCDIR = os.path.join(L0, "src", "hash-22", "Pavelor",
                      "Implementations and Test_Vectors", "API_CryptHash",
                      "Implementations", "Optimized_Implementation", "Pavelor-1024")
FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra",
         "-maes", "-msse2"]
OUT = os.path.join(HERE, "out")
KS = [1, 2, 3, 4, 6, 8, 12, 24]
FORB = ("rorx", "andn", "shlx", "shrx", "sarx", "bzhi", "pdep", "pext",
        "vaesdec", "vaesdeclast", "vpternlog", "vprol", "vpror", "vplzcnt",
        "kmov", "vpmullq")


def sha256(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def wpath(p):
    if p.startswith("/"):
        return p
    return "/mnt/c/" + p.replace("\\", "/").replace(":", "", 1)


def run(cmd, log):
    r = subprocess.run(cmd, capture_output=True)
    out = (r.stdout or b"").decode("utf-8", "replace")
    err = (r.stderr or b"").decode("utf-8", "replace")
    open(log, "w", encoding="utf-8").write(out + "\n" + err)
    return r.returncode, out + err


def build_one(k):
    src = os.path.join(HERE, "src", "unroll_k%d.c" % k)
    if not os.path.exists(src):
        raise SystemExit("缺 %s，先跑 gen_unroll_k.py all" % src)
    so = os.path.join(OUT, "ours_unroll_k%d.so" % k)
    objs = []
    # 两个 TU：交付源 + drng.c（对手配方也是两个源一起编）
    cmd = ["gcc"] + FLAGS + ["-shared", "-fPIC", "-I", SRCDIR, "-o", so,
                             src, os.path.join(SRCDIR, "drng.c")]
    log = os.path.join(OUT, "build_unroll_k%d.log" % k)
    rc, txt = run(cmd, log)
    nwarn = len(re.findall(r"warning:", txt))
    print("k=%2d  编译 rc=%d warning=%d  %s %d B"
          % (k, rc, nwarn, os.path.basename(so),
             os.path.getsize(so) if os.path.exists(so) else -1))
    if rc != 0:
        print(txt[-1500:])
        return None
    return so


def main():
    os.makedirs(OUT, exist_ok=True)
    sys.path.insert(0, WORK)
    sys.path.insert(0, os.path.join(WORK, "_std"))
    sys.path.insert(0, L0)
    import _kat_full as KF  # noqa: E402
    import kat_gate as KG  # noqa: E402

    recs, used = KG.find_kat("hash-22", "Pavelor-1024")
    print("KAT 向量：%s（%d 条）" % (os.path.basename(str(used))[:50], len(recs)))

    info = []
    for k in KS:
        so = build_one(k)
        if not so:
            continue
        n, m, first, err = KF.check_all(so, recs)
        r = subprocess.run(["objdump", "-d", so], capture_output=True)
        txt = (r.stdout or b"").decode("utf-8", "replace")
        bad = sum(txt.count("\t" + x + " ") + txt.count(" " + x + " ")
                  for x in FORB)
        print("      KAT %d/%d  first_bad=%s err=%s  forbidden=%d  "
              "aesenc=%d  ymm=%d" % (n, m, first, err, bad,
                                     txt.count("vaesenc"), txt.count("%ymm")))
        info.append({"k": k, "so": os.path.relpath(so, HERE),
                     "bytes": os.path.getsize(so), "sha256": sha256(so),
                     "kat_n": n, "kat_match": m, "forbidden": bad,
                     "aesenc": txt.count("vaesenc"),
                     "ymm": txt.count("%ymm")})
    dst = os.path.join(OUT, "build_unroll_k.json")
    json.dump(info, open(dst, "w"), ensure_ascii=False, indent=1)
    print("\n写出 %s（%d 个变体）" % (dst, len(info)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
