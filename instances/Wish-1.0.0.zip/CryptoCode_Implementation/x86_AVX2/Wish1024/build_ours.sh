#!/usr/bin/env bash
# MOZI-1024 的 CryptoCode 实现：官方外壳逐字保留 + 引擎置换核（官方 .c 挖掉 permutation 换引擎核）。
set -euo pipefail
cd "$(dirname "$0")"
REF=../../../Reference_Implementation/Wish1024_reference
OPT=../../../Optimized_Implementation/Wish1024_x86_performance_optimized
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -maes"
mkdir -p ../../../build
gcc $FLAGS -shared -fPIC -I "$REF" -I "$OPT" \
    -o ../../../build/our_1024.so wish1024.c -lm
echo "built build/our_1024.so"
