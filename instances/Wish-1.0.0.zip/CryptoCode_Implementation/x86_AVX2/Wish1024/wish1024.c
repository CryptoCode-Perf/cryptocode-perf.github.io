/*
 * Wish1024 (hash-35) -- our implementation.
 *
 * Structure (line numbers refer to the official sources; see MODEL.md):
 *   state    : 16 x 128-bit lanes = 2048 bits
 *   rate     : first 8 lanes      = 1024 bits
 *   one block: 8 xor absorb -> 12 x (1 tweak xor + 2 AES rounds + mixing M1..M4)
 *              -> 8 xor feedforward of lanes 8..15
 *   digest   : lanes 8..15 as-is (no extra permutation)
 *
 * Build switches
 *   (default)      state held in 8 ymm as Y_k = [lane k | lane k+8]; the mixing
 *                  network then needs 8 ymm unpacks per level instead of 8 xmm
 *                  unpacks per level-pair, and AES is done on the two 128-bit
 *                  halves in place (VAES is not used: the opponent does not use it).
 *   -DWISH_XMIX    the plain 128-bit state and 128-bit network (A/B control).
 *                  Also selected by -DWISH_NO_AES.
 *   -DWISH_NO_AES  AES-NI-free fallback (SubBytes/ShiftRows/MixColumns in C);
 *                  this variant compiles under the plain official ten flags.
 */
#include <stdint.h>
#include <string.h>
#include <immintrin.h>

#include "wish_tables.h"

#define WISH_NLANES     16u
#define WISH_NHALF      8u
#define WISH_RATE_BITS  1024u
#define WISH_RATE_BYTES 128u
#ifndef WISH_NSTEPS
#define WISH_NSTEPS     12u
#endif

typedef __m128i x128;
typedef __m256i y256;

/* Unaligned load: the public API takes a plain const unsigned char *, so the
 * message pointer carries no alignment guarantee.  The official optimized
 * build tolerates unaligned message pointers (verified against ref.so and
 * opp/Wish1024_perf_maes_avx2.so at off=1/8), so we must too. */
#define AI(p) _mm_loadu_si128((const __m128i *)(const void *)(p))

#if defined(WISH_NO_AES)
#define WISH_XMIX 1
#endif

/* ------------------------------------------------------------------ *
 *  AES round
 * ------------------------------------------------------------------ */
#if defined(WISH_NO_AES)

static inline unsigned char wish_xtime(unsigned char a)
{
    return (unsigned char)((a << 1) ^ ((a & 0x80u) ? 0x1bu : 0u));
}

/* identical to the reference wish.c AESR() (SubBytes; ShiftRows; MixColumns),
 * then AddRoundKey -- i.e. exactly what _mm_aesenc_si128 does. */
static inline x128 wish_aesr(x128 x, x128 k)
{
    unsigned char b[16], o[16];
    int row, col;
    _mm_storeu_si128((__m128i *)(void *)b, x);
    for (row = 0; row < 16; ++row) {
        b[row] = wish_sbox[b[row]];
    }
    for (row = 0; row < 4; ++row) {
        for (col = 0; col < 4; ++col) {
            o[col * 4 + row] = b[(((col + row) & 3) * 4) + row];   /* ShiftRows */
        }
    }
    for (col = 0; col < 4; ++col) {
        unsigned char c0 = o[col * 4 + 0], c1 = o[col * 4 + 1];
        unsigned char c2 = o[col * 4 + 2], c3 = o[col * 4 + 3];
        b[col * 4 + 0] = (unsigned char)(wish_xtime(c0) ^ (wish_xtime(c1) ^ c1) ^ c2 ^ c3);
        b[col * 4 + 1] = (unsigned char)(c0 ^ wish_xtime(c1) ^ (wish_xtime(c2) ^ c2) ^ c3);
        b[col * 4 + 2] = (unsigned char)(c0 ^ c1 ^ wish_xtime(c2) ^ (wish_xtime(c3) ^ c3));
        b[col * 4 + 3] = (unsigned char)((wish_xtime(c0) ^ c0) ^ c1 ^ c2 ^ wish_xtime(c3));
    }
    return _mm_xor_si128(_mm_loadu_si128((const __m128i *)(const void *)b), k);
}

#else

#define wish_aesr(x, k) _mm_aesenc_si128((x), (k))

#endif /* WISH_NO_AES */

/* ================================================================== *
 *  WISH_XMIX: plain 128-bit state, official 128-bit mixing order
 * ================================================================== */
#if defined(WISH_XMIX)

#define XMIX(g, A, B)                                            \
    do {                                                         \
        __m128i _lo = _mm_unpacklo_epi##g((A), (B));             \
        (B) = _mm_unpackhi_epi##g((A), (B));                     \
        (A) = _lo;                                               \
    } while (0)

static inline void wish_mix(x128 s[WISH_NLANES])
{
    XMIX(8, s[0], s[1]);   XMIX(8, s[2], s[3]);   XMIX(8, s[4], s[5]);   XMIX(8, s[6], s[7]);
    XMIX(8, s[8], s[9]);   XMIX(8, s[10], s[11]); XMIX(8, s[12], s[13]); XMIX(8, s[14], s[15]);
    XMIX(16, s[0], s[2]);  XMIX(16, s[1], s[3]);  XMIX(16, s[4], s[6]);  XMIX(16, s[5], s[7]);
    XMIX(16, s[8], s[10]); XMIX(16, s[9], s[11]); XMIX(16, s[12], s[14]); XMIX(16, s[13], s[15]);
    XMIX(32, s[0], s[4]);  XMIX(32, s[1], s[5]);  XMIX(32, s[2], s[6]);  XMIX(32, s[3], s[7]);
    XMIX(32, s[8], s[12]); XMIX(32, s[9], s[13]); XMIX(32, s[10], s[14]); XMIX(32, s[11], s[15]);
    XMIX(64, s[0], s[8]);  XMIX(64, s[1], s[9]);  XMIX(64, s[2], s[10]); XMIX(64, s[3], s[11]);
    XMIX(64, s[4], s[12]); XMIX(64, s[5], s[13]); XMIX(64, s[6], s[14]); XMIX(64, s[7], s[15]);
}

static inline void wish_absorb(x128 s[WISH_NLANES], x128 counter, int last_block,
                               const unsigned char *block)
{
    x128 feedforward[WISH_NHALF];
    unsigned j, i;

    for (j = 0; j < WISH_NHALF; ++j) {
        s[j] = _mm_xor_si128(s[j], AI(block + 16 * j));
    }
    if (last_block) {
        s[WISH_NLANES - 1] = _mm_xor_si128(s[WISH_NLANES - 1], AI(wish_theta));
    }
    for (j = 0; j < WISH_NHALF; ++j) {
        feedforward[j] = s[WISH_NHALF + j];
    }

    for (i = 0; i < WISH_NSTEPS; ++i) {
        const x128 zero = _mm_setzero_si128();
        const x128 c0 = AI(wish_rcon[2 * i]);
        const x128 c1 = AI(wish_rcon[2 * i + 1]);

        s[WISH_NHALF] = _mm_xor_si128(s[WISH_NHALF], counter);   /* tweak, lane 8 */

        s[0] = wish_aesr(s[0], c0);
        for (j = 1; j < WISH_NLANES; ++j) {
            s[j] = wish_aesr(s[j], zero);
        }
        s[0] = wish_aesr(s[0], c1);
        for (j = 1; j < WISH_NLANES; ++j) {
            s[j] = wish_aesr(s[j], zero);
        }

        wish_mix(s);
    }

    for (j = 0; j < WISH_NHALF; ++j) {
        s[WISH_NHALF + j] = _mm_xor_si128(s[WISH_NHALF + j], feedforward[j]);
    }
}

static inline x128 wish_state_lane(const x128 s[WISH_NLANES], unsigned k)
{
    return s[k];
}

static inline void wish_state_store(x128 s[WISH_NLANES], unsigned k, x128 v)
{
    s[k] = v;
}

/* ================================================================== *
 *  default: ymm state, Y_k = [lane k | lane k+8]
 * ================================================================== */
#else

#define YMIX(g, A, B)                                            \
    do {                                                         \
        y256 _lo = _mm256_unpacklo_epi##g((A), (B));             \
        (B) = _mm256_unpackhi_epi##g((A), (B));                  \
        (A) = _lo;                                               \
    } while (0)

/* levels 1..3 act on two lane-pairs at once; level 4 -- whose pairs are exactly
 * (k, k+8) -- is one vpermq per register.  Equivalence with the 128-bit network
 * is proved symbolically in scratch/check_ymm_mix.py. */
static inline void wish_mix(y256 s[WISH_NHALF])
{
    unsigned k;
    YMIX(8, s[0], s[1]);   YMIX(8, s[2], s[3]);   YMIX(8, s[4], s[5]);   YMIX(8, s[6], s[7]);
    YMIX(16, s[0], s[2]);  YMIX(16, s[1], s[3]);  YMIX(16, s[4], s[6]);  YMIX(16, s[5], s[7]);
    YMIX(32, s[0], s[4]);  YMIX(32, s[1], s[5]);  YMIX(32, s[2], s[6]);  YMIX(32, s[3], s[7]);
    for (k = 0; k < WISH_NHALF; ++k) {
        s[k] = _mm256_permute4x64_epi64(s[k], 0xD8);   /* qwords 0,2,1,3 */
    }
}

static inline void wish_absorb(y256 s[WISH_NHALF], x128 counter, int last_block,
                               const unsigned char *block)
{
    x128 feedforward[WISH_NHALF];
    const y256 zero = _mm256_setzero_si256();
    /* lane 8 is the *high* half of Y_0 (Y_k = [lane k | lane k+8]) */
    const y256 cvec = _mm256_inserti128_si256(zero, counter, 1);
    unsigned k, i;

    for (k = 0; k < WISH_NHALF; ++k) {   /* rate = lanes 0..7 = low halves of Y_0..Y_7 */
        s[k] = _mm256_xor_si256(s[k], _mm256_zextsi128_si256(AI(block + 16 * k)));
    }
    if (last_block) {   /* lane 15 == high half of Y_7 */
        y256 th = _mm256_inserti128_si256(zero, AI(wish_theta), 1);
        s[WISH_NHALF - 1] = _mm256_xor_si256(s[WISH_NHALF - 1], th);
    }
    for (k = 0; k < WISH_NHALF; ++k) {          /* lanes 8..15 */
        feedforward[k] = _mm256_extracti128_si256(s[k], 1);
    }

    for (i = 0; i < WISH_NSTEPS; ++i) {
        const x128 c0 = AI(wish_rcon[2 * i]);
        const x128 c1 = AI(wish_rcon[2 * i + 1]);
        y256 v;

        s[0] = _mm256_xor_si256(s[0], cvec);             /* tweak, lane 8 */

        for (k = 0; k < WISH_NHALF; ++k) {
            x128 lo = _mm256_castsi256_si128(s[k]);
            x128 hi = _mm256_extracti128_si256(s[k], 1);
            if (k == 0) {
                lo = wish_aesr(lo, c0);
                lo = wish_aesr(lo, c1);
            } else {
                lo = wish_aesr(lo, _mm_setzero_si128());
                lo = wish_aesr(lo, _mm_setzero_si128());
            }
            hi = wish_aesr(hi, _mm_setzero_si128());
            hi = wish_aesr(hi, _mm_setzero_si128());
            v = _mm256_inserti128_si256(_mm256_castsi128_si256(lo), hi, 1);
            s[k] = v;
        }

        wish_mix(s);
    }

    for (k = 0; k < WISH_NHALF; ++k) {          /* lanes 8..15 */
        x128 hi = _mm_xor_si128(_mm256_extracti128_si256(s[k], 1), feedforward[k]);
        s[k] = _mm256_inserti128_si256(s[k], hi, 1);
    }
}

static inline x128 wish_state_lane(const y256 s[WISH_NHALF], unsigned k)
{
    return (k < WISH_NHALF) ? _mm256_castsi256_si128(s[k])
                            : _mm256_extracti128_si256(s[k - WISH_NHALF], 1);
}

#endif /* WISH_XMIX */

/* ------------------------------------------------------------------ *
 *  driver -- behaviourally identical to the official wish.c, including the
 *  fact that digest_len_bits is not validated (CryptHash returns 0 always).
 * ------------------------------------------------------------------ */
int Wish1024(const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest)
{
    unsigned char padded[WISH_RATE_BYTES];
    unsigned long long n_full, i, full_bytes, partial_bits, tail;
    unsigned k;
#if defined(WISH_XMIX)
    x128 s[WISH_NLANES];
    for (k = 0; k < WISH_NLANES; ++k) {
        s[k] = _mm_setzero_si128();
    }
#else
    y256 s[WISH_NHALF];
    for (k = 0; k < WISH_NHALF; ++k) {
        s[k] = _mm256_setzero_si256();
    }
#endif

    n_full = msg_len_bits / WISH_RATE_BITS;
    for (i = 0; i < n_full; ++i) {
#if defined(WISH_XMIX)
        wish_absorb(s, _mm_set_epi64x(0, (long long)i), 0, msg + WISH_RATE_BYTES * i);
#else
        wish_absorb(s, _mm_set_epi64x(0, (long long)i), 0, msg + WISH_RATE_BYTES * i);
#endif
    }

    full_bytes = msg_len_bits / 8u;
    partial_bits = msg_len_bits % 8u;
    tail = full_bytes % WISH_RATE_BYTES;

    memset(padded, 0, WISH_RATE_BYTES);
    if (tail > 0) {
        memcpy(padded, msg + (full_bytes - tail), (size_t)tail);
    }
    if (partial_bits == 0) {
        padded[tail] = 0x80;
    } else {
        padded[tail] = (unsigned char)((msg[full_bytes] & (0xffu << (8u - partial_bits)))
                                       | (0x80u >> partial_bits));
    }

#if defined(WISH_XMIX)
    wish_absorb(s, _mm_set_epi64x(0, (long long)n_full), 1, padded);
#else
    wish_absorb(s, _mm_set_epi64x(0, (long long)n_full), 1, padded);
#endif

    for (k = 0; k < WISH_NHALF; ++k) {   /* digest = lanes 8..15 */
        _mm_storeu_si128((__m128i *)(void *)(digest + 16 * k),
                         wish_state_lane(s, k + WISH_NHALF));
    }
    return 0;
}

/* the ICCS glue: this instance ignores digest_len_bits (CryptHash_
 * AlgorithmInstance.c of the official optimized implementation, line 24) */
int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    (void)digest_len_bits;
    return Wish1024(msg, msg_len_bits, digest);
}

#ifdef WISH_TEST_HOOKS
/* ---- test hooks: a single block / a single mixing network (for G1) ---- */
int wish_hook_block(unsigned char *state, unsigned long long counter, int last_block,
                    const unsigned char *blk)
{
#if defined(WISH_XMIX)
    x128 s[WISH_NLANES];
    unsigned k;
    for (k = 0; k < WISH_NLANES; ++k) {
        _mm_storeu_si128((__m128i *)(void *)&s[k], AI(state + 16 * k));
    }
    wish_absorb(s, _mm_set_epi64x(0, (long long)counter), last_block, blk);
    for (k = 0; k < WISH_NLANES; ++k) {
        _mm_storeu_si128((__m128i *)(void *)(state + 16 * k), s[k]);
    }
#else
    y256 s[WISH_NHALF];
    unsigned k;
    for (k = 0; k < WISH_NHALF; ++k) {
        x128 lo = AI(state + 16 * k);
        x128 hi = AI(state + WISH_RATE_BYTES + 16 * k);
        s[k] = _mm256_inserti128_si256(_mm256_castsi128_si256(lo), hi, 1);
    }
    wish_absorb(s, _mm_set_epi64x(0, (long long)counter), last_block, blk);
    for (k = 0; k < WISH_NHALF; ++k) {
        _mm_storeu_si128((__m128i *)(void *)(state + 16 * k), _mm256_castsi256_si128(s[k]));
        _mm_storeu_si128((__m128i *)(void *)(state + WISH_RATE_BYTES + 16 * k),
                         _mm256_extracti128_si256(s[k], 1));
    }
#endif
    return 0;
}

int wish_hook_mix(unsigned char *state)
{
#if defined(WISH_XMIX)
    x128 s[WISH_NLANES];
    unsigned k;
    for (k = 0; k < WISH_NLANES; ++k) {
        _mm_storeu_si128((__m128i *)(void *)&s[k], AI(state + 16 * k));
    }
    wish_mix(s);
    for (k = 0; k < WISH_NLANES; ++k) {
        _mm_storeu_si128((__m128i *)(void *)(state + 16 * k), s[k]);
    }
#else
    y256 s[WISH_NHALF];
    unsigned k;
    for (k = 0; k < WISH_NHALF; ++k) {
        x128 lo = AI(state + 16 * k);
        x128 hi = AI(state + WISH_RATE_BYTES + 16 * k);
        s[k] = _mm256_inserti128_si256(_mm256_castsi128_si256(lo), hi, 1);
    }
    wish_mix(s);
    for (k = 0; k < WISH_NHALF; ++k) {
        _mm_storeu_si128((__m128i *)(void *)(state + 16 * k), _mm256_castsi256_si128(s[k]));
        _mm_storeu_si128((__m128i *)(void *)(state + WISH_RATE_BYTES + 16 * k),
                         _mm256_extracti128_si256(s[k], 1));
    }
#endif
    return 0;
}
#endif
