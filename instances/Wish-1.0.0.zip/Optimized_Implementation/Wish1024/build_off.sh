#!/usr/bin/env bash
# 官方优化版是 C（vendor 自己的 .c）：十 flag 原样 + 它 Makefile:2 自带的 -maes。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -maes"
mkdir -p ../../build
gcc $FLAGS -shared -fPIC -o ../../build/off_1024.so     CryptHash_AlgorithmInstance.c wish.c drng.c
echo "built build/off_1024.so"
