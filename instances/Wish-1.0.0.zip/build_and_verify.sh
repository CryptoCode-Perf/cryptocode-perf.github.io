#!/usr/bin/env bash
# MOZI 1.0.0 —— 三方编译 + 22 长度差分 + 黄金向量 + KAT 4097
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build

echo "== [Wish1024] 1/4 编译三方 =="
bash Reference_Implementation/Wish1024/build_ref.sh
bash Optimized_Implementation/Wish1024/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Wish1024/build_ours.sh
echo "== [Wish1024] 2/4 交叉差分（22 个长度，逐字节） =="
gcc -O2 -o build/vec_1024 test/vec_Wish1024.c -ldl
./build/vec_1024 build/ref_1024.so > build/vec_ref_1024.txt
./build/vec_1024 build/off_1024.so > build/vec_off_1024.txt
./build/vec_1024 build/our_1024.so > build/vec_our_1024.txt
cmp build/vec_ref_1024.txt build/vec_off_1024.txt
cmp build/vec_ref_1024.txt build/vec_our_1024.txt
cp build/vec_ref_1024.txt test/golden_vectors_ref_1024.txt
echo "== [Wish1024] 3/4 KAT 全量（4097 条 × 三方） =="
python3 test/kat_check.py build/ref_1024.so 100000 0 kat/KAT_2_12_Wish1024.txt
python3 test/kat_check.py build/off_1024.so 100000 0 kat/KAT_2_12_Wish1024.txt
python3 test/kat_check.py build/our_1024.so 100000 0 kat/KAT_2_12_Wish1024.txt
echo "== [Wish1024] 4/4 完成 =="

echo "== 验证全部通过 =="
