#!/usr/bin/env bash
# Build the Vedak "three tiers in one library" deliverable with the new
# 768 / 512 dedicated fast paths.  MUST be run inside WSL.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

# official ten flags, verbatim, plus the shared-object switches
FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

mkdir -p out
rm -f out/ours_vedak_tiers_fast.so out/ours_vedak_tiers_fast.o

echo "== gen_vedak_tiers_fast.py =="
python3 gen_vedak_tiers_fast.py

echo "== shared object =="
gcc "${FLAGS[@]}" -fPIC -shared -o out/ours_vedak_tiers_fast.so \
    src/vedak_tiers_fast.c

echo "== relocatable object (for static accounting) =="
gcc "${FLAGS[@]}" -fno-lto -c -o out/ours_vedak_tiers_fast.o \
    src/vedak_tiers_fast.c

echo
sha256sum out/ours_vedak_tiers_fast.so out/ours_vedak_tiers_fast.o
ls -l out/ours_vedak_tiers_fast.so out/ours_vedak_tiers_fast.o
