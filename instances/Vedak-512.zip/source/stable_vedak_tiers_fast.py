#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""stable_vedak_tiers_fast.py --- Vedak 768/512 多轮稳健复测。

单跑一轮的 32B 档噪声大（`sweep_tiers_fast.json` 里 32B 只有 1.03~1.06），
判 win/tie/loss 必须多轮重复。

口径：
  * `ratio = opt_ticks / ours_ticks`（>1 我方快）
  * 对手 `build/hash-27/vedak<bits>/opt.so`
  * 长度去掉 32 B（短消息置信度最低），留 512/1024/4096/65536
  * `WIN_T = 1.05`；跨轮极差 > 1% 判 unstable，不当结论

同时并排量「新件 vs 旧件」，把专用快路径的净贡献单列出来。

用法：python3 stable_vedak_tiers_fast.py [轮数，默认 5] [bits ...]
"""
from __future__ import annotations

import json
import os
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))
import bench_proto as BP  # noqa: E402

LENGTHS = [512, 1024, 4096, 65536]
ROUNDS = 120
WIN_T = 1.05
NEW = os.path.join(HERE, "out", "ours_vedak_tiers_fast.so")
OLD = os.path.join(HERE, "out", "ours_vedak_all.so")


def gm(d):
    p = 1.0
    for v in d.values():
        p *= v
    return p ** (1.0 / len(d))


def verdict(g):
    if g >= WIN_T:
        return "win"
    if g <= 1.0 / WIN_T:
        return "loss"
    return "tie"


def one(a, b, bits):
    rows = BP.sweep(a, b, lengths=LENGTHS, rounds=ROUNDS, cpu=BP.PIN_CPU,
                    bits_a=bits, bits_b=bits)
    return {r["length"]: r["ratio"] for r in rows}


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    tiers = [int(x) for x in sys.argv[2:]] or [768, 512]
    res = {}
    for bits in tiers:
        opp = os.path.join(L0, "build", "hash-27", "vedak%d" % bits, "opt.so")
        if not os.path.exists(opp):
            raise SystemExit("缺对手件：%s" % opp)
        acc_new, acc_old = [], []
        for i in range(n):
            gn = gm(one(NEW, opp, bits))
            go = gm(one(OLD, opp, bits))
            acc_new.append(gn)
            acc_old.append(go)
            print("Vedak-%d 轮 %d: 新件 %.6f  旧件 %.6f" % (bits, i + 1, gn, go))
        med_n = statistics.median(acc_new)
        med_o = statistics.median(acc_old)
        sp_n = 100.0 * (max(acc_new) - min(acc_new)) / med_n
        sp_o = 100.0 * (max(acc_old) - min(acc_old)) / med_o
        v_n = "unstable" if sp_n > 1.0 else verdict(med_n)
        v_o = "unstable" if sp_o > 1.0 else verdict(med_o)
        res["%d" % bits] = {
            "new_median": med_n, "new_spread_pct": sp_n, "new_verdict": v_n,
            "old_median": med_o, "old_spread_pct": sp_o, "old_verdict": v_o,
            "gain": med_n / med_o, "rounds_new": acc_new, "rounds_old": acc_old,
        }
        print("  => 新件 median %.6f spread %.2f%% %s | "
              "旧件 median %.6f spread %.2f%% %s | 提速 %.2f%%\n"
              % (med_n, sp_n, v_n, med_o, sp_o, v_o,
                 100.0 * (med_n / med_o - 1.0)))
    dst = os.path.join(HERE, "out", "stable_tiers_fast.json")
    json.dump(res, open(dst, "w"), ensure_ascii=False, indent=1)
    print("写出 %s" % dst)
    return 0


if __name__ == "__main__":
    sys.exit(main())
