#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""kat_vedak_tiers_fast.py --- 对 Vedak 三档做官方 KAT + ISA 自检。

Vedak 官方三档的 opt.so 逐字节相同（一件库按 digest_len_bits 运行时派发），
KAT 向量分三个文件。本站已有的 `Vedak-tiers.so` 也是三档合一，本脚本同时
检 1024/768/512 三档，确认新增的 768/512 专用快路径逐位正确。

用法：python3 kat_vedak_tiers_fast.py [so 路径]
"""
from __future__ import annotations

import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
WORK = os.path.dirname(os.path.dirname(L0))
sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))
sys.path.insert(0, L0)
import _kat_full as KF  # noqa: E402
import kat_gate as KG  # noqa: E402

FORB = ("rorx", "andn", "shlx", "shrx", "sarx", "bzhi", "pdep", "pext",
        "vaesenc", "vaesdec", "vaesenclast", "vaesdeclast", "vpternlog",
        "vprol", "vpror", "vplzcnt", "kmov", "vpmullq")


def isa(path):
    r = subprocess.run(["objdump", "-d", path], capture_output=True)
    t = (r.stdout or b"").decode("utf-8", "replace")
    bad = sum(t.count("\t" + m + " ") + t.count(" " + m + " ") for m in FORB)
    return bad, t.count("%ymm"), t.count("%zmm")


def main():
    so = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        HERE, "out", "ours_vedak_tiers_fast.so")
    if not os.path.exists(so):
        raise SystemExit("缺件：%s" % so)
    print("件：%s（%d B）" % (os.path.relpath(so, HERE), os.path.getsize(so)))
    bad, ymm, zmm = isa(so)
    print("ISA: forbidden=%d ymm=%d zmm=%d" % (bad, ymm, zmm))
    rc = 0
    for bits in (1024, 768, 512):
        inst = "Vedak-%d" % bits
        recs, used = KG.find_kat("hash-27", inst)
        n, m, first, err = KF.check_all(so, recs)
        ok = (n == m and n > 0 and first is None and err is None)
        print("%-10s KAT %d/%d  first_bad=%s err=%s  %s  [%s]"
              % (inst, n, m, first, err, "PASS" if ok else "FAIL",
                 os.path.basename(str(used))))
        if not ok:
            rc = 3
    if bad:
        rc = 4
    return rc


if __name__ == "__main__":
    sys.exit(main())
