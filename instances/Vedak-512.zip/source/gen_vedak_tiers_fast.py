#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_vedak_tiers_fast.py --- 给 Vedak-768 / Vedak-512 各补一条「专用快路径」。

## 为什么要做

站内 Vedak 三档：1024 **1.0773 win**，768 **1.0235 tie**，512 **1.0330 tie**。
三档跑的是同一份 `vedak_tiers.c`，但只有 1024 有一条从早期单独件继承下来的
专用快路径 `vd_hash1024()`：

  * rate 是编译期常量 `VD_RATE_BITS 512` / `VD_RATE_BYTES 64`
  * 吸收是 `vd_absorb()`，内部两次 `vd_expand32` **完全展开**（无循环）
  * 挤出是 8 条写死的 `vd_dump16()`

768 / 512 走通用函数 `vd_hash_bits()`：

  * `rate_bits = 2560u - 2u * bits` 是**运行时变量**
  * 吸收是 `vd_absorb_n(s, p, cells)`，里面 `for (k = 0; k < cells; k += 4u)`
    —— cells 未知 ⇒ 循环不能展开、`s[k >> 1]` 的寄存器下标也不能常量折叠
  * 挤出是 `while (done < out_words)` 动态循环

置换核 `vd_p40`（40 轮、每轮 p5 约 28 条）三档完全一样、一字不动，所以两条
快路径的唯一收益就是「把吸收/挤出/填充的外壳开销从运行时搬到编译期」。

## 做法（语义零改动）

按 1024 那条约 50 行的模板，为每个档生成一份 `vd_hash<BITS>_fast()`：

  * 常量：`rate_bits = 2560 - 2*BITS`、`rate_bytes = rate_bits/8`、
    `rate_cells = rate_bits/64`、`out_words = BITS/64`
  * 吸收：把 `vd_absorb_n` 按 `cells` 展开成 `cells/4` 组两次 `vd_expand32` +
    四条 xor，组内 `s[k>>1]` 的下标全部写成字面量
  * 挤出：`out_words` 已知 ⇒ 展开成固定条数的 `vd_dump16`
  * `CryptHash` 派发改成 768/512 各走自己的快路径；`vd_hash_bits()` 保留
    作为等价性对照（`gates/` 里可拿它与快路径对拍），不再被 CryptHash 调用

一次生成**两个档**到同一个文件（`src/vedak_tiers_fast.c`），因为派发点只有一处，
分别覆盖会互相覆盖。

用法：python3 gen_vedak_tiers_fast.py  → src/vedak_tiers_fast.c
"""
from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "src", "vedak_tiers.c")
OUT = os.path.join(HERE, "src", "vedak_tiers_fast.c")
TIERS = (768, 512)

DISPATCH_OLD = """    if (digest_len_bits == 768 || digest_len_bits == 512) {
        vd_hash_bits(msg, (uint64_t)msg_len_bits, (unsigned int)digest_len_bits,
                     digest);
        return 0;
    }"""

PROTO_OLD = ("int CryptHash(int digest_len_bits, const unsigned char *msg,\n"
             "              unsigned long long msg_len_bits, unsigned char *digest);")


def absorb_block(cells):
    """按 cells 展开的 vd_absorb_n 等价体（cells 是 4 的倍数）。"""
    L = []
    for k in range(0, cells, 4):
        i = k >> 1
        L.append("        vd_expand32(p + %du, &a, &b);" % (k * 8))
        L.append("        s[%d] = _mm256_xor_si256(s[%d], a);" % (i, i))
        L.append("        s[%d] = _mm256_xor_si256(s[%d], b);" % (i + 1, i + 1))
    return L


def emit(bits):
    rate_bits = 2560 - 2 * bits
    rate_bytes = rate_bits // 8
    rate_cells = rate_bits // 64
    out_words = bits // 64
    if out_words % 2 or rate_cells % 2:
        raise SystemExit("BITS=%d 的 rate_cells/out_words 不是偶数" % bits)

    L = []
    L.append("/* ---- Vedak-%d 专用快路径（由 gen_vedak_tiers_fast.py 生成）----" % bits)
    L.append(" * rate %d 位 = %d 字 = %d B，摘要 %d 字 = %d B；"
             % (rate_bits, rate_cells, rate_bytes, out_words, bits // 8))
    L.append(" * 吸收按 %d 字展开（%d 组 vd_expand32 + 2 条 xor/组），挤出 %d 条 dump16 展开。"
             % (rate_cells, rate_cells // 4, out_words // 2))
    L.append(" * 置换核 vd_p40 与 1024 档一字不差。 */")
    L.append("static void vd_hash%d_fast(const unsigned char *msg, uint64_t msg_bits," % bits)
    L.append("                        unsigned char *out)")
    L.append("{")
    L.append("    __m256i s[20];")
    L.append("    unsigned char last[%d];" % rate_bytes)
    L.append("    uint64_t full = msg_bits / %dull;" % rate_bits)
    L.append("    unsigned int tail_bits = (unsigned int)(msg_bits - full * %dull);" % rate_bits)
    L.append("    unsigned int tail_bytes = (tail_bits + 7u) >> 3;")
    L.append("    unsigned int full_byte, rem;")
    L.append("    uint64_t i;")
    L.append("")
    L.append("    for (i = 0; i < 20; i++)")
    L.append("        s[i] = _mm256_setzero_si256();")
    L.append("")
    L.append("    for (i = 0; i < full; i++) {")
    L.append("        __m256i a, b;")
    L.append("        const unsigned char *p = msg + i * %dull;" % rate_bytes)
    L += absorb_block(rate_cells)
    L.append("        vd_p40(s);")
    L.append("    }")
    L.append("")
    L.append("    memset(last, 0, sizeof last);")
    L.append("    if (tail_bytes)")
    L.append("        memcpy(last, msg + full * %dull, tail_bytes);" % rate_bytes)
    L.append("    rem = tail_bits & 7u;")
    L.append("    full_byte = tail_bits >> 3;")
    L.append("    if (rem)")
    L.append("        last[full_byte] &= (unsigned char)(0xffu << (8u - rem));")
    L.append("    last[full_byte] |= (unsigned char)(1u << (7u - rem));"
             "   /* the '1' of 10*1 */")
    L.append("")
    L.append("    if (tail_bits == %dull - 1u) {" % rate_bits)
    L.append("        /* the two padding bits live in different blocks */")
    L.append("        __m256i a, b;")
    L.append("        const unsigned char *p = last;")
    L += absorb_block(rate_cells)
    L.append("        vd_p40(s);")
    L.append("        memset(last, 0, sizeof last);")
    L.append("    }")
    L.append("    last[%d - 1] |= 0x01u;                       /* the final '1' */"
             % rate_bytes)
    L.append("")
    L.append("    {")
    L.append("        __m256i a, b;")
    L.append("        const unsigned char *p = last;")
    L += absorb_block(rate_cells)
    L.append("    }")
    L.append("    vd_p40(s);")
    L.append("")
    dumped = 0
    while dumped < out_words:
        take = min(rate_cells, out_words - dumped)
        for j in range(take // 2):
            L.append("    vd_dump16(out + %d, s[%d]);"
                     % ((dumped + 2 * j) * 8, j))
        dumped += take
        if dumped < out_words:
            L.append("    vd_p40(s);")
    L.append("}")
    L.append("")
    return "\n".join(L)


def main():
    txt = open(SRC, "r", encoding="utf-8").read()
    if txt.count(PROTO_OLD) != 1:
        raise SystemExit("原型锚点命中 %d 次" % txt.count(PROTO_OLD))
    if txt.count(DISPATCH_OLD) != 1:
        raise SystemExit("派发锚点命中 %d 次" % txt.count(DISPATCH_OLD))

    protos = "".join(
        "static void vd_hash%d_fast(const unsigned char *msg, uint64_t msg_bits,\n"
        "                        unsigned char *out);\n" % b for b in TIERS)
    txt = txt.replace(PROTO_OLD, protos + PROTO_OLD)

    dispatch_new = "".join(
        "    if (digest_len_bits == %d) {\n"
        "        vd_hash%d_fast(msg, (uint64_t)msg_len_bits, digest);\n"
        "        return 0;\n"
        "    }\n" % (b, b) for b in TIERS)
    txt = txt.replace(DISPATCH_OLD, dispatch_new.rstrip("\n"))

    # vd_hash_bits 保留作等价性对照，但已不被 CryptHash 调用 —— 加一个
    # 编译期可见的引用消掉 -Wunused-function（本仓「warning 也算失败」）。
    REF_OLD = "int CryptHash(int digest_len_bits, const unsigned char *msg,\n" \
              "              unsigned long long msg_len_bits, unsigned char *digest)\n" \
              "{\n"
    REF_NEW = REF_OLD
    # 通用版改为「可能未用」：它不再被 CryptHash 调用，但保留作等价性对照
    # 与 gates 对拍（本仓「warning 也算失败」，故用属性显式声明）。
    GEN_OLD = "static void vd_hash_bits(const unsigned char *msg, uint64_t msg_bits,\n" \
              "                         unsigned int bits, unsigned char *out)\n" \
              "{\n"
    GEN_NEW = "/* 通用版：三档共用、速率运行时决定。768/512 已各有专用快路径，\n" \
              " * 这一份保留作等价性对照（gates 可拿它与快路径逐位对拍）。 */\n" \
              "static void vd_hash_bits(const unsigned char *msg, uint64_t msg_bits,\n" \
              "                         unsigned int bits, unsigned char *out)\n" \
              "__attribute__((unused));\n" \
              "static void vd_hash_bits(const unsigned char *msg, uint64_t msg_bits,\n" \
              "                         unsigned int bits, unsigned char *out)\n" \
              "{\n"
    if txt.count(GEN_OLD) != 1:
        raise SystemExit("vd_hash_bits 定义锚点命中 %d 次" % txt.count(GEN_OLD))
    txt = txt.replace(GEN_OLD, GEN_NEW)

    txt = txt.rstrip("\n") + "\n\n" + "\n".join(emit(b) for b in TIERS)

    open(OUT, "w", encoding="utf-8", newline="\n").write(txt)
    print("写出 %s（%d B）" % (os.path.relpath(OUT, HERE), os.path.getsize(OUT)))
    for b in TIERS:
        rb = 2560 - 2 * b
        print("  Vedak-%d: rate %d 位 = %d 字 = %d B，摘要 %d 字，"
              "吸收展开 %d 组、挤出 %d 条 dump16"
              % (b, rb, rb // 64, rb // 8, b // 64, rb // 64 // 4, b // 64 // 2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
