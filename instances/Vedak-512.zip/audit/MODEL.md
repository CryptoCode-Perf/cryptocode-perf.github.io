# Vedak — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Vedak-1024
- 摘要位：1024；实现形态：AVX2 打包半字节
- 官方参考源码：随包 `Reference_Implementation/Vedak-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Vedak-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Vedak-1024/`
- 优化要点：**一件库三档**（`ours_vedak_tiers_fast.so`）：官方 `CryptHash` 按 `digest_len_bits` 运行时派发，速率 r = 2560 - 2*bits，所以官方三档的 opt.so 逐字节相同（md5 65f337fdef616a7e886790a65098e1fc）。本件在原有 1024 专用快路径之外，给 1024 档补了一条同形状的快路径：rate 512 位 = 8 字 = 64 B 全部做成编译期常量，吸收从 `vd_absorb_n(s, p, cells)` 的运行时循环展开成 2 组 `vd_expand32` + 2 条 xor（`s[k>>1]` 下标全字面量），挤出从 while 循环展开成 8 条 `vd_dump16`。置换核 `vd_p40`（40 轮、每轮 p5 约 28 条）与 1024 档一字不差 —— 快路

## Vedak-512
- 摘要位：512；实现形态：AVX2 打包半字节
- 官方参考源码：随包 `Reference_Implementation/Vedak-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Vedak-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Vedak-512/`
- 优化要点：**一件库三档**（`ours_vedak_tiers_fast.so`）：官方 `CryptHash` 按 `digest_len_bits` 运行时派发，速率 r = 2560 - 2*bits，所以官方三档的 opt.so 逐字节相同（md5 65f337fdef616a7e886790a65098e1fc）。本件在原有 1024 专用快路径之外，给 512 档补了一条同形状的快路径：rate 1536 位 = 24 字 = 192 B 全部做成编译期常量，吸收从 `vd_absorb_n(s, p, cells)` 的运行时循环展开成 6 组 `vd_expand32` + 2 条 xor（`s[k>>1]` 下标全字面量），挤出从 while 循环展开成 4 条 `vd_dump16`。置换核 `vd_p40`（40 轮、每轮 p5 约 28 条）与 1024 档一字不差 —— 

## Vedak-768
- 摘要位：768；实现形态：AVX2 打包半字节
- 官方参考源码：随包 `Reference_Implementation/Vedak-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Vedak-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Vedak-768/`
- 优化要点：**一件库三档**（`ours_vedak_tiers_fast.so`）：官方 `CryptHash` 按 `digest_len_bits` 运行时派发，速率 r = 2560 - 2*bits，所以官方三档的 opt.so 逐字节相同（md5 65f337fdef616a7e886790a65098e1fc）。本件在原有 1024 专用快路径之外，给 768 档补了一条同形状的快路径：rate 1024 位 = 16 字 = 128 B 全部做成编译期常量，吸收从 `vd_absorb_n(s, p, cells)` 的运行时循环展开成 4 组 `vd_expand32` + 2 条 xor（`s[k>>1]` 下标全字面量），挤出从 while 循环展开成 6 条 `vd_dump16`。置换核 `vd_p40`（40 轮、每轮 p5 约 28 条）与 1024 档一字不差 —— 
