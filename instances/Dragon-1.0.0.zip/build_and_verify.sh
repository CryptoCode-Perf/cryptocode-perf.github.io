#!/usr/bin/env bash
# Dragon 1.0.0 —— 三方编译 + 22 长度差分 + 黄金向量 + KAT 4097
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
bash Reference_Implementation/Dragon-512/build_ref.sh
bash Optimized_Implementation/Dragon-512/build_off.sh
bash CryptoCode_Implementation/x86_AVX2/Dragon-512/build_ours.sh
gcc -O2 -o build/vec_512 test/vec_512.c -ldl
./build/vec_512 build/ref_512.so > build/vec_ref_512.txt
./build/vec_512 build/off_512.so > build/vec_off_512.txt
./build/vec_512 build/our_512.so > build/vec_our_512.txt
cmp build/vec_ref_512.txt build/vec_off_512.txt
cmp build/vec_ref_512.txt build/vec_our_512.txt
cp build/vec_ref_512.txt test/golden_vectors_ref_512.txt
python3 test/kat_check.py build/ref_512.so 100000 0 kat/KAT_2_12_Dragon-512.txt
python3 test/kat_check.py build/off_512.so 100000 0 kat/KAT_2_12_Dragon-512.txt
python3 test/kat_check.py build/our_512.so 100000 0 kat/KAT_2_12_Dragon-512.txt
echo "== 验证全部通过 =="
