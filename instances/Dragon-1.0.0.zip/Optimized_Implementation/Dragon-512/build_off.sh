#!/usr/bin/env bash
# 官方优化版：官方 Optimized_Implementation 的 C 实现，官方十 flag。
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../build
gcc $FLAGS -shared -fPIC -o ../../build/off_512.so CryptHash_AlgorithmInstance.c
echo "built build/off_512.so"
