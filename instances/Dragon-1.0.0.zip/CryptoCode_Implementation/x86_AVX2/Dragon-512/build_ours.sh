#!/usr/bin/env bash
# Dragon-512 的 CryptoCode 实现：JIR→jasmin 生成的置换核（agent_baseline.s）
# + 官方 Reference 驱动的逐字包装（our_dragon.c）。
# 与当年出交付件时**同一条命令**（单次 gcc 调用，不拆 -c/.o）：-flto 下拆开编会得到不同的二进制。
set -euo pipefail
cd "$(dirname "$0")"
REF=../../../Reference_Implementation/Dragon-512
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
mkdir -p ../../../build
gcc $FLAGS -shared -fPIC -DSTATIC_IMPL -I "$REF" \
    -o ../../../build/our_512.so our_dragon.c agent_baseline.s -lm
echo "built build/our_512.so"
