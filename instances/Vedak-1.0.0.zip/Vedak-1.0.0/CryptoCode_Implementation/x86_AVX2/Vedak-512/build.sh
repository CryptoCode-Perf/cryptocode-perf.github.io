#!/usr/bin/env bash
# rebuild Vedak-512 with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o Vedak-512.so vedak_tiers_fast.c vedak_tables.h
sha256sum Vedak-512.so
