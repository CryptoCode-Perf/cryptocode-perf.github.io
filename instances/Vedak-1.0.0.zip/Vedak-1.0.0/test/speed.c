/* Throughput harness for QILIN (x86_64, so-vs-so fair protocol).
 *
 * Fair-comparison protocol: BOTH implementations are measured as shared
 * libraries dlopen'd by the SAME -O2 device.  This matches the project's
 * reporting methodology and avoids the asymmetric LTO effect seen when both
 * sources are compiled into the harness: with -flto the official optimized
 * implementation is fully inlined and loses 20-25% (its big scalar state is
 * spilled differently), while our implementation is unaffected — inflating
 * the measured speedup.
 *
 * Follows the x86 self-assessment guide (新一代商用密码算法x86架构实现自评估指引):
 *   - hash input sizes S1..S8: 32/128/512/1024/4096/8192/16384/65536 bytes;
 *   - >= 100 executions per size, report cycles and MB/s;
 *   - each call's input depends on the previous digest output so the loop
 *     cannot be collapsed.
 *
 * Usage: ./speed <ours.so> <baseline.so> [digest_len (default 1024)]
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>
#include <x86intrin.h>

typedef int (*crypt_hash_fn)(int digest_len_bits, const unsigned char *msg,
                             unsigned long long msg_len_bits,
                             unsigned char *digest);

static const unsigned SIZES[] = {
    32, 128, 512, 1024, 4096, 8192, 16384, 65536
};

static crypt_hash_fn load_hash(const char *path)
{
    void *h = dlopen(path, RTLD_NOW);
    if (!h) { fprintf(stderr, "dlopen %s: %s\n", path, dlerror()); exit(1); }
    crypt_hash_fn fn = (crypt_hash_fn)dlsym(h, "CryptHash");
    if (!fn) { fprintf(stderr, "dlsym CryptHash in %s\n", path); exit(1); }
    return fn;
}

/* Time N calls on a size-S input; input mutates through the previous
 * digest so every call differs.  Fixed-input vs varying-input changes the
 * absolute numbers only marginally; the protocol must simply be identical
 * for both libraries. */
static double bench_one(crypt_hash_fn fn, unsigned S, int digest_len, int iters)
{
    static unsigned char msg[65536];
    unsigned char dig[128];
    uint64_t best = UINT64_MAX;

    for (unsigned i = 0; i < S; i++)
        msg[i] = (unsigned char)(i * 131u + S);

    for (int run = 0; run < 5; run++) {
        _mm_lfence();
        uint64_t c0 = __rdtsc();
        _mm_lfence();
        for (int i = 0; i < iters; i++) {
            fn(digest_len, msg, (unsigned long long)S * 8, dig);
            msg[i % S] ^= dig[0] ^ (unsigned char)i;
        }
        _mm_lfence();
        uint64_t c1 = __rdtsc();
        _mm_lfence();
        uint64_t cyc = (c1 - c0) / (unsigned)iters;
        if (cyc < best) best = cyc;
    }
    return (double)best;
}

static void run(const char *tag, crypt_hash_fn fn, int digest_len)
{
    printf("-- %s --\n", tag);
    printf("digest=%d  size_bytes  tsc_ticks_per_iter  tsc_ticks_per_byte\n",
           digest_len);
    for (unsigned si = 0; si < sizeof(SIZES) / sizeof(SIZES[0]); si++) {
        unsigned S = SIZES[si];
        /* per guide: >= 100 executions; small sizes need more iterations
         * so the timed section stays long enough to be stable */
        int iters = (S < 1024) ? 20000 : 200;
        double cyc = bench_one(fn, S, digest_len, iters);
        double per_call = cyc;                     /* min over 5 runs */
        printf("%10u  %15.1f  %15.3f\n", S, per_call, per_call / S);
    }
}

int main(int argc, char **argv)
{
    if (argc < 3) {
        fprintf(stderr, "usage: %s <ours.so> <baseline.so> [digest_len]\n",
                argv[0]);
        return 2;
    }
    int digest_len = (argc > 3) ? atoi(argv[3]) : 1024;
    crypt_hash_fn ours = load_hash(argv[1]);
    crypt_hash_fn base = load_hash(argv[2]);
    run("baseline (official optimized)", base, digest_len);
    run("ours (CryptoCode AVX2)", ours, digest_len);
    return 0;
}
