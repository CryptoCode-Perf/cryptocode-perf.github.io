#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 kat_check.py ./Pavelor-1024.so 4097 0 KAT_2_12_Pavelor-1024.txt
