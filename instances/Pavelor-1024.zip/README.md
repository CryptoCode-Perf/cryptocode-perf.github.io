# Pavelor-1024

Algorithm: Pavelor | Digest bits: 1024 | Form: 标量 C

Contents: implementation source/, public header Pavelor-1024.h, prebuilt Pavelor-1024.so,
KAT vector KAT_2_12_Pavelor-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 6a0e744859180effa4f4aa6286a6627033cb8707a872feae31c155133e85f354
Speed (cpB, lower is faster): reference 437.78 / official-optimized 3.47 / optimized 3.17
Speedup: GM(S1-S8) 1.07x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
