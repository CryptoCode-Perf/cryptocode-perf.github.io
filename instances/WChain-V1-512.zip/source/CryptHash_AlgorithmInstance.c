#include "CryptHash_AlgorithmInstance.h"
#include "wchain_c.h"

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest) {
    if (digest_len_bits != DIGEST_BIT_LENGTH) return -1;
    if (digest == NULL || (msg == NULL && msg_len_bits != 0ull)) return -1;
    wchain_v1_hash_bits_c(msg, msg_len_bits, digest);
    return 0;
}
