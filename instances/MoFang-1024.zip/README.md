# MoFang-1024

Algorithm: MoFang | Digest bits: 1024 | Form: SSE C

Contents: implementation source/, public header MoFang-1024.h, prebuilt MoFang-1024.so,
KAT vector KAT_2_12_MoFang_1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 0576cf6525bfc8b9a8074f07b4ce75de800c2613b8c8ffcb71e4b7581b9114d4
Speed (cpB, lower is faster): reference 20.47 / official-optimized 9.10 / optimized 4.76
Speedup: GM(S1-S8) 1.91x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
