#!/usr/bin/env bash
# accept2.sh —— MoFang-1024 第二轮（v3 / v3b）一条命令全链复跑。**未计时**。
#
# 用法（WSL 内，任意 cwd）：
#   bash _overnight/l0/mofang/accept2.sh 2>&1 | tee _overnight/l0/mofang/probe3/ACCEPT2.log
#
# 链：可复现构建（v3 + v3b）→ M1 同 TU 对拍 → M4 11 位长 → M3 默认 40 →
#     M3 全量 4097 → 负对照（v3/v3b 各 7/7）→ cmp_so 逐字节 → 每块动态计数 →
#     三段拆分 → 静态清点 → 共享回归 → 指纹
#
# 硬边界：只写本目录；共享工具只读；**不做任何计时**。
set -u
MOF="$(cd "$(dirname "$0")" && pwd)"
WORK="$(cd "$MOF/../../.." && pwd)"
REFDIR="$WORK/_overnight/l0/src/hash-19/MoFang/Implementations/Reference_Implementation/MoFang-1024"
REFLIB="$WORK/_overnight/l0/build/hash-19/mofang1024/ref.so"
SO3="$MOF/out/ours_mofang1024_v3.so"
SO3B="$MOF/out/ours_mofang1024_v3b.so"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"

cd "$WORK" || exit 1
echo "===== 1/11 可复现构建（v3）====="
python3 _overnight/l0/mofang/build_mofang_v3.py build || exit 1
echo "===== 2/11 可复现构建（v3b，含等价快 glue）====="
python3 _overnight/l0/mofang/build_mofang_v3.py build-fast || exit 1

echo "===== 3/11 M1 同 TU 逐轮对拍 ====="
gcc $FLAGS -I "$REFDIR" -o "$MOF/probe3/m1_check_v3" \
    "$MOF/probe3/m1_check_v3.c" "$MOF/mofang_keys_v3.o" "$MOF/mofang_state_v3.o" || exit 1
"$MOF/probe3/m1_check_v3" || exit 1

for tag in v3 v3b; do
  so="$MOF/out/ours_mofang1024_$tag.so"
  echo "===== M4 第四道门（$tag）====="
  python3 _overnight/l0/delivery_gate.py "$so" "$REFLIB" 1024 || echo "!! $tag M4 失败"
  echo "===== M3 KAT 默认 40（$tag）====="
  python3 _overnight/l0/mofang/probe3/run_kat_v3.py "$so" | grep -E "checked=|记录"
  echo "===== M3 KAT 全量 4097（$tag）====="
  python3 _overnight/l0/mofang/probe3/run_kat_v3.py --full "$so" | grep -E "checked=|记录"
  echo "===== 负对照（$tag）====="
  if [ "$tag" = "v3b" ]; then
    python3 _overnight/l0/mofang/probe3/negctl_v3.py --fast | tail -3
  else
    python3 _overnight/l0/mofang/probe3/negctl_v3.py | tail -3
  fi
done

echo "===== cmp_so 逐字节并排 ====="
python3 _overnight/l0/mofang/probe3/cmp_so.py

echo "===== 每块动态指令数（**不是计时**）====="
bash _overnight/l0/mofang/probe3/dyncount.sh

echo "===== 三段拆分（**不是计时**）====="
bash _overnight/l0/mofang/probe3/dyncount_seg.sh | grep -E "^(seg_|三段)"

echo "===== 静态清点（**不是计时**）====="
python3 insn_mix.py "$SO3"
python3 insn_mix.py "$SO3B"

echo "===== 共享回归 ====="
bash run_tests.sh | tail -3
python3 test_semantics_golden.py | tail -2

echo "===== 指纹 ====="
sha256sum "$SO3" "$SO3B" "$MOF/out/ours_mofang1024.so"
echo "（v1 交付件 sha256 必须仍是 ec700046a6efefbe8ab8b4fbd41c585163ad8d38afa5941062712e041abb8985）"
echo "===== 完（本脚本不含任何计时）====="
