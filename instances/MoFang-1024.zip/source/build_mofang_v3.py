#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_mofang_v3.py —— MoFang-1024 **第三版**交付件（`out/ours_mofang1024_v3.so`）的构建。

第一版 `out/ours_mofang1024.so` **已进 `delivery_timings.json`**，第二版
`out/ours_mofang1024_v2.so` 也已过门 —— 本脚本绝不碰它们：所有产物都带 `_v3` 后缀。

复用 `build_mofang.py` 里已经过验收的零件（`FLAGS` / `CUT_FUNCS` / `CUT_DECLS` /
`cut_function` / `cut_decl` / `run` / `sha`），只把
* JIR 来源换成 `gen/gen_jir_v3.py`
* 入口名换成 `mofang_keys_v3` / `mofang_state_v3`
* 数据流换成 v3 的「一个 u256 装 (b, c)」布局（见 `gen/gen_jir_v3.py` 的模块注释）
* 产物名换成 `*_v3`

用法（WSL 内，工作目录 = feilian/work）：
    python3 _overnight/l0/mofang/build_mofang_v3.py build
    python3 _overnight/l0/mofang/build_mofang_v3.py asm
（`main` 只认一个子命令，要分次调用。）

**全程未计时**：本脚本不含任何 perf_counter / rdtsc / AD.measure。
"""
import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "gen"))

import build_mofang as B          # noqa: E402
import gen_jir_v3 as G3           # noqa: E402

ENTRIES = ("mofang_keys_v3", "mofang_state_v3")
JIRDIR = os.path.join(HERE, "jir")
SO = os.path.join(HERE, "out", "ours_mofang1024_v3.so")

# `FASTGLUE=True` 时也把官方 hash_MDPH 换成我方等价实现（大端 64 位载入），
# 产物写 `out/ours_mofang1024_v3b.so`。核心（keys/state）完全同一份。
FASTGLUE = False
SO_FAST = os.path.join(HERE, "out", "ours_mofang1024_v3b.so")


def _so():
    return SO_FAST if FASTGLUE else SO

# v3 的密钥扩展跨轮活跃集只有 9 个 YMM，理论上不溢出；
# 先给 14（jemalloc 不管，由 jasminc 自己定），编不过再往下调。
# **不能改 `B.NREGS`**：`accept.sh` 用 `B.NREGS=12` 重建 v1，
# 改了会让已交付并已计时的 v1 .so 的 sha256 变化。
NREGS3 = 14


def cmd_gen():
    G3.main()
    return 0


def cmd_emit():
    for nm in ENTRIES:
        text = io.open(os.path.join(JIRDIR, nm + ".jir"), encoding="utf-8").read()
        js, info = B.I.to_jasmin(text, nregs=NREGS3)
        with io.open(os.path.join(HERE, nm + ".jazz"), "w",
                     encoding="utf-8", newline="\n") as fh:
            fh.write(js)
        print("%-17s IR %4d 条  峰值 %2d/%d  溢出 %d  andn %d  slots %s"
              % (nm, info["ir_instr"], info["peak"], NREGS3, info["spill"],
                 info.get("andn", 0), info.get("slots")))
    return 0


CORE_V3 = r'''
/* ===================================================================
 * 我方核心（JIR 生成，见 gen/gen_jir_v3.py）
 *
 * 官方参考实现这里原本是：encrypt2 两个 run，各跑 16 轮，密钥扩展因此算了 2 遍。
 * 两个 run 的 k0/k1/k2 逐字相同、初始 state 都是 in_g、只差 state[2][2] 的 1 bit
 *   run1 -> out_g（我方 lane1）
 *   run2 -> out_h（我方 lane0，唯一带 ^1 的那一路）
 * ⇒ 合并成一条 2-lane u256 链；密钥扩展整块只算 1 遍。
 *
 * 第三版再把密钥扩展也搬进 u256：一个 YMM 同时装 (b_i, c_i)，
 * 每轮每字只要 blendd + vrot 各一条 ⇒ 跨轮活跃集从 18 个 u64 降到 9 个 YMM。
 * =================================================================== */
extern void mofang_keys_v3(uint64_t *kinb, uint64_t *kb);
extern void mofang_state_v3(uint64_t *sin, uint64_t *kb, uint64_t *ab0, uint64_t *sout);

void MoFang_BC_2_DBL(uint64_t in_g[3][3], uint64_t in_h[3][3], uint64_t in_m[2][3][3],
                     uint64_t out_g[3][3], uint64_t out_h[3][3])
{
    /* kinb：18 个 u256 广播（前 9 个 = in_m[0]，偏移 288 起 9 个 = in_m[1]） */
    uint64_t kinb[72] __attribute__((aligned(32)));
    /* ab0：9 个 u256 广播 = in_h */
    uint64_t ab0[36]  __attribute__((aligned(32)));
    uint64_t sin[36]  __attribute__((aligned(32)));
    uint64_t sout[36] __attribute__((aligned(32)));
    /* kb：17 组 × 9 个 u256 = 153 个 u256 = 612 个 u64 */
    uint64_t kb[612]  __attribute__((aligned(32)));
    int i, j, k;
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            int n = i * 3 + j;
            uint64_t m0 = in_m[0][i][j];
            uint64_t m1 = in_m[1][i][j];
            uint64_t h  = in_h[i][j];
            for (k = 0; k < 4; k++) {
                kinb[4 * n + k]      = m0;
                kinb[36 + 4 * n + k] = m1;
                ab0[4 * n + k]       = h;
            }
            sin[4 * n]     = in_g[i][j] ^ (uint64_t)(n == 8);  /* h 分支的 state[2][2]^=1 */
            sin[4 * n + 1] = in_g[i][j];
            sin[4 * n + 2] = 0;
            sin[4 * n + 3] = 0;
        }
    }
    mofang_keys_v3(kinb, kb);
    mofang_state_v3(sin, kb, ab0, sout);
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            int n = i * 3 + j;
            out_g[i][j] = sout[4 * n + 1];
            out_h[i][j] = sout[4 * n] ^ (uint64_t)(n == 8);    /* out_h[2][2]^=1 */
        }
    }
}
'''


HASH_ANCHOR = "int hash_MDPH(int output_len_bits"
CRYPT_ANCHOR = "int CryptHash(int digest_len_bits"

MY_HASH = r'''
/* ===================================================================
 * 我方 hash_MDPH —— 与官方参考实现**逐字等价**，只把两处逐字节循环换成
 * 等价的 64 位访问（**不是计时**，是静态指令数）：
 *
 *   官方  for k=7..0 { v <<= 8; v |= padded[base+k]; }
 *   ⇒     v = **小端**读 8 字节：p[base+0] 落在最低 8 位
 *          （v = Σ_k p[base+k] << 8k），所以就是一次 `memcpy(&v, p, 8)`，
 *          **不是 bswap64**。第一版我误当成大端、加了 __builtin_bswap64，
 *          `probe3/cmp_so.py` 立刻显示连 0 字节空消息都不一致。
 *   官方  output[i*8+k] = (v >> (8k)) & 0xFF;
 *   ⇒     小端存 8 字节 = memcpy(output + i*8, &v, 8)
 *
 * 其余逐字保留：padded_input_len_bits 的算法、malloc/memset/memcpy、
 * 非字节对齐尾巴的 mask 与 0x80>>rem、in_g[2][2] = 11、最后一块 ^= 2、
 * 块数与 144 字节块距、in_m 两个 72 字节半区的划分、只写前 8 个状态字
 * （i = 0..7，第 9 个字 i = 8 **不写**）、返回 0。
 * =================================================================== */
static uint64_t mofang_ld_le64(const unsigned char *p)
{
    uint64_t v;
    memcpy(&v, p, 8);
    return v;
}

int hash_MDPH(int output_len_bits, const unsigned char *input, uint64_t input_len_bits, unsigned char *output){
    uint64_t padded_input_len_bits = ((input_len_bits + 1152) / 1152) * 1152;
    uint64_t padded_bytes = padded_input_len_bits / 8;
    unsigned char *padded_input = (unsigned char *)malloc(padded_bytes);
    if (padded_input == NULL) {
        return -1;
    }
    memset(padded_input, 0, padded_bytes);
    uint64_t full_bytes = input_len_bits / 8;
    int remaining_bits = input_len_bits % 8;
    memcpy(padded_input, input, full_bytes);
    if (remaining_bits > 0) {
        unsigned char mask = 0xFF << (8 - remaining_bits);
        padded_input[full_bytes] = input[full_bytes] & mask;
        padded_input[full_bytes] |= (0x80 >> remaining_bits);
    } else {
        if (full_bytes < padded_bytes) {
            padded_input[full_bytes] = 0x80;
        }
    }

    uint64_t in_g[3][3] = {0};
    uint64_t in_h[3][3] = {0};
    uint64_t in_m[2][3][3];
    uint64_t out_g[3][3] = {0};
    uint64_t out_h[3][3] = {0};
    in_g[2][2] = 11;
    uint64_t blocks = padded_input_len_bits / 1152;
    (void)output_len_bits;
    for (uint64_t t = 0; t < blocks; t++) {
        const unsigned char *pb = padded_input + t * 144;
        if (t == blocks - 1) {
            in_g[2][2] ^= 2;
        }
        for (int n = 0; n < 9; n++) {
            in_m[0][n / 3][n % 3] = mofang_ld_le64(pb + 8 * n);
            in_m[1][n / 3][n % 3] = mofang_ld_le64(pb + 72 + 8 * n);
        }
        MoFang_BC_2_DBL(in_g, in_h, in_m, out_g, out_h);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                in_g[i][j] = out_g[i][j];
                in_h[i][j] = out_h[i][j];
            }
        }
    }

    for (int i = 0; i < 8; i++) {
        uint64_t v = out_g[i / 3][i % 3];
        memcpy(output + i * 8, &v, 8);
    }
    for (int i = 0; i < 8; i++) {
        uint64_t v = out_h[i / 3][i % 3];
        memcpy(output + 64 + i * 8, &v, 8);
    }
    free(padded_input);
    return 0;
}
'''


def make_glue_v3():
    """与 `build_mofang.make_glue` 同逻辑，只把核心换成 v3、产物名改成 `_v3`。

    `FASTGLUE=True` 时再挖掉官方 `hash_MDPH`、换成 `MY_HASH`（等价实现）。
    """
    text = io.open(B.REFSRC, encoding="utf-8").read()
    orig_lines = len(text.splitlines())
    cut_lines = 0
    for sig in B.CUT_FUNCS:
        text, cut = B.cut_function(text, sig)
        cut_lines += len(cut.splitlines())
    for sig in B.CUT_DECLS:
        text, cut = B.cut_decl(text, sig)
        cut_lines += len(cut.splitlines())
    if B.ANCHOR not in text:
        raise SystemExit("找不到插入锚点：" + B.ANCHOR)
    head = ("/* 本文件的标量核心已被整体替换：挖掉 %d 行官方参考实现代码"
            "（rotl/Sbox/SubBytes/mul_row/xor_row/MixColumns/ShiftRows_0/1/"
            "AddM_Key2/MessageExpansion2/encrypt2/MoFang_BC_2_DBL + 4 张常量表）。\n"
            " * 其余（文件头、hash_MDPH、CryptHash）逐字保留。 */\n" % cut_lines)
    text = text.replace(B.ANCHOR, head + CORE_V3 + "\n" + B.ANCHOR, 1)
    if FASTGLUE:
        text, cut = B.cut_function(text, HASH_ANCHOR)
        cut_lines += len(cut.splitlines())
        if CRYPT_ANCHOR not in text:
            raise SystemExit("找不到 CryptHash 锚点：" + CRYPT_ANCHOR)
        text = text.replace(CRYPT_ANCHOR, MY_HASH + "\n" + CRYPT_ANCHOR, 1)
    p = os.path.join(HERE, "glue_mofang1024_v3b.c" if FASTGLUE
                     else "glue_mofang1024_v3.c")
    with io.open(p, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    return p, orig_lines, cut_lines


def cmd_build():
    cmd_gen()
    cmd_emit()
    os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
    objs = []
    for nm in ENTRIES:
        B.run(["jasminc", "-o", nm + ".s", nm + ".jazz"])
        B.run(["gcc"] + B.FLAGS + ["-c", "-o", nm + ".o", nm + ".s"])
        objs.append(os.path.join(HERE, nm + ".o"))
    glue, orig, cut = make_glue_v3()
    so = _so()
    B.run(["gcc"] + B.FLAGS + ["-fPIC", "-shared", "-o", so, "-I", B.REFRDIR]
          + objs + [glue])
    # ---- 复核：`gcc -shared` 默认放过未定义符号，必须自己查 ----
    nm = os.path.join(HERE, "probe3", "v3_nm_undef.txt")
    os.makedirs(os.path.dirname(nm), exist_ok=True)
    with open(nm, "wb") as fh:
        subprocess.run(["nm", "-D", "-u", so], stdout=fh,
                       stderr=subprocess.STDOUT)
    und = [l.strip() for l in io.open(nm, encoding="utf-8",
                                      errors="replace").read().splitlines()
           if l.strip()]
    ours = [l for l in und if "mofang" in l.lower()]
    print("      未定义符号 %d 个；其中含 mofang 的 %d 个 %s"
          % (len(und), len(ours), ours if ours else ""))
    if ours:
        raise SystemExit("!! glue 仍在引用别的入口名：%s" % ours)
    print("build → %s（%d B，sha256 %s）"
          % (os.path.relpath(so, B.L0), os.path.getsize(so), B.sha(so)))
    print("      glue = 官方参考实现 %d 行，挖掉 %d 行%s"
          % (orig, cut, "（含 hash_MDPH 换成等价实现）" if FASTGLUE else "，其余逐字保留"))
    return 0


def cmd_gates():
    if not os.path.exists(B.REFSO):
        raise SystemExit("找不到官方 ref.so：%s" % B.REFSO)
    print("== M4 第四道门（%s vs 官方 ref，1024 bit 摘要）"
          % os.path.basename(_so()))
    B.run(["python3", os.path.join(B.L0, "delivery_gate.py"), _so(), B.REFSO,
           "1024"], cwd=B.WORK)
    return 0


WANT = ("mofang_keys_v3", "mofang_state_v3", "MoFang_BC_2_DBL", "hash_MDPH",
        "CryptHash", "MoFang_BC_2_DBL")


def cmd_asm():
    """静态清点（**不是计时**）：反汇编 v3 与官方 opt，数助记符、数回跳。"""
    tag = "OURS-v3b" if FASTGLUE else "OURS-v3"
    dp = os.path.join(HERE, "probe3",
                      "ours_v3b.asm" if FASTGLUE else "ours_v3.asm")
    for tg, so, d in ((tag, _so(), dp),
                      ("OFFICIAL-opt", B.OPTSO,
                       os.path.join(HERE, "probe", "opt.asm"))):
        if not os.path.exists(so):
            print("跳过 %s：找不到 %s" % (tg, so))
            continue
        txt = B._objdump(so, d)
        cnt = B._scan(txt)
        loops = B._backward_branches(txt)
        print("\n== %s  %s（反汇编留在 %s）"
              % (tg, os.path.relpath(so, B.L0), os.path.relpath(d, B.L0)))
        for fn in WANT:
            for k, v in cnt.items():
                if k == fn or k.endswith("+" + fn):
                    lp = loops.get(k, [])
                    extra = "" if not lp else "  回跳 %d 处：%s" % (
                        len(lp), "  ".join("[%x,%x) 体 %d 条" % (a, b, b - a + 1)
                                           for a, b in lp))
                    print("%-16s 静态 %4d 条%s" % (fn, sum(v.values()), extra))
                    print("   " + "  ".join("%s:%d" % (a, b)
                                            for a, b in v.most_common(14)))
    return 0


def main():
    global FASTGLUE
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "gen":
        return cmd_gen()
    if cmd == "emit":
        return cmd_emit()
    if cmd in ("build", "build-fast"):
        FASTGLUE = cmd.endswith("-fast")
        return cmd_build()
    if cmd in ("gates", "gates-fast"):
        FASTGLUE = cmd.endswith("-fast")
        return cmd_gates()
    if cmd in ("asm", "asm-fast"):
        FASTGLUE = cmd.endswith("-fast")
        return cmd_asm()
    raise SystemExit("用法：build_mofang_v3.py gen|emit|build[-fast]|gates[-fast]|asm[-fast]")


if __name__ == "__main__":
    raise SystemExit(main())
