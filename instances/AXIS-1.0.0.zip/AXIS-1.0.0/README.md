# AXIS 1.0.0 — CryptoCode implementation

Instances: AXIS-512, AXIS-768 and AXIS-1024. Requires x86-64 Linux/WSL2,
AVX2, GCC, Python 3 and standard Unix tools. From this directory run:

    bash build_and_verify.sh

The script rebuilds reference, official optimized and CryptoCode implementations,
checks all 4097 known-answer vectors per implementation and instance, compares
selected long and boundary inputs, checks guarded buffers and verifies the
reference-backed streaming helper API. Build commands and environment are
recorded under build/. Prebuilt libraries are in prebuilt/.

`CryptHash` accepts a digest length in bits, a message pointer, a message
length in bits, and an output pointer. Allocate digest_bits/8 output bytes.
The optimized one-shot implementation is in CryptoCode_Implementation.
The exported axis_core_* streaming helpers are linked from the original
reference implementation for API compatibility; they are not claimed to
be the optimized one-shot implementation. Their declarations are in
Reference_Implementation/AXIS-512/axis_core.h. The helper check exercises
all three variants with one-shot, streaming and copied configurations.

The one-shot sources match the current report sources. Linking the reference
helper changes library hashes; a separate paired comparison against the
report-matching libraries is preserved in results/2026-11-27-report-comparison.
Three 101-sample rounds over eight sizes against official optimized libraries
and their raw samples are in results/2026-11-27-delivery-comparison. Reference
measurements are in results/2026-11-27-reference-comparison and were sampled
in a separate session. Timings use elapsed nanoseconds, not hardware cycles.

To remeasure after building, coordinate exclusive access and run:

    python3 test/measure.py --lock /path/to/shared/measurement.lock --output /path/to/new/results

The lock cannot exclude unrelated host work. Results depend on hardware
and load; original source notices are retained. Tests do not prove security
or constant-time behavior. See SOURCE_MANIFEST.json for hashes.
