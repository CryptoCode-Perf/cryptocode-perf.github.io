#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "axis_core.h"
typedef struct api { void *handle; const axis_variant_config_t *(*cfg)(axis_variant_t); uint32_t (*bits)(axis_variant_t); void (*init)(axis_core_t*,axis_variant_t); void (*init_cfg)(axis_core_t*,const axis_variant_config_t*); void (*update)(axis_core_t*,const void*,uint64_t); void (*update_bits)(axis_core_t*,const void*,uint64_t); void (*final)(axis_core_t*,void*); void (*hash_bits)(axis_variant_t,const void*,uint64_t,void*); } api;
static void sym(void *h,const char *n,void *out,size_t size){void *p=dlsym(h,n);if(!p||size!=sizeof p){fprintf(stderr,"missing %s\n",n);exit(3);}memcpy(out,&p,size);}
#define SYM(a, field, name) sym((a)->handle,(name),&(a)->field,sizeof((a)->field))
static api load(const char *p){api a={0};a.handle=dlopen(p,RTLD_NOW|RTLD_LOCAL);if(!a.handle){fprintf(stderr,"%s\n",dlerror());exit(2);}SYM(&a,cfg,"axis_default_config");SYM(&a,bits,"axis_result_bits");SYM(&a,init,"axis_core_init");SYM(&a,init_cfg,"axis_core_init_with_config");SYM(&a,update,"axis_core_update");SYM(&a,update_bits,"axis_core_update_bits");SYM(&a,final,"axis_core_final");SYM(&a,hash_bits,"axis_core_hash_bits");return a;}
int main(int argc,char **argv){
 if(argc!=3)return 2;api ref=load(argv[1]),own=load(argv[2]);unsigned char msg[1024],expected[128],got[128],stream[128],custom[128];unsigned cases=0;
 const uint64_t lengths[]={0,1,7,8,9,63,64,65,255,256,257,511,512,513,1023,1024,1025,4095,4096,4097,8191};
 for(size_t i=0;i<sizeof msg;i++)msg[i]=(unsigned char)(i*73u+19u);
 for(int v=0;v<3;v++){
  axis_variant_t variant=(axis_variant_t)v;const axis_variant_config_t *cfg=ref.cfg(variant),*ocfg=own.cfg(variant);if(!cfg||!ocfg||memcmp(cfg,ocfg,sizeof(*cfg))||ref.bits(variant)!=own.bits(variant))return 4;
  size_t bytes=ref.bits(variant)/8;if(bytes>sizeof got)return 5;
  for(size_t k=0;k<sizeof(lengths)/sizeof(lengths[0]);k++){
   uint64_t n=lengths[k],prefix=(n/16)*8;if(prefix>n)prefix=0;axis_core_t ctx;axis_variant_config_t copy=*ocfg;
   memset(expected,0,sizeof expected);memset(got,0,sizeof got);memset(stream,0,sizeof stream);memset(custom,0,sizeof custom);
   ref.hash_bits(variant,msg,n,expected);own.hash_bits(variant,msg,n,got);
   own.init(&ctx,variant);own.update(&ctx,msg,prefix/8);own.update_bits(&ctx,msg+prefix/8,n-prefix);own.final(&ctx,stream);
   own.init_cfg(&ctx,&copy);own.update_bits(&ctx,msg,n);own.final(&ctx,custom);
   if(memcmp(expected,got,bytes)||memcmp(expected,stream,bytes)||memcmp(expected,custom,bytes)){fprintf(stderr,"helper mismatch variant=%d n=%llu\n",v,(unsigned long long)n);return 1;}cases++;
  }
 }
 printf("AXIS reference-backed helper API: %u variant/length cases passed\n",cases);dlclose(ref.handle);dlclose(own.handle);return 0;
}
