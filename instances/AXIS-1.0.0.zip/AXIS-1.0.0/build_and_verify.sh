#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
{ uname -a; gcc --version; lscpu; } > build/environment.txt
exec 9>build/build-commands.log
export BASH_XTRACEFD=9
set -x
for bits in 512 768 1024; do
 for kind in Reference Optimized; do
  d="${kind}_Implementation/AXIS-$bits"
  flags="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/axis_core.c" "$d/CryptHash_AlgorithmInstance.c" -o "build/$kind-$bits.so"
 done
 d="CryptoCode_Implementation/AXIS-$bits"
 if [ "$bits" = 1024 ]; then source=axis1024.c; else source=axis_tiers.c; fi
 gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -Wl,-z,defs -I"$d" -I"Reference_Implementation/AXIS-$bits" "$d/$source" "Reference_Implementation/AXIS-$bits/axis_core.c" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 "test/kat_$bits.py" "build/$kind-$bits.so" 100000 0 "kat/AXIS-$bits.txt"; done
done

python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
gcc -O2 -IReference_Implementation/AXIS-512 test/helper_check.c -ldl -o build/helper_check
for bits in 512 768 1024; do
 for kind in Reference Optimized CryptoCode; do build/guard_check "build/$kind-$bits.so" "$bits"; done
 build/helper_check "./build/Reference-$bits.so" "./build/CryptoCode-$bits.so"
done

set +x
