# XRH-1-1024

Algorithm: XRH-1 | Digest bits: 1024 | Form: AVX2 汇编

Contents: implementation source/, public header XRH-1-1024.h, prebuilt XRH-1-1024.so,
KAT vector KAT_2_12_XRH-1-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): c4441e917831f96b0d1a0c9c836f544b56ff8e5851899e5f516730543e848ad7
Speed (cpB, lower is faster): reference 60.17 / official-optimized 49.80 / optimized 43.33
Speedup: GM(S1-S8) 1.12x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
