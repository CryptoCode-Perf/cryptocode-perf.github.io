
#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <immintrin.h>

extern void xrh_round1(uint64_t *p);
extern void xrh_r0_9(uint64_t *p);
extern void xrh_r9_18(uint64_t *p);
extern void xrh_r0_18(uint64_t *p);

/* 自然序（20 个连续 u64）→ 向量 scratch（也是 20 个 u64，但换了排法） */
static void nat_to_sc(const uint64_t *x, uint64_t *sc)
{
    __m256i a0 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 0));
    __m256i a1 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 5));
    __m256i a2 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 10));
    __m256i a3 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 15));
    __m256i t0 = _mm256_unpacklo_epi64(a0, a1);
    __m256i t1 = _mm256_unpackhi_epi64(a0, a1);
    __m256i t2 = _mm256_unpacklo_epi64(a2, a3);
    __m256i t3 = _mm256_unpackhi_epi64(a2, a3);
    __m256i c0 = _mm256_permute2x128_si256(t0, t2, 0x20);
    __m256i c1 = _mm256_permute2x128_si256(t1, t3, 0x20);
    __m256i c2 = _mm256_permute2x128_si256(t0, t2, 0x31);
    __m256i c3 = _mm256_permute2x128_si256(t1, t3, 0x31);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 0), c0);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 4), c1);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 8), c2);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 12), c3);
    sc[16] = x[4];
    sc[17] = x[9];
    sc[18] = x[14];
    sc[19] = x[19];
}

/* 向量 scratch → 自然序（与上面同构，转置自逆） */
static void sc_to_nat(const uint64_t *sc, uint64_t *x)
{
    __m256i a0 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 0));
    __m256i a1 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 4));
    __m256i a2 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 8));
    __m256i a3 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 12));
    __m256i t0 = _mm256_unpacklo_epi64(a0, a1);
    __m256i t1 = _mm256_unpackhi_epi64(a0, a1);
    __m256i t2 = _mm256_unpacklo_epi64(a2, a3);
    __m256i t3 = _mm256_unpackhi_epi64(a2, a3);
    _mm256_storeu_si256((__m256i *)(void *)(x + 0),
                        _mm256_permute2x128_si256(t0, t2, 0x20));
    _mm256_storeu_si256((__m256i *)(void *)(x + 5),
                        _mm256_permute2x128_si256(t1, t3, 0x20));
    _mm256_storeu_si256((__m256i *)(void *)(x + 10),
                        _mm256_permute2x128_si256(t0, t2, 0x31));
    _mm256_storeu_si256((__m256i *)(void *)(x + 15),
                        _mm256_permute2x128_si256(t1, t3, 0x31));
    x[4] = sc[16];
    x[9] = sc[17];
    x[14] = sc[18];
    x[19] = sc[19];
}

void XRH1280(int R0, int R1, uint64_t *restrict buf)
{
    uint64_t sc[20] __attribute__((aligned(32)));
    nat_to_sc(buf, sc);
    if (R0 == 0 && R1 == 18) {
        xrh_r0_18(sc);
    } else if (R0 == 0 && R1 == 9) {
        xrh_r0_9(sc);
    } else if (R0 == 9 && R1 == 18) {
        xrh_r9_18(sc);
    } else if (R0 == 0 && R1 == 1) {
        xrh_round1(sc);
    } else {
        fprintf(stderr, "XRH1280: unsupported range (%d,%d)\n", R0, R1);
        abort();
    }
    sc_to_nat(sc, buf);
}

void XRH_edmc_permute(uint64_t state[STATE_LANES])
{
    volatile uint64_t initial_state[STATE_LANES];
    size_t i;
    for (i = 0; i < STATE_LANES; i++)
        initial_state[i] = state[i];
    /* 融合版：一次 nat_to_sc … sc_to_nat 走完 9 轮 + 容量反馈 + 9 轮。
       旧版走 XRH1280(0,9) 与 XRH1280(9,18)，每次 XRH1280 都自带一次
       nat_to_sc + 一次 sc_to_nat ⇒ 每个置换 4 次布局转换；融合后 2 次。
       反馈在 sc 坐标下做：x[w] 对应 sc[4*(w%5) + w/5]
       （因为 nat_to_sc 里 sc[4*j+k] = x[5*k+j]，j=4 时 4*4+k = 16+k 正好是
        sc[16+k] = x[5*k+4]，同一个公式覆盖全部 20 个字）。 */
    {
        uint64_t sc[20] __attribute__((aligned(32)));
        nat_to_sc(state, sc);
        xrh_r0_9(sc);
        for (i = STATE_LANES - (STATE_CAPACITY / 64); i < STATE_LANES; i++)
            sc[4 * (i % 5) + i / 5] ^= initial_state[i];
        xrh_r9_18(sc);
        sc_to_nat(sc, state);
    }
}
