"""XRH-1 核心置换的 256 位向量生成器（20 字 = **5 个 u256**，不是 10 个 ymm）。

布局（本文件的地基，两个域互相转置）
-----------------------------------
20 个字 x0..x19 分成 4 个 S 盒分组 g = 0..3：
    g=0: x0..x4      g=1: x5..x9      g=2: x10..x14     g=3: x15..x19
组内位置 j = 0..4。

域 (a)「lane = 分组、向量 = 位置」（S 盒用）：
    A_j lane g = x[5g+j]   （j = 0..3）
    T   lane g = x[5g+4]
    ⇒ 4 个 5 比特 S 盒变成**纯逐 lane 布尔网络**：一套 25 条指令覆盖全部 4 组
      （标量要 4×25）。

域 (c)「lane = 位置、向量 = 分组」（MDS / SR 用）：
    w_g lane j = x[5g+j]   （j = 0..3）
    b_k = 位置 4 的广播向量：b_k 的 4 个 lane 都等于 x[5k+4]
    ⇒ MDS 的「整组异或」与「组内位置错位」都变成整向量运算；SR 因为一个向量
      只装一个分组，4 个 lane 的移位量/掩码完全相同 ⇒ 用**立即数**移位即可，
      不需要 vpsllvq/vpsrlvq（kv 逐 lane 移位量只在「lane = 分组」布局下才必需）。

(a) ↔ (c) 就是 A_0..A_3 的 4×4 转置（8 条：4 unpack + 4 perm2i128，自逆），T/b 不转置。

一轮（严格照官方 `Reference_Implementation/.../CryptHash_AlgorithmInstance.c:197-234`）：
    APPLY_SBOX20 → MDS → APPLY_SBOX20 → SR_phase → MDS → SR_phase_INV → x0 ^= RC[i]
phase = i % 3（phase 按**绝对轮号**，不是每轮重置）。

自校验：本文件 `--check` 会在不编译的情况下，用 Python 逐指令复算自己发出的
JIR（u256 = 4 个 u64 lane），再和 Python 版官方参考实现对拍。先过这一关再编译。
"""
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, WORK)

import ir_text as I  # noqa: E402

M64 = (1 << 64) - 1
ONES = (1 << 256) - 1

ROUND_CONSTANTS = [
    0x243f6a8885a308d3, 0x13198a2e03707344, 0xa4093822299f31d0,
    0x082efa98ec4e6c89, 0x452821e638d01377, 0xbe5466cf34e90c6c,
    0xc0ac29b7c97c50dd, 0x3f84d5b5b5470917, 0x9216d5d98979fb1b,
    0xd1310ba698dfb5ac, 0x2ffd72dbd01adfb7, 0xb8e1afed6a267e96,
    0xba7c9045f12c7f99, 0x24a19947b3916cf7, 0x0801f2e2858efc16,
    0x636920d871574e69, 0xa458fea3f4933d7e, 0x0d95748f728eb658,
]

# 每个分组的掩码旋转规则：(左移量, 左移掩码, 右移量, 右移掩码)
SR_RULES = {
    0: {  # SR_X
        1: (1, 0x7777777777777777, 3, 0x8888888888888888),
        2: (2, 0x3333333333333333, 2, 0xcccccccccccccccc),
        3: (3, 0x1111111111111111, 1, 0xeeeeeeeeeeeeeeee),
    },
    1: {  # SR_Y
        1: (4, 0x0fff0fff0fff0fff, 12, 0xf000f000f000f000),
        2: (8, 0x00ff00ff00ff00ff, 8, 0xff00ff00ff00ff00),
        3: (12, 0x000f000f000f000f, 4, 0xfff0fff0fff0fff0),
    },
    2: {  # SR_Z：整字 rotl，无掩码
        1: (16, M64, 48, 0),
        2: (32, M64, 32, 0),
        3: (48, M64, 16, 0),
    },
}
SR_RULES_INV = {
    0: {  # SR_X_INV
        1: (3, 0x1111111111111111, 1, 0xeeeeeeeeeeeeeeee),
        2: (2, 0x3333333333333333, 2, 0xcccccccccccccccc),
        3: (1, 0x7777777777777777, 3, 0x8888888888888888),
    },
    1: {  # SR_Y_INV
        1: (12, 0x000f000f000f000f, 4, 0xfff0fff0fff0fff0),
        2: (8, 0x00ff00ff00ff00ff, 8, 0xff00ff00ff00ff00),
        3: (4, 0x0fff0fff0fff0fff, 12, 0xf000f000f000f000),
    },
    2: {  # SR_Z_INV
        1: (48, M64, 16, 0),
        2: (32, M64, 32, 0),
        3: (16, M64, 48, 0),
    },
}

# 只取第 0 个分组的常量（(c) 域里一个向量只装一个分组，掩码要在 4 个 lane 上重复）
def rep4(x):
    x &= M64
    return x | (x << 64) | (x << 128) | (x << 192)


def mask_const(g, v):
    """把 u64 掩码变成 4 个 lane 都重复的 u256 常量名。"""
    v &= M64
    return g.const("MK%016x" % v, rep4(v))


def mask_lane(k):
    """只有 lane k 是 1 的 u256。"""
    return (M64 << (64 * k)) & ONES


def _is_lit(x):
    """立即数/常量字面量（coalesce 时不参与 liveness 统计）。"""
    return not x[:1].isalpha() and not x[:1] == "_"


def _self_assign(line):
    """`a0 = a0` 这类自赋值行（coalesce 后可能出现）要丢掉。"""
    body = line.strip()
    if "=" not in body:
        return False
    lhs, rhs = body.split("=", 1)
    return lhs.strip() == rhs.strip()


class Gen(object):
    """发出 JIR 文本，同时记录每条指令以便 Python 侧复算。"""

    def __init__(self):
        self.text = []
        self.ops = []          # [(dst, fn, args)]
        self.consts = []       # [(name, value)]
        self._named = {}
        self.n = 0

    # ---- 常量 ----
    def const(self, name, val):
        assert 0 <= val <= ONES or val == M64, name
        if name in self._named:
            assert self._named[name] == val, (name, hex(self._named[name]), hex(val))
            return name
        self._named[name] = val
        self.consts.append((name, val))
        return name

    def rc_name(self, i):
        return self.const("RCV%d" % i, ROUND_CONSTANTS[i] & M64)  # lane0 只有

    # ---- 指令 ----
    def _emit(self, dst, fn, args):
        self.text.append("  %s = %s(%s)" % (dst, fn, ", ".join(args)))
        self.ops.append((dst, fn, list(args)))
        return dst

    def tmp(self, base="v"):
        self.n += 1
        return "%s%d" % (base, self.n)

    def _un(self, fn, a, base="v"):
        return self._emit(self.tmp(base), fn, [a])

    def _bin(self, fn, a, b, base="v"):
        return self._emit(self.tmp(base), fn, [a, b])

    def xor(self, a, b, base="x"):
        return self._bin("xor", a, b, base)

    def and_(self, a, b, base="a"):
        return self._bin("and", a, b, base)

    def or_(self, a, b, base="o"):
        return self._bin("or", a, b, base)

    def shl(self, a, k, base="s"):
        return self._emit(self.tmp(base), "shl", [a, str(k)])

    def shr(self, a, k, base="s"):
        return self._emit(self.tmp(base), "shr", [a, str(k)])

    def permq(self, a, imm, base="q"):
        return self._emit(self.tmp(base), "permq", [a, "0x%02x" % imm])

    def blendd(self, a, b, imm, base="b"):
        return self._emit(self.tmp(base), "blendd", [a, b, "0x%02x" % imm])

    def unpack(self, hi, a, b, base="u"):
        return self._emit(self.tmp(base), "unpackhi" if hi else "unpacklo", [a, b])

    def perm2i128(self, a, b, imm, base="p"):
        return self._emit(self.tmp(base), "perm2i128", [a, b, "0x%02x" % imm])

    # ---- copy coalescing ----
    # emit_sched 的 _two_op 只在「目的 == 第一个源」时走原地分支；否则插一条
    # vmovdqu 拷贝（实测 586 条，占全部指令 13.8%）。JIR 允许同名重赋值，
    # 所以在第一个源操作数**最后一次被使用**的那条指令处，把目的名改写成
    # 该源名，就等价于原地更新，拷贝消失。
    def coalesce(self, keep=()):
        """把 d = op(s0, s1) 改写成 s0 = op(s0, s1)（s0 此后不再被用）。"""
        consts = set(nm for nm, _ in self.consts)
        keep = set(keep)
        uses = {}
        for _, _, args in self.ops:
            for a in args:
                if a in consts or _is_lit(a):
                    continue
                uses[a] = uses.get(a, 0) + 1
        rem = dict(uses)
        for k in keep:
            rem[k] = 1 << 30            # 循环携带名永不“死亡”
        subst = {}
        new = []
        for d, fn, args in self.ops:
            a = [subst.get(x, x) for x in args]
            for x in a:
                if x in consts or _is_lit(x):
                    continue
                rem[x] = rem.get(x, 0) - 1
            nd = subst.get(d, d)
            if fn in ("xor", "and", "or") and len(a) >= 2:
                s0 = a[0]
                if (s0 not in consts and s0 not in keep and not _is_lit(s0)
                        and s0 != nd and rem.get(s0, 0) == 0):
                    subst[d] = s0                      # 后续对 d 的引用改指 s0
                    nd = s0
                    rem[s0] = rem.get(s0, 0) + uses.get(d, 0)
            new.append((nd, fn, a))
        self.ops = new
        self.text = ["  %s = %s(%s)" % (d, fn, ", ".join(args)) for d, fn, args in new]
        return subst


# ====================== 轮内各步（(a)/(c) 两个域） ======================

def sbox5(g, v0, v1, v2, v3, v4, ones="ONES"):
    """官方 `sbox_hw25_bitslice64_withtemp` 的逐 lane 版本。

    输入 v0..v4 是 (a) 域的 5 个向量（lanes = 4 个分组），输出同样 5 个。
    25 条指令覆盖全部 4 个 S 盒。
    """
    t0 = g.xor(v0, v1)
    t1 = g.xor(v2, v4)
    t2 = g.or_(v0, v2)
    t3 = g.xor(t0, ones)              # ~t0
    t4 = g.xor(v3, t3)
    t5 = g.xor(t1, g.and_(v1, v4))
    x0x4 = g.xor(v0, v4)
    x0a = g.and_(v0, v4)
    x3t1 = g.and_(v3, t1)
    x2t4 = g.and_(v2, t4)
    x3t5 = g.xor(v3, t5)
    y0 = g.xor(g.xor(g.and_(x0x4, t3), g.and_(v4, t1)), x2t4)
    y1 = g.xor(g.xor(t2, x0a), g.or_(v1, x3t5))
    y2 = g.xor(g.xor(v2, x3t1), g.or_(x0x4, t4))
    y3 = g.xor(g.xor(v1, t2), x3t1)
    y4 = g.xor(x3t5, x2t4)
    return y0, y1, y2, y3, y4


def transpose4(g, a):
    """(a) ↔ (c)：c_j lane g = a_g lane j（4×4 转置，8 条，自逆）。"""
    p0 = g.unpack(False, a[0], a[1])
    p1 = g.unpack(True, a[0], a[1])
    p2 = g.unpack(False, a[2], a[3])
    p3 = g.unpack(True, a[2], a[3])
    return [g.perm2i128(p0, p2, 0x20),
            g.perm2i128(p1, p3, 0x20),
            g.perm2i128(p0, p2, 0x31),
            g.perm2i128(p1, p3, 0x31)]


def to_bcast(g, t):
    """(a) 域的自然 T（lane g = x[5g+4]）→ 4 个广播向量 b_k。"""
    return [g.permq(t, 0x00), g.permq(t, 0x55), g.permq(t, 0xAA), g.permq(t, 0xFF)]


def pack_bcast(g, b):
    """4 个广播向量 → 自然 T（3 条 blendd；b_k 的 lane k 就是 x[5k+4]）。"""
    t = g.blendd(b[0], b[1], 0x0C)
    t = g.blendd(t, b[2], 0x30)
    t = g.blendd(t, b[3], 0xC0)
    return t


def shiftup(g, src, fill):
    """(fill, src0, src1, src2)；再给 lane2 补一个 fill（对应 x17/x12 的 A1^A4）。"""
    q = g.permq(src, 0x90)                     # (src0, src0, src1, src2)
    r = g.xor(q, fill)                         # lane2 需要的 src1^fill
    s = g.blendd(q, r, 0x30)
    s = g.blendd(s, fill, 0x03)
    return s


def mds(g, w, b):
    """官方 MDS 九步，(c) 域。w[g] lane j = x[5g+j]；b[k] 全 lane = x[5k+4]。"""
    w0, w1, w2, w3 = w
    b0, b1, b2, b3 = b
    # ① A ^= B
    w0 = g.xor(w0, w1)
    b0 = g.xor(b0, b1)
    # ② C ^= D
    w2 = g.xor(w2, w3)
    b2 = g.xor(b2, b3)
    # ③ B ^= C
    w1 = g.xor(w1, w2)
    b1 = g.xor(b1, b2)
    # ④ D_j ^= A_{j-1}（D0 ^= A4），D2 再多异或一次 A4，D4 ^= A3
    s = shiftup(g, w0, b0)
    w3 = g.xor(w3, s)
    b3 = g.xor(b3, g.permq(w0, 0xFF))
    # ⑤ MUL(B)：(x5..x9) ← (x9, x5, x6^x9, x7, x8)
    nb1 = g.permq(w1, 0xFF)                    # 新 x9 = 旧 x8
    n = shiftup(g, w1, b1)                     # (x9, x5, x6, x7) 且 lane2 = x6^x9
    w1 = n
    b1 = nb1
    # ⑥ C_j ^= D_{j-1}（C0 ^= D4），C2 再多异或一次 D4，C4 ^= D3
    s = shiftup(g, w3, b3)
    w2 = g.xor(w2, s)
    b2 = g.xor(b2, g.permq(w3, 0xFF))
    # ⑦ A ^= B
    w0 = g.xor(w0, w1)
    b0 = g.xor(b0, b1)
    # ⑧ D ^= A
    w3 = g.xor(w3, w0)
    b3 = g.xor(b3, b0)
    # ⑨ B ^= C
    w1 = g.xor(w1, w2)
    b1 = g.xor(b1, b2)
    return [w0, w1, w2, w3], [b0, b1, b2, b3]


LANE = None  # 常量名，在 emit_core 里填


def sr_vec(g, v, rule, tag):
    """一个向量（4 个 lane 同一分组）的掩码旋转：and/shl/and/shr/or 五条。"""
    sl, ml, sright, mr = rule
    if ml == M64 and mr == 0:                  # SR_Z：纯 rotl
        return g.or_(g.shl(v, sl), g.shr(v, sright))
    a = g.shl(g.and_(v, mask_const(g, ml)), sl)
    c = g.shr(g.and_(v, mask_const(g, mr)), sright)
    return g.or_(a, c)


def sr(g, w, b, phase, inv):
    """SR / SR_INV 作用在 (c) 域；分组 A（x0..x4）完全不动。"""
    rules = SR_RULES_INV if inv else SR_RULES
    r = rules[phase]
    w = list(w)
    b = list(b)
    for k in (1, 2, 3):
        w[k] = sr_vec(g, w[k], r[k], "sr")
        b[k] = sr_vec(g, b[k], r[k], "sr")
    return w, b


def round_body(g, A, T, i):
    """一轮：SBOX → MDS → SBOX → SR → MDS → SR_INV → x0 ^= RC[i]。"""
    # ① SBOX20（(a) 域，纯逐 lane）
    A = list(sbox5(g, A[0], A[1], A[2], A[3], T))
    T = A.pop()                                # 第 5 个输出就是新的 T
    # → (c)
    w = transpose4(g, A)
    b = to_bcast(g, T)
    w, b = mds(g, w, b)
    T = pack_bcast(g, b)
    A = transpose4(g, w)
    # ② SBOX20
    A = list(sbox5(g, A[0], A[1], A[2], A[3], T))
    T = A.pop()
    # → (c)，然后 SR / MDS / SR_INV / RC 全程留在 (c)
    w = transpose4(g, A)
    b = to_bcast(g, T)
    w, b = sr(g, w, b, i % 3, False)
    w, b = mds(g, w, b)
    w, b = sr(g, w, b, i % 3, True)
    w = list(w)
    w[0] = g.xor(w[0], g.rc_name(i))           # x0 ^= RC[i]（常量只有 lane0）
    T = pack_bcast(g, b)
    A = transpose4(g, w)
    return A, T


# ====================== 核心函数 ======================

def emit_core(name, r0, r1, ones_name="ONES", lane=("LANE0", "LANE1", "LANE2", "LANE3"),
              coal=True):
    global LANE
    LANE = list(lane)
    g = Gen()
    g.const(ones_name, ONES)
    for k in range(4):
        g.const(lane[k], mask_lane(k))
    hdr = ["entry %s(p: u64)" % name]
    hdr.append("  a0:u256 = ld(p + 0)")
    hdr.append("  a1:u256 = ld(p + 32)")
    hdr.append("  a2:u256 = ld(p + 64)")
    hdr.append("  a3:u256 = ld(p + 96)")
    hdr.append("  t0:u256 = ld(p + 128)")
    A = ["a0", "a1", "a2", "a3"]
    T = "t0"
    for i in range(r0, r1):
        A, T = round_body(g, A, T, i)
    # 消除 emit_sched._two_op 插入的冗余寄存器拷贝（B1）
    subst = {}
    if coal:
        subst = g.coalesce(keep=set(["a0", "a1", "a2", "a3", "t0"]))
    A = [subst.get(x, x) for x in A]
    T = subst.get(T, T)
    tail = ["  a0 = %s" % A[0], "  a1 = %s" % A[1],
            "  a2 = %s" % A[2], "  a3 = %s" % A[3], "  t0 = %s" % T]
    tail = [t for t in tail if not _self_assign(t)]
    tail.append("  st(p + 0, a0)")
    tail.append("  st(p + 32, a1)")
    tail.append("  st(p + 64, a2)")
    tail.append("  st(p + 96, a3)")
    tail.append("  st(p + 128, t0)")
    consts = ["const %s:u256 = 0x%064x" % (nm, v) for nm, v in g.consts]
    text = "\n".join(consts + [""] + hdr + g.text + tail) + "\n"
    return text, g, A, T


# ====================== Python 复算（自校验用） ======================

def ev_ops(ops, env):
    """按 emit 的顺序复算 u256（4 个 u64 lane 的 list）。"""
    def lanes(x):
        return list(x)

    for dst, fn, args in ops:
        if fn in ("xor", "and", "or"):
            a = env[args[0]]
            b = env[args[1]]
            if fn == "xor":
                r = [a[k] ^ b[k] for k in range(4)]
            elif fn == "and":
                r = [a[k] & b[k] for k in range(4)]
            else:
                r = [a[k] | b[k] for k in range(4)]
        elif fn == "shl":
            a = env[args[0]]
            k = int(args[1], 0)
            r = [(a[i] << k) & M64 for i in range(4)]
        elif fn == "shr":
            a = env[args[0]]
            k = int(args[1], 0)
            r = [a[i] >> k for i in range(4)]
        elif fn == "permq":
            a = env[args[0]]
            imm = int(args[1], 0)
            r = [a[(imm >> (2 * k)) & 3] for k in range(4)]
        elif fn == "blendd":
            a = env[args[0]]
            b = env[args[1]]
            imm = int(args[2], 0)
            r = []
            for k in range(4):
                av, bv = a[k], b[k]
                d0 = av & 0xFFFFFFFF
                d1 = (av >> 32) & 0xFFFFFFFF
                if imm & (1 << (2 * k)):
                    d0 = bv & 0xFFFFFFFF
                if imm & (1 << (2 * k + 1)):
                    d1 = (bv >> 32) & 0xFFFFFFFF
                r.append(d0 | (d1 << 32))
        elif fn in ("unpacklo", "unpackhi"):
            a = env[args[0]]
            b = env[args[1]]
            if fn == "unpacklo":
                r = [a[0], b[0], a[2], b[2]]
            else:
                r = [a[1], b[1], a[3], b[3]]
        elif fn == "perm2i128":
            a = env[args[0]]
            b = env[args[1]]
            imm = int(args[2], 0)
            src = (a, b)

            def half(sel):
                # VPERM2I128：imm[1:0]/imm[5:4] 的 bit0 选 128 位半，bit1 选 a/b
                v = src[(sel >> 1) & 1]
                return v[2:] if sel & 1 else v[:2]
            r = half(imm & 3) + half((imm >> 4) & 3)
        elif fn == "andn":
            a = env[args[0]]
            b = env[args[1]]
            r = [(~a[k] & b[k]) & M64 for k in range(4)]
        else:
            raise AssertionError("未实现 %s" % fn)
        env[dst] = r
    return env


def ref_round(x, i):
    """Python 版官方一轮（对照 Reference_Implementation 的 C 源码逐行抄）。"""
    x = list(x)
    sbox_apply(x)
    mds_ref(x)
    sbox_apply(x)
    sr_ref(x, i % 3, False)
    mds_ref(x)
    sr_ref(x, i % 3, True)
    x[0] ^= ROUND_CONSTANTS[i]
    return x


def sbox_group(x, base):
    x0, x1, x2, x3, x4 = [x[base + t] for t in range(5)]
    t0 = x0 ^ x1
    t1 = x2 ^ x4
    t2 = x0 | x2
    t3 = (~t0) & M64
    t4 = x3 ^ t3
    t5 = t1 ^ (x1 & x4)
    y0 = (((x0 ^ x4) & t3) ^ (x4 & t1)) ^ (x2 & t4)
    y1 = (t2 ^ (x0 & x4)) ^ (x1 | (x3 ^ t5))
    y2 = (x2 ^ (x3 & t1)) ^ ((x0 ^ x4) | t4)
    y3 = (x1 ^ t2) ^ (x3 & t1)
    y4 = (x3 ^ t5) ^ (x2 & t4)
    for k, v in enumerate((y0, y1, y2, y3, y4)):
        x[base + k] = v & M64


def sbox_apply(x):
    for base in (0, 5, 10, 15):
        sbox_group(x, base)


def mds_ref(x):
    x = x  # in place
    for k in range(5):
        x[k] ^= x[k + 5]
    for k in range(5):
        x[10 + k] ^= x[15 + k]
    for k in range(5):
        x[5 + k] ^= x[10 + k]
    x[15] ^= x[4]
    x[16] ^= x[0]
    x[17] ^= x[1] ^ x[4]
    x[18] ^= x[2]
    x[19] ^= x[3]
    tmp = x[9]
    x[9] = x[8]
    x[8] = x[7]
    x[7] = x[6] ^ tmp
    x[6] = x[5]
    x[5] = tmp
    x[10] ^= x[19]
    x[11] ^= x[15]
    x[12] ^= x[16] ^ x[19]
    x[13] ^= x[17]
    x[14] ^= x[18]
    for k in range(5):
        x[k] ^= x[k + 5]
    for k in range(5):
        x[15 + k] ^= x[k]
    for k in range(5):
        x[5 + k] ^= x[10 + k]


def sr_ref(x, phase, inv):
    rules = SR_RULES_INV if inv else SR_RULES
    r = rules[phase]
    for gidx in (1, 2, 3):
        sl, ml, sright, mr = r[gidx]
        for j in range(5):
            idx = 5 * gidx + j
            v = x[idx]
            x[idx] = ((((v & ml) << sl) | ((v & mr) >> sright)) & M64) & M64


# ====================== 布局互转（(a) ↔ 自然 20 字） ======================

def natural_to_a(x):
    A = []
    for j in range(4):
        A.append([x[5 * k + j] for k in range(4)])
    T = [x[5 * k + 4] for k in range(4)]
    return A, T


def a_to_natural(A, T):
    x = [0] * 20
    for k in range(4):
        for j in range(4):
            x[5 * k + j] = A[j][k]
        x[5 * k + 4] = T[k]
    return x


def check(verbose=True):
    """用 Python 复算自己发出的 JIR，与参考实现逐字比。"""
    import random
    ok = True
    rnd = random.Random(20261106)
    trials = []
    trials.append([0] * 20)
    trials.append([M64] * 20)
    for _ in range(8):
        trials.append([rnd.getrandbits(64) for _ in range(20)])
    text, g, OutA, OutT = emit_core("chk", 0, 1)
    for tno, x in enumerate(trials):
        A, T = natural_to_a(x)
        env = {}
        for nm, val in g.consts:
            env[nm] = [(val >> (64 * k)) & M64 for k in range(4)]
        env["a0"] = A[0]
        env["a1"] = A[1]
        env["a2"] = A[2]
        env["a3"] = A[3]
        env["t0"] = T
        ev_ops(g.ops, env)
        got = a_to_natural([env[n] for n in OutA], env[OutT])
        want = ref_round(x, 0)
        if got != want:
            ok = False
            if verbose:
                print("第 %d 组一轮不符" % tno)
                for k in range(20):
                    if got[k] != want[k]:
                        print("  x%-2d got=%016x want=%016x" % (k, got[k], want[k]))
            break
    if verbose:
        print("一轮自校验：%s（指令 %d 条）" % ("通过" if ok else "失败", len(g.ops)))
    return ok


def main(argv):
    if "--check" in argv:
        return 0 if check() else 1
    cores = [("xrh_round1", 0, 1), ("xrh_r0_9", 0, 9),
             ("xrh_r9_18", 9, 18), ("xrh_r0_18", 0, 18)]
    want = [a for a in argv[1:] if not a.startswith("-")] or [c[0] for c in cores]
    total = 0
    for nm, r0, r1 in cores:
        if nm not in want:
            continue
        text, g, _, _ = emit_core(nm, r0, r1)
        jir = os.path.join(HERE, nm + ".jir")
        io.open(jir, "w", encoding="utf-8", newline="\n").write(text)
        js, info = I.to_jasmin(text, nregs=16, entry=nm)
        jazz = os.path.join(HERE, nm + ".jazz")
        io.open(jazz, "w", encoding="utf-8", newline="\n").write(js)
        total += info["ir_instr"]
        print("%-11s 轮 %2d JIR %5d 行 → IR %5d 条、峰值 %2d/16、溢出 %d"
              % (nm, r1 - r0, len(text.splitlines()), info["ir_instr"],
                 info["peak"], info["spill"]))
    print("合计 IR %d 条" % total)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
