#!/usr/bin/env python3
"""build_vec.py —— XRH-1 的 256 位向量核心：生成 .jir → jasminc → gcc → .so（未计时）。

用法（WSL 内）：
    python3 build_vec.py cores     # 只生成 .jir / .jazz 并打印 IR 统计
    python3 build_vec.py build     # 三实例 512/768/1024 全部编译成 out/*.so
    python3 build_vec.py ref       # 与官方同源编译的裁判 .so（门 1/2/3 用）

布局（关键，别改）：
    20 个 u64 = **5 个 u256**。scratch 缓冲 sc 的排法
        sc[4*j + k] = x[5*k + j]      (j = 0..3, k = 0..3)
        sc[16 + k]  = x[5*k + 4]
    于是核心函数只吃 sc：a0..a3 = ld(p+0/32/64/96)、t0 = ld(p+128)，
    域 (a) 里 A_j lane k = x[5k+j]，S 盒就是纯逐 lane 布尔网络。
    真实状态序 ↔ sc 的搬移由 C 外壳做（8 条转置 + 4 条标量搬），
    这样 JIR 里不会出现 u64 中间值（to_jasmin 要求同函数同宽）。
"""
import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
L0 = os.path.dirname(HERE)                       # _overnight/l0
sys.path.insert(0, HERE)
sys.path.insert(0, WORK)

import ir_text as I  # noqa: E402
import gen_xrh as G  # noqa: E402

OUT = os.path.join(HERE, "out")
FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

INSTANCES = ["XRH-1-1024", "XRH-1-768", "XRH-1-512"]
PRIMARY = "XRH-1-1024"
# 三地址发射：消除 emit_sched._two_op 的寄存器拷贝（实测 4241 → 3665 条）。
# 设为 False 可复现旧版（用于对照）。
THREE_ADDR = True
DIGEST_BITS = {n: int(n.rsplit("-", 1)[1]) for n in INSTANCES}
REFROOT = os.path.join(L0, "src", "hash-28", "XRH-1",
                       "Implementations", "Reference_Implementation")
CORES = [("xrh_round1", 0, 1), ("xrh_r0_9", 0, 9),
         ("xrh_r9_18", 9, 18), ("xrh_r0_18", 0, 18)]


def run(args, cwd=HERE):
    rc = subprocess.run(args, cwd=cwd, stdout=None, stderr=None).returncode
    if rc != 0:
        raise SystemExit("失败 rc=%d：%s" % (rc, " ".join(args)))
    return rc


CORE_API = r"""
#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <immintrin.h>

extern void xrh_round1(uint64_t *p);
extern void xrh_r0_9(uint64_t *p);
extern void xrh_r9_18(uint64_t *p);
extern void xrh_r0_18(uint64_t *p);

/* 自然序（20 个连续 u64）→ 向量 scratch（也是 20 个 u64，但换了排法） */
static void nat_to_sc(const uint64_t *x, uint64_t *sc)
{
    __m256i a0 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 0));
    __m256i a1 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 5));
    __m256i a2 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 10));
    __m256i a3 = _mm256_loadu_si256((const __m256i *)(const void *)(x + 15));
    __m256i t0 = _mm256_unpacklo_epi64(a0, a1);
    __m256i t1 = _mm256_unpackhi_epi64(a0, a1);
    __m256i t2 = _mm256_unpacklo_epi64(a2, a3);
    __m256i t3 = _mm256_unpackhi_epi64(a2, a3);
    __m256i c0 = _mm256_permute2x128_si256(t0, t2, 0x20);
    __m256i c1 = _mm256_permute2x128_si256(t1, t3, 0x20);
    __m256i c2 = _mm256_permute2x128_si256(t0, t2, 0x31);
    __m256i c3 = _mm256_permute2x128_si256(t1, t3, 0x31);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 0), c0);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 4), c1);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 8), c2);
    _mm256_storeu_si256((__m256i *)(void *)(sc + 12), c3);
    sc[16] = x[4];
    sc[17] = x[9];
    sc[18] = x[14];
    sc[19] = x[19];
}

/* 向量 scratch → 自然序（与上面同构，转置自逆） */
static void sc_to_nat(const uint64_t *sc, uint64_t *x)
{
    __m256i a0 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 0));
    __m256i a1 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 4));
    __m256i a2 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 8));
    __m256i a3 = _mm256_loadu_si256((const __m256i *)(const void *)(sc + 12));
    __m256i t0 = _mm256_unpacklo_epi64(a0, a1);
    __m256i t1 = _mm256_unpackhi_epi64(a0, a1);
    __m256i t2 = _mm256_unpacklo_epi64(a2, a3);
    __m256i t3 = _mm256_unpackhi_epi64(a2, a3);
    _mm256_storeu_si256((__m256i *)(void *)(x + 0),
                        _mm256_permute2x128_si256(t0, t2, 0x20));
    _mm256_storeu_si256((__m256i *)(void *)(x + 5),
                        _mm256_permute2x128_si256(t1, t3, 0x20));
    _mm256_storeu_si256((__m256i *)(void *)(x + 10),
                        _mm256_permute2x128_si256(t0, t2, 0x31));
    _mm256_storeu_si256((__m256i *)(void *)(x + 15),
                        _mm256_permute2x128_si256(t1, t3, 0x31));
    x[4] = sc[16];
    x[9] = sc[17];
    x[14] = sc[18];
    x[19] = sc[19];
}

void XRH1280(int R0, int R1, uint64_t *restrict buf)
{
    uint64_t sc[20] __attribute__((aligned(32)));
    nat_to_sc(buf, sc);
    if (R0 == 0 && R1 == 18) {
        xrh_r0_18(sc);
    } else if (R0 == 0 && R1 == 9) {
        xrh_r0_9(sc);
    } else if (R0 == 9 && R1 == 18) {
        xrh_r9_18(sc);
    } else if (R0 == 0 && R1 == 1) {
        xrh_round1(sc);
    } else {
        fprintf(stderr, "XRH1280: unsupported range (%d,%d)\n", R0, R1);
        abort();
    }
    sc_to_nat(sc, buf);
}

void XRH_edmc_permute(uint64_t state[STATE_LANES])
{
    volatile uint64_t initial_state[STATE_LANES];
    size_t i;
    for (i = 0; i < STATE_LANES; i++)
        initial_state[i] = state[i];
    /* 融合版：一次 nat_to_sc … sc_to_nat 走完 9 轮 + 容量反馈 + 9 轮。
       旧版走 XRH1280(0,9) 与 XRH1280(9,18)，每次 XRH1280 都自带一次
       nat_to_sc + 一次 sc_to_nat ⇒ 每个置换 4 次布局转换；融合后 2 次。
       反馈在 sc 坐标下做：x[w] 对应 sc[4*(w%5) + w/5]
       （因为 nat_to_sc 里 sc[4*j+k] = x[5*k+j]，j=4 时 4*4+k = 16+k 正好是
        sc[16+k] = x[5*k+4]，同一个公式覆盖全部 20 个字）。 */
    {
        uint64_t sc[20] __attribute__((aligned(32)));
        nat_to_sc(state, sc);
        xrh_r0_9(sc);
        for (i = STATE_LANES - (STATE_CAPACITY / 64); i < STATE_LANES; i++)
            sc[4 * (i % 5) + i / 5] ^= initial_state[i];
        xrh_r9_18(sc);
        sc_to_nat(sc, state);
    }
}
"""


def cores():
    total = 0
    for nm, r0, r1 in CORES:
        text, g, _, _ = G.emit_core(nm, r0, r1, coal=False)
        jir = os.path.join(HERE, nm + ".jir")
        io.open(jir, "w", encoding="utf-8", newline="\n").write(text)
        # three_addr=True：让 emit_sched 直接发 `d = s0 op s1`，由 jasminc 自己
        # 做寄存器合并。默认档（False）会发 `d = s0; d = d op s1`，那一条拷贝
        # 实测 576 条/18 轮 = 32 条/轮；三地址档实测 0 条，总指令 4241 → 3665。
        # 依据：test_threeaddr.py 的 A/B，且四道门已在此档下全绿。
        js, info = I.to_jasmin(text, nregs=16, entry=nm, three_addr=THREE_ADDR)
        jazz = os.path.join(HERE, nm + ".jazz")
        io.open(jazz, "w", encoding="utf-8", newline="\n").write(js)
        total += info["ir_instr"]
        print("%-11s 轮 %2d  JIR %5d 行 → IR %5d 条、峰值 %2d/16、溢出 %d、andn %d"
              % (nm, r1 - r0, len(text.splitlines()), info["ir_instr"],
                 info["peak"], info["spill"], info.get("andn", 0)))
    print("三区间合计 IR %d 条" % total)
    return 0


def build(inst=None):
    os.makedirs(OUT, exist_ok=True)
    api = os.path.join(HERE, "vec_api.c")
    io.open(api, "w", encoding="utf-8", newline="\n").write(CORE_API)
    objs = []
    for nm, _, _ in CORES:
        run(["jasminc", "-o", nm + ".s", nm + ".jazz"])
        run(["gcc"] + FLAGS + ["-c", "-o", nm + ".o", nm + ".s"])
        objs.append(os.path.join(HERE, nm + ".o"))
    todo = [inst] if inst else INSTANCES
    for it in todo:
        dbits = DIGEST_BITS[it]
        glue = os.path.join(L0, "xrh", "glue_xrh1%d.c" % dbits)
        incd = os.path.join(REFROOT, it)
        so = os.path.join(OUT, "ours_vec_%d.so" % dbits)
        run(["gcc"] + FLAGS + ["-fPIC", "-shared", "-o", so, "-I", incd]
            + objs + [api, glue])
        print("build %s → %s" % (it, so))
    return 0


def build_v2(inst=None):
    """外壳改进版（A+B）：用 `glue_vec_<db>.c`（由 gen_glue_vec.py 派生），
    输出到**新文件名** `ours_vec2_<db>.so`，不覆盖已计时的 `ours_vec_<db>.so`。"""
    import gen_glue_vec as GV
    GV.main()                                   # 重新派生 glue_vec_<db>.c
    os.makedirs(OUT, exist_ok=True)
    api = os.path.join(HERE, "vec_api.c")
    io.open(api, "w", encoding="utf-8", newline="\n").write(CORE_API)
    objs = []
    for nm, _, _ in CORES:
        run(["jasminc", "-o", nm + ".s", nm + ".jazz"])
        run(["gcc"] + FLAGS + ["-c", "-o", nm + ".o", nm + ".s"])
        objs.append(os.path.join(HERE, nm + ".o"))
    todo = [inst] if inst else INSTANCES
    for it in todo:
        dbits = DIGEST_BITS[it]
        glue = os.path.join(HERE, "glue_vec_%d.c" % dbits)
        incd = os.path.join(REFROOT, it)
        so = os.path.join(OUT, "ours_vec2_%d.so" % dbits)
        run(["gcc"] + FLAGS + ["-fPIC", "-shared", "-o", so, "-I", incd]
            + objs + [api, glue])
        print("build_v2 %s → %s" % (it, so))
    return 0


def main(argv):
    if len(argv) > 1 and argv[1] == "cores":
        return cores()
    if len(argv) > 1 and argv[1] == "build":
        cores()
        return build(argv[2] if len(argv) > 2 else None)
    if len(argv) > 1 and argv[1] == "buildv2":
        cores()
        return build_v2(argv[2] if len(argv) > 2 else None)
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
