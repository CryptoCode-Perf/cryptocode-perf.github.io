/*
The software is provided by the Institute of Commercial Cryptography Standards
(ICCS), and is used for algorithm submissions in the Next-generation Commercial
Cryptographic Algorithms Program (NGCC).

ICCS doesn't represent or warrant that the operation of the software will be
uninterrupted or error-free in all cases. ICCS will take no responsibility for
the use of the software or the results thereof, if the software is used for any
other purposes.
*/

#include "CryptHash_AlgorithmInstance.h"
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <immintrin.h>

#if defined(__GNUC__) || defined(__clang__)
#  define FORCE_INLINE __attribute__((always_inline)) inline
#else
#  define FORCE_INLINE inline
#endif

const uint64_t ROUND_CONSTANTS[24] = {
    0x243f6a8885a308d3ULL, 0x13198a2e03707344ULL, 0xa4093822299f31d0ULL, 0x082efa98ec4e6c89ULL,
    0x452821e638d01377ULL, 0xbe5466cf34e90c6cULL, 0xc0ac29b7c97c50ddULL, 0x3f84d5b5b5470917ULL,
    0x9216d5d98979fb1bULL, 0xd1310ba698dfb5acULL, 0x2ffd72dbd01adfb7ULL, 0xb8e1afed6a267e96ULL,
    0xba7c9045f12c7f99ULL, 0x24a19947b3916cf7ULL, 0x0801f2e2858efc16ULL, 0x636920d871574e69ULL,
    0xa458fea3f4933d7eULL, 0x0d95748f728eb658ULL, 0x718bcd5882154aeeULL, 0x7b54a41dc25a59b5ULL,
    0x9c30d5392af26013ULL, 0xc5d1b023286085f0ULL, 0xca417918b8db38efULL, 0x8e79dcb0603a180eULL
};


/* ---- 以下两个函数体由我们自己的 JIR → C 实现替代（见 gen_xrh.py）；
 * 这里只保留声明，其余（ROUND_CONSTANTS / XRH_edmc_init / CryptHash）
 * 与官方 Reference_Implementation 逐字相同。 ---- */
void XRH1280(int R0, int R1, uint64_t *restrict buf);
void XRH_edmc_permute(uint64_t state[STATE_LANES]);

/* ---- B：32/16/8 字节向量 XOR（替换原来的逐字节吸收循环） ----
 * dst/msg 都可能非对齐（msg 是调用方给的任意缓冲，state_bytes 是栈上结构体成员），
 * 所以全用 unaligned 访存；只在整块放得下时才走向量，尾部不足 8 字节才逐字节。
 * 语义与原来的逐字节异或循环完全一致。
 * FORCE_INLINE：整块吸收那处的 n 是编译期常量（STATE_RATE/8），内联后 gcc 能
 * 按常量展开成 2×32 + 16 + 8，不再有 call/ret 与运行时循环判断。 */
static FORCE_INLINE void xor_bytes(uint8_t *dst, const uint8_t *src, size_t n)
{
    size_t j = 0;
    for (; j + 32 <= n; j += 32) {
        __m256i a = _mm256_loadu_si256((const __m256i *)(const void *)(dst + j));
        __m256i b = _mm256_loadu_si256((const __m256i *)(const void *)(src + j));
        _mm256_storeu_si256((__m256i *)(void *)(dst + j), _mm256_xor_si256(a, b));
    }
    if (j + 16 <= n) {
        __m128i a = _mm_loadu_si128((const __m128i *)(const void *)(dst + j));
        __m128i b = _mm_loadu_si128((const __m128i *)(const void *)(src + j));
        _mm_storeu_si128((__m128i *)(void *)(dst + j), _mm_xor_si128(a, b));
        j += 16;
    }
    if (j + 8 <= n) {
        uint64_t a, b;                      /* memcpy 规避对齐与严格别名问题 */
        memcpy(&a, dst + j, 8);
        memcpy(&b, src + j, 8);
        a ^= b;
        memcpy(dst + j, &a, 8);
        j += 8;
    }
    for (; j < n; j++) dst[j] ^= src[j];
}

static void XRH_edmc_init(XRH_state *state, uint32_t rate_bits) {
    memset(state->state, 0, STATE_LANES * sizeof(uint64_t));
    state->rate_bits = rate_bits;
}


int CryptHash(int digest_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest)
{
    XRH_state state;
    uint8_t *state_bytes = (uint8_t*)state.state;
    XRH_edmc_init(&state, STATE_RATE);
    int rate_bytes = STATE_RATE / 8;
    for (size_t i = 0; i < ((msg_len_bits + STATE_RATE) / STATE_RATE); i++) {
        if (msg_len_bits - STATE_RATE*i >= STATE_RATE) {
            xor_bytes(state_bytes, msg, (size_t)rate_bytes);
            XRH_edmc_permute(state.state);
            msg += rate_bytes; 
        }else {
            size_t length = (msg_len_bits - STATE_RATE*i) / 8;
            size_t tail_bits = msg_len_bits & 0b111;
            if (length > 0) xor_bytes(state_bytes, msg, length);
            if (tail_bits > 0) {
                state_bytes[length] ^= msg[length]&(0xFF << (8 - tail_bits));
            }
            state_bytes[length] ^= (0x80 >> tail_bits);
            if (msg_len_bits % STATE_RATE == STATE_RATE - 1) {
                XRH_edmc_permute(state.state);
            }
            state_bytes[rate_bytes - 1] ^= 0x01; 
            XRH_edmc_permute(state.state);
        }
    }

    size_t bits_out = 0;
    size_t bits_to_squeeze = (digest_len_bits - bits_out < STATE_RATE) ? (digest_len_bits - bits_out) : STATE_RATE;
    memcpy(digest + (bits_out / 8), state_bytes, bits_to_squeeze/8);
    bits_out += bits_to_squeeze;
    while (bits_out < digest_len_bits) {
        XRH1280(0, 18, (state.state));
        size_t bits_to_squeeze = (digest_len_bits - bits_out < STATE_RATE) ? (digest_len_bits - bits_out) : STATE_RATE;
        memcpy(digest + (bits_out / 8), state_bytes, bits_to_squeeze/8);
        bits_out += bits_to_squeeze;
    }

    return 0;
}