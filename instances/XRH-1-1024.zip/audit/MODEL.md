# XRH-1 — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## XRH-1-1024
- 摘要位：1024；实现形态：AVX2 汇编
- 官方参考源码：随包 `Reference_Implementation/XRH-1-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/XRH-1-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/XRH-1-1024/`
- 优化要点：引擎产物 `_overnight/l0/xrh_vec/out/ours_vec_1024.so`（build_vec.py 同一条管线，逐字节可重建） ★本行与 h28(XRH-1-512) **共用同一条发射管线与同一份生成器** `_overnight/l0/xrh_vec/build_vec.py` + `gen_xrh.py`，但产物是**单独编的一件**：XRH-1 的官方头文件把摘要长度写成编译期宏（`#define DIGEST_BIT_LENGTH 1024`、`STATE_CAPACITY = DIGEST_BIT_LENGTH + 64`、`STATE_RATE = STATE_LANES*64 - DIGEST_BIT_LENGTH - 64`），所以三档的官方 opt.so sha256 互不相同、我们三档也各是一份 .so。本行产物 `_overnight/l0

## XRH-1-768
- 摘要位：768；实现形态：AVX2 汇编
- 官方参考源码：随包 `Reference_Implementation/XRH-1-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/XRH-1-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/XRH-1-768/`
- 优化要点：引擎产物 `_overnight/l0/xrh_vec/out/ours_vec_768.so`（build_vec.py 同一条管线，逐字节可重建） ★本行与 h28(XRH-1-512) **共用同一条发射管线与同一份生成器** `_overnight/l0/xrh_vec/build_vec.py` + `gen_xrh.py`，但产物是**单独编的一件**：XRH-1 的官方头文件把摘要长度写成编译期宏（`#define DIGEST_BIT_LENGTH 768`、`STATE_CAPACITY = DIGEST_BIT_LENGTH + 64`、`STATE_RATE = STATE_LANES*64 - DIGEST_BIT_LENGTH - 64`），所以三档的官方 opt.so sha256 互不相同、我们三档也各是一份 .so。本行产物 `_overnight/l0/x
