# XRH-1 — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| XRH-1-1024 | `XRH-1-1024.so` | 63592 B | `c4441e917831f96b0d1a0c9c836f544b56ff8e5851899e5f516730543e848ad7` |
| XRH-1-768 | `XRH-1-768.so` | 63592 B | `d1903c27de8fb1a8605070f15b7c2ef4bf92557ee543c7e692ec759d41514014` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| XRH-1-1024 | 1024 | 60.1709 | 49.795 | 43.32663 | 1.149293 | 1.1238 |
| XRH-1-768 | 768 | 25.7754 | 21.2384 | 19.643396 | 1.081198 | 1.0656 |

## 优化方法（逐实例原文，来自交付清单）

### XRH-1-1024
引擎产物 `_overnight/l0/xrh_vec/out/ours_vec_1024.so`（build_vec.py 同一条管线，逐字节可重建） ★本行与 h28(XRH-1-512) **共用同一条发射管线与同一份生成器** `_overnight/l0/xrh_vec/build_vec.py` + `gen_xrh.py`，但产物是**单独编的一件**：XRH-1 的官方头文件把摘要长度写成编译期宏（`#define DIGEST_BIT_LENGTH 1024`、`STATE_CAPACITY = DIGEST_BIT_LENGTH + 64`、`STATE_RATE = STATE_LANES*64 - DIGEST_BIT_LENGTH - 64`），所以三档的官方 opt.so sha256 互不相同、我们三档也各是一份 .so。本行产物 `_overnight/l0/xrh_vec/out/ours_vec_1024.so` 逐字节可重建（同一条命令、同一份 .jir）。等价性：门2 `KAT_2_12_XRH-1-1024.txt` 4097 条逐字节不符 0；门4 `delivery_gate` 11 个长度对各自 opt.so 全过；A3 负对照（`xrh_vec/negctl_a3.py`）阳性对照 4097/4097、扰动件 4097 检查 / 0 相同。

### XRH-1-768
引擎产物 `_overnight/l0/xrh_vec/out/ours_vec_768.so`（build_vec.py 同一条管线，逐字节可重建） ★本行与 h28(XRH-1-512) **共用同一条发射管线与同一份生成器** `_overnight/l0/xrh_vec/build_vec.py` + `gen_xrh.py`，但产物是**单独编的一件**：XRH-1 的官方头文件把摘要长度写成编译期宏（`#define DIGEST_BIT_LENGTH 768`、`STATE_CAPACITY = DIGEST_BIT_LENGTH + 64`、`STATE_RATE = STATE_LANES*64 - DIGEST_BIT_LENGTH - 64`），所以三档的官方 opt.so sha256 互不相同、我们三档也各是一份 .so。本行产物 `_overnight/l0/xrh_vec/out/ours_vec_768.so` 逐字节可重建（同一条命令、同一份 .jir）。等价性：门2 `KAT_2_12_XRH-1-768.txt` 4097 条逐字节不符 0；门4 `delivery_gate` 11 个长度对各自 opt.so 全过；A3 负对照（`xrh_vec/negctl_a3.py`）阳性对照 4097/4097、扰动件 4097 检查 / 0 相同。
