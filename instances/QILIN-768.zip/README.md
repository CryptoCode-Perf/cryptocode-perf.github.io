# QILIN-768

Algorithm: QILIN | Digest bits: 768 | Form: 标量 C

Contents: implementation source/, public header QILIN-768.h, prebuilt QILIN-768.so,
KAT vector KAT_2_12_QILIN-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 0e13a5c27f6a2540202a782e614c4646d53efbc3f054239af5c7ed62cf44a944
Speed (cpB, lower is faster): reference 53.87 / official-optimized 9.673 / optimized 7.240
Speedup: GM(S1-S8) 1.37x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
