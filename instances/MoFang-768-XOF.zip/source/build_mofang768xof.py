#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mofang/build_mofang768xof.py —— MoFang-768-XOF 兄弟档交付件。

## 为什么这一档是「廉价兄弟档」

`diff Reference_Implementation/MoFang-768/CryptHash_AlgorithmInstance.c \
      Reference_Implementation/MoFang-768-XOF/CryptHash_AlgorithmInstance.c`
去掉空白行只有两处语义差异：

  1. `in_g[2][2] = 10;`  →  `in_g[2][2] = 15;`   （域分离常量）
  2. 摘要写出段 → XOF 挤出段：
     768 档  直接写 96 B（out_g 前 6 字 @0，out_h 前 6 字 @48）
     768-XOF 先 `memset(in_m, 0, ...)`，再按 `output_blocks = (output_len_bits + 767) / 768`
             循环；`i != 0` 时 `in_h[2][2] ^= 2` 并重跑 `MoFang_BC_2_DBL`，
             每块写 96 B（out_g 6 字 @0 + out_h 6 字 @48），末字节按
             `0xFF << (8 - output_len_bits % 8)` 掩码。

`encrypt2` / `MoFang_BC_2_DBL` / `hash_MDPH` 的其余部分逐字相同 ⇒ 1024 档
已验收的核心（`mofang_keys_v3.o` + `mofang_state_v3.o`）**原样复用**，
不重新生成 JIR、不重编核心。

## 本脚本做什么

从 `glue_mofang768_v3b.c`（768 档 glue，由 build_mofang768.py 生成）派生
`glue_mofang768xof_v3b.c`，三处替换每处断言命中 1 次，然后链接成
`out/ours_mofang768xof.so`。

用法：
    python3 build_mofang768xof.py build
    python3 build_mofang768xof.py kat
"""

import io
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
HERE = os.path.join(L0, "mofang")

REFHDRDIR = os.path.join(L0, "src", "hash-19", "MoFang",
                         "Implementations", "Reference_Implementation",
                         "MoFang-768-XOF")
BUILDDIR = os.path.join(L0, "build", "hash-19", "mofang768xof")
REFSO = os.path.join(BUILDDIR, "ref.so")
OPTSO = os.path.join(BUILDDIR, "opt.so")
OUT = os.path.join(HERE, "out")

SRC_GLUE = os.path.join(HERE, "glue_mofang768_v3b.c")
DST_GLUE = os.path.join(HERE, "glue_mofang768xof_v3b.c")
SO = os.path.join(OUT, "ours_mofang768xof.so")

OBJS = [os.path.join(HERE, "mofang_keys_v3.o"),
        os.path.join(HERE, "mofang_state_v3.o")]

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

# ---- 摘要段（768 档，来自 build_mofang768.py 派生后的文本）----
DIGEST_768 = """    for (int i = 0; i < 6; i++) {
        uint64_t v = out_g[i / 3][i % 3];
        memcpy(output + i * 8, &v, 8);
    }
    for (int i = 0; i < 6; i++) {
        uint64_t v = out_h[i / 3][i % 3];
        memcpy(output + 48 + i * 8, &v, 8);
    }
    free(padded_input);
    return 0;
}"""

# ---- XOF 挤出段（照 official MoFang-768-XOF 逐字搬，只把
#      `output[i*96+j] = ss` 的字节序写法换成本文件既有的 memcpy 小端写法）----
XOF_SQUEEZE = """    {
        int output_blocks = (output_len_bits + 767) / 768;
        int output_len_bytes = (output_len_bits + 7) / 8;
        memset(in_m, 0, sizeof(in_m));
        for (int b = 0; b < output_blocks; b++) {
            if (b != 0) {
                in_h[2][2] ^= 2;
                MoFang_BC_2_DBL(in_g, in_h, in_m, out_g, out_h);
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        in_g[i][j] = out_g[i][j];
                        in_h[i][j] = out_h[i][j];
                    }
                }
            }
            for (int j = 0; j < 96 && b * 96 + j < output_len_bytes; j++) {
                unsigned char ss = (j < 48)
                    ? (unsigned char)((out_g[(j / 8) / 3][(j / 8) % 3]
                                       >> (8 * (j % 8))) & 0xFFu)
                    : (unsigned char)((out_h[((j - 48) / 8) / 3][((j - 48) / 8) % 3]
                                       >> (8 * ((j - 48) % 8))) & 0xFFu);
                if (b * 96 + j == output_len_bytes - 1) {
                    int remaining_bits = output_len_bits % 8;
                    if (remaining_bits == 0) remaining_bits = 8;
                    ss = (unsigned char)(ss & (unsigned char)(0xFFu << (8 - remaining_bits)));
                }
                output[b * 96 + j] = ss;
            }
        }
    }
    free(padded_input);
    return 0;
}"""

SUBS = [
    ("    in_g[2][2] = 10;",
     "    in_g[2][2] = 15;",
     "域分离常量 10 -> 15（XOF 档）"),

    ("    (void)output_len_bits;",
     "",
     "去掉 (void)output_len_bits（XOF 真的会用它）"),

    (DIGEST_768,
     XOF_SQUEEZE,
     "摘要写出段 -> 96 B/块的 XOF 挤出段"),
]

BANNER = """/* ==== 本文件由 mofang/build_mofang768xof.py 自动生成，勿手改 ====
 * 基质 = glue_mofang768_v3b.c（我方 MoFang-768 档 glue）
 * 三处改成 768-XOF 档：%s
 * 核心（mofang_keys_v3.o / mofang_state_v3.o）与 1024 档完全同一份 ——
 * 官方 768 与 768-XOF 的 encrypt2 / MoFang_BC_2_DBL 逐字相同。
 * ================================================================= */
"""


def run(args, cwd=HERE):
    p = subprocess.run(args, cwd=cwd)
    if p.returncode != 0:
        raise SystemExit("失败 rc=%d：%s" % (p.returncode, " ".join(args)))


def cmd_glue():
    text = io.open(SRC_GLUE, encoding="utf-8", newline="").read()
    why = []
    for old, new, desc in SUBS:
        n = text.count(old)
        if n != 1:
            raise SystemExit("!! 锚点命中 %d 次（应为 1）：%s\n---\n%s" % (n, desc, old))
        text = text.replace(old, new, 1)
        why.append(desc)
    text = BANNER % "；".join(why) + text
    io.open(DST_GLUE, "w", encoding="utf-8", newline="").write(text)
    print("      glue -> %s（%d 字节）" % (os.path.basename(DST_GLUE),
                                        len(text.encode("utf-8"))))
    return 0


def cmd_build():
    os.makedirs(OUT, exist_ok=True)
    for o in OBJS:
        if not os.path.isfile(o):
            raise SystemExit("!! 缺核心目标文件：%s" % o)
    cmd_glue()
    run(["gcc"] + FLAGS + ["-fPIC", "-shared", "-o", SO, "-I", REFHDRDIR]
        + OBJS + [DST_GLUE])
    print("      -> %s  %d 字节" % (SO, os.path.getsize(SO)))
    p = subprocess.run(["nm", "-D", "-u", SO], stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, text=True)
    for ln in p.stdout.splitlines():
        s = ln.strip()
        if s and (s.startswith("U mofang") or s.startswith("U CryptHash")):
            raise SystemExit("!! 仍有未定义我方入口：%s" % s)
    return 0


def cmd_kat():
    sys.path.insert(0, os.path.join(L0, "..", ".."))
    sys.path.insert(0, L0)
    import kat_gate as K
    K.MAX_RECORDS = 10 ** 9
    K.MAX_MSG_BYTES = 1 << 20
    kat = os.path.join(L0, "src", "hash-19", "MoFang", "Test_Vectors",
                       "Test_Vector", "KAT_2_12_MoFang_768_XOF.txt")
    recs = K.parse_kat(kat)
    print("      KAT 记录 %d 条" % len(recs))
    bad = 0
    for tag, lib in (("ref", REFSO), ("opt", OPTSO), ("ours", SO)):
        chk, match, first_bad, err = K.check(lib, recs)
        print("      %-5s %d/%d  %s" % (tag, match, chk,
                                        "OK" if err is None else ("ERR " + str(err))))
        if err is not None or match != chk:
            print("            first_bad=%s" % (first_bad,))
            bad = 2
    return bad


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "glue":
        return cmd_glue()
    if cmd == "build":
        return cmd_build()
    if cmd == "kat":
        return cmd_kat()
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main())
