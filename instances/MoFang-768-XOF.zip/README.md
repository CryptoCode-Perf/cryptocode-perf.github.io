# MoFang-768-XOF

Algorithm: MoFang | Digest bits: 768 | Form: 标量 C（核心复用 1024 档）

Contents: implementation source/, public header MoFang-768-XOF.h, prebuilt MoFang-768-XOF.so,
KAT vector KAT_2_12_MoFang_768_XOF.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): ba39b63b533a1ba4742311412171b948db4fb7f873b4095c6b3ae7946269a7e9
Speed (cpB, lower is faster): reference 17.14 / official-optimized 7.97 / optimized 4.27
Speedup: GM(S1-S8) 1.83x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
