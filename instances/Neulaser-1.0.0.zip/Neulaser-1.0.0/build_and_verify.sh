#!/usr/bin/env bash
# Neulaser 1.0.0 — three-way build + cross-validation + golden vectors + KAT + speed
set -euo pipefail
cd "$(dirname "$0")"
FLAGS="-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra"
REFFLAGS="-std=c99 -Wpedantic -Wall -Wextra -O2"
mkdir -p build
pass=1
uname -a > build/environment.txt
gcc --version >> build/environment.txt
lscpu >> build/environment.txt

build_so() {   # $1 = out tag, $2 = flags, $3.. = source files
  local tag=$1 flags=$2; shift 2
  local incs=() objs=() f
  for f in "$@"; do incs+=("-I$(dirname "$f")"); done
  local cc=gcc cpp=0
  for f in "$@"; do
    case "$f" in *.cpp|*.cc|*.cxx) cc=g++; cpp=1;; *) cc=gcc;; esac
    $cc $flags "${incs[@]}" -c "$f" -o "build/${tag}_$(basename "$f").o"
    objs+=("build/${tag}_$(basename "$f").o")
  done
  local link=gcc; [ $cpp -eq 1 ] && link=g++
  $link $flags "${incs[@]}" -fPIC -shared "${objs[@]}" -o "build/${tag}.so" -lm
}

echo "== [Neulaser-512] 1/5 编译三方 =="
build_so ref_512 "$REFFLAGS" "Reference_Implementation/Neulaser-512/CryptHash_AlgorithmInstance.c"
build_so off_512 "$FLAGS"   "Optimized_Implementation/Neulaser-512/CryptHash_AlgorithmInstance.c"
build_so our_512 "$FLAGS"   "CryptoCode_Implementation/x86_AVX2/Neulaser-512/shell_512_noshellvstore.c" "CryptoCode_Implementation/x86_AVX2/Neulaser-512/nl_vstore_sisl_3.c"
for tag in ref off our; do
  gcc $FLAGS -I"$(dirname "Reference_Implementation/Neulaser-512/CryptHash_AlgorithmInstance.c")" "$@" test/vec_Neulaser-512.c build/${tag}_512.so \
      -o "build/vec_${tag}_512" -Wl,-rpath,'$ORIGIN' -lm
done

echo "== [Neulaser-512] 2/5 交叉验证（22 padding 边界长度，逐字节 diff） =="
./build/vec_ref_512 > build/v_ref_512.txt
./build/vec_off_512 > build/v_off_512.txt
./build/vec_our_512 > build/v_our_512.txt
diff -q build/v_ref_512.txt build/v_off_512.txt >/dev/null \
  || { echo "   !! 官方优化版与参考不一致"; pass=0; }
diff -q build/v_ref_512.txt build/v_our_512.txt >/dev/null \
  || { echo "   !! CryptoCode 版与参考不一致"; diff build/v_ref_512.txt build/v_our_512.txt | head -4; pass=0; }

echo "== [Neulaser-512] 3/5 黄金向量（官方参考在打包时冻结的输出） =="
diff -q build/v_ref_512.txt test/golden_vectors_ref_Neulaser-512.txt >/dev/null 2>&1 \
  || { echo "ERROR: golden vectors mismatch (Neulaser-512)"; pass=0; }

echo "== [Neulaser-512] 4/5 KAT 全量（4097 条 × 三方） =="
for tag in our ref off; do
  python3 test/kat_check.py "build/${tag}_512.so" 100000 0 kat/KAT_2_12_Neulaser-512.txt || pass=0
done

echo "== [Neulaser-512] 5/5 测速（3 次重复；TSC ticks/B，min-of-5） =="
gcc -O2 -mavx2 test/speed.c -o build/speed_512 -ldl -lm
for rep in 1 2 3; do
  ./build/speed_512 ./build/our_512.so ./build/off_512.so 512 > "build/speed_512_${rep}.txt" \
    || { echo "   !! 测速未跑通"; pass=0; }
done

echo "== [Neulaser-768] 1/5 编译三方 =="
build_so ref_768 "$REFFLAGS" "Reference_Implementation/Neulaser-768/CryptHash_AlgorithmInstance.c"
build_so off_768 "$FLAGS"   "Optimized_Implementation/Neulaser-768/CryptHash_AlgorithmInstance.c"
build_so our_768 "$FLAGS"   "CryptoCode_Implementation/x86_AVX2/Neulaser-768/shell_768_noshellvstore.c" "CryptoCode_Implementation/x86_AVX2/Neulaser-768/nl_vstore_sisl_4.c"
for tag in ref off our; do
  gcc $FLAGS -I"$(dirname "Reference_Implementation/Neulaser-768/CryptHash_AlgorithmInstance.c")" "$@" test/vec_Neulaser-768.c build/${tag}_768.so \
      -o "build/vec_${tag}_768" -Wl,-rpath,'$ORIGIN' -lm
done

echo "== [Neulaser-768] 2/5 交叉验证（22 padding 边界长度，逐字节 diff） =="
./build/vec_ref_768 > build/v_ref_768.txt
./build/vec_off_768 > build/v_off_768.txt
./build/vec_our_768 > build/v_our_768.txt
diff -q build/v_ref_768.txt build/v_off_768.txt >/dev/null \
  || { echo "   !! 官方优化版与参考不一致"; pass=0; }
diff -q build/v_ref_768.txt build/v_our_768.txt >/dev/null \
  || { echo "   !! CryptoCode 版与参考不一致"; diff build/v_ref_768.txt build/v_our_768.txt | head -4; pass=0; }

echo "== [Neulaser-768] 3/5 黄金向量（官方参考在打包时冻结的输出） =="
diff -q build/v_ref_768.txt test/golden_vectors_ref_Neulaser-768.txt >/dev/null 2>&1 \
  || { echo "ERROR: golden vectors mismatch (Neulaser-768)"; pass=0; }

echo "== [Neulaser-768] 4/5 KAT 全量（4097 条 × 三方） =="
for tag in our ref off; do
  python3 test/kat_check.py "build/${tag}_768.so" 100000 0 kat/KAT_2_12_Neulaser-768.txt || pass=0
done

echo "== [Neulaser-768] 5/5 测速（3 次重复；TSC ticks/B，min-of-5） =="
gcc -O2 -mavx2 test/speed.c -o build/speed_768 -ldl -lm
for rep in 1 2 3; do
  ./build/speed_768 ./build/our_768.so ./build/off_768.so 768 > "build/speed_768_${rep}.txt" \
    || { echo "   !! 测速未跑通"; pass=0; }
done

echo "== [Neulaser-1024] 1/5 编译三方 =="
build_so ref_1024 "$REFFLAGS" "Reference_Implementation/Neulaser-1024/CryptHash_AlgorithmInstance.c"
build_so off_1024 "$FLAGS"   "Optimized_Implementation/Neulaser-1024/CryptHash_AlgorithmInstance.c"
build_so our_1024 "$FLAGS"   "CryptoCode_Implementation/x86_AVX2/Neulaser-1024/shell_1024_noshellvstore.c" "CryptoCode_Implementation/x86_AVX2/Neulaser-1024/nl_vstore_sisl_5.c"
for tag in ref off our; do
  gcc $FLAGS -I"$(dirname "Reference_Implementation/Neulaser-1024/CryptHash_AlgorithmInstance.c")" "$@" test/vec_Neulaser-1024.c build/${tag}_1024.so \
      -o "build/vec_${tag}_1024" -Wl,-rpath,'$ORIGIN' -lm
done

echo "== [Neulaser-1024] 2/5 交叉验证（22 padding 边界长度，逐字节 diff） =="
./build/vec_ref_1024 > build/v_ref_1024.txt
./build/vec_off_1024 > build/v_off_1024.txt
./build/vec_our_1024 > build/v_our_1024.txt
diff -q build/v_ref_1024.txt build/v_off_1024.txt >/dev/null \
  || { echo "   !! 官方优化版与参考不一致"; pass=0; }
diff -q build/v_ref_1024.txt build/v_our_1024.txt >/dev/null \
  || { echo "   !! CryptoCode 版与参考不一致"; diff build/v_ref_1024.txt build/v_our_1024.txt | head -4; pass=0; }

echo "== [Neulaser-1024] 3/5 黄金向量（官方参考在打包时冻结的输出） =="
diff -q build/v_ref_1024.txt test/golden_vectors_ref_Neulaser-1024.txt >/dev/null 2>&1 \
  || { echo "ERROR: golden vectors mismatch (Neulaser-1024)"; pass=0; }

echo "== [Neulaser-1024] 4/5 KAT 全量（4097 条 × 三方） =="
for tag in our ref off; do
  python3 test/kat_check.py "build/${tag}_1024.so" 100000 0 kat/KAT_2_12_Neulaser-1024.txt || pass=0
done

echo "== [Neulaser-1024] 5/5 测速（3 次重复；TSC ticks/B，min-of-5） =="
gcc -O2 -mavx2 test/speed.c -o build/speed_1024 -ldl -lm
for rep in 1 2 3; do
  ./build/speed_1024 ./build/our_1024.so ./build/off_1024.so 1024 > "build/speed_1024_${rep}.txt" \
    || { echo "   !! 测速未跑通"; pass=0; }
done

[ $pass -eq 1 ] && echo "== 验证全部通过 ==" || { echo "== 验证存在失败项 =="; exit 2; }
