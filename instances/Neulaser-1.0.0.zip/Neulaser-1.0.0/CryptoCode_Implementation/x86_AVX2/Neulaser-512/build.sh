#!/usr/bin/env bash
# rebuild Neulaser-512 with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o Neulaser-512.so shell_512_noshellvstore.c nl_vstore_sisl_3.c CryptHash_AlgorithmInstance.h
sha256sum Neulaser-512.so
