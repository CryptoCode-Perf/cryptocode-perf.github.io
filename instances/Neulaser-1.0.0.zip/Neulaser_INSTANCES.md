# Neulaser — 实例优化说明 / Instance Optimization Notes

> 对照基准：随包 `Optimized_Implementation`。加速比为八档几何均值（32 B … 64 KiB）。
> Baseline: the vendor `Optimized_Implementation` in the same package. Metric: geometric mean over eight sizes.

本族三档共用同一套做法，差别只在参数 `mu`（状态宽度对应的 256 位寄存器组数：512→3、768→4、1024→5）。

All three tiers share one technique; they differ only in `mu` (number of 256-bit register groups for the state width: 3 / 4 / 5).

---

## 共同的两步改动 / The two changes shared by all tiers

**一、S 盒从「位切片」改成「16 段 pshufb + 掩码选择」**
官方实现把 256 字节的 S 盒展开成位切片 ANF 电路（单个 `sbox_word` 上千项），指令数爆炸，这正是它在短消息上偏慢的原因。
我方把 S 盒改成 **16 次 `vpshufb` 查表**：`lo = x & 0x0f`、`hi = (x >> 4) & 0x0f`，对每个高半字节 `h` 广播常量表 `SBOX[16h … 16h+15]` 并 `vpshufb`，再用 `vpcmpeqb` + `blendv` 选中。一个 256 位寄存器一次吃掉 32 字节，约 66 条指令完成整个 S 盒层。

**EN — 1. S-box: bit-sliced ANF → 16-way `vpshufb` + mask select.**
The vendor expands the 256-byte S-box into a bit-sliced ANF circuit (thousands of terms per `sbox_word`), which is exactly why it is slow on short inputs. Ours does 16 table look-ups: `lo = x & 0x0f`, `hi = (x >> 4) & 0x0f`, broadcast `SBOX[16h … 16h+15]` for each high nibble and `vpshufb`, then select via `vpcmpeqb` + `blendv` — one 256-bit register consumes 32 bytes, ~66 instructions for the whole layer.

**二、写回改 `volatile` 存储**
轮体末尾把 32 个 32 位结果写回状态数组时，GCC 会做 SLP store-merging，把它们拼成 8 个 ymm 的向量搬移（整个库 88 条向量指令，全在这一段）。
把每一条写成 `((volatile uint32_t *)S)[k] = x;` 之后，编译器不再合并，这段变成纯标量存储；配合寄存器里已有的值，长消息与短消息同时受益。

**EN — 2. `volatile` write-back.**
At the end of a round the 32 scalar results are written back; GCC SLP-merges them into eight 256-bit vector moves (88 vector instructions in the library, all in that tail). Writing each as `((volatile uint32_t *)S)[k] = x;` blocks the merge, so it becomes plain scalar stores and the register-resident values stay put — helping both short and long messages.

---

## Neulaser-512 · mu=3 · 1.2902（win）

350 条指令、13 次 `vpshufb`（对比位切片版约 7900 条）。/ 350 instructions, 13 `vpshufb` (vs ~7900 for the bit-sliced build).

## Neulaser-768 · mu=4 · 1.1195（win）

395 条指令、14 次 `vpshufb`。该档是 `volatile` 改动的首个受益者：改前 1.0413（平手），改后 1.1195。/ 395 instructions, 14 `vpshufb`; the first tier to benefit from the `volatile` change (1.0413 → 1.1195).

## Neulaser-1024 · mu=5 · 1.2522（win）

559 条指令、29 次 `vpshufb`、27 次掩码比较与混合。/ 559 instructions, 29 `vpshufb`, 27 compare/blend pairs.

---

## 交付与验证 / Delivery & verification

- 三档 × 3 个实现 × 4097 条 KAT，全部通过。/ Three tiers × three implementations × 4097 vectors, all pass.
- 22 个边界长度（0,1,7,63,…,16384）三方逐字节一致。/ Byte-exact agreement across 22 boundary lengths.
- 只使用 AVX2 及以下指令。/ AVX2 only.
