# QILIN 1.0.1 — CryptoCode AVX2 Implementation

Covers QILIN-512, QILIN-768, QILIN-1024 through the CryptHash ABI.
Requires x86-64 Linux/WSL2, AVX2, GCC, Python 3 and standard shell tools.

```sh
bash build_and_verify.sh
```

The script rebuilds the official reference implementation, the official optimized
implementation and the CryptoCode implementation from the sources in this package;
diff-compares digests over 22 padding-boundary message lengths; compares against the
golden vectors frozen from the official reference at release time; verifies all 4097
KAT records per digest size; and benchmarks the rebuilt shared libraries (three
repetitions each). Failure returns non-zero. All output goes to `build/`.

Baselines are compiled from exactly the files recorded in `SOURCE_MANIFEST.json`
(read out of the recipe that produced the measured opponent libraries), with the
official reference flags `-std=c99 -Wpedantic -Wall -Wextra -O2` and the official optimized flags
`-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra`.
No ISA exceptions are used by this package.

The benchmark harness uses -O2. Units are TSC ticks, not hardware core cycles; each
size reports the minimum of five batches. Results depend on the machine — they are a
reproducibility record, not a universal performance guarantee.

Directory guide: `CryptoCode_Implementation/` holds our optimized implementation, its
build script and the verified prebuilt library; `Reference_Implementation/` and
`Optimized_Implementation/` hold the official baselines; `kat/` holds official vectors;
`test/` holds the validation and benchmark tools; `results/` records this release.
Rebuilding the CryptoCode source is supported; regenerating it from the generator is
outside this release procedure.

CryptHash takes digest length in bits, message pointer, message length in bits and
output pointer; allocate at least digest_bits/8 output bytes. Supported release digest
sizes are 512, 768, 1024. AVX2 is mandatory; no runtime dispatch or fallback is supplied.
No constant-time or security proof is claimed.

Third-party sources retain their existing notices; no new license grant is invented and
redistribution permission still needs review. See SOURCE_MANIFEST.json.
