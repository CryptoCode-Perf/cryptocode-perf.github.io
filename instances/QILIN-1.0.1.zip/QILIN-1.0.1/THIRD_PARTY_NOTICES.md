# Third-party notices — QILIN 1.0.1

`Reference_Implementation/` and `Optimized_Implementation/` contain the official
QILIN sources as distributed with the competition submission (hash-23), included unchanged
for cross-validation and as the performance baseline. No new license is granted and
redistribution permission has not been established; treat this package as an
experiment record until that review is done.

`CryptoCode_Implementation/` is our own optimized source. `kat/` holds the official
known-answer vectors. `test/` holds our validation and benchmark harness.
