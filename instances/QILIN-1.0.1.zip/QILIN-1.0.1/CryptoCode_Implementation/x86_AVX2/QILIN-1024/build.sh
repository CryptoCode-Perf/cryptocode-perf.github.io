#!/usr/bin/env bash
# rebuild QILIN-1024 with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o QILIN-1024.so qilin1024.c
sha256sum QILIN-1024.so
