# Third-party notices — QSH 1.0.0

`Reference_Implementation/` and `Optimized_Implementation/` contain the official
QSH sources as distributed with the competition submission (hash-24), included unchanged
for cross-validation and as the performance baseline. No new license is granted and
redistribution permission has not been established; treat this package as an
experiment record until that review is done.

`CryptoCode_Implementation/` is our own optimized source. `kat/` holds the official
known-answer vectors. `test/` holds our validation and benchmark harness.
