#!/usr/bin/env bash
# rebuild QSH-768 with the official ten flags
set -euo pipefail
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -o QSH-768.so glue_qsh_v7.c
sha256sum QSH-768.so
