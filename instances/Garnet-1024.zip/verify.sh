#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 kat_check.py ./Garnet-1024.so 4097 0 KAT_2_12_Garnet-1024.txt
