#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -Isource source/reference_bridge.c source/Garnet_1024.c -o Garnet-1024.so
