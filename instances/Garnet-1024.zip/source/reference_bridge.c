/* Diagnostic 1024-only bridge, original core unchanged. */
extern int CryptHash_1024(const unsigned char *, unsigned long long, unsigned char *);
int CryptHash(int n,const unsigned char *m,unsigned long long bits,unsigned char *out){if(n!=1024)return -1;return CryptHash_1024(m,bits,out);}
