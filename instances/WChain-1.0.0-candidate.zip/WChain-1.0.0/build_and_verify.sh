#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")";mkdir -p build
for name in WChain-V1-512 WChain-V2-1024; do
 bits="${name##*-}";ref="Reference_Implementation/$name";opt="Optimized_Implementation/$name";own="CryptoCode_Implementation/$name"
 gcc -O2 -fPIC -shared -Wl,-z,defs -I"$ref" "$ref/CryptHash_AlgorithmInstance.c" "$ref/wchain_c.c" -o "build/Reference-$bits.so"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" "$opt/CryptHash_AlgorithmInstance.c" "$opt/wchain_c.c" -o "build/Optimized-$bits.so"
 gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$opt" "$opt/CryptHash_AlgorithmInstance.c" "$own/implementation.c" -o "build/CryptoCode-$bits.so"
 for kind in Reference Optimized CryptoCode; do python3 test/kat.py "build/$kind-$bits.so" 100000 0 "kat/$name.txt";done
done
python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for bits in 512 1024; do for kind in Reference Optimized CryptoCode; do ./build/guard_check "./build/$kind-$bits.so" "$bits";done;done
