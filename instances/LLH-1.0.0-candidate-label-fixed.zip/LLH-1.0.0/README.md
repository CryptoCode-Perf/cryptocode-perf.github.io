# LLH candidate package

Includes LLH-512 and LLH-1024. On x86-64 Linux with GCC, Python 3 and AVX2,
run `bash build_and_verify.sh`. The script rebuilds official reference,
official optimized and CryptoCode implementations and runs full KAT, selected
reference differential and input/output guard-page checks.

Candidate only: performance comparison, release review and upstream
redistribution permissions remain pending. Tests do not prove security.
