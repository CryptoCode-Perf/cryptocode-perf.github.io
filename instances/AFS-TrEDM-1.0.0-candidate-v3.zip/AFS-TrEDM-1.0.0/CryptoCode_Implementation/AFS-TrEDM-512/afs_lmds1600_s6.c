/*
 * AFS-LMDS-1600-S6 reference implementation.
 *
 * Algebra:
 *   GF(32) = F_2[a] / (a^5 + a^2 + 1).
 *   A 5-lane column is interpreted as a bitsliced GF(32) symbol
 *   S = S0 + a*S1 + a^2*S2 + a^3*S3 + a^4*S4.
 *
 * The Cauchy MDS column step is a fixed word-affine map over the 25 state
 * lanes.  It is implemented below as a common-subexpression-eliminated
 * straight-line XOR network (123 word XORs, unit depth 4) whose operands are
 * held in scalar locals so the compiler can keep the hot values in registers
 * instead of streaming through the generic per-coefficient multiply loop's
 * stack temporaries and variable-count branching.  The network was checked
 * bit-exactly against the GF(32) matrix expansion; only the state-index
 * transpose (tool word p <-> lane (p/5)+5*(p%5)) is applied at the boundaries.
 *
 * The direction-dependent tau wrap, rho, pi and mu steps are fused into a
 * single pass.  Two identities make this exact:
 *   (1) mu is lane-local, so mu o pi = pi o mu and mu commutes with every
 *       lane permutation (tau/pi);
 *   (2) mu(t) = t ^ rotr17(t) ^ rotr32(t) is a XOR of constant rotations, so
 *       mu(rotr(t,n)) = rotr(mu(t),n).
 * Consequently  tau^-1 o mu o pi o rho o C o tau  is evaluated as:
 *   C <- MDS(tau(A))                       (tau fused into MDS loads),
 *   r_i = rotr( mu(C_i), rho_i ),          (AVX2: constant + variable shifts)
 *   A[ F(pi_dst(i)) ] = r_i               (fused pi and tau^-1 scatter).
 * This removes 3 permutation loops, 3 whole-state memcpy copies and the
 * separate 25-lane rho pass from every round.  Rounds, constants, state
 * layout, byte order and the public API are unchanged.
 */

#include "afs_lmds1600_s6.h"

#include <stdint.h>
#include <string.h>

/* Called once per permutation to prepare the linear-layer index tables. */
void afs_lin_prepare(void);
/* Maps a round number to its precomputed direction slot. */
unsigned afs_lmds_slot_for_round(unsigned round);

#if defined(__AVX2__)
# include <immintrin.h>
#endif

#define AFS_LANES 25U
#define AFS_IDX(x,y) ((unsigned)((x) + 5U * (y)))
#define AFS_DIR_INF (-1)

/* Function rotr64: rotates a 64-bit word right by a constant-count modulo 64 amount. */
static uint64_t rotr64(uint64_t x, unsigned n)
{
    n &= 63U;
    return (uint64_t)((x >> n) | (x << ((64U - n) & 63U)));
}

/* rho_AFS[x][y]. */
static const unsigned char AFS_RHO[5][5] = {
    { 0U,  1U,  3U,  7U, 19U},
    { 5U,  9U, 23U, 11U, 24U},
    {14U,  6U, 25U,  8U, 21U},
    {10U, 15U, 29U, 37U, 34U},
    {28U, 33U, 39U, 43U, 27U}
};

/* d_r = [INF, 0, 1, 2, 3, 4][r mod 6]. */
static const signed char AFS_S6_DIR[6] = {
    AFS_DIR_INF, 0, 1, 2, 3, 4
};

/*
 * Public-index tables derived directly from the reference index formulas:
 *   pi_AFS: source i=(x,y) -> dest ((x+y)%5, 3x%5), dst = xp + 5*yp.
 *   F_dx(j) = (j/5) + 5*((j%5 + dx*(j/5)) % 5), for dx = 0..4.
 *     tau_d forward:  B[j] = A[F_dx(j)]
 *     tau_d inverse:  Aout[F_dx(i)] = A[i]
 *   T(p) = (p/5) + 5*(p%5) is the MDS tool-word transpose.
 *   MIDX[0] is the INF (identity) case; MIDX[dx+1][p] = F_dx(T(p)).
 * All tables are built once from the formulas; no secret data is involved.
 */
static unsigned char AFS_FMAP[5][AFS_LANES];   /* F_dx */
static unsigned char AFS_PI[AFS_LANES];        /* pi destination per source */
static uint64_t      AFS_RHO64[AFS_LANES];     /* rho count as 64-bit lane */
static uint64_t      AFS_RHO64_INV[AFS_LANES]; /* 64 - rho count, materialized once */
static unsigned char AFS_MIDX[6][AFS_LANES];   /* tau_fwd composed with T */
static unsigned char AFS_DST[6][AFS_LANES];    /* F_dx(pi(i)): flattened scatter dest */
static int AFS_LIN_READY = 0;

/* Function afs_lin_tables_build: materializes the public constant index tables
 * unconditionally.  Kept as a separate cold body so the round loop never has
 * to carry this initialization code after inlining. */
static void afs_lin_tables_build(void)
{
    unsigned dx, j;

    for (dx = 0U; dx < 5U; dx++) {
        for (j = 0U; j < AFS_LANES; j++) {
            AFS_FMAP[dx][j] = (unsigned char)((j / 5U) + 5U * ((j % 5U + dx * (j / 5U)) % 5U));
        }
    }

    for (j = 0U; j < AFS_LANES; j++) {
        unsigned x = j % 5U;
        unsigned y = j / 5U;
        unsigned t = (j / 5U) + 5U * (j % 5U); /* T(j) */
        unsigned pi = ((x + y) % 5U) + 5U * ((3U * x) % 5U);
        unsigned rho = AFS_RHO[x][y];
        AFS_PI[j] = (unsigned char)pi;
        AFS_RHO64[j] = (uint64_t)rho;
        AFS_RHO64_INV[j] = (uint64_t)(64U - rho);
        /* INF direction: tau^-1 is identity, so dst = pi.  Otherwise
         * dst = F_dx(pi), the flat composition of pi and tau^-1. */
        AFS_DST[0][j] = (unsigned char)pi;
        AFS_MIDX[0][j] = (unsigned char)t;
        for (dx = 0U; dx < 5U; dx++) {
            AFS_MIDX[dx + 1U][j] = AFS_FMAP[dx][t];
            AFS_DST[dx + 1U][j] = AFS_FMAP[dx][pi];
        }
    }

    AFS_LIN_READY = 1;
}

/* Function afs_lin_tables: guarded initializer for the public entry point. */
static void afs_lin_tables(void)
{
    if (!AFS_LIN_READY) {
        afs_lin_tables_build();
    }
}

/* Function afs_lin_prepare: forces table initialization once per permutation
 * call, outside the round loop, so the hot per-round path has no guard. */
void afs_lin_prepare(void)
{
    if (!AFS_LIN_READY) {
        afs_lin_tables_build();
    }
}

/*
 * M_col: exact 123-XOR shared Cauchy network.  Tool word p is state lane
 * T(p) = (p/5) + 5*(p%5); when a direction tau is active the source lane is
 * shifted to F_dx(T(p)) via the midx table.  T is an involution.
 */
/* Function mds_col: performs the Cauchy MDS column-symbol mixing step. */
static void mds_col(const uint64_t A[AFS_LANES],
                    uint64_t C[AFS_LANES],
                    const unsigned char midx[AFS_LANES])
{
    const uint64_t x0 = A[midx[0]],   x1 = A[midx[1]],   x2 = A[midx[2]],   x3 = A[midx[3]],   x4 = A[midx[4]];
    const uint64_t x5 = A[midx[5]],   x6 = A[midx[6]],   x7 = A[midx[7]],   x8 = A[midx[8]],   x9 = A[midx[9]];
    const uint64_t x10 = A[midx[10]], x11 = A[midx[11]], x12 = A[midx[12]], x13 = A[midx[13]], x14 = A[midx[14]];
    const uint64_t x15 = A[midx[15]], x16 = A[midx[16]], x17 = A[midx[17]], x18 = A[midx[18]], x19 = A[midx[19]];
    const uint64_t x20 = A[midx[20]], x21 = A[midx[21]], x22 = A[midx[22]], x23 = A[midx[23]], x24 = A[midx[24]];
    uint64_t s0,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15;
    uint64_t s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27,s28,s29,s30,s31;
    uint64_t s32,s33,s34,s35,s36,s37,s38,s39,s40,s41,s42,s43,s44,s45,s46,s47;
    uint64_t s48,s49,s50,s51,s52,s53,s54,s55,s56,s57,s58,s59,s60,s61,s62,s63;
    uint64_t s64,s65,s66,s67,s68,s69,s70,s71,s72,s73,s74,s75,s76,s77,s78,s79;
    uint64_t s80,s81,s82,s83,s84,s85,s86,s87,s88,s89,s90,s91,s92,s93,s94,s95;
    uint64_t s96,s97,s98,s99,s100,s101,s102,s103,s104,s105,s106,s107,s108,s109;
    uint64_t s110,s111,s112,s113,s114,s115,s116,s117,s118,s119,s120,s121,s122;

    s0 = x1 ^ x6;
    s1 = x0 ^ x14;
    s2 = s0 ^ s1;
    s3 = x15 ^ x23;
    s4 = x20 ^ x4;
    s5 = s3 ^ x5;
    s6 = s2 ^ s4;
    s7 = s5 ^ s6;
    s8 = s0 ^ x24;
    s9 = x10 ^ x21;
    s10 = x2 ^ x7;
    s11 = s10 ^ x16;
    s12 = s9 ^ x5;
    s13 = s11 ^ s12;
    s14 = s13 ^ s8;
    s15 = x3 ^ x8;
    s16 = s10 ^ s15;
    s17 = x14 ^ x22;
    s18 = s17 ^ x11;
    s19 = x17 ^ x20;
    s20 = x1 ^ x23;
    s21 = s19 ^ x4;
    s22 = s16 ^ s20;
    s23 = s18 ^ s21;
    s24 = s22 ^ s23;
    s25 = x4 ^ x9;
    s26 = s15 ^ s25;
    s27 = x18 ^ x21;
    s28 = x2 ^ x23;
    s29 = s27 ^ s28;
    s30 = x12 ^ x24;
    s31 = s26 ^ s30;
    s32 = s29 ^ s31;
    s33 = x0 ^ x13;
    s34 = s25 ^ x22;
    s35 = x19 ^ x24;
    s36 = s35 ^ x5;
    s37 = s33 ^ x3;
    s38 = s34 ^ s36;
    s39 = s37 ^ s38;
    s40 = x1 ^ x19;
    s41 = x10 ^ x20;
    s42 = s40 ^ x8;
    s43 = s34 ^ s41;
    s44 = s42 ^ s43;
    s45 = x11 ^ x2;
    s46 = x5 ^ x9;
    s47 = s3 ^ x21;
    s48 = s45 ^ s46;
    s49 = s47 ^ s48;
    s50 = x12 ^ x16;
    s51 = s0 ^ s50;
    s52 = s26 ^ s36;
    s53 = s51 ^ s52;
    s54 = x13 ^ x6;
    s55 = s10 ^ s19;
    s56 = s25 ^ s54;
    s57 = s55 ^ s56;
    s58 = s1 ^ x7;
    s59 = s15 ^ s27;
    s60 = s58 ^ s59;
    s61 = x15 ^ x17;
    s62 = s33 ^ x10;
    s63 = s46 ^ s61;
    s64 = s62 ^ s63;
    s65 = s64 ^ s8;
    s66 = s2 ^ x18;
    s67 = x11 ^ x16;
    s68 = s10 ^ x20;
    s69 = s67 ^ s68;
    s70 = s66 ^ s69;
    s71 = s35 ^ x9;
    s72 = s54 ^ x12;
    s73 = s16 ^ s9;
    s74 = s71 ^ s72;
    s75 = s73 ^ s74;
    s76 = x13 ^ x15;
    s77 = s76 ^ x7;
    s78 = s18 ^ s26;
    s79 = s77 ^ s78;
    s80 = s50 ^ x8;
    s81 = x23 ^ x5;
    s82 = s1 ^ s25;
    s83 = s80 ^ s81;
    s84 = s82 ^ s83;
    s85 = x12 ^ x3;
    s86 = x10 ^ x18;
    s87 = s25 ^ s86;
    s88 = x15 ^ x20;
    s89 = s85 ^ x6;
    s90 = s87 ^ s88;
    s91 = s89 ^ s90;
    s92 = x19 ^ x4;
    s93 = x21 ^ x7;
    s94 = s33 ^ s67;
    s95 = s92 ^ s93;
    s96 = s94 ^ s95;
    s97 = s61 ^ x22;
    s98 = s26 ^ s97;
    s99 = s66 ^ s98;
    s100 = s40 ^ x23;
    s101 = s100 ^ s11;
    s102 = s101 ^ s87;
    s103 = s36 ^ x17;
    s104 = s15 ^ s45;
    s105 = s103 ^ s104;
    s106 = s3 ^ s67;
    s107 = s106 ^ s36;
    s108 = s107 ^ s58;
    s109 = s19 ^ s8;
    s110 = s109 ^ s80;
    s111 = x13 ^ x14;
    s112 = s111 ^ s19;
    s113 = s112 ^ s67;
    s114 = s29 ^ s71;
    s115 = s113 ^ s114;
    s116 = s17 ^ s27;
    s117 = s116 ^ s85;
    s118 = s103 ^ s117;
    s119 = s3 ^ x22;
    s120 = s54 ^ s86;
    s121 = s119 ^ s92;
    s122 = s120 ^ s121;

    C[0]  = s7;   C[5]  = s14;  C[10] = s24;  C[15] = s32;  C[20] = s39;
    C[1]  = s44;  C[6]  = s49;  C[11] = s53;  C[16] = s57;  C[21] = s60;
    C[2]  = s65;  C[7]  = s70;  C[12] = s75;  C[17] = s79;  C[22] = s84;
    C[3]  = s91;  C[8]  = s96;  C[13] = s99;  C[18] = s102; C[23] = s105;
    C[4]  = s108; C[9]  = s110; C[14] = s115; C[19] = s118; C[24] = s122;
}

/* Function afs_lmds1600_s6_slot: applies the linear layer using a precomputed
 * direction slot (0 == INF, 1..5 == tau dx 0..4).  All tables must already be
 * initialized via afs_lin_prepare(); no guard or divide remains on this path. */
void afs_lmds1600_s6_slot(uint64_t *restrict A, unsigned slot)
{
    const unsigned char *midx;
    const unsigned char *dst;
    uint64_t C[AFS_LANES];
    unsigned i;

    /* tau forward is folded into the MDS input index table; tau^-1 o pi is
     * folded into the flattened per-direction destination table. */
    midx = AFS_MIDX[slot];
    dst = AFS_DST[slot];
    mds_col(A, C, midx);

    /*
     * Fused rho / pi / mu / tau^-1.  mu and rho are lane-local and are
     * evaluated together with AVX2 variable-width shifts (explicit SIMD over
     * four independent 64-bit state lanes); pi and tau^-1 are pure index
     * maps applied during the scatter.
     */
#if defined(__AVX2__)
    {
    /* Byte control for rotr64(x,32): swap the two 32-bit halves of each qword. */
    const __m256i rot32 = _mm256_setr_epi8(
        4, 5, 6, 7, 0, 1, 2, 3, 12, 13, 14, 15, 8, 9, 10, 11,
        4, 5, 6, 7, 0, 1, 2, 3, 12, 13, 14, 15, 8, 9, 10, 11);
    for (i = 0U; i + 4U <= AFS_LANES; i += 4U) {
        __m256i c = _mm256_loadu_si256((const __m256i *)(C + i));
        __m256i r17 = _mm256_or_si256(_mm256_srli_epi64(c, 17),
                                      _mm256_slli_epi64(c, 47));
        /* rotr64(c,32) is the byte permutation [4,5,6,7,0,1,2,3] per qword,
         * a single vpshufb instead of srl32+sll32+or. */
        __m256i r32 = _mm256_shuffle_epi8(c, rot32);
        __m256i t = _mm256_xor_si256(_mm256_xor_si256(c, r17), r32);
        __m256i cnt = _mm256_loadu_si256((const __m256i *)(AFS_RHO64 + i));
        __m256i cnt64 = _mm256_loadu_si256((const __m256i *)(AFS_RHO64_INV + i));
        __m256i rr = _mm256_or_si256(_mm256_srlv_epi64(t, cnt),
                                     _mm256_sllv_epi64(t, cnt64));
        uint64_t tmp[4];
        _mm256_storeu_si256((__m256i *)tmp, rr);
        A[dst[i]]     = tmp[0];
        A[dst[i + 1U]] = tmp[1];
        A[dst[i + 2U]] = tmp[2];
        A[dst[i + 3U]] = tmp[3];
    }
    for (; i < AFS_LANES; i++) {
        uint64_t t = C[i] ^ rotr64(C[i], 17U) ^ rotr64(C[i], 32U);
        uint64_t r = rotr64(t, (unsigned)AFS_RHO64[i]);
        A[dst[i]] = r;
    }
    }
#else
    for (i = 0U; i < AFS_LANES; i++) {
        uint64_t t = C[i] ^ rotr64(C[i], 17U) ^ rotr64(C[i], 32U);
        uint64_t r = rotr64(t, (unsigned)AFS_RHO64[i]);
        A[dst[i]] = r;
    }
#endif
}

/* Function afs_lmds_slot_for_round: maps a round number to its direction slot
 * (0 == INF, 1..5 == tau dx 0..4). */
unsigned afs_lmds_slot_for_round(unsigned round)
{
    int d = (int)AFS_S6_DIR[round % 6U];
    return (d == AFS_DIR_INF) ? 0U : ((unsigned)d + 1U);
}

/* Function afs_lmds1600_s6: reference-compatible per-round entry point. */
void afs_lmds1600_s6(uint64_t A[AFS_LANES], unsigned round)
{
    afs_lin_tables();
    afs_lmds1600_s6_slot(A, afs_lmds_slot_for_round(round));
}
