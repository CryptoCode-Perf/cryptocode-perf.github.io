#include "afs_p1600.h"
#include "afs_sbox64.h"
#include "afs_lmds1600_s6.h"

#if defined(__AVX2__)
# include <immintrin.h>
#endif

/* Function splitmix64_value: computes the public SplitMix64 value used for round/lane constant derivation. */
static uint64_t splitmix64_value(uint64_t x)
{
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

/* Function afs_round_lane_constant: derives RC32(round,lane) from the documented public SplitMix64 schedule. */
static uint32_t afs_round_lane_constant(unsigned round, unsigned lane)
{
    const uint64_t seed = 0xB4C5F1D62E1738A9ULL; /* public SplitMix64 domain seed. */
    uint64_t idx = (uint64_t)round * 25ULL + (uint64_t)lane;
    uint64_t z = splitmix64_value(seed + idx * 0x9E3779B97F4A7C15ULL);
    return (uint32_t)(z ^ (z >> 32));
}

/*
 * The AVX2 S-box deinterleaves the 32-bit halves of two adjacent 64-bit lanes
 * with vshufps controls 0x88 / 0xDD.  vshufps works within a 128-bit lane, so
 * the eight dwords of one 8-lane group come out in the order
 *   [0,1,4,5,2,3,6,7]
 * (logical lane indices) instead of 0..7.  The ARX is lane-independent, so
 * only the round constants have to be stored in the same permuted order.
 * AFS_RC_PERM8 maps a logical lane to its physical slot inside one group.
 * Lane 24 is the scalar tail (slot 24 maps to itself).
 */
static const unsigned char AFS_RC_PERM8[8] = { 0U, 1U, 4U, 5U, 2U, 3U, 6U, 7U };

/* Function afs_rc_slot: physical RC-table slot for logical lane l. */
static unsigned afs_rc_slot(unsigned l)
{
    return (l & ~7U) + (unsigned)AFS_RC_PERM8[l & 7U];
}

/*
 * The round/lane constants are a pure function of (round, lane).  Cache the
 * complete documented schedule (rounds 0..AFS_P1600_MAX_ROUNDS-1) as 32-bit
 * words, stored in the vector-lane order used by the S-box.  One AVX2 load
 * then fetches the eight constants matching the eight active ARX lanes.
 */
static uint32_t AFS_RC_TABLE[AFS_P1600_MAX_ROUNDS][AFS_P1600_LANES];
static int AFS_RC_READY = 0;

/* Function afs_rc_init: materializes the full public RC32 schedule once. */
static void afs_rc_init(void)
{
    unsigned r, l;

    if (AFS_RC_READY) {
        return;
    }
    for (r = 0U; r < AFS_P1600_MAX_ROUNDS; r++) {
        for (l = 0U; l < AFS_P1600_LANES; l++) {
            AFS_RC_TABLE[r][afs_rc_slot(l)] = afs_round_lane_constant(r, l);
        }
    }
    AFS_RC_READY = 1;
}

/* Function afs_round_constants: returns the RC32 vector for a round.  All
 * in-range rounds are precomputed by afs_rc_init(); the out-of-range fallback
 * is kept for API completeness but lives outside the hot round path. */
static const uint32_t *afs_round_constants(unsigned round,
                                           uint32_t local[AFS_P1600_LANES])
{
    unsigned l;

    if (round < AFS_P1600_MAX_ROUNDS) {
        return AFS_RC_TABLE[round];
    }
    for (l = 0U; l < AFS_P1600_LANES; l++) {
        local[afs_rc_slot(l)] = afs_round_lane_constant(round, l);
    }
    return local;
}

/* Linear-layer preparation/mapping helpers (afs_lmds1600_s6.c). */
extern void afs_lin_prepare(void);
extern unsigned afs_lmds_slot_for_round(unsigned round);
extern void afs_lmds1600_s6_slot(uint64_t *restrict A, unsigned slot);

#if defined(__AVX2__)

/* Function afs_rotr32_8: 32-bit rotate-right applied independently to all eight dwords of a vector. */
static __m256i afs_rotr32_8(__m256i x, unsigned n)
{
    if (n == 0U) {
        return x;
    }
    return _mm256_or_si256(_mm256_srli_epi32(x, (int)n),
                           _mm256_slli_epi32(x, (int)(32U - n)));
}

/*
 * Function afs_rotr16_8: 32-bit rotate by 16 applied to all eight dwords.
 * rotr32(x,16) == rotl32(x,16) is just a swap of the two 16-bit halves of each
 * dword, i.e. the byte permutation [2,3,0,1] within every dword.  vpshufb does
 * this in ONE instruction instead of the three (srl, sll, or) of the generic
 * rotate, and stays in the integer domain feeding the ARX add/xor chain.
 */
static __m256i afs_rotr16_8(__m256i x, const __m256i rot16)
{
    return _mm256_shuffle_epi8(x, rot16);
}

/*
 * Function afs_rotr24_8: 32-bit rotate-right-by-24 applied to all eight dwords.
 * rotr32(x,24) == rotl32(x,8) is a byte rotation [3,0,1,2] within each dword
 * (verified bit-exactly as (x>>24)|(x<<8)).  One vpshufb replaces the three
 * shift/shift/or instructions of the generic rotate and keeps the value in
 * the integer domain feeding the ARX add/xor chain.
 */
static __m256i afs_rotr24_8(__m256i x, const __m256i rot24)
{
    return _mm256_shuffle_epi8(x, rot24);
}

/*
 * Function afs_p1600_sbox_layer: applies one AFS-64 S-box per 64-bit lane for
 * all 25 lanes.  Each lane holds its 32-bit x half in the high dword and its
 * y half in the low dword.  For each 8-lane group the two source vectors (four
 * 64-bit lanes each) are deinterleaved into all-y and all-x dword planes with
 * two vshufps instructions (0x88 selects even dwords, 0xDD selects odd).
 * vshufps is confined to a 128-bit lane, so the eight dwords emerge in order
 * [0,1,4,5,2,3,6,7]; the ARX is lane independent and the round constants are
 * stored in exactly this order.  On output, vpunpckldq / vpunpckhdq of Y/X
 * directly form the correctly ordered 64-bit lanes, so no cross-lane
 * permute2x128 is required.  All add/rotate/xor operations are 32-bit dword
 * operations, matching the reference uint32_t ARX bit-for-bit.
 *
 * The three independent 8-lane ARX chains are interleaved step by step so
 * that all three dependency chains are simultaneously live, exposing ILP to
 * the out-of-order scheduler.
 */
static void afs_p1600_sbox_layer(uint64_t A[AFS_P1600_LANES],
                                  const uint32_t C[AFS_P1600_LANES])
{
    /* Byte control for rotr32(x,16): swap each dword's two 16-bit halves. */
    const __m256i rot16 = _mm256_setr_epi8(
        2, 3, 0, 1, 6, 7, 4, 5, 10, 11, 8, 9, 14, 15, 12, 13,
        2, 3, 0, 1, 6, 7, 4, 5, 10, 11, 8, 9, 14, 15, 12, 13);
    /* Byte control for rotr32(x,24) == rotl32(x,8): rotate bytes [3,0,1,2]. */
    const __m256i rot24 = _mm256_setr_epi8(
        3, 0, 1, 2, 7, 4, 5, 6, 11, 8, 9, 10, 15, 12, 13, 14,
        3, 0, 1, 2, 7, 4, 5, 6, 11, 8, 9, 10, 15, 12, 13, 14);
    __m256 va, vb;
    __m256i Y0, X0, Y1, X1, Y2, X2, C0, C1, C2;
    __m256i o0, o1;

    /* Phase 1: load + deinterleave all groups before any ARX begins. */
    va = _mm256_castsi256_ps(_mm256_loadu_si256((const __m256i *)(A)));
    vb = _mm256_castsi256_ps(_mm256_loadu_si256((const __m256i *)(A + 4)));
    Y0 = _mm256_castps_si256(_mm256_shuffle_ps(va, vb, 0x88));
    X0 = _mm256_castps_si256(_mm256_shuffle_ps(va, vb, 0xDD));

    va = _mm256_castsi256_ps(_mm256_loadu_si256((const __m256i *)(A + 8)));
    vb = _mm256_castsi256_ps(_mm256_loadu_si256((const __m256i *)(A + 12)));
    Y1 = _mm256_castps_si256(_mm256_shuffle_ps(va, vb, 0x88));
    X1 = _mm256_castps_si256(_mm256_shuffle_ps(va, vb, 0xDD));

    va = _mm256_castsi256_ps(_mm256_loadu_si256((const __m256i *)(A + 16)));
    vb = _mm256_castsi256_ps(_mm256_loadu_si256((const __m256i *)(A + 20)));
    Y2 = _mm256_castps_si256(_mm256_shuffle_ps(va, vb, 0x88));
    X2 = _mm256_castps_si256(_mm256_shuffle_ps(va, vb, 0xDD));

    C0 = _mm256_loadu_si256((const __m256i *)(C));
    C1 = _mm256_loadu_si256((const __m256i *)(C + 8));
    C2 = _mm256_loadu_si256((const __m256i *)(C + 16));

    /* Phase 2: interleave the three independent ARX chains step by step. */
    X0 = _mm256_xor_si256(_mm256_add_epi32(X0, afs_rotr32_8(Y0, 17U)), C0);
    X1 = _mm256_xor_si256(_mm256_add_epi32(X1, afs_rotr32_8(Y1, 17U)), C1);
    X2 = _mm256_xor_si256(_mm256_add_epi32(X2, afs_rotr32_8(Y2, 17U)), C2);
    Y0 = _mm256_xor_si256(_mm256_add_epi32(Y0, afs_rotr24_8(X0, rot24)), C0);
    Y1 = _mm256_xor_si256(_mm256_add_epi32(Y1, afs_rotr24_8(X1, rot24)), C1);
    Y2 = _mm256_xor_si256(_mm256_add_epi32(Y2, afs_rotr24_8(X2, rot24)), C2);
    X0 = _mm256_xor_si256(X0, afs_rotr32_8(Y0, 1U));
    X1 = _mm256_xor_si256(X1, afs_rotr32_8(Y1, 1U));
    X2 = _mm256_xor_si256(X2, afs_rotr32_8(Y2, 1U));
    Y0 = _mm256_xor_si256(Y0, afs_rotr32_8(X0, 1U));
    Y1 = _mm256_xor_si256(Y1, afs_rotr32_8(X1, 1U));
    Y2 = _mm256_xor_si256(Y2, afs_rotr32_8(X2, 1U));
    X0 = _mm256_xor_si256(X0, afs_rotr16_8(Y0, rot16));
    X1 = _mm256_xor_si256(X1, afs_rotr16_8(Y1, rot16));
    X2 = _mm256_xor_si256(X2, afs_rotr16_8(Y2, rot16));
    Y0 = _mm256_xor_si256(Y0, afs_rotr32_8(X0, 31U));
    Y1 = _mm256_xor_si256(Y1, afs_rotr32_8(X1, 31U));
    Y2 = _mm256_xor_si256(Y2, afs_rotr32_8(X2, 31U));
    X0 = _mm256_xor_si256(_mm256_add_epi32(X0, afs_rotr24_8(Y0, rot24)), C0);
    X1 = _mm256_xor_si256(_mm256_add_epi32(X1, afs_rotr24_8(Y1, rot24)), C1);
    X2 = _mm256_xor_si256(_mm256_add_epi32(X2, afs_rotr24_8(Y2, rot24)), C2);
    Y0 = _mm256_xor_si256(_mm256_add_epi32(Y0, X0), C0); /* rotr32(X,0) == X */
    Y1 = _mm256_xor_si256(_mm256_add_epi32(Y1, X1), C1);
    Y2 = _mm256_xor_si256(_mm256_add_epi32(Y2, X2), C2);

    /* Phase 3: interleave Y/X back into 64-bit lanes and store.  With the
     * [0,1,4,5,2,3,6,7] plane order, unpacklo yields lanes 0..3 of the group
     * and unpackhi yields lanes 4..7, so no cross-lane shuffle is needed. */
    o0 = _mm256_unpacklo_epi32(Y0, X0);
    o1 = _mm256_unpackhi_epi32(Y0, X0);
    _mm256_storeu_si256((__m256i *)(A), o0);
    _mm256_storeu_si256((__m256i *)(A + 4), o1);

    o0 = _mm256_unpacklo_epi32(Y1, X1);
    o1 = _mm256_unpackhi_epi32(Y1, X1);
    _mm256_storeu_si256((__m256i *)(A + 8), o0);
    _mm256_storeu_si256((__m256i *)(A + 12), o1);

    o0 = _mm256_unpacklo_epi32(Y2, X2);
    o1 = _mm256_unpackhi_epi32(Y2, X2);
    _mm256_storeu_si256((__m256i *)(A + 16), o0);
    _mm256_storeu_si256((__m256i *)(A + 20), o1);
}

#endif /* __AVX2__ */

/* Function afs_p1600_round_hot: applies one round using a precomputed RC
 * vector and direction slot.  No cache guard, constant fallback, or round-
 * to-direction divide remains on this path. */
static void afs_p1600_round_hot(uint64_t *restrict A,
                                const uint32_t *restrict C,
                                unsigned slot)
{
    unsigned i;

    /* Nonlinear layer: one selected AFS-64 S-box per 64-bit lane. */
#if defined(__AVX2__)
    afs_p1600_sbox_layer(A, C);
    for (i = 24U; i < AFS_P1600_LANES; i++) {
        A[i] = afs64_t5_k2(A[i], C[i]);
    }
#else
    for (i = 0U; i < AFS_P1600_LANES; i++) {
        A[i] = afs64_t5_k2(A[i], C[i]);
    }
#endif

    /* Lane-friendly AFS-LMDS-1600-S6 linear layer with precomputed direction. */
    afs_lmds1600_s6_slot(A, slot);
}

/* Function afs_p1600_permute: applies a consecutive range of AFS-p-S6 rounds. */
void afs_p1600_permute(uint64_t A[AFS_P1600_LANES], unsigned first_round, unsigned nr)
{
    unsigned i;

    /* Prepare all public constant tables once per call, outside the round
     * loop, so the hot per-round path is guard-free. */
    afs_rc_init();
    afs_lin_prepare();

    if (nr <= AFS_P1600_MAX_ROUNDS && first_round <= AFS_P1600_MAX_ROUNDS - nr) {
        /* All rounds are within the precomputed RC table. */
        for (i = 0U; i < nr; i++) {
            unsigned r = first_round + i;
            afs_p1600_round_hot(A, AFS_RC_TABLE[r], afs_lmds_slot_for_round(r));
        }
    } else {
        /* Preserve the original out-of-range fallback semantics. */
        for (i = 0U; i < nr; i++) {
            unsigned r = first_round + i;
            uint32_t local[AFS_P1600_LANES];
            const uint32_t *C = afs_round_constants(r, local);
            afs_p1600_round_hot(A, C, afs_lmds_slot_for_round(r));
        }
    }
}

/* Function afs_p1600_g: applies the front half g of the split permutation. */
void afs_p1600_g(uint64_t A[AFS_P1600_LANES])
{
    afs_p1600_permute(A, 0U, AFS_P1600_SPLIT_ROUNDS);
}

/* Function afs_p1600_h: applies the back half h of the split permutation. */
void afs_p1600_h(uint64_t A[AFS_P1600_LANES])
{
    afs_p1600_permute(A, AFS_P1600_SPLIT_ROUNDS, AFS_P1600_SPLIT_ROUNDS);
}
