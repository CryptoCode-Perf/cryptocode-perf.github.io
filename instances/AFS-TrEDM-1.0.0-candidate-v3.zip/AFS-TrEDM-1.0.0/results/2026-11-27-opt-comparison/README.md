# Exploratory performance comparison

The three rounds compare package-built official optimized and CryptoCode
libraries using the frozen `plan.json` and the included raw CSV files. Ratios
are official time / CryptoCode time: greater than one favors CryptoCode.
The 8-size geometric means were 1.072 (512), 0.947 (768), and 1.192 (1024).
The 768-bit candidate was slower than official optimized in this experiment.

The timer is CLOCK_MONOTONIC_RAW and reports nanoseconds, not hardware cycles.
Measurements used WSL2, CPU affinity, randomized size order and ABBA/BAAB
pairing; cooperative locking cannot prevent unrelated host load. Consult
`environment.txt` and `summary.json`. Results are exploratory and depend on
CPU, toolchain, and load; no universal fastest or release certification claim
is made. `test/pair_bench.c` is the measurement harness; rerun only with
appropriate exclusive measurement coordination.
