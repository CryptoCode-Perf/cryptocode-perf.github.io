# AFS-TrEDM candidate package

Instances: AFS-TrEDM-512, AFS-TrEDM-768 and AFS-TrEDM-1024.
On x86-64 Linux with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`.
This rebuilds the reference, official optimized and CryptoCode implementations,
checks all 4097 known-answer vectors for each, compares deterministic long and
boundary inputs, and checks selected input/output guard-page boundaries.

The 512-bit candidate is recovered from the current site package; the 768
and 1024-bit candidates are recovered from the local performance report.
The latter use the included official wrapper and supporting optimized files.
Build flags include -mtune=native, so output can vary by host/compiler.

Candidate only: controlled fastest-implementation comparison, source and
license review, redistribution permission and final release review remain
pending. Tests do not prove security or cover every input and environment.

Exploratory measurements against the included official optimized builds are
under results/. In that experiment the 768-bit CryptoCode build was slower
than the official optimized build; implementation selection remains open.

Provisional performance-based selection is recorded in selection.json. Run
`bash build_selected.sh` to rebuild, verify and place selected libraries in
`build/selected/`. For 768 bits the selected library is the upstream official
optimized implementation, which measured faster than the report-derived
CryptoCode candidate. Its origin is explicit; the other two selections use
CryptoCode implementations. Performance depends on the environment.
