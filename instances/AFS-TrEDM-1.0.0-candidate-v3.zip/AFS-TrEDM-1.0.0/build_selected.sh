#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash build_and_verify.sh
mkdir -p build/selected
cp build/CryptoCode-512.so build/selected/AFS-TrEDM-512.so
cp build/Optimized-768.so build/selected/AFS-TrEDM-768.so
cp build/CryptoCode-1024.so build/selected/AFS-TrEDM-1024.so
sha256sum build/selected/*.so > build/selected/SHA256SUMS
printf 'Selected libraries: build/selected/ (selection is provisional; see selection.json)\n'
