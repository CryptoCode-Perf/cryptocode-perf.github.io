# ZC-DM — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## ZC-DM-1280-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/ZC-DM-1280-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/ZC-DM-1280-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/ZC-DM-1280-512/`
- 优化要点：**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息

## ZC-DM-1280-768
- 摘要位：768；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/ZC-DM-1280-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/ZC-DM-1280-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/ZC-DM-1280-768/`
- 优化要点：**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息

## ZC-DM-1536-1024
- 摘要位：1024；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/ZC-DM-1536-1024/`
- 官方优化源码：随包 `Official_Optimized_Implementation/ZC-DM-1536-1024/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/ZC-DM-1536-1024/`
- 优化要点：**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes 

## ZC-DM-1536-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/ZC-DM-1536-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/ZC-DM-1536-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/ZC-DM-1536-512/`
- 优化要点：**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes 

## ZC-DM-1536-768
- 摘要位：768；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/ZC-DM-1536-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/ZC-DM-1536-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/ZC-DM-1536-768/`
- 优化要点：**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes 
