# ZC-DM — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| ZC-DM-1280-512 | `ZC-DM-1280-512.so` | 38448 B | `19d694eacd5a635b2c2836c23f9e5e362b630d5e941bf2ecef47603a3a60ff48` |
| ZC-DM-1280-768 | `ZC-DM-1280-768.so` | 38448 B | `19d694eacd5a635b2c2836c23f9e5e362b630d5e941bf2ecef47603a3a60ff48` |
| ZC-DM-1536-1024 | `ZC-DM-1536-1024.so` | 26008 B | `8411bf58fbca3300a78dd55b89f8b25ee933cc24b04da632aee4cd45bd776d05` |
| ZC-DM-1536-512 | `ZC-DM-1536-512.so` | 26008 B | `8411bf58fbca3300a78dd55b89f8b25ee933cc24b04da632aee4cd45bd776d05` |
| ZC-DM-1536-768 | `ZC-DM-1536-768.so` | 26008 B | `8411bf58fbca3300a78dd55b89f8b25ee933cc24b04da632aee4cd45bd776d05` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| ZC-DM-1280-512 | 512 | 4.5361 | 3.2695 | 3.1235 | 1.0467 | 1.1493 |
| ZC-DM-1280-768 | 768 | 7.501 | 5.4267 | 5.253 | 1.0331 | 1.0728 |
| ZC-DM-1536-1024 | 1024 | 16.2188 | 8.8879 | 7.676 | 1.1579 | 1.175 |
| ZC-DM-1536-512 | 512 | 7.4238 | 4.5427 | 3.4077 | 1.3331 | 1.5271 |
| ZC-DM-1536-768 | 768 | 10.832 | 6.2244 | 5.188 | 1.1998 | 1.2675 |

## 优化方法（逐实例原文，来自交付清单）

### ZC-DM-1280-512
**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息长度无关 ⇒ 短消息里它占整次调用的相当比例，而 cpB 表的几何均值含 S1/S2，收益直接进总 gm。改法（`zc/try_1280_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.029085（512 B 处 1.0816、1024 B 1.0496、4096 B 1.0180、65536 B 1.0001）。ZC-DM 的 1280 档原本只赢在置换核的寄存器驻留（我方 `zud_permute12` 674 条 vs 官方 `ZuD1280_avx2_Permute_12rounds` 685 条，官方另有 4950 条的 `ZuD1280_avx2_DMLoop_Absorb` 把置换整段内联进吸收回路），官方 `ZuD1280_avx2_AddBytes` 本来就是 32 字节 AVX2，吸收段无便宜可捡。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DM-1280-768
**本批改动（驱动层结构性冗余，不是指令级微调）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。空转次数上限 512 档 703 次 / 768 档 447 次 / 1024 档 191 次，**每次 `CryptHash` 调用都跑一遍**，与消息长度无关 ⇒ 短消息里它占整次调用的相当比例，而 cpB 表的几何均值含 S1/S2，收益直接进总 gm。改法（`zc/try_1280_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.033189（512 B 处 1.0816、1024 B 1.0404、4096 B 1.0126、65536 B 1.0001）。ZC-DM 的 1280 档原本只赢在置换核的寄存器驻留（我方 `zud_permute12` 674 条 vs 官方 `ZuD1280_avx2_Permute_12rounds` 685 条，官方另有 4950 条的 `ZuD1280_avx2_DMLoop_Absorb` 把置换整段内联进吸收回路），官方 `ZuD1280_avx2_AddBytes` 本来就是 32 字节 AVX2，吸收段无便宜可捡。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DM-1536-1024
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.024652（512 B 处 1.0626、1024 B 1.0311、4096 B 1.0098、65536 B 0.9963）。本档 rate = 56 B，pad 空转上限 447 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-DM 的 1536 档原本靠「官方 `ZuD1536_avx2_AddBytes` 是逐字节循环（11 条指令）而我方改成 32 字节成组」拿到 1.146–1.158，核心置换两边逐项同构；本批再叠一层驱动层 pad 空转的消除，短档涨到 1.26 是因为 rate 120 B 最长、空转上限 959 次也最多，固定开销在 S1/S2 里占比最高。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DM-1536-512
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.120599（512 B 处 1.2648、1024 B 1.1896、4096 B 1.0476、65536 B 1.0005）。本档 rate = 120 B，pad 空转上限 959 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-DM 的 1536 档原本靠「官方 `ZuD1536_avx2_AddBytes` 是逐字节循环（11 条指令）而我方改成 32 字节成组」拿到 1.146–1.158，核心置换两边逐项同构；本批再叠一层驱动层 pad 空转的消除，短档涨到 1.26 是因为 rate 120 B 最长、空转上限 959 次也最多，固定开销在 S1/S2 里占比最高。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。

### ZC-DM-1536-768
**本批改动（承 accel52 的 1280 档同一条：驱动层 pad 空转）**：官方胶水 `CryptHash()` 里有一段「把当前位置补到块尾前一位」的逐比特循环 —— `while (bitpos < rateBytes * 8u - 1u) { append_bit_msb_custom(&st, block, &bitpos, rateBytes, 0); }`；而 `append_bit_msb_custom(..., b = 0)` 的实体在 `b == 0` 时既不写块也不异或，只把 `bitpos` 加一，循环条件又保证那条「攒满一块」的分支永远进不去 ⇒ **整段等价于把 `bitpos` 直接推到块尾前一位**，逐字节等价、不改变任何消息块。改法（`zc1536/try_1536_pad.py`）把它换成一次赋值 `if (bitpos < rateBytes * 8u - 1u) { bitpos = rateBytes * 8u - 1u; }`。对现网件实测 1.023324（512 B 处 1.0360、1024 B 1.0370、4096 B 1.0148、65536 B 1.0059）。本档 rate = 88 B，pad 空转上限 703 次，每次 `CryptHash` 调用都跑一遍、与消息长度无关。ZC-DM 的 1536 档原本靠「官方 `ZuD1536_avx2_AddBytes` 是逐字节循环（11 条指令）而我方改成 32 字节成组」拿到 1.146–1.158，核心置换两边逐项同构；本批再叠一层驱动层 pad 空转的消除，短档涨到 1.26 是因为 rate 120 B 最长、空转上限 959 次也最多，固定开销在 S1/S2 里占比最高。全部 4097 条 KAT 通过（ref/opt/ours 三侧），`delivery_gate` 全位长通过。
