"""256 位版构建：JIR → jasmin（`ir_text.to_jasmin`）→ jasminc → .s → .so，再跑三道门。

和标量版共用 `zud_api.c`（`ZuD1280_avx2_*` 外壳）。区别只在核心置换：
这里 `zud_permute12` 由 **jasmin 生成**，`zud_round_*`（Nrounds/6rounds 用）仍是标量 C。
KAT 与实测走的都是 `Permute_12rounds`，所以量的就是 jasmin 那条路。
"""
import ctypes
import io
import os
import random
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_ours as B  # noqa: E402

OPT_FLAGS = B.OPT_FLAGS
INC = B.INC
INST_DIR = B.INST_DIR


def sh(args):
    r = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, errors="replace")
    return r.returncode, r.stdout


def strip_permute12(path):
    """从标量 zud_gen.c 里摘掉 `zud_permute12`（否则与 jasmin 的符号重名）。"""
    txt = io.open(path, encoding="utf-8").read()
    i = txt.find("void zud_permute12(")
    j = txt.find("void zud_round_", i)
    assert i >= 0 and j > i, "找不到 zud_permute12 边界"
    out = os.path.join(HERE, "zud_gen_rounds.c")
    io.open(out, "w", encoding="utf-8", newline="\n").write(txt[:i] + txt[j:])
    return out


def build(outdir):
    os.makedirs(outdir, exist_ok=True)
    # 1) 生成 .jir + .jazz（12 轮全置换 + 6 轮版，后者给 Permute_6rounds 用）
    rc, log = sh([sys.executable, os.path.join(HERE, "gen_zud256.py")])
    if rc != 0:
        print(log[-2000:])
        return None
    objs = []
    for jazz_name, obj_name in (("zud1280_v256.jazz", "zud_v.o"),
                                ("zud1280_v256_r6.jazz", "zud_v6.o")):
        jazz = os.path.join(HERE, jazz_name)
        s_path = os.path.join(outdir, obj_name.replace(".o", ".s"))
        rc, log = sh(["jasminc", "-o", s_path, jazz])
        if rc != 0:
            print("jasminc 失败（%s）：\n%s" % (jazz_name, log[-3000:]))
            return None
        o = os.path.join(outdir, obj_name)
        rc, log = sh(["gcc", "-c", "-o", o, s_path])
        if rc != 0:
            print("汇编失败：\n" + log[-2000:])
            return None
        objs.append(o)
    rounds = strip_permute12(os.path.join(HERE, "zud_gen.c"))
    for src in (rounds, os.path.join(HERE, "zud_api.c")):
        o = os.path.join(outdir, os.path.basename(src) + ".o")
        cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", o]
        for d in INC:
            cmd += ["-I", d]
        cmd.append(src)
        rc, log = sh(cmd)
        if rc != 0:
            print("编译失败（%s）：\n%s" % (src, log[-2000:]))
            return None
        objs.append(o)
    glue_o = os.path.join(outdir, "glue.o")
    cmd = ["gcc"] + OPT_FLAGS + ["-fPIC", "-c", "-o", glue_o]
    for d in INC:
        cmd += ["-I", d]
    cmd.append(os.path.join(INST_DIR, "CryptHash_AlgorithmInstance.c"))
    rc, log = sh(cmd)
    if rc != 0:
        print("胶水编译失败：\n" + log[-2000:])
        return None
    objs.append(glue_o)
    so = os.path.join(outdir, "ours_v256_1280_1024.so")
    rc, log = sh(["gcc", "-shared", "-o", so] + objs)
    if rc != 0:
        print("链接失败：\n" + log[-2000:])
        return None
    # 512/768 三个名字写同一份字节：官方胶水按 `digest_len_bits` 在**运行时**选容量
    # （capacity = digest + 64，576/832/1088），一个 .so 服务三个实例，官方自己也是
    # 三份逐字节相同的胶水。留三个名字只是为了 `time_all_deliveries.CASES` 好读。
    # ⚠ 曾经出过事：重建后只更新了 `_1024`，`_512/768` 还是旧字节（缺 `zud_permute6`），
    # 于是「同名不同物」。所以这里显式一起覆盖。
    for cap in ("512", "768"):
        dst = os.path.join(outdir, "ours_v256_1280_%s.so" % cap)
        with open(so, "rb") as f:
            data = f.read()
        with open(dst, "wb") as g:
            g.write(data)
    print("构建成功：%s（%d 字节，512/768 两个别名同字节）"
          % (so, os.path.getsize(so)))
    return so


def perm6_test(ours_so, plain_so, trials=48):
    """6 轮置换门：`ZuD1280_avx2_Permute_6rounds`（现在走 jasmin 的 `zud_permute6`）
    必须与官方 `ZuD1280_plain_Permute_6rounds` 逐 lane 相同。"""
    ours = ctypes.CDLL(ours_so)
    plain = ctypes.CDLL(plain_so)
    PTR = ctypes.POINTER(ctypes.c_uint64)
    ours.ZuD1280_avx2_Permute_6rounds.argtypes = [PTR]
    plain.ZuD1280_plain_Permute_6rounds.argtypes = [PTR]
    rnd = random.Random(20261106)
    cases = [[0] * 20, [0xFFFFFFFFFFFFFFFF] * 20] + \
            [[rnd.getrandbits(64) for _ in range(20)] for _ in range(trials)]
    bad = 0
    first = None
    for t, st in enumerate(cases):
        a = (ctypes.c_uint64 * 20)(*st)
        b = (ctypes.c_uint64 * 20)(*st)
        ours.ZuD1280_avx2_Permute_6rounds(a)
        plain.ZuD1280_plain_Permute_6rounds(b)
        if list(a) != list(b):
            bad += 1
            if first is None:
                first = (t, [(i, hex(a[i]), hex(b[i])) for i in range(20) if a[i] != b[i]][:3])
    print("%s 6 轮置换：%d/%d 组一致%s"
          % ("✓" if bad == 0 else "✗", len(cases) - bad, len(cases),
             "" if not bad else "，首个 %s" % (first,)))
    return bad == 0


def main() -> int:
    outdir = os.path.join(HERE, "out")
    so = build(outdir)
    if not so:
        return 1
    plain = os.path.join(outdir, "plain_1280.so")
    if not os.path.exists(plain):
        plain = B.build_plain_ref(outdir)
    ok_perm = B.perm_test(so, plain)
    ok_perm6 = perm6_test(so, plain)
    ok_kat = B.kat_check(so)
    if not (ok_perm and ok_perm6 and ok_kat):
        print("\n正确性未过，不测性能。")
        return 1
    opt_so = os.path.abspath(os.path.join(HERE, "..", "build", "hash-30",
                                          "zcdm12801024", "opt.so"))
    B.measure(so, opt_so)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
