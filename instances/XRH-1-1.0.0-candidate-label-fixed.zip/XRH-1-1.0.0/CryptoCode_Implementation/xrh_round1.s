	.att_syntax
	.text
	.p2align	5
	.global	xrh_round1
	.type	xrh_round1, %function
xrh_round1:
	vmovdqu	(%rdi), %ymm7
	vmovdqu	32(%rdi), %ymm2
	vmovdqu	64(%rdi), %ymm0
	vmovdqu	96(%rdi), %ymm10
	vmovdqu	128(%rdi), %ymm1
	vpxor	%ymm2, %ymm7, %ymm5
	vpxor	%ymm1, %ymm0, %ymm3
	vpor	%ymm0, %ymm7, %ymm4
	vpxor	glob_data + 352(%rip), %ymm5, %ymm11
	vpxor	%ymm11, %ymm10, %ymm5
	vpand	%ymm1, %ymm2, %ymm6
	vpxor	%ymm3, %ymm6, %ymm12
	vpxor	%ymm1, %ymm7, %ymm6
	vpand	%ymm1, %ymm7, %ymm7
	vpand	%ymm3, %ymm10, %ymm8
	vpand	%ymm5, %ymm0, %ymm9
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm6, %ymm11, %ymm11
	vpand	%ymm3, %ymm1, %ymm1
	vpxor	%ymm1, %ymm11, %ymm1
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm4, %ymm7, %ymm7
	vpor	%ymm10, %ymm2, %ymm3
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm8, %ymm0, %ymm0
	vpor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm8, %ymm8
	vpxor	%ymm10, %ymm9, %ymm9
	vpunpcklqdq	%ymm7, %ymm1, %ymm2
	vpunpckhqdq	%ymm7, %ymm1, %ymm7
	vpunpcklqdq	%ymm8, %ymm0, %ymm6
	vpunpckhqdq	%ymm8, %ymm0, %ymm3
	vperm2i128	$32, %ymm6, %ymm2, %ymm4
	vperm2i128	$32, %ymm3, %ymm7, %ymm0
	vperm2i128	$49, %ymm6, %ymm2, %ymm6
	vperm2i128	$49, %ymm3, %ymm7, %ymm5
	vpermq	$0, %ymm9, %ymm3
	vpermq	$85, %ymm9, %ymm7
	vpermq	$170, %ymm9, %ymm10
	vpermq	$255, %ymm9, %ymm1
	vpxor	%ymm0, %ymm4, %ymm2
	vpxor	%ymm7, %ymm3, %ymm4
	vpxor	%ymm5, %ymm6, %ymm6
	vpxor	%ymm1, %ymm10, %ymm10
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm10, %ymm7, %ymm3
	vpermq	$144, %ymm2, %ymm7
	vpxor	%ymm4, %ymm7, %ymm8
	vpblendd	$48, %ymm8, %ymm7, %ymm8
	vpblendd	$3, %ymm4, %ymm8, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vpermq	$255, %ymm2, %ymm12
	vpxor	%ymm12, %ymm1, %ymm1
	vpermq	$255, %ymm0, %ymm7
	vpermq	$144, %ymm0, %ymm0
	vpxor	%ymm3, %ymm0, %ymm9
	vpblendd	$48, %ymm9, %ymm0, %ymm0
	vpblendd	$3, %ymm3, %ymm0, %ymm0
	vpermq	$144, %ymm5, %ymm8
	vpxor	%ymm1, %ymm8, %ymm3
	vpblendd	$48, %ymm3, %ymm8, %ymm12
	vpblendd	$3, %ymm1, %ymm12, %ymm3
	vpxor	%ymm3, %ymm6, %ymm6
	vpermq	$255, %ymm5, %ymm3
	vpxor	%ymm3, %ymm10, %ymm10
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm7, %ymm4, %ymm3
	vpxor	%ymm2, %ymm5, %ymm5
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm10, %ymm7, %ymm7
	vpblendd	$12, %ymm7, %ymm3, %ymm9
	vpblendd	$48, %ymm10, %ymm9, %ymm3
	vpblendd	$192, %ymm1, %ymm3, %ymm1
	vpunpcklqdq	%ymm0, %ymm2, %ymm8
	vpunpckhqdq	%ymm0, %ymm2, %ymm0
	vpunpcklqdq	%ymm5, %ymm6, %ymm12
	vpunpckhqdq	%ymm5, %ymm6, %ymm2
	vperm2i128	$32, %ymm12, %ymm8, %ymm3
	vperm2i128	$32, %ymm2, %ymm0, %ymm4
	vperm2i128	$49, %ymm12, %ymm8, %ymm7
	vperm2i128	$49, %ymm2, %ymm0, %ymm10
	vpxor	%ymm4, %ymm3, %ymm9
	vpxor	%ymm1, %ymm7, %ymm0
	vpor	%ymm7, %ymm3, %ymm2
	vpxor	glob_data + 352(%rip), %ymm9, %ymm11
	vpxor	%ymm11, %ymm10, %ymm5
	vpand	%ymm1, %ymm4, %ymm8
	vpxor	%ymm0, %ymm8, %ymm12
	vpxor	%ymm1, %ymm3, %ymm6
	vpand	%ymm1, %ymm3, %ymm3
	vpand	%ymm0, %ymm10, %ymm8
	vpand	%ymm5, %ymm7, %ymm9
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm6, %ymm11, %ymm11
	vpand	%ymm0, %ymm1, %ymm0
	vpxor	%ymm0, %ymm11, %ymm0
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm2, %ymm3, %ymm3
	vpor	%ymm10, %ymm4, %ymm12
	vpxor	%ymm12, %ymm3, %ymm3
	vpxor	%ymm8, %ymm7, %ymm7
	vpor	%ymm6, %ymm5, %ymm1
	vpxor	%ymm1, %ymm7, %ymm7
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm4, %ymm8, %ymm5
	vpxor	%ymm10, %ymm9, %ymm8
	vpunpcklqdq	%ymm3, %ymm0, %ymm2
	vpunpckhqdq	%ymm3, %ymm0, %ymm0
	vpunpcklqdq	%ymm5, %ymm7, %ymm12
	vpunpckhqdq	%ymm5, %ymm7, %ymm4
	vperm2i128	$32, %ymm12, %ymm2, %ymm1
	vperm2i128	$32, %ymm4, %ymm0, %ymm5
	vperm2i128	$49, %ymm12, %ymm2, %ymm6
	vperm2i128	$49, %ymm4, %ymm0, %ymm2
	vpermq	$0, %ymm8, %ymm3
	vpermq	$85, %ymm8, %ymm4
	vpermq	$170, %ymm8, %ymm10
	vpermq	$255, %ymm8, %ymm9
	vpand	glob_data + 192(%rip), %ymm5, %ymm0
	vpsllq	$1, %ymm0, %ymm7
	vpand	glob_data + 160(%rip), %ymm5, %ymm5
	vpsrlq	$3, %ymm5, %ymm5
	vpor	%ymm5, %ymm7, %ymm7
	vpand	glob_data + 192(%rip), %ymm4, %ymm0
	vpsllq	$1, %ymm0, %ymm0
	vpand	glob_data + 160(%rip), %ymm4, %ymm4
	vpsrlq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm0, %ymm0
	vpand	glob_data + 128(%rip), %ymm6, %ymm4
	vpsllq	$2, %ymm4, %ymm8
	vpand	glob_data + 96(%rip), %ymm6, %ymm6
	vpsrlq	$2, %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm8
	vpand	glob_data + 128(%rip), %ymm10, %ymm5
	vpsllq	$2, %ymm5, %ymm5
	vpand	glob_data + 96(%rip), %ymm10, %ymm10
	vpsrlq	$2, %ymm10, %ymm4
	vpor	%ymm4, %ymm5, %ymm5
	vpand	glob_data + 64(%rip), %ymm2, %ymm4
	vpsllq	$3, %ymm4, %ymm4
	vpand	glob_data + 32(%rip), %ymm2, %ymm2
	vpsrlq	$1, %ymm2, %ymm11
	vpor	%ymm11, %ymm4, %ymm4
	vpand	glob_data + 64(%rip), %ymm9, %ymm6
	vpsllq	$3, %ymm6, %ymm6
	vpand	glob_data + 32(%rip), %ymm9, %ymm9
	vpsrlq	$1, %ymm9, %ymm12
	vpor	%ymm12, %ymm6, %ymm6
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm0, %ymm3, %ymm2
	vpxor	%ymm4, %ymm8, %ymm8
	vpxor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm5, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm10
	vpxor	%ymm2, %ymm10, %ymm3
	vpblendd	$48, %ymm3, %ymm10, %ymm3
	vpblendd	$3, %ymm2, %ymm3, %ymm3
	vpxor	%ymm3, %ymm4, %ymm4
	vpermq	$255, %ymm1, %ymm11
	vpxor	%ymm11, %ymm6, %ymm3
	vpermq	$255, %ymm7, %ymm6
	vpermq	$144, %ymm7, %ymm9
	vpxor	%ymm0, %ymm9, %ymm12
	vpblendd	$48, %ymm12, %ymm9, %ymm10
	vpblendd	$3, %ymm0, %ymm10, %ymm0
	vpermq	$144, %ymm4, %ymm7
	vpxor	%ymm3, %ymm7, %ymm9
	vpblendd	$48, %ymm9, %ymm7, %ymm11
	vpblendd	$3, %ymm3, %ymm11, %ymm7
	vpxor	%ymm7, %ymm8, %ymm8
	vpermq	$255, %ymm4, %ymm9
	vpxor	%ymm9, %ymm5, %ymm5
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm5, %ymm6, %ymm6
	vpand	glob_data + 64(%rip), %ymm0, %ymm12
	vpsllq	$3, %ymm12, %ymm12
	vpand	glob_data + 32(%rip), %ymm0, %ymm0
	vpsrlq	$1, %ymm0, %ymm10
	vpor	%ymm10, %ymm12, %ymm0
	vpand	glob_data + 64(%rip), %ymm6, %ymm7
	vpsllq	$3, %ymm7, %ymm9
	vpand	glob_data + 32(%rip), %ymm6, %ymm6
	vpsrlq	$1, %ymm6, %ymm11
	vpor	%ymm11, %ymm9, %ymm6
	vpand	glob_data + 128(%rip), %ymm8, %ymm7
	vpsllq	$2, %ymm7, %ymm9
	vpand	glob_data + 96(%rip), %ymm8, %ymm8
	vpsrlq	$2, %ymm8, %ymm12
	vpor	%ymm12, %ymm9, %ymm9
	vpand	glob_data + 128(%rip), %ymm5, %ymm7
	vpsllq	$2, %ymm7, %ymm10
	vpand	glob_data + 96(%rip), %ymm5, %ymm5
	vpsrlq	$2, %ymm5, %ymm7
	vpor	%ymm7, %ymm10, %ymm10
	vpand	glob_data + 192(%rip), %ymm4, %ymm5
	vpsllq	$1, %ymm5, %ymm5
	vpand	glob_data + 160(%rip), %ymm4, %ymm4
	vpsrlq	$3, %ymm4, %ymm7
	vpor	%ymm7, %ymm5, %ymm4
	vpand	glob_data + 192(%rip), %ymm3, %ymm8
	vpsllq	$1, %ymm8, %ymm5
	vpand	glob_data + 160(%rip), %ymm3, %ymm3
	vpsrlq	$3, %ymm3, %ymm3
	vpor	%ymm3, %ymm5, %ymm5
	vpxor	glob_data + 0(%rip), %ymm1, %ymm1
	vpblendd	$12, %ymm6, %ymm2, %ymm8
	vpblendd	$48, %ymm10, %ymm8, %ymm3
	vpblendd	$192, %ymm5, %ymm3, %ymm5
	vpunpcklqdq	%ymm0, %ymm1, %ymm2
	vpunpckhqdq	%ymm0, %ymm1, %ymm7
	vpunpcklqdq	%ymm4, %ymm9, %ymm8
	vpunpckhqdq	%ymm4, %ymm9, %ymm0
	vperm2i128	$32, %ymm8, %ymm2, %ymm3
	vperm2i128	$32, %ymm0, %ymm7, %ymm1
	vperm2i128	$49, %ymm8, %ymm2, %ymm2
	vperm2i128	$49, %ymm0, %ymm7, %ymm10
	vmovdqu	%ymm3, (%rdi)
	vmovdqu	%ymm1, 32(%rdi)
	vmovdqu	%ymm2, 64(%rdi)
	vmovdqu	%ymm10, 96(%rdi)
	vmovdqu	%ymm5, 128(%rdi)
	ret
	.data
	.p2align	5
glob_data:
G$RCV0:
	.byte	211,   8, 163, 133, 136, 106,  63,  36,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$MKeeeeeeeeeeeeeeee:
	.byte	238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238
	.byte	238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238
G$MK1111111111111111:
	.byte	 17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17
	.byte	 17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17
G$MKcccccccccccccccc:
	.byte	204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204
	.byte	204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204
G$MK3333333333333333:
	.byte	 51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51
	.byte	 51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51
G$MK8888888888888888:
	.byte	136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136
	.byte	136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136
G$MK7777777777777777:
	.byte	119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119
	.byte	119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119
G$LANE3:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 255, 255, 255, 255, 255, 255, 255, 255
G$LANE2:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	255, 255, 255, 255, 255, 255, 255, 255,   0,   0,   0,   0,   0,   0,   0,   0
G$LANE1:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 255, 255, 255, 255, 255, 255, 255, 255
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$LANE0:
	.byte	255, 255, 255, 255, 255, 255, 255, 255,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$ONES:
	.byte	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255
	.byte	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits
