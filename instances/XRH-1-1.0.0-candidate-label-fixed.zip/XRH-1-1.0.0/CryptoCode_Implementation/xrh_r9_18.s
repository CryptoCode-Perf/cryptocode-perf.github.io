	.att_syntax
	.text
	.p2align	5
	.global	xrh_r9_18
	.type	xrh_r9_18, %function
xrh_r9_18:
	vmovdqu	(%rdi), %ymm7
	vmovdqu	32(%rdi), %ymm2
	vmovdqu	64(%rdi), %ymm0
	vmovdqu	96(%rdi), %ymm10
	vmovdqu	128(%rdi), %ymm1
	vpxor	%ymm2, %ymm7, %ymm8
	vpxor	%ymm1, %ymm0, %ymm3
	vpor	%ymm0, %ymm7, %ymm4
	vpxor	glob_data + 896(%rip), %ymm8, %ymm11
	vpxor	%ymm11, %ymm10, %ymm5
	vpand	%ymm1, %ymm2, %ymm6
	vpxor	%ymm3, %ymm6, %ymm12
	vpxor	%ymm1, %ymm7, %ymm6
	vpand	%ymm1, %ymm7, %ymm7
	vpand	%ymm3, %ymm10, %ymm8
	vpand	%ymm5, %ymm0, %ymm9
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm6, %ymm11, %ymm11
	vpand	%ymm3, %ymm1, %ymm1
	vpxor	%ymm1, %ymm11, %ymm1
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm4, %ymm7, %ymm7
	vpor	%ymm10, %ymm2, %ymm3
	vpxor	%ymm3, %ymm7, %ymm7
	vpxor	%ymm8, %ymm0, %ymm0
	vpor	%ymm6, %ymm5, %ymm3
	vpxor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm8, %ymm5
	vpxor	%ymm10, %ymm9, %ymm9
	vpunpcklqdq	%ymm7, %ymm1, %ymm4
	vpunpckhqdq	%ymm7, %ymm1, %ymm3
	vpunpcklqdq	%ymm5, %ymm0, %ymm1
	vpunpckhqdq	%ymm5, %ymm0, %ymm6
	vperm2i128	$32, %ymm1, %ymm4, %ymm5
	vperm2i128	$32, %ymm6, %ymm3, %ymm0
	vperm2i128	$49, %ymm1, %ymm4, %ymm7
	vperm2i128	$49, %ymm6, %ymm3, %ymm1
	vpermq	$0, %ymm9, %ymm4
	vpermq	$85, %ymm9, %ymm8
	vpermq	$170, %ymm9, %ymm10
	vpermq	$255, %ymm9, %ymm2
	vpxor	%ymm0, %ymm5, %ymm3
	vpxor	%ymm8, %ymm4, %ymm4
	vpxor	%ymm1, %ymm7, %ymm6
	vpxor	%ymm2, %ymm10, %ymm10
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm10, %ymm8, %ymm5
	vpermq	$144, %ymm3, %ymm7
	vpxor	%ymm4, %ymm7, %ymm8
	vpblendd	$48, %ymm8, %ymm7, %ymm8
	vpblendd	$3, %ymm4, %ymm8, %ymm7
	vpxor	%ymm7, %ymm1, %ymm1
	vpermq	$255, %ymm3, %ymm7
	vpxor	%ymm7, %ymm2, %ymm2
	vpermq	$255, %ymm0, %ymm7
	vpermq	$144, %ymm0, %ymm0
	vpxor	%ymm5, %ymm0, %ymm9
	vpblendd	$48, %ymm9, %ymm0, %ymm0
	vpblendd	$3, %ymm5, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm5
	vpxor	%ymm2, %ymm5, %ymm8
	vpblendd	$48, %ymm8, %ymm5, %ymm5
	vpblendd	$3, %ymm2, %ymm5, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vpermq	$255, %ymm1, %ymm5
	vpxor	%ymm5, %ymm10, %ymm10
	vpxor	%ymm0, %ymm3, %ymm3
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm10, %ymm7, %ymm7
	vpblendd	$12, %ymm7, %ymm4, %ymm9
	vpblendd	$48, %ymm10, %ymm9, %ymm5
	vpblendd	$192, %ymm2, %ymm5, %ymm7
	vpunpcklqdq	%ymm0, %ymm3, %ymm5
	vpunpckhqdq	%ymm0, %ymm3, %ymm8
	vpunpcklqdq	%ymm1, %ymm6, %ymm0
	vpunpckhqdq	%ymm1, %ymm6, %ymm1
	vperm2i128	$32, %ymm0, %ymm5, %ymm3
	vperm2i128	$32, %ymm1, %ymm8, %ymm4
	vperm2i128	$49, %ymm0, %ymm5, %ymm0
	vperm2i128	$49, %ymm1, %ymm8, %ymm10
	vpxor	%ymm4, %ymm3, %ymm9
	vpxor	%ymm7, %ymm0, %ymm1
	vpor	%ymm0, %ymm3, %ymm2
	vpxor	glob_data + 896(%rip), %ymm9, %ymm11
	vpxor	%ymm11, %ymm10, %ymm5
	vpand	%ymm7, %ymm4, %ymm8
	vpxor	%ymm1, %ymm8, %ymm12
	vpxor	%ymm7, %ymm3, %ymm6
	vpand	%ymm7, %ymm3, %ymm3
	vpand	%ymm1, %ymm10, %ymm8
	vpand	%ymm5, %ymm0, %ymm9
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm6, %ymm11, %ymm11
	vpand	%ymm1, %ymm7, %ymm1
	vpxor	%ymm1, %ymm11, %ymm1
	vpxor	%ymm9, %ymm1, %ymm1
	vpxor	%ymm2, %ymm3, %ymm3
	vpor	%ymm10, %ymm4, %ymm7
	vpxor	%ymm7, %ymm3, %ymm3
	vpxor	%ymm8, %ymm0, %ymm0
	vpor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm5, %ymm0, %ymm0
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm4, %ymm8, %ymm5
	vpxor	%ymm10, %ymm9, %ymm8
	vpunpcklqdq	%ymm3, %ymm1, %ymm4
	vpunpckhqdq	%ymm3, %ymm1, %ymm3
	vpunpcklqdq	%ymm5, %ymm0, %ymm7
	vpunpckhqdq	%ymm5, %ymm0, %ymm0
	vperm2i128	$32, %ymm7, %ymm4, %ymm1
	vperm2i128	$32, %ymm0, %ymm3, %ymm5
	vperm2i128	$49, %ymm7, %ymm4, %ymm6
	vperm2i128	$49, %ymm0, %ymm3, %ymm3
	vpermq	$0, %ymm8, %ymm2
	vpermq	$85, %ymm8, %ymm4
	vpermq	$170, %ymm8, %ymm10
	vpermq	$255, %ymm8, %ymm9
	vpand	glob_data + 736(%rip), %ymm5, %ymm0
	vpsllq	$1, %ymm0, %ymm0
	vpand	glob_data + 704(%rip), %ymm5, %ymm5
	vpsrlq	$3, %ymm5, %ymm5
	vpor	%ymm5, %ymm0, %ymm7
	vpand	glob_data + 736(%rip), %ymm4, %ymm0
	vpsllq	$1, %ymm0, %ymm0
	vpand	glob_data + 704(%rip), %ymm4, %ymm4
	vpsrlq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm0, %ymm0
	vpand	glob_data + 672(%rip), %ymm6, %ymm8
	vpsllq	$2, %ymm8, %ymm5
	vpand	glob_data + 640(%rip), %ymm6, %ymm6
	vpsrlq	$2, %ymm6, %ymm4
	vpor	%ymm4, %ymm5, %ymm8
	vpand	glob_data + 672(%rip), %ymm10, %ymm5
	vpsllq	$2, %ymm5, %ymm5
	vpand	glob_data + 640(%rip), %ymm10, %ymm10
	vpsrlq	$2, %ymm10, %ymm4
	vpor	%ymm4, %ymm5, %ymm5
	vpand	glob_data + 608(%rip), %ymm3, %ymm4
	vpsllq	$3, %ymm4, %ymm4
	vpand	glob_data + 576(%rip), %ymm3, %ymm3
	vpsrlq	$1, %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm3
	vpand	glob_data + 608(%rip), %ymm9, %ymm6
	vpsllq	$3, %ymm6, %ymm4
	vpand	glob_data + 576(%rip), %ymm9, %ymm9
	vpsrlq	$1, %ymm9, %ymm6
	vpor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm3, %ymm8, %ymm8
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm5, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm10
	vpxor	%ymm2, %ymm10, %ymm6
	vpblendd	$48, %ymm6, %ymm10, %ymm6
	vpblendd	$3, %ymm2, %ymm6, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpermq	$255, %ymm1, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vpermq	$255, %ymm7, %ymm6
	vpermq	$144, %ymm7, %ymm9
	vpxor	%ymm0, %ymm9, %ymm7
	vpblendd	$48, %ymm7, %ymm9, %ymm10
	vpblendd	$3, %ymm0, %ymm10, %ymm0
	vpermq	$144, %ymm3, %ymm7
	vpxor	%ymm4, %ymm7, %ymm9
	vpblendd	$48, %ymm9, %ymm7, %ymm7
	vpblendd	$3, %ymm4, %ymm7, %ymm7
	vpxor	%ymm7, %ymm8, %ymm8
	vpermq	$255, %ymm3, %ymm9
	vpxor	%ymm9, %ymm5, %ymm5
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm1, %ymm3, %ymm3
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm5, %ymm6, %ymm6
	vpand	glob_data + 608(%rip), %ymm0, %ymm7
	vpsllq	$3, %ymm7, %ymm7
	vpand	glob_data + 576(%rip), %ymm0, %ymm0
	vpsrlq	$1, %ymm0, %ymm10
	vpor	%ymm10, %ymm7, %ymm0
	vpand	glob_data + 608(%rip), %ymm6, %ymm7
	vpsllq	$3, %ymm7, %ymm7
	vpand	glob_data + 576(%rip), %ymm6, %ymm6
	vpsrlq	$1, %ymm6, %ymm9
	vpor	%ymm9, %ymm7, %ymm6
	vpand	glob_data + 672(%rip), %ymm8, %ymm7
	vpsllq	$2, %ymm7, %ymm9
	vpand	glob_data + 640(%rip), %ymm8, %ymm8
	vpsrlq	$2, %ymm8, %ymm7
	vpor	%ymm7, %ymm9, %ymm9
	vpand	glob_data + 672(%rip), %ymm5, %ymm7
	vpsllq	$2, %ymm7, %ymm10
	vpand	glob_data + 640(%rip), %ymm5, %ymm5
	vpsrlq	$2, %ymm5, %ymm7
	vpor	%ymm7, %ymm10, %ymm10
	vpand	glob_data + 736(%rip), %ymm3, %ymm7
	vpsllq	$1, %ymm7, %ymm7
	vpand	glob_data + 704(%rip), %ymm3, %ymm3
	vpsrlq	$3, %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm3
	vpand	glob_data + 736(%rip), %ymm4, %ymm5
	vpsllq	$1, %ymm5, %ymm5
	vpand	glob_data + 704(%rip), %ymm4, %ymm4
	vpsrlq	$3, %ymm4, %ymm4
	vpor	%ymm4, %ymm5, %ymm5
	vpxor	glob_data + 544(%rip), %ymm1, %ymm1
	vpblendd	$12, %ymm6, %ymm2, %ymm6
	vpblendd	$48, %ymm10, %ymm6, %ymm4
	vpblendd	$192, %ymm5, %ymm4, %ymm6
	vpunpcklqdq	%ymm0, %ymm1, %ymm4
	vpunpckhqdq	%ymm0, %ymm1, %ymm7
	vpunpcklqdq	%ymm3, %ymm9, %ymm5
	vpunpckhqdq	%ymm3, %ymm9, %ymm3
	vperm2i128	$32, %ymm5, %ymm4, %ymm0
	vperm2i128	$32, %ymm3, %ymm7, %ymm2
	vperm2i128	$49, %ymm5, %ymm4, %ymm1
	vperm2i128	$49, %ymm3, %ymm7, %ymm10
	vpxor	%ymm2, %ymm0, %ymm5
	vpxor	%ymm6, %ymm1, %ymm3
	vpor	%ymm1, %ymm0, %ymm4
	vpxor	glob_data + 896(%rip), %ymm5, %ymm11
	vpxor	%ymm11, %ymm10, %ymm5
	vpand	%ymm6, %ymm2, %ymm7
	vpxor	%ymm3, %ymm7, %ymm12
	vpxor	%ymm6, %ymm0, %ymm9
	vpand	%ymm6, %ymm0, %ymm0
	vpand	%ymm3, %ymm10, %ymm7
	vpand	%ymm5, %ymm1, %ymm8
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm9, %ymm11, %ymm11
	vpand	%ymm3, %ymm6, %ymm3
	vpxor	%ymm3, %ymm11, %ymm3
	vpxor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm4, %ymm0, %ymm0
	vpor	%ymm10, %ymm2, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm7, %ymm1, %ymm1
	vpor	%ymm9, %ymm5, %ymm5
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm7, %ymm2
	vpxor	%ymm10, %ymm8, %ymm4
	vpunpcklqdq	%ymm0, %ymm3, %ymm7
	vpunpckhqdq	%ymm0, %ymm3, %ymm3
	vpunpcklqdq	%ymm2, %ymm1, %ymm12
	vpunpckhqdq	%ymm2, %ymm1, %ymm1
	vperm2i128	$32, %ymm12, %ymm7, %ymm6
	vperm2i128	$32, %ymm1, %ymm3, %ymm0
	vperm2i128	$49, %ymm12, %ymm7, %ymm9
	vperm2i128	$49, %ymm1, %ymm3, %ymm5
	vpermq	$0, %ymm4, %ymm7
	vpermq	$85, %ymm4, %ymm2
	vpermq	$170, %ymm4, %ymm10
	vpermq	$255, %ymm4, %ymm1
	vpxor	%ymm0, %ymm6, %ymm6
	vpxor	%ymm2, %ymm7, %ymm4
	vpxor	%ymm5, %ymm9, %ymm9
	vpxor	%ymm1, %ymm10, %ymm10
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm10, %ymm2, %ymm2
	vpermq	$144, %ymm6, %ymm7
	vpxor	%ymm4, %ymm7, %ymm3
	vpblendd	$48, %ymm3, %ymm7, %ymm3
	vpblendd	$3, %ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm5, %ymm5
	vpermq	$255, %ymm6, %ymm7
	vpxor	%ymm7, %ymm1, %ymm1
	vpermq	$255, %ymm0, %ymm3
	vpermq	$144, %ymm0, %ymm0
	vpxor	%ymm2, %ymm0, %ymm8
	vpblendd	$48, %ymm8, %ymm0, %ymm0
	vpblendd	$3, %ymm2, %ymm0, %ymm0
	vpermq	$144, %ymm5, %ymm2
	vpxor	%ymm1, %ymm2, %ymm7
	vpblendd	$48, %ymm7, %ymm2, %ymm7
	vpblendd	$3, %ymm1, %ymm7, %ymm8
	vpxor	%ymm8, %ymm9, %ymm9
	vpermq	$255, %ymm5, %ymm7
	vpxor	%ymm7, %ymm10, %ymm10
	vpxor	%ymm0, %ymm6, %ymm6
	vpxor	%ymm3, %ymm4, %ymm4
	vpxor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm9, %ymm0, %ymm7
	vpxor	%ymm10, %ymm3, %ymm0
	vpblendd	$12, %ymm0, %ymm4, %ymm0
	vpblendd	$48, %ymm10, %ymm0, %ymm2
	vpblendd	$192, %ymm1, %ymm2, %ymm0
	vpunpcklqdq	%ymm7, %ymm6, %ymm1
	vpunpckhqdq	%ymm7, %ymm6, %ymm7
	vpunpcklqdq	%ymm5, %ymm9, %ymm12
	vpunpckhqdq	%ymm5, %ymm9, %ymm5
	vperm2i128	$32, %ymm12, %ymm1, %ymm3
	vperm2i128	$32, %ymm5, %ymm7, %ymm4
	vperm2i128	$49, %ymm12, %ymm1, %ymm1
	vperm2i128	$49, %ymm5, %ymm7, %ymm10
	vpxor	%ymm4, %ymm3, %ymm8
	vpxor	%ymm0, %ymm1, %ymm5
	vpor	%ymm1, %ymm3, %ymm2
	vpxor	glob_data + 896(%rip), %ymm8, %ymm11
	vpxor	%ymm11, %ymm10, %ymm6
	vpand	%ymm0, %ymm4, %ymm7
	vpxor	%ymm5, %ymm7, %ymm12
	vpxor	%ymm0, %ymm3, %ymm9
	vpand	%ymm0, %ymm3, %ymm3
	vpand	%ymm5, %ymm10, %ymm7
	vpand	%ymm6, %ymm1, %ymm8
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm9, %ymm11, %ymm11
	vpand	%ymm5, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm0
	vpxor	%ymm8, %ymm0, %ymm0
	vpxor	%ymm2, %ymm3, %ymm3
	vpor	%ymm10, %ymm4, %ymm12
	vpxor	%ymm12, %ymm3, %ymm3
	vpxor	%ymm7, %ymm1, %ymm1
	vpor	%ymm9, %ymm6, %ymm6
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm4, %ymm7, %ymm5
	vpxor	%ymm10, %ymm8, %ymm7
	vpunpcklqdq	%ymm3, %ymm0, %ymm4
	vpunpckhqdq	%ymm3, %ymm0, %ymm0
	vpunpcklqdq	%ymm5, %ymm1, %ymm3
	vpunpckhqdq	%ymm5, %ymm1, %ymm5
	vperm2i128	$32, %ymm3, %ymm4, %ymm1
	vperm2i128	$32, %ymm5, %ymm0, %ymm12
	vperm2i128	$49, %ymm3, %ymm4, %ymm9
	vperm2i128	$49, %ymm5, %ymm0, %ymm6
	vpermq	$0, %ymm7, %ymm2
	vpermq	$85, %ymm7, %ymm0
	vpermq	$170, %ymm7, %ymm10
	vpermq	$255, %ymm7, %ymm3
	vpand	glob_data + 512(%rip), %ymm12, %ymm5
	vpsllq	$4, %ymm5, %ymm4
	vpand	glob_data + 480(%rip), %ymm12, %ymm7
	vpsrlq	$12, %ymm7, %ymm5
	vpor	%ymm5, %ymm4, %ymm4
	vpand	glob_data + 512(%rip), %ymm0, %ymm7
	vpsllq	$4, %ymm7, %ymm5
	vpand	glob_data + 480(%rip), %ymm0, %ymm0
	vpsrlq	$12, %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm0
	vpand	glob_data + 448(%rip), %ymm9, %ymm5
	vpsllq	$8, %ymm5, %ymm7
	vpand	glob_data + 416(%rip), %ymm9, %ymm9
	vpsrlq	$8, %ymm9, %ymm5
	vpor	%ymm5, %ymm7, %ymm7
	vpand	glob_data + 448(%rip), %ymm10, %ymm12
	vpsllq	$8, %ymm12, %ymm5
	vpand	glob_data + 416(%rip), %ymm10, %ymm10
	vpsrlq	$8, %ymm10, %ymm8
	vpor	%ymm8, %ymm5, %ymm5
	vpand	glob_data + 384(%rip), %ymm6, %ymm8
	vpsllq	$12, %ymm8, %ymm8
	vpand	glob_data + 352(%rip), %ymm6, %ymm6
	vpsrlq	$4, %ymm6, %ymm6
	vpor	%ymm6, %ymm8, %ymm8
	vpand	glob_data + 384(%rip), %ymm3, %ymm9
	vpsllq	$12, %ymm9, %ymm6
	vpand	glob_data + 352(%rip), %ymm3, %ymm3
	vpsrlq	$4, %ymm3, %ymm12
	vpor	%ymm12, %ymm6, %ymm3
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm8, %ymm7, %ymm7
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm5, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm10
	vpxor	%ymm2, %ymm10, %ymm6
	vpblendd	$48, %ymm6, %ymm10, %ymm6
	vpblendd	$3, %ymm2, %ymm6, %ymm6
	vpxor	%ymm6, %ymm8, %ymm8
	vpermq	$255, %ymm1, %ymm6
	vpxor	%ymm6, %ymm3, %ymm3
	vpermq	$255, %ymm4, %ymm9
	vpermq	$144, %ymm4, %ymm4
	vpxor	%ymm0, %ymm4, %ymm12
	vpblendd	$48, %ymm12, %ymm4, %ymm10
	vpblendd	$3, %ymm0, %ymm10, %ymm0
	vpermq	$144, %ymm8, %ymm4
	vpxor	%ymm3, %ymm4, %ymm6
	vpblendd	$48, %ymm6, %ymm4, %ymm6
	vpblendd	$3, %ymm3, %ymm6, %ymm4
	vpxor	%ymm4, %ymm7, %ymm7
	vpermq	$255, %ymm8, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm9, %ymm2, %ymm2
	vpxor	%ymm1, %ymm8, %ymm8
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm5, %ymm9, %ymm9
	vpand	glob_data + 384(%rip), %ymm0, %ymm4
	vpsllq	$12, %ymm4, %ymm6
	vpand	glob_data + 352(%rip), %ymm0, %ymm0
	vpsrlq	$4, %ymm0, %ymm10
	vpor	%ymm10, %ymm6, %ymm0
	vpand	glob_data + 384(%rip), %ymm9, %ymm4
	vpsllq	$12, %ymm4, %ymm6
	vpand	glob_data + 352(%rip), %ymm9, %ymm9
	vpsrlq	$4, %ymm9, %ymm11
	vpor	%ymm11, %ymm6, %ymm6
	vpand	glob_data + 448(%rip), %ymm7, %ymm4
	vpsllq	$8, %ymm4, %ymm4
	vpand	glob_data + 416(%rip), %ymm7, %ymm7
	vpsrlq	$8, %ymm7, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpand	glob_data + 448(%rip), %ymm5, %ymm7
	vpsllq	$8, %ymm7, %ymm10
	vpand	glob_data + 416(%rip), %ymm5, %ymm5
	vpsrlq	$8, %ymm5, %ymm7
	vpor	%ymm7, %ymm10, %ymm10
	vpand	glob_data + 512(%rip), %ymm8, %ymm9
	vpsllq	$4, %ymm9, %ymm5
	vpand	glob_data + 480(%rip), %ymm8, %ymm8
	vpsrlq	$12, %ymm8, %ymm7
	vpor	%ymm7, %ymm5, %ymm5
	vpand	glob_data + 512(%rip), %ymm3, %ymm7
	vpsllq	$4, %ymm7, %ymm7
	vpand	glob_data + 480(%rip), %ymm3, %ymm3
	vpsrlq	$12, %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm7
	vpxor	glob_data + 320(%rip), %ymm1, %ymm8
	vpblendd	$12, %ymm6, %ymm2, %ymm12
	vpblendd	$48, %ymm10, %ymm12, %ymm1
	vpblendd	$192, %ymm7, %ymm1, %ymm1
	vpunpcklqdq	%ymm0, %ymm8, %ymm6
	vpunpckhqdq	%ymm0, %ymm8, %ymm3
	vpunpcklqdq	%ymm5, %ymm4, %ymm7
	vpunpckhqdq	%ymm5, %ymm4, %ymm5
	vperm2i128	$32, %ymm7, %ymm6, %ymm0
	vperm2i128	$32, %ymm5, %ymm3, %ymm2
	vperm2i128	$49, %ymm7, %ymm6, %ymm6
	vperm2i128	$49, %ymm5, %ymm3, %ymm10
	vpxor	%ymm2, %ymm0, %ymm5
	vpxor	%ymm1, %ymm6, %ymm7
	vpor	%ymm6, %ymm0, %ymm4
	vpxor	glob_data + 896(%rip), %ymm5, %ymm12
	vpxor	%ymm12, %ymm10, %ymm3
	vpand	%ymm1, %ymm2, %ymm8
	vpxor	%ymm7, %ymm8, %ymm11
	vpxor	%ymm1, %ymm0, %ymm8
	vpand	%ymm1, %ymm0, %ymm0
	vpand	%ymm7, %ymm10, %ymm5
	vpand	%ymm3, %ymm6, %ymm9
	vpxor	%ymm11, %ymm10, %ymm10
	vpand	%ymm8, %ymm12, %ymm12
	vpand	%ymm7, %ymm1, %ymm1
	vpxor	%ymm1, %ymm12, %ymm7
	vpxor	%ymm9, %ymm7, %ymm7
	vpxor	%ymm4, %ymm0, %ymm0
	vpor	%ymm10, %ymm2, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm5, %ymm6, %ymm1
	vpor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm4, %ymm2, %ymm2
	vpxor	%ymm2, %ymm5, %ymm3
	vpxor	%ymm10, %ymm9, %ymm5
	vpunpcklqdq	%ymm0, %ymm7, %ymm4
	vpunpckhqdq	%ymm0, %ymm7, %ymm0
	vpunpcklqdq	%ymm3, %ymm1, %ymm6
	vpunpckhqdq	%ymm3, %ymm1, %ymm7
	vperm2i128	$32, %ymm6, %ymm4, %ymm9
	vperm2i128	$32, %ymm7, %ymm0, %ymm1
	vperm2i128	$49, %ymm6, %ymm4, %ymm3
	vperm2i128	$49, %ymm7, %ymm0, %ymm0
	vpermq	$0, %ymm5, %ymm4
	vpermq	$85, %ymm5, %ymm2
	vpermq	$170, %ymm5, %ymm10
	vpermq	$255, %ymm5, %ymm5
	vpxor	%ymm1, %ymm9, %ymm9
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm0, %ymm3, %ymm3
	vpxor	%ymm5, %ymm10, %ymm10
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm10, %ymm2, %ymm2
	vpermq	$144, %ymm9, %ymm6
	vpxor	%ymm4, %ymm6, %ymm7
	vpblendd	$48, %ymm7, %ymm6, %ymm6
	vpblendd	$3, %ymm4, %ymm6, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vpermq	$255, %ymm9, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vpermq	$255, %ymm1, %ymm6
	vpermq	$144, %ymm1, %ymm1
	vpxor	%ymm2, %ymm1, %ymm8
	vpblendd	$48, %ymm8, %ymm1, %ymm7
	vpblendd	$3, %ymm2, %ymm7, %ymm1
	vpermq	$144, %ymm0, %ymm8
	vpxor	%ymm5, %ymm8, %ymm7
	vpblendd	$48, %ymm7, %ymm8, %ymm7
	vpblendd	$3, %ymm5, %ymm7, %ymm2
	vpxor	%ymm2, %ymm3, %ymm3
	vpermq	$255, %ymm0, %ymm7
	vpxor	%ymm7, %ymm10, %ymm10
	vpxor	%ymm1, %ymm9, %ymm9
	vpxor	%ymm6, %ymm4, %ymm4
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm4, %ymm5, %ymm5
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm10, %ymm6, %ymm6
	vpblendd	$12, %ymm6, %ymm4, %ymm6
	vpblendd	$48, %ymm10, %ymm6, %ymm2
	vpblendd	$192, %ymm5, %ymm2, %ymm7
	vpunpcklqdq	%ymm1, %ymm9, %ymm5
	vpunpckhqdq	%ymm1, %ymm9, %ymm6
	vpunpcklqdq	%ymm0, %ymm3, %ymm8
	vpunpckhqdq	%ymm0, %ymm3, %ymm2
	vperm2i128	$32, %ymm8, %ymm5, %ymm1
	vperm2i128	$32, %ymm2, %ymm6, %ymm4
	vperm2i128	$49, %ymm8, %ymm5, %ymm0
	vperm2i128	$49, %ymm2, %ymm6, %ymm10
	vpxor	%ymm4, %ymm1, %ymm6
	vpxor	%ymm7, %ymm0, %ymm5
	vpor	%ymm0, %ymm1, %ymm2
	vpxor	glob_data + 896(%rip), %ymm6, %ymm11
	vpxor	%ymm11, %ymm10, %ymm9
	vpand	%ymm7, %ymm4, %ymm3
	vpxor	%ymm5, %ymm3, %ymm12
	vpxor	%ymm7, %ymm1, %ymm3
	vpand	%ymm7, %ymm1, %ymm1
	vpand	%ymm5, %ymm10, %ymm6
	vpand	%ymm9, %ymm0, %ymm8
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm3, %ymm11, %ymm11
	vpand	%ymm5, %ymm7, %ymm7
	vpxor	%ymm7, %ymm11, %ymm5
	vpxor	%ymm8, %ymm5, %ymm5
	vpxor	%ymm2, %ymm1, %ymm1
	vpor	%ymm10, %ymm4, %ymm7
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm6, %ymm0, %ymm0
	vpor	%ymm3, %ymm9, %ymm9
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm4, %ymm6, %ymm3
	vpxor	%ymm10, %ymm8, %ymm6
	vpunpcklqdq	%ymm1, %ymm5, %ymm4
	vpunpckhqdq	%ymm1, %ymm5, %ymm1
	vpunpcklqdq	%ymm3, %ymm0, %ymm7
	vpunpckhqdq	%ymm3, %ymm0, %ymm5
	vperm2i128	$32, %ymm7, %ymm4, %ymm0
	vperm2i128	$32, %ymm5, %ymm1, %ymm8
	vperm2i128	$49, %ymm7, %ymm4, %ymm4
	vperm2i128	$49, %ymm5, %ymm1, %ymm9
	vpermq	$0, %ymm6, %ymm2
	vpermq	$85, %ymm6, %ymm7
	vpermq	$170, %ymm6, %ymm10
	vpermq	$255, %ymm6, %ymm5
	vpshufb	glob_data + 0(%rip), %ymm8, %ymm1
	vpshufb	glob_data + 0(%rip), %ymm7, %ymm3
	vpshufb	glob_data + 32(%rip), %ymm4, %ymm8
	vpshufb	glob_data + 32(%rip), %ymm10, %ymm4
	vpshufb	glob_data + 64(%rip), %ymm9, %ymm6
	vpshufb	glob_data + 64(%rip), %ymm5, %ymm7
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm6, %ymm8, %ymm5
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm4, %ymm3, %ymm3
	vpermq	$144, %ymm0, %ymm8
	vpxor	%ymm2, %ymm8, %ymm11
	vpblendd	$48, %ymm11, %ymm8, %ymm8
	vpblendd	$3, %ymm2, %ymm8, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vpermq	$255, %ymm0, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vpermq	$255, %ymm1, %ymm10
	vpermq	$144, %ymm1, %ymm1
	vpxor	%ymm3, %ymm1, %ymm8
	vpblendd	$48, %ymm8, %ymm1, %ymm8
	vpblendd	$3, %ymm3, %ymm8, %ymm1
	vpermq	$144, %ymm6, %ymm8
	vpxor	%ymm7, %ymm8, %ymm3
	vpblendd	$48, %ymm3, %ymm8, %ymm3
	vpblendd	$3, %ymm7, %ymm3, %ymm12
	vpxor	%ymm12, %ymm5, %ymm3
	vpermq	$255, %ymm6, %ymm9
	vpxor	%ymm9, %ymm4, %ymm4
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm0, %ymm6, %ymm6
	vpxor	%ymm2, %ymm7, %ymm8
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm4, %ymm10, %ymm10
	vpshufb	glob_data + 64(%rip), %ymm1, %ymm5
	vpshufb	glob_data + 64(%rip), %ymm10, %ymm1
	vpshufb	glob_data + 32(%rip), %ymm3, %ymm7
	vpshufb	glob_data + 32(%rip), %ymm4, %ymm4
	vpshufb	glob_data + 0(%rip), %ymm6, %ymm3
	vpshufb	glob_data + 0(%rip), %ymm8, %ymm8
	vpxor	glob_data + 288(%rip), %ymm0, %ymm6
	vpblendd	$12, %ymm1, %ymm2, %ymm0
	vpblendd	$48, %ymm4, %ymm0, %ymm0
	vpblendd	$192, %ymm8, %ymm0, %ymm0
	vpunpcklqdq	%ymm5, %ymm6, %ymm10
	vpunpckhqdq	%ymm5, %ymm6, %ymm5
	vpunpcklqdq	%ymm3, %ymm7, %ymm4
	vpunpckhqdq	%ymm3, %ymm7, %ymm6
	vperm2i128	$32, %ymm4, %ymm10, %ymm1
	vperm2i128	$32, %ymm6, %ymm5, %ymm2
	vperm2i128	$49, %ymm4, %ymm10, %ymm3
	vperm2i128	$49, %ymm6, %ymm5, %ymm8
	vpxor	%ymm2, %ymm1, %ymm7
	vpxor	%ymm0, %ymm3, %ymm4
	vpor	%ymm3, %ymm1, %ymm9
	vpxor	glob_data + 896(%rip), %ymm7, %ymm12
	vpxor	%ymm12, %ymm8, %ymm5
	vpand	%ymm0, %ymm2, %ymm6
	vpxor	%ymm4, %ymm6, %ymm11
	vpxor	%ymm0, %ymm1, %ymm7
	vpand	%ymm0, %ymm1, %ymm1
	vpand	%ymm4, %ymm8, %ymm6
	vpand	%ymm5, %ymm3, %ymm10
	vpxor	%ymm11, %ymm8, %ymm8
	vpand	%ymm7, %ymm12, %ymm12
	vpand	%ymm4, %ymm0, %ymm0
	vpxor	%ymm0, %ymm12, %ymm0
	vpxor	%ymm10, %ymm0, %ymm0
	vpxor	%ymm9, %ymm1, %ymm1
	vpor	%ymm8, %ymm2, %ymm4
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm6, %ymm3, %ymm3
	vpor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm9, %ymm2, %ymm2
	vpxor	%ymm2, %ymm6, %ymm4
	vpxor	%ymm8, %ymm10, %ymm10
	vpunpcklqdq	%ymm1, %ymm0, %ymm5
	vpunpckhqdq	%ymm1, %ymm0, %ymm0
	vpunpcklqdq	%ymm4, %ymm3, %ymm6
	vpunpckhqdq	%ymm4, %ymm3, %ymm3
	vperm2i128	$32, %ymm6, %ymm5, %ymm8
	vperm2i128	$32, %ymm3, %ymm0, %ymm1
	vperm2i128	$49, %ymm6, %ymm5, %ymm5
	vperm2i128	$49, %ymm3, %ymm0, %ymm0
	vpermq	$0, %ymm10, %ymm9
	vpermq	$85, %ymm10, %ymm2
	vpermq	$170, %ymm10, %ymm4
	vpermq	$255, %ymm10, %ymm7
	vpxor	%ymm1, %ymm8, %ymm3
	vpxor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm0, %ymm5, %ymm5
	vpxor	%ymm7, %ymm4, %ymm8
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm8, %ymm2, %ymm2
	vpermq	$144, %ymm3, %ymm11
	vpxor	%ymm9, %ymm11, %ymm6
	vpblendd	$48, %ymm6, %ymm11, %ymm4
	vpblendd	$3, %ymm9, %ymm4, %ymm6
	vpxor	%ymm6, %ymm0, %ymm0
	vpermq	$255, %ymm3, %ymm4
	vpxor	%ymm4, %ymm7, %ymm7
	vpermq	$255, %ymm1, %ymm6
	vpermq	$144, %ymm1, %ymm1
	vpxor	%ymm2, %ymm1, %ymm10
	vpblendd	$48, %ymm10, %ymm1, %ymm1
	vpblendd	$3, %ymm2, %ymm1, %ymm1
	vpermq	$144, %ymm0, %ymm4
	vpxor	%ymm7, %ymm4, %ymm10
	vpblendd	$48, %ymm10, %ymm4, %ymm4
	vpblendd	$3, %ymm7, %ymm4, %ymm4
	vpxor	%ymm4, %ymm5, %ymm5
	vpermq	$255, %ymm0, %ymm4
	vpxor	%ymm4, %ymm8, %ymm4
	vpxor	%ymm1, %ymm3, %ymm3
	vpxor	%ymm6, %ymm9, %ymm9
	vpxor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm9, %ymm7, %ymm7
	vpxor	%ymm5, %ymm1, %ymm12
	vpxor	%ymm4, %ymm6, %ymm1
	vpblendd	$12, %ymm1, %ymm9, %ymm1
	vpblendd	$48, %ymm4, %ymm1, %ymm2
	vpblendd	$192, %ymm7, %ymm2, %ymm1
	vpunpcklqdq	%ymm12, %ymm3, %ymm4
	vpunpckhqdq	%ymm12, %ymm3, %ymm3
	vpunpcklqdq	%ymm0, %ymm5, %ymm6
	vpunpckhqdq	%ymm0, %ymm5, %ymm5
	vperm2i128	$32, %ymm6, %ymm4, %ymm0
	vperm2i128	$32, %ymm5, %ymm3, %ymm9
	vperm2i128	$49, %ymm6, %ymm4, %ymm6
	vperm2i128	$49, %ymm5, %ymm3, %ymm10
	vpxor	%ymm9, %ymm0, %ymm3
	vpxor	%ymm1, %ymm6, %ymm7
	vpor	%ymm6, %ymm0, %ymm2
	vpxor	glob_data + 896(%rip), %ymm3, %ymm11
	vpxor	%ymm11, %ymm10, %ymm3
	vpand	%ymm1, %ymm9, %ymm5
	vpxor	%ymm7, %ymm5, %ymm12
	vpxor	%ymm1, %ymm0, %ymm5
	vpand	%ymm1, %ymm0, %ymm0
	vpand	%ymm7, %ymm10, %ymm8
	vpand	%ymm3, %ymm6, %ymm4
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm5, %ymm11, %ymm11
	vpand	%ymm7, %ymm1, %ymm1
	vpxor	%ymm1, %ymm11, %ymm1
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm2, %ymm0, %ymm0
	vpor	%ymm10, %ymm9, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm8, %ymm6, %ymm6
	vpor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm3, %ymm6, %ymm3
	vpxor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm8, %ymm5
	vpxor	%ymm10, %ymm4, %ymm4
	vpunpcklqdq	%ymm0, %ymm1, %ymm6
	vpunpckhqdq	%ymm0, %ymm1, %ymm0
	vpunpcklqdq	%ymm5, %ymm3, %ymm7
	vpunpckhqdq	%ymm5, %ymm3, %ymm12
	vperm2i128	$32, %ymm7, %ymm6, %ymm1
	vperm2i128	$32, %ymm12, %ymm0, %ymm11
	vperm2i128	$49, %ymm7, %ymm6, %ymm5
	vperm2i128	$49, %ymm12, %ymm0, %ymm3
	vpermq	$0, %ymm4, %ymm2
	vpermq	$85, %ymm4, %ymm0
	vpermq	$170, %ymm4, %ymm8
	vpermq	$255, %ymm4, %ymm10
	vpand	glob_data + 736(%rip), %ymm11, %ymm4
	vpsllq	$1, %ymm4, %ymm6
	vpand	glob_data + 704(%rip), %ymm11, %ymm4
	vpsrlq	$3, %ymm4, %ymm9
	vpor	%ymm9, %ymm6, %ymm6
	vpand	glob_data + 736(%rip), %ymm0, %ymm7
	vpsllq	$1, %ymm7, %ymm7
	vpand	glob_data + 704(%rip), %ymm0, %ymm0
	vpsrlq	$3, %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm0
	vpand	glob_data + 672(%rip), %ymm5, %ymm4
	vpsllq	$2, %ymm4, %ymm4
	vpand	glob_data + 640(%rip), %ymm5, %ymm5
	vpsrlq	$2, %ymm5, %ymm11
	vpor	%ymm11, %ymm4, %ymm4
	vpand	glob_data + 672(%rip), %ymm8, %ymm7
	vpsllq	$2, %ymm7, %ymm5
	vpand	glob_data + 640(%rip), %ymm8, %ymm7
	vpsrlq	$2, %ymm7, %ymm7
	vpor	%ymm7, %ymm5, %ymm5
	vpand	glob_data + 608(%rip), %ymm3, %ymm9
	vpsllq	$3, %ymm9, %ymm7
	vpand	glob_data + 576(%rip), %ymm3, %ymm3
	vpsrlq	$1, %ymm3, %ymm12
	vpor	%ymm12, %ymm7, %ymm3
	vpand	glob_data + 608(%rip), %ymm10, %ymm7
	vpsllq	$3, %ymm7, %ymm8
	vpand	glob_data + 576(%rip), %ymm10, %ymm10
	vpsrlq	$1, %ymm10, %ymm7
	vpor	%ymm7, %ymm8, %ymm8
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm3, %ymm4, %ymm4
	vpxor	%ymm8, %ymm5, %ymm5
	vpxor	%ymm4, %ymm6, %ymm6
	vpxor	%ymm5, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm7
	vpxor	%ymm2, %ymm7, %ymm9
	vpblendd	$48, %ymm9, %ymm7, %ymm9
	vpblendd	$3, %ymm2, %ymm9, %ymm11
	vpxor	%ymm11, %ymm3, %ymm3
	vpermq	$255, %ymm1, %ymm7
	vpxor	%ymm7, %ymm8, %ymm8
	vpermq	$255, %ymm6, %ymm7
	vpermq	$144, %ymm6, %ymm10
	vpxor	%ymm0, %ymm10, %ymm6
	vpblendd	$48, %ymm6, %ymm10, %ymm6
	vpblendd	$3, %ymm0, %ymm6, %ymm0
	vpermq	$144, %ymm3, %ymm9
	vpxor	%ymm8, %ymm9, %ymm6
	vpblendd	$48, %ymm6, %ymm9, %ymm12
	vpblendd	$3, %ymm8, %ymm12, %ymm6
	vpxor	%ymm6, %ymm4, %ymm4
	vpermq	$255, %ymm3, %ymm10
	vpxor	%ymm10, %ymm5, %ymm5
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm1, %ymm3, %ymm3
	vpxor	%ymm2, %ymm8, %ymm8
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm5, %ymm7, %ymm7
	vpand	glob_data + 608(%rip), %ymm0, %ymm6
	vpsllq	$3, %ymm6, %ymm6
	vpand	glob_data + 576(%rip), %ymm0, %ymm0
	vpsrlq	$1, %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm0
	vpand	glob_data + 608(%rip), %ymm7, %ymm9
	vpsllq	$3, %ymm9, %ymm6
	vpand	glob_data + 576(%rip), %ymm7, %ymm7
	vpsrlq	$1, %ymm7, %ymm7
	vpor	%ymm7, %ymm6, %ymm6
	vpand	glob_data + 672(%rip), %ymm4, %ymm7
	vpsllq	$2, %ymm7, %ymm10
	vpand	glob_data + 640(%rip), %ymm4, %ymm4
	vpsrlq	$2, %ymm4, %ymm4
	vpor	%ymm4, %ymm10, %ymm10
	vpand	glob_data + 672(%rip), %ymm5, %ymm7
	vpsllq	$2, %ymm7, %ymm4
	vpand	glob_data + 640(%rip), %ymm5, %ymm5
	vpsrlq	$2, %ymm5, %ymm9
	vpor	%ymm9, %ymm4, %ymm4
	vpand	glob_data + 736(%rip), %ymm3, %ymm5
	vpsllq	$1, %ymm5, %ymm7
	vpand	glob_data + 704(%rip), %ymm3, %ymm3
	vpsrlq	$3, %ymm3, %ymm3
	vpor	%ymm3, %ymm7, %ymm7
	vpand	glob_data + 736(%rip), %ymm8, %ymm3
	vpsllq	$1, %ymm3, %ymm3
	vpand	glob_data + 704(%rip), %ymm8, %ymm8
	vpsrlq	$3, %ymm8, %ymm5
	vpor	%ymm5, %ymm3, %ymm3
	vpxor	glob_data + 256(%rip), %ymm1, %ymm1
	vpblendd	$12, %ymm6, %ymm2, %ymm5
	vpblendd	$48, %ymm4, %ymm5, %ymm9
	vpblendd	$192, %ymm3, %ymm9, %ymm5
	vpunpcklqdq	%ymm0, %ymm1, %ymm3
	vpunpckhqdq	%ymm0, %ymm1, %ymm6
	vpunpcklqdq	%ymm7, %ymm10, %ymm1
	vpunpckhqdq	%ymm7, %ymm10, %ymm4
	vperm2i128	$32, %ymm1, %ymm3, %ymm0
	vperm2i128	$32, %ymm4, %ymm6, %ymm2
	vperm2i128	$49, %ymm1, %ymm3, %ymm1
	vperm2i128	$49, %ymm4, %ymm6, %ymm8
	vpxor	%ymm2, %ymm0, %ymm6
	vpxor	%ymm5, %ymm1, %ymm7
	vpor	%ymm1, %ymm0, %ymm9
	vpxor	glob_data + 896(%rip), %ymm6, %ymm11
	vpxor	%ymm11, %ymm8, %ymm3
	vpand	%ymm5, %ymm2, %ymm4
	vpxor	%ymm7, %ymm4, %ymm12
	vpxor	%ymm5, %ymm0, %ymm10
	vpand	%ymm5, %ymm0, %ymm0
	vpand	%ymm7, %ymm8, %ymm4
	vpand	%ymm3, %ymm1, %ymm6
	vpxor	%ymm12, %ymm8, %ymm8
	vpand	%ymm10, %ymm11, %ymm11
	vpand	%ymm7, %ymm5, %ymm5
	vpxor	%ymm5, %ymm11, %ymm5
	vpxor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm9, %ymm0, %ymm0
	vpor	%ymm8, %ymm2, %ymm7
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm4, %ymm1, %ymm1
	vpor	%ymm10, %ymm3, %ymm3
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm9, %ymm2, %ymm2
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm8, %ymm6, %ymm3
	vpunpcklqdq	%ymm0, %ymm5, %ymm6
	vpunpckhqdq	%ymm0, %ymm5, %ymm0
	vpunpcklqdq	%ymm4, %ymm1, %ymm2
	vpunpckhqdq	%ymm4, %ymm1, %ymm7
	vperm2i128	$32, %ymm2, %ymm6, %ymm8
	vperm2i128	$32, %ymm7, %ymm0, %ymm4
	vperm2i128	$49, %ymm2, %ymm6, %ymm10
	vperm2i128	$49, %ymm7, %ymm0, %ymm0
	vpermq	$0, %ymm3, %ymm1
	vpermq	$85, %ymm3, %ymm2
	vpermq	$170, %ymm3, %ymm6
	vpermq	$255, %ymm3, %ymm5
	vpxor	%ymm4, %ymm8, %ymm7
	vpxor	%ymm2, %ymm1, %ymm1
	vpxor	%ymm0, %ymm10, %ymm10
	vpxor	%ymm5, %ymm6, %ymm8
	vpxor	%ymm10, %ymm4, %ymm4
	vpxor	%ymm8, %ymm2, %ymm2
	vpermq	$144, %ymm7, %ymm3
	vpxor	%ymm1, %ymm3, %ymm6
	vpblendd	$48, %ymm6, %ymm3, %ymm12
	vpblendd	$3, %ymm1, %ymm12, %ymm3
	vpxor	%ymm3, %ymm0, %ymm0
	vpermq	$255, %ymm7, %ymm3
	vpxor	%ymm3, %ymm5, %ymm5
	vpermq	$255, %ymm4, %ymm3
	vpermq	$144, %ymm4, %ymm4
	vpxor	%ymm2, %ymm4, %ymm6
	vpblendd	$48, %ymm6, %ymm4, %ymm6
	vpblendd	$3, %ymm2, %ymm6, %ymm6
	vpermq	$144, %ymm0, %ymm4
	vpxor	%ymm5, %ymm4, %ymm12
	vpblendd	$48, %ymm12, %ymm4, %ymm2
	vpblendd	$3, %ymm5, %ymm2, %ymm4
	vpxor	%ymm4, %ymm10, %ymm10
	vpermq	$255, %ymm0, %ymm4
	vpxor	%ymm4, %ymm8, %ymm4
	vpxor	%ymm6, %ymm7, %ymm7
	vpxor	%ymm3, %ymm1, %ymm1
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm10, %ymm6, %ymm6
	vpxor	%ymm4, %ymm3, %ymm3
	vpblendd	$12, %ymm3, %ymm1, %ymm1
	vpblendd	$48, %ymm4, %ymm1, %ymm2
	vpblendd	$192, %ymm5, %ymm2, %ymm1
	vpunpcklqdq	%ymm6, %ymm7, %ymm4
	vpunpckhqdq	%ymm6, %ymm7, %ymm6
	vpunpcklqdq	%ymm0, %ymm10, %ymm2
	vpunpckhqdq	%ymm0, %ymm10, %ymm7
	vperm2i128	$32, %ymm2, %ymm4, %ymm0
	vperm2i128	$32, %ymm7, %ymm6, %ymm9
	vperm2i128	$49, %ymm2, %ymm4, %ymm3
	vperm2i128	$49, %ymm7, %ymm6, %ymm8
	vpxor	%ymm9, %ymm0, %ymm4
	vpxor	%ymm1, %ymm3, %ymm5
	vpor	%ymm3, %ymm0, %ymm2
	vpxor	glob_data + 896(%rip), %ymm4, %ymm11
	vpxor	%ymm11, %ymm8, %ymm7
	vpand	%ymm1, %ymm9, %ymm6
	vpxor	%ymm5, %ymm6, %ymm12
	vpxor	%ymm1, %ymm0, %ymm10
	vpand	%ymm1, %ymm0, %ymm0
	vpand	%ymm5, %ymm8, %ymm6
	vpand	%ymm7, %ymm3, %ymm4
	vpxor	%ymm12, %ymm8, %ymm8
	vpand	%ymm10, %ymm11, %ymm11
	vpand	%ymm5, %ymm1, %ymm1
	vpxor	%ymm1, %ymm11, %ymm1
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm2, %ymm0, %ymm0
	vpor	%ymm8, %ymm9, %ymm11
	vpxor	%ymm11, %ymm0, %ymm0
	vpxor	%ymm6, %ymm3, %ymm3
	vpor	%ymm10, %ymm7, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm6, %ymm5
	vpxor	%ymm8, %ymm4, %ymm7
	vpunpcklqdq	%ymm0, %ymm1, %ymm6
	vpunpckhqdq	%ymm0, %ymm1, %ymm0
	vpunpcklqdq	%ymm5, %ymm3, %ymm8
	vpunpckhqdq	%ymm5, %ymm3, %ymm5
	vperm2i128	$32, %ymm8, %ymm6, %ymm1
	vperm2i128	$32, %ymm5, %ymm0, %ymm9
	vperm2i128	$49, %ymm8, %ymm6, %ymm10
	vperm2i128	$49, %ymm5, %ymm0, %ymm5
	vpermq	$0, %ymm7, %ymm2
	vpermq	$85, %ymm7, %ymm0
	vpermq	$170, %ymm7, %ymm4
	vpermq	$255, %ymm7, %ymm3
	vpand	glob_data + 512(%rip), %ymm9, %ymm6
	vpsllq	$4, %ymm6, %ymm8
	vpand	glob_data + 480(%rip), %ymm9, %ymm7
	vpsrlq	$12, %ymm7, %ymm6
	vpor	%ymm6, %ymm8, %ymm8
	vpand	glob_data + 512(%rip), %ymm0, %ymm6
	vpsllq	$4, %ymm6, %ymm6
	vpand	glob_data + 480(%rip), %ymm0, %ymm0
	vpsrlq	$12, %ymm0, %ymm0
	vpor	%ymm0, %ymm6, %ymm0
	vpand	glob_data + 448(%rip), %ymm10, %ymm6
	vpsllq	$8, %ymm6, %ymm7
	vpand	glob_data + 416(%rip), %ymm10, %ymm10
	vpsrlq	$8, %ymm10, %ymm6
	vpor	%ymm6, %ymm7, %ymm7
	vpand	glob_data + 448(%rip), %ymm4, %ymm9
	vpsllq	$8, %ymm9, %ymm6
	vpand	glob_data + 416(%rip), %ymm4, %ymm4
	vpsrlq	$8, %ymm4, %ymm12
	vpor	%ymm12, %ymm6, %ymm6
	vpand	glob_data + 384(%rip), %ymm5, %ymm9
	vpsllq	$12, %ymm9, %ymm4
	vpand	glob_data + 352(%rip), %ymm5, %ymm5
	vpsrlq	$4, %ymm5, %ymm5
	vpor	%ymm5, %ymm4, %ymm4
	vpand	glob_data + 384(%rip), %ymm3, %ymm10
	vpsllq	$12, %ymm10, %ymm11
	vpand	glob_data + 352(%rip), %ymm3, %ymm3
	vpsrlq	$4, %ymm3, %ymm3
	vpor	%ymm3, %ymm11, %ymm3
	vpxor	%ymm8, %ymm1, %ymm1
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm4, %ymm7, %ymm7
	vpxor	%ymm3, %ymm6, %ymm6
	vpxor	%ymm7, %ymm8, %ymm8
	vpxor	%ymm6, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm10
	vpxor	%ymm2, %ymm10, %ymm12
	vpblendd	$48, %ymm12, %ymm10, %ymm9
	vpblendd	$3, %ymm2, %ymm9, %ymm5
	vpxor	%ymm5, %ymm4, %ymm4
	vpermq	$255, %ymm1, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vpermq	$255, %ymm8, %ymm10
	vpermq	$144, %ymm8, %ymm5
	vpxor	%ymm0, %ymm5, %ymm8
	vpblendd	$48, %ymm8, %ymm5, %ymm8
	vpblendd	$3, %ymm0, %ymm8, %ymm0
	vpermq	$144, %ymm4, %ymm9
	vpxor	%ymm3, %ymm9, %ymm5
	vpblendd	$48, %ymm5, %ymm9, %ymm5
	vpblendd	$3, %ymm3, %ymm5, %ymm8
	vpxor	%ymm8, %ymm7, %ymm7
	vpermq	$255, %ymm4, %ymm5
	vpxor	%ymm5, %ymm6, %ymm6
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm6, %ymm10, %ymm10
	vpand	glob_data + 384(%rip), %ymm0, %ymm8
	vpsllq	$12, %ymm8, %ymm5
	vpand	glob_data + 352(%rip), %ymm0, %ymm0
	vpsrlq	$4, %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm0
	vpand	glob_data + 384(%rip), %ymm10, %ymm9
	vpsllq	$12, %ymm9, %ymm5
	vpand	glob_data + 352(%rip), %ymm10, %ymm10
	vpsrlq	$4, %ymm10, %ymm8
	vpor	%ymm8, %ymm5, %ymm5
	vpand	glob_data + 448(%rip), %ymm7, %ymm8
	vpsllq	$8, %ymm8, %ymm11
	vpand	glob_data + 416(%rip), %ymm7, %ymm7
	vpsrlq	$8, %ymm7, %ymm7
	vpor	%ymm7, %ymm11, %ymm7
	vpand	glob_data + 448(%rip), %ymm6, %ymm12
	vpsllq	$8, %ymm12, %ymm8
	vpand	glob_data + 416(%rip), %ymm6, %ymm6
	vpsrlq	$8, %ymm6, %ymm9
	vpor	%ymm9, %ymm8, %ymm8
	vpand	glob_data + 512(%rip), %ymm4, %ymm10
	vpsllq	$4, %ymm10, %ymm6
	vpand	glob_data + 480(%rip), %ymm4, %ymm4
	vpsrlq	$12, %ymm4, %ymm4
	vpor	%ymm4, %ymm6, %ymm9
	vpand	glob_data + 512(%rip), %ymm3, %ymm4
	vpsllq	$4, %ymm4, %ymm4
	vpand	glob_data + 480(%rip), %ymm3, %ymm3
	vpsrlq	$12, %ymm3, %ymm3
	vpor	%ymm3, %ymm4, %ymm3
	vpxor	glob_data + 224(%rip), %ymm1, %ymm6
	vpblendd	$12, %ymm5, %ymm2, %ymm1
	vpblendd	$48, %ymm8, %ymm1, %ymm1
	vpblendd	$192, %ymm3, %ymm1, %ymm1
	vpunpcklqdq	%ymm0, %ymm6, %ymm3
	vpunpckhqdq	%ymm0, %ymm6, %ymm4
	vpunpcklqdq	%ymm9, %ymm7, %ymm12
	vpunpckhqdq	%ymm9, %ymm7, %ymm6
	vperm2i128	$32, %ymm12, %ymm3, %ymm0
	vperm2i128	$32, %ymm6, %ymm4, %ymm2
	vperm2i128	$49, %ymm12, %ymm3, %ymm5
	vperm2i128	$49, %ymm6, %ymm4, %ymm10
	vpxor	%ymm2, %ymm0, %ymm6
	vpxor	%ymm1, %ymm5, %ymm3
	vpor	%ymm5, %ymm0, %ymm9
	vpxor	glob_data + 896(%rip), %ymm6, %ymm12
	vpxor	%ymm12, %ymm10, %ymm6
	vpand	%ymm1, %ymm2, %ymm7
	vpxor	%ymm3, %ymm7, %ymm11
	vpxor	%ymm1, %ymm0, %ymm4
	vpand	%ymm1, %ymm0, %ymm0
	vpand	%ymm3, %ymm10, %ymm8
	vpand	%ymm6, %ymm5, %ymm7
	vpxor	%ymm11, %ymm10, %ymm10
	vpand	%ymm4, %ymm12, %ymm12
	vpand	%ymm3, %ymm1, %ymm1
	vpxor	%ymm1, %ymm12, %ymm1
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm9, %ymm0, %ymm0
	vpor	%ymm10, %ymm2, %ymm12
	vpxor	%ymm12, %ymm0, %ymm0
	vpxor	%ymm8, %ymm5, %ymm5
	vpor	%ymm4, %ymm6, %ymm3
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm9, %ymm2, %ymm2
	vpxor	%ymm2, %ymm8, %ymm6
	vpxor	%ymm10, %ymm7, %ymm3
	vpunpcklqdq	%ymm0, %ymm1, %ymm4
	vpunpckhqdq	%ymm0, %ymm1, %ymm7
	vpunpcklqdq	%ymm6, %ymm5, %ymm1
	vpunpckhqdq	%ymm6, %ymm5, %ymm2
	vperm2i128	$32, %ymm1, %ymm4, %ymm10
	vperm2i128	$32, %ymm2, %ymm7, %ymm0
	vperm2i128	$49, %ymm1, %ymm4, %ymm4
	vperm2i128	$49, %ymm2, %ymm7, %ymm1
	vpermq	$0, %ymm3, %ymm9
	vpermq	$85, %ymm3, %ymm2
	vpermq	$170, %ymm3, %ymm6
	vpermq	$255, %ymm3, %ymm3
	vpxor	%ymm0, %ymm10, %ymm10
	vpxor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm1, %ymm4, %ymm4
	vpxor	%ymm3, %ymm6, %ymm8
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm8, %ymm2, %ymm2
	vpermq	$144, %ymm10, %ymm6
	vpxor	%ymm9, %ymm6, %ymm5
	vpblendd	$48, %ymm5, %ymm6, %ymm5
	vpblendd	$3, %ymm9, %ymm5, %ymm11
	vpxor	%ymm11, %ymm1, %ymm1
	vpermq	$255, %ymm10, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vpermq	$255, %ymm0, %ymm7
	vpermq	$144, %ymm0, %ymm0
	vpxor	%ymm2, %ymm0, %ymm6
	vpblendd	$48, %ymm6, %ymm0, %ymm0
	vpblendd	$3, %ymm2, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm5
	vpxor	%ymm3, %ymm5, %ymm11
	vpblendd	$48, %ymm11, %ymm5, %ymm5
	vpblendd	$3, %ymm3, %ymm5, %ymm12
	vpxor	%ymm12, %ymm4, %ymm4
	vpermq	$255, %ymm1, %ymm2
	vpxor	%ymm2, %ymm8, %ymm6
	vpxor	%ymm0, %ymm10, %ymm10
	vpxor	%ymm7, %ymm9, %ymm9
	vpxor	%ymm10, %ymm1, %ymm1
	vpxor	%ymm9, %ymm3, %ymm3
	vpxor	%ymm4, %ymm0, %ymm5
	vpxor	%ymm6, %ymm7, %ymm0
	vpblendd	$12, %ymm0, %ymm9, %ymm0
	vpblendd	$48, %ymm6, %ymm0, %ymm2
	vpblendd	$192, %ymm3, %ymm2, %ymm0
	vpunpcklqdq	%ymm5, %ymm10, %ymm6
	vpunpckhqdq	%ymm5, %ymm10, %ymm8
	vpunpcklqdq	%ymm1, %ymm4, %ymm3
	vpunpckhqdq	%ymm1, %ymm4, %ymm4
	vperm2i128	$32, %ymm3, %ymm6, %ymm1
	vperm2i128	$32, %ymm4, %ymm8, %ymm9
	vperm2i128	$49, %ymm3, %ymm6, %ymm3
	vperm2i128	$49, %ymm4, %ymm8, %ymm7
	vpxor	%ymm9, %ymm1, %ymm4
	vpxor	%ymm0, %ymm3, %ymm6
	vpor	%ymm3, %ymm1, %ymm2
	vpxor	glob_data + 896(%rip), %ymm4, %ymm11
	vpxor	%ymm11, %ymm7, %ymm10
	vpand	%ymm0, %ymm9, %ymm5
	vpxor	%ymm6, %ymm5, %ymm12
	vpxor	%ymm0, %ymm1, %ymm4
	vpand	%ymm0, %ymm1, %ymm1
	vpand	%ymm6, %ymm7, %ymm5
	vpand	%ymm10, %ymm3, %ymm8
	vpxor	%ymm12, %ymm7, %ymm7
	vpand	%ymm4, %ymm11, %ymm11
	vpand	%ymm6, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm0
	vpxor	%ymm8, %ymm0, %ymm6
	vpxor	%ymm2, %ymm1, %ymm0
	vpor	%ymm7, %ymm9, %ymm1
	vpxor	%ymm1, %ymm0, %ymm1
	vpxor	%ymm5, %ymm3, %ymm0
	vpor	%ymm4, %ymm10, %ymm3
	vpxor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm9, %ymm5, %ymm3
	vpxor	%ymm7, %ymm8, %ymm5
	vpunpcklqdq	%ymm1, %ymm6, %ymm4
	vpunpckhqdq	%ymm1, %ymm6, %ymm1
	vpunpcklqdq	%ymm3, %ymm0, %ymm7
	vpunpckhqdq	%ymm3, %ymm0, %ymm3
	vperm2i128	$32, %ymm7, %ymm4, %ymm0
	vperm2i128	$32, %ymm3, %ymm1, %ymm6
	vperm2i128	$49, %ymm7, %ymm4, %ymm4
	vperm2i128	$49, %ymm3, %ymm1, %ymm10
	vpermq	$0, %ymm5, %ymm2
	vpermq	$85, %ymm5, %ymm9
	vpermq	$170, %ymm5, %ymm7
	vpermq	$255, %ymm5, %ymm8
	vpshufb	glob_data + 0(%rip), %ymm6, %ymm1
	vpshufb	glob_data + 0(%rip), %ymm9, %ymm3
	vpshufb	glob_data + 32(%rip), %ymm4, %ymm6
	vpshufb	glob_data + 32(%rip), %ymm7, %ymm11
	vpshufb	glob_data + 64(%rip), %ymm10, %ymm5
	vpshufb	glob_data + 64(%rip), %ymm8, %ymm4
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm5, %ymm6, %ymm6
	vpxor	%ymm4, %ymm11, %ymm8
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm8, %ymm3, %ymm3
	vpermq	$144, %ymm0, %ymm7
	vpxor	%ymm2, %ymm7, %ymm9
	vpblendd	$48, %ymm9, %ymm7, %ymm7
	vpblendd	$3, %ymm2, %ymm7, %ymm9
	vpxor	%ymm9, %ymm5, %ymm5
	vpermq	$255, %ymm0, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$255, %ymm1, %ymm7
	vpermq	$144, %ymm1, %ymm1
	vpxor	%ymm3, %ymm1, %ymm11
	vpblendd	$48, %ymm11, %ymm1, %ymm1
	vpblendd	$3, %ymm3, %ymm1, %ymm9
	vpermq	$144, %ymm5, %ymm1
	vpxor	%ymm4, %ymm1, %ymm11
	vpblendd	$48, %ymm11, %ymm1, %ymm1
	vpblendd	$3, %ymm4, %ymm1, %ymm1
	vpxor	%ymm1, %ymm6, %ymm1
	vpermq	$255, %ymm5, %ymm3
	vpxor	%ymm3, %ymm8, %ymm3
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm0, %ymm5, %ymm5
	vpxor	%ymm2, %ymm4, %ymm12
	vpxor	%ymm1, %ymm9, %ymm6
	vpxor	%ymm3, %ymm7, %ymm7
	vpshufb	glob_data + 64(%rip), %ymm6, %ymm4
	vpshufb	glob_data + 64(%rip), %ymm7, %ymm6
	vpshufb	glob_data + 32(%rip), %ymm1, %ymm1
	vpshufb	glob_data + 32(%rip), %ymm3, %ymm3
	vpshufb	glob_data + 0(%rip), %ymm5, %ymm9
	vpshufb	glob_data + 0(%rip), %ymm12, %ymm5
	vpxor	glob_data + 192(%rip), %ymm0, %ymm7
	vpblendd	$12, %ymm6, %ymm2, %ymm0
	vpblendd	$48, %ymm3, %ymm0, %ymm3
	vpblendd	$192, %ymm5, %ymm3, %ymm0
	vpunpcklqdq	%ymm4, %ymm7, %ymm6
	vpunpckhqdq	%ymm4, %ymm7, %ymm5
	vpunpcklqdq	%ymm9, %ymm1, %ymm3
	vpunpckhqdq	%ymm9, %ymm1, %ymm7
	vperm2i128	$32, %ymm3, %ymm6, %ymm1
	vperm2i128	$32, %ymm7, %ymm5, %ymm2
	vperm2i128	$49, %ymm3, %ymm6, %ymm3
	vperm2i128	$49, %ymm7, %ymm5, %ymm8
	vpxor	%ymm2, %ymm1, %ymm7
	vpxor	%ymm0, %ymm3, %ymm4
	vpor	%ymm3, %ymm1, %ymm10
	vpxor	glob_data + 896(%rip), %ymm7, %ymm11
	vpxor	%ymm11, %ymm8, %ymm6
	vpand	%ymm0, %ymm2, %ymm7
	vpxor	%ymm4, %ymm7, %ymm12
	vpxor	%ymm0, %ymm1, %ymm5
	vpand	%ymm0, %ymm1, %ymm1
	vpand	%ymm4, %ymm8, %ymm9
	vpand	%ymm6, %ymm3, %ymm7
	vpxor	%ymm12, %ymm8, %ymm8
	vpand	%ymm5, %ymm11, %ymm11
	vpand	%ymm4, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm0
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm10, %ymm1, %ymm1
	vpor	%ymm8, %ymm2, %ymm4
	vpxor	%ymm4, %ymm1, %ymm1
	vpxor	%ymm9, %ymm3, %ymm3
	vpor	%ymm5, %ymm6, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm2, %ymm9, %ymm9
	vpxor	%ymm8, %ymm7, %ymm6
	vpunpcklqdq	%ymm1, %ymm0, %ymm5
	vpunpckhqdq	%ymm1, %ymm0, %ymm7
	vpunpcklqdq	%ymm9, %ymm3, %ymm1
	vpunpckhqdq	%ymm9, %ymm3, %ymm3
	vperm2i128	$32, %ymm1, %ymm5, %ymm8
	vperm2i128	$32, %ymm3, %ymm7, %ymm0
	vperm2i128	$49, %ymm1, %ymm5, %ymm12
	vperm2i128	$49, %ymm3, %ymm7, %ymm4
	vpermq	$0, %ymm6, %ymm3
	vpermq	$85, %ymm6, %ymm2
	vpermq	$170, %ymm6, %ymm7
	vpermq	$255, %ymm6, %ymm1
	vpxor	%ymm0, %ymm8, %ymm5
	vpxor	%ymm2, %ymm3, %ymm10
	vpxor	%ymm4, %ymm12, %ymm3
	vpxor	%ymm1, %ymm7, %ymm6
	vpxor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm6, %ymm2, %ymm2
	vpermq	$144, %ymm5, %ymm7
	vpxor	%ymm10, %ymm7, %ymm8
	vpblendd	$48, %ymm8, %ymm7, %ymm9
	vpblendd	$3, %ymm10, %ymm9, %ymm8
	vpxor	%ymm8, %ymm4, %ymm4
	vpermq	$255, %ymm5, %ymm7
	vpxor	%ymm7, %ymm1, %ymm1
	vpermq	$255, %ymm0, %ymm7
	vpermq	$144, %ymm0, %ymm0
	vpxor	%ymm2, %ymm0, %ymm8
	vpblendd	$48, %ymm8, %ymm0, %ymm0
	vpblendd	$3, %ymm2, %ymm0, %ymm0
	vpermq	$144, %ymm4, %ymm9
	vpxor	%ymm1, %ymm9, %ymm8
	vpblendd	$48, %ymm8, %ymm9, %ymm12
	vpblendd	$3, %ymm1, %ymm12, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vpermq	$255, %ymm4, %ymm11
	vpxor	%ymm11, %ymm6, %ymm6
	vpxor	%ymm0, %ymm5, %ymm5
	vpxor	%ymm7, %ymm10, %ymm10
	vpxor	%ymm5, %ymm4, %ymm4
	vpxor	%ymm10, %ymm1, %ymm1
	vpxor	%ymm3, %ymm0, %ymm8
	vpxor	%ymm6, %ymm7, %ymm0
	vpblendd	$12, %ymm0, %ymm10, %ymm0
	vpblendd	$48, %ymm6, %ymm0, %ymm2
	vpblendd	$192, %ymm1, %ymm2, %ymm0
	vpunpcklqdq	%ymm8, %ymm5, %ymm9
	vpunpckhqdq	%ymm8, %ymm5, %ymm6
	vpunpcklqdq	%ymm4, %ymm3, %ymm7
	vpunpckhqdq	%ymm4, %ymm3, %ymm3
	vperm2i128	$32, %ymm7, %ymm9, %ymm1
	vperm2i128	$32, %ymm3, %ymm6, %ymm10
	vperm2i128	$49, %ymm7, %ymm9, %ymm5
	vperm2i128	$49, %ymm3, %ymm6, %ymm7
	vpxor	%ymm10, %ymm1, %ymm4
	vpxor	%ymm0, %ymm5, %ymm2
	vpor	%ymm5, %ymm1, %ymm3
	vpxor	glob_data + 896(%rip), %ymm4, %ymm11
	vpxor	%ymm11, %ymm7, %ymm8
	vpand	%ymm0, %ymm10, %ymm4
	vpxor	%ymm2, %ymm4, %ymm12
	vpxor	%ymm0, %ymm1, %ymm6
	vpand	%ymm0, %ymm1, %ymm1
	vpand	%ymm2, %ymm7, %ymm4
	vpand	%ymm8, %ymm5, %ymm9
	vpxor	%ymm12, %ymm7, %ymm7
	vpand	%ymm6, %ymm11, %ymm11
	vpand	%ymm2, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm0
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm3, %ymm1, %ymm1
	vpor	%ymm7, %ymm10, %ymm12
	vpxor	%ymm12, %ymm1, %ymm1
	vpxor	%ymm4, %ymm5, %ymm5
	vpor	%ymm6, %ymm8, %ymm6
	vpxor	%ymm6, %ymm5, %ymm5
	vpxor	%ymm3, %ymm10, %ymm3
	vpxor	%ymm3, %ymm4, %ymm3
	vpxor	%ymm7, %ymm9, %ymm9
	vpunpcklqdq	%ymm1, %ymm0, %ymm6
	vpunpckhqdq	%ymm1, %ymm0, %ymm0
	vpunpcklqdq	%ymm3, %ymm5, %ymm4
	vpunpckhqdq	%ymm3, %ymm5, %ymm2
	vperm2i128	$32, %ymm4, %ymm6, %ymm1
	vperm2i128	$32, %ymm2, %ymm0, %ymm7
	vperm2i128	$49, %ymm4, %ymm6, %ymm3
	vperm2i128	$49, %ymm2, %ymm0, %ymm5
	vpermq	$0, %ymm9, %ymm2
	vpermq	$85, %ymm9, %ymm10
	vpermq	$170, %ymm9, %ymm6
	vpermq	$255, %ymm9, %ymm4
	vpand	glob_data + 736(%rip), %ymm7, %ymm0
	vpsllq	$1, %ymm0, %ymm0
	vpand	glob_data + 704(%rip), %ymm7, %ymm7
	vpsrlq	$3, %ymm7, %ymm7
	vpor	%ymm7, %ymm0, %ymm7
	vpand	glob_data + 736(%rip), %ymm10, %ymm0
	vpsllq	$1, %ymm0, %ymm0
	vpand	glob_data + 704(%rip), %ymm10, %ymm10
	vpsrlq	$3, %ymm10, %ymm8
	vpor	%ymm8, %ymm0, %ymm0
	vpand	glob_data + 672(%rip), %ymm3, %ymm8
	vpsllq	$2, %ymm8, %ymm9
	vpand	glob_data + 640(%rip), %ymm3, %ymm3
	vpsrlq	$2, %ymm3, %ymm3
	vpor	%ymm3, %ymm9, %ymm9
	vpand	glob_data + 672(%rip), %ymm6, %ymm3
	vpsllq	$2, %ymm3, %ymm3
	vpand	glob_data + 640(%rip), %ymm6, %ymm6
	vpsrlq	$2, %ymm6, %ymm6
	vpor	%ymm6, %ymm3, %ymm6
	vpand	glob_data + 608(%rip), %ymm5, %ymm3
	vpsllq	$3, %ymm3, %ymm3
	vpand	glob_data + 576(%rip), %ymm5, %ymm5
	vpsrlq	$1, %ymm5, %ymm8
	vpor	%ymm8, %ymm3, %ymm3
	vpand	glob_data + 608(%rip), %ymm4, %ymm5
	vpsllq	$3, %ymm5, %ymm5
	vpand	glob_data + 576(%rip), %ymm4, %ymm4
	vpsrlq	$1, %ymm4, %ymm12
	vpor	%ymm12, %ymm5, %ymm4
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm3, %ymm9, %ymm9
	vpxor	%ymm4, %ymm6, %ymm6
	vpxor	%ymm9, %ymm7, %ymm5
	vpxor	%ymm6, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm7
	vpxor	%ymm2, %ymm7, %ymm8
	vpblendd	$48, %ymm8, %ymm7, %ymm10
	vpblendd	$3, %ymm2, %ymm10, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vpermq	$255, %ymm1, %ymm7
	vpxor	%ymm7, %ymm4, %ymm4
	vpermq	$255, %ymm5, %ymm7
	vpermq	$144, %ymm5, %ymm8
	vpxor	%ymm0, %ymm8, %ymm12
	vpblendd	$48, %ymm12, %ymm8, %ymm5
	vpblendd	$3, %ymm0, %ymm5, %ymm0
	vpermq	$144, %ymm3, %ymm10
	vpxor	%ymm4, %ymm10, %ymm5
	vpblendd	$48, %ymm5, %ymm10, %ymm8
	vpblendd	$3, %ymm4, %ymm8, %ymm5
	vpxor	%ymm5, %ymm9, %ymm9
	vpermq	$255, %ymm3, %ymm8
	vpxor	%ymm8, %ymm6, %ymm6
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm7, %ymm2, %ymm2
	vpxor	%ymm1, %ymm3, %ymm3
	vpxor	%ymm2, %ymm4, %ymm4
	vpxor	%ymm9, %ymm0, %ymm0
	vpxor	%ymm6, %ymm7, %ymm5
	vpand	glob_data + 608(%rip), %ymm0, %ymm7
	vpsllq	$3, %ymm7, %ymm7
	vpand	glob_data + 576(%rip), %ymm0, %ymm0
	vpsrlq	$1, %ymm0, %ymm0
	vpor	%ymm0, %ymm7, %ymm0
	vpand	glob_data + 608(%rip), %ymm5, %ymm10
	vpsllq	$3, %ymm10, %ymm8
	vpand	glob_data + 576(%rip), %ymm5, %ymm5
	vpsrlq	$1, %ymm5, %ymm7
	vpor	%ymm7, %ymm8, %ymm5
	vpand	glob_data + 672(%rip), %ymm9, %ymm7
	vpsllq	$2, %ymm7, %ymm7
	vpand	glob_data + 640(%rip), %ymm9, %ymm9
	vpsrlq	$2, %ymm9, %ymm12
	vpor	%ymm12, %ymm7, %ymm7
	vpand	glob_data + 672(%rip), %ymm6, %ymm8
	vpsllq	$2, %ymm8, %ymm8
	vpand	glob_data + 640(%rip), %ymm6, %ymm6
	vpsrlq	$2, %ymm6, %ymm10
	vpor	%ymm10, %ymm8, %ymm6
	vpand	glob_data + 736(%rip), %ymm3, %ymm12
	vpsllq	$1, %ymm12, %ymm8
	vpand	glob_data + 704(%rip), %ymm3, %ymm3
	vpsrlq	$3, %ymm3, %ymm12
	vpor	%ymm12, %ymm8, %ymm3
	vpand	glob_data + 736(%rip), %ymm4, %ymm9
	vpsllq	$1, %ymm9, %ymm12
	vpand	glob_data + 704(%rip), %ymm4, %ymm4
	vpsrlq	$3, %ymm4, %ymm8
	vpor	%ymm8, %ymm12, %ymm12
	vpxor	glob_data + 160(%rip), %ymm1, %ymm4
	vpblendd	$12, %ymm5, %ymm2, %ymm1
	vpblendd	$48, %ymm6, %ymm1, %ymm1
	vpblendd	$192, %ymm12, %ymm1, %ymm1
	vpunpcklqdq	%ymm0, %ymm4, %ymm8
	vpunpckhqdq	%ymm0, %ymm4, %ymm12
	vpunpcklqdq	%ymm3, %ymm7, %ymm9
	vpunpckhqdq	%ymm3, %ymm7, %ymm3
	vperm2i128	$32, %ymm9, %ymm8, %ymm0
	vperm2i128	$32, %ymm3, %ymm12, %ymm2
	vperm2i128	$49, %ymm9, %ymm8, %ymm5
	vperm2i128	$49, %ymm3, %ymm12, %ymm9
	vpxor	%ymm2, %ymm0, %ymm3
	vpxor	%ymm1, %ymm5, %ymm6
	vpor	%ymm5, %ymm0, %ymm10
	vpxor	glob_data + 896(%rip), %ymm3, %ymm11
	vpxor	%ymm11, %ymm9, %ymm3
	vpand	%ymm1, %ymm2, %ymm4
	vpxor	%ymm6, %ymm4, %ymm12
	vpxor	%ymm1, %ymm0, %ymm4
	vpand	%ymm1, %ymm0, %ymm0
	vpand	%ymm6, %ymm9, %ymm7
	vpand	%ymm3, %ymm5, %ymm8
	vpxor	%ymm12, %ymm9, %ymm9
	vpand	%ymm4, %ymm11, %ymm11
	vpand	%ymm6, %ymm1, %ymm1
	vpxor	%ymm1, %ymm11, %ymm1
	vpxor	%ymm8, %ymm1, %ymm6
	vpxor	%ymm10, %ymm0, %ymm0
	vpor	%ymm9, %ymm2, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm7, %ymm5, %ymm5
	vpor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm3, %ymm5, %ymm5
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm2, %ymm7, %ymm1
	vpxor	%ymm9, %ymm8, %ymm3
	vpunpcklqdq	%ymm0, %ymm6, %ymm7
	vpunpckhqdq	%ymm0, %ymm6, %ymm0
	vpunpcklqdq	%ymm1, %ymm5, %ymm4
	vpunpckhqdq	%ymm1, %ymm5, %ymm6
	vperm2i128	$32, %ymm4, %ymm7, %ymm5
	vperm2i128	$32, %ymm6, %ymm0, %ymm1
	vperm2i128	$49, %ymm4, %ymm7, %ymm7
	vperm2i128	$49, %ymm6, %ymm0, %ymm0
	vpermq	$0, %ymm3, %ymm10
	vpermq	$85, %ymm3, %ymm2
	vpermq	$170, %ymm3, %ymm6
	vpermq	$255, %ymm3, %ymm4
	vpxor	%ymm1, %ymm5, %ymm3
	vpxor	%ymm2, %ymm10, %ymm10
	vpxor	%ymm0, %ymm7, %ymm7
	vpxor	%ymm4, %ymm6, %ymm5
	vpxor	%ymm7, %ymm1, %ymm1
	vpxor	%ymm5, %ymm2, %ymm2
	vpermq	$144, %ymm3, %ymm6
	vpxor	%ymm10, %ymm6, %ymm8
	vpblendd	$48, %ymm8, %ymm6, %ymm8
	vpblendd	$3, %ymm10, %ymm8, %ymm8
	vpxor	%ymm8, %ymm0, %ymm0
	vpermq	$255, %ymm3, %ymm12
	vpxor	%ymm12, %ymm4, %ymm4
	vpermq	$255, %ymm1, %ymm6
	vpermq	$144, %ymm1, %ymm1
	vpxor	%ymm2, %ymm1, %ymm8
	vpblendd	$48, %ymm8, %ymm1, %ymm1
	vpblendd	$3, %ymm2, %ymm1, %ymm8
	vpermq	$144, %ymm0, %ymm1
	vpxor	%ymm4, %ymm1, %ymm12
	vpblendd	$48, %ymm12, %ymm1, %ymm1
	vpblendd	$3, %ymm4, %ymm1, %ymm1
	vpxor	%ymm1, %ymm7, %ymm1
	vpermq	$255, %ymm0, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vpxor	%ymm8, %ymm3, %ymm3
	vpxor	%ymm6, %ymm10, %ymm10
	vpxor	%ymm3, %ymm0, %ymm0
	vpxor	%ymm10, %ymm4, %ymm4
	vpxor	%ymm1, %ymm8, %ymm8
	vpxor	%ymm5, %ymm6, %ymm6
	vpblendd	$12, %ymm6, %ymm10, %ymm11
	vpblendd	$48, %ymm5, %ymm11, %ymm2
	vpblendd	$192, %ymm4, %ymm2, %ymm5
	vpunpcklqdq	%ymm8, %ymm3, %ymm2
	vpunpckhqdq	%ymm8, %ymm3, %ymm7
	vpunpcklqdq	%ymm0, %ymm1, %ymm4
	vpunpckhqdq	%ymm0, %ymm1, %ymm9
	vperm2i128	$32, %ymm4, %ymm2, %ymm0
	vperm2i128	$32, %ymm9, %ymm7, %ymm1
	vperm2i128	$49, %ymm4, %ymm2, %ymm3
	vperm2i128	$49, %ymm9, %ymm7, %ymm10
	vpxor	%ymm1, %ymm0, %ymm8
	vpxor	%ymm5, %ymm3, %ymm4
	vpor	%ymm3, %ymm0, %ymm2
	vpxor	glob_data + 896(%rip), %ymm8, %ymm11
	vpxor	%ymm11, %ymm10, %ymm6
	vpand	%ymm5, %ymm1, %ymm8
	vpxor	%ymm4, %ymm8, %ymm12
	vpxor	%ymm5, %ymm0, %ymm7
	vpand	%ymm5, %ymm0, %ymm0
	vpand	%ymm4, %ymm10, %ymm8
	vpand	%ymm6, %ymm3, %ymm9
	vpxor	%ymm12, %ymm10, %ymm10
	vpand	%ymm7, %ymm11, %ymm11
	vpand	%ymm4, %ymm5, %ymm5
	vpxor	%ymm5, %ymm11, %ymm4
	vpxor	%ymm9, %ymm4, %ymm4
	vpxor	%ymm2, %ymm0, %ymm0
	vpor	%ymm10, %ymm1, %ymm12
	vpxor	%ymm12, %ymm0, %ymm0
	vpxor	%ymm8, %ymm3, %ymm3
	vpor	%ymm7, %ymm6, %ymm5
	vpxor	%ymm5, %ymm3, %ymm3
	vpxor	%ymm2, %ymm1, %ymm1
	vpxor	%ymm1, %ymm8, %ymm6
	vpxor	%ymm10, %ymm9, %ymm7
	vpunpcklqdq	%ymm0, %ymm4, %ymm5
	vpunpckhqdq	%ymm0, %ymm4, %ymm0
	vpunpcklqdq	%ymm6, %ymm3, %ymm8
	vpunpckhqdq	%ymm6, %ymm3, %ymm3
	vperm2i128	$32, %ymm8, %ymm5, %ymm1
	vperm2i128	$32, %ymm3, %ymm0, %ymm12
	vperm2i128	$49, %ymm8, %ymm5, %ymm4
	vperm2i128	$49, %ymm3, %ymm0, %ymm3
	vpermq	$0, %ymm7, %ymm2
	vpermq	$85, %ymm7, %ymm10
	vpermq	$170, %ymm7, %ymm5
	vpermq	$255, %ymm7, %ymm8
	vpand	glob_data + 512(%rip), %ymm12, %ymm0
	vpsllq	$4, %ymm0, %ymm0
	vpand	glob_data + 480(%rip), %ymm12, %ymm7
	vpsrlq	$12, %ymm7, %ymm6
	vpor	%ymm6, %ymm0, %ymm6
	vpand	glob_data + 512(%rip), %ymm10, %ymm0
	vpsllq	$4, %ymm0, %ymm0
	vpand	glob_data + 480(%rip), %ymm10, %ymm10
	vpsrlq	$12, %ymm10, %ymm9
	vpor	%ymm9, %ymm0, %ymm0
	vpand	glob_data + 448(%rip), %ymm4, %ymm7
	vpsllq	$8, %ymm7, %ymm7
	vpand	glob_data + 416(%rip), %ymm4, %ymm4
	vpsrlq	$8, %ymm4, %ymm12
	vpor	%ymm12, %ymm7, %ymm7
	vpand	glob_data + 448(%rip), %ymm5, %ymm4
	vpsllq	$8, %ymm4, %ymm4
	vpand	glob_data + 416(%rip), %ymm5, %ymm5
	vpsrlq	$8, %ymm5, %ymm5
	vpor	%ymm5, %ymm4, %ymm4
	vpand	glob_data + 384(%rip), %ymm3, %ymm10
	vpsllq	$12, %ymm10, %ymm9
	vpand	glob_data + 352(%rip), %ymm3, %ymm3
	vpsrlq	$4, %ymm3, %ymm3
	vpor	%ymm3, %ymm9, %ymm9
	vpand	glob_data + 384(%rip), %ymm8, %ymm10
	vpsllq	$12, %ymm10, %ymm3
	vpand	glob_data + 352(%rip), %ymm8, %ymm8
	vpsrlq	$4, %ymm8, %ymm12
	vpor	%ymm12, %ymm3, %ymm3
	vpxor	%ymm6, %ymm1, %ymm1
	vpxor	%ymm0, %ymm2, %ymm2
	vpxor	%ymm9, %ymm7, %ymm7
	vpxor	%ymm3, %ymm4, %ymm4
	vpxor	%ymm7, %ymm6, %ymm6
	vpxor	%ymm4, %ymm0, %ymm0
	vpermq	$144, %ymm1, %ymm5
	vpxor	%ymm2, %ymm5, %ymm8
	vpblendd	$48, %ymm8, %ymm5, %ymm10
	vpblendd	$3, %ymm2, %ymm10, %ymm5
	vpxor	%ymm5, %ymm9, %ymm9
	vpermq	$255, %ymm1, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vpermq	$255, %ymm6, %ymm8
	vpermq	$144, %ymm6, %ymm11
	vpxor	%ymm0, %ymm11, %ymm12
	vpblendd	$48, %ymm12, %ymm11, %ymm5
	vpblendd	$3, %ymm0, %ymm5, %ymm0
	vpermq	$144, %ymm9, %ymm10
	vpxor	%ymm3, %ymm10, %ymm5
	vpblendd	$48, %ymm5, %ymm10, %ymm6
	vpblendd	$3, %ymm3, %ymm6, %ymm5
	vpxor	%ymm5, %ymm7, %ymm7
	vpermq	$255, %ymm9, %ymm11
	vpxor	%ymm11, %ymm4, %ymm4
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm8, %ymm2, %ymm2
	vpxor	%ymm1, %ymm9, %ymm9
	vpxor	%ymm2, %ymm3, %ymm3
	vpxor	%ymm7, %ymm0, %ymm0
	vpxor	%ymm4, %ymm8, %ymm6
	vpand	glob_data + 384(%rip), %ymm0, %ymm12
	vpsllq	$12, %ymm12, %ymm5
	vpand	glob_data + 352(%rip), %ymm0, %ymm0
	vpsrlq	$4, %ymm0, %ymm0
	vpor	%ymm0, %ymm5, %ymm0
	vpand	glob_data + 384(%rip), %ymm6, %ymm10
	vpsllq	$12, %ymm10, %ymm5
	vpand	glob_data + 352(%rip), %ymm6, %ymm6
	vpsrlq	$4, %ymm6, %ymm6
	vpor	%ymm6, %ymm5, %ymm5
	vpand	glob_data + 448(%rip), %ymm7, %ymm6
	vpsllq	$8, %ymm6, %ymm8
	vpand	glob_data + 416(%rip), %ymm7, %ymm7
	vpsrlq	$8, %ymm7, %ymm7
	vpor	%ymm7, %ymm8, %ymm8
	vpand	glob_data + 448(%rip), %ymm4, %ymm7
	vpsllq	$8, %ymm7, %ymm6
	vpand	glob_data + 416(%rip), %ymm4, %ymm4
	vpsrlq	$8, %ymm4, %ymm10
	vpor	%ymm10, %ymm6, %ymm6
	vpand	glob_data + 512(%rip), %ymm9, %ymm4
	vpsllq	$4, %ymm4, %ymm4
	vpand	glob_data + 480(%rip), %ymm9, %ymm9
	vpsrlq	$12, %ymm9, %ymm7
	vpor	%ymm7, %ymm4, %ymm4
	vpand	glob_data + 512(%rip), %ymm3, %ymm7
	vpsllq	$4, %ymm7, %ymm7
	vpand	glob_data + 480(%rip), %ymm3, %ymm3
	vpsrlq	$12, %ymm3, %ymm12
	vpor	%ymm12, %ymm7, %ymm7
	vpxor	glob_data + 128(%rip), %ymm1, %ymm3
	vpblendd	$12, %ymm5, %ymm2, %ymm11
	vpblendd	$48, %ymm6, %ymm11, %ymm1
	vpblendd	$192, %ymm7, %ymm1, %ymm1
	vpunpcklqdq	%ymm0, %ymm3, %ymm9
	vpunpckhqdq	%ymm0, %ymm3, %ymm5
	vpunpcklqdq	%ymm4, %ymm8, %ymm3
	vpunpckhqdq	%ymm4, %ymm8, %ymm6
	vperm2i128	$32, %ymm3, %ymm9, %ymm0
	vperm2i128	$32, %ymm6, %ymm5, %ymm2
	vperm2i128	$49, %ymm3, %ymm9, %ymm3
	vperm2i128	$49, %ymm6, %ymm5, %ymm7
	vpxor	%ymm2, %ymm0, %ymm6
	vpxor	%ymm1, %ymm3, %ymm4
	vpor	%ymm3, %ymm0, %ymm10
	vpxor	glob_data + 896(%rip), %ymm6, %ymm11
	vpxor	%ymm11, %ymm7, %ymm5
	vpand	%ymm1, %ymm2, %ymm6
	vpxor	%ymm4, %ymm6, %ymm12
	vpxor	%ymm1, %ymm0, %ymm8
	vpand	%ymm1, %ymm0, %ymm0
	vpand	%ymm4, %ymm7, %ymm6
	vpand	%ymm5, %ymm3, %ymm9
	vpxor	%ymm12, %ymm7, %ymm7
	vpand	%ymm8, %ymm11, %ymm11
	vpand	%ymm4, %ymm1, %ymm1
	vpxor	%ymm1, %ymm11, %ymm4
	vpxor	%ymm9, %ymm4, %ymm4
	vpxor	%ymm10, %ymm0, %ymm0
	vpor	%ymm7, %ymm2, %ymm1
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm6, %ymm3, %ymm1
	vpor	%ymm8, %ymm5, %ymm5
	vpxor	%ymm5, %ymm1, %ymm1
	vpxor	%ymm10, %ymm2, %ymm2
	vpxor	%ymm2, %ymm6, %ymm3
	vpxor	%ymm7, %ymm9, %ymm9
	vpunpcklqdq	%ymm0, %ymm4, %ymm5
	vpunpckhqdq	%ymm0, %ymm4, %ymm6
	vpunpcklqdq	%ymm3, %ymm1, %ymm8
	vpunpckhqdq	%ymm3, %ymm1, %ymm1
	vperm2i128	$32, %ymm8, %ymm5, %ymm4
	vperm2i128	$32, %ymm1, %ymm6, %ymm0
	vperm2i128	$49, %ymm8, %ymm5, %ymm8
	vperm2i128	$49, %ymm1, %ymm6, %ymm5
	vpermq	$0, %ymm9, %ymm10
	vpermq	$85, %ymm9, %ymm2
	vpermq	$170, %ymm9, %ymm6
	vpermq	$255, %ymm9, %ymm3
	vpxor	%ymm0, %ymm4, %ymm1
	vpxor	%ymm2, %ymm10, %ymm10
	vpxor	%ymm5, %ymm8, %ymm4
	vpxor	%ymm3, %ymm6, %ymm6
	vpxor	%ymm4, %ymm0, %ymm0
	vpxor	%ymm6, %ymm2, %ymm2
	vpermq	$144, %ymm1, %ymm7
	vpxor	%ymm10, %ymm7, %ymm12
	vpblendd	$48, %ymm12, %ymm7, %ymm7
	vpblendd	$3, %ymm10, %ymm7, %ymm7
	vpxor	%ymm7, %ymm5, %ymm5
	vpermq	$255, %ymm1, %ymm8
	vpxor	%ymm8, %ymm3, %ymm3
	vpermq	$255, %ymm0, %ymm7
	vpermq	$144, %ymm0, %ymm0
	vpxor	%ymm2, %ymm0, %ymm9
	vpblendd	$48, %ymm9, %ymm0, %ymm0
	vpblendd	$3, %ymm2, %ymm0, %ymm0
	vpermq	$144, %ymm5, %ymm8
	vpxor	%ymm3, %ymm8, %ymm11
	vpblendd	$48, %ymm11, %ymm8, %ymm8
	vpblendd	$3, %ymm3, %ymm8, %ymm2
	vpxor	%ymm2, %ymm4, %ymm4
	vpermq	$255, %ymm5, %ymm12
	vpxor	%ymm12, %ymm6, %ymm6
	vpxor	%ymm0, %ymm1, %ymm1
	vpxor	%ymm7, %ymm10, %ymm10
	vpxor	%ymm1, %ymm5, %ymm5
	vpxor	%ymm10, %ymm3, %ymm3
	vpxor	%ymm4, %ymm0, %ymm12
	vpxor	%ymm6, %ymm7, %ymm0
	vpblendd	$12, %ymm0, %ymm10, %ymm0
	vpblendd	$48, %ymm6, %ymm0, %ymm2
	vpblendd	$192, %ymm3, %ymm2, %ymm0
	vpunpcklqdq	%ymm12, %ymm1, %ymm3
	vpunpckhqdq	%ymm12, %ymm1, %ymm6
	vpunpcklqdq	%ymm5, %ymm4, %ymm8
	vpunpckhqdq	%ymm5, %ymm4, %ymm2
	vperm2i128	$32, %ymm8, %ymm3, %ymm1
	vperm2i128	$32, %ymm2, %ymm6, %ymm10
	vperm2i128	$49, %ymm8, %ymm3, %ymm3
	vperm2i128	$49, %ymm2, %ymm6, %ymm9
	vpxor	%ymm10, %ymm1, %ymm11
	vpxor	%ymm0, %ymm3, %ymm4
	vpor	%ymm3, %ymm1, %ymm2
	vpxor	glob_data + 896(%rip), %ymm11, %ymm11
	vpxor	%ymm11, %ymm9, %ymm7
	vpand	%ymm0, %ymm10, %ymm5
	vpxor	%ymm4, %ymm5, %ymm12
	vpxor	%ymm0, %ymm1, %ymm8
	vpand	%ymm0, %ymm1, %ymm1
	vpand	%ymm4, %ymm9, %ymm5
	vpand	%ymm7, %ymm3, %ymm6
	vpxor	%ymm12, %ymm9, %ymm9
	vpand	%ymm8, %ymm11, %ymm11
	vpand	%ymm4, %ymm0, %ymm0
	vpxor	%ymm0, %ymm11, %ymm0
	vpxor	%ymm6, %ymm0, %ymm0
	vpxor	%ymm2, %ymm1, %ymm1
	vpor	%ymm9, %ymm10, %ymm11
	vpxor	%ymm11, %ymm1, %ymm1
	vpxor	%ymm5, %ymm3, %ymm3
	vpor	%ymm8, %ymm7, %ymm4
	vpxor	%ymm4, %ymm3, %ymm3
	vpxor	%ymm2, %ymm10, %ymm10
	vpxor	%ymm10, %ymm5, %ymm5
	vpxor	%ymm9, %ymm6, %ymm4
	vpunpcklqdq	%ymm1, %ymm0, %ymm6
	vpunpckhqdq	%ymm1, %ymm0, %ymm1
	vpunpcklqdq	%ymm5, %ymm3, %ymm7
	vpunpckhqdq	%ymm5, %ymm3, %ymm3
	vperm2i128	$32, %ymm7, %ymm6, %ymm0
	vperm2i128	$32, %ymm3, %ymm1, %ymm5
	vperm2i128	$49, %ymm7, %ymm6, %ymm8
	vperm2i128	$49, %ymm3, %ymm1, %ymm6
	vpermq	$0, %ymm4, %ymm2
	vpermq	$85, %ymm4, %ymm3
	vpermq	$170, %ymm4, %ymm7
	vpermq	$255, %ymm4, %ymm9
	vpshufb	glob_data + 0(%rip), %ymm5, %ymm1
	vpshufb	glob_data + 0(%rip), %ymm3, %ymm3
	vpshufb	glob_data + 32(%rip), %ymm8, %ymm8
	vpshufb	glob_data + 32(%rip), %ymm7, %ymm4
	vpshufb	glob_data + 64(%rip), %ymm6, %ymm5
	vpshufb	glob_data + 64(%rip), %ymm9, %ymm7
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm3, %ymm2, %ymm2
	vpxor	%ymm5, %ymm8, %ymm8
	vpxor	%ymm7, %ymm4, %ymm4
	vpxor	%ymm8, %ymm1, %ymm1
	vpxor	%ymm4, %ymm3, %ymm3
	vpermq	$144, %ymm0, %ymm6
	vpxor	%ymm2, %ymm6, %ymm11
	vpblendd	$48, %ymm11, %ymm6, %ymm6
	vpblendd	$3, %ymm2, %ymm6, %ymm10
	vpxor	%ymm10, %ymm5, %ymm5
	vpermq	$255, %ymm0, %ymm11
	vpxor	%ymm11, %ymm7, %ymm7
	vpermq	$255, %ymm1, %ymm6
	vpermq	$144, %ymm1, %ymm1
	vpxor	%ymm3, %ymm1, %ymm9
	vpblendd	$48, %ymm9, %ymm1, %ymm11
	vpblendd	$3, %ymm3, %ymm11, %ymm1
	vpermq	$144, %ymm5, %ymm3
	vpxor	%ymm7, %ymm3, %ymm10
	vpblendd	$48, %ymm10, %ymm3, %ymm3
	vpblendd	$3, %ymm7, %ymm3, %ymm12
	vpxor	%ymm12, %ymm8, %ymm8
	vpermq	$255, %ymm5, %ymm10
	vpxor	%ymm10, %ymm4, %ymm3
	vpxor	%ymm1, %ymm0, %ymm0
	vpxor	%ymm6, %ymm2, %ymm2
	vpxor	%ymm0, %ymm5, %ymm5
	vpxor	%ymm2, %ymm7, %ymm7
	vpxor	%ymm8, %ymm1, %ymm1
	vpxor	%ymm3, %ymm6, %ymm6
	vpshufb	glob_data + 64(%rip), %ymm1, %ymm1
	vpshufb	glob_data + 64(%rip), %ymm6, %ymm6
	vpshufb	glob_data + 32(%rip), %ymm8, %ymm4
	vpshufb	glob_data + 32(%rip), %ymm3, %ymm3
	vpshufb	glob_data + 0(%rip), %ymm5, %ymm10
	vpshufb	glob_data + 0(%rip), %ymm7, %ymm8
	vpxor	glob_data + 96(%rip), %ymm0, %ymm0
	vpblendd	$12, %ymm6, %ymm2, %ymm7
	vpblendd	$48, %ymm3, %ymm7, %ymm6
	vpblendd	$192, %ymm8, %ymm6, %ymm3
	vpunpcklqdq	%ymm1, %ymm0, %ymm5
	vpunpckhqdq	%ymm1, %ymm0, %ymm0
	vpunpcklqdq	%ymm10, %ymm4, %ymm1
	vpunpckhqdq	%ymm10, %ymm4, %ymm6
	vperm2i128	$32, %ymm1, %ymm5, %ymm2
	vperm2i128	$32, %ymm6, %ymm0, %ymm8
	vperm2i128	$49, %ymm1, %ymm5, %ymm1
	vperm2i128	$49, %ymm6, %ymm0, %ymm0
	vmovdqu	%ymm2, (%rdi)
	vmovdqu	%ymm8, 32(%rdi)
	vmovdqu	%ymm1, 64(%rdi)
	vmovdqu	%ymm0, 96(%rdi)
	vmovdqu	%ymm3, 128(%rdi)
	ret
	.data
	.p2align	5
glob_data:
G$rotr48mask:
	.byte	  6,   7,   0,   1,   2,   3,   4,   5,  14,  15,   8,   9,  10,  11,  12,  13
	.byte	  6,   7,   0,   1,   2,   3,   4,   5,  14,  15,   8,   9,  10,  11,  12,  13
G$rotr32mask:
	.byte	  4,   5,   6,   7,   0,   1,   2,   3,  12,  13,  14,  15,   8,   9,  10,  11
	.byte	  4,   5,   6,   7,   0,   1,   2,   3,  12,  13,  14,  15,   8,   9,  10,  11
G$rotr16mask:
	.byte	  2,   3,   4,   5,   6,   7,   0,   1,  10,  11,  12,  13,  14,  15,   8,   9
	.byte	  2,   3,   4,   5,   6,   7,   0,   1,  10,  11,  12,  13,  14,  15,   8,   9
G$RCV17:
	.byte	 88, 182, 142, 114, 143, 116, 149,  13,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RCV16:
	.byte	126,  61, 147, 244, 163, 254,  88, 164,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RCV15:
	.byte	105,  78,  87, 113, 216,  32, 105,  99,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RCV14:
	.byte	 22, 252, 142, 133, 226, 242,   1,   8,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RCV13:
	.byte	247, 108, 145, 179,  71, 153, 161,  36,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RCV12:
	.byte	153, 127,  44, 241,  69, 144, 124, 186,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RCV11:
	.byte	150, 126,  38, 106, 237, 175, 225, 184,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$RCV10:
	.byte	183, 223,  26, 208, 219, 114, 253,  47,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$MKfff0fff0fff0fff0:
	.byte	240, 255, 240, 255, 240, 255, 240, 255, 240, 255, 240, 255, 240, 255, 240, 255
	.byte	240, 255, 240, 255, 240, 255, 240, 255, 240, 255, 240, 255, 240, 255, 240, 255
G$MK000f000f000f000f:
	.byte	 15,   0,  15,   0,  15,   0,  15,   0,  15,   0,  15,   0,  15,   0,  15,   0
	.byte	 15,   0,  15,   0,  15,   0,  15,   0,  15,   0,  15,   0,  15,   0,  15,   0
G$MKff00ff00ff00ff00:
	.byte	  0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255
	.byte	  0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255
G$MK00ff00ff00ff00ff:
	.byte	255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0
	.byte	255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0, 255,   0
G$MKf000f000f000f000:
	.byte	  0, 240,   0, 240,   0, 240,   0, 240,   0, 240,   0, 240,   0, 240,   0, 240
	.byte	  0, 240,   0, 240,   0, 240,   0, 240,   0, 240,   0, 240,   0, 240,   0, 240
G$MK0fff0fff0fff0fff:
	.byte	255,  15, 255,  15, 255,  15, 255,  15, 255,  15, 255,  15, 255,  15, 255,  15
	.byte	255,  15, 255,  15, 255,  15, 255,  15, 255,  15, 255,  15, 255,  15, 255,  15
G$RCV9:
	.byte	172, 181, 223, 152, 166,  11,  49, 209,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$MKeeeeeeeeeeeeeeee:
	.byte	238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238
	.byte	238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238
G$MK1111111111111111:
	.byte	 17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17
	.byte	 17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17,  17
G$MKcccccccccccccccc:
	.byte	204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204
	.byte	204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204, 204
G$MK3333333333333333:
	.byte	 51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51
	.byte	 51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51,  51
G$MK8888888888888888:
	.byte	136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136
	.byte	136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136
G$MK7777777777777777:
	.byte	119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119
	.byte	119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119, 119
G$LANE3:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 255, 255, 255, 255, 255, 255, 255, 255
G$LANE2:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	255, 255, 255, 255, 255, 255, 255, 255,   0,   0,   0,   0,   0,   0,   0,   0
G$LANE1:
	.byte	  0,   0,   0,   0,   0,   0,   0,   0, 255, 255, 255, 255, 255, 255, 255, 255
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$LANE0:
	.byte	255, 255, 255, 255, 255, 255, 255, 255,   0,   0,   0,   0,   0,   0,   0,   0
	.byte	  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
G$ONES:
	.byte	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255
	.byte	255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255
	.ident	"Jasmin Compiler 2026.09.0"
	.section	".note.GNU-stack", "", %progbits
