# Vedak-1024

Algorithm: Vedak | Digest bits: 1024 | Form: AVX2 打包半字节

Contents: implementation source/, public header Vedak-1024.h, prebuilt Vedak-1024.so,
KAT vector KAT_2_12_Vedak-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): b6be104e76805ba20553610b6db2ab1562e8954d3339a9236f537db311c7982d
Speed (cpB, lower is faster): reference 285.58 / official-optimized 32.32 / optimized 28.44
Speedup: GM(S1-S8) 1.09x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
