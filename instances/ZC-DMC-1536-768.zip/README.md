# ZC-DMC-1536-768

Algorithm: ZC-DMC | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header ZC-DMC-1536-768.h, prebuilt ZC-DMC-1536-768.so,
KAT vector KAT_2_12_ZC-DMC-1536-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 7d6764f210b3915a8ff103c196424e32cc863157b1f991d89836d6420ba8440b
Speed (cpB, lower is faster): reference 19.67 / official-optimized 12.54 / optimized 9.46
Speedup: GM(S1-S8) 1.33x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
