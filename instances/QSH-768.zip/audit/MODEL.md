# QSH — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## QSH-512
- 摘要位：512；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/QSH-512/`
- 官方优化源码：随包 `Official_Optimized_Implementation/QSH-512/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/QSH-512/`
- 优化要点：QSH 三档共用一件库（CryptHash 把摘要长度当运行时参数）。本轮给 512 档走的 blk32 补满块 memcpy 快路径：官方原先每字节调用 pbyte（每次重算 f=L>>3、r=L&7、tot-16 并走三分支）；本件在 nm==128（整块落在消息内）时走 __builtin_memcpy 常量长度拷贝、gcc 内联成向量搬移，尾块逐字复刻官方常量界循环（gcc 全展开，短消息不退化）——与同库 768/1024 的 blk64 v3（nm==256）补的是同一类 Vedak 型不对称。唯一源码改动在 gen_blk32_v3.py，其余（E3_32/E3_64、tree、CryptHash、blk64 v3）逐字保留，单翻译单元。构建十 flag、warnings=0；三档 KAT 各 4097/4097、forbidden=0；3 档 × 21 长度 = 63/63

## QSH-768
- 摘要位：768；实现形态：AVX2 C
- 官方参考源码：随包 `Reference_Implementation/QSH-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/QSH-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/QSH-768/`
- 优化要点：QSH 三档共用一件库（CryptHash 把摘要长度当运行时参数、不读 DIGEST_BIT_LENGTH）。本轮交付件换成了给 512 档 blk32 补满块 memcpy 快路径的新件，但 768/1024 走的是 blk64（v3 早已带 nm==256 满块快路径），blk32 对这两档是死代码 —— 新件与旧件行为逐位相同（三档 KAT 各 4097/4097；3 档 × 21 长度 = 63/63 多长度对拍与 ref/opt/旧件逐字节相同、无越界写）。共享库二进制 sha 变了，故按一件库多档的纪律与 512 档一起重测、刷新 sha、确认无回归：稳健复测新/旧 768 = −0.04%、1024 = +0.41%（都在 ±1% 分辨力内，即无回归）；本档判数仍由本轮实测给出。构建十 flag、warnings=0、forbidden=0。 【判读澄清】本档表内 gm=1
