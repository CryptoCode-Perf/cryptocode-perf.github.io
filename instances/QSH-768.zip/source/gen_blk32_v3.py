# -*- coding: utf-8 -*-
"""QSH 多档共享库的 Vedak 型不对称修补：给 512 档的 blk32 补满块 memcpy 快路径。

事实（只读侦察确认）
  同一件 `ours_qsh1024_v3.so` 通过运行时 digest_len_bits 服务三档：
    512 -> crypt512 -> blk32（w=32, base=t*128, 每块 128 字节, k<4）
    768/1024 -> crypt64 -> blk64（w=64, base=t*256, 每块 256 字节, k<8）
  blk64 早已在 v3 里换成「满块 nm==256 常量长度 memcpy + 尾块照抄官方」，
  而 blk32 仍是官方原样：每字节调用 pbyte（重算 f/r/tot 后走三分支）。

本脚本在 v3 glue 的基础上，把 blk32 也换成同形状（满块 nm==128 常量长度 memcpy，
尾块逐字复刻官方常量界循环 —— gcc 全展开，短消息不退化）。其余一字不动，
blk64 v3、E3_32/E3_64、tree、CryptHash 全部保留。

语义（小端逐位等价）：b[j]=Σ_k pbyte(base+j*4+k)<<(8k)，落在消息内的字节
pbyte(...)==m[i]；小端机上 b 的字节序列就是 m[base..base+128)。

单翻译单元：产物 glue 是官方源文本原位拼接，禁跨 TU 薄包装。

用法：python3 gen_blk32_v3.py        （gen + build + sha）
No timing anywhere.
"""
import hashlib
import importlib.util
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

NEW_BLK32 = r'''static void blk32(const unsigned char*m,unsigned long long L,unsigned long long tot,unsigned long long t,uint32_t*b){
    unsigned long long base=t*128ull;
    unsigned long long full=L>>3;              /* complete message bytes       */
    unsigned long long nm=0;

    if(full>base){ nm=full-base; if(nm>128ull)nm=128ull; }

    if(nm==128ull){
        /* 满块：常量长度 memcpy -> 向量搬移，无变长分支 */
        __builtin_memcpy(b,m+base,128);
        return;
    }

    /* 尾块：官方常量界循环逐字保留（gcc 全展开，短消息形状与官方同） */
    {
        unsigned long long base1=base;
        unsigned j,k;
        for(j=0;j<V;j++){uint32_t w=0;for(k=0;k<4;k++)w|=(uint32_t)pbyte(m,L,tot,base1+j*4+k)<<(8*k);b[j]=w;}
    }
}
'''


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    B = load("build_qsh", os.path.join(HERE, "build_qsh.py"))

    # v3 glue 已经是「官方源 + blk64 v3」的单 TU；在其上再替换 blk32。
    src_glue = os.path.join(HERE, "glue_qsh1024_v3.c")
    text = open(src_glue, encoding="utf-8").read()
    if text.count("static void blk32(") != 1:
        raise SystemExit("FATAL: blk32 signature count != 1")
    before, removed, after = B.cut_function(text, "static void blk32(")
    if "pbyte" not in removed or "128ull" not in removed:
        raise SystemExit("FATAL: unexpected original blk32 body")
    out = before + NEW_BLK32.rstrip() + "\n" + after

    dst_glue = os.path.join(HERE, "glue_qsh512_v3.c")
    with open(dst_glue, "w", encoding="utf-8") as f:
        f.write(out)
    # blk64 v3 必须仍在（768/1024 路径不能被破坏）
    if "__builtin_memcpy(b,m+base,256)" not in out:
        raise SystemExit("FATAL: blk64 v3 fast path lost")
    print("gen   -> %s (%d B, sha256 %s)" % (dst_glue, len(out.encode()), sha256(dst_glue)[:32]))

    dst_so = os.path.join(HERE, "out", "ours_qsh512_v3.so")
    os.makedirs(os.path.dirname(dst_so), exist_ok=True)
    cmd = ["gcc"] + B.FLAGS + ["-shared", "-fPIC", "-I", B.SRCDIR, "-o", dst_so, dst_glue, "-lm"]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        print("BUILD FAILED:\n" + p.stdout[:3000])
        return 1
    warn = [l for l in p.stdout.splitlines() if "warning" in l.lower()]
    print("build -> %s (%d B, sha256 %s)" % (dst_so, os.path.getsize(dst_so), sha256(dst_so)))
    print("        warnings: %d" % len(warn))
    for w in warn[:6]:
        print("          " + w)
    nm = subprocess.run(["nm", "-D", "-u", dst_so], stdout=subprocess.PIPE,
                        text=True).stdout
    bad = [l for l in nm.splitlines() if "CryptHash" in l]
    if bad:
        print("FATAL: undefined CryptHash: %s" % bad)
        return 1
    dis = subprocess.run(["objdump", "-d", "--no-show-raw-insn", dst_so],
                         stdout=subprocess.PIPE, text=True).stdout
    calls = [l for l in dis.splitlines() if "call" in l and "memcpy" in l]
    print("        call-memcpy 条数 = %d" % len(calls))
    return 0


if __name__ == "__main__":
    sys.exit(main())
