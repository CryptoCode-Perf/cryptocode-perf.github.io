#!/usr/bin/env python3
"""build_qsh.py -- assemble and build OUR QSH-1024 delivery artifact.

Architecture (single translation unit -- this project has been burned three times
by cross-TU wrapper layers, see TASK notes, so the replacement text is SPLICED
into the official source text and compiled as ONE TU):

   glue_qsh1024.c  =  official Optimized-implementation source
                      with the body of blk64() replaced by gen/ours_blk.c

Everything else -- the round function E3_64, G64, the tree, the length logic --
is kept verbatim from the official source, which is what makes the G1 same-TU
comparison meaningful and keeps "two sides from one source" false-ratio risk away
(the OPPONENT is this same file unmodified; our artifact differs from it by
exactly the blk64 body, so the measured ratio is the effect of that change).

Subcommands:
  gen     write glue_qsh1024.c
  build   gcc with the official ten flags -> out/ours_qsh1024.so, then nm -D -u
  asm     objdump the artifact, dump probe/ours.asm
  all     gen + build + asm

No timing anywhere.
"""

import hashlib
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))     # _overnight/l0/qsh
L0 = os.path.dirname(HERE)                            # _overnight/l0

SRCDIR = os.path.join(L0, "src", "hash-24", "QSH", "Implementations",
                      "03_Implementations", "2_Optimized_Implementation", "QSH-1024")
OPT_SRC = os.path.join(SRCDIR, "CryptHash_AlgorithmInstance.c")

GLUE = os.path.join(HERE, "glue_qsh1024.c")
OURS_BLK = os.path.join(HERE, "gen", "ours_blk.c")
OUT = os.path.join(HERE, "out", "ours_qsh1024.so")
ASM = os.path.join(HERE, "probe", "ours.asm")

# The official ten flags -- verbatim, in the official order.
FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def cut_function(text, signature):
    """Split out a whole C function definition, by brace balancing (never line numbers).

    Returns (before, removed, after) so the caller can splice a replacement *in
    place*.  Appending the replacement at the end of the file instead would put
    the definition after its callers and break -Wimplicit-function-declaration.
    """
    i = text.index(signature)
    j = text.index("{", i + len(signature) - 1)
    depth = 0
    k = j
    while k < len(text):
        if text[k] == "{":
            depth += 1
        elif text[k] == "}":
            depth -= 1
            if depth == 0:
                break
        k += 1
    return text[:i], text[i:k + 1], text[k + 1:]


def make_glue():
    text = open(OPT_SRC, encoding="utf-8").read()
    our = open(OURS_BLK, encoding="utf-8").read().rstrip() + "\n"
    sig = "static void blk64("
    before, removed, after = cut_function(text, sig)
    if "pbyte" not in removed:
        raise SystemExit("blk64 did not contain the expected pbyte call")
    out = before + our + after
    with open(GLUE, "w", encoding="utf-8") as f:
        f.write(out)
    return out


def run(cmd, to=None):
    log = to or "/tmp/qsh_build.log"
    with open(log, "w") as lf:
        rc = subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT).returncode
    with open(log) as lf:
        return rc, lf.read()


def cmd_gen():
    out = make_glue()
    print("gen   -> %s (%d B, sha256 %s)" % (GLUE, len(out.encode()), sha256(GLUE)[:32]))
    return 0


def cmd_build():
    if not os.path.exists(GLUE):
        cmd_gen()
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    cmd = (["gcc"] + FLAGS + ["-shared", "-fPIC", "-I", SRCDIR, "-o", OUT, GLUE, "-lm"])
    rc, log = run(cmd)
    if rc != 0:
        print("BUILD FAILED rc=%d\n%s" % (rc, log[:3000]))
        return 1
    warn = [l for l in log.splitlines() if "warning" in l.lower()]
    print("build -> %s (%d B, sha256 %s)" % (OUT, os.path.getsize(OUT), sha256(OUT)))
    print("        warnings: %d" % len(warn))
    for w in warn[:6]:
        print("          " + w)

    # gcc -shared does NOT report undefined symbols: check explicitly.
    rc2, nm = run(["nm", "-D", "-u", OUT])
    bad = [l for l in nm.splitlines() if "chash" in l or "CryptHash" in l]
    undef = [l for l in nm.splitlines() if l.strip()]
    print("        undefined symbols: %d; of them chash/CryptHash: %d" % (len(undef), len(bad)))
    if bad:
        print("        *** UNDEFINED CORE SYMBOL -- refusing to ship ***")
        return 1
    return 0


def cmd_asm():
    if not os.path.exists(OUT):
        cmd_build()
    rc, out = run(["objdump", "-d", "--no-show-raw-insn", OUT], to=ASM)
    if rc != 0:
        print("objdump failed")
        return 1
    print("asm   -> %s (%d B)" % (ASM, os.path.getsize(ASM)))
    return 0


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    cmd = sys.argv[1]
    if cmd == "gen":
        return cmd_gen()
    if cmd == "build":
        return cmd_build()
    if cmd == "asm":
        return cmd_asm()
    if cmd == "all":
        rc = cmd_gen() or cmd_build()
        if rc:
            return rc
        return cmd_asm()
    print("unknown subcommand %r" % cmd)
    return 2


if __name__ == "__main__":
    sys.exit(main())
