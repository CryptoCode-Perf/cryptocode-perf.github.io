/* ours_blk_v3.c -- QSH-1024 `blk64` 的第三版替换：满块走常量长度拷贝，尾块**照抄官方**

 * 为什么 v1/v2 的短消息都亏 6–8%（captain 实测，8 档）：
 *   v1  32 位 1.0607 … 65536 位 0.9337
 *   v2  32 位 1.0771 … 65536 位 0.9239（长消息更好、短消息更差）
 *   —— 症结不在「拷贝多少字节」，而在**代码形状**：官方那两个循环的边界
 *   （`j<V`、`k<8`）全是编译期常量，gcc 把 256 次 `pbyte` **全展开成直线代码**；
 *   而 v1/v2 的尾巴是 `for(k=nm;k<256;k++)`，起点是运行时变量 ⇒ 只能留成真循环，
 *   每次迭代重新算 `f=L>>3`、`r=L&7`、`tot-16` 并走三分支。
 *   短消息只有 1 个块且必然是「尾块」⇒ 100% 走这条慢形状；长消息几乎全是满块 ⇒ 只吃收益。

 * 本版策略：**只在「整块都落在消息内」时改写，其余一字不动地保留官方代码形状**。
 *   - `nm==256`（满块）：常量长度 `__builtin_memcpy(b,m+base,256)` ⇒ 内联成向量搬移；
 *   - 否则（尾块，每条消息最多一个）：**逐字复刻官方那两个常量界循环**，
 *     gcc 同样全展开 ⇒ 短消息与官方代码逐指令同形。

 * 语义：`b[j]=Σ_k pbyte(base+j*8+k)<<(8k)`，落在消息内的字节 `pbyte(...)==m[i]`，
 * 小端机上 256 字节就是消息原字节按序排列。尾块里对消息内字节调 pbyte 也返回 m[i]，
 * 所以「不改尾块」不损失正确性，只损失那里本可省的少量指令。
 */
static void blk64(const unsigned char*m,unsigned long long L,unsigned long long tot,unsigned long long t,uint64_t*b){
    unsigned long long base=t*256ull;
    unsigned long long full=L>>3;              /* complete message bytes       */
    unsigned long long nm=0;

    if(full>base){ nm=full-base; if(nm>256ull)nm=256ull; }

    if(nm==256ull){
        /* 满块：常量长度 ⇒ 向量搬移，无 libc 调用、无变长分支 */
        __builtin_memcpy(b,m+base,256);
        return;
    }

    /* 尾块：与官方**逐字相同**的常量界循环（gcc 全展开）。
       保留独立的一对大括号，避免与外部同名变量冲突。 */
    {
        unsigned long long base1=base;
        unsigned j,k;
        for(j=0;j<V;j++){uint64_t w=0;for(k=0;k<8;k++)w|=(uint64_t)pbyte(m,L,tot,base1+j*8+k)<<(8*k);b[j]=w;}
    }
}
