# -*- coding: utf-8 -*-
"""构建 QSH-1024 的 v3 交付件（满块走常量长度拷贝，尾块照抄官方）。

为什么需要这个脚本（真实缺陷）
`out/ours_qsh1024_v3.so` 是 `c75add64` 提交进来的**交付件**，同批还带来了
`gen/ours_blk_v3.c` 与 `glue_qsh1024_v3.c` 两份**源**，但**没有带来构建脚本** ——
仓库里只有 `build_v2.py`（产 v2）。于是这一件在复算普查里被判成
`named_fmt: build_v2.py`，而 `build_v2.py` 根本不产 v3：
它的 `B.OURS_BLK / B.GLUE / B.OUT` 三个路径全指向 `_v2`。

那份 `named_fmt` 判定本身就是**普查器的误判**（`_norm_name` 把 `_v2` / `_v3` 里的
数字一起折成 `#`，两代名字折叠后相同）。误判的方向很危险：它让一件**没有配方**的
交付件看起来「有入口」。

本脚本补的就是那个配方，做法与 `build_v2.py` 完全相同（把 `build_qsh` 当模块导入、
改三个路径、调它自己的 `cmd_gen()` + `cmd_build()`），只是三个路径指向 `_v3`：
- `B.OURS_BLK = gen/ours_blk_v3.c`
- `B.GLUE     = glue_qsh1024_v3.c`
- `B.OUT      = out/ours_qsh1024_v3.so`
- `-I` 目录与十个旗标全部沿用 `build_qsh`，不自己另写一份（两份实现必然漂开）。

**这个配方不是猜的，是证过的**：先手工用同样的源 + 十个旗标编译一次，得到的
sha256 `2fd0f96a276acac359daecd032e4392e4669b02c85f165e547836e1f744b0574`
与交付件**逐字节相同**，然后才把它写成脚本。顺序是「先证明、再落成脚本」，
不是「先写脚本、再看它过不过」。

产物：`qsh/out/ours_qsh1024_v3.so`（不覆盖 v1/v2）。
用法：python3 qsh/build_v3.py
"""
import importlib.util
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    B = load("build_qsh", os.path.join(HERE, "build_qsh.py"))
    B.OURS_BLK = os.path.join(HERE, "gen", "ours_blk_v3.c")
    B.GLUE = os.path.join(HERE, "glue_qsh1024_v3.c")
    B.OUT = os.path.join(HERE, "out", "ours_qsh1024_v3.so")
    B.ASM = os.path.join(HERE, "probe", "ours_v3.asm")

    rc = B.cmd_gen()
    if rc:
        return rc
    rc = B.cmd_build()
    if rc:
        return rc

    # 判据：满块应当是常量长度拷贝 —— 出现大量 memcpy 调用说明没内联，
    # v3 的前提（满块走向量搬移）就不成立。
    p = subprocess.run(["objdump", "-d", "--no-show-raw-insn", B.OUT],
                       stdout=subprocess.PIPE, text=True)
    calls = [l.strip() for l in p.stdout.splitlines() if "call" in l and "memcpy" in l]
    print("call-memcpy 条数 = %d %s" % (len(calls), "" if not calls else "⚠ 满块没内联"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
