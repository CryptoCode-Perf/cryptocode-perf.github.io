#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QSH 三档共用库的 blk32 满块快路径门禁：三档全量 KAT + ISA + 同 TU 对拍。

No timing anywhere. 严格只读比较。

用法：python3 gate_blk32_v3.py
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
QSH = HERE
L0 = os.path.dirname(QSH)
WORK = os.path.abspath(os.path.join(L0, "..", ".."))

sys.path.insert(0, WORK)
sys.path.insert(0, os.path.join(WORK, "_std"))
sys.path.insert(0, L0)
import _kat_full as KF  # noqa: E402
import kat_gate as KG  # noqa: E402

SO = os.path.join(QSH, "out", "ours_qsh512_v3.so")
FORBIDDEN = ("rorx", "andn", "shlx", "shrx", "sarx", "bzhi", "pdep", "pext",
             "vaesenc", "vaesdec", "vaesenclast", "vaesdeclast", "vpternlog",
             "vprol", "vpror", "vplzcnt", "kmov", "vpmullq")


def isa(path):
    p = subprocess.run(["objdump", "-d", path], stdout=subprocess.PIPE,
                       stderr=subprocess.DEVNULL, text=True)
    dis = p.stdout
    counts = {}
    for m in FORBIDDEN:
        n = sum(1 for ln in dis.splitlines() if ("\t" + m + " ") in ln or (" " + m + " ") in ln)
        if n:
            counts[m] = n
    ymm = sum(1 for ln in dis.splitlines() if "%ymm" in ln)
    zmm = sum(1 for ln in dis.splitlines() if "%zmm" in ln)
    return counts, ymm, zmm


def main():
    if not os.path.exists(SO):
        print("FATAL: missing %s" % SO)
        return 2
    size = os.path.getsize(SO)
    counts, ymm, zmm = isa(SO)
    print("so       : %s (%d B)" % (os.path.basename(SO), size))
    print("forbidden: %s  ymm=%d zmm=%d" % (counts if counts else "0", ymm, zmm))
    if counts or zmm:
        print("FATAL: forbidden/AVX512 instruction present")
        return 4

    rc_all = 0
    for bits, inst in [(512, "QSH-512"), (768, "QSH-768"), (1024, "QSH-1024")]:
        recs, used = KG.find_kat("hash-24", inst)
        n, m, first, err = KF.check_all(SO, recs)
        ok = (n == m and first is None and err is None)
        print("%-10s KAT %d/%d  first=%s err=%s  %s  kat=%s" % (
            inst, m, n, first, err, "PASS" if ok else "FAIL", used))
        if not ok:
            rc_all = 3
    return rc_all


if __name__ == "__main__":
    sys.exit(main())
