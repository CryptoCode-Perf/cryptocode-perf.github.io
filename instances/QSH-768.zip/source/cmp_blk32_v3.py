#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QSH blk32 快路径：多长度逐字节对拍（含非整字节 + 摘要外哨兵越界检测）。

ours = out/ours_qsh512_v3.so（blk32 满块 memcpy 版）
对照 = build/hash-24/qsh<bits>/{ref,opt}.so 与现网 libh24_ours.so（旧件）
三档 × 21 长度，摘要必须 ours == ref == opt == 旧件，且摘要外 0xAA 哨兵不被覆盖。

No timing.
"""
import ctypes
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
QSH = HERE
L0 = os.path.dirname(QSH)
WORK = os.path.abspath(os.path.join(L0, "..", ".."))

OURS = os.path.join(QSH, "out", "ours_qsh512_v3.so")
OLD = os.path.join(WORK, "_std", "out", "so", "libh24_ours.so")
LENS = [0, 1, 7, 8, 63, 64, 127, 128, 511, 512, 1000, 1023, 1024, 1025,
        2048, 4095, 4096, 4097, 8192, 16384, 65536]


def load(path):
    fn = ctypes.CDLL(os.path.abspath(path)).CryptHash
    fn.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_ulonglong, ctypes.c_void_p]
    fn.restype = ctypes.c_int
    return fn


def dig(fn, bits, nbytes, sentinel=0xAA, bufsize=512):
    msg = bytes(((i * 7 + 1) & 0xFF) for i in range(nbytes))
    buf = ctypes.create_string_buffer(bytes([sentinel]) * bufsize)
    rc = fn(bits, msg if nbytes else None, nbytes * 8, buf)
    raw = buf.raw
    want = bits // 8
    over = next((i for i in range(want, bufsize) if raw[i] != sentinel), None)
    return rc, raw[:want], over


def main():
    paths = {"ours": OURS, "old": OLD}
    for b in (512, 768, 1024):
        for k in ("ref", "opt"):
            paths["%s_%d" % (k, b)] = os.path.join(L0, "build", "hash-24", "qsh%d" % b, k + ".so")
    for name, p in paths.items():
        if not os.path.exists(p):
            print("FATAL missing %s: %s" % (name, p))
            return 2
    fn = {name: load(p) for name, p in paths.items()}

    npass = nfail = 0
    for bits in (512, 768, 1024):
        for nb in LENS:
            res = {name: dig(f, bits, nb) for name, f in fn.items()}
            digs = {name: v[1] for name, v in res.items()}
            same = len(set(digs.values())) == 1
            rcs_ok = all(v[0] == 0 for v in res.values())
            over = {name: v[2] for name, v in res.items() if v[2] is not None}
            if same and rcs_ok and not over:
                npass += 1
            else:
                nfail += 1
                print("FAIL bits=%d bytes=%d same=%s rcs=%s over=%s" % (
                    bits, nb, same, {n: v[0] for n, v in res.items()}, over))
    print("TOTAL: %d pass, %d fail (3 tiers x %d lengths)" % (npass, nfail, len(LENS)))
    return 0 if nfail == 0 else 3


if __name__ == "__main__":
    sys.exit(main())
