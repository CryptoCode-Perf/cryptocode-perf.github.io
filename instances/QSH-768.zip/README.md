# QSH-768

Algorithm: QSH | Digest bits: 768 | Form: AVX2 C

Contents: implementation source/, public header QSH-768.h, prebuilt QSH-768.so,
KAT vector KAT_2_12_QSH-768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 942b95666f743eb6ee52bd0bdd396ce1ecc0a1d8e9637aea91cbe74055e27832
Speed (cpB, lower is faster): reference 192.40 / official-optimized 11.37 / optimized 10.53
Speedup: GM(S1-S8) 1.05x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
