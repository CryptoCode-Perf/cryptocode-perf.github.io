#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for name in MoFang-256 MoFang-256-XOF MoFang-512 MoFang-768 MoFang-768-XOF MoFang-1024; do
 for kind in Reference Optimized CryptoCode; do
  d="${kind}_Implementation/$name"; source=CryptHash_AlgorithmInstance.c; extra=()
  if [ "$kind" = Reference ]; then flags=-O2; else flags="-O3 -mavx2"; fi
  if [ "$kind" = CryptoCode ]; then
   case "$name" in
    MoFang-256) source=glue_mofang256drv.c;;
    MoFang-256-XOF) source=glue_mofang256xofdrv.c;;
    MoFang-768) source=glue_mofang768_v3b.c; extra=("$d/mofang_keys_v3.s" "$d/mofang_state_v3.s");;
    MoFang-768-XOF) source=glue_mofang768xof_v3b.c; extra=("$d/mofang_keys_v3.s" "$d/mofang_state_v3.s");;
    MoFang-1024) source=glue_mofang1024_v3b.c; extra=("$d/mofang_keys_v3.s" "$d/mofang_state_v3.s");;
   esac
  fi
  gcc $flags -fPIC -shared -Wl,-z,defs -I"$d" "$d/$source" "${extra[@]}" -o "build/$kind-$name.so"
  python3 "test/$name.py" "build/$kind-$name.so" 100000 0 "kat/$name.txt"
 done
done

gcc -O2 test/guard_check.c -ldl -o build/guard_check
build/guard_check build/CryptoCode-MoFang-256.so 256
build/guard_check build/CryptoCode-MoFang-256-XOF.so 256
build/guard_check build/CryptoCode-MoFang-512.so 512
build/guard_check build/CryptoCode-MoFang-768.so 768
build/guard_check build/CryptoCode-MoFang-768-XOF.so 768
build/guard_check build/CryptoCode-MoFang-1024.so 1024

python3 test/differential.py
