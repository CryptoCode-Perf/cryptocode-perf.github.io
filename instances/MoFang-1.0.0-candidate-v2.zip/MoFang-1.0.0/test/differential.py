from pathlib import Path
import ctypes,random,json
r=Path(__file__).resolve().parent.parent;rng=random.Random(20261127);results=[]
for name,bits in [('MoFang-256',256),('MoFang-256-XOF',256),('MoFang-512',512),('MoFang-768',768),('MoFang-768-XOF',768),('MoFang-1024',1024)]:
 libs=[ctypes.CDLL(str(r/'build'/f'{kind}-{name}.so')) for kind in ('Reference','CryptoCode')]
 for lib in libs:lib.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];lib.CryptHash.restype=ctypes.c_int
 outputs=[bits] if 'XOF' not in name else [1,7,8,9,127,128,bits-1,bits,bits+1,776,1024,1536]
 failures=[];count=0
 for ob in outputs:
  for n in [0,1,7,8,9,511,512,513,767,768,769,1151,1152,1153,4095,4096,4097,65535,65536,65537]+[rng.randrange(131073) for _ in range(100)]:
   msg=ctypes.create_string_buffer(rng.randbytes((n+7)//8) or b'\0');values=[]
   for lib in libs:
    dst=ctypes.create_string_buffer((ob+7)//8);rc=lib.CryptHash(ob,msg,n,dst);values.append((rc,dst.raw))
   if values[0][0]!=0 or values[1][0]!=0 or values[0][1]!=values[1][1]:failures.append([ob,n])
   count+=1
 results.append({'instance':name,'cases':count,'failures':failures});print(name,count,'failures',len(failures),flush=True)
(r/'build/differential.json').write_text(json.dumps(results,indent=2))
if any(x['failures'] for x in results):raise SystemExit(1)
