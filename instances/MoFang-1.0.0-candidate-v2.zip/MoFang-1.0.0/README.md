# MoFang candidate package

Includes 256, 256-XOF, 512, 768, 768-XOF and 1024 instances. On x86-64 Linux
with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`. It rebuilds the
three implementation families, checks full provided KAT, selected reference
differential cases and input/output guard pages. XOF differential checks cover selected byte-aligned and non-byte-aligned
output lengths; they do not establish all possible output lengths.

Candidate only: performance comparison, release review and upstream
redistribution permissions remain pending. Tests do not prove security.
