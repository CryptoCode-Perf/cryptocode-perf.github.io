from pathlib import Path
import ctypes,random,json
r=Path('/mnt/c/CryptoCode-release/MoFang-1.0.0-candidate');libs=[ctypes.CDLL(str(r/'build'/n)) for n in ('reference-768-xof.so','MoFang-768-XOF.so')]
for l in libs:l.CryptHash.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_ulonglong,ctypes.c_void_p];l.CryptHash.restype=ctypes.c_int
rng=random.Random(1234);out=[]
for ob in [8,128,256,512,768,776,1024,1536]:
 fails=[]
 for n in [0,1,7,8,9,1151,1152,1153,4096]:
  msg=ctypes.create_string_buffer(rng.randbytes((n+7)//8) or b'\0');res=[]
  for l in libs:
   dst=ctypes.create_string_buffer((ob+7)//8);rc=l.CryptHash(ob,msg,n,dst);res.append((rc,dst.raw))
  if res[0]!=res[1]:fails.append(n)
 out.append({'output_bits':ob,'failures':fails});print(ob,'failures',fails)
(r/'build/xof-differential.json').write_text(json.dumps(out,indent=2))
