# Garnet candidate package

This candidate covers Garnet-768 only. Other Garnet instances are not included.
On x86-64 Linux with GCC, GNU objcopy, Python 3 and AVX2, run
`bash build_and_verify.sh`. This builds three implementations, checks all
4097 known-answer vectors, runs deterministic long and boundary differential
tests, and tests selected input and output boundaries using guard pages.

The optimized assembly is linked with a test adapter derived from the
reference 768-bit wrapper. It uses the same padding operation; 512- and
1024-bit stubs are present only to satisfy the shared dispatcher and return
an error. The adapter is not an upstream supplied optimized API.

Candidate only: fastest-implementation comparison, independent adapter review,
upstream redistribution permissions and final release review are pending.
These tests do not prove security or cover all inputs and environments.
