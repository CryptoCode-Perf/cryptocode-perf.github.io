#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
ref=Reference_Implementation/Garnet
opt=Optimized_Implementation/Garnet_768
ours=CryptoCode_Implementation/Garnet-768
for kind in Reference Optimized CryptoCode; do
 case "$kind" in
  Reference) gcc -O2 -fPIC -shared -Wl,-z,defs -I"$ref" -I"$ref/include" "$ref/CryptHash_Garnet.c" "$ref/Garnet_768.c" "$ours/stubs.c" -o "build/$kind-768.so";;
  Optimized)
   gcc -O3 -mavx2 -fPIC -c "$opt/Garnet_768.S" -o build/optimized-asm.o
   objcopy --localize-symbol=TE0 --localize-symbol=TE1 --localize-symbol=TE2 --localize-symbol=TE3 build/optimized-asm.o
   gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$ref" -I"$ref/include" "$ref/CryptHash_Garnet.c" test/opt_wrapper.c build/optimized-asm.o "$ours/stubs.c" -o "build/$kind-768.so";;
  CryptoCode) gcc -O3 -mavx2 -fPIC -shared -Wl,-z,defs -I"$ref" -I"$ref/include" "$ref/CryptHash_Garnet.c" "$ours/core.c" "$ours/stubs.c" -o "build/$kind-768.so";;
 esac
 python3 test/kat_768.py "build/$kind-768.so" 100000 0 kat/Garnet-768.txt
done

python3 test/differential.py
gcc -O2 test/guard_check.c -ldl -o build/guard_check
for kind in Reference Optimized CryptoCode; do
 ./build/guard_check "./build/$kind-768.so" 768
done
