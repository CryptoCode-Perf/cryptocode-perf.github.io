/* 自动生成：Garnet 官方胶水固定引用 CryptHash_512/768/1024 三个入口，
 * 而每个容量变体只实现其中一个。这里把没实现的两个补成返回 -1 的桩，
 * 保证「被调用的入口一定真的是那个容量的实现」。 */
#include <stddef.h>
int CryptHash_512(const unsigned char *m, unsigned long long b, unsigned char *d){ (void)m; (void)b; (void)d; return -1; }
int CryptHash_1024(const unsigned char *m, unsigned long long b, unsigned char *d){ (void)m; (void)b; (void)d; return -1; }
