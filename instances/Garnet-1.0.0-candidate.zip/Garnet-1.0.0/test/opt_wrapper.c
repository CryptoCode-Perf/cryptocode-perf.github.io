#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "Garnet_768.h"
static void pad_message(unsigned char *msg, uint64_t bit_len) { unsigned rem=bit_len%8; msg[bit_len/8] &= (unsigned char)(0xffu << (8-rem)); msg[bit_len/8] |= (unsigned char)(0x80u >> rem); }
 int CryptHash_768(const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *digest) {
    size_t msg_len_bytes = (msg_len_bits + 7) / 8;
    size_t alloc_size = msg_len_bytes + 256;
    uint8_t *temp_msg = (uint8_t *)calloc(alloc_size, sizeof(uint8_t));
    if (!temp_msg) return -1;

    if (msg_len_bytes > 0 && msg != NULL) {
        memcpy(temp_msg, msg, msg_len_bytes);
    }

    pad_message(temp_msg, msg_len_bits);

    struct garnet_u128_t state_c[STATE_4x4];
    memset(state_c, 0, sizeof(state_c));

    Garnet_768(temp_msg, msg_len_bits, digest, state_c);

    free(temp_msg);
    return 0;
}






