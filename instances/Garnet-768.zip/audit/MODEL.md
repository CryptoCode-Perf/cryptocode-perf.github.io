# Garnet — 结构与优化模型

结构判据来自各实例官方参考源（随包 `Reference_Implementation/`），优化机制来自交付清单原文（见 `RESULT.md`）。

## Garnet-768
- 摘要位：768；实现形态：标量 C
- 官方参考源码：随包 `Reference_Implementation/Garnet-768/`
- 官方优化源码：随包 `Official_Optimized_Implementation/Garnet-768/`
- Agent 实现源码：随包 `Optimized_Implementation/x86_AVX2/Garnet-768/`
- 优化要点：选表方式改成纯标量：官方优化版用 `_mm256_blendv_epi8` 在 16 段 S 盒表里选，`vpblendvb ymm` 是 2 uops 且 `vpshufb` 已吃满 p5 端口（每轮 p5 342 条 = 唯一约束）；本件把选表搬到标量侧，p5 压力全消。v1（改 or(and) 选表）实测 1.1415、v2 SIMD 件实测 1.1533，两件都输，只有标量件成立。全部 4097 条 KAT 通过，`delivery_gate.py` 11 个位长全过。
