# Garnet — 交付结果（源自 NGCC 标准实例交付清单）

本文件的 cpB / 加速比 / sha256 均逐字转录自 `perf-report/attachments/MANIFEST.csv`，非估算。计时由 lead 装置实测。

## 交付件 sha256

| 实例 | so 文件 | 大小 | sha256 |
| --- | --- | --- | --- |
| Garnet-768 | `Garnet-768.so` | 28224 B | `54aab183816ca3b88edad907199446d9c6373cc9fea18f96df9af4f5f6b8f32c` |

## 验证与加速比

每实例：全量 KAT 4097/4097 + `delivery_gate.py` 11 个位长全过。加速比口径 = 我方 cpB ÷ 官方优化 cpB（S4），几何平均覆盖 S1–S8。

| 实例 | 摘要位 | 参考 cpB | 官方优化 cpB | 我方 cpB | S4 加速比 | GM |
| --- | --- | --- | --- | --- | --- | --- |
| Garnet-768 | 768 | 32.1904 | 32.3018 | 27.963668 | 1.155135 | 1.1513 |

## 优化方法（逐实例原文，来自交付清单）

### Garnet-768
选表方式改成纯标量：官方优化版用 `_mm256_blendv_epi8` 在 16 段 S 盒表里选，`vpblendvb ymm` 是 2 uops 且 `vpshufb` 已吃满 p5 端口（每轮 p5 342 条 = 唯一约束）；本件把选表搬到标量侧，p5 压力全消。v1（改 or(and) 选表）实测 1.1415、v2 SIMD 件实测 1.1533，两件都输，只有标量件成立。全部 4097 条 KAT 通过，`delivery_gate.py` 11 个位长全过。
