# Garnet-768

Algorithm: Garnet | Digest bits: 768 | Form: 标量 C

Contents: implementation source/, public header Garnet-768.h, prebuilt Garnet-768.so,
KAT vector KAT_2_12_Garnet_768.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 54aab183816ca3b88edad907199446d9c6373cc9fea18f96df9af4f5f6b8f32c
Speed (cpB, lower is faster): reference 32.19 / official-optimized 32.30 / optimized 27.96
Speedup: GM(S1-S8) 1.15x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
