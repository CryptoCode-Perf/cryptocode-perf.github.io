/* Diagnostic 768-only bridge; core is unchanged original reference. */
#include "Garnet_768.h"
extern int CryptHash_768(const unsigned char *, unsigned long long, unsigned char *);
int CryptHash(int digest_bits,const unsigned char *msg,unsigned long long bits,unsigned char *digest) {
 if (digest_bits != 768) return -1;
 return CryptHash_768(msg,bits,digest);
}
