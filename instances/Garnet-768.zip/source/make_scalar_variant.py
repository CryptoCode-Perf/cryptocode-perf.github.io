#!/usr/bin/env python3
"""garnet768b -- A/B control: the *scalar L1 T-table* subword.

The captain's hypothesis for Garnet-768 v2 was "stop emulating the table lookup
in AVX2; do the reference T-table lookup from L1 and keep the packing".  This
script builds exactly that variant so the claim can be judged on numbers
instead of on argument:

  * subword_4x4_st  -> 16 lanes of the reference scalar T-table AES round
                        (TE0/TE1/TE2/TE3, 4 KiB of .rodata, L1-resident)
  * AddRoundKey     -> folded into the vector part (one vpxor per ymm covers
                        all 16 lanes at once, instead of 16*4 scalar xors)
  * mix_column / add_constant / mix_diagonal -> unchanged, still AVX2 (v1/v2)

The scalar round is taken verbatim from the reference build order, so the only
thing that changes relative to v2 is *who* performs the byte lookup.
"""
import hashlib
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)
REF = os.path.join(L0, "src", "hash-11", "Garnet", "Implementations",
                   "API_CryptHash", "Implementations",
                   "Reference_Implementation", "Garnet")
STUBS = os.path.join(L0, "build", "hash-11", "garnet-768", "stubs.c")
CORE = os.path.join(HERE, "garnet768_core.c")
FULL_C = os.path.join(REF, "Garnet_768.c")
SCRATCH = os.path.join(HERE, "scratch")
OUT = os.path.join(HERE, "out")

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]


def parse_te0(text):
    m = re.search(r"TE0\s*\[\s*1024\s*\]\s*=\s*\{(.*?)\}\s*;", text, re.S)
    assert m, "TE0[1024] not found in the reference source"
    body = re.sub(r"/\*.*?\*/", " ", m.group(1), flags=re.S)
    body = re.sub(r"//[^\n]*", " ", body)
    vals = re.findall(r"0[xX][0-9a-fA-F]+|\d+", body)
    assert len(vals) == 1024, "TE0 body has %d entries, expected 1024" % len(vals)
    b = [int(v, 0) & 0xFF for v in vals]
    u32 = [b[4 * x] | (b[4 * x + 1] << 8) | (b[4 * x + 2] << 16) |
           (b[4 * x + 3] << 24) for x in range(256)]
    return b, u32


def rotl32(v, n):
    return ((v << n) | (v >> (32 - n))) & 0xFFFFFFFF


def emit_tables(u32):
    out = ["", "/* ---- reference T-tables, extracted from Garnet_768.c:196-283 ---",
           " * TE0[x] = (2*S(x), S(x), S(x), 3*S(x)) little-endian;",
           " * TE1/TE2/TE3 are TE0 rotated left by 8/16/24 bits (Garnet_768.c:286-292).",
           " * Used only by the A/B scalar subword control. */"]
    for name, rot in (("TE0", 0), ("TE1", 8), ("TE2", 16), ("TE3", 24)):
        out.append("static const uint32_t %s[256] = {" % name)
        for row in range(0, 256, 8):
            items = [("0x%08xu" % rotl32(u32[x], rot)) for x in range(row, row + 8)]
            out.append("    " + ", ".join(items) + ",")
        out.append("};")
    return "\n".join(out) + "\n\n"


SCALAR_HELPER = r"""
/* ---- scalar reference subword: 16 lanes of the T-table AES round ---------
 * SubBytes + ShiftRows + MixColumns in one pass, exactly the reference
 * aesround() index pattern (Garnet_768.c:286-292).  AddRoundKey is NOT here:
 * the key is uniform over all lanes, so the caller folds it into one vpxor
 * per ymm (8 of them) instead of 64 scalar xors. */
/* NOTE (measured, not guessed): with a `for (i = 0; i < 16; i++)` loop GCC
 * keeps the loop ROLLED -- the static disassembly then shows only ~40
 * instructions while the dynamic count is ~40*16.  insn_mix cannot see that.
 * The 16 lanes are therefore expanded explicitly, exactly like GT_SUB() in the
 * vector version. */
#define GT_LANE(i) do {                                                  \
        const unsigned char *p = sb + 16 * (i);                          \
        uint32_t a0 = TE0[p[0]],  a1 = TE1[p[5]],  a2 = TE2[p[10]],      \
                 a3 = TE3[p[15]];                                        \
        uint32_t b0 = TE0[p[4]],  b1 = TE1[p[9]],  b2 = TE2[p[14]],      \
                 b3 = TE3[p[3]];                                         \
        uint32_t c0 = TE0[p[8]],  c1 = TE1[p[13]], c2 = TE2[p[2]],       \
                 c3 = TE3[p[7]];                                         \
        uint32_t d0 = TE0[p[12]], d1 = TE1[p[1]],  d2 = TE2[p[6]],       \
                 d3 = TE3[p[11]];                                        \
        uint32_t *o = (uint32_t *)(void *)(sb + 16 * (i));               \
        o[0] = a0 ^ a1 ^ a2 ^ a3;                                        \
        o[1] = b0 ^ b1 ^ b2 ^ b3;                                        \
        o[2] = c0 ^ c1 ^ c2 ^ c3;                                        \
        o[3] = d0 ^ d1 ^ d2 ^ d3;                                        \
    } while (0)

static void gt_subword_scalar(unsigned char *sb)
{
    GT_LANE(0);  GT_LANE(1);  GT_LANE(2);  GT_LANE(3);
    GT_LANE(4);  GT_LANE(5);  GT_LANE(6);  GT_LANE(7);
    GT_LANE(8);  GT_LANE(9);  GT_LANE(10); GT_LANE(11);
    GT_LANE(12); GT_LANE(13); GT_LANE(14); GT_LANE(15);
#undef GT_LANE
}
"""

SUBWORD_OLD = "".join(
    "    s[%d] = gt_aesround(s[%d], key256);\n" % (i, i) for i in range(8))

SUBWORD_NEW = """    /* ---- subword_4x4_st: scalar L1 T-table lookups, then the key once -- */
    {
        uint32_t rk[4];
        unsigned char gtsb[256];
        int gti;
        _mm_store_si128((__m128i *)(void *)rk, _mm256_castsi256_si128(key256));
        (void)rk;
        for (gti = 0; gti < 8; gti++)
            _mm256_storeu_si256((__m256i *)(void *)(gtsb + 32 * gti), s[gti]);
        gt_subword_scalar(gtsb);
        for (gti = 0; gti < 8; gti++) {
            s[gti] = _mm256_loadu_si256((const __m256i *)(const void *)
                                        (gtsb + 32 * gti));
            s[gti] = _mm256_xor_si256(s[gti], key256);
        }
    }
"""


def main():
    ref_text = open(FULL_C).read()
    b, u32 = parse_te0(ref_text)
    # the reference TE0 must agree with the S-box we already validated
    sbox = []
    for x in range(256):
        assert (u32[x] >> 8) & 0xFF == (u32[x] >> 16) & 0xFF, "TE0[%d] malformed" % x
        sbox.append((u32[x] >> 8) & 0xFF)
    print("TE0 parsed: 256 entries, T(x) == (2S,S,S,3S) consistent")

    text = open(CORE).read()
    n = text.count(SUBWORD_OLD)
    assert n == 1, "expected the 8 gt_aesround lines exactly once, found %d" % n

    marker = "/* ---- one full round of permutation_p_4x4_st"
    assert text.count(marker) == 1
    text = text.replace(marker, emit_tables(u32) + SCALAR_HELPER + marker, 1)
    text = text.replace(SUBWORD_OLD, SUBWORD_NEW, 1)
    assert "gt_subword_scalar(gtsb);" in text and "gt_aesround(s[0]" not in text

    os.makedirs(SCRATCH, exist_ok=True)
    os.makedirs(OUT, exist_ok=True)
    src = os.path.join(SCRATCH, "garnet768_core_scalar.c")
    open(src, "w").write(text)
    print("wrote %s (%d bytes, sha256 %s)" %
          (src, len(text), hashlib.sha256(text.encode()).hexdigest()[:16]))

    so = os.path.join(OUT, "ours_garnet768b_scalar.so")
    cmd = ["gcc"] + FLAGS + ["-shared", "-fPIC", "-I" + REF,
                             "-I" + os.path.join(REF, "include"), "-o", so, src,
                             os.path.join(REF, "CryptHash_Garnet.c"), STUBS]
    log = os.path.join(SCRATCH, "build_scalar.log")
    with open(log, "w") as fh:
        rc = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT).returncode
    print("gcc rc=%d (log %s)" % (rc, log))
    if rc != 0:
        print(open(log).read()[-2000:])
        return 1
    print("built %s" % so)
    return 0


if __name__ == "__main__":
    sys.exit(main())
