#!/usr/bin/env bash
# Build OUR Garnet-768 delivery.
#
# The command line is the OFFICIAL TEN FLAGS verbatim (fix11.py OPT_FLAGS),
# with nothing added -- no -maes, no -mvaes, no -march=native.  Everything our
# core uses is covered by -mavx2, which is one of the ten.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
L0="$(cd "$HERE/.." && pwd)"
REF="$L0/src/hash-11/Garnet/Implementations/API_CryptHash/Implementations/Reference_Implementation/Garnet"
STUBS="$L0/build/hash-11/garnet-768/stubs.c"
OUT="$HERE/out"
mkdir -p "$OUT"

FLAGS=(-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer
       -std=c99 -Wpedantic -Wall -Wextra)

echo "gcc ${FLAGS[*]}"
echo "  -shared -fPIC -> $OUT/ours_garnet768b.so"
echo "  sources: garnet768_core.c  $(basename "$REF")/CryptHash_Garnet.c  stubs.c"

gcc "${FLAGS[@]}" -shared -fPIC -I"$REF" -I"$REF/include" \
    -o "$OUT/ours_garnet768b.so" \
    "$HERE/garnet768_core.c" "$REF/CryptHash_Garnet.c" "$STUBS"

# same flags, one TU, no LTO: for static instruction accounting (objdump)
gcc "${FLAGS[@]}" -c -fno-lto -I"$REF" -I"$REF/include" \
    -o "$OUT/garnet768b_core.o" "$HERE/garnet768_core.c"

ls -l "$OUT/ours_garnet768b.so" "$OUT/garnet768b_core.o"
