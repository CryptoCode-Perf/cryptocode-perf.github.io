# QSH-512

Algorithm: QSH | Digest bits: 512 | Form: AVX2 C

Contents: implementation source/, public header QSH-512.h, prebuilt QSH-512.so,
KAT vector KAT_2_12_QSH-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): 942b95666f743eb6ee52bd0bdd396ce1ecc0a1d8e9637aea91cbe74055e27832
Speed (cpB, lower is faster): reference 148.67 / official-optimized 6.33 / optimized 5.72
Speedup: GM(S1-S8) 1.09x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
