# MOZI-512

Algorithm: Mozi | Digest bits: 512 | Form: SSE C++（对手 fast 驱动）

Contents: implementation source/, public header MOZI-512.h, prebuilt MOZI-512.so,
KAT vector KAT_2_12_MOZI-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): f4ba38b999bbcf36e2b43f8756ba0b0397014fc1eb6e80559c5cd31f8b6db11f
Speed (cpB, lower is faster): reference 17.40 / official-optimized 4.87 / optimized 4.52
Speedup: GM(S1-S8) 1.08x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
