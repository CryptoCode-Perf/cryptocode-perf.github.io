# Cuishen candidate package

Instances: Cuishen-512, Cuishen-768 and Cuishen-1024. On x86-64 Linux
with GCC, Python 3 and AVX2, run `bash build_and_verify.sh`. It rebuilds
reference, official optimized assembly and CryptoCode C implementations,
checks 4097 known-answer vectors per implementation, compares deterministic
long and boundary inputs, and checks selected input/output guard pages.
`CryptHash` lengths are in bits.

CryptoCode sources were recovered from the local performance report. Source
generators are included for provenance but are not required or validated by
the build. Candidate only: controlled performance comparisons, independent
source and license review, redistribution permission and final release review
remain pending. Tests do not prove security.
