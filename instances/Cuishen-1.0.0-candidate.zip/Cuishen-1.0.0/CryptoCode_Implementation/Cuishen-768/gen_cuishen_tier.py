#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cuishen/gen_cuishen_tier.py —— 从我方 1024 档交付件派生 Cuishen-768。

## 为什么 768 档能白捡（判据，带行号）

官方两档几乎逐字相同。`diff Reference_Implementation/Cuishen-768/
CryptHash_Cuishen-768.c Reference_Implementation/Cuishen-1024/
CryptHash_Cuishen-1024.c` 只有 44 行，且差异**只有三类**：

  1. `#include "CryptHash_Cuishen-768.h"` vs `-1024.h`
  2. `IV_1[8]` / `IV_2[8]` 两组常数（`:49-57`）
  3. `store768_be(out[96], in[12])` 循环 `i < 12` vs
     `store1024_be(out[128], in[16])` 循环 `i < 16`（`:116-119`、`:410`）

`ROUNDS = 64`、`MESSAGE_WORDS = 16`、`LINK_WORDS = 8`、`MASTER_KEY_WORDS = 24`、
A..H（18/33/47/60/49/20/16/21）、MA..MH（14/43/28/19/29/63/12/6）、BA = 47、
`E_CONST[64]` **两档逐字节相同**（实测首行都是
`0xb7e151628aed2a6a, 0xbf7158809cf4f3c7, 0x62e7160f38b4da56,`）。

所以派生只需四处：`DIGEST_BIT_LENGTH`、两组 IV、`cs_store1024_be` 的名字与宽度、
以及调用点。

512 档**不能**这样派生：`diff Cuishen-512 ... Cuishen-1024` 是 362 行，
`LINK_WORDS = 4`、`ROUND_KEY_WORDS = ROUNDS * 4`、`MASTER_KEY_WORDS = 20`、
轮常数只有 A..D（7/31/56/20）与 BA = 27 —— 是另一套结构，得另写核。

## 用法

    cd feilian/work/_overnight/l0/cuishen && python3 -u gen_cuishen_tier.py 768

产物 `src/cuishen768.c` 与 `out/ours_cuishen768_purec.so`（只用官方十 flag）。
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
L0 = os.path.dirname(HERE)

FLAGS = ["-O3", "-march=x86-64", "-mavx2", "-mtune=native", "-flto",
         "-fomit-frame-pointer", "-std=c99", "-Wpedantic", "-Wall", "-Wextra"]

# 各档的两组 IV，逐字抄自官方 reference .c（:49-57）
IVS = {
    768: (
        (0x34e0d42e61a33f99, 0x87abb9f2087207ed, 0xec3fc3f38a10ea02,
         0x610bebf29db2faf5, 0x7420b49edc5a21ee, 0xd1fd8a3396bdeee8,
         0x092197f60194adc1, 0x1b530c95f8b3def8),
        (0x869d6342f6d22822, 0x11076689f6aff6b0, 0x43ab9fb62162bb7f,
         0x75a9f91d5813e9e8, 0xd7cd8173f479197a, 0x07fe00ff606fac41,
         0x379f513f856fc7a9, 0x66b651a8ab0e883b),
    ),
}

SRC = os.path.join(HERE, "src", "cuishen1024.c")
OUTDIR = os.path.join(HERE, "out")


def sub_once(text, old, new, tag):
    n = text.count(old)
    if n != 1:
        sys.exit("锚点命中 %d 次（应为 1）：%s" % (n, tag))
    return text.replace(old, new)


def fmt_iv(vals, name, per_line=4):
    lines = []
    for i in range(0, len(vals), per_line):
        chunk = ", ".join("0x%016x" % v for v in vals[i:i + per_line])
        lines.append("    " + chunk + ",")
    return "static const uint64_t %s[8] = {\n%s\n};" % (name, "\n".join(lines))


def build(tier):
    bits = tier
    nwords = bits // 64          # 摘要字数：768 → 12
    out_bytes = bits // 8        # 96
    iv1, iv2 = IVS[tier]

    src = open(SRC, encoding="utf-8").read()

    # 1) DIGEST_BIT_LENGTH
    src = sub_once(src, "#define DIGEST_BIT_LENGTH 1024",
                   "#define DIGEST_BIT_LENGTH %d" % bits, "DIGEST_BIT_LENGTH")

    # 2) 两组 IV
    old_iv1_start = "static const uint64_t IV_1[8] = {"
    idx = src.index(old_iv1_start)
    end = src.index("};", idx) + 2
    src = src[:idx] + fmt_iv(iv1, "IV_1") + src[end:]

    idx = src.index("static const uint64_t IV_2[8] = {")
    end = src.index("};", idx) + 2
    src = src[:idx] + fmt_iv(iv2, "IV_2") + src[end:]

    # 3) store 函数：改名 + 换宽度
    src = sub_once(
        src,
        "static void cs_store1024_be(unsigned char out[128], const uint64_t in[16])\n"
        "{\n"
        "    int i;\n"
        "    for (i = 0; i < 16; ++i) {",
        "static void cs_store%d_be(unsigned char out[%d], const uint64_t in[%d])\n"
        "{\n"
        "    int i;\n"
        "    for (i = 0; i < %d; ++i) {" % (bits, out_bytes, nwords, nwords),
        "store 函数")

    # 4) 调用点
    src = sub_once(src, "cs_store1024_be(digest, digest_words);",
                   "cs_store%d_be(digest, digest_words);" % bits, "store 调用点")

    dst = os.path.join(HERE, "src", "cuishen%d.c" % bits)
    open(dst, "w", encoding="utf-8", newline="\n").write(src)
    print("已写 %s（%d B）" % (dst, os.path.getsize(dst)))

    os.makedirs(OUTDIR, exist_ok=True)
    so = os.path.join(OUTDIR, "ours_cuishen%d_purec.so" % bits)
    cmd = (["gcc"] + FLAGS + ["-fPIC", "-shared", "-o", so, dst])
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    msg = r.stdout.decode("utf-8", "replace").strip()
    if r.returncode != 0 or msg:
        print("!! 构建有输出：rc=%d" % r.returncode)
        print(msg[:2000])
        return 3
    print("构建 OK：%s（%d B）" % (so, os.path.getsize(so)))
    return 0


def main():
    if len(sys.argv) != 2 or int(sys.argv[1]) not in IVS:
        print("用法：python3 gen_cuishen_tier.py <tier>   （tier ∈ %s）"
              % sorted(IVS))
        return 2
    return build(int(sys.argv[1]))


if __name__ == "__main__":
    sys.exit(main())
