#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
champ/build_champ512.py —— CHAMP-512 我方交付件的可复现构建（CHAMP-1024 的兄弟档）。

与 CHAMP-1024 同族同病：
  官方 Optimized 的 `CryptHash`（`OPT/...CHAMP-512/...c:583-586`）在**每次调用**里做
  **4 次互相独立的费马求逆**（`invmod` = Fermat 幂，每次 ~127 次平方 + ~100 次乘法），
  4 条串行依赖链；而 CHAMP-512 的状态只有 4 个 u128，吸收路径每字节成本远低于一次求逆
  ⇒ 固定开销占比比 1024 档还高。

我方替换的只有驱动层的**摘要阶段**：
  * 4 次独立求逆 ⇒ **1 次批量求逆**（Montgomery 前缀积：10 次 mulmod + 1 次求逆 = 替掉 3 次求逆）
  * 摘要写出从逐字节存改成 16 次 64 位存（x86 小端 ⇒ 逐字节等价）
吸收路径（`build_small_byte_table` / `process_chunk_aligned_bytes` / `process_scalar_bytes` /
`canonicalize_lazy_u128` / `mulmod` / `Mat2x2` …）全部是官方源码**逐字保留**。

子命令：build | kat | asm
用法：python3 champ/build_champ512.py build
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
L0 = os.path.join(WORK, "_overnight", "l0")
sys.path.insert(0, os.path.join(L0, "mofang"))
import build_mofang as B  # noqa: E402

INT = os.path.join(WORK, "_overnight/l0/src/hash-04/CHAMP/Implementations and Test_Vectors/API_CryptHash/Implementations")
OPTDIR = os.path.join(INT, "Optimized_Implementation", "CHAMP-512")
REFDIR = os.path.join(INT, "Reference_Implementation", "CHAMP-512")
OPTSRC = os.path.join(OPTDIR, "CryptHash_AlgorithmInstance.c")
OPTSO = os.path.join(WORK, "_overnight/l0/build/hash-04/champ512/opt.so")

GLUE = os.path.join(HERE, "glue_champ512.c")
OUTDIR = os.path.join(HERE, "out")
SO = os.path.join(OUTDIR, "ours_champ512.so")

CUT_SIG = "int CryptHash(int digest_len_bits, const unsigned char *msg,"

MY_CODE = r'''
/* =====================================================================
 * 以下为**我方实现**。其上全部内容为官方 Optimized 源码逐字保留。
 *
 * 官方做法（OPT `CHAMP-512/...c:583-586`）：
 *     if (zero) u=0; else invmod(&u, &state[i]);     // ×4，四条链互不重叠
 * 我方做法：一次批量求逆（Montgomery 前缀积）——
 *     b[i]  = (in[i]==0) ? 1 : in[i]
 *     pre[i] = b[0]*...*b[i]
 *     acc = 1/(b0*b1*b2*b3)                        （唯一的 invmod）
 *     逆序遍历 acc *= b[i] 并从 acc 反推每个 1/b[i]
 * 代价 10 次 mulmod + 1 次求逆，替掉 3 次求逆；语义与官方逐位相同（零元仍映到 0）。
 * ===================================================================== */

static const u128 ONE_U128_CH = {{1, 0}};
static const u128 ZERO_U128_CH = {{0, 0}};

/* out[i] = (in[i] == 0) ? 0 : in[i]^(-1) mod p   （与官方逐位等价） */
static void invmod_batch(u128 out[4], const u128 in[4])
{
    u128 b[4];
    u128 pre[4];
    u128 acc;
    int zero[4];
    int i;

    for (i = 0; i < 4; i++) {
        zero[i] = u128_is_zero(&in[i]);
        if (zero[i]) { b[i] = ONE_U128_CH; } else { b[i] = in[i]; }
    }

    acc = ONE_U128_CH;
    for (i = 0; i < 4; i++) {
        mulmod(&acc, &acc, &b[i]);
        pre[i] = acc;
    }

    invmod(&acc, &acc);

    for (i = 3; i >= 0; i--) {
        u128 t;
        if (i == 0) {
            t = acc;
        } else {
            mulmod(&t, &acc, &pre[i - 1]);
        }
        if (zero[i]) { out[i] = ZERO_U128_CH; } else { out[i] = t; }
        if (i > 0) { mulmod(&acc, &acc, &b[i]); }
    }
}

/* 吸收阶段：与官方 `CryptHash`（OPT `...c:554-581`）逐字相同，抽出来复用。
 * msg_len_bits 的**单位是位**（`full_bytes = bits >> 3`），与官方一致。
 * 注意 512 档的 chunk 粒度是 4 字节（`full_bytes & ~3ULL`），而 1024 档是 8 字节。 */
static void champ_absorb(u128 state[4], const unsigned char *msg,
                         unsigned long long msg_len_bits)
{
    unsigned long long full_bytes, full_chunk_bytes;
    unsigned int remaining_bits;

    build_small_byte_table();
    memcpy(state, MAT_IDENTITY, sizeof(MAT_IDENTITY));

    full_bytes = msg_len_bits >> 3;
    full_chunk_bytes = full_bytes & ~3ULL;

    if (full_chunk_bytes > 0) {
        process_chunk_aligned_bytes(state, msg, 0, full_chunk_bytes);
    }
    process_scalar_bytes(state, msg, full_chunk_bytes, full_bytes);

    remaining_bits = (unsigned int)(msg_len_bits & 7u);
    if (remaining_bits > 0) {
        unsigned char byte = msg[full_bytes];
        int b;
        for (b = 7; b >= (int)(8 - remaining_bits); b--) {
            Mat2x2 tmp;
            int bit = (byte >> b) & 1;
            mat2x2_mul(tmp.m, state, bit ? GEN_B : GEN_A);
            memcpy(state, tmp.m, sizeof(tmp.m));
        }
    }

    canonicalize_lazy_u128(&state[0]);
    canonicalize_lazy_u128(&state[1]);
    canonicalize_lazy_u128(&state[2]);
    canonicalize_lazy_u128(&state[3]);
}

/* 测试/对拍钩子：把吸收后的规范状态按与摘要相同的排布（LE limb）写 64 字节。 */
void champ_absorb_state(unsigned char out[64], const unsigned char *msg,
                        unsigned long long msg_len_bits)
{
    u128 state[4];
    int ci, limb;
    champ_absorb(state, msg, msg_len_bits);
    for (ci = 0; ci < 4; ci++) {
        for (limb = 0; limb < 2; limb++) {
            uint64_t v = state[ci].w[limb];
            memcpy(out + ci * 16 + limb * 8, &v, 8);
        }
    }
}

int CryptHash(int digest_len_bits, const unsigned char *msg,
              unsigned long long msg_len_bits, unsigned char *digest)
{
    u128 state[4];
    u128 inv[4];
    int ci, limb;

    (void)digest_len_bits; /* fixed at 512 bits for this instance */

    champ_absorb(state, msg, msg_len_bits);

    invmod_batch(inv, (const u128 *)state);

    /* 官方写出是逐字节小端（OPT `...c:593-605`）；x86-64 上 64 位存等价。 */
    for (ci = 0; ci < 4; ci++) {
        for (limb = 0; limb < 2; limb++) {
            uint64_t v = inv[ci].w[limb];
            memcpy(digest + ci * 16 + limb * 8, &v, 8);
        }
    }
    return 0;
}
'''


def opt_text():
    return open(OPTSRC, "r", encoding="utf-8", errors="replace").read()


def make_glue(text=None, path=GLUE):
    t = opt_text() if text is None else text
    rest, cut = B.cut_function(t, CUT_SIG)
    assert cut, "官方 CryptHash 没找到"
    rest = rest.rstrip() + "\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(rest + MY_CODE)
    return path, len(cut.splitlines()), len(rest.splitlines())


def compile_so(src, out):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    log = out + ".log"
    args = ["gcc"] + B.FLAGS + ["-fPIC", "-shared", "-Wl,--no-undefined",
                                "-I", REFDIR, "-I", OPTDIR, "-o", out, src, "-lm"]
    r = subprocess.run(args, stdout=open(log, "w"), stderr=subprocess.STDOUT)
    return r.returncode, log


def cmd_build():
    glue, cutn, restn = make_glue()
    print("glue = 官方 Optimized 源码挖掉 CryptHash（%d 行），保留 %d 行，接上我方 %d 行"
          % (cutn, restn, len(MY_CODE.splitlines())))
    rc, log = compile_so(glue, SO)
    if rc != 0:
        print(open(log).read()[-4000:])
        raise SystemExit(1)
    print("build rc=%d -> %s (%d B, sha256 %s)" % (rc, SO, os.path.getsize(SO), B.sha(SO)))
    for l in open(log).read().splitlines():
        if "warning" in l:
            print("  warn:", l)
    return SO


def cmd_kat():
    sys.path.insert(0, L0)
    import kat_gate as K
    K.MAX_RECORDS = 10 ** 9
    K.MAX_MSG_BYTES = 1 << 20
    recs, used = K.find_kat("hash-04", "CHAMP-512")
    print("KAT 文件:", used)
    print("记录 %d 条" % len(recs))
    for tag, so in (("ref", os.path.join(WORK, "_overnight/l0/build/hash-04/champ512/ref.so")),
                    ("opt", OPTSO), ("ours", SO)):
        c, m, fb, err = K._check(so, recs, False)
        print("  %-4s checked=%d match=%d first_bad=%s err=%s"
              % (tag, c, m, fb, err))
    return 0


def cmd_asm():
    for so, name in ((SO, "ours512.asm"), (OPTSO, "opt512.asm")):
        if not os.path.exists(so):
            continue
        B._objdump(so, os.path.join(HERE, "probe", name))
        print("dumped", name)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    c = sys.argv[1]
    if c == "build":
        cmd_build()
    elif c == "kat":
        cmd_kat()
    elif c == "asm":
        cmd_asm()
    else:
        raise SystemExit("unknown subcommand: " + c)


if __name__ == "__main__":
    main()
