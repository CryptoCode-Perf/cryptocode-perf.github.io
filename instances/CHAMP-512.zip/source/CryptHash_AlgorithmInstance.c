/*
 * CHAMP-512 (NGCC ICCS submission)
 *
 * Hash function based on walks in the Cayley graph of GL(2, F_p) where
 *     p = 2^128 - 15449  (a 128-bit safe prime; p-1 = 2q, q prime)
 * and generators
 *     A = [[-2, 1], [4, -3]]
 *     B = [[-5, 2], [-6, 2]]  (entries reduced mod p)
 *
 * Each input BIT is mapped to a matrix (0 -> A, 1 -> B), MSB-first within
 * a byte. The product of these matrices is accumulated modulo p, and the
 * final result is obtained by inverting and concatenating its entries.
 *
 * This implementation keeps the four independent field elements of a 2x2
 * matrix in the four 64-bit lanes of AVX2 registers and performs the field
 * operations (multiply, add, and the four simultaneous inversions) in
 * parallel across those lanes.
 */

#include <stdint.h>
#include <string.h>
#include <immintrin.h>
#include "CryptHash_AlgorithmInstance.h"

/* 128-bit integer type: stored as 2 little-endian 64-bit limbs.   */
typedef struct { uint64_t w[2]; } u128;

/* p = 2^128 - 15449.  15449 = 0x3C59, so low limb = 2^64 - 15449. */
static const u128 P = {{ 0xFFFFFFFFFFFFC3A7ULL, 0xFFFFFFFFFFFFFFFFULL }};

/* Generators (mod p) stored column-major: (m00, m10, m01, m11)    */
static const u128 GEN_A[4] = {
    {{0xFFFFFFFFFFFFC3A5ULL, 0xFFFFFFFFFFFFFFFFULL}}, {{4,0}}, {{1,0}}, {{0xFFFFFFFFFFFFC3A4ULL, 0xFFFFFFFFFFFFFFFFULL}}
};
/* B = [[-5, 2], [-6, 2]] mod p.  col-major (-5, -6, 2, 2). */
static const u128 GEN_B[4] = {
    {{0xFFFFFFFFFFFFC3A2ULL, 0xFFFFFFFFFFFFFFFFULL}},
    {{0xFFFFFFFFFFFFC3A1ULL, 0xFFFFFFFFFFFFFFFFULL}},
    {{2, 0}},
    {{2, 0}}
};

/* Identity matrix col-major (1, 0, 0, 1) */
static const u128 MAT_IDENTITY[4] = {
    {{1,0}}, {{0,0}}, {{0,0}}, {{1,0}}
};

/* Full 64x64 -> 128-bit product.  One native wide multiply yields BOTH
 * limbs, replacing the portable 32x32 decomposition that needed four imuls
 * plus carry fixups just for the high half.  This is the hot scalar field
 * primitive (final Montgomery-batch inversion); it is exact for all inputs. */
static inline void mul64to128(uint64_t a, uint64_t b,
                              uint64_t *lo, uint64_t *hi)
{
    unsigned __int128 p = (unsigned __int128)a * (unsigned __int128)b;
    *lo = (uint64_t)p;
    *hi = (uint64_t)(p >> 64);
}

/* -------------------------------------------------------------------------
 * scalar 128-bit arithmetic (used to construct the byte table once)
 * ------------------------------------------------------------------------- */

static int u128_gte(const u128 *a, const u128 *b)
{
    if (a->w[1] != b->w[1]) return a->w[1] > b->w[1];
    return a->w[0] >= b->w[0];
}

static int u128_is_zero(const u128 *a)
{
    return (a->w[0] | a->w[1]) == 0;
}

static uint64_t u128_add(u128 *r, const u128 *a, const u128 *b)
{
    uint64_t s0 = a->w[0] + b->w[0];
    uint64_t c0 = (s0 < a->w[0]) ? 1 : 0;
    r->w[0] = s0;
    uint64_t s1 = a->w[1] + b->w[1];
    uint64_t c1 = (s1 < a->w[1]) ? 1 : 0;
    s1 += c0;
    uint64_t c2 = (s1 < c0) ? 1 : 0;
    r->w[1] = s1;
    return c1 + c2;
}

static void u128_sub(u128 *r, const u128 *a, const u128 *b)
{
    uint64_t a0 = a->w[0];
    uint64_t a1 = a->w[1];
    uint64_t w0 = a0 - b->w[0];
    uint64_t borrow = (a0 < b->w[0]) ? 1 : 0;
    r->w[0] = w0;
    r->w[1] = a1 - b->w[1] - borrow;
}

/* r = a mod p  (a has 256 bits: a[0..3] are 4 little-endian 64-bit limbs) */
static void reduce256(u128 *r, const uint64_t a[4])
{
    static const uint64_t c = 15449ULL;

    {
        uint64_t hi_c[3];
        uint64_t carry = 0;
        int i;
        for (i = 0; i < 2; i++) {
            uint64_t lo, hi;
            mul64to128(a[2 + i], c, &lo, &hi);
            uint64_t s  = lo + carry;
            uint64_t c0 = (s < lo) ? 1 : 0;
            hi_c[i] = s;
            carry   = hi + c0;
        }
        hi_c[2] = carry;

        uint64_t t[3];
        carry = 0;
        for (i = 0; i < 2; i++) {
            uint64_t s  = a[i] + hi_c[i];
            uint64_t c0 = (s < a[i]) ? 1 : 0;
            s  += carry;
            uint64_t c1 = (s < carry) ? 1 : 0;
            t[i]  = s;
            carry = c0 + c1;
        }
        t[2] = hi_c[2] + carry;

        {
            uint64_t extra = t[2] * c;
            uint64_t carry2;
            r->w[0] = t[0] + extra;
            carry2  = (r->w[0] < t[0]) ? 1 : 0;
            r->w[1] = t[1] + carry2;
            carry2  = (r->w[1] < t[1]) ? 1 : 0;
            if (carry2) {
                r->w[0] += c;
                r->w[1] += (r->w[0] < c) ? 1 : 0;
            }
        }

        if (u128_gte(r, &P)) {
            u128_sub(r, r, &P);
        }
    }
}

static void addmod(u128 *r, const u128 *a, const u128 *b)
{
    uint64_t carry = u128_add(r, a, b);
    if (carry || u128_gte(r, &P)) {
        u128_sub(r, r, &P);
    }
}

static void mulmod(u128 *r, const u128 *a, const u128 *b)
{
    uint64_t prod[4] = {0};
    int i;
    for (i = 0; i < 2; i++) {
        uint64_t carry = 0;
        int j;
        for (j = 0; j < 2; j++) {
            uint64_t lo, hi;
            mul64to128(a->w[i], b->w[j], &lo, &hi);
            uint64_t s  = prod[i + j] + carry;
            uint64_t c0 = (s < prod[i + j]) ? 1 : 0;
            uint64_t s2 = s + lo;
            uint64_t c1 = (s2 < s) ? 1 : 0;
            prod[i + j] = s2;
            carry = hi + c0 + c1;
        }
        prod[i + 2] += carry;
    }
    reduce256(r, prod);
}

/* Modular inverse: r = a^(p-2) mod p  (Fermat's little theorem, p prime). */
static void invmod(u128 *r, const u128 *a)
{
    u128 exp = {{ 0xFFFFFFFFFFFFC3A5ULL, 0xFFFFFFFFFFFFFFFFULL }};
    u128 base   = *a;
    u128 result = {{ 1, 0 }};
    int limb;
    for (limb = 0; limb < 2; limb++) {
        uint64_t bits = exp.w[limb];
        int bit;
        for (bit = 0; bit < 64; bit++) {
            if (bits & 1ULL) mulmod(&result, &result, &base);
            mulmod(&base, &base, &base);
            bits >>= 1;
        }
    }
    *r = result;
}

static void mat2x2_mul(u128 r[4], const u128 x[4], const u128 y[4])
{
    u128 t0, t1;
    mulmod(&t0, &x[0], &y[0]); mulmod(&t1, &x[2], &y[1]); addmod(&r[0], &t0, &t1);
    mulmod(&t0, &x[1], &y[0]); mulmod(&t1, &x[3], &y[1]); addmod(&r[1], &t0, &t1);
    mulmod(&t0, &x[0], &y[2]); mulmod(&t1, &x[2], &y[3]); addmod(&r[2], &t0, &t1);
    mulmod(&t0, &x[1], &y[2]); mulmod(&t1, &x[3], &y[3]); addmod(&r[3], &t0, &t1);
}

/* -------------------------------------------------------------------------
 * AVX2 four-lane field arithmetic.
 *
 * One vf128 holds four independent F_p elements: lane i is (lo[i], hi[i]),
 * the two 64-bit limbs of a 128-bit field element.  All operations below
 * are per-lane, i.e. exactly the scalar operations applied to four elements
 * at once.
 * ------------------------------------------------------------------------- */
typedef struct { __m256i lo; __m256i hi; } vf128;

/* Right-hand matrix operand pre-expanded into the exact lane layouts that
 * vec_mat2x2_mul consumes:  s22 = (y0,y0,y2,y2), s13 = (y1,y1,y3,y3) for
 * both limbs.  The running state (left operand) must still be permuted at
 * runtime, but the CONSTANT table operand's four cross-lane vpermq are
 * hoisted into one-time table construction.  Bit-exact data-layout transform. */
typedef struct { vf128 s22, s13; } MatExp;

/* Ordered byte-pair table.  Entry [i*256+j] is the 2x2 product M[i]*M[j],
 * stored pre-expanded in the operand layout consumed by the hot-loop matmul.
 * Matrix multiplication is associative, so one multiply per two bytes
 * replaces two multiplies in the dominant walk. */
static MatExp vec_pair_table[65536];

static inline __m256i vconst(uint64_t x)
{
    return _mm256_set1_epi64x((long long)x);
}

/* unsigned 64-bit lane-wise a > b (mask of all-ones / zero) */
static inline __m256i ucmpgt(__m256i a, __m256i b)
{
    const __m256i sign = _mm256_set1_epi64x((long long)0x8000000000000000ULL);
    return _mm256_cmpgt_epi64(_mm256_xor_si256(a, sign),
                               _mm256_xor_si256(b, sign));
}

/* carry (0 or 1) of unsigned a + b, given the wrapped sum s */
static inline __m256i ovf01(__m256i a, __m256i s)
{
    return _mm256_and_si256(ucmpgt(a, s), _mm256_set1_epi64x(1LL));
}

/* Carry-out of t + ci where ci is a per-lane 0/1 carry-in (each 64-bit lane
 * holds numeric 0 or 1).  t + ci overflows iff ci==1 AND t == 2^64-1
 * (all ones), so
 *     carry(t + ci) = ci & (t == ~0)
 * (verified exhaustively as a Boolean circuit).  This replaces ovf01()'s
 * 2 sign-xors + vpcmpgtq + and with a single vpcmpeqq + vpand.
 *
 * Validity at every use below: the carry-in is produced by ovf01() (hence
 * 0/1), AND a generated carry ca=ovf01(a,b)=1 forces the partial sum
 * t=a+b-2^64 <= 2^64-2 != ~0, so ca and carry(t+ci) are mutually exclusive
 * and every propagated carry stays 0/1. */
static inline __m256i carry01(__m256i t, __m256i ci)
{
    return _mm256_and_si256(ci,
                            _mm256_cmpeq_epi64(t, _mm256_set1_epi64x(-1LL)));
}

static inline __m256i addc(__m256i a, __m256i b, __m256i *carry)
{
    __m256i s = _mm256_add_epi64(a, b);
    *carry = ovf01(a, s);
    return s;
}

/* Representation of one 64-bit limb for vpmuludq consumption.
 *
 * AVX2 _mm256_mul_epu32 (vpmuludq) multiplies ONLY the low 32 bits of each
 * 64-bit lane and ignores that lane's upper 32 bits.  Consequently the
 * "low half" field of split64 can hold the ORIGINAL unmodified limb: the
 * implicit low-32 selection of vpmuludq makes an explicit vpand provably
 * redundant.  The limb stays in its natural packed (hi:lo) representation;
 * only a single vpsrlq is needed to expose the high half.  A 128x128 product
 * is four 64x64 sub-products, and splitting each 64-bit operand ONCE per
 * product (instead of inside every sub-product) removes half the split work
 * from the four-lane chain. */
typedef struct { __m256i lo, hi; } split64;

static inline split64 split_limb(__m256i x)
{
    split64 s;
    s.lo = x;                          /* vpmuludq inherently reads low 32 bits */
    s.hi = _mm256_srli_epi64(x, 32);   /* high half zero-extended into low 32 */
    return s;
}

/* Full 64x64 -> 128 bit product per lane from pre-split operands. */
static inline void mul_split128(const split64 *x, const split64 *y,
                                __m256i *lo, __m256i *hi)
{
    const __m256i m32 = vconst(0xFFFFFFFFULL);
    /* x->lo,y->lo hold the original packed limbs: vpmuludq inherently
     * selects each lane's low 32 bits, so no explicit input mask is needed. */
    __m256i p00 = _mm256_mul_epu32(x->lo, y->lo);
    __m256i p01 = _mm256_mul_epu32(x->lo, y->hi);
    __m256i p10 = _mm256_mul_epu32(x->hi, y->lo);
    __m256i p11 = _mm256_mul_epu32(x->hi, y->hi);

    /* Shifting the (possibly 65-bit) p01+p10 left by 32 discards every bit
     * above bit 63, which is exactly low32(p01+p10) << 32; the explicit
     * mask is therefore redundant. */
    *lo = _mm256_add_epi64(
        p00, _mm256_slli_epi64(_mm256_add_epi64(p01, p10), 32));

    /* high limb: p11 + (p01>>32) + (p10>>32) + (mid>>32),
     * mid = (p00>>32) + low32(p01) + low32(p10).  Here m32 IS required:
     * p01,p10 are full 64-bit products and mid needs their exact low halves. */
    __m256i mid = _mm256_add_epi64(
        _mm256_add_epi64(_mm256_srli_epi64(p00, 32),
                         _mm256_and_si256(p01, m32)),
        _mm256_and_si256(p10, m32));
    *hi = _mm256_add_epi64(
        _mm256_add_epi64(
            _mm256_add_epi64(p11, _mm256_srli_epi64(p01, 32)),
            _mm256_srli_epi64(p10, 32)),
        _mm256_srli_epi64(mid, 32));
}

/* Multiply a 64-bit lane vector by the small constant c = 15449 (< 2^14).
 * Writing x = xh*2^32 + xl, with p0 = xl*c and p1 = xh*c (both < 2^46),
 * the exact 128-bit product is lo = p0 + (p1<<32) mod 2^64 and
 * hi = (p1>>32) + carry(p0 + (p1<<32)).  Only two vpmuludq are needed,
 * instead of the four a general 64x64 -> 128 multiply requires.  x is fed
 * directly to vpmuludq, which inherently reads only the low 32 bits. */
static inline void mulc64to128(__m256i x, __m256i cvec,
                               __m256i *lo, __m256i *hi)
{
    __m256i xh = _mm256_srli_epi64(x, 32);
    __m256i p0 = _mm256_mul_epu32(x, cvec);    /* low32(x) * c */
    __m256i p1 = _mm256_mul_epu32(xh, cvec);   /* high32(x) * c */
    __m256i s  = _mm256_add_epi64(p0, _mm256_slli_epi64(p1, 32));
    *lo = s;
    *hi = _mm256_add_epi64(_mm256_srli_epi64(p1, 32), ovf01(p0, s));
}

/* Low 64 bits of x*c (used where the full product is known to fit in 64 bits). */
static inline __m256i mulc_lo(__m256i x, __m256i cvec)
{
    __m256i xh = _mm256_srli_epi64(x, 32);
    __m256i p0 = _mm256_mul_epu32(x, cvec);
    __m256i p1 = _mm256_mul_epu32(xh, cvec);
    return _mm256_add_epi64(p0, _mm256_slli_epi64(p1, 32));
}

/* Reduction of a 256-bit product, plus an optional already-form low-limb
 * contribution p4c (the folded c*p4 term from a summed product; see
 * vec_mat2x2_mul).  With p = 2^128 - c, the limb p4*2^256 folds as
 * c*(c*p4) = c*p4 * 2^128, so adding p4c to t[2] before the t[2]*c fold
 * is exactly equivalent to reducing the full 257-bit integer.
 *
 * REPRESENTATION: the result is kept as a redundant residue in [0, 2^128)
 * (congruent to the input modulo p) rather than canonicalized to [0, p).
 * The original final "r >= p ? r - p : r" step is pure canonicalization;
 * every consumer of a hot-path residue works modulo p, and the scalar
 * digest path canonicalizes before zero-detection and serialization. */
static inline void vec_reduce_core(vf128 *r, __m256i p0, __m256i p1,
                                   __m256i p2, __m256i p3, __m256i p4c)
{
    const __m256i cc  = vconst(15449ULL);
    const __m256i one = _mm256_set1_epi64x(1LL);

    /* step 1: hi_c = (p2,p3) * c */
    __m256i lc0, hc0, lc1, hc1;
    mulc64to128(p2, cc, &lc0, &hc0);
    mulc64to128(p3, cc, &lc1, &hc1);
    __m256i c0;
    __m256i s1 = addc(lc1, hc0, &c0);
    __m256i hi_c0 = lc0;
    __m256i hi_c1 = s1;
    __m256i hi_c2 = _mm256_add_epi64(hc1, c0);

    /* step 2: t = (p0,p1) + hi_c */
    __m256i ca, cb, cc2;
    __m256i t0 = addc(p0, hi_c0, &ca);
    __m256i s  = addc(p1, hi_c1, &cb);
    /* ca is a 0/1 carry-in to s, so carry01() is exact here. */
    __m256i t1 = _mm256_add_epi64(s, ca); cc2 = carry01(s, ca);
    __m256i t2 = _mm256_add_epi64(
        _mm256_add_epi64(hi_c2, _mm256_add_epi64(cb, cc2)), p4c);

    /* step 3: fold t[2]*2^128 into the low part.
     * t2*c fits in < 2^30, so the low limb of the full product is exact. */
    /* t2 is provably < 2^16: hi_c2 is the sum of the two high halves of
     * (p2*c),(p3*c) (each < 2^14) plus a 0/1 carry, cb/cc2 are 0/1, and
     * p4c <= c < 2^14.  Therefore t2*c < 2^30 and its full product is
     * exactly low32(t2)*c: the high-half term of mulc_lo() is identically
     * zero.  One vpmuludq replaces two plus a shift and an add on the
     * saturated multiply port. */
    __m256i extra = _mm256_mul_epu32(t2, cc);
    __m256i ce, cf;
    __m256i r0 = addc(t0, extra, &ce);
    /* ce is a 0/1 carry-in to t1, so carry01() is exact here. */
    __m256i r1 = _mm256_add_epi64(t1, ce); cf = carry01(t1, ce);
    /* cf is 0/1, so cf*c is c when cf==1 and 0 otherwise.  Fold that
     * redundant 2^128 limb: since 2^128 == c (mod p), adding cf*c to the
     * low limb and carrying its overflow keeps the value in Z/(p). */
    __m256i cfmask = _mm256_cmpeq_epi64(cf, one);
    __m256i addc_c = _mm256_and_si256(cfmask, cc);
    __m256i r0new = _mm256_add_epi64(r0, addc_c);
    __m256i carry_c = _mm256_and_si256(ovf01(r0, r0new), one);
    r0 = r0new;
    r1 = _mm256_add_epi64(r1, carry_c);

    /* No canonical conditional subtraction: r0 + r1*2^64 is a congruent
     * representative in [0, 2^128), which fits the 128-bit lane pair. */
    r->lo = r0;
    r->hi = r1;
}

/* r = reduction of the 256-bit product held in limbs p0..p3 */
static inline void vec_reduce256(vf128 *r, __m256i p0, __m256i p1,
                                  __m256i p2, __m256i p3)
{
    vec_reduce_core(r, p0, p1, p2, p3, _mm256_setzero_si256());
}

/* Raw (unreduced) 256-bit product of two 128-bit field values, matching
 * scalar mulmod()'s schoolbook accumulation exactly. */
static inline void vec_mul_raw(__m256i out[4], __m256i a0, __m256i a1,
                               __m256i b0, __m256i b1)
{
    __m256i l00, h00, l01, h01, l10, h10, l11, h11;
    split64 sa0 = split_limb(a0), sa1 = split_limb(a1);
    split64 sb0 = split_limb(b0), sb1 = split_limb(b1);
    mul_split128(&sa0, &sb0, &l00, &h00);
    mul_split128(&sa0, &sb1, &l01, &h01);
    mul_split128(&sa1, &sb0, &l10, &h10);
    mul_split128(&sa1, &sb1, &l11, &h11);

    /* Symbolic simplification of the schoolbook carry recurrence.
     * Using the exhaustively-verified carry identity
     *     carry(a+b) = majority(a, b, carry_in)  (0/1 form),
     * the first accumulation had out[1]=0 and cr=h00, so its carry
     * ca = carry(0 + h00) is provably zero; likewise the two zero-initialised
     * limbs out[2]/out[3] contributed provably-dead zero adds.  Rewriting the
     * recurrence with explicit 0/1 carries removes one ovf01 (2 sign-xor +
     * cmpgt + and) and three vpaddq from every 128x128 product while keeping
     * the exact limb values and carry order:
     *   t    = h00 + l01            (carry cb1)
     *   o1   = t + l10              (carry cb2)
     *   A+B  = (h01+cb1) + (h10+cb2) (carry ca)
     *   o2   = (A+B) + l11          (carry cb3)
     *   o3   = h11 + ca + cb3. */
    __m256i cb1, cb2, ca, cb3, t, ab;
    out[0] = l00;
    t   = _mm256_add_epi64(h00, l01);
    cb1 = ovf01(h00, t);
    out[1] = _mm256_add_epi64(t, l10);
    cb2 = ovf01(t, out[1]);
    ab  = _mm256_add_epi64(_mm256_add_epi64(h01, cb1),
                           _mm256_add_epi64(h10, cb2));
    ca  = ovf01(_mm256_add_epi64(h01, cb1), ab);
    out[2] = _mm256_add_epi64(ab, l11);
    cb3 = ovf01(ab, out[2]);
    out[3] = _mm256_add_epi64(_mm256_add_epi64(h11, ca), cb3);
}

/* s[0..4] = a[0..3] + b[0..3], with the top carry in s[4].
 *
 * Each limb carry is a generated carry ca=ovf01(a[i],t) (a 0/1 bit) OR a
 * propagated carry pb = carry01(t, cin).  Since ca==1 forces t != ~0, the
 * two are mutually exclusive and c_{i+1} = ca | pb stays 0/1. */
static inline void add256(__m256i s[5], const __m256i a[4], const __m256i b[4])
{
    __m256i c0, c1, c2, c3, ca, t;
    s[0] = addc(a[0], b[0], &c0);
    t = _mm256_add_epi64(a[1], b[1]); ca = ovf01(a[1], t);
    s[1] = _mm256_add_epi64(t, c0);   c1 = _mm256_or_si256(ca, carry01(t, c0));
    t = _mm256_add_epi64(a[2], b[2]); ca = ovf01(a[2], t);
    s[2] = _mm256_add_epi64(t, c1);   c2 = _mm256_or_si256(ca, carry01(t, c1));
    t = _mm256_add_epi64(a[3], b[3]); ca = ovf01(a[3], t);
    s[3] = _mm256_add_epi64(t, c2);   c3 = _mm256_or_si256(ca, carry01(t, c2));
    s[4] = c3;
}

/* r = a*b mod p, four lanes at a time */
static inline vf128 vec_mulmod(vf128 a, vf128 b)
{
    __m256i p[4];
    vec_mul_raw(p, a.lo, a.hi, b.lo, b.hi);
    vf128 res;
    vec_reduce256(&res, p[0], p[1], p[2], p[3]);
    return res;
}

/* r = a + b mod p, four lanes at a time */
static inline vf128 vec_addmod(vf128 a, vf128 b)
{
    const __m256i phi  = vconst(0xFFFFFFFFFFFFFFFFULL);
    const __m256i plo  = vconst(0xFFFFFFFFFFFFC3A7ULL);
    const __m256i one  = _mm256_set1_epi64x(1LL);
    const __m256i all1 = _mm256_set1_epi64x(-1LL);
    const __m256i zero = _mm256_setzero_si256();

    __m256i c0, c1, c2;
    __m256i s0 = addc(a.lo, b.lo, &c0);
    __m256i s1 = addc(a.hi, b.hi, &c1);
    __m256i s1b = addc(s1, c0, &c2);
    __m256i carry = _mm256_add_epi64(c1, c2);

    __m256i nz = _mm256_xor_si256(_mm256_cmpeq_epi64(carry, zero), all1);
    __m256i gethi = ucmpgt(s1b, phi);
    __m256i eqhi  = _mm256_cmpeq_epi64(s1b, phi);
    __m256i gelo  = _mm256_xor_si256(ucmpgt(plo, s0), all1);
    __m256i ge = _mm256_or_si256(nz,
                                 _mm256_or_si256(gethi,
                                                 _mm256_and_si256(eqhi, gelo)));

    __m256i borrow = _mm256_and_si256(ucmpgt(plo, s0), one);
    __m256i d0 = _mm256_sub_epi64(s0, plo);
    __m256i d1 = _mm256_sub_epi64(_mm256_sub_epi64(s1b, phi), borrow);

    vf128 r;
    r.lo = _mm256_blendv_epi8(s0, d0, ge);
    r.hi = _mm256_blendv_epi8(s1b, d1, ge);
    return r;
}

/* 2x2 matrix multiply, four matrix entries in the four lanes.
 *
 * The two 128x128 products behind the two output sums are added as raw
 * 256-bit integers BEFORE reduction.  Since (A mod p)+(B mod p) == (A+B)
 * mod p, this replaces two full vec_reduce256 calls plus a separate
 * vec_addmod with a single reduction of the (at most 257-bit) sum.  The
 * extra 2^256 limb folds into the existing t2*c step as c*p4. */
/* Core matmul: both operands already in the lane layouts the raw multiply
 * consumes.  x = (xs01,xs23) from the running state, y = (ys0022,ys1133)
 * either permuted on the fly or read pre-expanded from the table. */
static inline vf128 vec_mat2x2_mul_core(const vf128 *xs01, const vf128 *xs23,
                                        const vf128 *ys0022, const vf128 *ys1133)
{
    __m256i pa[4], pb[4], ps[5];
    vec_mul_raw(pa, xs01->lo, xs01->hi, ys0022->lo, ys0022->hi);
    vec_mul_raw(pb, xs23->lo, xs23->hi, ys1133->lo, ys1133->hi);
    add256(ps, pa, pb);

    /* p4 <= 2 and c < 2^14, so one vpmuludq gives the exact c*p4. */
    __m256i p4c = _mm256_mul_epu32(ps[4], vconst(15449ULL));
    vf128 res;
    vec_reduce_core(&res, ps[0], ps[1], ps[2], ps[3], p4c);
    return res;
}

/* Generic 2x2 matrix multiply: permute both operands on the fly. */
static inline vf128 vec_mat2x2_mul(const vf128 *x, const vf128 *y)
{
    vf128 xs01, xs23, ys0022, ys1133;
    xs01.lo   = _mm256_permute4x64_epi64(x->lo, _MM_SHUFFLE(1, 0, 1, 0));
    xs01.hi   = _mm256_permute4x64_epi64(x->hi, _MM_SHUFFLE(1, 0, 1, 0));
    xs23.lo   = _mm256_permute4x64_epi64(x->lo, _MM_SHUFFLE(3, 2, 3, 2));
    xs23.hi   = _mm256_permute4x64_epi64(x->hi, _MM_SHUFFLE(3, 2, 3, 2));
    ys0022.lo = _mm256_permute4x64_epi64(y->lo, _MM_SHUFFLE(2, 2, 0, 0));
    ys0022.hi = _mm256_permute4x64_epi64(y->hi, _MM_SHUFFLE(2, 2, 0, 0));
    ys1133.lo = _mm256_permute4x64_epi64(y->lo, _MM_SHUFFLE(3, 3, 1, 1));
    ys1133.hi = _mm256_permute4x64_epi64(y->hi, _MM_SHUFFLE(3, 3, 1, 1));
    return vec_mat2x2_mul_core(&xs01, &xs23, &ys0022, &ys1133);
}

/* Hot-loop matmul: right operand is a CONSTANT table entry already expanded
 * into (y0,y0,y2,y2)/(y1,y1,y3,y3), so only the state is permuted at runtime.
 * Saves four vpermq per call versus vec_mat2x2_mul, bit-exact. */
static inline vf128 vec_mat2x2_mul_exp(const vf128 *x, const MatExp *y)
{
    vf128 xs01, xs23;
    /* x->{lo,hi} hold (y0,y1 | y2,y3) as two 128-bit halves.  Broadcasting
     * each half across the whole register yields exactly the layouts
     * (y0,y1,y0,y1) and (y2,y3,y2,y3) that the four vpermq calls produced.
     * vperm2f128 is a cheaper shuffle (no cross-register lane source) and
     * halves the shuffle count per hot matmul; the selected lanes are bit-
     * identical.  Control 0x00 -> low half in both outputs, 0x11 -> high. */
    xs01.lo = _mm256_permute2x128_si256(x->lo, x->lo, 0x00);
    xs01.hi = _mm256_permute2x128_si256(x->hi, x->hi, 0x00);
    xs23.lo = _mm256_permute2x128_si256(x->lo, x->lo, 0x11);
    xs23.hi = _mm256_permute2x128_si256(x->hi, x->hi, 0x11);
    return vec_mat2x2_mul_core(&xs01, &xs23, &y->s22, &y->s13);
}

/* r = a^(p-2) for all four lanes simultaneously (zero lanes -> zero). */
static inline vf128 vec_invmod(vf128 a)
{
    const uint64_t exp0 = 0xFFFFFFFFFFFFC3A5ULL;
    const uint64_t exp1 = 0xFFFFFFFFFFFFFFFFULL;
    vf128 base = a;
    vf128 result;
    result.lo = _mm256_set1_epi64x(1LL);
    result.hi = _mm256_setzero_si256();

    uint64_t bits = exp0;
    int k;
    for (k = 0; k < 128; k++) {
        if (k == 64) bits = exp1;
        if (bits & 1ULL) result = vec_mulmod(result, base);
        base = vec_mulmod(base, base);
        bits >>= 1;
    }

    __m256i zero = _mm256_setzero_si256();
    __m256i zmask = _mm256_and_si256(_mm256_cmpeq_epi64(a.lo, zero),
                                      _mm256_cmpeq_epi64(a.hi, zero));
    result.lo = _mm256_blendv_epi8(result.lo, zero, zmask);
    result.hi = _mm256_blendv_epi8(result.hi, zero, zmask);
    return result;
}

static inline vf128 gen_to_vec(const u128 m[4])
{
    vf128 v;
    v.lo = _mm256_setr_epi64x((long long)m[0].w[0], (long long)m[1].w[0],
                               (long long)m[2].w[0], (long long)m[3].w[0]);
    v.hi = _mm256_setr_epi64x((long long)m[0].w[1], (long long)m[1].w[1],
                               (long long)m[2].w[1], (long long)m[3].w[1]);
    return v;
}

/* Pre-expand a 2x2 matrix (column-major entries y0,y1,y2,y3) into the exact
 * cross-lane layouts vec_mat2x2_mul consumes for its right-hand operand:
 *   s22 = (y0,y0,y2,y2),  s13 = (y1,y1,y3,y3)   (both 64-bit limbs). */
static inline MatExp gen_to_exp(const u128 m[4])
{
    MatExp e;
    e.s22.lo = _mm256_setr_epi64x((long long)m[0].w[0], (long long)m[0].w[0],
                                   (long long)m[2].w[0], (long long)m[2].w[0]);
    e.s22.hi = _mm256_setr_epi64x((long long)m[0].w[1], (long long)m[0].w[1],
                                   (long long)m[2].w[1], (long long)m[2].w[1]);
    e.s13.lo = _mm256_setr_epi64x((long long)m[1].w[0], (long long)m[1].w[0],
                                   (long long)m[3].w[0], (long long)m[3].w[0]);
    e.s13.hi = _mm256_setr_epi64x((long long)m[1].w[1], (long long)m[1].w[1],
                                   (long long)m[3].w[1], (long long)m[3].w[1]);
    return e;
}

/* Same expansion from an already-packed natural-order vf128 (one-time use). */
static inline MatExp vf128_to_exp(vf128 v)
{
    MatExp e;
    e.s22.lo = _mm256_permute4x64_epi64(v.lo, _MM_SHUFFLE(2, 2, 0, 0));
    e.s22.hi = _mm256_permute4x64_epi64(v.hi, _MM_SHUFFLE(2, 2, 0, 0));
    e.s13.lo = _mm256_permute4x64_epi64(v.lo, _MM_SHUFFLE(3, 3, 1, 1));
    e.s13.hi = _mm256_permute4x64_epi64(v.hi, _MM_SHUFFLE(3, 3, 1, 1));
    return e;
}

/* -------------------------------------------------------------------------
 * Byte tables (built once).
 * ------------------------------------------------------------------------- */
typedef struct { u128 m[4]; } Mat2x2;

static Mat2x2 byte_table[256];
static vf128   vec_byte_table[256];
static vf128   vec_GEN_A, vec_GEN_B;
static int     byte_table_ready = 0;

static void build_byte_table(void)
{
    int i;
    if (byte_table_ready) return;
    for (i = 0; i < 256; i++) {
        Mat2x2 acc;
        int b;
        memcpy(acc.m, MAT_IDENTITY, sizeof(acc.m));
        for (b = 7; b >= 0; b--) {
            int bit = (i >> b) & 1;
            Mat2x2 tmp;
            mat2x2_mul(tmp.m, acc.m, bit ? GEN_B : GEN_A);
            acc = tmp;
        }
        byte_table[i] = acc;
        vec_byte_table[i] = gen_to_vec(byte_table[i].m);
    }
    vec_GEN_A = gen_to_vec(GEN_A);
    vec_GEN_B = gen_to_vec(GEN_B);

    /* Precompute every ordered byte-pair product M[i]*M[j], storing each
     * result in the pre-expanded right-operand layout the hot-loop matmul
     * consumes.  One-time vector cost; consulted once per two message bytes. */
    {
        int a, b;
        for (a = 0; a < 256; a++) {
            vf128 va = gen_to_vec(byte_table[a].m);
            for (b = 0; b < 256; b++) {
                vf128 prod = vec_mat2x2_mul(&va, &vec_byte_table[b]);
                vec_pair_table[a * 256 + b] = vf128_to_exp(prod);
            }
        }
    }
    byte_table_ready = 1;
}

/* -------------------------------------------------------------------------
 * public API
 * ------------------------------------------------------------------------- */
int CryptHash(int digest_len_bits, const unsigned char *msg,
               unsigned long long msg_len_bits, unsigned char *digest)
{
    unsigned long long full_bytes;
    unsigned int remaining_bits;
    vf128 state;
    uint64_t loarr[4], hiarr[4];
    int ci, b;

    (void)digest_len_bits; /* fixed at 512 bits for this instance */

    build_byte_table();

    state.lo = _mm256_setr_epi64x(1LL, 0LL, 0LL, 1LL);
    state.hi = _mm256_setzero_si256();

    full_bytes = msg_len_bits >> 3;
    /* Accumulate two bytes per matmul by associativity:
     *   state*M[i]*M[i+1] = state*(M[i]*M[i+1]).
     * The pair sequence is split into FOUR CONTIGUOUS quarters, each advanced
     * by an independent AVX2 chain in one interleaved loop.  Four chains expose
     * four independent 128x128 multiply/reduction trees to the out-of-order
     * core, so one chain's serial reduction stalls overlap another chain's
     * vpmuludq work.  Every vec_mat2x2_mul_exp still uses explicit
     * _mm256_permute2x128_si256 broadcasts over four parallel field lanes.
     * Only contiguous factors are regrouped; the balanced combine
     * (s0*s1)*(s2*s3) == s0*s1*s2*s3 by matrix associativity (NOT commutativity)
     * preserves the exact order state*M[0]*M[1]*... . */
    {
        unsigned long long pairs = full_bytes >> 1;
        unsigned long long n = pairs >> 2;          /* pairs per quarter */
        unsigned long long rem = pairs - (n << 2);  /* 0..3 trailing pairs */
        unsigned long long k;
        const unsigned long long stride = n << 1;   /* bytes per quarter */
        const vf128 ident = { _mm256_setr_epi64x(1LL, 0LL, 0LL, 1LL),
                               _mm256_setzero_si256() };
        vf128 s0 = ident, s1 = ident, s2 = ident, s3 = ident;

        for (k = 0; k < n; k++) {
            unsigned long long o0 = (k << 1);
            unsigned long long o1 = o0 + stride;
            unsigned long long o2 = o1 + stride;
            unsigned long long o3 = o2 + stride;
            unsigned int p0 = ((unsigned int)msg[o0] << 8) | msg[o0 + 1];
            unsigned int p1 = ((unsigned int)msg[o1] << 8) | msg[o1 + 1];
            unsigned int p2 = ((unsigned int)msg[o2] << 8) | msg[o2 + 1];
            unsigned int p3 = ((unsigned int)msg[o3] << 8) | msg[o3 + 1];
            s0 = vec_mat2x2_mul_exp(&s0, &vec_pair_table[p0]);
            s1 = vec_mat2x2_mul_exp(&s1, &vec_pair_table[p1]);
            s2 = vec_mat2x2_mul_exp(&s2, &vec_pair_table[p2]);
            s3 = vec_mat2x2_mul_exp(&s3, &vec_pair_table[p3]);
        }
        /* Combine the four contiguous quarters in original order. */
        {
            vf128 t01 = vec_mat2x2_mul(&s0, &s1);
            vf128 t23 = vec_mat2x2_mul(&s2, &s3);
            state = vec_mat2x2_mul(&t01, &t23);
        }
        /* Trailing pairs (if any) stay serial, preserving order. */
        {
            unsigned long long base = n << 2;   /* first trailing pair index */
            for (k = 0; k < rem; k++) {
                unsigned long long off = ((base + k) << 1);
                unsigned int pi = ((unsigned int)msg[off] << 8) | msg[off + 1];
                state = vec_mat2x2_mul_exp(&state, &vec_pair_table[pi]);
            }
        }
        if (full_bytes & 1ULL) {
            state = vec_mat2x2_mul(&state,
                                   &vec_byte_table[(unsigned char)msg[full_bytes - 1]]);
        }
    }

    /* Handle remaining partial byte bits, MSB first */
    remaining_bits = (unsigned int)(msg_len_bits & 7u);
    if (remaining_bits > 0) {
        unsigned char byte = msg[full_bytes];
        for (b = 7; b >= (int)(8 - remaining_bits); b--) {
            int bit = (byte >> b) & 1;
            state = vec_mat2x2_mul(&state, bit ? &vec_GEN_B : &vec_GEN_A);
        }
    }

    /* Invert the four matrix entries via Montgomery batch inversion.
     * With z_i = (a_i == 0 ? 1 : a_i), the prefix products s_i and the
     * single reciprocal t = 1/(s_3) give 1/a_i = t * s_{i-1} * (s_i / a_i),
     * where s_i/a_i is just the product of earlier entries (1 for a zero
     * slot, since z_i was substituted). Zero slots are forced back to 0 at
     * the end, preserving the reference's zero -> zero rule. This replaces
     * four independent Fermat exponentiations with one plus nine field
     * multiplications.
     */
    {
        u128 aa[4], zz[4], pp[4], zinv[4];
        u128 one, acc;

        _mm256_storeu_si256((__m256i *)loarr, state.lo);
        _mm256_storeu_si256((__m256i *)hiarr, state.hi);
        for (ci = 0; ci < 4; ci++) {
            aa[ci].w[0] = loarr[ci];
            aa[ci].w[1] = hiarr[ci];
            /* HOT-PATH RESIDUES ARE REDUNDANT [0,2^128): canonicalize here,
             * before zero-detection.  A mathematical zero may be stored as
             * p ( == 0 mod p ); subtracting p once maps it to 0 so the
             * Montgomery zero-slot handling remains exact.  Since every
             * residue is < 2^128 < 2p, one subtraction suffices. */
            if (u128_gte(&aa[ci], &P)) {
                u128_sub(&aa[ci], &aa[ci], &P);
            }
        }

        one.w[0] = 1; one.w[1] = 0;
        acc = one;
        for (ci = 0; ci < 4; ci++) {
            if (u128_is_zero(&aa[ci])) {
                zz[ci] = one;            /* nonzero substitute */
                pp[ci] = one;            /* s_i / z_i = 1 for a zero slot */
            } else {
                zz[ci] = aa[ci];
                pp[ci] = acc;            /* s_{i-1}, the prefix before slot i */
            }
            mulmod(&acc, &acc, &zz[ci]); /* acc = s_i */
        }

        /* Single exponentiation: t = 1 / (z_0 z_1 z_2 z_3). */
        invmod(&acc, &acc);

        for (ci = 3; ci >= 0; ci--) {
            mulmod(&zinv[ci], &acc, &pp[ci]);   /* 1 / z_i */
            mulmod(&acc, &acc, &zz[ci]);        /* 1 / s_{i-1} */
        }

        for (ci = 0; ci < 4; ci++) {
            if (u128_is_zero(&aa[ci])) {
                loarr[ci] = 0; hiarr[ci] = 0;
            } else {
                loarr[ci] = zinv[ci].w[0];
                hiarr[ci] = zinv[ci].w[1];
            }
        }
    }
    for (ci = 0; ci < 4; ci++) {
        uint64_t val = loarr[ci];
        digest[ci * 16 + 0] = (unsigned char)(val);
        digest[ci * 16 + 1] = (unsigned char)(val >>  8);
        digest[ci * 16 + 2] = (unsigned char)(val >> 16);
        digest[ci * 16 + 3] = (unsigned char)(val >> 24);
        digest[ci * 16 + 4] = (unsigned char)(val >> 32);
        digest[ci * 16 + 5] = (unsigned char)(val >> 40);
        digest[ci * 16 + 6] = (unsigned char)(val >> 48);
        digest[ci * 16 + 7] = (unsigned char)(val >> 56);
        val = hiarr[ci];
        digest[ci * 16 + 8] = (unsigned char)(val);
        digest[ci * 16 + 9] = (unsigned char)(val >>  8);
        digest[ci * 16 + 10] = (unsigned char)(val >> 16);
        digest[ci * 16 + 11] = (unsigned char)(val >> 24);
        digest[ci * 16 + 12] = (unsigned char)(val >> 32);
        digest[ci * 16 + 13] = (unsigned char)(val >> 40);
        digest[ci * 16 + 14] = (unsigned char)(val >> 48);
        digest[ci * 16 + 15] = (unsigned char)(val >> 56);
    }

    return 0;
}
