#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -Isource source/CryptHash_AlgorithmInstance.c -o CHAMP-512.so
