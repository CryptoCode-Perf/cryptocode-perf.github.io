# CHAMP-512

Algorithm: CHAMP | Digest bits: 512 | Form: 标量 C

Contents: implementation source/, public header CHAMP-512.h, prebuilt CHAMP-512.so,
KAT vector KAT_2_12_CHAMP-512.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): d318a504d0dc2fecf98821af5e2a4094ba9878293d4eb99265c0f531727a3f51
Speed (cpB, lower is faster): reference 280.34 / official-optimized 41.96 / optimized 17.22
Speedup: GM(S1-S8) 1.99x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
