#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
python3 kat_check.py ./CHAMP-512.so 4097 0 KAT_2_12_CHAMP-512.txt
