# Third-party material

Reference_Implementation and Optimized_Implementation contain material
from the original QILIN submission, and kat contains its test vectors.
Original source notices are retained in the corresponding files. CryptoCode
implementation derives algorithm data from the reference. Source and file
hashes are recorded in SOURCE_MANIFEST.json. No additional license or rights
grant is asserted by this package.
