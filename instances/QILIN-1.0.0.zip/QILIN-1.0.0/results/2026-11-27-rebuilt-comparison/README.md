# Rebuilt-library comparison

Three independent runs at eight message sizes, 101 paired samples per size
and run, on the system in environment.txt. Ratios are official optimized
elapsed time / CryptoCode elapsed time; values above 1 favor CryptoCode.
Elapsed time is measured with CLOCK_MONOTONIC_RAW in nanoseconds, not hardware
cycles. Randomized ABBA/BAAB pairing and CPU affinity are used. Shared locks
coordinate participating measurements but cannot exclude unrelated host load.
Raw CSV, run registration, input hashes, flags and results are included.
Rebuild and verify first, then rerun with an agreed exclusive lock:

    python3 test/measure.py --lock /path/to/shared/measurement.lock --output /path/to/new/results-directory

Performance is platform and load dependent; these samples are not a universal
fastest claim. Earlier comparison records remain as historical evidence.
