# Exploratory performance comparisons

The package comparison uses package-rebuilt official optimized and CryptoCode
libraries. The report comparison uses separately frozen website and report
binaries. `plan.json`, `summary.json` and raw CSV files retain identities and
samples. Ratios are baseline time / CryptoCode time; > 1 favors CryptoCode.
Measurements use CLOCK_MONOTONIC_RAW nanoseconds, randomized ABBA/BAAB pairs,
and CPU affinity under WSL2. A cooperative lock cannot exclude unrelated host
load. Results are environment-specific, not a universal fastest claim.
`test/pair_bench.c` is the harness; use exclusive measurement coordination.
