# QILIN 1.0.0 — CryptoCode AVX2 Implementation

Supports QILIN-512, QILIN-768 and QILIN-1024 through the CryptHash ABI.
Requires x86-64 Linux/WSL2, AVX2, GCC, Python 3 and standard shell tools.

Run from any directory:

```sh
bash build_and_verify.sh
```

The script rebuilds reference, official optimized and CryptoCode implementations;
compares 66 boundary vectors and frozen golden vectors; verifies all 4097 KAT
records for each of three implementations and digest sizes; compares selected
long inputs; and checks selected guard-page boundaries. Outputs are written
to build/. Performance results are recorded under results/ and are not rerun
automatically, as reliable measurement requires exclusive coordination.

Directory guide: CryptoCode_Implementation/ holds our optimized implementation and its generator;
Reference_Implementation/ and Optimized_Implementation/ hold baselines;
kat/ holds official vectors; test/ holds validation and benchmark tools;
prebuilt/ holds the verified rebuilt CryptoCode library; results/ records this release.
Use the checked-in CryptoCode C source for rebuilding. Regenerating source is outside
this release procedure; the generator has not been established as CryptoCode-equivalent.

CryptHash takes digest length in bits, message pointer, message length in bits,
and output pointer; allocate at least digest_bits/8 output bytes. Supported
release digest sizes are 512, 768 and 1024. AVX2 is mandatory; no runtime CPU
dispatch or fallback is supplied. No constant-time or security proof is claimed.

Third-party sources retain their existing notices. No new license grant is
invented for upstream sources. See THIRD_PARTY_NOTICES.md and
SOURCE_MANIFEST.json for source identity and file hashes.

Rebuilt-library performance measurements and raw samples are in
results/2026-11-27-rebuilt-comparison/. Earlier comparisons are retained
as historical evidence. See that directory for measurement procedure,
platform and limitations.
