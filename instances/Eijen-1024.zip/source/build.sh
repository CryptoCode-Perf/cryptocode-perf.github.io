#!/bin/sh
set -eu
cd "$(dirname "$0")"
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra -fPIC -shared -I. CryptHash_AlgorithmInstance.c eijen_ref.c -o "../Eijen-1024-rebuilt.so"
