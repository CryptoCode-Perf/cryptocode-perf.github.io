#define _GNU_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <linux/perf_event.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#include <x86intrin.h>
int CryptHash(int,const unsigned char*,unsigned long long,unsigned char*);
static volatile unsigned sink;
static uint64_t now_ns(void) {
    struct timespec ts;if(clock_gettime(CLOCK_MONOTONIC_RAW,&ts))exit(3);
    return (uint64_t)ts.tv_sec*1000000000ULL+(uint64_t)ts.tv_nsec;
}
static uint64_t ticks(void) { unsigned aux;_mm_lfence();uint64_t t=__rdtscp(&aux);_mm_lfence();return t; }
static int cycle_counter(void) {
    struct perf_event_attr attr;memset(&attr,0,sizeof(attr));
    attr.size=sizeof(attr);attr.type=PERF_TYPE_HARDWARE;attr.config=PERF_COUNT_HW_CPU_CYCLES;
    attr.exclude_kernel=1;attr.exclude_hv=1;
    return (int)syscall(SYS_perf_event_open,&attr,0,-1,-1,0);
}
static uint64_t cycle_read(int fd) {
    uint64_t value=0;if(fd>=0 && read(fd,&value,sizeof(value))!=(ssize_t)sizeof(value))exit(4);return value;
}
static uint64_t batch(int bits,const unsigned char *msg,size_t bytes,unsigned count) {
    unsigned char out[1024];unsigned sum=0;uint64_t start=now_ns();
    for(unsigned i=0;i<count;i++) {
        /* Keep repeated calls observable even with whole-program LTO. */
        __asm__ __volatile__("" : : "r"(msg),"r"(out) : "memory");
        if(CryptHash(bits,msg,(unsigned long long)bytes*8,out))exit(5);
        sum+=out[i%((unsigned)bits/8)];
    }
    uint64_t end=now_ns();sink+=sum;return end-start;
}
int main(int argc,char **argv) {
    if(argc!=5)return 2;
    int bits=atoi(argv[1]),samples=atoi(argv[2]);unsigned target_ms=(unsigned)atoi(argv[3]);
    unsigned long seed=strtoul(argv[4],NULL,10);
    if(bits<8||bits>8192||bits%8||samples<100||target_ms<1)return 6;
    const size_t sizes[]={32,128,512,1024,4096,8192,16384,65536};
    unsigned char *msg=malloc(65536);if(!msg)return 7;
    for(size_t i=0;i<65536;i++)msg[i]=(unsigned char)(i*131u+17u);
    int fd=cycle_counter();int cycle_errno=fd<0?errno:0;
    fprintf(stderr,"PERF_COUNTER_FD=%d PERF_COUNTER_ERRNO=%d\n",fd,cycle_errno);
    unsigned iterations[8];
    for(int s=0;s<8;s++) {
        batch(bits,msg,sizes[s],16);unsigned n=1;
        while(batch(bits,msg,sizes[s],n)<(uint64_t)target_ms*1000000ULL&&n<(1u<<22))n*=2;
        iterations[s]=n;
    }
    puts("sample,bytes,iterations,elapsed_ns,ns_per_operation,tsc_ticks_per_operation,user_core_cycles_per_operation");
    for(int sample=0;sample<samples;sample++) {
        int order[8];for(int i=0;i<8;i++)order[i]=i;
        for(int i=7;i>0;i--) {seed=seed*1664525UL+1013904223UL;int j=(int)(seed%(unsigned long)(i+1));int t=order[i];order[i]=order[j];order[j]=t;}
        for(int k=0;k<8;k++) {
            int s=order[k];uint64_t c1=cycle_read(fd),t1=ticks();
            uint64_t elapsed=batch(bits,msg,sizes[s],iterations[s]);
            uint64_t t2=ticks(),c2=cycle_read(fd);
            printf("%d,%zu,%u,%" PRIu64 ",%.9f,%.9f,",sample,sizes[s],iterations[s],elapsed,
                (double)elapsed/iterations[s],(double)(t2-t1)/iterations[s]);
            if(fd>=0)printf("%.9f",(double)(c2-c1)/iterations[s]);
            putchar('\n');
        }
    }
    if(fd>=0)close(fd);
    free(msg);
    return 0;
}
