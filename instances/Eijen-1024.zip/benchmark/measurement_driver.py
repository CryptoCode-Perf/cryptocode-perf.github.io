"""User-requested controlled diagnostic; not a formal win or publishing evidence."""
import hashlib
import json
import math
import os
from pathlib import Path
import sys

root = Path('/mnt/c/CAP')
out = root / 'evaluation/roi/EIJEN_TRANSFER_TIMING_20261127_V1'
plan_path = out / 'PLAN.json'
plan = json.loads(plan_path.read_text())
if not os.environ.get('CAP_NATIVE_GATE_INHERITED'):
    raise RuntimeError('Exclusive native gate required')
bits = sys.argv[1]
item = plan['instances'][bits]
taskid = item['task_id']
task = root / 'lab/runs' / taskid / 'task'
source = root / f'evaluation/roi/EIJEN{bits}_TRANSFER_STUDY_20261127_V1/from_512'
profile = root / 'standards/guide_profile.json'
preflight = root / 'evaluation/registered_refkat' / taskid / 'comparator_preflight/result.json'
paths = {'source': source/'eijen_ref.c', 'wrapper': task/'input/CryptHash_AlgorithmInstance.c',
         'task': task/'task.json', 'preflight': preflight, 'qualification': source/'qualification/result.json',
         'helper': source/'helper_diagnostic_v3/result.json', 'profile': profile}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if any(sha(p) != item['sha256'][k] for k,p in paths.items()):
    raise RuntimeError('Frozen input changed')
pre = json.loads(preflight.read_text())
opt = [Path(p) for p in pre['comparator_sources']]
if any(sha(Path(p)) != digest for p,digest in pre['comparator_sources'].items()):
    raise RuntimeError('Comparator source changed')
if 0 not in os.sched_getaffinity(0):
    raise RuntimeError('CPU 0 unavailable')
os.sched_setaffinity(0, {0})
sys.path.insert(0, str(root/'lab/engine_refkat_paired_v2'))
import cap, guide
cfg = cap.config(task)
variants = {'candidate': ('candidate', [paths['wrapper'], paths['source']], 'performance'),
            'opt': ('official_optimized', opt, 'performance')}
dst = out / bits
dst.mkdir(exist_ok=False)
result = {'status':'running', 'plan_sha256':sha(plan_path), 'gate_id':os.environ['CAP_NATIVE_GATE_INHERITED'],
          'diagnostic_only':True, 'rounds':[]}
try:
    for i, order in enumerate(plan['orders'],1):
        folder = dst / f'round_{i:02d}'
        report = guide.run(task, cfg, [variants[x] for x in order], folder, profile)
        if not report['compile_options_match_guide'] or not report['sample_counts_match_guide']:
            raise RuntimeError('Profile or sample mismatch')
        ratios = {str(n): report['variants']['official_optimized']['summary'][str(n)]['mean_ns'] /
                         report['variants']['candidate']['summary'][str(n)]['mean_ns'] for n in plan['sizes']}
        result['rounds'].append({'ratios':ratios, 'report_sha256':sha(folder/'report.json'),
                                 'eight_gm':math.prod(ratios.values())**(1/len(ratios))})
        (dst/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    result['eight_length_gm'] = math.prod(x['eight_gm'] for x in result['rounds'])**(1/3)
    result['status'] = 'completed_diagnostic_only'
finally:
    (dst/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
