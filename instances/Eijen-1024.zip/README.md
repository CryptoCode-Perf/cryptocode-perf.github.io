# Eijen-1024

Algorithm: Eijen | Digest bits: 1024 | Form: AVX2 C

Contents: implementation source/, public header Eijen-1024.h, prebuilt Eijen-1024.so,
KAT vector KAT_2_12_Eijen-1024.txt, kat_check.py, verify.sh, README.md, and audit/*.md
(RESULT / MODEL / DYNCOUNT / REPRODUCE_FLAGS).

SHA-256(so): a3803c644d62fbf4a295308bc0c91ee16aceca81e094f0224569d2e67e76c58d
Speed (cpB, lower is faster): reference 9.63 / official-optimized 3.95 / optimized 3.66
Speedup: GM(S1-S8) 1.08x — geometric mean of per-tier speedups
relative to the official optimized implementation.

Reproduce:
  bash verify.sh

ABI: int CryptHash(int digest_len_bits, const unsigned char* msg,
                  unsigned long long msg_len_bits, unsigned char* digest);
