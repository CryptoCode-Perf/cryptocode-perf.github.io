# Eijen-1024 controlled transfer diagnostic

This is a cross-instance transfer from Eijen-512, not a verified new-source CAP win. The measured source and raw samples are included. Ratios compare official OPT against the candidate, based on elapsed time. Timing evidence identity reconciliation and independent publication audits are pending. Hardware core cycle counters were unavailable. The previous website archive is retained separately.

Binary SHA-256: 492a2007b7e9da729e835d7f8ecc403928b17a18604fceb81c5230c51e35fedf
